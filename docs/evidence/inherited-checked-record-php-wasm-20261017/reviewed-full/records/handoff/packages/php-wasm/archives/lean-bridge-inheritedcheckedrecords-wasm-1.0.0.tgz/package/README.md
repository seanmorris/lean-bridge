# inheritedcheckedrecords for PHP-Wasm

Import this package's default descriptor and include it in PHP-Wasm's `sharedLibs` array. npm installs the matching Lean runtime dependency. The descriptor registers that runtime once per PHP host and mounts the generated PHP files.

```js
import { PhpNode } from 'php-wasm/PhpNode';
import api from 'lean-bridge-inheritedcheckedrecords-wasm';

const php = new PhpNode({ version: '8.4', sharedLibs: [api] });
await php.run(`<?php require '${api.autoload}';`);
```

Call the generated functions in the `LeanInheritedcheckedrecords` PHP namespace. The `compiled/src/Api.php` file contains their typed declarations. Other descriptors can share the same `sharedLibs` list. Conflicting runtime, component and PHP namespace identities are rejected before startup.

For a Composer application, install the companion `lean-bridge-inheritedcheckedrecords/wasm:1.0.0` ZIP, mount your application's `vendor` directory into PHP-Wasm, and use the named `extensions` export in `sharedLibs` instead of the default descriptor. Require your normal `vendor/autoload.php`. This export registers the native libraries without preloading a second copy of the PHP files.

For first-call loading, import `{ lazy as api }` from this package and pass `dynamicLibs: [api]` instead. With Composer, use `api.extensions` in `dynamicLibs`. The host loads PHP declarations at startup but fetches the Lean runtime and this component only on its first valid API call. An unused component stays unloaded. Different components may choose different modes; registering the same component in both modes is rejected.

This package uses PHP-Wasm 0.1.0, PHP 8.4.1 and the default host variant in Node or Chromium. Register descriptors before constructing the host. Lazy loading requires `enable_dl=1`; await each host request before starting another. After an extension-loading failure, create a new PHP instance. No compiler, FFI extension or install script is required. The handoff receipt verifies package bytes; the descriptor checks compatibility identities, not downloaded byte integrity.

Compound exports use null or Some for Option, Ok or Err for Except, and exact two-element lists for Prod. Some(null) retains a present Unit or an outer Some containing None, according to the declared type. Generated branch classes are final readonly and expose one value property. Calls validate payload types without weak-mode coercion and return independent copies, including nested arrays and records. PHP object identity is not Lean value equality. On wasm32, UInt32, UInt64, Int64, Nat, Int and USize use Brick\Math\BigInteger; ISize uses a 32-bit PHP int. These mappings apply inside compound payloads. Type nesting stops at 32. Validation, Zend conversion and native copying each have a 16 MiB accounting limit, not a bound on Lean working memory. Compound callables, generic or indexed variants and recursive copied types remain unsupported.

Lean List inputs, results and record fields use consecutive-key PHP arrays with `list<T>` PHPDoc. Empty Lists, order, duplicates and nesting are preserved. List and Array retain distinct IR and native identities. Returned mutable values are independent copies. Weak and strict callers receive the same validation and copy-budget checks. List callback payloads remain unsupported.


## Copied Lean aliases

Pass ordinary PHP target values. The binding manifest and installed public source retain alias names, original targets and chains. PHPDoc keeps the PHP target type; lean-bridge annotations record the original Lean contract at parameters, results and record fields. Aliases create no PHP wrapper classes or runtime type aliases. Nat requires a nonnegative Brick\Math\BigInteger, Unit uses null and Char requires one Unicode scalar. Weak and strict callers receive the same target checks. Copied values keep independent storage, the existing copy budgets and the 32-level type-depth bound. Recursive copied types, compound callable payloads and identity-bearing alias targets remain unsupported.

| Lean alias | Contract target | PHP value |
| --- | --- | --- |
| `TicketAlias` | `Ticket` | `Ticket` |

## Value comparison

Generated records, variant cases, Some/Ok/Err and Bytes expose equals($other) and hashCode(). equals compares nested copied contents without numeric-string or other weak coercion and keeps class/constructor identity distinct. NaNs compare equal and signed zeros differ. hashCode returns a matching 64-character hexadecimal value hash; hashes are not a proof of equality or a versioned serialization format. PHP == and === keep their built-in meanings. Comparisons and hashing have a 32-level nesting bound and a 16 MiB traversal budget. Cycles exceed that depth bound; uninitialized values, foreign objects, resources and non-list arrays reject. Do not mutate referenced payloads while using their hash as a lookup key.

## Checked refinements

Lean Fin n parameters and results are Brick\Math\BigInteger values below n. The PHP-Wasm side module compares each argument with its exact bound, including bounds wider than 64 bits, before any Lean code runs; a value at or above its bound throws LeanBridgeError with code 1 whose message names the Lean parameter and bound. Fin 0 has no values, so every call to a function taking one is rejected. Results are BigInteger values below their declared bound. Fin inside arrays, lists and options is checked element by element before Lean runs; an empty array or an absent option is valid even for Fin 0. Bounds below list every element as name[*] and a present option value as name?. Fin inside callbacks or generic record instantiations is not supported in PHP-Wasm packages.

Lean Subtype parameters cross as their base value. The PHP-Wasm side module runs the author's checked constructor, named below, before the export runs; a value the constructor rejects fails the call with the invalid-argument error naming the parameter and constructor, and the export receives the constructed value, which may differ from the input. Arrays, Lists, options, products and active result branches apply the same constructor checks to each Subtype leaf. Rejections identify the argument and nested element path. Subtype results are the base value. Reviewed APIs select the constructor and reconcile it with fresh Lean compilation. Copied plain records check each selected field; variants check only the active case. Repeated uses of one type retain their own constructor choices, and every Fin bound is checked before any constructor. Recursive, generic, owned and callback Subtype positions remain unsupported.

Checked records cross as generated record values containing only their payload fields. The bundled native library validates each input through the constructor selected for that exact occurrence before calling the export. Nested arrays, Lists, options, products, Except values, plain records and active variant cases retain their own checked-record constructors. Fin and Subtype payload fields run their checks before the outer record constructor. A rejection names the argument, nested path and failing constructor or bound. A normalizing constructor changes the copied value received by Lean without changing the caller's record. Results recursively project the payload fields and refined base values of records whose proofs Lean has already constructed. No proof object or input constructor is needed for a result-only export. Ordinary and reviewed APIs retain every per-occurrence constructor choice. Recursive, generic, owned and callback checked-record positions remain unsupported.

- LeanInheritedcheckedrecords\aliased: $value0 checked by InheritedCheckedRecords.mkTicket; $value0.toSpan checked by InheritedCheckedRecords.normalizeSpan; $value0.word checked by InheritedCheckedRecords.normalizeWord
- LeanInheritedcheckedrecords\echo_: $value0 checked by InheritedCheckedRecords.normalizeTicket; $value0.toSpan checked by InheritedCheckedRecords.mkSpan; $value0.word checked by InheritedCheckedRecords.normalizeWord; result projects proof-backed record payload fields; result.toSpan projects proof-backed record payload fields; result.word projects the Subtype base value
- LeanInheritedcheckedrecords\first: $value0 checked by InheritedCheckedRecords.mkTicket; $value0.toSpan checked by InheritedCheckedRecords.mkSpan; $value0.word checked by InheritedCheckedRecords.mkWord
- LeanInheritedcheckedrecords\nested: $value0 checked by InheritedCheckedRecords.mkStamped; $value0.toTicket checked by InheritedCheckedRecords.mkTicket; $value0.toTicket.toSpan checked by InheritedCheckedRecords.mkSpan; $value0.toTicket.word checked by InheritedCheckedRecords.mkWord; $value0.mark < 8
- LeanInheritedcheckedrecords\normalized: $value0 checked by InheritedCheckedRecords.normalizeTicket; $value0.toSpan checked by InheritedCheckedRecords.normalizeSpan; $value0.word checked by InheritedCheckedRecords.normalizeWord
- LeanInheritedcheckedrecords\pair: $value0 checked by InheritedCheckedRecords.mkTicket; $value0.toSpan checked by InheritedCheckedRecords.mkSpan; $value0.word checked by InheritedCheckedRecords.mkWord; $value1 checked by InheritedCheckedRecords.normalizeTicket; $value1.toSpan checked by InheritedCheckedRecords.normalizeSpan; $value1.word checked by InheritedCheckedRecords.normalizeWord
- LeanInheritedcheckedrecords\produce: result projects proof-backed record payload fields; result.toSpan projects proof-backed record payload fields; result.word projects the Subtype base value
- LeanInheritedcheckedrecords\produce_stamped: result projects proof-backed record payload fields; result.toTicket projects proof-backed record payload fields; result.toTicket.toSpan projects proof-backed record payload fields; result.toTicket.word projects the Subtype base value; result.mark < 8
