#include "component.h"
#include "lean_bridge_native_runtime.h"
static _Thread_local int lean_bridge_owned_callback_failure_4c33c6f684c22d557e8a_state;
int lean_bridge_owned_callback_failure_4c33c6f684c22d557e8a(void) { int result = lean_bridge_owned_callback_failure_4c33c6f684c22d557e8a_state; lean_bridge_owned_callback_failure_4c33c6f684c22d557e8a_state = 0; return result; }
