#include "component.h"
#include "lean_bridge_native_runtime.h"
static _Thread_local int lean_bridge_owned_callback_failure_32dbf91ac351343a7e56_state;
int lean_bridge_owned_callback_failure_32dbf91ac351343a7e56(void) { int result = lean_bridge_owned_callback_failure_32dbf91ac351343a7e56_state; lean_bridge_owned_callback_failure_32dbf91ac351343a7e56_state = 0; return result; }
