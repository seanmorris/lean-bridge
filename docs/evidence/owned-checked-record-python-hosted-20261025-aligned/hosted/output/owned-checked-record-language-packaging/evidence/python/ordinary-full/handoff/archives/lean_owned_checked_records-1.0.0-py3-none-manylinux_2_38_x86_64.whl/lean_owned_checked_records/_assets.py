import ctypes as _c
import _ctypes
import hashlib as _hashlib
import json as _json
import os as _os
import pathlib as _pathlib
import platform as _platform
import stat as _stat
import sys as _sys
import threading as _threading
import types as _types

_evidence = _json.loads("{\n  \"componentId\": \"owned-checked-records@1.0.0\",\n  \"componentReceiptSha256\": \"e7649bae9161631a17d436ea2f6225bc153b3d8f8f2a42192ce705e8ccf90519\",\n  \"libraries\": {\n    \"libcomponent_161bdaa35ee11fef40c6.so\": \"ba28a08889ddaed07b8023bad26d3c92ec6312e0b478196bcb1b3f7d543b4019\",\n    \"libgmp.so.10\": \"1980c7331f830ab5291a3ec606e03fdc4d00ce7b8a93da6c64da10806ea36cd7\",\n    \"liblean_bridge_native.so\": \"459fcd2098d4b646ab6ae0f4cdccd1f222908cb162562bfc3940a533cd4e4e21\",\n    \"libleanshared.so\": \"d7768b88d8162736da4305777cd6f147676038fd885bd8a265c958b0ecea00b4\",\n    \"libowned_checked_records.so\": \"3cf449ee874221d764882da011e8c5ab21b92897e663a8e2eebe94da131cea38\"\n  },\n  \"library\": \"libowned_checked_records.so\",\n  \"ownedValues\": {\n    \"abiHeaderSha256\": \"cbd92e104a394f57f66415008ac5c8089b6c8d789868bddd7b629e138b5f2647\",\n    \"callbackFailure\": \"raise-after-native-return\",\n    \"callbackLifetime\": \"call\",\n    \"conversionsSha256\": \"a6544c213f331d4ddfc62c48da5f95e5dbbc583ae385371c455ddcee53ac2507\",\n    \"exactIntegers\": \"python-int\",\n    \"explicitRetention\": \"retain\",\n    \"inputTransfers\": {\n      \"aliases\": \"shared-lease\",\n      \"arguments\": \"ordinary-values\",\n      \"borrowedInputs\": \"reject\",\n      \"consumption\": \"before-lean-call\",\n      \"failure\": \"consumed-after-handoff\",\n      \"independentRetains\": \"preserved\",\n      \"schemaVersion\": 1,\n      \"validation\": \"before-consumption\"\n    },\n    \"language\": \"python-3.11\",\n    \"limits\": {\n      \"bytes\": 16777216,\n      \"depth\": 128,\n      \"retained\": 4096,\n      \"visits\": 262144\n    },\n    \"loader\": \"authenticated-bundled-native\",\n    \"loaderSha256\": \"db5e100249b15b5016167eb7cb89da2be64393f0f2d45f7b5ffdd3323569ca60\",\n    \"ownership\": \"checked-result-leases\",\n    \"publicSha256\": \"e87681efcd44c00389cbe8f7b79dddb627acff46ae705d7585f90464b365a006\",\n    \"runtimeSha256\": \"afeb0a968e058feb64f7200f80ac1a8d91f770b420c036339860666ad934ed5a\",\n    \"schemaVersion\": 2,\n    \"stubSha256\": \"8454912dcb4cb2e1e7f8f09c14b8d0be610bea626fd21afc088f2267cfc51204\"\n  },\n  \"runtimeIdentity\": \"4b5a7fdf0cb11d4bb429181cfd50b330c5622ed8f5f5382a293955a439b595b5\"\n}\n")
if _evidence is None:
    raise ImportError("Build a compiled PyPI release before importing this API")
if (_sys.version_info < (3, 11) or _sys.platform != "linux"
        or _platform.machine() not in ("x86_64", "AMD64")
        or _c.sizeof(_c.c_void_p) != 8 or _sys.byteorder != "little"):
    raise ImportError("This Lean package requires Python 3.11+ on Linux x86-64")
if hasattr(_sys, "_is_gil_enabled") and not _sys._is_gil_enabled():
    raise ImportError("This Lean package requires a GIL-enabled interpreter")

_PID = _os.getpid()
_root = _pathlib.Path(__file__).resolve().parent / "native" / "linux-x64"
for _directory in (_root.parent, _root):
    if not _stat.S_ISDIR(_directory.lstat().st_mode):
        raise ImportError("Native library directory is not a regular directory")
_libraries = _evidence["libraries"]
for _name, _expected in _libraries.items():
    _path = _root / _name
    if not _stat.S_ISREG(_path.lstat().st_mode):
        raise ImportError("Native library is not a regular file: " + _name)
    with _path.open("rb") as _stream:
        _actual = _hashlib.file_digest(_stream, "sha256").hexdigest()
    if _actual != _expected:
        raise ImportError("Native library differs from compiled evidence: " + _name)

# Reuse the interpreter registry used by copied-value Python packages.
# No shared on-disk module: removing one wheel cannot remove another's loader.
_candidate = _types.ModuleType("_lean_bridge_copied_runtime_v1")
_candidate.lock = _threading.RLock()
_candidate.pid = _PID
_candidate.identity = None
_candidate.failed = False
_candidate.components = {}
_candidate.libraries = {}
_candidate.handles = []
_state = _sys.modules.setdefault(_candidate.__name__, _candidate)
if _state.pid != _PID:
    raise ImportError("Start a fresh Python interpreter after fork to use Lean packages")

def _reject_unverified_loaded(name):
    for candidate in (name, str(_root / name)):
        try:
            probe = _c.CDLL(candidate, mode=_os.RTLD_NOW | _os.RTLD_NOLOAD)
        except OSError:
            continue
        _ctypes.dlclose(probe._handle)
        raise ImportError("Unverified native library is already loaded: " + name)

with _state.lock:
    if _state.failed:
        raise ImportError("Lean native loading failed earlier in this interpreter")
    if _state.identity not in (None, _evidence["runtimeIdentity"]):
        raise ImportError("Incompatible Lean runtime identities")
    for _name, _expected in _libraries.items():
        if _state.libraries.get(_name, _expected) != _expected:
            raise ImportError("Conflicting builds of the same native library: " + _name)
    _previous = _state.components.get(_evidence["componentId"])
    _identity = "58c2dcbc55b9b6a1b9fcb71ad54cf2c91a327ef0201e6d62fe54bc93c1a17077"
    if _previous is not None and _previous[0] != _identity:
        raise ImportError("Conflicting builds of the same Lean component")
    try:
        if _previous is None:
            # Check every unknown SONAME before loading any new library.
            for _name in _libraries:
                if _name not in _state.libraries:
                    _reject_unverified_loaded(_name)
            _order = ["libleanshared.so", "liblean_bridge_native.so"]
            _order += [name for name in _libraries
                       if name not in (*_order, _evidence["library"])]
            _order.append(_evidence["library"])
            for _name in _order:
                if _name not in _state.libraries:
                    _loaded = _c.CDLL(str(_root / _name), mode=_os.RTLD_NOW | _os.RTLD_GLOBAL)
                    _state.handles.append(_loaded)
                    _state.libraries[_name] = _libraries[_name]
                else:
                    _loaded = next(item for item in _state.handles
                                   if _pathlib.Path(item._name).name == _name)
            _previous = (_identity, _loaded)
            _state.components[_evidence["componentId"]] = _previous
            _state.identity = _evidence["runtimeIdentity"]
        _LIBRARY = _previous[1]
    except BaseException:
        _state.failed = True
        raise

def _ensure_process():
    if _os.getpid() != _PID:
        raise RuntimeError("Start a fresh Python interpreter after fork to use Lean packages")
