#include "owned/src/owned_checked_records.c"
#include "runtime.h"
#include "owned_checked_records.h"

#include "EXTERN.h"
#include "perl.h"
#include "XSUB.h"
#include <stdlib.h>
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <stdio.h>
_Static_assert(sizeof(void *) == 8 && sizeof(IV) == 8 && sizeof(UV) == 8, "Perl graph conversion requires a 64-bit ABI");
#ifndef LB_PERL_GRAPH_MALLOC
#define LB_PERL_GRAPH_MALLOC malloc
#endif
#ifndef LB_PERL_GRAPH_FREE
#define LB_PERL_GRAPH_FREE free
#endif
#ifndef LB_PERL_GRAPH_CHECKPOINT
#define LB_PERL_GRAPH_CHECKPOINT() ((void)0)
#endif
typedef struct lpg_allocation {
  struct lpg_allocation *next;
  max_align_t alignment;
  unsigned char data[];
} lpg_allocation;
typedef struct {
  lpg_allocation *allocations;
  void *output;
  void (*clear)(void *);
  void (*retire)(void);
  size_t native_bytes, storage_bytes, nodes;
  struct { const void *address; size_t type; } path[129];
} lpg_scope;
static void lpg_close(lpg_scope *scope) {
  void *output = scope->output; scope->output = NULL;
  if (output && scope->clear) scope->clear(output);
  lpg_allocation *allocation = scope->allocations; scope->allocations = NULL;
  while (allocation) {
    lpg_allocation *next = allocation->next;
    LB_PERL_GRAPH_FREE(allocation); allocation = next;
  }
}
static void lpg_end(pTHX_ void *value) {
  PERL_UNUSED_CONTEXT;
  lpg_scope *scope = value; lpg_close(scope); LB_PERL_GRAPH_FREE(scope);
}
static lpg_scope *lpg_begin(pTHX_ void (*retire)(void)) {
  /* Grow Perl's save stack before acquiring memory needing its destructor. */
  SSGROW(4);
  LB_PERL_GRAPH_CHECKPOINT();
  lpg_scope *scope = LB_PERL_GRAPH_MALLOC(sizeof(*scope));
  if (!scope) croak("Perl graph allocation failed");
  memset(scope, 0, sizeof(*scope));
  SAVEDESTRUCTOR_X(lpg_end, scope);
  scope->retire = retire;
  scope->native_bytes = scope->storage_bytes = 16 * 1024 * 1024;
  scope->nodes = 262144;
  return scope;
}
static void lpg_charge(pTHX_ size_t *remaining, size_t count, size_t width) {
  if (!width || count > *remaining / width) croak("Perl copied graph storage limit exceeded");
  *remaining -= count * width;
}
static void *lpg_allocate(pTHX_ lpg_scope *scope, size_t count, size_t width) {
  if (!count) return NULL;
  lpg_charge(aTHX_ &scope->storage_bytes, count, width);
  lpg_charge(aTHX_ &scope->storage_bytes, 1, sizeof(lpg_allocation));
  LB_PERL_GRAPH_CHECKPOINT();
  lpg_allocation *allocation = LB_PERL_GRAPH_MALLOC(sizeof(*allocation) + count * width);
  if (!allocation) croak("Perl graph allocation failed");
  allocation->next = scope->allocations; scope->allocations = allocation;
  memset(allocation->data, 0, count * width); return allocation->data;
}
static void lpg_invalid(pTHX_ lpg_scope *scope, const char *message) {
  if (scope->retire) scope->retire();
  croak("Invalid native copied graph: %s", message);
}
static void lpg_enter(pTHX_ lpg_scope *scope, const void *value, size_t type, size_t depth, size_t native_storage, int output) {
  if (depth > 128 || !scope->nodes) croak("Perl copied graph depth or node limit exceeded");
  --scope->nodes;
  lpg_charge(aTHX_ &scope->native_bytes, native_storage, 1);
  for (size_t i = 0; value && i < depth; ++i) if (scope->path[i].address == value && scope->path[i].type == type) {
    if (output) lpg_invalid(aTHX_ scope, "cycle");
    croak("Cyclic Perl copied value");
  }
  scope->path[depth].address = value; scope->path[depth].type = type;
}
static void lpg_pointer(pTHX_ lpg_scope *scope, const void *pointer, size_t count, size_t width, size_t alignment) {
  if (!count) return;
  if (!pointer || (uintptr_t)pointer % alignment || count > (UINTPTR_MAX - (uintptr_t)pointer) / width)
    lpg_invalid(aTHX_ scope, "missing, misaligned or overflowing span");
  /* Authenticated native producers supply readable process memory. */
}
static SV *lpg_pin(pTHX_ SV *value) {
  EXTEND_MORTAL(1); return sv_2mortal(SvREFCNT_inc(value));
}
static SV *lpg_sv(pTHX_ lpg_scope *scope) {
  lpg_charge(aTHX_ &scope->storage_bytes, 1, sizeof(SV) + 64);
  LB_PERL_GRAPH_CHECKPOINT(); EXTEND_MORTAL(1);
  return sv_2mortal(newSV(0));
}
static SV *lpg_text(pTHX_ lpg_scope *scope, const char *text, size_t length, int unicode) {
  lpg_charge(aTHX_ &scope->storage_bytes, length + 1, 1);
  SV *value = lpg_sv(aTHX_ scope);
  LB_PERL_GRAPH_CHECKPOINT(); sv_setpvn(value, length ? text : "", length);
  if (unicode) SvUTF8_on(value);
  return value;
}
static HV *lpg_hash(pTHX_ lpg_scope *scope) {
  lpg_charge(aTHX_ &scope->storage_bytes, 1, sizeof(HV) + 128);
  LB_PERL_GRAPH_CHECKPOINT(); EXTEND_MORTAL(1);
  return (HV *)sv_2mortal((SV *)newHV());
}
static AV *lpg_array(pTHX_ lpg_scope *scope, size_t length) {
  lpg_charge(aTHX_ &scope->storage_bytes, length, sizeof(SV *) + sizeof(SV) + 64);
  lpg_charge(aTHX_ &scope->storage_bytes, 1, sizeof(AV) + 128);
  LB_PERL_GRAPH_CHECKPOINT(); EXTEND_MORTAL(1);
  AV *value = (AV *)sv_2mortal((SV *)newAV());
  if (length) { LB_PERL_GRAPH_CHECKPOINT(); av_extend(value, length - 1); }
  return value;
}
static SV *lpg_reference(pTHX_ lpg_scope *scope, SV *referent, const char *package) {
  SV *value = lpg_sv(aTHX_ scope);
  LB_PERL_GRAPH_CHECKPOINT(); sv_setrv_inc(value, referent);
  if (package) { LB_PERL_GRAPH_CHECKPOINT(); sv_bless(value, gv_stashpv(package, GV_ADD)); }
  return value;
}
static void lpg_store(pTHX_ lpg_scope *scope, HV *hash, const char *field, SV *value) {
  lpg_charge(aTHX_ &scope->storage_bytes, 1, sizeof(SV) + 64 + strlen(field));
  LB_PERL_GRAPH_CHECKPOINT(); SV **slot = hv_fetch(hash, field, strlen(field), 1);
  if (!slot) croak("Perl graph field allocation failed");
  LB_PERL_GRAPH_CHECKPOINT(); sv_setsv(*slot, value);
}
static void lpg_append(pTHX_ AV *array, size_t index, SV *value) {
  LB_PERL_GRAPH_CHECKPOINT(); SV **slot = av_fetch(array, index, 1);
  if (!slot) croak("Perl graph element allocation failed");
  LB_PERL_GRAPH_CHECKPOINT(); sv_setsv(*slot, value);
}
static int lpg_branch(SV *value, const char *package) {
  if (!SvROK(value) || SvTYPE(SvRV(value)) != SVt_PVHV || SvMAGICAL(SvRV(value)) || !SvOBJECT(SvRV(value))) return 0;
  HV *stash = SvSTASH(SvRV(value));
  const char *name = stash ? HvNAME(stash) : NULL;
  return name && strEQ(name, package);
}
static SV **lpg_fields(pTHX_ lpg_scope *scope, SV *value, const char *package, const char *const *fields, size_t count) {
  if (!lpg_branch(value, package)) croak("Expected exact %s with a plain untied hash", package);
  HV *input = (HV *)lpg_pin(aTHX_ SvRV(value));
  if (HvUSEDKEYS(input) != count) croak("Perl graph fields do not match the generated schema");
  SV **slots = lpg_allocate(aTHX_ scope, count, sizeof(SV *));
  /* Pin every slot before a child conversion can invoke Perl. */
  for (size_t i = 0; i < count; ++i) {
    SV **entry = hv_fetch(input, fields[i], strlen(fields[i]), 0);
    if (!entry) croak("Missing Perl graph field %s", fields[i]);
    slots[i] = lpg_pin(aTHX_ *entry);
  }
  return slots;
}
static SV **lpg_sequence(pTHX_ lpg_scope *scope, SV *value, size_t *length) {
  if (!SvROK(value) || SvTYPE(SvRV(value)) != SVt_PVAV || SvOBJECT(SvRV(value)) ||
      (SvMAGICAL(SvRV(value)) && mg_find(SvRV(value), PERL_MAGIC_tied))) croak("Expected a plain untied array reference");
  AV *array = (AV *)lpg_pin(aTHX_ SvRV(value)); *length = av_count(array);
  if (*length > scope->nodes) croak("Perl copied graph node limit exceeded");
  SV **slots = lpg_allocate(aTHX_ scope, *length, sizeof(SV *));
  for (size_t i = 0; i < *length; ++i) {
    SV **entry = av_fetch(array, i, 0);
    if (!entry) croak("Sparse Perl copied arrays are unsupported");
    slots[i] = lpg_pin(aTHX_ *entry);
  }
  return slots;
}
static uint64_t lpg_unsigned(pTHX_ SV *value, uint64_t maximum) {
  if (!SvIOK(value) || (!SvIsUV(value) && SvIV(value) < 0) || SvUV(value) > maximum)
    croak("Unsigned integer is out of range or not an exact integer scalar");
  return (uint64_t)SvUV(value);
}
static int64_t lpg_signed(pTHX_ SV *value, int64_t minimum, int64_t maximum) {
  if (!SvIOK(value) || (SvIsUV(value) && SvUV(value) > (uint64_t)maximum) ||
      (!SvIsUV(value) && (SvIV(value) < minimum || SvIV(value) > maximum)))
    croak("Signed integer is out of range or not an exact integer scalar");
  return (int64_t)SvIV(value);
}
static SV *lpg_bigint_text(pTHX_ lpg_scope *scope, SV *value, int natural) {
  if (!SvROK(value) || !sv_derived_from(value, "Math::BigInt")) croak("Expected Math::BigInt");
  LB_PERL_GRAPH_CHECKPOINT();
  dSP; PUSHMARK(SP); XPUSHs(value); PUTBACK;
  int count = call_method("bstr", G_SCALAR); SPAGAIN;
  if (count != 1) { SP -= count; PUTBACK; croak("Math::BigInt must return one decimal value"); }
  SV *text = POPs; PUTBACK; lpg_pin(aTHX_ text); SvGETMAGIC(text);
  if (SvROK(text) || (!SvPOK(text) && !SvIOK(text) && !SvNOK(text))) croak("Math::BigInt must return a decimal scalar");
  LB_PERL_GRAPH_CHECKPOINT();
  STRLEN length; const char *bytes = SvPV_nomg(text, length);
  lpg_charge(aTHX_ &scope->storage_bytes, length, 1);
  size_t i = 0;
  if (!length) croak("Invalid Math::BigInt");
  if (bytes[0] == '-') { if (natural) croak("Nat cannot be negative"); i = 1; }
  if (i == length) croak("Invalid Math::BigInt");
  for (; i < length; ++i) if (bytes[i] < '0' || bytes[i] > '9') croak("Math::BigInt must be finite and integral");
  return text;
}
static const uint32_t *lpg_limbs(pTHX_ lpg_scope *scope, SV *value, int natural, size_t *count, int *negative) {
  SV *text = lpg_bigint_text(aTHX_ scope, value, natural);
  STRLEN length; const char *bytes = SvPV_nomg(text, length);
  *negative = bytes[0] == '-'; bytes += *negative; length -= *negative;
  while (length && *bytes == '0') { ++bytes; --length; }
  if (!length) { *count = 0; *negative = 0; return NULL; }
  size_t capacity = length / 9 + 1;
  uint32_t *limbs = lpg_allocate(aTHX_ scope, capacity, sizeof(uint32_t));
  size_t used = 0;
  while (length) {
    size_t digits = length % 9; if (!digits) digits = 9;
    uint32_t factor = 1, chunk = 0;
    for (size_t i = 0; i < digits; ++i) { factor *= 10; chunk = chunk * 10 + (bytes[i] - '0'); }
    uint64_t carry = chunk;
    for (size_t i = 0; i < used; ++i) { carry += (uint64_t)limbs[i] * factor; limbs[i] = (uint32_t)carry; carry >>= 32; }
    if (carry) { if (used == capacity) croak("Perl graph limb capacity exceeded"); limbs[used++] = (uint32_t)carry; }
    bytes += digits; length -= digits;
  }
  lpg_charge(aTHX_ &scope->native_bytes, used, sizeof(uint32_t));
  *count = used; return limbs;
}
static SV *lpg_bigint(pTHX_ lpg_scope *scope, const uint32_t *limbs, size_t count, int negative) {
  while (count && !limbs[count - 1]) --count;
  uint32_t *work = lpg_allocate(aTHX_ scope, count, sizeof(uint32_t));
  if (count) memcpy(work, limbs, count * sizeof(uint32_t));
  size_t capacity = count * 2 + 1;
  uint32_t *chunks = lpg_allocate(aTHX_ scope, capacity, sizeof(uint32_t));
  size_t used = 0;
  while (count) {
    uint64_t remainder = 0;
    for (size_t i = count; i > 0; --i) { uint64_t value = (remainder << 32) | work[i - 1]; work[i - 1] = value / 1000000000; remainder = value % 1000000000; }
    chunks[used++] = remainder;
    while (count && !work[count - 1]) --count;
  }
  char *bytes = lpg_allocate(aTHX_ scope, used * 9 + 3, 1), *cursor = bytes;
  if (negative && used) *cursor++ = '-';
  if (!used) *cursor++ = '0';
  else { cursor += sprintf(cursor, "%u", chunks[--used]); while (used) cursor += sprintf(cursor, "%09u", chunks[--used]); }
  SV *text = lpg_text(aTHX_ scope, bytes, cursor - bytes, 0), *klass = lpg_text(aTHX_ scope, "Math::BigInt", 12, 0);
  LB_PERL_GRAPH_CHECKPOINT(); dSP; PUSHMARK(SP); XPUSHs(klass); XPUSHs(text); PUTBACK;
  int returns = call_method("new", G_SCALAR); SPAGAIN;
  if (returns != 1) { SP -= returns; PUTBACK; croak("Math::BigInt construction failed"); }
  SV *result = POPs; PUTBACK; lpg_pin(aTHX_ result);
  if (!SvROK(result) || !sv_derived_from(result, "Math::BigInt")) croak("Math::BigInt constructor returned an invalid value");
  return result;
}

#include <pthread.h>
#include <unistd.h>
#ifndef LB_PERL_OWNED_MALLOC
#define LB_PERL_OWNED_MALLOC malloc
#endif
#ifndef LB_PERL_OWNED_FREE
#define LB_PERL_OWNED_FREE free
#endif
#ifdef MULTIPLICITY
#define LPO_CONTEXT aTHX
#else
#define LPO_CONTEXT ((PerlInterpreter *)1)
#endif
typedef struct lpo_owner lpo_owner;
struct lpo_owner {
  lpo_owner *previous, *next;
  owned_checked_records_result *result;
  size_t references;
  int published, borrowed, valid;
};
typedef struct {
  lpo_owner *owner;
  void *handle;
  size_t type;
  const char *package;
} lpo_wrapper;
static struct {
  owned_checked_records_session *session;
  lpo_owner *owners;
  PerlInterpreter *interpreter;
  pthread_t thread;
  pid_t process;
  unsigned active;
  int initialized, closed, cleanup_status;
} lpo_state;
static int lpo_origin(pTHX) {
  return lpo_state.initialized && lpo_state.process == getpid()
    && lpo_state.interpreter == LPO_CONTEXT
    && pthread_equal(lpo_state.thread, pthread_self());
}
static void lpo_context(pTHX) {
  if (!lpo_origin(aTHX))
    croak("Lean ownership requires its initiating process and Perl interpreter thread");
}
static void lpo_status(pTHX_ unsigned status) {
  if (!status) return;
  const char *message = status == 1 ? "invalid argument" : status == 2 ? "conversion limit exceeded"
    : status == 3 ? "allocation failed" : status == 4 ? "resource closed"
    : status == 5 ? "wrong thread" : status == 6 ? "wrong process"
    : status == 7 ? "shared runtime unavailable" : status == 8 ? "invalid call order"
    : status == 9 ? "malformed native result" : status == 10 ? "host callback failed" : "unknown status";
  croak("Lean ownership failed (status=%u): %s", status, message);
}
static void lpo_release_native(pTHX_ lpo_owner *owner) {
  if (!owner->result) return;
  if (!lpo_origin(aTHX)) { owner->result = NULL; return; }
  unsigned status = owned_checked_records_result_release(&owner->result);
  if (status && !lpo_state.cleanup_status) lpo_state.cleanup_status = (int)status;
}
static void lpo_hold(pTHX_ lpo_owner *owner) {
  if (!owner || owner->references == SIZE_MAX) croak("Perl ownership reference limit exceeded");
  ++owner->references;
}
static void lpo_release(pTHX_ lpo_owner *owner) {
  if (!owner || !owner->references) return;
  if (--owner->references) return;
  lpo_release_native(aTHX_ owner);
  if (owner->previous) owner->previous->next = owner->next;
  else lpo_state.owners = owner->next;
  if (owner->next) owner->next->previous = owner->previous;
  LB_PERL_OWNED_FREE(owner);
}
static void lpo_end_owner(pTHX_ void *data) {
  lpo_owner *owner = data;
  if (!owner->published || owner->borrowed) {
    owner->valid = 0;
    lpo_release_native(aTHX_ owner);
  }
  lpo_release(aTHX_ owner);
}
static lpo_owner *lpo_begin_owner(pTHX_ int borrowed) {
  lpo_context(aTHX);
  if (lpo_state.closed) croak("Lean ownership session is closed");
  /* No native owner exists until its save-stack cleanup is registered. */
  SSGROW(4);
  LB_PERL_GRAPH_CHECKPOINT();
  lpo_owner *owner = LB_PERL_OWNED_MALLOC(sizeof(*owner));
  if (!owner) croak("Perl ownership allocation failed");
  memset(owner, 0, sizeof(*owner));
  owner->references = 1; owner->borrowed = borrowed; owner->valid = 1;
  SAVEDESTRUCTOR_X(lpo_end_owner, owner);
  owner->next = lpo_state.owners;
  if (owner->next) owner->next->previous = owner;
  lpo_state.owners = owner;
  return owner;
}
static void lpo_publish(pTHX_ lpo_owner *owner) {
  lpo_context(aTHX);
  if (!owner || !owner->valid || owner->borrowed || lpo_state.closed)
    croak("Invalid Perl ownership publication");
  owner->published = 1;
}
static void lpo_wrapper_close(pTHX_ lpo_wrapper *wrapper) {
  lpo_owner *owner = wrapper->owner;
  wrapper->owner = NULL; wrapper->handle = NULL;
  lpo_release(aTHX_ owner);
}
static int lpo_wrapper_free(pTHX_ SV *value, MAGIC *magic) {
  (void)value;
  lpo_wrapper *wrapper = (lpo_wrapper *)magic->mg_ptr;
  magic->mg_ptr = NULL;
  if (wrapper) {
    lpo_wrapper_close(aTHX_ wrapper);
    LB_PERL_OWNED_FREE(wrapper);
  }
  return 0;
}
#ifdef USE_ITHREADS
static int lpo_wrapper_dup(pTHX_ MAGIC *magic, CLONE_PARAMS *params) {
  PERL_UNUSED_CONTEXT; (void)params;
  magic->mg_ptr = NULL;
  return 0;
}
#endif
static MGVTBL lpo_wrapper_magic = {
  .svt_free = lpo_wrapper_free,
#ifdef USE_ITHREADS
  .svt_dup = lpo_wrapper_dup,
#endif
};
static SV *lpo_wrap(pTHX_ lpg_scope *scope, lpo_owner *owner,
    void *handle, size_t type, const char *package) {
  lpo_context(aTHX);
  if (!owner || !owner->valid || !handle || (!owner->borrowed && !owner->result))
    lpg_invalid(aTHX_ scope, "missing resource owner");
  HV *hash = lpg_hash(aTHX_ scope);
  SV *value = lpg_reference(aTHX_ scope, (SV *)hash, package);
  lpg_charge(aTHX_ &scope->storage_bytes, 1, sizeof(lpo_wrapper));
  LB_PERL_GRAPH_CHECKPOINT();
  MAGIC *magic = sv_magicext((SV *)hash, NULL, PERL_MAGIC_ext, &lpo_wrapper_magic, NULL, 0);
#ifdef USE_ITHREADS
  magic->mg_flags |= MGf_DUP;
#endif
  LB_PERL_GRAPH_CHECKPOINT();
  lpo_wrapper *wrapper = LB_PERL_OWNED_MALLOC(sizeof(*wrapper));
  if (!wrapper) croak("Perl ownership allocation failed");
  memset(wrapper, 0, sizeof(*wrapper)); magic->mg_ptr = (char *)wrapper;
  lpo_hold(aTHX_ owner);
  wrapper->owner = owner; wrapper->handle = handle;
  wrapper->type = type; wrapper->package = package;
  return value;
}
static lpo_wrapper *lpo_get(pTHX_ SV *value, size_t type) {
  SvGETMAGIC(value); lpo_context(aTHX);
  if (!SvROK(value) || SvTYPE(SvRV(value)) != SVt_PVHV || !SvOBJECT(SvRV(value)))
    croak("Expected a generated Lean resource or closure");
  MAGIC *magic = mg_findext(SvRV(value), PERL_MAGIC_ext, &lpo_wrapper_magic);
  if (!magic || !magic->mg_ptr) croak("Invalid or foreign Lean identity");
  lpo_wrapper *wrapper = (lpo_wrapper *)magic->mg_ptr;
  HV *stash = SvSTASH(SvRV(value));
  const char *name = stash ? HvNAME(stash) : NULL;
  if (wrapper->type != type || !name || strcmp(name, wrapper->package))
    croak("Wrong Lean identity type");
  return wrapper;
}
static int lpo_closed(lpo_wrapper *wrapper) {
  return lpo_state.closed || !wrapper->handle || !wrapper->owner
    || !wrapper->owner->valid
    || (!wrapper->owner->published && !wrapper->owner->borrowed);
}
static void lpo_unpin(pTHX_ void *data) { lpo_release(aTHX_ data); }
static void *lpo_borrow(pTHX_ SV *value, size_t type) {
  lpo_wrapper *wrapper = lpo_get(aTHX_ value, type);
  if (lpo_closed(wrapper)) croak("Lean identity is closed or its callback borrow has expired");
  /* Explicit close during reentry cannot release an in-flight input owner. */
  SSGROW(4);
  lpo_hold(aTHX_ wrapper->owner);
  SAVEDESTRUCTOR_X(lpo_unpin, wrapper->owner);
  return wrapper->handle;
}
static void lpo_drain(pTHX) {
  if (!lpo_origin(aTHX) || !lpo_state.closed || lpo_state.active) return;
  for (lpo_owner *owner = lpo_state.owners; owner; owner = owner->next) {
    owner->valid = 0; lpo_release_native(aTHX_ owner);
  }
  unsigned status = owned_checked_records_session_close(&lpo_state.session);
  if (status && !lpo_state.cleanup_status) lpo_state.cleanup_status = (int)status;
}
static void lpo_shutdown(pTHX_ void *unused) {
  (void)unused;
  if (!lpo_origin(aTHX)) return;
  lpo_state.closed = 1; lpo_drain(aTHX);
}
static void lpo_end_call(pTHX_ void *unused) {
  (void)unused;
  if (lpo_state.active) --lpo_state.active;
  lpo_drain(aTHX);
}
static void lpo_enter_call(pTHX) {
  lpo_context(aTHX);
  if (lpo_state.closed) croak("Lean ownership session is closed");
  if (lpo_state.active == 64) croak("Perl ownership reentry limit exceeded");
  SSGROW(4);
  ++lpo_state.active;
  SAVEDESTRUCTOR_X(lpo_end_call, NULL);
}
static void lpo_boot(pTHX) {
  if (lpo_state.initialized) { lpo_context(aTHX); return; }
  lpo_state.interpreter = LPO_CONTEXT; lpo_state.thread = pthread_self();
  lpo_state.process = getpid(); lpo_state.initialized = 1; lpo_state.closed = 1;
  /* Register shutdown before acquiring a native session. */
  call_atexit(lpo_shutdown, NULL);
  lpo_status(aTHX_ owned_checked_records_session_open(&lpo_state.session));
  lpo_state.closed = 0;
}


static void lpo_clear_integer(pTHX_ void *value) {
  PERL_UNUSED_CONTEXT; mpz_clear(value);
}
static mpz_srcptr lpo_read_integer(pTHX_ lpg_scope *scope, SV *value, int natural) {
  SV *text = lpg_bigint_text(aTHX_ scope, value, natural);
  STRLEN length; const char *bytes = SvPV_nomg(text, length);
  lpg_charge(aTHX_ &scope->native_bytes, length, 1);
  mpz_ptr number = lpg_allocate(aTHX_ scope, 1, sizeof(*number));
  SSGROW(4); mpz_init(number); SAVEDESTRUCTOR_X(lpo_clear_integer, number);
  LB_PERL_GRAPH_CHECKPOINT();
  if (mpz_set_str(number, bytes, 10)) croak("Invalid integral Math::BigInt");
  return number;
}
static SV *lpo_write_integer(pTHX_ lpg_scope *scope, mpz_srcptr value, int natural) {
  lpg_pointer(aTHX_ scope, value, 1, sizeof(*value), _Alignof(__mpz_struct));
  if (natural && mpz_sgn(value) < 0) lpg_invalid(aTHX_ scope, "negative Nat");
  if (mpz_size(value) > scope->native_bytes / sizeof(mp_limb_t))
    croak("Perl ownership integer storage limit exceeded");
  size_t count = mpz_sgn(value) ? (mpz_sizeinbase(value, 2) - 1) / 32 + 1 : 0;
  lpg_charge(aTHX_ &scope->native_bytes, count, sizeof(uint32_t));
  uint32_t *limbs = lpg_allocate(aTHX_ scope, count, sizeof(uint32_t));
  size_t written = 0;
  if (count) mpz_export(limbs, &written, -1, sizeof(uint32_t), 0, 0, value);
  if (written != count) lpg_invalid(aTHX_ scope, "integer limb count");
  return lpg_bigint(aTHX_ scope, limbs, count, mpz_sgn(value) < 0);
}

static void lpo_read0(pTHX_ lpg_scope *, SV *, owned_checked_records_value_160ce821a84f6887bbfd_t *, size_t, int);
static SV *lpo_write0(pTHX_ lpg_scope *, lpo_owner *, owned_checked_records_value_160ce821a84f6887bbfd_t const *, size_t, int);
static void lpo_read1(pTHX_ lpg_scope *, SV *, owned_checked_records_claim_t *, size_t, int);
static SV *lpo_write1(pTHX_ lpg_scope *, lpo_owner *, owned_checked_records_claim_t const *, size_t, int);
static void lpo_read2(pTHX_ lpg_scope *, SV *, owned_checked_records_ticket_t *, size_t, int);
static SV *lpo_write2(pTHX_ lpg_scope *, lpo_owner *, owned_checked_records_ticket_t const *, size_t, int);
static void lpo_read3(pTHX_ lpg_scope *, SV *, mpz_srcptr *, size_t, int);
static SV *lpo_write3(pTHX_ lpg_scope *, lpo_owner *, mpz_srcptr const *, size_t, int);
static void lpo_read4(pTHX_ lpg_scope *, SV *, owned_checked_records_scalar_string_t *, size_t, int);
static SV *lpo_write4(pTHX_ lpg_scope *, lpo_owner *, owned_checked_records_scalar_string_t const *, size_t, int);
static void lpo_read0(pTHX_ lpg_scope *scope, SV *value, owned_checked_records_value_160ce821a84f6887bbfd_t *out, size_t depth, int storage) {
  (void)out; SvGETMAGIC(value);
  lpg_enter(aTHX_ scope, SvROK(value) ? SvRV(value) : NULL, 0, depth, storage ? sizeof(*out) : 0, 0);
  if (!SvOK(value)) { out->has_value = 0; return; }
  if (lpg_branch(value, "LeanBridge::OwnedCheckedRecords::Some")) { out->has_value = 1;
  static const char *const fields[] = {"value"};
  SV **slots = lpg_fields(aTHX_ scope, value, "LeanBridge::OwnedCheckedRecords::Some", fields, 1); (void)slots;
  { owned_checked_records_claim_t *child = lpg_allocate(aTHX_ scope, 1, sizeof(*child)); out->value = child; lpo_read1(aTHX_ scope, slots[0], child, depth + 1, 1); }
  return;
  }
  croak("Expected undef or Some");
}
static SV *lpo_write0(pTHX_ lpg_scope *scope, lpo_owner *owner, owned_checked_records_value_160ce821a84f6887bbfd_t const *value, size_t depth, int storage) {
  (void)owner;
  lpg_pointer(aTHX_ scope, value, 1, sizeof(*value), _Alignof(owned_checked_records_value_160ce821a84f6887bbfd_t));
  lpg_enter(aTHX_ scope, value, 0, depth, storage ? sizeof(*value) : 0, 1);
  uint8_t flag; memcpy(&flag, &value->has_value, 1); if (flag > 1) lpg_invalid(aTHX_ scope, "branch flag");
  if (!flag) return &PL_sv_undef;
  {
  HV *result = lpg_hash(aTHX_ scope);
  lpg_store(aTHX_ scope, result, "value", lpo_write1(aTHX_ scope, owner, value->value, depth + 1, 1));
  return lpg_reference(aTHX_ scope, (SV *)result, "LeanBridge::OwnedCheckedRecords::Some");
  }
}

static void lpo_read1(pTHX_ lpg_scope *scope, SV *value, owned_checked_records_claim_t *out, size_t depth, int storage) {
  (void)out; SvGETMAGIC(value);
  lpg_enter(aTHX_ scope, SvROK(value) ? SvRV(value) : NULL, 1, depth, storage ? sizeof(*out) : 0, 0);
  static const char *const fields[] = {"holder", "quota"};
  SV **slots = lpg_fields(aTHX_ scope, value, "LeanBridge::OwnedCheckedRecords::Claim", fields, 2); (void)slots;
  lpo_read2(aTHX_ scope, slots[0], &out->holder, depth + 1, 0);
  lpo_read3(aTHX_ scope, slots[1], &out->quota, depth + 1, 0);
}
static SV *lpo_write1(pTHX_ lpg_scope *scope, lpo_owner *owner, owned_checked_records_claim_t const *value, size_t depth, int storage) {
  (void)owner;
  lpg_pointer(aTHX_ scope, value, 1, sizeof(*value), _Alignof(owned_checked_records_claim_t));
  lpg_enter(aTHX_ scope, value, 1, depth, storage ? sizeof(*value) : 0, 1);
  HV *result = lpg_hash(aTHX_ scope);
  lpg_store(aTHX_ scope, result, "holder", lpo_write2(aTHX_ scope, owner, &value->holder, depth + 1, 0));
  lpg_store(aTHX_ scope, result, "quota", lpo_write3(aTHX_ scope, owner, &value->quota, depth + 1, 0));
  return lpg_reference(aTHX_ scope, (SV *)result, "LeanBridge::OwnedCheckedRecords::Claim");
}

static void lpo_read2(pTHX_ lpg_scope *scope, SV *value, owned_checked_records_ticket_t *out, size_t depth, int storage) {
  (void)out; SvGETMAGIC(value);
  lpg_enter(aTHX_ scope, SvROK(value) ? SvRV(value) : NULL, 2, depth, storage ? sizeof(*out) : 0, 0);
  *out = (owned_checked_records_ticket_t)lpo_borrow(aTHX_ value, 2);
}
static SV *lpo_write2(pTHX_ lpg_scope *scope, lpo_owner *owner, owned_checked_records_ticket_t const *value, size_t depth, int storage) {
  (void)owner;
  lpg_pointer(aTHX_ scope, value, 1, sizeof(*value), _Alignof(owned_checked_records_ticket_t));
  lpg_enter(aTHX_ scope, value, 2, depth, storage ? sizeof(*value) : 0, 1);
  return lpo_wrap(aTHX_ scope, owner, (void *)*value, 2, "LeanBridge::OwnedCheckedRecords::Ticket");
}

static void lpo_read3(pTHX_ lpg_scope *scope, SV *value, mpz_srcptr *out, size_t depth, int storage) {
  (void)out; SvGETMAGIC(value);
  lpg_enter(aTHX_ scope, SvROK(value) ? SvRV(value) : NULL, 3, depth, storage ? sizeof(*out) : 0, 0);
  *out = lpo_read_integer(aTHX_ scope, value, 1);
}
static SV *lpo_write3(pTHX_ lpg_scope *scope, lpo_owner *owner, mpz_srcptr const *value, size_t depth, int storage) {
  (void)owner;
  lpg_pointer(aTHX_ scope, value, 1, sizeof(*value), _Alignof(mpz_srcptr));
  lpg_enter(aTHX_ scope, value, 3, depth, storage ? sizeof(*value) : 0, 1);
  return lpo_write_integer(aTHX_ scope, *value, 1);
}

static void lpo_read4(pTHX_ lpg_scope *scope, SV *value, owned_checked_records_scalar_string_t *out, size_t depth, int storage) {
  (void)out; SvGETMAGIC(value);
  lpg_enter(aTHX_ scope, SvROK(value) ? SvRV(value) : NULL, 4, depth, storage ? sizeof(*out) : 0, 0);
  if (SvROK(value)) croak("Expected a scalar value");
  if (!SvPOK(value)) croak("Expected a string scalar");
  STRLEN length; const U8 *bytes = (const U8 *)SvPV_nomg(value, length); size_t size = length;
  if (SvUTF8(value)) { if (length && !is_utf8_string_flags(bytes, length, UTF8_DISALLOW_SURROGATE | UTF8_DISALLOW_SUPER)) croak("String contains invalid Unicode"); }
  else { for (size_t i = 0; i < length; ++i) if (bytes[i] >= 128) { if (size == SIZE_MAX) croak("String size overflow"); ++size; } }
  lpg_charge(aTHX_ &scope->native_bytes, size, 1);
  U8 *data = lpg_allocate(aTHX_ scope, size, 1); out->data = (const void *)data; out->length = size;
  if (!SvUTF8(value)) { size_t j = 0; for (size_t i = 0; i < length; ++i) { U8 point = bytes[i]; if (point >= 128) { data[j++] = 0xc0 | (point >> 6); data[j++] = 0x80 | (point & 63); } else data[j++] = point; } }
  else if (length) memcpy(data, bytes, length);
}
static SV *lpo_write4(pTHX_ lpg_scope *scope, lpo_owner *owner, owned_checked_records_scalar_string_t const *value, size_t depth, int storage) {
  (void)owner;
  lpg_pointer(aTHX_ scope, value, 1, sizeof(*value), _Alignof(owned_checked_records_scalar_string_t));
  lpg_enter(aTHX_ scope, value, 4, depth, storage ? sizeof(*value) : 0, 1);
  lpg_charge(aTHX_ &scope->native_bytes, value->length, 1);
  lpg_pointer(aTHX_ scope, value->data, value->length, 1, 1);
  if (value->length && !is_utf8_string_flags((const U8 *)value->data, value->length, UTF8_DISALLOW_SURROGATE | UTF8_DISALLOW_SUPER)) lpg_invalid(aTHX_ scope, "UTF-8");
  return lpg_text(aTHX_ scope, (const char *)value->data, value->length, 1);
}


typedef struct {
  lpg_scope *scope;
  SV *error, *replacement;
} lpo_frame;
typedef struct {
  lpo_frame *frame;
  SV *code;
  CV *invoker;
} lpo_callback;
typedef struct {
  lpo_callback *callback;
  const void **arguments;
  void *output;
  owned_checked_records_result **owner;
  int returned;
} lpo_invocation;
static lpo_invocation *lpo_active;
static void lpo_frame_end(pTHX_ void *value) {
  lpo_frame *frame = value;
  SvREFCNT_dec(frame->error); SvREFCNT_dec(frame->replacement);
}
static lpo_frame *lpo_begin_frame(pTHX_ lpg_scope *scope) {
  lpo_frame *frame = lpg_allocate(aTHX_ scope, 1, sizeof(*frame));
  SSGROW(4); SAVEDESTRUCTOR_X(lpo_frame_end, frame);
  frame->scope = scope;
  save_scalar(PL_errgv);
  LB_PERL_GRAPH_CHECKPOINT(); frame->replacement = newSVpvs("");
  return frame;
}
static lpo_callback *lpo_new_callback(pTHX_ lpo_frame *frame, SV *code, const char *name) {
  SvGETMAGIC(code);
  if (!SvROK(code) || SvTYPE(SvRV(code)) != SVt_PVCV || SvOBJECT(SvRV(code)))
    croak("Expected an unblessed Perl code reference");
  CV *invoker = get_cv(name, 0);
  if (!invoker) croak("Missing generated owned callback converter");
  lpo_callback *callback = lpg_allocate(aTHX_ frame->scope, 1, sizeof(*callback));
  callback->frame = frame;
  callback->code = lpg_pin(aTHX_ SvRV(code));
  callback->invoker = (CV *)lpg_pin(aTHX_ (SV *)invoker);
  return callback;
}
static uint32_t lpo_invoke(lpo_callback *callback, owned_checked_records_session *session,
    const void **arguments, void *output, owned_checked_records_result **owner) {
  dTHX; dSP;
  if (!lpo_origin(aTHX) || lpo_state.closed || session != lpo_state.session) return 10;
  lpo_frame *frame = callback->frame;
  if (frame->error) return 10;
  lpo_invocation invocation = { callback, arguments, output, owner, 0 }, *previous = lpo_active;
  lpo_active = &invocation;
  PUSHMARK(SP); PUTBACK;
  int count = call_sv((SV *)callback->invoker, G_VOID | G_EVAL);
  SPAGAIN; SP -= count;
  if (SvROK(ERRSV) || SvTRUE(ERRSV)) {
    frame->error = GvSV(PL_errgv);
    GvSV(PL_errgv) = frame->replacement; frame->replacement = NULL;
  }
  PUTBACK; lpo_active = previous;
  return !frame->error && invocation.returned ? 0 : 10;
}
static void lpo_finish_frame(pTHX_ lpo_frame *frame, uint32_t status) {
  if (frame->error) croak_sv(frame->error);
  lpo_status(aTHX_ status);
}

MODULE = LeanBridge::OwnedCheckedRecords PACKAGE = LeanBridge::OwnedCheckedRecords
PROTOTYPES: DISABLE

BOOT:
    lpo_boot(aTHX);

void
claim_for(...)
  PPCODE:
    if (items != 1) croak("claim_for expects 1 arguments");
    ENTER;
    lpo_enter_call(aTHX);
    lpg_scope *scope = lpg_begin(aTHX_ NULL);
    lpo_frame *frame = lpo_begin_frame(aTHX_ scope);
    lpo_owner *owner = lpo_begin_owner(aTHX_ 0);
    SV *argument0 = lpg_pin(aTHX_ ST(0));
    owned_checked_records_ticket_t input0 = {0}; lpo_read2(aTHX_ scope, argument0, &input0, 0, 1);
    lpo_context(aTHX);
    if (lpo_state.closed) croak("Lean ownership session is closed");
    owned_checked_records_value_160ce821a84f6887bbfd_t returned = {0};
    uint32_t status = owned_checked_records_claim_for(lpo_state.session, input0, &returned, &owner->result);
    lpo_finish_frame(aTHX_ frame, status);
    SV *out = lpo_write0(aTHX_ scope, owner, &returned, 0, 1);
    lpo_publish(aTHX_ owner);
    LEAVE;
    SPAGAIN; SP = PL_stack_base + ax - 1; EXTEND(SP, 1); XPUSHs(out);

void
new_ticket(...)
  PPCODE:
    if (items != 2) croak("new_ticket expects 2 arguments");
    ENTER;
    lpo_enter_call(aTHX);
    lpg_scope *scope = lpg_begin(aTHX_ NULL);
    lpo_frame *frame = lpo_begin_frame(aTHX_ scope);
    lpo_owner *owner = lpo_begin_owner(aTHX_ 0);
    SV *argument0 = lpg_pin(aTHX_ ST(0));
    SV *argument1 = lpg_pin(aTHX_ ST(1));
    mpz_srcptr input0 = {0}; lpo_read3(aTHX_ scope, argument0, &input0, 0, 1);
    owned_checked_records_scalar_string_t input1 = {0}; lpo_read4(aTHX_ scope, argument1, &input1, 0, 1);
    lpo_context(aTHX);
    if (lpo_state.closed) croak("Lean ownership session is closed");
    owned_checked_records_ticket_t returned = {0};
    uint32_t status = owned_checked_records_new_ticket(lpo_state.session, input0, input1, &returned, &owner->result);
    lpo_finish_frame(aTHX_ frame, status);
    SV *out = lpo_write2(aTHX_ scope, owner, &returned, 0, 1);
    lpo_publish(aTHX_ owner);
    LEAVE;
    SPAGAIN; SP = PL_stack_base + ax - 1; EXTEND(SP, 1); XPUSHs(out);

void
serial(...)
  PPCODE:
    if (items != 1) croak("serial expects 1 arguments");
    ENTER;
    lpo_enter_call(aTHX);
    lpg_scope *scope = lpg_begin(aTHX_ NULL);
    lpo_frame *frame = lpo_begin_frame(aTHX_ scope);
    lpo_owner *owner = lpo_begin_owner(aTHX_ 0);
    SV *argument0 = lpg_pin(aTHX_ ST(0));
    owned_checked_records_ticket_t input0 = {0}; lpo_read2(aTHX_ scope, argument0, &input0, 0, 1);
    lpo_context(aTHX);
    if (lpo_state.closed) croak("Lean ownership session is closed");
    mpz_srcptr returned = {0};
    uint32_t status = owned_checked_records_serial(lpo_state.session, input0, &returned, &owner->result);
    lpo_finish_frame(aTHX_ frame, status);
    SV *out = lpo_write3(aTHX_ scope, owner, &returned, 0, 1);
    lpo_publish(aTHX_ owner);
    LEAVE;
    SPAGAIN; SP = PL_stack_base + ax - 1; EXTEND(SP, 1); XPUSHs(out);

MODULE = LeanBridge::OwnedCheckedRecords PACKAGE = LeanBridge::OwnedCheckedRecords::Ticket

void
close(value)
    SV *value
  PPCODE:
    lpo_wrapper_close(aTHX_ lpo_get(aTHX_ value, 2));

int
closed(value)
    SV *value
  CODE:
    RETVAL = lpo_closed(lpo_get(aTHX_ value, 2));
  OUTPUT:
    RETVAL

void
retain(...)
  PPCODE:
    if (items != 1) croak("retain expects 1 arguments");
    ENTER;
    lpo_enter_call(aTHX);
    lpg_scope *scope = lpg_begin(aTHX_ NULL);
    lpo_frame *frame = lpo_begin_frame(aTHX_ scope);
    lpo_owner *owner = lpo_begin_owner(aTHX_ 0);
    SV *argument0 = lpg_pin(aTHX_ ST(0));
    owned_checked_records_ticket_t input0 = {0}; lpo_read2(aTHX_ scope, argument0, &input0, 0, 1);
    lpo_context(aTHX);
    if (lpo_state.closed) croak("Lean ownership session is closed");
    owned_checked_records_ticket_t returned = {0};
    uint32_t status = owned_checked_records_ticket_t_retain(lpo_state.session, input0, &returned, &owner->result);
    lpo_finish_frame(aTHX_ frame, status);
    SV *out = lpo_write2(aTHX_ scope, owner, &returned, 0, 1);
    lpo_publish(aTHX_ owner);
    LEAVE;
    SPAGAIN; SP = PL_stack_base + ax - 1; EXTEND(SP, 1); XPUSHs(out);

MODULE = LeanBridge::OwnedCheckedRecords PACKAGE = LeanBridge::OwnedCheckedRecords::Runtime

void
shutdown()
  PPCODE:
    lpo_context(aTHX);
    lpo_shutdown(aTHX_ NULL);
