# LeanInheritedcheckedrecords

Install the prepared Composer archive and require vendor/autoload.php. Call the generated LeanInheritedcheckedrecords functions. The package includes the compiled Lean libraries and loads its runtime automatically. Consumers do not compile Lean or configure a package-specific Zend extension.

Requires PHP 8.2+ (below 9), NTS CLI, Linux x86-64, the packaged glibc floor, and FFI enabled. This copied-value profile does not cover FPM, Apache, cli-server, ZTS or PHP-Wasm. Compatible packages share one process runtime; post-fork calls and an already loaded foreign Lean runtime are rejected. No per-package or shared runtime files are written during use.

Unit is null. Fixed-width integers use range-checked PHP int except UInt64, which uses BigInteger. Nat and Int also use Brick\Math\BigInteger::of with decimal text. Composer installs brick/math 1.0.0 automatically. Lean Bridge accepts integer objects up to 16384 decimal digits. String requires UTF-8, including NUL. ByteArray uses Bytes::fromString. Floats require PHP float; Float32 rounds to binary32 and preserves NaN classification, infinities and signed zero. Arrays are consecutive-key lists; records are final readonly value classes.

Input parameters deliberately use mixed with precise PHPDoc: generated checks reject coercion even if the caller omits strict_types. Records and lists have independent copied results. Copied types must be pure and acyclic, at most 32 levels deep. Validation, FFI scratch/output conversion, and native input/output copies each have a 16 MiB limit; PHP lists account for at least 32 bytes per element. These budgets do not bound the Lean algorithm's working memory. Native output owners are released in finally.

- LeanInheritedcheckedrecords\aliased: lean:InheritedCheckedRecords.aliased
- LeanInheritedcheckedrecords\echo_: lean:InheritedCheckedRecords.echo
- LeanInheritedcheckedrecords\first: lean:InheritedCheckedRecords.first
- LeanInheritedcheckedrecords\nested: lean:InheritedCheckedRecords.nested
- LeanInheritedcheckedrecords\normalized: lean:InheritedCheckedRecords.normalized
- LeanInheritedcheckedrecords\pair: lean:InheritedCheckedRecords.pair
- LeanInheritedcheckedrecords\produce: lean:InheritedCheckedRecords.produce
- LeanInheritedcheckedrecords\produce_stamped: lean:InheritedCheckedRecords.produceStamped

## Copied Lean aliases

Pass ordinary PHP target values. The binding manifest and installed public source retain alias names, original targets and chains. PHPDoc keeps the PHP target type; lean-bridge annotations record the original Lean contract at parameters, results and record fields. Aliases create no PHP wrapper classes or runtime type aliases. Nat requires a nonnegative Brick\Math\BigInteger, Unit uses null and Char requires one Unicode scalar. Weak and strict callers receive the same target checks. Copied values keep independent storage, the existing copy budgets and the 32-level type-depth bound. Recursive copied types, compound callable payloads and identity-bearing alias targets remain unsupported.

| Lean alias | Contract target | PHP value |
| --- | --- | --- |
| `TicketAlias` | `Ticket` | `Ticket` |

## Value comparison

Generated records, variant cases, Some/Ok/Err and Bytes expose equals($other) and hashCode(). equals compares nested copied contents without numeric-string or other weak coercion and keeps class/constructor identity distinct. NaNs compare equal and signed zeros differ. hashCode returns a matching 64-character hexadecimal value hash; hashes are not a proof of equality or a versioned serialization format. PHP == and === keep their built-in meanings. Comparisons and hashing have a 32-level nesting bound and a 16 MiB traversal budget. Cycles exceed that depth bound; uninitialized values, foreign objects, resources and non-list arrays reject. Do not mutate referenced payloads while using their hash as a lookup key.

## Bounded integers

Lean Fin n parameters and results are Brick\Math\BigInteger values below n. The bundled native library compares each argument with its exact bound, including bounds wider than 64 bits, before any Lean code runs. A non-BigInteger argument throws TypeError and a negative value throws ValueError, as for Nat; a value at or above its bound throws LeanBridgeError with code 1 whose message names the Lean parameter and bound. Fin 0 has no values, so every call to a function taking one is rejected. Results are BigInteger values below their declared bound. Fin inside arrays, lists and options is checked element by element before Lean runs; an empty array or an absent option is valid even for Fin 0. Bounds below list every element as name[*] and a present option value as name?. Fin inside records, variants or callbacks is not supported in native PHP packages.

Lean Subtype parameters cross as their base value. The bundled native library runs the author's checked constructor, named below, before the export runs; a value the constructor rejects fails the call with the invalid-argument error naming the parameter and constructor, and the export receives the constructed value, which may differ from the input. Arrays, Lists, options, products and active result branches apply the same constructor checks to each Subtype leaf. Rejections identify the argument and nested element path. Subtype results are the base value. Reviewed APIs select the constructor and reconcile it with fresh Lean compilation. Copied plain records check each selected field; variants check only the active case. Repeated uses of one type retain their own constructor choices, and every Fin bound is checked before any constructor. Recursive, generic, owned and callback Subtype positions remain unsupported.

Checked records cross as generated record values containing only their payload fields. The bundled native library validates each input through the constructor selected for that exact occurrence before calling the export. Nested arrays, Lists, options, products, Except values, plain records and active variant cases retain their own checked-record constructors. Fin and Subtype payload fields run their checks before the outer record constructor. A rejection names the argument, nested path and failing constructor or bound. A normalizing constructor changes the copied value received by Lean without changing the caller's record. Results recursively project the payload fields and refined base values of records whose proofs Lean has already constructed. No proof object or input constructor is needed for a result-only export. Ordinary and reviewed APIs retain every per-occurrence constructor choice. Recursive, generic, owned and callback checked-record positions remain unsupported.

- LeanInheritedcheckedrecords\aliased: $arg0 checked by InheritedCheckedRecords.mkTicket; $arg0.toSpan checked by InheritedCheckedRecords.normalizeSpan; $arg0.word checked by InheritedCheckedRecords.normalizeWord
- LeanInheritedcheckedrecords\echo_: $arg0 checked by InheritedCheckedRecords.normalizeTicket; $arg0.toSpan checked by InheritedCheckedRecords.mkSpan; $arg0.word checked by InheritedCheckedRecords.normalizeWord; result projects proof-backed record payload fields; result.toSpan projects proof-backed record payload fields; result.word projects the Subtype base value
- LeanInheritedcheckedrecords\first: $arg0 checked by InheritedCheckedRecords.mkTicket; $arg0.toSpan checked by InheritedCheckedRecords.mkSpan; $arg0.word checked by InheritedCheckedRecords.mkWord
- LeanInheritedcheckedrecords\nested: $arg0 checked by InheritedCheckedRecords.mkStamped; $arg0.toTicket checked by InheritedCheckedRecords.mkTicket; $arg0.toTicket.toSpan checked by InheritedCheckedRecords.mkSpan; $arg0.toTicket.word checked by InheritedCheckedRecords.mkWord; $arg0.mark < 8
- LeanInheritedcheckedrecords\normalized: $arg0 checked by InheritedCheckedRecords.normalizeTicket; $arg0.toSpan checked by InheritedCheckedRecords.normalizeSpan; $arg0.word checked by InheritedCheckedRecords.normalizeWord
- LeanInheritedcheckedrecords\pair: $arg0 checked by InheritedCheckedRecords.mkTicket; $arg0.toSpan checked by InheritedCheckedRecords.mkSpan; $arg0.word checked by InheritedCheckedRecords.mkWord; $arg1 checked by InheritedCheckedRecords.normalizeTicket; $arg1.toSpan checked by InheritedCheckedRecords.normalizeSpan; $arg1.word checked by InheritedCheckedRecords.normalizeWord
- LeanInheritedcheckedrecords\produce: result projects proof-backed record payload fields; result.toSpan projects proof-backed record payload fields; result.word projects the Subtype base value
- LeanInheritedcheckedrecords\produce_stamped: result projects proof-backed record payload fields; result.toTicket projects proof-backed record payload fields; result.toTicket.toSpan projects proof-backed record payload fields; result.toTicket.word projects the Subtype base value; result.mark < 8
