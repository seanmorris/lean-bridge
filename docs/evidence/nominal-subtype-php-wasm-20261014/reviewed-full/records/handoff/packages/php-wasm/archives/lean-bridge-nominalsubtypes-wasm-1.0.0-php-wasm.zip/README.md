# nominalsubtypes for PHP-Wasm

Import this package's default descriptor and include it in PHP-Wasm's `sharedLibs` array. npm installs the matching Lean runtime dependency. The descriptor registers that runtime once per PHP host and mounts the generated PHP files.

```js
import { PhpNode } from 'php-wasm/PhpNode';
import api from 'lean-bridge-nominalsubtypes-wasm';

const php = new PhpNode({ version: '8.4', sharedLibs: [api] });
await php.run(`<?php require '${api.autoload}';`);
```

Call the generated functions in the `LeanNominalsubtypes` PHP namespace. The `compiled/src/Api.php` file contains their typed declarations. Other descriptors can share the same `sharedLibs` list. Conflicting runtime, component and PHP namespace identities are rejected before startup.

For a Composer application, install the companion `lean-bridge-nominalsubtypes/wasm:1.0.0` ZIP, mount your application's `vendor` directory into PHP-Wasm, and use the named `extensions` export in `sharedLibs` instead of the default descriptor. Require your normal `vendor/autoload.php`. This export registers the native libraries without preloading a second copy of the PHP files.

For first-call loading, import `{ lazy as api }` from this package and pass `dynamicLibs: [api]` instead. With Composer, use `api.extensions` in `dynamicLibs`. The host loads PHP declarations at startup but fetches the Lean runtime and this component only on its first valid API call. An unused component stays unloaded. Different components may choose different modes; registering the same component in both modes is rejected.

This package uses PHP-Wasm 0.1.0, PHP 8.4.1 and the default host variant in Node or Chromium. Register descriptors before constructing the host. Lazy loading requires `enable_dl=1`; await each host request before starting another. After an extension-loading failure, create a new PHP instance. No compiler, FFI extension or install script is required. The handoff receipt verifies package bytes; the descriptor checks compatibility identities, not downloaded byte integrity.

Compound exports use null or Some for Option, Ok or Err for Except, and exact two-element lists for Prod. Some(null) retains a present Unit or an outer Some containing None, according to the declared type. Generated branch classes are final readonly and expose one value property. Calls validate payload types without weak-mode coercion and return independent copies, including nested arrays and records. PHP object identity is not Lean value equality. On wasm32, UInt32, UInt64, Int64, Nat, Int and USize use Brick\Math\BigInteger; ISize uses a 32-bit PHP int. These mappings apply inside compound payloads. Type nesting stops at 32. Validation, Zend conversion and native copying each have a 16 MiB accounting limit, not a bound on Lean working memory. Compound callables, generic or indexed variants and recursive copied types remain unsupported.

Lean List inputs, results and record fields use consecutive-key PHP arrays with `list<T>` PHPDoc. Empty Lists, order, duplicates and nesting are preserved. List and Array retain distinct IR and native identities. Returned mutable values are independent copies. Weak and strict callers receive the same validation and copy-budget checks. List callback payloads remain unsupported.


## Copied Lean aliases

Pass ordinary PHP target values. The binding manifest and installed public source retain alias names, original targets and chains. PHPDoc keeps the PHP target type; lean-bridge annotations record the original Lean contract at parameters, results and record fields. Aliases create no PHP wrapper classes or runtime type aliases. Nat requires a nonnegative Brick\Math\BigInteger, Unit uses null and Char requires one Unicode scalar. Weak and strict callers receive the same target checks. Copied values keep independent storage, the existing copy budgets and the 32-level type-depth bound. Recursive copied types, compound callable payloads and identity-bearing alias targets remain unsupported.

| Lean alias | Contract target | PHP value |
| --- | --- | --- |
| `EnvelopeAlias` | `Envelope` | `Envelope` |

## Tagged variants

Concrete copied variants use abstract readonly family classes and final readonly constructor classes, such as SignalData extends Signal. Constructors take named or positional payload arguments with the original Lean field names. All payload checks apply in weak and strict PHP callers. Empty constructors and null Unit payloads stay distinct. Calls accept only exact generated constructor classes with their initialized fields; unknown family subclasses and uninitialized reflection-created objects reject. The native tag and union layout are private. Returned tags are checked before reading the active payload.

Accepted payloads include all nineteen primitives, copied arrays, Lists, records, options, results, products and other admitted variants. Returned payloads have independent copied storage. Readonly properties cannot be reassigned; arrays and objects still follow PHP's value and object semantics. PHP === compares object identity, while == compares properties under PHP rules. PHP does not check branch exhaustiveness. The 32-level schema limit and separate 16 MiB validation, PHP conversion and native-copy budgets remain in effect. Generic, indexed, proof-bearing, recursive, callable and identity-bearing payloads remain unsupported.

## Value comparison

Generated records, variant cases, Some/Ok/Err and Bytes expose equals($other) and hashCode(). equals compares nested copied contents without numeric-string or other weak coercion and keeps class/constructor identity distinct. NaNs compare equal and signed zeros differ. hashCode returns a matching 64-character hexadecimal value hash; hashes are not a proof of equality or a versioned serialization format. PHP == and === keep their built-in meanings. Comparisons and hashing have a 32-level nesting bound and a 16 MiB traversal budget. Cycles exceed that depth bound; uninitialized values, foreign objects, resources and non-list arrays reject. Do not mutate referenced payloads while using their hash as a lookup key.

## Checked refinements

Lean Fin n parameters and results are Brick\Math\BigInteger values below n. The PHP-Wasm side module compares each argument with its exact bound, including bounds wider than 64 bits, before any Lean code runs; a value at or above its bound throws LeanBridgeError with code 1 whose message names the Lean parameter and bound. Fin 0 has no values, so every call to a function taking one is rejected. Results are BigInteger values below their declared bound. Fin inside arrays, lists, options, products, Except values, records and variants is checked before Lean runs: every array or list element, a present option value, both product components, only the active Except branch, every record field and only the fields of the active variant case. An empty array, an absent option or an inactive branch or case is valid even for Fin 0. Bounds below list every element as name[*], a present option value as name?, product components as name.0 and name.1, the active branch as name.ok or name.error, a record field as name.field and a field of the active variant case as name.Case.field. Fin inside callbacks or generic record instantiations is not supported in PHP-Wasm packages.

Lean Subtype parameters cross as their base value. The PHP-Wasm side module runs the author's checked constructor, named below, before the export runs; a value the constructor rejects fails the call with the invalid-argument error naming the parameter and constructor, and the export receives the constructed value, which may differ from the input. Arrays, Lists, options, products and active result branches apply the same constructor checks to each Subtype leaf. Rejections identify the argument and nested element path. Subtype results are the base value. Reviewed APIs select the constructor and reconcile it with fresh Lean compilation. Copied plain records check each selected field; variants check only the active case. Repeated uses of one type retain their own constructor choices, and every Fin bound is checked before any constructor. Recursive, generic, owned and callback Subtype positions remain unsupported.

- LeanNominalsubtypes\aliases: $value0[*]?.payload checked by NominalSubtypes.plusOne; $value0[*]?.digit < 3; $value1[*]?.payload checked by NominalSubtypes.plusTwo; $value1[*]?.digit < 3
- LeanNominalsubtypes\array_values: result[*] projects the Subtype base value
- LeanNominalsubtypes\branch: result.ok projects the Subtype base value; result.error projects the Subtype base value
- LeanNominalsubtypes\combine: $value0.payload checked by NominalSubtypes.plusOne; $value0.digit < 3; $value1.payload checked by NominalSubtypes.plusTwo; $value1.digit < 3
- LeanNominalsubtypes\echo_envelope: $value0.payload checked by NominalSubtypes.plusOne; $value0.digit < 3; result.payload projects the Subtype base value; result.digit < 3
- LeanNominalsubtypes\echo_event: $value0.box.value.payload checked by NominalSubtypes.plusOne; $value0.box.value.digit < 3; $value0.choices.values[*]?.ok checked by NominalSubtypes.plusOne; $value0.choices.values[*]?.error checked by NominalSubtypes.plusTwo; result.box.value.payload projects the Subtype base value; result.box.value.digit < 3; result.choices.values[*]?.ok projects the Subtype base value; result.choices.values[*]?.error projects the Subtype base value
- LeanNominalsubtypes\echo_groups: $value0[*]?.payload checked by NominalSubtypes.plusOne; $value0[*]?.digit < 3; result[*]?.payload projects the Subtype base value; result[*]?.digit < 3
- LeanNominalsubtypes\echo_pair: $value0.left[*]?.payload checked by NominalSubtypes.plusOne; $value0.left[*]?.digit < 3; $value0.right[*]?.payload checked by NominalSubtypes.plusTwo; $value0.right[*]?.digit < 3; result.left[*]?.payload projects the Subtype base value; result.left[*]?.digit < 3; result.right[*]?.payload projects the Subtype base value; result.right[*]?.digit < 3
- LeanNominalsubtypes\event_choices: result.box.value.payload projects the Subtype base value; result.box.value.digit < 3; result.choices.values[*]?.ok projects the Subtype base value; result.choices.values[*]?.error projects the Subtype base value
- LeanNominalsubtypes\event_empty: result.box.value.payload projects the Subtype base value; result.box.value.digit < 3; result.choices.values[*]?.ok projects the Subtype base value; result.choices.values[*]?.error projects the Subtype base value
- LeanNominalsubtypes\event_first: $value0.box.value.payload checked by NominalSubtypes.plusOne; $value0.box.value.digit < 3; $value0.choices.values[*]?.ok checked by NominalSubtypes.plusOne; $value0.choices.values[*]?.error checked by NominalSubtypes.plusTwo
- LeanNominalsubtypes\event_second: $value0.box.value.payload checked by NominalSubtypes.plusTwo; $value0.box.value.digit < 3; $value0.choices.values[*]?.ok checked by NominalSubtypes.plusTwo; $value0.choices.values[*]?.error checked by NominalSubtypes.plusOne
- LeanNominalsubtypes\event_value: result.box.value.payload projects the Subtype base value; result.box.value.digit < 3; result.choices.values[*]?.ok projects the Subtype base value; result.choices.values[*]?.error projects the Subtype base value
- LeanNominalsubtypes\first: $value0.payload checked by NominalSubtypes.plusOne; $value0.digit < 3
- LeanNominalsubtypes\group_values: result[*]?.payload projects the Subtype base value; result[*]?.digit < 3
- LeanNominalsubtypes\inspect_alias_pair: $value0.left[*]?.payload checked by NominalSubtypes.plusOne; $value0.left[*]?.digit < 3; $value0.right[*]?.payload checked by NominalSubtypes.plusTwo; $value0.right[*]?.digit < 3
- LeanNominalsubtypes\list_values: result[*] projects the Subtype base value
- LeanNominalsubtypes\nested: $value0.left.payload checked by NominalSubtypes.plusOne; $value0.left.digit < 3; $value0.right.payload checked by NominalSubtypes.plusTwo; $value0.right.digit < 3
- LeanNominalsubtypes\no_items: result[*] projects the Subtype base value
- LeanNominalsubtypes\optional: result? projects the Subtype base value
- LeanNominalsubtypes\pair_values: result.left[*]?.payload projects the Subtype base value; result.left[*]?.digit < 3; result.right[*]?.payload projects the Subtype base value; result.right[*]?.digit < 3
- LeanNominalsubtypes\plain_fin: $value0 < 3
- LeanNominalsubtypes\produce_envelope: result.payload projects the Subtype base value; result.digit < 3
- LeanNominalsubtypes\product: result.0 projects the Subtype base value; result.1 projects the Subtype base value
- LeanNominalsubtypes\scalar: result projects the Subtype base value
- LeanNominalsubtypes\second: $value0.payload checked by NominalSubtypes.plusTwo; $value0.digit < 3
