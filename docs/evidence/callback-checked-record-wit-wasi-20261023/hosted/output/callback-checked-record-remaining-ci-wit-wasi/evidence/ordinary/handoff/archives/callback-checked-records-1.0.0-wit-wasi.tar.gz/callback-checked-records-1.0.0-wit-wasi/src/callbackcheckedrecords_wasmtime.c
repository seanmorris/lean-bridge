#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif
#include <dlfcn.h>
#include <link.h>

#include <errno.h>
#include <fcntl.h>
#include <stdint.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

typedef struct {
  uint32_t words[8];
  uint64_t bytes;
  size_t used;
  unsigned char block[64];
} lb_receipt_hash;

static uint32_t lb_receipt_rotr(uint32_t x, unsigned n) {
  return (x >> n) | (x << (32u - n));
}
static void lb_receipt_block(lb_receipt_hash *hash, const unsigned char *block) {
  static const uint32_t constants[64] = {
    0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
    0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
    0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
    0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
    0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
    0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
    0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
    0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2
  };
  uint32_t w[64];
  for (size_t i = 0; i < 16; ++i)
    w[i] = ((uint32_t)block[4*i] << 24) | ((uint32_t)block[4*i+1] << 16)
      | ((uint32_t)block[4*i+2] << 8) | block[4*i+3];
  for (size_t i = 16; i < 64; ++i) {
    uint32_t x = w[i-15], y = w[i-2];
    w[i] = w[i-16] + (lb_receipt_rotr(x,7) ^ lb_receipt_rotr(x,18) ^ (x >> 3))
      + w[i-7] + (lb_receipt_rotr(y,17) ^ lb_receipt_rotr(y,19) ^ (y >> 10));
  }
  uint32_t a=hash->words[0], b=hash->words[1], c=hash->words[2], d=hash->words[3];
  uint32_t e=hash->words[4], f=hash->words[5], g=hash->words[6], h=hash->words[7];
  for (size_t i = 0; i < 64; ++i) {
    uint32_t t1 = h + (lb_receipt_rotr(e,6) ^ lb_receipt_rotr(e,11) ^ lb_receipt_rotr(e,25))
      + ((e & f) ^ (~e & g)) + constants[i] + w[i];
    uint32_t t2 = (lb_receipt_rotr(a,2) ^ lb_receipt_rotr(a,13) ^ lb_receipt_rotr(a,22))
      + ((a & b) ^ (a & c) ^ (b & c));
    h=g; g=f; f=e; e=d+t1; d=c; c=b; b=a; a=t1+t2;
  }
  hash->words[0]+=a; hash->words[1]+=b; hash->words[2]+=c; hash->words[3]+=d;
  hash->words[4]+=e; hash->words[5]+=f; hash->words[6]+=g; hash->words[7]+=h;
}
static void lb_receipt_update(lb_receipt_hash *hash, const unsigned char *bytes, size_t count) {
  hash->bytes += count;
  while (count) {
    size_t take = 64 - hash->used;
    if (take > count) take = count;
    memcpy(hash->block + hash->used, bytes, take);
    hash->used += take; bytes += take; count -= take;
    if (hash->used == 64) { lb_receipt_block(hash, hash->block); hash->used = 0; }
  }
}
static void lb_receipt_finish(lb_receipt_hash *hash, char out[65]) {
  static const char hex[] = "0123456789abcdef";
  uint64_t bits = hash->bytes * UINT64_C(8);
  unsigned char padding[128] = {0x80};
  size_t count = hash->used < 56 ? 56 - hash->used : 120 - hash->used;
  for (size_t i = 0; i < 8; ++i) padding[count+i] = (unsigned char)(bits >> (56-8*i));
  lb_receipt_update(hash, padding, count + 8);
  for (size_t i = 0; i < 32; ++i) {
    unsigned byte = (hash->words[i/4] >> (24-8*(i%4))) & 255u;
    out[2*i] = hex[byte >> 4]; out[2*i+1] = hex[byte & 15];
  }
  out[64] = 0;
}
static int lb_receipt_file_matches(const char *path, uint64_t bytes, const char *expected) {
  int fd = open(path, O_RDONLY | O_CLOEXEC | O_NOFOLLOW | O_NONBLOCK);
  if (fd < 0) return 0;
  struct stat before, after;
  int valid = !fstat(fd, &before) && S_ISREG(before.st_mode) && before.st_size >= 0
    && (uint64_t)before.st_size == bytes && bytes <= UINT64_MAX/8;
  lb_receipt_hash hash = {.words = {0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,
    0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19}};
  unsigned char buffer[16384];
  while (valid) {
    ssize_t count = read(fd, buffer, sizeof(buffer));
    if (count < 0 && errno == EINTR) continue;
    if (count < 0) { valid = 0; break; }
    if (!count) break;
    if ((uint64_t)count > bytes - hash.bytes) { valid = 0; break; }
    lb_receipt_update(&hash, buffer, (size_t)count);
  }
  valid = valid && hash.bytes == bytes && !fstat(fd, &after)
    && before.st_size == after.st_size
    && before.st_mtim.tv_sec == after.st_mtim.tv_sec && before.st_mtim.tv_nsec == after.st_mtim.tv_nsec
    && before.st_ctim.tv_sec == after.st_ctim.tv_sec && before.st_ctim.tv_nsec == after.st_ctim.tv_nsec;
  if (close(fd)) valid = 0;
  char actual[65]; lb_receipt_finish(&hash, actual);
  return valid && !strcmp(actual, expected);
}


static pid_t lb_package_pid;
/* Private loader handshake, not a consumer API. Keep each host's origin local
 * even when another host exports the same handshake symbol. */
__attribute__((visibility("default"))) pid_t __lean_bridge_wit_host_process_origin_v1(void) {
  return lb_package_pid;
}
static const char *lb_package_problem = "WIT package dependencies have not been verified";
static const struct { const char *name; uint64_t bytes; const char *sha256; } lb_package_libraries[] = {
  {"libcallbackcheckedrecords.so", UINT64_C(66080), "5c25c214ce14bb0cc16ec491a987daaf34fea4405464f8f43a10e9597fd4bc92"},
  {"libcomponent_82670d9206f057180ea5.so", UINT64_C(136000), "735b1ed491423e37d316f7714b805425cd4c51246cc99deaf6b8ecdb3ccf5730"},
  {"liblean_bridge_native.so", UINT64_C(21632), "459fcd2098d4b646ab6ae0f4cdccd1f222908cb162562bfc3940a533cd4e4e21"},
  {"libleanshared.so", UINT64_C(158401256), "d7768b88d8162736da4305777cd6f147676038fd885bd8a265c958b0ecea00b4"},
  {"libwasmtime.so", UINT64_C(22277728), "566e57cfeabafd6d44fab1b5e6660b4569a71aae4cff2e4d89563a424ee799f3"}
};
typedef struct { unsigned seen[5]; const char *failure; } lb_package_scan;
static int lb_package_process(struct dl_phdr_info *info, size_t size, void *data) {
  (void)size;
  lb_package_scan *scan = data;
  const char *path = info->dlpi_name;
  if (!path || !*path) return 0;
  const char *slash = strrchr(path, '/'), *name = slash ? slash+1 : path;
  const char suffix[] = "_wasmtime.so";
  size_t length = strlen(name);
  if (length <= 3 + sizeof(suffix)-1 || strncmp(name, "lib", 3)
      || strcmp(name+length-(sizeof(suffix)-1), suffix)) return 0;
  void *loaded = dlopen(path, RTLD_NOW | RTLD_NOLOAD);
  if (!loaded) { scan->failure = "Cannot inspect loaded WIT host"; return 1; }
  void *address = dlsym(loaded, "__lean_bridge_wit_host_process_origin_v1");
  Dl_info owner;
  /* dlsym also searches dependencies. Only use this library's own marker. */
  if (address && dladdr(address, &owner) && owner.dli_fbase == (void *)info->dlpi_addr) {
    pid_t (*origin)(void);
    _Static_assert(sizeof(origin) == sizeof(address), "POSIX function pointer");
    memcpy(&origin, &address, sizeof(origin));
    pid_t process = origin();
    /* A host whose constructor has not run yet has no Wasmtime state. */
    if (process && process != getpid())
      scan->failure = "WIT hosts cannot be used after fork; exec a fresh process";
  }
  dlclose(loaded);
  return scan->failure != NULL;
}
static int lb_package_library(struct dl_phdr_info *info, size_t size, void *data) {
  (void)size;
  lb_package_scan *scan = data;
  const char *path = info->dlpi_name;
  if (!path || !*path) return 0;
  const char *slash = strrchr(path, '/'), *name = slash ? slash+1 : path;
  for (size_t i = 0; i < sizeof(lb_package_libraries)/sizeof(lb_package_libraries[0]); ++i) {
    if (strcmp(name, lb_package_libraries[i].name)) continue;
    if (!lb_receipt_file_matches(path, lb_package_libraries[i].bytes, lb_package_libraries[i].sha256)) {
      scan->failure = "WIT package dependency conflict: loaded library differs from its receipt";
      return 1;
    }
    /* Resolve lazy dependency relocations before another host is loaded. */
    void *loaded = dlopen(path, RTLD_NOW | RTLD_NOLOAD);
    if (!loaded) { scan->failure = "Cannot bind verified WIT dependency"; return 1; }
    dlclose(loaded);
    scan->seen[i] = 1;
  }
  return 0;
}
__attribute__((constructor)) static void lb_package_verify(void) {
  lb_package_pid = getpid();
  lb_package_scan scan = {0};
  dl_iterate_phdr(lb_package_process, &scan);
  if (!scan.failure) dl_iterate_phdr(lb_package_library, &scan);
  for (size_t i = 0; i < sizeof(scan.seen)/sizeof(scan.seen[0]); ++i)
    if (!scan.seen[i] && !scan.failure) scan.failure = "WIT package dependency is missing from the loaded libraries";
  lb_package_problem = scan.failure;
}
static const char *lb_package_failure(void) {
  if (getpid() != lb_package_pid) return "WIT hosts cannot be used after fork; exec a fresh process";
  return lb_package_problem;
}
#include "callbackcheckedrecords_wasmtime.h"
#include "callbackcheckedrecords-graph.h"
#include "lean_bridge_native_runtime.h"
#include <pthread.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

_Static_assert(sizeof(bool) == 1, "WIT bool validation requires a one-byte representation");
typedef struct lb_allocation { struct lb_allocation *next; } lb_allocation;
typedef struct { size_t remaining; lb_allocation *allocations; unsigned failure; } lb_scope;
/* Native callers still own valid backing storage; this checks shape, alignment
 * and address arithmetic, not the allocation extent of an arbitrary pointer. */
static inline bool lb_buffer(const void *data, size_t count, size_t width, size_t alignment) {
  if (!count) return true;
  if (!data || !width || !alignment || (uintptr_t)data % alignment || count > SIZE_MAX / width) return false;
  return count * width <= UINTPTR_MAX - (uintptr_t)data;
}
static inline bool lb_boolean(const void *data, bool *out) {
  uint8_t raw; memcpy(&raw, data, sizeof(raw));
  if (raw > 1) return false;
  *out = raw != 0; return true;
}
static inline bool lb_charge(lb_scope *scope, size_t count, size_t width) {
  if (count && width > scope->remaining / count) { scope->failure = 2; return false; }
  scope->remaining -= count * width; return true;
}
static inline void *lb_alloc(lb_scope *scope, size_t count, size_t width) {
  if (!count) return NULL;
  if (width > (SIZE_MAX - sizeof(lb_allocation)) / count) { scope->failure = 2; return NULL; }
  lb_allocation *allocation = calloc(1, sizeof(*allocation) + count * width);
  if (!allocation) { scope->failure = 3; return NULL; }
  allocation->next = scope->allocations; scope->allocations = allocation;
  return allocation + 1;
}
static inline void lb_scope_close(lb_scope *scope) {
  while (scope->allocations) { lb_allocation *next = scope->allocations->next; free(scope->allocations); scope->allocations = next; }
}
static inline bool lb_name(const wasm_name_t *name, const char *expected) {
  size_t length = strlen(expected);
  return name->size == length && lb_buffer(name->data, length, 1, 1) && (!length || memcmp(name->data, expected, length) == 0);
}
static inline bool lb_utf8(const char *text, size_t length) {
  const uint8_t *p = (const uint8_t *)text;
  if (!lb_buffer(p, length, 1, 1)) return false;
  for (size_t i = 0; i < length;) {
    uint32_t c = p[i++]; size_t extra = 0; uint32_t minimum = 0;
    if (c < 0x80) continue;
    if (c >= 0xc2 && c <= 0xdf) { extra = 1; minimum = 0x80; c &= 0x1f; }
    else if (c >= 0xe0 && c <= 0xef) { extra = 2; minimum = 0x800; c &= 0x0f; }
    else if (c >= 0xf0 && c <= 0xf4) { extra = 3; minimum = 0x10000; c &= 7; }
    else return false;
    if (extra > length - i) return false;
    while (extra--) { uint8_t b = p[i++]; if ((b & 0xc0) != 0x80) return false; c = (c << 6) | (b & 0x3f); }
    if (c < minimum || c > 0x10ffff || (c >= 0xd800 && c <= 0xdfff)) return false;
  }
  return true;
}
static inline bool lb_limbs_in(const wasmtime_component_val_t *value, lb_scope *scope, uint32_t **out, size_t *length) {
  if (value->kind != WASMTIME_COMPONENT_LIST) return false;
  size_t count = value->of.list.size;
  if (!lb_buffer(value->of.list.data, count, sizeof(wasmtime_component_val_t), _Alignof(wasmtime_component_val_t)) || !lb_charge(scope, count, sizeof(wasmtime_component_val_t) + sizeof(uint32_t))) return false;
  for (size_t i = 0; i < count; ++i) if (value->of.list.data[i].kind != WASMTIME_COMPONENT_U32) return false;
  if (count && value->of.list.data[count - 1].of.u32 == 0) return false;
  if (out) {
    *out = lb_alloc(scope, count, sizeof(uint32_t)); if (count && !*out) return false;
    for (size_t i = 0; i < count; ++i) (*out)[i] = value->of.list.data[i].of.u32;
    *length = count;
  }
  return true;
}
static inline bool lb_limbs_out(const uint32_t *data, size_t length, lb_scope *scope, wasmtime_component_val_t *out) {
  if (!lb_buffer(data, length, sizeof(uint32_t), _Alignof(uint32_t)) || !lb_charge(scope, length, sizeof(wasmtime_component_val_t))) return false;
  if (length && (!data || !data[length - 1])) return false;
  out->kind = WASMTIME_COMPONENT_LIST;
  wasmtime_component_vallist_new_uninit(&out->of.list, length);
  for (size_t i = 0; i < length; ++i) out->of.list.data[i] = (wasmtime_component_val_t){.kind = WASMTIME_COMPONENT_U32, .of.u32 = data[i]};
  return true;
}
static inline bool lb_in_5(const wasmtime_component_val_t *value, lb_scope *scope, callbackcheckedrecords_scalar_nat_t *out) {
  (void)out;
  if (!lb_buffer(value, 1, sizeof(*value), _Alignof(wasmtime_component_val_t)) || (out && !lb_buffer(out, 1, sizeof(*out), _Alignof(callbackcheckedrecords_scalar_nat_t))) || !lb_charge(scope, 1, sizeof(wasmtime_component_val_t))) return false;
  uint32_t *limbs = NULL; size_t length = 0;
  if (!lb_limbs_in(value, scope, out ? &limbs : NULL, &length)) return false;
  if (out) *out = (callbackcheckedrecords_scalar_nat_t){.data = limbs, .length = length};
  return true;
}
static inline bool lb_out_5(const callbackcheckedrecords_scalar_nat_t *value, lb_scope *scope, wasmtime_component_val_t *out) {
  (void)value;
  if (!lb_buffer(value, 1, sizeof(*value), _Alignof(callbackcheckedrecords_scalar_nat_t)) || !lb_buffer(out, 1, sizeof(*out), _Alignof(wasmtime_component_val_t)) || !lb_charge(scope, 1, sizeof(wasmtime_component_val_t))) return false;
  return lb_limbs_out(value->data, value->length, scope, out);
  return true;
}

static inline bool lb_in_7(const wasmtime_component_val_t *value, lb_scope *scope, uint8_t *out) {
  (void)out;
  if (!lb_buffer(value, 1, sizeof(*value), _Alignof(wasmtime_component_val_t)) || (out && !lb_buffer(out, 1, sizeof(*out), _Alignof(uint8_t))) || !lb_charge(scope, 1, sizeof(wasmtime_component_val_t))) return false;
  if (value->kind != WASMTIME_COMPONENT_ENUM || !lb_name(&value->of.enumeration, "unit")) return false;
  if (out) *out = 0;
  return true;
}
static inline bool lb_out_7(const uint8_t *value, lb_scope *scope, wasmtime_component_val_t *out) {
  (void)value;
  if (!lb_buffer(value, 1, sizeof(*value), _Alignof(uint8_t)) || !lb_buffer(out, 1, sizeof(*out), _Alignof(wasmtime_component_val_t)) || !lb_charge(scope, 1, sizeof(wasmtime_component_val_t))) return false;
  if (*value) return false;
  out->kind = WASMTIME_COMPONENT_ENUM; wasm_name_new(&out->of.enumeration, 4, "unit");
  return true;
}
static inline bool lb_in_6(const wasmtime_component_val_t *value, lb_scope *scope, callbackcheckedrecords_scalar_string_t *out) {
  if (!lb_buffer(value, 1, sizeof(*value), _Alignof(wasmtime_component_val_t)) || value->kind != WASMTIME_COMPONENT_STRING || !lb_charge(scope, 1, sizeof(*value)) || !lb_charge(scope, value->of.string.size, 2) || !lb_utf8(value->of.string.data, value->of.string.size)) return false;
  if (out) {
    char *text = lb_alloc(scope, value->of.string.size, 1);
    if (value->of.string.size && !text) return false;
    if (value->of.string.size) memcpy(text, value->of.string.data, value->of.string.size);
    *out = (callbackcheckedrecords_scalar_string_t){.data = text, .length = value->of.string.size};
  }
  return true;
}
static inline bool lb_out_6(const callbackcheckedrecords_scalar_string_t *value, lb_scope *scope, wasmtime_component_val_t *out) {
  if (!lb_buffer(value, 1, sizeof(*value), _Alignof(callbackcheckedrecords_scalar_string_t)) || !lb_charge(scope, 1, sizeof(*out)) || !lb_charge(scope, value->length, 1) || !lb_utf8(value->data, value->length)) return false;
  out->kind = WASMTIME_COMPONENT_STRING; wasm_name_new(&out->of.string, value->length, value->data); return true;
}

#define LB_GRAPH_TABLES 5
#define LB_GRAPH_DEPTH 128
#define LB_GRAPH_NODES 262144
#define LB_GRAPH_BYTES 16777216
typedef struct { lb_scope memory; size_t nodes; } lb_graph_scope;
typedef struct { size_t type; uint32_t index; const void *address; } lb_graph_path;
typedef struct {
  lb_graph_scope *scope;
  const wasmtime_component_vallist_t *tables[LB_GRAPH_TABLES];
  size_t offsets[LB_GRAPH_TABLES], total, visited, active;
  uint8_t *seen;
  lb_graph_path path[LB_GRAPH_DEPTH + 1];
} lb_graph_input;
typedef struct lb_graph_row {
  struct lb_graph_row *next;
  wasmtime_component_val_t value;
} lb_graph_row;
typedef struct { lb_graph_row *head, *tail; uint32_t count; } lb_graph_table;
typedef struct {
  lb_graph_scope *scope;
  lb_graph_table tables[LB_GRAPH_TABLES];
  size_t active;
  lb_graph_path path[LB_GRAPH_DEPTH + 1];
} lb_graph_output;
static inline bool lb_graph_visit(lb_graph_scope *scope, unsigned depth, size_t bytes) {
  if (depth > LB_GRAPH_DEPTH || !scope->nodes) { scope->memory.failure = 2; return false; }
  if (!lb_charge(&scope->memory, 1, bytes)) return false;
  --scope->nodes; return true;
}
static inline bool lb_graph_count(lb_graph_scope *scope, size_t count) {
  if (count > scope->nodes) { scope->memory.failure = 2; return false; }
  return true;
}
static inline void lb_graph_release(void *owner) {
  lb_scope memory = {.allocations = owner}; lb_scope_close(&memory);
}
static inline bool lb_graph_record_in(const wasmtime_component_val_t *value, size_t count, lb_graph_scope *scope) {
  return lb_buffer(value, 1, sizeof(*value), _Alignof(wasmtime_component_val_t)) && value->kind == WASMTIME_COMPONENT_RECORD && value->of.record.size == count
    && lb_buffer(value->of.record.data, count, sizeof(*value->of.record.data), _Alignof(wasmtime_component_valrecord_entry_t))
    && lb_charge(&scope->memory, count, sizeof(*value->of.record.data));
}
static inline bool lb_graph_index(const wasmtime_component_val_t *value, lb_graph_scope *scope, uint32_t *out) {
  if (!lb_graph_record_in(value, 1, scope) || !lb_name(&value->of.record.data[0].name, "index") || value->of.record.data[0].val.kind != WASMTIME_COMPONENT_U32) return false;
  *out = value->of.record.data[0].val.of.u32; return true;
}
static inline lb_graph_input *lb_graph_open(const wasmtime_component_val_t *value, lb_graph_scope *scope) {
  if (!lb_graph_record_in(value, 2, scope) || !lb_name(&value->of.record.data[0].name, "root") || !lb_name(&value->of.record.data[1].name, "nodes")) return NULL;
  const wasmtime_component_val_t *arena = &value->of.record.data[1].val;
  if (!lb_graph_record_in(arena, 5, scope) || !lb_charge(&scope->memory, 1, sizeof(lb_graph_input))) return NULL;
  lb_graph_input *context = lb_alloc(&scope->memory, 1, sizeof(*context));
  if (!context) return NULL;
  context->scope = scope;
  {
    const wasmtime_component_valrecord_entry_t *field = &arena->of.record.data[0];
    if (!lb_name(&field->name, "nodes0") || field->val.kind != WASMTIME_COMPONENT_LIST) return NULL;
    const wasmtime_component_vallist_t *table = &field->val.of.list;
    if (table->size > LB_GRAPH_NODES - context->total) { scope->memory.failure = 2; return NULL; }
    if (!lb_buffer(table->data, table->size, sizeof(*table->data), _Alignof(wasmtime_component_val_t)) || !lb_charge(&scope->memory, table->size, sizeof(*table->data) + 1)) return NULL;
    context->tables[0] = table; context->offsets[0] = context->total; context->total += table->size;
  }
  {
    const wasmtime_component_valrecord_entry_t *field = &arena->of.record.data[1];
    if (!lb_name(&field->name, "nodes1") || field->val.kind != WASMTIME_COMPONENT_LIST) return NULL;
    const wasmtime_component_vallist_t *table = &field->val.of.list;
    if (table->size > LB_GRAPH_NODES - context->total) { scope->memory.failure = 2; return NULL; }
    if (!lb_buffer(table->data, table->size, sizeof(*table->data), _Alignof(wasmtime_component_val_t)) || !lb_charge(&scope->memory, table->size, sizeof(*table->data) + 1)) return NULL;
    context->tables[1] = table; context->offsets[1] = context->total; context->total += table->size;
  }
  {
    const wasmtime_component_valrecord_entry_t *field = &arena->of.record.data[2];
    if (!lb_name(&field->name, "nodes2") || field->val.kind != WASMTIME_COMPONENT_LIST) return NULL;
    const wasmtime_component_vallist_t *table = &field->val.of.list;
    if (table->size > LB_GRAPH_NODES - context->total) { scope->memory.failure = 2; return NULL; }
    if (!lb_buffer(table->data, table->size, sizeof(*table->data), _Alignof(wasmtime_component_val_t)) || !lb_charge(&scope->memory, table->size, sizeof(*table->data) + 1)) return NULL;
    context->tables[2] = table; context->offsets[2] = context->total; context->total += table->size;
  }
  {
    const wasmtime_component_valrecord_entry_t *field = &arena->of.record.data[3];
    if (!lb_name(&field->name, "nodes3") || field->val.kind != WASMTIME_COMPONENT_LIST) return NULL;
    const wasmtime_component_vallist_t *table = &field->val.of.list;
    if (table->size > LB_GRAPH_NODES - context->total) { scope->memory.failure = 2; return NULL; }
    if (!lb_buffer(table->data, table->size, sizeof(*table->data), _Alignof(wasmtime_component_val_t)) || !lb_charge(&scope->memory, table->size, sizeof(*table->data) + 1)) return NULL;
    context->tables[3] = table; context->offsets[3] = context->total; context->total += table->size;
  }
  {
    const wasmtime_component_valrecord_entry_t *field = &arena->of.record.data[4];
    if (!lb_name(&field->name, "nodes4") || field->val.kind != WASMTIME_COMPONENT_LIST) return NULL;
    const wasmtime_component_vallist_t *table = &field->val.of.list;
    if (table->size > LB_GRAPH_NODES - context->total) { scope->memory.failure = 2; return NULL; }
    if (!lb_buffer(table->data, table->size, sizeof(*table->data), _Alignof(wasmtime_component_val_t)) || !lb_charge(&scope->memory, table->size, sizeof(*table->data) + 1)) return NULL;
    context->tables[4] = table; context->offsets[4] = context->total; context->total += table->size;
  }
  context->seen = lb_alloc(&scope->memory, context->total, 1);
  if (context->total && !context->seen) return NULL;
  return context;
}
static inline const wasmtime_component_val_t *lb_graph_dereference(lb_graph_input *context, size_t type, const wasmtime_component_val_t *reference) {
  uint32_t index;
  if (context->active > LB_GRAPH_DEPTH) { context->scope->memory.failure = 2; return NULL; }
  if (!lb_graph_index(reference, context->scope, &index) || index >= context->tables[type]->size) return NULL;
  for (size_t i = 0; i < context->active; ++i) if (context->path[i].type == type && context->path[i].index == index) return NULL;
  context->path[context->active++] = (lb_graph_path){.type = type, .index = index};
  size_t position = context->offsets[type] + index;
  if (!context->seen[position]) { context->seen[position] = 1; ++context->visited; }
  return &context->tables[type]->data[index];
}
static inline bool lb_graph_record_out(wasmtime_component_val_t *out, size_t count, lb_graph_scope *scope) {
  if (!lb_charge(&scope->memory, count, sizeof(wasmtime_component_valrecord_entry_t))) return false;
  out->kind = WASMTIME_COMPONENT_RECORD;
  wasmtime_component_valrecord_new_uninit(&out->of.record, count);
  if (count) memset(out->of.record.data, 0, count * sizeof(*out->of.record.data));
  return true;
}
static inline bool lb_graph_field_out(wasmtime_component_valrecord_entry_t *field, const char *name, lb_graph_scope *scope) {
  size_t length = strlen(name);
  if (!lb_charge(&scope->memory, length, 1)) return false;
  wasm_name_new(&field->name, length, name); return true;
}
static inline wasmtime_component_val_t *lb_graph_append(lb_graph_output *context, size_t type, const void *address, wasmtime_component_val_t *reference) {
  if (context->active > LB_GRAPH_DEPTH) { context->scope->memory.failure = 2; return NULL; }
  for (size_t i = 0; i < context->active; ++i) if (context->path[i].type == type && context->path[i].address == address) return NULL;
  lb_graph_table *table = &context->tables[type];
  if (table->count >= LB_GRAPH_NODES) { context->scope->memory.failure = 2; return NULL; }
  if (!lb_charge(&context->scope->memory, 1, sizeof(lb_graph_row))) return NULL;
  lb_graph_row *row = lb_alloc(&context->scope->memory, 1, sizeof(*row));
  if (!row) return NULL;
  if (table->tail) table->tail->next = row; else table->head = row;
  table->tail = row;
  if (!lb_graph_record_out(reference, 1, context->scope) || !lb_graph_field_out(&reference->of.record.data[0], "index", context->scope)) return NULL;
  reference->of.record.data[0].val = (wasmtime_component_val_t){.kind = WASMTIME_COMPONENT_U32, .of.u32 = table->count++};
  context->path[context->active++] = (lb_graph_path){.type = type, .address = address};
  return &row->value;
}
static inline void lb_graph_output_close(lb_graph_output *context) {
  for (size_t i = 0; i < 5; ++i) for (lb_graph_row *row = context->tables[i].head; row; row = row->next) wasmtime_component_val_delete(&row->value);
}
static inline bool lb_graph_finish(lb_graph_output *context, wasmtime_component_val_t *arena) {
  if (!lb_graph_record_out(arena, 5, context->scope)) return false;
  {
    wasmtime_component_valrecord_entry_t *field = &arena->of.record.data[0];
    lb_graph_table *table = &context->tables[0];
    if (!lb_graph_field_out(field, "nodes0", context->scope) || !lb_charge(&context->scope->memory, table->count, sizeof(wasmtime_component_val_t))) return false;
    field->val.kind = WASMTIME_COMPONENT_LIST;
    wasmtime_component_vallist_new_uninit(&field->val.of.list, table->count);
    size_t offset = 0;
    for (lb_graph_row *row = table->head; row; row = row->next) { field->val.of.list.data[offset++] = row->value; row->value = (wasmtime_component_val_t){0}; }
  }
  {
    wasmtime_component_valrecord_entry_t *field = &arena->of.record.data[1];
    lb_graph_table *table = &context->tables[1];
    if (!lb_graph_field_out(field, "nodes1", context->scope) || !lb_charge(&context->scope->memory, table->count, sizeof(wasmtime_component_val_t))) return false;
    field->val.kind = WASMTIME_COMPONENT_LIST;
    wasmtime_component_vallist_new_uninit(&field->val.of.list, table->count);
    size_t offset = 0;
    for (lb_graph_row *row = table->head; row; row = row->next) { field->val.of.list.data[offset++] = row->value; row->value = (wasmtime_component_val_t){0}; }
  }
  {
    wasmtime_component_valrecord_entry_t *field = &arena->of.record.data[2];
    lb_graph_table *table = &context->tables[2];
    if (!lb_graph_field_out(field, "nodes2", context->scope) || !lb_charge(&context->scope->memory, table->count, sizeof(wasmtime_component_val_t))) return false;
    field->val.kind = WASMTIME_COMPONENT_LIST;
    wasmtime_component_vallist_new_uninit(&field->val.of.list, table->count);
    size_t offset = 0;
    for (lb_graph_row *row = table->head; row; row = row->next) { field->val.of.list.data[offset++] = row->value; row->value = (wasmtime_component_val_t){0}; }
  }
  {
    wasmtime_component_valrecord_entry_t *field = &arena->of.record.data[3];
    lb_graph_table *table = &context->tables[3];
    if (!lb_graph_field_out(field, "nodes3", context->scope) || !lb_charge(&context->scope->memory, table->count, sizeof(wasmtime_component_val_t))) return false;
    field->val.kind = WASMTIME_COMPONENT_LIST;
    wasmtime_component_vallist_new_uninit(&field->val.of.list, table->count);
    size_t offset = 0;
    for (lb_graph_row *row = table->head; row; row = row->next) { field->val.of.list.data[offset++] = row->value; row->value = (wasmtime_component_val_t){0}; }
  }
  {
    wasmtime_component_valrecord_entry_t *field = &arena->of.record.data[4];
    lb_graph_table *table = &context->tables[4];
    if (!lb_graph_field_out(field, "nodes4", context->scope) || !lb_charge(&context->scope->memory, table->count, sizeof(wasmtime_component_val_t))) return false;
    field->val.kind = WASMTIME_COMPONENT_LIST;
    wasmtime_component_vallist_new_uninit(&field->val.of.list, table->count);
    size_t offset = 0;
    for (lb_graph_row *row = table->head; row; row = row->next) { field->val.of.list.data[offset++] = row->value; row->value = (wasmtime_component_val_t){0}; }
  }
  return true;
}
static inline bool lb_graph_read_0(const wasmtime_component_val_t *, lb_graph_input *, unsigned, callbackcheckedrecords_graph_38a8689c2f20ead532ea_t *);
static inline bool lb_graph_write_0(const callbackcheckedrecords_graph_38a8689c2f20ead532ea_t *, lb_graph_output *, unsigned, wasmtime_component_val_t *);
static inline bool lb_graph_read_1(const wasmtime_component_val_t *, lb_graph_input *, unsigned, callbackcheckedrecords_graph_7ee21eb6b8ea120b53f0_t *);
static inline bool lb_graph_write_1(const callbackcheckedrecords_graph_7ee21eb6b8ea120b53f0_t *, lb_graph_output *, unsigned, wasmtime_component_val_t *);
static inline bool lb_graph_read_2(const wasmtime_component_val_t *, lb_graph_input *, unsigned, callbackcheckedrecords_graph_29468227bdfd05da1480_t *);
static inline bool lb_graph_write_2(const callbackcheckedrecords_graph_29468227bdfd05da1480_t *, lb_graph_output *, unsigned, wasmtime_component_val_t *);
static inline bool lb_graph_read_3(const wasmtime_component_val_t *, lb_graph_input *, unsigned, callbackcheckedrecords_interval_t *);
static inline bool lb_graph_write_3(const callbackcheckedrecords_interval_t *, lb_graph_output *, unsigned, wasmtime_component_val_t *);
static inline bool lb_graph_read_4(const wasmtime_component_val_t *, lb_graph_input *, unsigned, callbackcheckedrecords_weighted_t *);
static inline bool lb_graph_write_4(const callbackcheckedrecords_weighted_t *, lb_graph_output *, unsigned, wasmtime_component_val_t *);
static inline bool lb_graph_read_5(const wasmtime_component_val_t *, lb_graph_input *, unsigned, callbackcheckedrecords_scalar_nat_t *);
static inline bool lb_graph_write_5(const callbackcheckedrecords_scalar_nat_t *, lb_graph_output *, unsigned, wasmtime_component_val_t *);
static inline bool lb_graph_read_6(const wasmtime_component_val_t *, lb_graph_input *, unsigned, callbackcheckedrecords_scalar_string_t *);
static inline bool lb_graph_write_6(const callbackcheckedrecords_scalar_string_t *, lb_graph_output *, unsigned, wasmtime_component_val_t *);
static inline bool lb_graph_read_7(const wasmtime_component_val_t *, lb_graph_input *, unsigned, uint8_t *);
static inline bool lb_graph_write_7(const uint8_t *, lb_graph_output *, unsigned, wasmtime_component_val_t *);
static inline bool lb_graph_read_0(const wasmtime_component_val_t *value, lb_graph_input *context, unsigned depth, callbackcheckedrecords_graph_38a8689c2f20ead532ea_t *out) {
  (void)out;
  if (!lb_graph_visit(context->scope, depth, sizeof(callbackcheckedrecords_graph_38a8689c2f20ead532ea_t) + sizeof(wasmtime_component_val_t)) || !lb_buffer(value, 1, sizeof(*value), _Alignof(wasmtime_component_val_t))) return false;
  value = lb_graph_dereference(context, 0, value);
  if (!value) return false;
  if (value->kind != WASMTIME_COMPONENT_OPTION) return false;
  bool present = value->of.option != NULL;
  if (out) out->has_value = present;
  if (present) {
  if (!lb_graph_read_3(value->of.option, context, depth + 1, out ? &out->value : NULL)) return false;
  }
  --context->active;
  return true;
}
static inline bool lb_graph_write_0(const callbackcheckedrecords_graph_38a8689c2f20ead532ea_t *value, lb_graph_output *context, unsigned depth, wasmtime_component_val_t *out) {
  if (!lb_graph_visit(context->scope, depth, sizeof(wasmtime_component_val_t)) || !lb_buffer(value, 1, sizeof(*value), _Alignof(callbackcheckedrecords_graph_38a8689c2f20ead532ea_t))) return false;
  out = lb_graph_append(context, 0, value, out);
  if (!out) return false;
  if (value->has_value > 1) return false;
  out->kind = WASMTIME_COMPONENT_OPTION;
  out->of.option = NULL;
  if (value->has_value) {
  if (!lb_charge(&context->scope->memory, 1, sizeof(wasmtime_component_val_t))) return false;
  wasmtime_component_val_t empty = {0}; out->of.option = wasmtime_component_val_new(&empty);
  if (!lb_graph_write_3(&value->value, context, depth + 1, out->of.option)) return false;
  }
  --context->active;
  return true;
}

static inline bool lb_graph_read_1(const wasmtime_component_val_t *value, lb_graph_input *context, unsigned depth, callbackcheckedrecords_graph_7ee21eb6b8ea120b53f0_t *out) {
  (void)out;
  if (!lb_graph_visit(context->scope, depth, sizeof(callbackcheckedrecords_graph_7ee21eb6b8ea120b53f0_t) + sizeof(wasmtime_component_val_t)) || !lb_buffer(value, 1, sizeof(*value), _Alignof(wasmtime_component_val_t))) return false;
  value = lb_graph_dereference(context, 1, value);
  if (!value) return false;
  if (value->kind != WASMTIME_COMPONENT_LIST) return false;
  size_t count = value->of.list.size;
  if (!lb_graph_count(context->scope, count) || !lb_buffer(value->of.list.data, count, sizeof(wasmtime_component_val_t), _Alignof(wasmtime_component_val_t)) || !lb_charge(&context->scope->memory, count, sizeof(callbackcheckedrecords_graph_38a8689c2f20ead532ea_t) + sizeof(wasmtime_component_val_t))) return false;
  callbackcheckedrecords_graph_38a8689c2f20ead532ea_t *items = out ? lb_alloc(&context->scope->memory, count, sizeof(callbackcheckedrecords_graph_38a8689c2f20ead532ea_t)) : NULL;
  if (out && count && !items) return false;
  if (out) { out->data = items; out->length = count; }
  for (size_t i = 0; i < count; ++i) if (!lb_graph_read_0(&value->of.list.data[i], context, depth + 1, out ? &items[i] : NULL)) return false;
  --context->active;
  return true;
}
static inline bool lb_graph_write_1(const callbackcheckedrecords_graph_7ee21eb6b8ea120b53f0_t *value, lb_graph_output *context, unsigned depth, wasmtime_component_val_t *out) {
  if (!lb_graph_visit(context->scope, depth, sizeof(wasmtime_component_val_t)) || !lb_buffer(value, 1, sizeof(*value), _Alignof(callbackcheckedrecords_graph_7ee21eb6b8ea120b53f0_t))) return false;
  out = lb_graph_append(context, 1, value, out);
  if (!out) return false;
  if (!lb_graph_count(context->scope, value->length) || !lb_buffer(value->data, value->length, sizeof(callbackcheckedrecords_graph_38a8689c2f20ead532ea_t), _Alignof(callbackcheckedrecords_graph_38a8689c2f20ead532ea_t)) || !lb_charge(&context->scope->memory, value->length, sizeof(wasmtime_component_val_t))) return false;
  out->kind = WASMTIME_COMPONENT_LIST;
  wasmtime_component_vallist_new_uninit(&out->of.list, value->length);
  if (value->length) memset(out->of.list.data, 0, value->length * sizeof(*out->of.list.data));
  for (size_t i = 0; i < value->length; ++i) if (!lb_graph_write_0(&value->data[i], context, depth + 1, &out->of.list.data[i])) return false;
  --context->active;
  return true;
}

static inline bool lb_graph_read_2(const wasmtime_component_val_t *value, lb_graph_input *context, unsigned depth, callbackcheckedrecords_graph_29468227bdfd05da1480_t *out) {
  (void)out;
  if (!lb_graph_visit(context->scope, depth, sizeof(callbackcheckedrecords_graph_29468227bdfd05da1480_t) + sizeof(wasmtime_component_val_t)) || !lb_buffer(value, 1, sizeof(*value), _Alignof(wasmtime_component_val_t))) return false;
  value = lb_graph_dereference(context, 2, value);
  if (!value) return false;
  if (value->kind != WASMTIME_COMPONENT_RESULT) return false;
  bool present; if (!value->of.result.val || !lb_boolean(&value->of.result.is_ok, &present)) return false;
  if (out) out->is_ok = present;
  if (present) {
  if (!lb_graph_read_0(value->of.result.val, context, depth + 1, out ? &out->ok : NULL)) return false;
  }
  else if (!present) {
  if (!lb_graph_read_6(value->of.result.val, context, depth + 1, out ? &out->error : NULL)) return false;
  }
  --context->active;
  return true;
}
static inline bool lb_graph_write_2(const callbackcheckedrecords_graph_29468227bdfd05da1480_t *value, lb_graph_output *context, unsigned depth, wasmtime_component_val_t *out) {
  if (!lb_graph_visit(context->scope, depth, sizeof(wasmtime_component_val_t)) || !lb_buffer(value, 1, sizeof(*value), _Alignof(callbackcheckedrecords_graph_29468227bdfd05da1480_t))) return false;
  out = lb_graph_append(context, 2, value, out);
  if (!out) return false;
  if (value->is_ok > 1) return false;
  out->kind = WASMTIME_COMPONENT_RESULT;
  out->of.result.is_ok = value->is_ok;
  if (!lb_charge(&context->scope->memory, 1, sizeof(wasmtime_component_val_t))) return false;
  wasmtime_component_val_t empty = {0}; out->of.result.val = wasmtime_component_val_new(&empty);
  if (value->is_ok) {
  if (!lb_graph_write_0(&value->ok, context, depth + 1, out->of.result.val)) return false;
  }
  else if (!value->is_ok) {
  if (!lb_graph_write_6(&value->error, context, depth + 1, out->of.result.val)) return false;
  }
  --context->active;
  return true;
}

static inline bool lb_graph_read_3(const wasmtime_component_val_t *value, lb_graph_input *context, unsigned depth, callbackcheckedrecords_interval_t *out) {
  (void)out;
  if (!lb_graph_visit(context->scope, depth, sizeof(callbackcheckedrecords_interval_t) + sizeof(wasmtime_component_val_t)) || !lb_buffer(value, 1, sizeof(*value), _Alignof(wasmtime_component_val_t))) return false;
  value = lb_graph_dereference(context, 3, value);
  if (!value) return false;
  if (!lb_graph_record_in(value, 2, context->scope)) return false;
  if (!lb_name(&value->of.record.data[0].name, "lo")) return false;
  if (!lb_graph_read_5(&value->of.record.data[0].val, context, depth + 1, out ? &out->lo : NULL)) return false;
  if (!lb_name(&value->of.record.data[1].name, "hi")) return false;
  if (!lb_graph_read_5(&value->of.record.data[1].val, context, depth + 1, out ? &out->hi : NULL)) return false;
  --context->active;
  return true;
}
static inline bool lb_graph_write_3(const callbackcheckedrecords_interval_t *value, lb_graph_output *context, unsigned depth, wasmtime_component_val_t *out) {
  if (!lb_graph_visit(context->scope, depth, sizeof(wasmtime_component_val_t)) || !lb_buffer(value, 1, sizeof(*value), _Alignof(callbackcheckedrecords_interval_t))) return false;
  out = lb_graph_append(context, 3, value, out);
  if (!out) return false;
  if (!lb_graph_record_out(out, 2, context->scope)) return false;
  if (!lb_graph_field_out(&out->of.record.data[0], "lo", context->scope)) return false;
  if (!lb_graph_write_5(&value->lo, context, depth + 1, &out->of.record.data[0].val)) return false;
  if (!lb_graph_field_out(&out->of.record.data[1], "hi", context->scope)) return false;
  if (!lb_graph_write_5(&value->hi, context, depth + 1, &out->of.record.data[1].val)) return false;
  --context->active;
  return true;
}

static inline bool lb_graph_read_4(const wasmtime_component_val_t *value, lb_graph_input *context, unsigned depth, callbackcheckedrecords_weighted_t *out) {
  (void)out;
  if (!lb_graph_visit(context->scope, depth, sizeof(callbackcheckedrecords_weighted_t) + sizeof(wasmtime_component_val_t)) || !lb_buffer(value, 1, sizeof(*value), _Alignof(wasmtime_component_val_t))) return false;
  value = lb_graph_dereference(context, 4, value);
  if (!value) return false;
  if (!lb_graph_record_in(value, 2, context->scope)) return false;
  if (!lb_name(&value->of.record.data[0].name, "weight")) return false;
  if (!lb_graph_read_5(&value->of.record.data[0].val, context, depth + 1, out ? &out->weight : NULL)) return false;
  if (!lb_name(&value->of.record.data[1].name, "limit")) return false;
  if (!lb_graph_read_5(&value->of.record.data[1].val, context, depth + 1, out ? &out->limit : NULL)) return false;
  --context->active;
  return true;
}
static inline bool lb_graph_write_4(const callbackcheckedrecords_weighted_t *value, lb_graph_output *context, unsigned depth, wasmtime_component_val_t *out) {
  if (!lb_graph_visit(context->scope, depth, sizeof(wasmtime_component_val_t)) || !lb_buffer(value, 1, sizeof(*value), _Alignof(callbackcheckedrecords_weighted_t))) return false;
  out = lb_graph_append(context, 4, value, out);
  if (!out) return false;
  if (!lb_graph_record_out(out, 2, context->scope)) return false;
  if (!lb_graph_field_out(&out->of.record.data[0], "weight", context->scope)) return false;
  if (!lb_graph_write_5(&value->weight, context, depth + 1, &out->of.record.data[0].val)) return false;
  if (!lb_graph_field_out(&out->of.record.data[1], "limit", context->scope)) return false;
  if (!lb_graph_write_5(&value->limit, context, depth + 1, &out->of.record.data[1].val)) return false;
  --context->active;
  return true;
}

static inline bool lb_graph_read_5(const wasmtime_component_val_t *value, lb_graph_input *context, unsigned depth, callbackcheckedrecords_scalar_nat_t *out) {
  (void)out;
  if (!lb_graph_visit(context->scope, depth, sizeof(callbackcheckedrecords_scalar_nat_t) + sizeof(wasmtime_component_val_t)) || !lb_buffer(value, 1, sizeof(*value), _Alignof(wasmtime_component_val_t))) return false;
  return lb_in_5(value, &context->scope->memory, out);
}
static inline bool lb_graph_write_5(const callbackcheckedrecords_scalar_nat_t *value, lb_graph_output *context, unsigned depth, wasmtime_component_val_t *out) {
  if (!lb_graph_visit(context->scope, depth, sizeof(wasmtime_component_val_t)) || !lb_buffer(value, 1, sizeof(*value), _Alignof(callbackcheckedrecords_scalar_nat_t))) return false;
  return lb_out_5(value, &context->scope->memory, out);
}

static inline bool lb_graph_read_6(const wasmtime_component_val_t *value, lb_graph_input *context, unsigned depth, callbackcheckedrecords_scalar_string_t *out) {
  (void)out;
  if (!lb_graph_visit(context->scope, depth, sizeof(callbackcheckedrecords_scalar_string_t) + sizeof(wasmtime_component_val_t)) || !lb_buffer(value, 1, sizeof(*value), _Alignof(wasmtime_component_val_t))) return false;
  return lb_in_6(value, &context->scope->memory, out);
}
static inline bool lb_graph_write_6(const callbackcheckedrecords_scalar_string_t *value, lb_graph_output *context, unsigned depth, wasmtime_component_val_t *out) {
  if (!lb_graph_visit(context->scope, depth, sizeof(wasmtime_component_val_t)) || !lb_buffer(value, 1, sizeof(*value), _Alignof(callbackcheckedrecords_scalar_string_t))) return false;
  return lb_out_6(value, &context->scope->memory, out);
}

static inline bool lb_graph_read_7(const wasmtime_component_val_t *value, lb_graph_input *context, unsigned depth, uint8_t *out) {
  (void)out;
  if (!lb_graph_visit(context->scope, depth, sizeof(uint8_t) + sizeof(wasmtime_component_val_t)) || !lb_buffer(value, 1, sizeof(*value), _Alignof(wasmtime_component_val_t))) return false;
  return lb_in_7(value, &context->scope->memory, out);
}
static inline bool lb_graph_write_7(const uint8_t *value, lb_graph_output *context, unsigned depth, wasmtime_component_val_t *out) {
  if (!lb_graph_visit(context->scope, depth, sizeof(wasmtime_component_val_t)) || !lb_buffer(value, 1, sizeof(*value), _Alignof(uint8_t))) return false;
  return lb_out_7(value, &context->scope->memory, out);
}
static inline bool lb_graph_decode_0(const wasmtime_component_val_t *value, lb_graph_scope *scope, callbackcheckedrecords_graph_38a8689c2f20ead532ea_t *out) {
  if (out && !lb_buffer(out, 1, sizeof(*out), _Alignof(callbackcheckedrecords_graph_38a8689c2f20ead532ea_t))) return false;
  callbackcheckedrecords_graph_38a8689c2f20ead532ea_t converted = {0};
  lb_graph_input *context = lb_graph_open(value, scope);
  if (!context || !lb_graph_read_0(&value->of.record.data[0].val, context, 0, out ? &converted : NULL) || context->visited != context->total) return false;
  if (out) *out = converted;
  return true;
}
static inline bool lb_graph_encode_0(const callbackcheckedrecords_graph_38a8689c2f20ead532ea_t *value, lb_graph_scope *scope, wasmtime_component_val_t *out) {
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(wasmtime_component_val_t))) return false;
  wasmtime_component_val_t converted = {0};
  if (!lb_charge(&scope->memory, 1, sizeof(lb_graph_output))) return false;
  lb_graph_output *context = lb_alloc(&scope->memory, 1, sizeof(*context));
  if (!context) return false;
  context->scope = scope;
  bool valid = lb_graph_record_out(&converted, 2, scope)
    && lb_graph_field_out(&converted.of.record.data[0], "root", scope)
    && lb_graph_field_out(&converted.of.record.data[1], "nodes", scope)
    && lb_graph_write_0(value, context, 0, &converted.of.record.data[0].val)
    && lb_graph_finish(context, &converted.of.record.data[1].val);
  lb_graph_output_close(context);
  if (valid) *out = converted; else wasmtime_component_val_delete(&converted);
  return valid;
}


static inline bool lb_graph_decode_1(const wasmtime_component_val_t *value, lb_graph_scope *scope, callbackcheckedrecords_graph_7ee21eb6b8ea120b53f0_t *out) {
  if (out && !lb_buffer(out, 1, sizeof(*out), _Alignof(callbackcheckedrecords_graph_7ee21eb6b8ea120b53f0_t))) return false;
  callbackcheckedrecords_graph_7ee21eb6b8ea120b53f0_t converted = {0};
  lb_graph_input *context = lb_graph_open(value, scope);
  if (!context || !lb_graph_read_1(&value->of.record.data[0].val, context, 0, out ? &converted : NULL) || context->visited != context->total) return false;
  if (out) *out = converted;
  return true;
}
static inline bool lb_graph_encode_1(const callbackcheckedrecords_graph_7ee21eb6b8ea120b53f0_t *value, lb_graph_scope *scope, wasmtime_component_val_t *out) {
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(wasmtime_component_val_t))) return false;
  wasmtime_component_val_t converted = {0};
  if (!lb_charge(&scope->memory, 1, sizeof(lb_graph_output))) return false;
  lb_graph_output *context = lb_alloc(&scope->memory, 1, sizeof(*context));
  if (!context) return false;
  context->scope = scope;
  bool valid = lb_graph_record_out(&converted, 2, scope)
    && lb_graph_field_out(&converted.of.record.data[0], "root", scope)
    && lb_graph_field_out(&converted.of.record.data[1], "nodes", scope)
    && lb_graph_write_1(value, context, 0, &converted.of.record.data[0].val)
    && lb_graph_finish(context, &converted.of.record.data[1].val);
  lb_graph_output_close(context);
  if (valid) *out = converted; else wasmtime_component_val_delete(&converted);
  return valid;
}


static inline bool lb_graph_decode_2(const wasmtime_component_val_t *value, lb_graph_scope *scope, callbackcheckedrecords_graph_29468227bdfd05da1480_t *out) {
  if (out && !lb_buffer(out, 1, sizeof(*out), _Alignof(callbackcheckedrecords_graph_29468227bdfd05da1480_t))) return false;
  callbackcheckedrecords_graph_29468227bdfd05da1480_t converted = {0};
  lb_graph_input *context = lb_graph_open(value, scope);
  if (!context || !lb_graph_read_2(&value->of.record.data[0].val, context, 0, out ? &converted : NULL) || context->visited != context->total) return false;
  if (out) *out = converted;
  return true;
}
static inline bool lb_graph_encode_2(const callbackcheckedrecords_graph_29468227bdfd05da1480_t *value, lb_graph_scope *scope, wasmtime_component_val_t *out) {
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(wasmtime_component_val_t))) return false;
  wasmtime_component_val_t converted = {0};
  if (!lb_charge(&scope->memory, 1, sizeof(lb_graph_output))) return false;
  lb_graph_output *context = lb_alloc(&scope->memory, 1, sizeof(*context));
  if (!context) return false;
  context->scope = scope;
  bool valid = lb_graph_record_out(&converted, 2, scope)
    && lb_graph_field_out(&converted.of.record.data[0], "root", scope)
    && lb_graph_field_out(&converted.of.record.data[1], "nodes", scope)
    && lb_graph_write_2(value, context, 0, &converted.of.record.data[0].val)
    && lb_graph_finish(context, &converted.of.record.data[1].val);
  lb_graph_output_close(context);
  if (valid) *out = converted; else wasmtime_component_val_delete(&converted);
  return valid;
}


static inline bool lb_graph_decode_3(const wasmtime_component_val_t *value, lb_graph_scope *scope, callbackcheckedrecords_interval_t *out) {
  if (out && !lb_buffer(out, 1, sizeof(*out), _Alignof(callbackcheckedrecords_interval_t))) return false;
  callbackcheckedrecords_interval_t converted = {0};
  lb_graph_input *context = lb_graph_open(value, scope);
  if (!context || !lb_graph_read_3(&value->of.record.data[0].val, context, 0, out ? &converted : NULL) || context->visited != context->total) return false;
  if (out) *out = converted;
  return true;
}
static inline bool lb_graph_encode_3(const callbackcheckedrecords_interval_t *value, lb_graph_scope *scope, wasmtime_component_val_t *out) {
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(wasmtime_component_val_t))) return false;
  wasmtime_component_val_t converted = {0};
  if (!lb_charge(&scope->memory, 1, sizeof(lb_graph_output))) return false;
  lb_graph_output *context = lb_alloc(&scope->memory, 1, sizeof(*context));
  if (!context) return false;
  context->scope = scope;
  bool valid = lb_graph_record_out(&converted, 2, scope)
    && lb_graph_field_out(&converted.of.record.data[0], "root", scope)
    && lb_graph_field_out(&converted.of.record.data[1], "nodes", scope)
    && lb_graph_write_3(value, context, 0, &converted.of.record.data[0].val)
    && lb_graph_finish(context, &converted.of.record.data[1].val);
  lb_graph_output_close(context);
  if (valid) *out = converted; else wasmtime_component_val_delete(&converted);
  return valid;
}


static inline bool lb_graph_decode_4(const wasmtime_component_val_t *value, lb_graph_scope *scope, callbackcheckedrecords_weighted_t *out) {
  if (out && !lb_buffer(out, 1, sizeof(*out), _Alignof(callbackcheckedrecords_weighted_t))) return false;
  callbackcheckedrecords_weighted_t converted = {0};
  lb_graph_input *context = lb_graph_open(value, scope);
  if (!context || !lb_graph_read_4(&value->of.record.data[0].val, context, 0, out ? &converted : NULL) || context->visited != context->total) return false;
  if (out) *out = converted;
  return true;
}
static inline bool lb_graph_encode_4(const callbackcheckedrecords_weighted_t *value, lb_graph_scope *scope, wasmtime_component_val_t *out) {
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(wasmtime_component_val_t))) return false;
  wasmtime_component_val_t converted = {0};
  if (!lb_charge(&scope->memory, 1, sizeof(lb_graph_output))) return false;
  lb_graph_output *context = lb_alloc(&scope->memory, 1, sizeof(*context));
  if (!context) return false;
  context->scope = scope;
  bool valid = lb_graph_record_out(&converted, 2, scope)
    && lb_graph_field_out(&converted.of.record.data[0], "root", scope)
    && lb_graph_field_out(&converted.of.record.data[1], "nodes", scope)
    && lb_graph_write_4(value, context, 0, &converted.of.record.data[0].val)
    && lb_graph_finish(context, &converted.of.record.data[1].val);
  lb_graph_output_close(context);
  if (valid) *out = converted; else wasmtime_component_val_delete(&converted);
  return valid;
}


static inline bool lb_graph_decode_5(const wasmtime_component_val_t *value, lb_graph_scope *scope, callbackcheckedrecords_scalar_nat_t *out) {
  if (out && !lb_buffer(out, 1, sizeof(*out), _Alignof(callbackcheckedrecords_scalar_nat_t))) return false;
  callbackcheckedrecords_scalar_nat_t converted = {0};
  lb_graph_input context = {.scope = scope};
  if (!lb_graph_read_5(value, &context, 0, out ? &converted : NULL)) return false;
  if (out) *out = converted;
  return true;
}
static inline bool lb_graph_encode_5(const callbackcheckedrecords_scalar_nat_t *value, lb_graph_scope *scope, wasmtime_component_val_t *out) {
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(wasmtime_component_val_t))) return false;
  wasmtime_component_val_t converted = {0};
  lb_graph_output context = {.scope = scope};
  bool valid = lb_graph_write_5(value, &context, 0, &converted);
  if (valid) *out = converted; else wasmtime_component_val_delete(&converted);
  return valid;
}


static inline bool lb_graph_decode_6(const wasmtime_component_val_t *value, lb_graph_scope *scope, callbackcheckedrecords_scalar_string_t *out) {
  if (out && !lb_buffer(out, 1, sizeof(*out), _Alignof(callbackcheckedrecords_scalar_string_t))) return false;
  callbackcheckedrecords_scalar_string_t converted = {0};
  lb_graph_input context = {.scope = scope};
  if (!lb_graph_read_6(value, &context, 0, out ? &converted : NULL)) return false;
  if (out) *out = converted;
  return true;
}
static inline bool lb_graph_encode_6(const callbackcheckedrecords_scalar_string_t *value, lb_graph_scope *scope, wasmtime_component_val_t *out) {
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(wasmtime_component_val_t))) return false;
  wasmtime_component_val_t converted = {0};
  lb_graph_output context = {.scope = scope};
  bool valid = lb_graph_write_6(value, &context, 0, &converted);
  if (valid) *out = converted; else wasmtime_component_val_delete(&converted);
  return valid;
}


static inline bool lb_graph_decode_7(const wasmtime_component_val_t *value, lb_graph_scope *scope, uint8_t *out) {
  if (out && !lb_buffer(out, 1, sizeof(*out), _Alignof(uint8_t))) return false;
  uint8_t converted = {0};
  lb_graph_input context = {.scope = scope};
  if (!lb_graph_read_7(value, &context, 0, out ? &converted : NULL)) return false;
  if (out) *out = converted;
  return true;
}
static inline bool lb_graph_encode_7(const uint8_t *value, lb_graph_scope *scope, wasmtime_component_val_t *out) {
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(wasmtime_component_val_t))) return false;
  wasmtime_component_val_t converted = {0};
  lb_graph_output context = {.scope = scope};
  bool valid = lb_graph_write_7(value, &context, 0, &converted);
  if (valid) *out = converted; else wasmtime_component_val_delete(&converted);
  return valid;
}


#define LB_CAPACITY 1024
#define LB_BUDGET (16u * 1024u * 1024u)
#define LB_MAX_ARGS 3
typedef struct lb_entry lb_entry;
typedef struct lb_frame { struct lb_frame *previous, *thread_previous; callbackcheckedrecords_wasmtime *session; lb_entry *pending; } lb_frame;
static _Thread_local lb_frame *lb_active_frame;
static _Thread_local uint64_t lb_thread_serial;
static uint64_t lb_thread_counter;
static pthread_mutex_t lb_thread_mutex = PTHREAD_MUTEX_INITIALIZER;
static uint64_t lb_thread_identity(void) {
  if (!lb_thread_serial) {
    pthread_mutex_lock(&lb_thread_mutex);
    if (lb_thread_counter != UINT64_MAX) lb_thread_serial = ++lb_thread_counter;
    pthread_mutex_unlock(&lb_thread_mutex);
  }
  return lb_thread_serial;
}
struct lb_entry {
  uint64_t token;
  uint32_t tag;
  unsigned active;
  bool closed;
  callbackcheckedrecords_wasmtime *session;
  callbackcheckedrecords_wasmtime_callback callback;
  void *data, *owned, *recovery;
  void (*release)(void *);
};
struct callbackcheckedrecords_wasmtime {
  wasm_engine_t *engine;
  wasmtime_component_t *component;
  wasmtime_store_t *store;
  wasmtime_component_linker_t *linker;
  wasmtime_component_instance_t instance;
  pthread_t thread;
  uint64_t thread_serial;
  pid_t process;
  unsigned depth, finalizing;
  bool poisoned, closing;
  char first_error[1024];
  lb_frame *frame;
  lb_entry entries[LB_CAPACITY];
};
static const char lb_identity_kind[] = "callbackcheckedrecords:wit-callable";
static bool lb_thread(callbackcheckedrecords_wasmtime *session) {
  return session && session->process == getpid() && session->thread_serial == lb_thread_identity() && pthread_equal(session->thread, pthread_self()) && !session->finalizing;
}
static void lb_record_text(callbackcheckedrecords_wasmtime *session, const char *text, size_t length) {
  if (!session->poisoned) {
    if (length >= sizeof(session->first_error)) length = sizeof(session->first_error) - 1;
    memcpy(session->first_error, text, length); session->first_error[length] = 0;
  }
  session->poisoned = true;
}
static void lb_record_error(callbackcheckedrecords_wasmtime *session, wasmtime_error_t *error) {
  if (session->poisoned) return;
  wasm_name_t message; wasmtime_error_message(error, &message);
  lb_record_text(session, message.data, message.size); wasm_name_delete(&message);
}
static lb_entry *lb_entry_find(callbackcheckedrecords_wasmtime *session, uint64_t token) {
  for (size_t i = 0; token && i < LB_CAPACITY; ++i)
    if (session->entries[i].token == token && !session->entries[i].closed) return &session->entries[i];
  return NULL;
}
static lb_entry *lb_entry_new(callbackcheckedrecords_wasmtime *session, uint32_t tag) {
  for (size_t i = 0; i < LB_CAPACITY; ++i) {
    lb_entry *entry = &session->entries[i];
    if (entry->token) continue;
    uint64_t token = lean_bridge_native_identity_acquire(lb_identity_kind, entry);
    if (!token) return NULL;
    *entry = (lb_entry){.token = token, .tag = tag, .session = session}; return entry;
  }
  return NULL;
}
static void lb_entry_collect(lb_entry *entry) {
  if (!entry->token || !entry->closed || entry->active) return;
  callbackcheckedrecords_wasmtime *session = entry->session;
  void (*release)(void *) = entry->release;
  void *data = entry->owned ? entry->owned : entry->data;
  (void)lean_bridge_native_identity_release(entry->token, lb_identity_kind, entry);
  *entry = (lb_entry){0};
  if (release) { ++session->finalizing; release(data); --session->finalizing; }
}
typedef struct { lb_scope scope; wasmtime_component_val_t value; } lb_result;
static inline void lb_result_release(void *data) {
  lb_result *owner = data;
  lb_scope_close(&owner->scope); wasmtime_component_val_delete(&owner->value); free(owner);
}
/* Proxies never own a persistent lease. A call frame owns unreturned leases;
 * the session owns published tokens. Dropping a proxy cannot close an alias. */
static wasmtime_error_t *lb_proxy_drop(void *data, wasmtime_context_t *context, uint32_t rep) {
  (void)data; (void)context; (void)rep; return NULL;
}
static wasmtime_error_t *lb_proxy(callbackcheckedrecords_wasmtime *session, wasmtime_context_t *context,
    lb_entry *entry, wasmtime_component_val_t *out) {
  uint32_t rep = (uint32_t)(entry - session->entries) + 1;
  wasmtime_component_resource_host_t *host = wasmtime_component_resource_host_new(true, rep, entry->tag);
  out->kind = WASMTIME_COMPONENT_RESOURCE;
  wasmtime_error_t *error = wasmtime_component_resource_host_to_any(context, host, &out->of.resource);
  wasmtime_component_resource_host_delete(host);
  if (error) *out = (wasmtime_component_val_t){0};
  return error;
}
static wasmtime_error_t *lb_unwrap(callbackcheckedrecords_wasmtime *session, wasmtime_context_t *context,
    const wasmtime_component_val_t *value, uint32_t tag, bool owned, lb_entry **out) {
  if (value->kind != WASMTIME_COMPONENT_RESOURCE || !value->of.resource || wasmtime_component_resource_any_owned(value->of.resource) != owned)
    return wasmtime_error_new("Invalid WIT callable resource ownership");
  wasmtime_component_resource_host_t *host = NULL;
  wasmtime_error_t *error = wasmtime_component_resource_any_to_host(context, value->of.resource, &host);
  if (error) return error;
  uint32_t rep = wasmtime_component_resource_host_rep(host), actual = wasmtime_component_resource_host_type(host);
  wasmtime_component_resource_host_delete(host);
  if (!rep || rep > LB_CAPACITY || actual != tag) return wasmtime_error_new("Invalid WIT callable representation");
  lb_entry *entry = &session->entries[rep - 1];
  if (!entry->token || entry->tag != tag) return wasmtime_error_new("Expired WIT callable resource");
  *out = entry; return NULL;
}
static wasmtime_error_t *lb_borrow(callbackcheckedrecords_wasmtime *session, wasmtime_context_t *context,
    const wasmtime_component_val_t *value, uint32_t tag, lb_entry **out) {
  wasmtime_error_t *error = lb_unwrap(session, context, value, tag, false, out);
  if (!error && !(*out)->active) error = wasmtime_error_new("WIT callable has no active borrow");
  return error;
}

/* Validate a callback context against active frames before dereferencing it.
 * A stale, foreign, wrong-thread or wrong-signature context owns no borrow. */
static lb_entry *lb_graph_callback_entry(void *raw, uint32_t tag) {
  uintptr_t address = (uintptr_t)raw;
  for (lb_frame *frame = lb_active_frame; frame; frame = frame->thread_previous) {
    callbackcheckedrecords_wasmtime *session = frame->session;
    uintptr_t first = (uintptr_t)&session->entries[0];
    if (address < first || address - first >= sizeof(session->entries) || (address - first) % sizeof(lb_entry)) continue;
    lb_entry *entry = raw;
    if (entry->session == session && entry->active && entry->token && entry->tag == tag && lb_thread(session)) return entry;
  }
  return NULL;
}

typedef struct { uint64_t token; } lb_graph_lease;

static uint32_t lb_graph_callback_2(void *data, const callbackcheckedrecords_graph_38a8689c2f20ead532ea_t *arg0, callbackcheckedrecords_graph_29468227bdfd05da1480_t *out) {
  lb_entry *entry = lb_graph_callback_entry(data, 2);
  if (!entry) return 1;
  callbackcheckedrecords_wasmtime *session = entry->session;
  if (session->poisoned || session->closing) return 1;
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(callbackcheckedrecords_graph_29468227bdfd05da1480_t)) || out->_bridge_owner || out->_bridge_release) return 1;
  
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  wasmtime_component_val_t args[1] = {{0}}, reply = {0};
  wasmtime_error_t *failure = NULL;
  uint32_t status = 0;
  callbackcheckedrecords_graph_29468227bdfd05da1480_t converted = {0};
  lb_result *owner = NULL;
  if (!lb_graph_encode_0(arg0, &input, &args[0])) {
    if (!input.memory.failure) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new(input.memory.failure ? "WIT callback input conversion limit or allocation failure" : "Malformed native callback input; runtime retired"); goto done;
  }
  failure = entry->callback(entry->data, args, 1, &reply);
  if (failure || session->poisoned || session->closing) goto done;
  if (!lb_graph_decode_2(&reply, &output, &converted)) { failure = wasmtime_error_new("Invalid WIT callback result, conversion limit or allocation failure"); goto done; }
  if (!lean_bridge_native_component_ready("callbackcheckedrecords@1.0.0")) { failure = wasmtime_error_new("Lean runtime is unavailable"); goto done; }
  if (!lb_charge(&output.memory, 1, sizeof(*owner))) { failure = wasmtime_error_new("WIT callback reply ownership limit"); goto done; }
  owner = calloc(1, sizeof(*owner));
  if (!owner) { failure = wasmtime_error_new("Cannot allocate WIT callback reply owner"); goto done; }
  owner->scope = output.memory; output.memory.allocations = NULL;
  owner->value = reply; reply = (wasmtime_component_val_t){0};
  converted._bridge_owner = owner; converted._bridge_release = lb_result_release;
  *out = converted;
done:
  if (failure) { lb_record_error(session, failure); wasmtime_error_delete(failure); }
  if (session->closing && !session->poisoned) lb_record_text(session, "WIT session closed during callback", sizeof("WIT session closed during callback") - 1);
  if (session->poisoned) status = 1;
  for (size_t i = 0; i < 1; ++i) wasmtime_component_val_delete(&args[i]);
  wasmtime_component_val_delete(&reply); lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return status;
}


static uint32_t lb_graph_callback_3(void *data, const callbackcheckedrecords_scalar_nat_t *arg0, const callbackcheckedrecords_interval_t *arg1, callbackcheckedrecords_interval_t *out) {
  lb_entry *entry = lb_graph_callback_entry(data, 3);
  if (!entry) return 1;
  callbackcheckedrecords_wasmtime *session = entry->session;
  if (session->poisoned || session->closing) return 1;
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(callbackcheckedrecords_interval_t)) || out->_bridge_owner || out->_bridge_release) return 1;
  
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  wasmtime_component_val_t args[2] = {{0}}, reply = {0};
  wasmtime_error_t *failure = NULL;
  uint32_t status = 0;
  callbackcheckedrecords_interval_t converted = {0};
  lb_result *owner = NULL;
  if (!lb_graph_encode_5(arg0, &input, &args[0])) {
    if (!input.memory.failure) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new(input.memory.failure ? "WIT callback input conversion limit or allocation failure" : "Malformed native callback input; runtime retired"); goto done;
  }
  if (!lb_graph_encode_3(arg1, &input, &args[1])) {
    if (!input.memory.failure) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new(input.memory.failure ? "WIT callback input conversion limit or allocation failure" : "Malformed native callback input; runtime retired"); goto done;
  }
  failure = entry->callback(entry->data, args, 2, &reply);
  if (failure || session->poisoned || session->closing) goto done;
  if (!lb_graph_decode_3(&reply, &output, &converted)) { failure = wasmtime_error_new("Invalid WIT callback result, conversion limit or allocation failure"); goto done; }
  if (!lean_bridge_native_component_ready("callbackcheckedrecords@1.0.0")) { failure = wasmtime_error_new("Lean runtime is unavailable"); goto done; }
  if (!lb_charge(&output.memory, 1, sizeof(*owner))) { failure = wasmtime_error_new("WIT callback reply ownership limit"); goto done; }
  owner = calloc(1, sizeof(*owner));
  if (!owner) { failure = wasmtime_error_new("Cannot allocate WIT callback reply owner"); goto done; }
  owner->scope = output.memory; output.memory.allocations = NULL;
  owner->value = reply; reply = (wasmtime_component_val_t){0};
  converted._bridge_owner = owner; converted._bridge_release = lb_result_release;
  *out = converted;
done:
  if (failure) { lb_record_error(session, failure); wasmtime_error_delete(failure); }
  if (session->closing && !session->poisoned) lb_record_text(session, "WIT session closed during callback", sizeof("WIT session closed during callback") - 1);
  if (session->poisoned) status = 1;
  for (size_t i = 0; i < 2; ++i) wasmtime_component_val_delete(&args[i]);
  wasmtime_component_val_delete(&reply); lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return status;
}


static uint32_t lb_graph_callback_5(void *data, const callbackcheckedrecords_interval_t *arg0, callbackcheckedrecords_scalar_nat_t *out) {
  lb_entry *entry = lb_graph_callback_entry(data, 5);
  if (!entry) return 1;
  callbackcheckedrecords_wasmtime *session = entry->session;
  if (session->poisoned || session->closing) return 1;
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(callbackcheckedrecords_scalar_nat_t)) || out->_bridge_owner || out->_bridge_release) return 1;
  if (entry->owned) {
    uint32_t status = callbackcheckedrecords_callback_e014092ff0a1ee8527eeeb58a78e2de63bdf09fa_lease_call(((lb_graph_lease *)entry->owned)->token, arg0, out);
    if (status) { const char *refusal = status == 1 ? callbackcheckedrecords_callable_graph_error() : NULL;
      if (refusal) lb_record_text(session, refusal, strlen(refusal));
      else lb_record_text(session, "Native Lean closure call failed", sizeof("Native Lean closure call failed") - 1); }
    return status;
  }
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  wasmtime_component_val_t args[1] = {{0}}, reply = {0};
  wasmtime_error_t *failure = NULL;
  uint32_t status = 0;
  callbackcheckedrecords_scalar_nat_t converted = {0};
  lb_result *owner = NULL;
  if (!lb_graph_encode_3(arg0, &input, &args[0])) {
    if (!input.memory.failure) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new(input.memory.failure ? "WIT callback input conversion limit or allocation failure" : "Malformed native callback input; runtime retired"); goto done;
  }
  failure = entry->callback(entry->data, args, 1, &reply);
  if (failure || session->poisoned || session->closing) goto done;
  if (!lb_graph_decode_5(&reply, &output, &converted)) { failure = wasmtime_error_new("Invalid WIT callback result, conversion limit or allocation failure"); goto done; }
  if (!lean_bridge_native_component_ready("callbackcheckedrecords@1.0.0")) { failure = wasmtime_error_new("Lean runtime is unavailable"); goto done; }
  if (!lb_charge(&output.memory, 1, sizeof(*owner))) { failure = wasmtime_error_new("WIT callback reply ownership limit"); goto done; }
  owner = calloc(1, sizeof(*owner));
  if (!owner) { failure = wasmtime_error_new("Cannot allocate WIT callback reply owner"); goto done; }
  owner->scope = output.memory; output.memory.allocations = NULL;
  owner->value = reply; reply = (wasmtime_component_val_t){0};
  converted._bridge_owner = owner; converted._bridge_release = lb_result_release;
  *out = converted;
done:
  if (failure) { lb_record_error(session, failure); wasmtime_error_delete(failure); }
  if (session->closing && !session->poisoned) lb_record_text(session, "WIT session closed during callback", sizeof("WIT session closed during callback") - 1);
  if (session->poisoned) status = 1;
  for (size_t i = 0; i < 1; ++i) wasmtime_component_val_delete(&args[i]);
  wasmtime_component_val_delete(&reply); lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return status;
}
static inline void lb_graph_owned_drop_5(void *data) {
  lb_graph_lease *lease = data; callbackcheckedrecords_callback_e014092ff0a1ee8527eeeb58a78e2de63bdf09fa_lease_dispose(lease->token); free(lease);
}

static uint32_t lb_graph_callback_1(void *data, const callbackcheckedrecords_interval_t *arg0, callbackcheckedrecords_interval_t *out) {
  lb_entry *entry = lb_graph_callback_entry(data, 1);
  if (!entry) return 1;
  callbackcheckedrecords_wasmtime *session = entry->session;
  if (session->poisoned || session->closing) return 1;
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(callbackcheckedrecords_interval_t)) || out->_bridge_owner || out->_bridge_release) return 1;
  
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  wasmtime_component_val_t args[1] = {{0}}, reply = {0};
  wasmtime_error_t *failure = NULL;
  uint32_t status = 0;
  callbackcheckedrecords_interval_t converted = {0};
  lb_result *owner = NULL;
  if (!lb_graph_encode_3(arg0, &input, &args[0])) {
    if (!input.memory.failure) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new(input.memory.failure ? "WIT callback input conversion limit or allocation failure" : "Malformed native callback input; runtime retired"); goto done;
  }
  failure = entry->callback(entry->data, args, 1, &reply);
  if (failure || session->poisoned || session->closing) goto done;
  if (!lb_graph_decode_3(&reply, &output, &converted)) { failure = wasmtime_error_new("Invalid WIT callback result, conversion limit or allocation failure"); goto done; }
  if (!lean_bridge_native_component_ready("callbackcheckedrecords@1.0.0")) { failure = wasmtime_error_new("Lean runtime is unavailable"); goto done; }
  if (!lb_charge(&output.memory, 1, sizeof(*owner))) { failure = wasmtime_error_new("WIT callback reply ownership limit"); goto done; }
  owner = calloc(1, sizeof(*owner));
  if (!owner) { failure = wasmtime_error_new("Cannot allocate WIT callback reply owner"); goto done; }
  owner->scope = output.memory; output.memory.allocations = NULL;
  owner->value = reply; reply = (wasmtime_component_val_t){0};
  converted._bridge_owner = owner; converted._bridge_release = lb_result_release;
  *out = converted;
done:
  if (failure) { lb_record_error(session, failure); wasmtime_error_delete(failure); }
  if (session->closing && !session->poisoned) lb_record_text(session, "WIT session closed during callback", sizeof("WIT session closed during callback") - 1);
  if (session->poisoned) status = 1;
  for (size_t i = 0; i < 1; ++i) wasmtime_component_val_delete(&args[i]);
  wasmtime_component_val_delete(&reply); lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return status;
}


static uint32_t lb_graph_callback_8(void *data, const callbackcheckedrecords_weighted_t *arg0, callbackcheckedrecords_scalar_nat_t *out) {
  lb_entry *entry = lb_graph_callback_entry(data, 8);
  if (!entry) return 1;
  callbackcheckedrecords_wasmtime *session = entry->session;
  if (session->poisoned || session->closing) return 1;
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(callbackcheckedrecords_scalar_nat_t)) || out->_bridge_owner || out->_bridge_release) return 1;
  if (entry->owned) {
    uint32_t status = callbackcheckedrecords_callback_d885a7d82ec894d17b81e7a67a36bc2930adca13_lease_call(((lb_graph_lease *)entry->owned)->token, arg0, out);
    if (status) { const char *refusal = status == 1 ? callbackcheckedrecords_callable_graph_error() : NULL;
      if (refusal) lb_record_text(session, refusal, strlen(refusal));
      else lb_record_text(session, "Native Lean closure call failed", sizeof("Native Lean closure call failed") - 1); }
    return status;
  }
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  wasmtime_component_val_t args[1] = {{0}}, reply = {0};
  wasmtime_error_t *failure = NULL;
  uint32_t status = 0;
  callbackcheckedrecords_scalar_nat_t converted = {0};
  lb_result *owner = NULL;
  if (!lb_graph_encode_4(arg0, &input, &args[0])) {
    if (!input.memory.failure) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new(input.memory.failure ? "WIT callback input conversion limit or allocation failure" : "Malformed native callback input; runtime retired"); goto done;
  }
  failure = entry->callback(entry->data, args, 1, &reply);
  if (failure || session->poisoned || session->closing) goto done;
  if (!lb_graph_decode_5(&reply, &output, &converted)) { failure = wasmtime_error_new("Invalid WIT callback result, conversion limit or allocation failure"); goto done; }
  if (!lean_bridge_native_component_ready("callbackcheckedrecords@1.0.0")) { failure = wasmtime_error_new("Lean runtime is unavailable"); goto done; }
  if (!lb_charge(&output.memory, 1, sizeof(*owner))) { failure = wasmtime_error_new("WIT callback reply ownership limit"); goto done; }
  owner = calloc(1, sizeof(*owner));
  if (!owner) { failure = wasmtime_error_new("Cannot allocate WIT callback reply owner"); goto done; }
  owner->scope = output.memory; output.memory.allocations = NULL;
  owner->value = reply; reply = (wasmtime_component_val_t){0};
  converted._bridge_owner = owner; converted._bridge_release = lb_result_release;
  *out = converted;
done:
  if (failure) { lb_record_error(session, failure); wasmtime_error_delete(failure); }
  if (session->closing && !session->poisoned) lb_record_text(session, "WIT session closed during callback", sizeof("WIT session closed during callback") - 1);
  if (session->poisoned) status = 1;
  for (size_t i = 0; i < 1; ++i) wasmtime_component_val_delete(&args[i]);
  wasmtime_component_val_delete(&reply); lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return status;
}
static inline void lb_graph_owned_drop_8(void *data) {
  lb_graph_lease *lease = data; callbackcheckedrecords_callback_d885a7d82ec894d17b81e7a67a36bc2930adca13_lease_dispose(lease->token); free(lease);
}

static uint32_t lb_graph_callback_4(void *data, const callbackcheckedrecords_weighted_t *arg0, callbackcheckedrecords_weighted_t *out) {
  lb_entry *entry = lb_graph_callback_entry(data, 4);
  if (!entry) return 1;
  callbackcheckedrecords_wasmtime *session = entry->session;
  if (session->poisoned || session->closing) return 1;
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(callbackcheckedrecords_weighted_t)) || out->_bridge_owner || out->_bridge_release) return 1;
  
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  wasmtime_component_val_t args[1] = {{0}}, reply = {0};
  wasmtime_error_t *failure = NULL;
  uint32_t status = 0;
  callbackcheckedrecords_weighted_t converted = {0};
  lb_result *owner = NULL;
  if (!lb_graph_encode_4(arg0, &input, &args[0])) {
    if (!input.memory.failure) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new(input.memory.failure ? "WIT callback input conversion limit or allocation failure" : "Malformed native callback input; runtime retired"); goto done;
  }
  failure = entry->callback(entry->data, args, 1, &reply);
  if (failure || session->poisoned || session->closing) goto done;
  if (!lb_graph_decode_4(&reply, &output, &converted)) { failure = wasmtime_error_new("Invalid WIT callback result, conversion limit or allocation failure"); goto done; }
  if (!lean_bridge_native_component_ready("callbackcheckedrecords@1.0.0")) { failure = wasmtime_error_new("Lean runtime is unavailable"); goto done; }
  if (!lb_charge(&output.memory, 1, sizeof(*owner))) { failure = wasmtime_error_new("WIT callback reply ownership limit"); goto done; }
  owner = calloc(1, sizeof(*owner));
  if (!owner) { failure = wasmtime_error_new("Cannot allocate WIT callback reply owner"); goto done; }
  owner->scope = output.memory; output.memory.allocations = NULL;
  owner->value = reply; reply = (wasmtime_component_val_t){0};
  converted._bridge_owner = owner; converted._bridge_release = lb_result_release;
  *out = converted;
done:
  if (failure) { lb_record_error(session, failure); wasmtime_error_delete(failure); }
  if (session->closing && !session->poisoned) lb_record_text(session, "WIT session closed during callback", sizeof("WIT session closed during callback") - 1);
  if (session->poisoned) status = 1;
  for (size_t i = 0; i < 1; ++i) wasmtime_component_val_delete(&args[i]);
  wasmtime_component_val_delete(&reply); lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return status;
}


static uint32_t lb_graph_callback_7(void *data, const callbackcheckedrecords_scalar_nat_t *arg0, const callbackcheckedrecords_interval_t *arg1, callbackcheckedrecords_interval_t *out) {
  lb_entry *entry = lb_graph_callback_entry(data, 7);
  if (!entry) return 1;
  callbackcheckedrecords_wasmtime *session = entry->session;
  if (session->poisoned || session->closing) return 1;
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(callbackcheckedrecords_interval_t)) || out->_bridge_owner || out->_bridge_release) return 1;
  if (entry->owned) {
    uint32_t status = callbackcheckedrecords_callback_2e292aebff8c53f6a465ec3d5745e74400590434_lease_call(((lb_graph_lease *)entry->owned)->token, arg0, arg1, out);
    if (status) { const char *refusal = status == 1 ? callbackcheckedrecords_callable_graph_error() : NULL;
      if (refusal) lb_record_text(session, refusal, strlen(refusal));
      else lb_record_text(session, "Native Lean closure call failed", sizeof("Native Lean closure call failed") - 1); }
    return status;
  }
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  wasmtime_component_val_t args[2] = {{0}}, reply = {0};
  wasmtime_error_t *failure = NULL;
  uint32_t status = 0;
  callbackcheckedrecords_interval_t converted = {0};
  lb_result *owner = NULL;
  if (!lb_graph_encode_5(arg0, &input, &args[0])) {
    if (!input.memory.failure) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new(input.memory.failure ? "WIT callback input conversion limit or allocation failure" : "Malformed native callback input; runtime retired"); goto done;
  }
  if (!lb_graph_encode_3(arg1, &input, &args[1])) {
    if (!input.memory.failure) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new(input.memory.failure ? "WIT callback input conversion limit or allocation failure" : "Malformed native callback input; runtime retired"); goto done;
  }
  failure = entry->callback(entry->data, args, 2, &reply);
  if (failure || session->poisoned || session->closing) goto done;
  if (!lb_graph_decode_3(&reply, &output, &converted)) { failure = wasmtime_error_new("Invalid WIT callback result, conversion limit or allocation failure"); goto done; }
  if (!lean_bridge_native_component_ready("callbackcheckedrecords@1.0.0")) { failure = wasmtime_error_new("Lean runtime is unavailable"); goto done; }
  if (!lb_charge(&output.memory, 1, sizeof(*owner))) { failure = wasmtime_error_new("WIT callback reply ownership limit"); goto done; }
  owner = calloc(1, sizeof(*owner));
  if (!owner) { failure = wasmtime_error_new("Cannot allocate WIT callback reply owner"); goto done; }
  owner->scope = output.memory; output.memory.allocations = NULL;
  owner->value = reply; reply = (wasmtime_component_val_t){0};
  converted._bridge_owner = owner; converted._bridge_release = lb_result_release;
  *out = converted;
done:
  if (failure) { lb_record_error(session, failure); wasmtime_error_delete(failure); }
  if (session->closing && !session->poisoned) lb_record_text(session, "WIT session closed during callback", sizeof("WIT session closed during callback") - 1);
  if (session->poisoned) status = 1;
  for (size_t i = 0; i < 2; ++i) wasmtime_component_val_delete(&args[i]);
  wasmtime_component_val_delete(&reply); lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return status;
}
static inline void lb_graph_owned_drop_7(void *data) {
  lb_graph_lease *lease = data; callbackcheckedrecords_callback_2e292aebff8c53f6a465ec3d5745e74400590434_lease_dispose(lease->token); free(lease);
}

static uint32_t lb_graph_callback_6(void *data, const callbackcheckedrecords_graph_7ee21eb6b8ea120b53f0_t *arg0, callbackcheckedrecords_graph_38a8689c2f20ead532ea_t *out) {
  lb_entry *entry = lb_graph_callback_entry(data, 6);
  if (!entry) return 1;
  callbackcheckedrecords_wasmtime *session = entry->session;
  if (session->poisoned || session->closing) return 1;
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(callbackcheckedrecords_graph_38a8689c2f20ead532ea_t)) || out->_bridge_owner || out->_bridge_release) return 1;
  if (entry->owned) {
    uint32_t status = callbackcheckedrecords_callback_8994592329ecba032f0abfaa9703e59a57f3c6a1_lease_call(((lb_graph_lease *)entry->owned)->token, arg0, out);
    if (status) { const char *refusal = status == 1 ? callbackcheckedrecords_callable_graph_error() : NULL;
      if (refusal) lb_record_text(session, refusal, strlen(refusal));
      else lb_record_text(session, "Native Lean closure call failed", sizeof("Native Lean closure call failed") - 1); }
    return status;
  }
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  wasmtime_component_val_t args[1] = {{0}}, reply = {0};
  wasmtime_error_t *failure = NULL;
  uint32_t status = 0;
  callbackcheckedrecords_graph_38a8689c2f20ead532ea_t converted = {0};
  lb_result *owner = NULL;
  if (!lb_graph_encode_1(arg0, &input, &args[0])) {
    if (!input.memory.failure) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new(input.memory.failure ? "WIT callback input conversion limit or allocation failure" : "Malformed native callback input; runtime retired"); goto done;
  }
  failure = entry->callback(entry->data, args, 1, &reply);
  if (failure || session->poisoned || session->closing) goto done;
  if (!lb_graph_decode_0(&reply, &output, &converted)) { failure = wasmtime_error_new("Invalid WIT callback result, conversion limit or allocation failure"); goto done; }
  if (!lean_bridge_native_component_ready("callbackcheckedrecords@1.0.0")) { failure = wasmtime_error_new("Lean runtime is unavailable"); goto done; }
  if (!lb_charge(&output.memory, 1, sizeof(*owner))) { failure = wasmtime_error_new("WIT callback reply ownership limit"); goto done; }
  owner = calloc(1, sizeof(*owner));
  if (!owner) { failure = wasmtime_error_new("Cannot allocate WIT callback reply owner"); goto done; }
  owner->scope = output.memory; output.memory.allocations = NULL;
  owner->value = reply; reply = (wasmtime_component_val_t){0};
  converted._bridge_owner = owner; converted._bridge_release = lb_result_release;
  *out = converted;
done:
  if (failure) { lb_record_error(session, failure); wasmtime_error_delete(failure); }
  if (session->closing && !session->poisoned) lb_record_text(session, "WIT session closed during callback", sizeof("WIT session closed during callback") - 1);
  if (session->poisoned) status = 1;
  for (size_t i = 0; i < 1; ++i) wasmtime_component_val_delete(&args[i]);
  wasmtime_component_val_delete(&reply); lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return status;
}
static inline void lb_graph_owned_drop_6(void *data) {
  lb_graph_lease *lease = data; callbackcheckedrecords_callback_8994592329ecba032f0abfaa9703e59a57f3c6a1_lease_dispose(lease->token); free(lease);
}

static wasmtime_error_t *lb_call_0(void *data, wasmtime_context_t *context,
    const wasmtime_component_func_type_t *type, wasmtime_component_val_t *args, size_t count,
    wasmtime_component_val_t *results, size_t result_count) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  (void)type; (void)context;
  callbackcheckedrecords_wasmtime *session = data;
  if (!session->frame || session->poisoned || session->closing || count != 1 || result_count != 1
      || !lb_buffer(args, count, sizeof(*args), _Alignof(wasmtime_component_val_t))
      || !lb_buffer(results, 1, sizeof(*results), _Alignof(wasmtime_component_val_t))) return wasmtime_error_new("Unavailable WIT graph import or signature mismatch");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  wasmtime_error_t *failure = NULL;
  callbackcheckedrecords_scalar_nat_t value = {0};
  wasmtime_component_val_t converted = {0};
  lb_entry *entry0 = NULL;
  callbackcheckedrecords_callback_00652748bed3eb7036c9091f570efa39888f5490 arg0 = {0};
  failure = lb_borrow(session, context, &args[0], 1, &entry0);
  if (failure) goto done;
  if (!entry0->recovery) { failure = wasmtime_error_new("Missing callback Subtype recovery"); goto done; }
  arg0 = (callbackcheckedrecords_callback_00652748bed3eb7036c9091f570efa39888f5490){.call = lb_graph_callback_1, .context = entry0, .recovery = entry0->recovery};
  uint32_t native_status = lean_bridge_697151f2fc3cf6b95ff12b69_graph(&arg0, &value);
  if (native_status) { failure = wasmtime_error_new(native_status == 10 ? "Host callback result failed its Lean constructor" : "Native Lean graph call failed"); goto done; }
  if (session->poisoned || session->closing) { failure = wasmtime_error_new("WIT callback failed or session closed"); goto done; }
  if (!lb_graph_encode_5(&value, &output, &converted)) {
    if (!output.memory.failure) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new(output.memory.failure ? "WIT graph result conversion limit or allocation failure" : "Malformed native graph result; runtime retired"); goto done;
  }
  if (!lean_bridge_native_component_ready("callbackcheckedrecords@1.0.0")) { failure = wasmtime_error_new("Lean runtime is unavailable"); goto done; }
  results[0] = converted; converted = (wasmtime_component_val_t){0};
done:
  if (failure) lb_record_error(session, failure);
  wasmtime_component_val_delete(&converted);
  callbackcheckedrecords_scalar_nat_t_clear(&value);
  lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}

static wasmtime_error_t *lb_call_1(void *data, wasmtime_context_t *context,
    const wasmtime_component_func_type_t *type, wasmtime_component_val_t *args, size_t count,
    wasmtime_component_val_t *results, size_t result_count) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  (void)type; (void)context;
  callbackcheckedrecords_wasmtime *session = data;
  if (!session->frame || session->poisoned || session->closing || count != 1 || result_count != 1
      || !lb_buffer(args, count, sizeof(*args), _Alignof(wasmtime_component_val_t))
      || !lb_buffer(results, 1, sizeof(*results), _Alignof(wasmtime_component_val_t))) return wasmtime_error_new("Unavailable WIT graph import or signature mismatch");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  wasmtime_error_t *failure = NULL;
  callbackcheckedrecords_scalar_nat_t value = {0};
  wasmtime_component_val_t converted = {0};
  lb_entry *entry0 = NULL;
  callbackcheckedrecords_callback_2663a58c7c0e71654db1d87936875f8677e197b2 arg0 = {0};
  failure = lb_borrow(session, context, &args[0], 2, &entry0);
  if (failure) goto done;
  if (!entry0->recovery) { failure = wasmtime_error_new("Missing callback Subtype recovery"); goto done; }
  arg0 = (callbackcheckedrecords_callback_2663a58c7c0e71654db1d87936875f8677e197b2){.call = lb_graph_callback_2, .context = entry0, .recovery = entry0->recovery};
  uint32_t native_status = lean_bridge_413afe4aaf66162bb3ba3d3c_graph(&arg0, &value);
  if (native_status) { failure = wasmtime_error_new(native_status == 10 ? "Host callback result failed its Lean constructor" : "Native Lean graph call failed"); goto done; }
  if (session->poisoned || session->closing) { failure = wasmtime_error_new("WIT callback failed or session closed"); goto done; }
  if (!lb_graph_encode_5(&value, &output, &converted)) {
    if (!output.memory.failure) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new(output.memory.failure ? "WIT graph result conversion limit or allocation failure" : "Malformed native graph result; runtime retired"); goto done;
  }
  if (!lean_bridge_native_component_ready("callbackcheckedrecords@1.0.0")) { failure = wasmtime_error_new("Lean runtime is unavailable"); goto done; }
  results[0] = converted; converted = (wasmtime_component_val_t){0};
done:
  if (failure) lb_record_error(session, failure);
  wasmtime_component_val_delete(&converted);
  callbackcheckedrecords_scalar_nat_t_clear(&value);
  lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}

static wasmtime_error_t *lb_call_2(void *data, wasmtime_context_t *context,
    const wasmtime_component_func_type_t *type, wasmtime_component_val_t *args, size_t count,
    wasmtime_component_val_t *results, size_t result_count) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  (void)type; (void)context;
  callbackcheckedrecords_wasmtime *session = data;
  if (!session->frame || session->poisoned || session->closing || count != 1 || result_count != 1
      || !lb_buffer(args, count, sizeof(*args), _Alignof(wasmtime_component_val_t))
      || !lb_buffer(results, 1, sizeof(*results), _Alignof(wasmtime_component_val_t))) return wasmtime_error_new("Unavailable WIT graph import or signature mismatch");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  wasmtime_error_t *failure = NULL;
  callbackcheckedrecords_scalar_nat_t value = {0};
  wasmtime_component_val_t converted = {0};
  lb_entry *entry0 = NULL;
  callbackcheckedrecords_callback_526ba4a0f03797057c1f9a17ca435a5a42131510 arg0 = {0};
  failure = lb_borrow(session, context, &args[0], 3, &entry0);
  if (failure) goto done;
  if (!entry0->recovery) { failure = wasmtime_error_new("Missing callback Subtype recovery"); goto done; }
  arg0 = (callbackcheckedrecords_callback_526ba4a0f03797057c1f9a17ca435a5a42131510){.call = lb_graph_callback_3, .context = entry0, .recovery = entry0->recovery};
  uint32_t native_status = lean_bridge_184bfb6b98fb39095f0bfec8_graph(&arg0, &value);
  if (native_status) { failure = wasmtime_error_new(native_status == 10 ? "Host callback result failed its Lean constructor" : "Native Lean graph call failed"); goto done; }
  if (session->poisoned || session->closing) { failure = wasmtime_error_new("WIT callback failed or session closed"); goto done; }
  if (!lb_graph_encode_5(&value, &output, &converted)) {
    if (!output.memory.failure) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new(output.memory.failure ? "WIT graph result conversion limit or allocation failure" : "Malformed native graph result; runtime retired"); goto done;
  }
  if (!lean_bridge_native_component_ready("callbackcheckedrecords@1.0.0")) { failure = wasmtime_error_new("Lean runtime is unavailable"); goto done; }
  results[0] = converted; converted = (wasmtime_component_val_t){0};
done:
  if (failure) lb_record_error(session, failure);
  wasmtime_component_val_delete(&converted);
  callbackcheckedrecords_scalar_nat_t_clear(&value);
  lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}

static wasmtime_error_t *lb_call_3(void *data, wasmtime_context_t *context,
    const wasmtime_component_func_type_t *type, wasmtime_component_val_t *args, size_t count,
    wasmtime_component_val_t *results, size_t result_count) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  (void)type; (void)context;
  callbackcheckedrecords_wasmtime *session = data;
  if (!session->frame || session->poisoned || session->closing || count != 1 || result_count != 1
      || !lb_buffer(args, count, sizeof(*args), _Alignof(wasmtime_component_val_t))
      || !lb_buffer(results, 1, sizeof(*results), _Alignof(wasmtime_component_val_t))) return wasmtime_error_new("Unavailable WIT graph import or signature mismatch");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  wasmtime_error_t *failure = NULL;
  callbackcheckedrecords_scalar_nat_t value = {0};
  wasmtime_component_val_t converted = {0};
  lb_entry *entry0 = NULL;
  callbackcheckedrecords_callback_cd01d463066ae86d043223e65eab1640e16b22ab arg0 = {0};
  failure = lb_borrow(session, context, &args[0], 4, &entry0);
  if (failure) goto done;
  if (!entry0->recovery) { failure = wasmtime_error_new("Missing callback Subtype recovery"); goto done; }
  arg0 = (callbackcheckedrecords_callback_cd01d463066ae86d043223e65eab1640e16b22ab){.call = lb_graph_callback_4, .context = entry0, .recovery = entry0->recovery};
  uint32_t native_status = lean_bridge_f168e18f231fdb7eb1733b0e_graph(&arg0, &value);
  if (native_status) { failure = wasmtime_error_new(native_status == 10 ? "Host callback result failed its Lean constructor" : "Native Lean graph call failed"); goto done; }
  if (session->poisoned || session->closing) { failure = wasmtime_error_new("WIT callback failed or session closed"); goto done; }
  if (!lb_graph_encode_5(&value, &output, &converted)) {
    if (!output.memory.failure) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new(output.memory.failure ? "WIT graph result conversion limit or allocation failure" : "Malformed native graph result; runtime retired"); goto done;
  }
  if (!lean_bridge_native_component_ready("callbackcheckedrecords@1.0.0")) { failure = wasmtime_error_new("Lean runtime is unavailable"); goto done; }
  results[0] = converted; converted = (wasmtime_component_val_t){0};
done:
  if (failure) lb_record_error(session, failure);
  wasmtime_component_val_delete(&converted);
  callbackcheckedrecords_scalar_nat_t_clear(&value);
  lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}

static wasmtime_error_t *lb_call_4(void *data, wasmtime_context_t *context,
    const wasmtime_component_func_type_t *type, wasmtime_component_val_t *args, size_t count,
    wasmtime_component_val_t *results, size_t result_count) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  (void)type; (void)context;
  callbackcheckedrecords_wasmtime *session = data;
  if (!session->frame || session->poisoned || session->closing || count != 1 || result_count != 1
      || !lb_buffer(args, count, sizeof(*args), _Alignof(wasmtime_component_val_t))
      || !lb_buffer(results, 1, sizeof(*results), _Alignof(wasmtime_component_val_t))) return wasmtime_error_new("Unavailable WIT graph import or signature mismatch");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  wasmtime_error_t *failure = NULL;
  uint64_t value = {0};
  wasmtime_component_val_t converted = {0};
  callbackcheckedrecords_scalar_nat_t arg0 = {0};
  if (!lb_graph_decode_5(&args[0], &input, &arg0)) { failure = wasmtime_error_new("Invalid WIT graph input, conversion limit or allocation failure"); goto done; }
  uint32_t native_status = lean_bridge_97d7a19c3e5ee22681017ca9_graph(&arg0, &value);
  if (native_status) { failure = wasmtime_error_new(native_status == 10 ? "Host callback result failed its Lean constructor" : "Native Lean graph call failed"); goto done; }
  if (session->poisoned || session->closing) { failure = wasmtime_error_new("WIT callback failed or session closed"); goto done; }
  if (!value) { lean_bridge_native_runtime_retire(); failure = wasmtime_error_new("Missing native closure identity; runtime retired"); goto done; }
  session->frame->pending = lb_entry_new(session, 5);
  if (!session->frame->pending) { failure = wasmtime_error_new("WIT callable capacity exhausted"); goto done; }
  lb_graph_lease *lease = malloc(sizeof(*lease));
  if (!lease) { failure = wasmtime_error_new("Cannot allocate WIT closure identity owner"); goto done; }
  lease->token = value; value = 0;
  session->frame->pending->owned = lease; session->frame->pending->release = lb_graph_owned_drop_5;
  failure = lb_proxy(session, context, session->frame->pending, &converted);
  if (failure) goto done;
  if (!lean_bridge_native_component_ready("callbackcheckedrecords@1.0.0")) { failure = wasmtime_error_new("Lean runtime is unavailable"); goto done; }
  results[0] = converted; converted = (wasmtime_component_val_t){0};
done:
  if (failure) lb_record_error(session, failure);
  wasmtime_component_val_delete(&converted);
  if (value) callbackcheckedrecords_callback_e014092ff0a1ee8527eeeb58a78e2de63bdf09fa_lease_dispose(value);
  lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}

static wasmtime_error_t *lb_call_5(void *data, wasmtime_context_t *context,
    const wasmtime_component_func_type_t *type, wasmtime_component_val_t *args, size_t count,
    wasmtime_component_val_t *results, size_t result_count) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  (void)type; (void)context;
  callbackcheckedrecords_wasmtime *session = data;
  if (!session->frame || session->poisoned || session->closing || count != 1 || result_count != 1
      || !lb_buffer(args, count, sizeof(*args), _Alignof(wasmtime_component_val_t))
      || !lb_buffer(results, 1, sizeof(*results), _Alignof(wasmtime_component_val_t))) return wasmtime_error_new("Unavailable WIT graph import or signature mismatch");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  wasmtime_error_t *failure = NULL;
  uint64_t value = {0};
  wasmtime_component_val_t converted = {0};
  callbackcheckedrecords_scalar_nat_t arg0 = {0};
  if (!lb_graph_decode_5(&args[0], &input, &arg0)) { failure = wasmtime_error_new("Invalid WIT graph input, conversion limit or allocation failure"); goto done; }
  uint32_t native_status = lean_bridge_74ed57fc03e7ed555389a3ab_graph(&arg0, &value);
  if (native_status) { failure = wasmtime_error_new(native_status == 10 ? "Host callback result failed its Lean constructor" : "Native Lean graph call failed"); goto done; }
  if (session->poisoned || session->closing) { failure = wasmtime_error_new("WIT callback failed or session closed"); goto done; }
  if (!value) { lean_bridge_native_runtime_retire(); failure = wasmtime_error_new("Missing native closure identity; runtime retired"); goto done; }
  session->frame->pending = lb_entry_new(session, 6);
  if (!session->frame->pending) { failure = wasmtime_error_new("WIT callable capacity exhausted"); goto done; }
  lb_graph_lease *lease = malloc(sizeof(*lease));
  if (!lease) { failure = wasmtime_error_new("Cannot allocate WIT closure identity owner"); goto done; }
  lease->token = value; value = 0;
  session->frame->pending->owned = lease; session->frame->pending->release = lb_graph_owned_drop_6;
  failure = lb_proxy(session, context, session->frame->pending, &converted);
  if (failure) goto done;
  if (!lean_bridge_native_component_ready("callbackcheckedrecords@1.0.0")) { failure = wasmtime_error_new("Lean runtime is unavailable"); goto done; }
  results[0] = converted; converted = (wasmtime_component_val_t){0};
done:
  if (failure) lb_record_error(session, failure);
  wasmtime_component_val_delete(&converted);
  if (value) callbackcheckedrecords_callback_8994592329ecba032f0abfaa9703e59a57f3c6a1_lease_dispose(value);
  lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}

static wasmtime_error_t *lb_call_6(void *data, wasmtime_context_t *context,
    const wasmtime_component_func_type_t *type, wasmtime_component_val_t *args, size_t count,
    wasmtime_component_val_t *results, size_t result_count) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  (void)type; (void)context;
  callbackcheckedrecords_wasmtime *session = data;
  if (!session->frame || session->poisoned || session->closing || count != 1 || result_count != 1
      || !lb_buffer(args, count, sizeof(*args), _Alignof(wasmtime_component_val_t))
      || !lb_buffer(results, 1, sizeof(*results), _Alignof(wasmtime_component_val_t))) return wasmtime_error_new("Unavailable WIT graph import or signature mismatch");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  wasmtime_error_t *failure = NULL;
  uint64_t value = {0};
  wasmtime_component_val_t converted = {0};
  callbackcheckedrecords_scalar_nat_t arg0 = {0};
  if (!lb_graph_decode_5(&args[0], &input, &arg0)) { failure = wasmtime_error_new("Invalid WIT graph input, conversion limit or allocation failure"); goto done; }
  uint32_t native_status = lean_bridge_bbabc0c3fa2252f4f7a67708_graph(&arg0, &value);
  if (native_status) { failure = wasmtime_error_new(native_status == 10 ? "Host callback result failed its Lean constructor" : "Native Lean graph call failed"); goto done; }
  if (session->poisoned || session->closing) { failure = wasmtime_error_new("WIT callback failed or session closed"); goto done; }
  if (!value) { lean_bridge_native_runtime_retire(); failure = wasmtime_error_new("Missing native closure identity; runtime retired"); goto done; }
  session->frame->pending = lb_entry_new(session, 7);
  if (!session->frame->pending) { failure = wasmtime_error_new("WIT callable capacity exhausted"); goto done; }
  lb_graph_lease *lease = malloc(sizeof(*lease));
  if (!lease) { failure = wasmtime_error_new("Cannot allocate WIT closure identity owner"); goto done; }
  lease->token = value; value = 0;
  session->frame->pending->owned = lease; session->frame->pending->release = lb_graph_owned_drop_7;
  failure = lb_proxy(session, context, session->frame->pending, &converted);
  if (failure) goto done;
  if (!lean_bridge_native_component_ready("callbackcheckedrecords@1.0.0")) { failure = wasmtime_error_new("Lean runtime is unavailable"); goto done; }
  results[0] = converted; converted = (wasmtime_component_val_t){0};
done:
  if (failure) lb_record_error(session, failure);
  wasmtime_component_val_delete(&converted);
  if (value) callbackcheckedrecords_callback_2e292aebff8c53f6a465ec3d5745e74400590434_lease_dispose(value);
  lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}

static wasmtime_error_t *lb_call_7(void *data, wasmtime_context_t *context,
    const wasmtime_component_func_type_t *type, wasmtime_component_val_t *args, size_t count,
    wasmtime_component_val_t *results, size_t result_count) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  (void)type; (void)context;
  callbackcheckedrecords_wasmtime *session = data;
  if (!session->frame || session->poisoned || session->closing || count != 1 || result_count != 1
      || !lb_buffer(args, count, sizeof(*args), _Alignof(wasmtime_component_val_t))
      || !lb_buffer(results, 1, sizeof(*results), _Alignof(wasmtime_component_val_t))) return wasmtime_error_new("Unavailable WIT graph import or signature mismatch");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  wasmtime_error_t *failure = NULL;
  uint64_t value = {0};
  wasmtime_component_val_t converted = {0};
  callbackcheckedrecords_scalar_nat_t arg0 = {0};
  if (!lb_graph_decode_5(&args[0], &input, &arg0)) { failure = wasmtime_error_new("Invalid WIT graph input, conversion limit or allocation failure"); goto done; }
  uint32_t native_status = lean_bridge_77496697d09177e0d1ebadfd_graph(&arg0, &value);
  if (native_status) { failure = wasmtime_error_new(native_status == 10 ? "Host callback result failed its Lean constructor" : "Native Lean graph call failed"); goto done; }
  if (session->poisoned || session->closing) { failure = wasmtime_error_new("WIT callback failed or session closed"); goto done; }
  if (!value) { lean_bridge_native_runtime_retire(); failure = wasmtime_error_new("Missing native closure identity; runtime retired"); goto done; }
  session->frame->pending = lb_entry_new(session, 8);
  if (!session->frame->pending) { failure = wasmtime_error_new("WIT callable capacity exhausted"); goto done; }
  lb_graph_lease *lease = malloc(sizeof(*lease));
  if (!lease) { failure = wasmtime_error_new("Cannot allocate WIT closure identity owner"); goto done; }
  lease->token = value; value = 0;
  session->frame->pending->owned = lease; session->frame->pending->release = lb_graph_owned_drop_8;
  failure = lb_proxy(session, context, session->frame->pending, &converted);
  if (failure) goto done;
  if (!lean_bridge_native_component_ready("callbackcheckedrecords@1.0.0")) { failure = wasmtime_error_new("Lean runtime is unavailable"); goto done; }
  results[0] = converted; converted = (wasmtime_component_val_t){0};
done:
  if (failure) lb_record_error(session, failure);
  wasmtime_component_val_delete(&converted);
  if (value) callbackcheckedrecords_callback_d885a7d82ec894d17b81e7a67a36bc2930adca13_lease_dispose(value);
  lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}

static wasmtime_error_t *lb_call_8(void *data, wasmtime_context_t *context,
    const wasmtime_component_func_type_t *type, wasmtime_component_val_t *args, size_t count,
    wasmtime_component_val_t *results, size_t result_count) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  (void)type; (void)context;
  callbackcheckedrecords_wasmtime *session = data;
  if (!session->frame || session->poisoned || session->closing || count != 2 || result_count != 1
      || !lb_buffer(args, count, sizeof(*args), _Alignof(wasmtime_component_val_t))
      || !lb_buffer(results, 1, sizeof(*results), _Alignof(wasmtime_component_val_t))) return wasmtime_error_new("Unavailable WIT graph import or signature mismatch");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  wasmtime_error_t *failure = NULL;
  callbackcheckedrecords_interval_t value = {0};
  wasmtime_component_val_t converted = {0};
  lb_entry *entry0 = NULL;
  callbackcheckedrecords_interval_t arg1 = {0};
  failure = lb_borrow(session, context, &args[0], 1, &entry0);
  if (failure) goto done;

  if (!lb_graph_decode_3(&args[1], &input, &arg1)) { failure = wasmtime_error_new("Invalid WIT graph input, conversion limit or allocation failure"); goto done; }
  uint32_t native_status = lb_graph_callback_1(entry0, &arg1, &value);
  if (native_status) { failure = wasmtime_error_new("WIT callback failed"); goto done; }
  if (session->poisoned || session->closing) { failure = wasmtime_error_new("WIT callback failed or session closed"); goto done; }
  if (!lb_graph_encode_3(&value, &output, &converted)) {
    if (!output.memory.failure) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new(output.memory.failure ? "WIT graph result conversion limit or allocation failure" : "Malformed native graph result; runtime retired"); goto done;
  }
  if (!lean_bridge_native_component_ready("callbackcheckedrecords@1.0.0")) { failure = wasmtime_error_new("Lean runtime is unavailable"); goto done; }
  results[0] = converted; converted = (wasmtime_component_val_t){0};
done:
  if (failure) lb_record_error(session, failure);
  wasmtime_component_val_delete(&converted);
  callbackcheckedrecords_interval_t_clear(&value);
  lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}

static wasmtime_error_t *lb_call_9(void *data, wasmtime_context_t *context,
    const wasmtime_component_func_type_t *type, wasmtime_component_val_t *args, size_t count,
    wasmtime_component_val_t *results, size_t result_count) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  (void)type; (void)context;
  callbackcheckedrecords_wasmtime *session = data;
  if (!session->frame || session->poisoned || session->closing || count != 2 || result_count != 1
      || !lb_buffer(args, count, sizeof(*args), _Alignof(wasmtime_component_val_t))
      || !lb_buffer(results, 1, sizeof(*results), _Alignof(wasmtime_component_val_t))) return wasmtime_error_new("Unavailable WIT graph import or signature mismatch");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  wasmtime_error_t *failure = NULL;
  callbackcheckedrecords_graph_29468227bdfd05da1480_t value = {0};
  wasmtime_component_val_t converted = {0};
  lb_entry *entry0 = NULL;
  callbackcheckedrecords_graph_38a8689c2f20ead532ea_t arg1 = {0};
  failure = lb_borrow(session, context, &args[0], 2, &entry0);
  if (failure) goto done;

  if (!lb_graph_decode_0(&args[1], &input, &arg1)) { failure = wasmtime_error_new("Invalid WIT graph input, conversion limit or allocation failure"); goto done; }
  uint32_t native_status = lb_graph_callback_2(entry0, &arg1, &value);
  if (native_status) { failure = wasmtime_error_new("WIT callback failed"); goto done; }
  if (session->poisoned || session->closing) { failure = wasmtime_error_new("WIT callback failed or session closed"); goto done; }
  if (!lb_graph_encode_2(&value, &output, &converted)) {
    if (!output.memory.failure) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new(output.memory.failure ? "WIT graph result conversion limit or allocation failure" : "Malformed native graph result; runtime retired"); goto done;
  }
  if (!lean_bridge_native_component_ready("callbackcheckedrecords@1.0.0")) { failure = wasmtime_error_new("Lean runtime is unavailable"); goto done; }
  results[0] = converted; converted = (wasmtime_component_val_t){0};
done:
  if (failure) lb_record_error(session, failure);
  wasmtime_component_val_delete(&converted);
  callbackcheckedrecords_graph_29468227bdfd05da1480_t_clear(&value);
  lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}

static wasmtime_error_t *lb_call_10(void *data, wasmtime_context_t *context,
    const wasmtime_component_func_type_t *type, wasmtime_component_val_t *args, size_t count,
    wasmtime_component_val_t *results, size_t result_count) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  (void)type; (void)context;
  callbackcheckedrecords_wasmtime *session = data;
  if (!session->frame || session->poisoned || session->closing || count != 3 || result_count != 1
      || !lb_buffer(args, count, sizeof(*args), _Alignof(wasmtime_component_val_t))
      || !lb_buffer(results, 1, sizeof(*results), _Alignof(wasmtime_component_val_t))) return wasmtime_error_new("Unavailable WIT graph import or signature mismatch");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  wasmtime_error_t *failure = NULL;
  callbackcheckedrecords_interval_t value = {0};
  wasmtime_component_val_t converted = {0};
  lb_entry *entry0 = NULL;
  callbackcheckedrecords_scalar_nat_t arg1 = {0};
  callbackcheckedrecords_interval_t arg2 = {0};
  failure = lb_borrow(session, context, &args[0], 3, &entry0);
  if (failure) goto done;

  if (!lb_graph_decode_5(&args[1], &input, &arg1)) { failure = wasmtime_error_new("Invalid WIT graph input, conversion limit or allocation failure"); goto done; }
  if (!lb_graph_decode_3(&args[2], &input, &arg2)) { failure = wasmtime_error_new("Invalid WIT graph input, conversion limit or allocation failure"); goto done; }
  uint32_t native_status = lb_graph_callback_3(entry0, &arg1, &arg2, &value);
  if (native_status) { failure = wasmtime_error_new("WIT callback failed"); goto done; }
  if (session->poisoned || session->closing) { failure = wasmtime_error_new("WIT callback failed or session closed"); goto done; }
  if (!lb_graph_encode_3(&value, &output, &converted)) {
    if (!output.memory.failure) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new(output.memory.failure ? "WIT graph result conversion limit or allocation failure" : "Malformed native graph result; runtime retired"); goto done;
  }
  if (!lean_bridge_native_component_ready("callbackcheckedrecords@1.0.0")) { failure = wasmtime_error_new("Lean runtime is unavailable"); goto done; }
  results[0] = converted; converted = (wasmtime_component_val_t){0};
done:
  if (failure) lb_record_error(session, failure);
  wasmtime_component_val_delete(&converted);
  callbackcheckedrecords_interval_t_clear(&value);
  lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}

static wasmtime_error_t *lb_call_11(void *data, wasmtime_context_t *context,
    const wasmtime_component_func_type_t *type, wasmtime_component_val_t *args, size_t count,
    wasmtime_component_val_t *results, size_t result_count) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  (void)type; (void)context;
  callbackcheckedrecords_wasmtime *session = data;
  if (!session->frame || session->poisoned || session->closing || count != 2 || result_count != 1
      || !lb_buffer(args, count, sizeof(*args), _Alignof(wasmtime_component_val_t))
      || !lb_buffer(results, 1, sizeof(*results), _Alignof(wasmtime_component_val_t))) return wasmtime_error_new("Unavailable WIT graph import or signature mismatch");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  wasmtime_error_t *failure = NULL;
  callbackcheckedrecords_weighted_t value = {0};
  wasmtime_component_val_t converted = {0};
  lb_entry *entry0 = NULL;
  callbackcheckedrecords_weighted_t arg1 = {0};
  failure = lb_borrow(session, context, &args[0], 4, &entry0);
  if (failure) goto done;

  if (!lb_graph_decode_4(&args[1], &input, &arg1)) { failure = wasmtime_error_new("Invalid WIT graph input, conversion limit or allocation failure"); goto done; }
  uint32_t native_status = lb_graph_callback_4(entry0, &arg1, &value);
  if (native_status) { failure = wasmtime_error_new("WIT callback failed"); goto done; }
  if (session->poisoned || session->closing) { failure = wasmtime_error_new("WIT callback failed or session closed"); goto done; }
  if (!lb_graph_encode_4(&value, &output, &converted)) {
    if (!output.memory.failure) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new(output.memory.failure ? "WIT graph result conversion limit or allocation failure" : "Malformed native graph result; runtime retired"); goto done;
  }
  if (!lean_bridge_native_component_ready("callbackcheckedrecords@1.0.0")) { failure = wasmtime_error_new("Lean runtime is unavailable"); goto done; }
  results[0] = converted; converted = (wasmtime_component_val_t){0};
done:
  if (failure) lb_record_error(session, failure);
  wasmtime_component_val_delete(&converted);
  callbackcheckedrecords_weighted_t_clear(&value);
  lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}

static wasmtime_error_t *lb_call_12(void *data, wasmtime_context_t *context,
    const wasmtime_component_func_type_t *type, wasmtime_component_val_t *args, size_t count,
    wasmtime_component_val_t *results, size_t result_count) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  (void)type; (void)context;
  callbackcheckedrecords_wasmtime *session = data;
  if (!session->frame || session->poisoned || session->closing || count != 2 || result_count != 1
      || !lb_buffer(args, count, sizeof(*args), _Alignof(wasmtime_component_val_t))
      || !lb_buffer(results, 1, sizeof(*results), _Alignof(wasmtime_component_val_t))) return wasmtime_error_new("Unavailable WIT graph import or signature mismatch");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  wasmtime_error_t *failure = NULL;
  callbackcheckedrecords_scalar_nat_t value = {0};
  wasmtime_component_val_t converted = {0};
  lb_entry *entry0 = NULL;
  callbackcheckedrecords_interval_t arg1 = {0};
  failure = lb_borrow(session, context, &args[0], 5, &entry0);
  if (failure) goto done;

  if (!lb_graph_decode_3(&args[1], &input, &arg1)) { failure = wasmtime_error_new("Invalid WIT graph input, conversion limit or allocation failure"); goto done; }
  uint32_t native_status = lb_graph_callback_5(entry0, &arg1, &value);
  if (native_status) { failure = wasmtime_error_new("WIT callback failed"); goto done; }
  if (session->poisoned || session->closing) { failure = wasmtime_error_new("WIT callback failed or session closed"); goto done; }
  if (!lb_graph_encode_5(&value, &output, &converted)) {
    if (!output.memory.failure) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new(output.memory.failure ? "WIT graph result conversion limit or allocation failure" : "Malformed native graph result; runtime retired"); goto done;
  }
  if (!lean_bridge_native_component_ready("callbackcheckedrecords@1.0.0")) { failure = wasmtime_error_new("Lean runtime is unavailable"); goto done; }
  results[0] = converted; converted = (wasmtime_component_val_t){0};
done:
  if (failure) lb_record_error(session, failure);
  wasmtime_component_val_delete(&converted);
  callbackcheckedrecords_scalar_nat_t_clear(&value);
  lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}

static wasmtime_error_t *lb_call_13(void *data, wasmtime_context_t *context,
    const wasmtime_component_func_type_t *type, wasmtime_component_val_t *args, size_t count,
    wasmtime_component_val_t *results, size_t result_count) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  (void)type; (void)context;
  callbackcheckedrecords_wasmtime *session = data;
  if (!session->frame || session->poisoned || session->closing || count != 2 || result_count != 1
      || !lb_buffer(args, count, sizeof(*args), _Alignof(wasmtime_component_val_t))
      || !lb_buffer(results, 1, sizeof(*results), _Alignof(wasmtime_component_val_t))) return wasmtime_error_new("Unavailable WIT graph import or signature mismatch");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  wasmtime_error_t *failure = NULL;
  callbackcheckedrecords_graph_38a8689c2f20ead532ea_t value = {0};
  wasmtime_component_val_t converted = {0};
  lb_entry *entry0 = NULL;
  callbackcheckedrecords_graph_7ee21eb6b8ea120b53f0_t arg1 = {0};
  failure = lb_borrow(session, context, &args[0], 6, &entry0);
  if (failure) goto done;

  if (!lb_graph_decode_1(&args[1], &input, &arg1)) { failure = wasmtime_error_new("Invalid WIT graph input, conversion limit or allocation failure"); goto done; }
  uint32_t native_status = lb_graph_callback_6(entry0, &arg1, &value);
  if (native_status) { failure = wasmtime_error_new("WIT callback failed"); goto done; }
  if (session->poisoned || session->closing) { failure = wasmtime_error_new("WIT callback failed or session closed"); goto done; }
  if (!lb_graph_encode_0(&value, &output, &converted)) {
    if (!output.memory.failure) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new(output.memory.failure ? "WIT graph result conversion limit or allocation failure" : "Malformed native graph result; runtime retired"); goto done;
  }
  if (!lean_bridge_native_component_ready("callbackcheckedrecords@1.0.0")) { failure = wasmtime_error_new("Lean runtime is unavailable"); goto done; }
  results[0] = converted; converted = (wasmtime_component_val_t){0};
done:
  if (failure) lb_record_error(session, failure);
  wasmtime_component_val_delete(&converted);
  callbackcheckedrecords_graph_38a8689c2f20ead532ea_t_clear(&value);
  lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}

static wasmtime_error_t *lb_call_14(void *data, wasmtime_context_t *context,
    const wasmtime_component_func_type_t *type, wasmtime_component_val_t *args, size_t count,
    wasmtime_component_val_t *results, size_t result_count) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  (void)type; (void)context;
  callbackcheckedrecords_wasmtime *session = data;
  if (!session->frame || session->poisoned || session->closing || count != 3 || result_count != 1
      || !lb_buffer(args, count, sizeof(*args), _Alignof(wasmtime_component_val_t))
      || !lb_buffer(results, 1, sizeof(*results), _Alignof(wasmtime_component_val_t))) return wasmtime_error_new("Unavailable WIT graph import or signature mismatch");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  wasmtime_error_t *failure = NULL;
  callbackcheckedrecords_interval_t value = {0};
  wasmtime_component_val_t converted = {0};
  lb_entry *entry0 = NULL;
  callbackcheckedrecords_scalar_nat_t arg1 = {0};
  callbackcheckedrecords_interval_t arg2 = {0};
  failure = lb_borrow(session, context, &args[0], 7, &entry0);
  if (failure) goto done;

  if (!lb_graph_decode_5(&args[1], &input, &arg1)) { failure = wasmtime_error_new("Invalid WIT graph input, conversion limit or allocation failure"); goto done; }
  if (!lb_graph_decode_3(&args[2], &input, &arg2)) { failure = wasmtime_error_new("Invalid WIT graph input, conversion limit or allocation failure"); goto done; }
  uint32_t native_status = lb_graph_callback_7(entry0, &arg1, &arg2, &value);
  if (native_status) { failure = wasmtime_error_new("WIT callback failed"); goto done; }
  if (session->poisoned || session->closing) { failure = wasmtime_error_new("WIT callback failed or session closed"); goto done; }
  if (!lb_graph_encode_3(&value, &output, &converted)) {
    if (!output.memory.failure) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new(output.memory.failure ? "WIT graph result conversion limit or allocation failure" : "Malformed native graph result; runtime retired"); goto done;
  }
  if (!lean_bridge_native_component_ready("callbackcheckedrecords@1.0.0")) { failure = wasmtime_error_new("Lean runtime is unavailable"); goto done; }
  results[0] = converted; converted = (wasmtime_component_val_t){0};
done:
  if (failure) lb_record_error(session, failure);
  wasmtime_component_val_delete(&converted);
  callbackcheckedrecords_interval_t_clear(&value);
  lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}

static wasmtime_error_t *lb_call_15(void *data, wasmtime_context_t *context,
    const wasmtime_component_func_type_t *type, wasmtime_component_val_t *args, size_t count,
    wasmtime_component_val_t *results, size_t result_count) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  (void)type; (void)context;
  callbackcheckedrecords_wasmtime *session = data;
  if (!session->frame || session->poisoned || session->closing || count != 2 || result_count != 1
      || !lb_buffer(args, count, sizeof(*args), _Alignof(wasmtime_component_val_t))
      || !lb_buffer(results, 1, sizeof(*results), _Alignof(wasmtime_component_val_t))) return wasmtime_error_new("Unavailable WIT graph import or signature mismatch");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  wasmtime_error_t *failure = NULL;
  callbackcheckedrecords_scalar_nat_t value = {0};
  wasmtime_component_val_t converted = {0};
  lb_entry *entry0 = NULL;
  callbackcheckedrecords_weighted_t arg1 = {0};
  failure = lb_borrow(session, context, &args[0], 8, &entry0);
  if (failure) goto done;

  if (!lb_graph_decode_4(&args[1], &input, &arg1)) { failure = wasmtime_error_new("Invalid WIT graph input, conversion limit or allocation failure"); goto done; }
  uint32_t native_status = lb_graph_callback_8(entry0, &arg1, &value);
  if (native_status) { failure = wasmtime_error_new("WIT callback failed"); goto done; }
  if (session->poisoned || session->closing) { failure = wasmtime_error_new("WIT callback failed or session closed"); goto done; }
  if (!lb_graph_encode_5(&value, &output, &converted)) {
    if (!output.memory.failure) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new(output.memory.failure ? "WIT graph result conversion limit or allocation failure" : "Malformed native graph result; runtime retired"); goto done;
  }
  if (!lean_bridge_native_component_ready("callbackcheckedrecords@1.0.0")) { failure = wasmtime_error_new("Lean runtime is unavailable"); goto done; }
  results[0] = converted; converted = (wasmtime_component_val_t){0};
done:
  if (failure) lb_record_error(session, failure);
  wasmtime_component_val_delete(&converted);
  callbackcheckedrecords_scalar_nat_t_clear(&value);
  lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}

static const uint8_t lb_component[] = {0,97,115,109,13,0,1,0,7,195,15,1,66,112,1,112,121,1,114,1,5,105,110,100,101,120,121,4,0,13,108,98,45,103,114,97,112,104,45,114,101,102,51,3,0,1,1,107,2,4,0,14,98,114,105,100,103,101,45,118,97,108,117,101,45,50,3,0,3,1,112,4,4,0,14,98,114,105,100,103,101,45,118,97,108,117,101,45,51,3,0,5,1,114,1,5,105,110,100,101,120,121,4,0,13,108,98,45,103,114,97,112,104,45,114,101,102,48,3,0,7,1,112,8,4,0,14,98,114,105,100,103,101,45,118,97,108,117,101,45,53,3,0,9,1,112,10,4,0,14,98,114,105,100,103,101,45,118,97,108,117,101,45,54,3,0,11,1,106,1,8,1,115,4,0,14,98,114,105,100,103,101,45,118,97,108,117,101,45,56,3,0,13,1,112,14,4,0,14,98,114,105,100,103,101,45,118,97,108,117,101,45,57,3,0,15,1,112,121,4,0,15,98,114,105,100,103,101,45,118,97,108,117,101,45,49,48,3,0,17,1,114,2,2,108,111,18,2,104,105,18,4,0,14,108,98,45,103,114,97,112,104,45,110,111,100,101,51,3,0,19,1,112,20,4,0,15,98,114,105,100,103,101,45,118,97,108,117,101,45,49,50,3,0,21,1,114,2,6,119,101,105,103,104,116,18,5,108,105,109,105,116,18,4,0,14,108,98,45,103,114,97,112,104,45,110,111,100,101,52,3,0,23,1,112,24,4,0,15,98,114,105,100,103,101,45,118,97,108,117,101,45,49,52,3,0,25,4,0,14,108,98,45,103,114,97,112,104,45,110,111,100,101,48,3,0,4,1,112,27,4,0,21,98,114,105,100,103,101,45,97,108,105,97,115,45,118,97,108,117,101,45,50,53,3,0,28,4,0,14,108,98,45,103,114,97,112,104,45,110,111,100,101,49,3,0,10,1,112,30,4,0,21,98,114,105,100,103,101,45,97,108,105,97,115,45,118,97,108,117,101,45,50,55,3,0,31,4,0,14,108,98,45,103,114,97,112,104,45,110,111,100,101,50,3,0,14,1,112,33,4,0,21,98,114,105,100,103,101,45,97,108,105,97,115,45,118,97,108,117,101,45,50,57,3,0,34,1,114,5,6,110,111,100,101,115,48,29,6,110,111,100,101,115,49,32,6,110,111,100,101,115,50,35,6,110,111,100,101,115,51,22,6,110,111,100,101,115,52,26,4,0,14,108,98,45,103,114,97,112,104,45,97,114,101,110,97,3,0,36,1,114,2,4,114,111,111,116,2,5,110,111,100,101,115,37,4,0,15,108,98,45,103,114,97,112,104,45,118,97,108,117,101,51,3,0,38,1,114,2,4,114,111,111,116,8,5,110,111,100,101,115,37,4,0,15,108,98,45,103,114,97,112,104,45,118,97,108,117,101,48,3,0,40,1,114,1,5,105,110,100,101,120,121,4,0,13,108,98,45,103,114,97,112,104,45,114,101,102,50,3,0,42,1,114,2,4,114,111,111,116,43,5,110,111,100,101,115,37,4,0,15,108,98,45,103,114,97,112,104,45,118,97,108,117,101,50,3,0,44,1,114,1,5,105,110,100,101,120,121,4,0,13,108,98,45,103,114,97,112,104,45,114,101,102,52,3,0,46,1,114,2,4,114,111,111,116,47,5,110,111,100,101,115,37,4,0,15,108,98,45,103,114,97,112,104,45,118,97,108,117,101,52,3,0,48,1,114,1,5,105,110,100,101,120,121,4,0,13,108,98,45,103,114,97,112,104,45,114,101,102,49,3,0,50,1,114,2,4,114,111,111,116,51,5,110,111,100,101,115,37,4,0,15,108,98,45,103,114,97,112,104,45,118,97,108,117,101,49,3,0,52,4,0,8,105,110,116,101,114,118,97,108,3,0,39,4,0,8,119,101,105,103,104,116,101,100,3,0,49,4,0,33,102,117,110,99,116,105,111,110,45,52,57,57,99,56,55,57,97,51,100,52,53,48,102,54,54,48,52,55,102,99,101,101,51,3,1,1,104,56,1,105,56,4,0,33,102,117,110,99,116,105,111,110,45,49,52,99,99,97,98,102,50,53,101,97,49,55,49,57,101,98,55,48,57,100,48,55,53,3,1,1,104,59,1,105,59,4,0,33,102,117,110,99,116,105,111,110,45,98,101,53,99,54,52,48,48,49,56,55,52,50,50,55,100,56,56,100,48,98,53,52,99,3,1,1,104,62,1,105,62,4,0,33,102,117,110,99,116,105,111,110,45,57,97,99,49,101,54,48,99,55,55,102,98,54,102,101,56,97,55,54,49,55,100,51,97,3,1,1,104,65,1,105,65,4,0,33,102,117,110,99,116,105,111,110,45,48,99,102,100,56,98,55,54,100,100,57,55,100,52,55,48,48,52,97,56,53,50,98,48,3,1,1,104,68,1,105,68,4,0,33,102,117,110,99,116,105,111,110,45,101,56,48,48,52,100,50,56,54,50,49,102,57,98,53,53,51,102,52,99,56,51,97,54,3,1,1,104,71,1,105,71,4,0,33,102,117,110,99,116,105,111,110,45,52,99,102,56,51,97,56,51,100,51,57,48,97,99,98,99,54,52,99,48,97,99,50,51,3,1,1,104,74,1,105,74,4,0,33,102,117,110,99,116,105,111,110,45,51,101,54,49,56,51,54,99,52,102,102,49,56,55,55,55,57,52,102,53,98,52,50,101,3,1,1,104,77,1,105,77,1,64,1,4,97,114,103,48,57,0,18,4,0,9,99,97,108,108,45,104,111,115,116,1,80,1,64,1,4,97,114,103,48,60,0,18,4,0,19,99,97,108,108,45,104,111,115,116,45,99,111,110,116,97,105,110,101,114,1,81,1,64,1,4,97,114,103,48,63,0,18,4,0,15,99,97,108,108,45,104,111,115,116,45,109,105,120,101,100,1,82,1,64,1,4,97,114,103,48,194,0,0,18,4,0,16,99,97,108,108,45,104,111,115,116,45,110,101,115,116,101,100,1,83,1,64,1,4,97,114,103,48,18,0,198,0,4,0,12,109,97,107,101,45,99,108,111,115,117,114,101,1,84,1,64,1,4,97,114,103,48,18,0,201,0,4,0,22,109,97,107,101,45,99,111,110,116,97,105,110,101,114,45,99,108,111,115,117,114,101,1,85,1,64,1,4,97,114,103,48,18,0,204,0,4,0,18,109,97,107,101,45,109,105,120,101,100,45,99,108,111,115,117,114,101,1,86,1,64,1,4,97,114,103,48,18,0,207,0,4,0,19,109,97,107,101,45,110,101,115,116,101,100,45,99,108,111,115,117,114,101,1,87,1,64,2,4,115,101,108,102,57,4,97,114,103,48,54,0,54,4,0,40,105,110,118,111,107,101,45,102,117,110,99,116,105,111,110,45,52,57,57,99,56,55,57,97,51,100,52,53,48,102,54,54,48,52,55,102,99,101,101,51,1,88,1,64,2,4,115,101,108,102,60,4,97,114,103,48,41,0,45,4,0,40,105,110,118,111,107,101,45,102,117,110,99,116,105,111,110,45,49,52,99,99,97,98,102,50,53,101,97,49,55,49,57,101,98,55,48,57,100,48,55,53,1,89,1,64,3,4,115,101,108,102,63,4,97,114,103,48,18,4,97,114,103,49,54,0,54,4,0,40,105,110,118,111,107,101,45,102,117,110,99,116,105,111,110,45,98,101,53,99,54,52,48,48,49,56,55,52,50,50,55,100,56,56,100,48,98,53,52,99,1,90,1,64,2,4,115,101,108,102,194,0,4,97,114,103,48,55,0,55,4,0,40,105,110,118,111,107,101,45,102,117,110,99,116,105,111,110,45,57,97,99,49,101,54,48,99,55,55,102,98,54,102,101,56,97,55,54,49,55,100,51,97,1,91,1,64,2,4,115,101,108,102,197,0,4,97,114,103,48,54,0,18,4,0,40,105,110,118,111,107,101,45,102,117,110,99,116,105,111,110,45,48,99,102,100,56,98,55,54,100,100,57,55,100,52,55,48,48,52,97,56,53,50,98,48,1,92,1,64,2,4,115,101,108,102,200,0,4,97,114,103,48,53,0,41,4,0,40,105,110,118,111,107,101,45,102,117,110,99,116,105,111,110,45,101,56,48,48,52,100,50,56,54,50,49,102,57,98,53,53,51,102,52,99,56,51,97,54,1,93,1,64,3,4,115,101,108,102,203,0,4,97,114,103,48,18,4,97,114,103,49,54,0,54,4,0,40,105,110,118,111,107,101,45,102,117,110,99,116,105,111,110,45,52,99,102,56,51,97,56,51,100,51,57,48,97,99,98,99,54,52,99,48,97,99,50,51,1,94,1,64,2,4,115,101,108,102,206,0,4,97,114,103,48,55,0,18,4,0,40,105,110,118,111,107,101,45,102,117,110,99,116,105,111,110,45,51,101,54,49,56,51,54,99,52,102,102,49,56,55,55,55,57,52,102,53,98,52,50,101,1,95,10,54,1,0,49,108,101,97,110,45,98,114,105,100,103,101,58,99,97,108,108,98,97,99,107,45,99,104,101,99,107,101,100,45,114,101,99,111,114,100,115,47,110,97,116,105,118,101,64,49,46,48,46,48,5,0,6,206,4,31,3,0,0,13,108,98,45,103,114,97,112,104,45,114,101,102,51,3,0,0,14,98,114,105,100,103,101,45,118,97,108,117,101,45,50,3,0,0,14,98,114,105,100,103,101,45,118,97,108,117,101,45,51,3,0,0,13,108,98,45,103,114,97,112,104,45,114,101,102,48,3,0,0,14,98,114,105,100,103,101,45,118,97,108,117,101,45,53,3,0,0,14,98,114,105,100,103,101,45,118,97,108,117,101,45,54,3,0,0,14,98,114,105,100,103,101,45,118,97,108,117,101,45,56,3,0,0,14,98,114,105,100,103,101,45,118,97,108,117,101,45,57,3,0,0,15,98,114,105,100,103,101,45,118,97,108,117,101,45,49,48,3,0,0,14,108,98,45,103,114,97,112,104,45,110,111,100,101,51,3,0,0,15,98,114,105,100,103,101,45,118,97,108,117,101,45,49,50,3,0,0,14,108,98,45,103,114,97,112,104,45,110,111,100,101,52,3,0,0,15,98,114,105,100,103,101,45,118,97,108,117,101,45,49,52,3,0,0,14,108,98,45,103,114,97,112,104,45,110,111,100,101,48,3,0,0,21,98,114,105,100,103,101,45,97,108,105,97,115,45,118,97,108,117,101,45,50,53,3,0,0,14,108,98,45,103,114,97,112,104,45,110,111,100,101,49,3,0,0,21,98,114,105,100,103,101,45,97,108,105,97,115,45,118,97,108,117,101,45,50,55,3,0,0,14,108,98,45,103,114,97,112,104,45,110,111,100,101,50,3,0,0,21,98,114,105,100,103,101,45,97,108,105,97,115,45,118,97,108,117,101,45,50,57,3,0,0,14,108,98,45,103,114,97,112,104,45,97,114,101,110,97,3,0,0,15,108,98,45,103,114,97,112,104,45,118,97,108,117,101,51,3,0,0,15,108,98,45,103,114,97,112,104,45,118,97,108,117,101,48,3,0,0,13,108,98,45,103,114,97,112,104,45,114,101,102,50,3,0,0,15,108,98,45,103,114,97,112,104,45,118,97,108,117,101,50,3,0,0,13,108,98,45,103,114,97,112,104,45,114,101,102,52,3,0,0,15,108,98,45,103,114,97,112,104,45,118,97,108,117,101,52,3,0,0,13,108,98,45,103,114,97,112,104,45,114,101,102,49,3,0,0,15,108,98,45,103,114,97,112,104,45,118,97,108,117,101,49,3,0,0,8,105,110,116,101,114,118,97,108,3,0,0,8,119,101,105,103,104,116,101,100,3,0,0,33,102,117,110,99,116,105,111,110,45,52,57,57,99,56,55,57,97,51,100,52,53,48,102,54,54,48,52,55,102,99,101,101,51,7,5,2,104,31,105,31,6,38,1,3,0,0,33,102,117,110,99,116,105,111,110,45,49,52,99,99,97,98,102,50,53,101,97,49,55,49,57,101,98,55,48,57,100,48,55,53,7,5,2,104,34,105,34,6,38,1,3,0,0,33,102,117,110,99,116,105,111,110,45,98,101,53,99,54,52,48,48,49,56,55,52,50,50,55,100,56,56,100,48,98,53,52,99,7,5,2,104,37,105,37,6,38,1,3,0,0,33,102,117,110,99,116,105,111,110,45,57,97,99,49,101,54,48,99,55,55,102,98,54,102,101,56,97,55,54,49,55,100,51,97,7,5,2,104,40,105,40,6,38,1,3,0,0,33,102,117,110,99,116,105,111,110,45,48,99,102,100,56,98,55,54,100,100,57,55,100,52,55,48,48,52,97,56,53,50,98,48,7,5,2,104,43,105,43,6,38,1,3,0,0,33,102,117,110,99,116,105,111,110,45,101,56,48,48,52,100,50,56,54,50,49,102,57,98,53,53,51,102,52,99,56,51,97,54,7,5,2,104,46,105,46,6,38,1,3,0,0,33,102,117,110,99,116,105,111,110,45,52,99,102,56,51,97,56,51,100,51,57,48,97,99,98,99,54,52,99,48,97,99,50,51,7,5,2,104,49,105,49,6,38,1,3,0,0,33,102,117,110,99,116,105,111,110,45,51,101,54,49,56,51,54,99,52,102,102,49,56,55,55,55,57,52,102,53,98,52,50,101,7,5,2,104,52,105,52,6,131,4,16,1,0,0,9,99,97,108,108,45,104,111,115,116,1,0,0,19,99,97,108,108,45,104,111,115,116,45,99,111,110,116,97,105,110,101,114,1,0,0,15,99,97,108,108,45,104,111,115,116,45,109,105,120,101,100,1,0,0,16,99,97,108,108,45,104,111,115,116,45,110,101,115,116,101,100,1,0,0,12,109,97,107,101,45,99,108,111,115,117,114,101,1,0,0,22,109,97,107,101,45,99,111,110,116,97,105,110,101,114,45,99,108,111,115,117,114,101,1,0,0,18,109,97,107,101,45,109,105,120,101,100,45,99,108,111,115,117,114,101,1,0,0,19,109,97,107,101,45,110,101,115,116,101,100,45,99,108,111,115,117,114,101,1,0,0,40,105,110,118,111,107,101,45,102,117,110,99,116,105,111,110,45,52,57,57,99,56,55,57,97,51,100,52,53,48,102,54,54,48,52,55,102,99,101,101,51,1,0,0,40,105,110,118,111,107,101,45,102,117,110,99,116,105,111,110,45,49,52,99,99,97,98,102,50,53,101,97,49,55,49,57,101,98,55,48,57,100,48,55,53,1,0,0,40,105,110,118,111,107,101,45,102,117,110,99,116,105,111,110,45,98,101,53,99,54,52,48,48,49,56,55,52,50,50,55,100,56,56,100,48,98,53,52,99,1,0,0,40,105,110,118,111,107,101,45,102,117,110,99,116,105,111,110,45,57,97,99,49,101,54,48,99,55,55,102,98,54,102,101,56,97,55,54,49,55,100,51,97,1,0,0,40,105,110,118,111,107,101,45,102,117,110,99,116,105,111,110,45,48,99,102,100,56,98,55,54,100,100,57,55,100,52,55,48,48,52,97,56,53,50,98,48,1,0,0,40,105,110,118,111,107,101,45,102,117,110,99,116,105,111,110,45,101,56,48,48,52,100,50,56,54,50,49,102,57,98,53,53,51,102,52,99,56,51,97,54,1,0,0,40,105,110,118,111,107,101,45,102,117,110,99,116,105,111,110,45,52,99,102,56,51,97,56,51,100,51,57,48,97,99,98,99,54,52,99,48,97,99,50,51,1,0,0,40,105,110,118,111,107,101,45,102,117,110,99,116,105,111,110,45,51,101,54,49,56,51,54,99,52,102,102,49,56,55,55,55,57,52,102,53,98,52,50,101,1,197,3,0,97,115,109,1,0,0,0,1,28,6,96,0,0,96,4,127,127,127,127,1,127,96,1,127,0,96,1,126,0,96,1,125,0,96,1,124,0,3,8,7,0,0,1,2,3,4,5,5,5,1,1,1,128,8,6,12,2,127,1,65,144,2,11,127,1,65,0,11,7,72,7,6,109,101,109,111,114,121,2,0,5,101,110,116,101,114,0,0,7,114,101,97,108,108,111,99,0,2,8,112,111,115,116,45,105,51,50,0,3,8,112,111,115,116,45,105,54,52,0,4,8,112,111,115,116,45,102,51,50,0,5,8,112,111,115,116,45,102,54,52,0,6,10,206,1,7,29,0,35,1,65,192,0,79,4,64,0,11,35,1,65,2,116,35,0,54,2,16,35,1,65,1,106,36,1,11,36,0,35,1,69,4,64,0,11,35,1,65,1,107,36,1,35,1,69,4,127,65,144,2,5,35,1,65,2,116,40,2,16,11,36,0,11,117,1,3,127,32,3,69,4,64,65,0,15,11,35,0,32,2,65,1,107,106,65,0,32,2,107,113,33,4,32,4,32,3,106,33,5,32,5,32,4,73,32,5,65,128,128,128,32,75,114,4,64,0,11,32,5,65,255,255,3,106,65,16,118,33,6,32,6,63,0,75,4,64,32,6,63,0,107,64,0,65,127,70,4,64,0,11,11,32,0,4,64,32,4,32,0,32,1,32,3,32,1,32,3,73,27,252,10,0,0,11,32,5,36,0,32,4,11,4,0,16,1,11,4,0,16,1,11,4,0,16,1,11,4,0,16,1,11,0,99,4,110,97,109,101,0,10,9,97,108,108,111,99,97,116,111,114,1,8,1,1,5,108,101,97,118,101,2,54,1,2,7,0,3,111,108,100,1,8,111,108,100,45,115,105,122,101,2,9,97,108,105,103,110,109,101,110,116,3,4,115,105,122,101,4,5,115,116,97,114,116,5,3,101,110,100,6,5,112,97,103,101,115,7,14,2,0,4,104,101,97,112,1,5,100,101,112,116,104,2,4,1,0,0,0,6,76,6,0,2,1,0,6,109,101,109,111,114,121,0,0,1,0,7,114,101,97,108,108,111,99,0,0,1,0,8,112,111,115,116,45,105,51,50,0,0,1,0,8,112,111,115,116,45,105,54,52,0,0,1,0,8,112,111,115,116,45,102,51,50,0,0,1,0,8,112,111,115,116,45,102,54,52,8,145,1,24,1,0,0,2,3,0,4,0,1,0,1,2,3,0,4,0,1,0,2,2,3,0,4,0,1,0,3,2,3,0,4,0,1,0,4,2,3,0,4,0,1,0,5,2,3,0,4,0,1,0,6,2,3,0,4,0,1,0,7,2,3,0,4,0,1,0,8,2,3,0,4,0,1,0,9,2,3,0,4,0,1,0,10,2,3,0,4,0,1,0,11,2,3,0,4,0,1,0,12,2,3,0,4,0,1,0,13,2,3,0,4,0,1,0,14,2,3,0,4,0,1,0,15,2,3,0,4,0,3,31,3,34,3,37,3,40,3,43,3,46,3,49,3,52,1,221,11,0,97,115,109,1,0,0,0,1,100,10,96,4,127,127,127,127,1,127,96,0,0,96,1,127,0,96,2,127,127,0,96,2,127,127,1,127,96,13,127,127,127,127,127,127,127,127,127,127,127,127,127,0,96,15,127,127,127,127,127,127,127,127,127,127,127,127,127,127,127,0,96,1,127,1,127,96,12,127,127,127,127,127,127,127,127,127,127,127,127,1,127,96,14,127,127,127,127,127,127,127,127,127,127,127,127,127,127,1,127,2,252,2,27,10,97,108,108,111,99,97,116,105,111,110,7,114,101,97,108,108,111,99,0,0,10,97,108,108,111,99,97,116,105,111,110,6,109,101,109,111,114,121,2,0,1,10,97,108,108,111,99,97,116,105,111,110,5,101,110,116,101,114,0,1,9,114,101,115,111,117,114,99,101,115,6,100,114,111,112,51,50,0,2,9,114,101,115,111,117,114,99,101,115,6,100,114,111,112,51,51,0,2,9,114,101,115,111,117,114,99,101,115,6,100,114,111,112,51,52,0,2,9,114,101,115,111,117,114,99,101,115,6,100,114,111,112,51,53,0,2,9,114,101,115,111,117,114,99,101,115,6,100,114,111,112,51,54,0,2,9,114,101,115,111,117,114,99,101,115,6,100,114,111,112,51,55,0,2,9,114,101,115,111,117,114,99,101,115,6,100,114,111,112,51,56,0,2,9,114,101,115,111,117,114,99,101,115,6,100,114,111,112,51,57,0,2,4,104,111,115,116,2,102,48,0,3,4,104,111,115,116,2,102,49,0,3,4,104,111,115,116,2,102,50,0,3,4,104,111,115,116,2,102,51,0,3,4,104,111,115,116,2,102,52,0,4,4,104,111,115,116,2,102,53,0,4,4,104,111,115,116,2,102,54,0,4,4,104,111,115,116,2,102,55,0,4,4,104,111,115,116,2,102,56,0,5,4,104,111,115,116,2,102,57,0,5,4,104,111,115,116,3,102,49,48,0,6,4,104,111,115,116,3,102,49,49,0,5,4,104,111,115,116,3,102,49,50,0,5,4,104,111,115,116,3,102,49,51,0,5,4,104,111,115,116,3,102,49,52,0,6,4,104,111,115,116,3,102,49,53,0,5,3,17,16,7,7,7,7,4,4,4,4,8,8,9,8,8,8,9,8,7,87,16,2,102,48,0,26,2,102,49,0,27,2,102,50,0,28,2,102,51,0,29,2,102,52,0,30,2,102,53,0,31,2,102,54,0,32,2,102,55,0,33,2,102,56,0,34,2,102,57,0,35,3,102,49,48,0,36,3,102,49,49,0,37,3,102,49,50,0,38,3,102,49,51,0,39,3,102,49,52,0,40,3,102,49,53,0,41,10,217,4,16,30,1,1,127,16,1,65,0,65,0,65,4,65,8,16,0,33,1,32,0,32,1,16,10,32,0,16,2,32,1,11,30,1,1,127,16,1,65,0,65,0,65,4,65,8,16,0,33,1,32,0,32,1,16,11,32,0,16,3,32,1,11,30,1,1,127,16,1,65,0,65,0,65,4,65,8,16,0,33,1,32,0,32,1,16,12,32,0,16,4,32,1,11,30,1,1,127,16,1,65,0,65,0,65,4,65,8,16,0,33,1,32,0,32,1,16,13,32,0,16,5,32,1,11,10,0,16,1,32,0,32,1,16,14,11,10,0,16,1,32,0,32,1,16,15,11,10,0,16,1,32,0,32,1,16,16,11,10,0,16,1,32,0,32,1,16,17,11,52,1,1,127,16,1,65,0,65,0,65,4,65,44,16,0,33,12,32,0,32,1,32,2,32,3,32,4,32,5,32,6,32,7,32,8,32,9,32,10,32,11,32,12,16,18,32,0,16,2,32,12,11,52,1,1,127,16,1,65,0,65,0,65,4,65,44,16,0,33,12,32,0,32,1,32,2,32,3,32,4,32,5,32,6,32,7,32,8,32,9,32,10,32,11,32,12,16,19,32,0,16,3,32,12,11,56,1,1,127,16,1,65,0,65,0,65,4,65,44,16,0,33,14,32,0,32,1,32,2,32,3,32,4,32,5,32,6,32,7,32,8,32,9,32,10,32,11,32,12,32,13,32,14,16,20,32,0,16,4,32,14,11,52,1,1,127,16,1,65,0,65,0,65,4,65,44,16,0,33,12,32,0,32,1,32,2,32,3,32,4,32,5,32,6,32,7,32,8,32,9,32,10,32,11,32,12,16,21,32,0,16,5,32,12,11,52,1,1,127,16,1,65,0,65,0,65,4,65,8,16,0,33,12,32,0,32,1,32,2,32,3,32,4,32,5,32,6,32,7,32,8,32,9,32,10,32,11,32,12,16,22,32,0,16,6,32,12,11,52,1,1,127,16,1,65,0,65,0,65,4,65,44,16,0,33,12,32,0,32,1,32,2,32,3,32,4,32,5,32,6,32,7,32,8,32,9,32,10,32,11,32,12,16,23,32,0,16,7,32,12,11,56,1,1,127,16,1,65,0,65,0,65,4,65,44,16,0,33,14,32,0,32,1,32,2,32,3,32,4,32,5,32,6,32,7,32,8,32,9,32,10,32,11,32,12,32,13,32,14,16,24,32,0,16,8,32,14,11,52,1,1,127,16,1,65,0,65,0,65,4,65,8,16,0,33,12,32,0,32,1,32,2,32,3,32,4,32,5,32,6,32,7,32,8,32,9,32,10,32,11,32,12,16,25,32,0,16,9,32,12,11,0,165,2,4,110,97,109,101,0,8,7,102,111,114,119,97,114,100,1,152,1,26,0,8,97,108,108,111,99,97,116,101,1,5,101,110,116,101,114,2,6,100,114,111,112,51,50,3,6,100,114,111,112,51,51,4,6,100,114,111,112,51,52,5,6,100,114,111,112,51,53,6,6,100,114,111,112,51,54,7,6,100,114,111,112,51,55,8,6,100,114,111,112,51,56,9,6,100,114,111,112,51,57,10,2,102,48,11,2,102,49,12,2,102,50,13,2,102,51,14,2,102,52,15,2,102,53,16,2,102,54,17,2,102,55,18,2,102,56,19,2,102,57,20,3,102,49,48,21,3,102,49,49,22,3,102,49,50,23,3,102,49,51,24,3,102,49,52,25,3,102,49,53,2,121,12,26,1,1,6,114,101,115,117,108,116,27,1,1,6,114,101,115,117,108,116,28,1,1,6,114,101,115,117,108,116,29,1,1,6,114,101,115,117,108,116,34,1,12,6,114,101,115,117,108,116,35,1,12,6,114,101,115,117,108,116,36,1,14,6,114,101,115,117,108,116,37,1,12,6,114,101,115,117,108,116,38,1,12,6,114,101,115,117,108,116,39,1,12,6,114,101,115,117,108,116,40,1,14,6,114,101,115,117,108,116,41,1,12,6,114,101,115,117,108,116,2,198,1,3,1,16,2,102,48,0,5,2,102,49,0,6,2,102,50,0,7,2,102,51,0,8,2,102,52,0,9,2,102,53,0,10,2,102,54,0,11,2,102,55,0,12,2,102,56,0,13,2,102,57,0,14,3,102,49,48,0,15,3,102,49,49,0,16,3,102,49,50,0,17,3,102,49,51,0,18,3,102,49,52,0,19,3,102,49,53,0,20,1,8,6,100,114,111,112,51,50,0,21,6,100,114,111,112,51,51,0,22,6,100,114,111,112,51,52,0,23,6,100,114,111,112,51,53,0,24,6,100,114,111,112,51,54,0,25,6,100,114,111,112,51,55,0,26,6,100,114,111,112,51,56,0,27,6,100,114,111,112,51,57,0,28,0,1,3,10,97,108,108,111,99,97,116,105,111,110,18,0,4,104,111,115,116,18,1,9,114,101,115,111,117,114,99,101,115,18,2,6,119,16,0,0,1,3,2,102,48,0,0,1,3,2,102,49,0,0,1,3,2,102,50,0,0,1,3,2,102,51,0,0,1,3,2,102,52,0,0,1,3,2,102,53,0,0,1,3,2,102,54,0,0,1,3,2,102,55,0,0,1,3,2,102,56,0,0,1,3,2,102,57,0,0,1,3,3,102,49,48,0,0,1,3,3,102,49,49,0,0,1,3,3,102,49,50,0,0,1,3,3,102,49,51,0,0,1,3,3,102,49,52,0,0,1,3,3,102,49,53,7,11,1,64,1,4,97,114,103,48,32,0,9,8,12,1,0,0,29,3,3,0,4,0,5,1,55,7,11,1,64,1,4,97,114,103,48,35,0,9,8,12,1,0,0,30,3,3,0,4,0,5,1,56,7,11,1,64,1,4,97,114,103,48,38,0,9,8,12,1,0,0,31,3,3,0,4,0,5,1,57,7,11,1,64,1,4,97,114,103,48,41,0,9,8,12,1,0,0,32,3,3,0,4,0,5,1,58,7,11,1,64,1,4,97,114,103,48,9,0,45,8,12,1,0,0,33,3,3,0,4,0,5,1,59,7,11,1,64,1,4,97,114,103,48,9,0,48,8,12,1,0,0,34,3,3,0,4,0,5,1,60,7,11,1,64,1,4,97,114,103,48,9,0,51,8,12,1,0,0,35,3,3,0,4,0,5,1,61,7,11,1,64,1,4,97,114,103,48,9,0,54,8,12,1,0,0,36,3,3,0,4,0,5,1,62,7,17,1,64,2,4,115,101,108,102,32,4,97,114,103,48,29,0,29,8,12,1,0,0,37,3,3,0,4,0,5,1,63,7,17,1,64,2,4,115,101,108,102,35,4,97,114,103,48,22,0,24,8,12,1,0,0,38,3,3,0,4,0,5,1,64,7,23,1,64,3,4,115,101,108,102,38,4,97,114,103,48,9,4,97,114,103,49,29,0,29,8,12,1,0,0,39,3,3,0,4,0,5,1,65,7,17,1,64,2,4,115,101,108,102,41,4,97,114,103,48,30,0,30,8,12,1,0,0,40,3,3,0,4,0,5,1,66,7,17,1,64,2,4,115,101,108,102,44,4,97,114,103,48,29,0,9,8,12,1,0,0,41,3,3,0,4,0,5,1,67,7,17,1,64,2,4,115,101,108,102,47,4,97,114,103,48,28,0,22,8,12,1,0,0,42,3,3,0,4,0,5,1,68,7,23,1,64,3,4,115,101,108,102,50,4,97,114,103,48,9,4,97,114,103,49,29,0,29,8,12,1,0,0,43,3,3,0,4,0,5,1,69,7,17,1,64,2,4,115,101,108,102,53,4,97,114,103,48,30,0,9,8,12,1,0,0,44,3,3,0,4,0,5,1,70,7,153,15,1,66,124,2,3,2,1,1,4,0,13,108,98,45,103,114,97,112,104,45,114,101,102,51,3,0,0,2,3,2,1,2,4,0,14,98,114,105,100,103,101,45,118,97,108,117,101,45,50,3,0,2,2,3,2,1,3,4,0,14,98,114,105,100,103,101,45,118,97,108,117,101,45,51,3,0,4,2,3,2,1,4,4,0,13,108,98,45,103,114,97,112,104,45,114,101,102,48,3,0,6,2,3,2,1,5,4,0,14,98,114,105,100,103,101,45,118,97,108,117,101,45,53,3,0,8,2,3,2,1,6,4,0,14,98,114,105,100,103,101,45,118,97,108,117,101,45,54,3,0,10,2,3,2,1,7,4,0,14,98,114,105,100,103,101,45,118,97,108,117,101,45,56,3,0,12,2,3,2,1,8,4,0,14,98,114,105,100,103,101,45,118,97,108,117,101,45,57,3,0,14,2,3,2,1,9,4,0,15,98,114,105,100,103,101,45,118,97,108,117,101,45,49,48,3,0,16,2,3,2,1,10,4,0,14,108,98,45,103,114,97,112,104,45,110,111,100,101,51,3,0,18,2,3,2,1,11,4,0,15,98,114,105,100,103,101,45,118,97,108,117,101,45,49,50,3,0,20,2,3,2,1,12,4,0,14,108,98,45,103,114,97,112,104,45,110,111,100,101,52,3,0,22,2,3,2,1,13,4,0,15,98,114,105,100,103,101,45,118,97,108,117,101,45,49,52,3,0,24,2,3,2,1,14,4,0,14,108,98,45,103,114,97,112,104,45,110,111,100,101,48,3,0,26,2,3,2,1,15,4,0,21,98,114,105,100,103,101,45,97,108,105,97,115,45,118,97,108,117,101,45,50,53,3,0,28,2,3,2,1,16,4,0,14,108,98,45,103,114,97,112,104,45,110,111,100,101,49,3,0,30,2,3,2,1,17,4,0,21,98,114,105,100,103,101,45,97,108,105,97,115,45,118,97,108,117,101,45,50,55,3,0,32,2,3,2,1,18,4,0,14,108,98,45,103,114,97,112,104,45,110,111,100,101,50,3,0,34,2,3,2,1,19,4,0,21,98,114,105,100,103,101,45,97,108,105,97,115,45,118,97,108,117,101,45,50,57,3,0,36,2,3,2,1,20,4,0,14,108,98,45,103,114,97,112,104,45,97,114,101,110,97,3,0,38,2,3,2,1,21,4,0,15,108,98,45,103,114,97,112,104,45,118,97,108,117,101,51,3,0,40,2,3,2,1,22,4,0,15,108,98,45,103,114,97,112,104,45,118,97,108,117,101,48,3,0,42,2,3,2,1,23,4,0,13,108,98,45,103,114,97,112,104,45,114,101,102,50,3,0,44,2,3,2,1,24,4,0,15,108,98,45,103,114,97,112,104,45,118,97,108,117,101,50,3,0,46,2,3,2,1,25,4,0,13,108,98,45,103,114,97,112,104,45,114,101,102,52,3,0,48,2,3,2,1,26,4,0,15,108,98,45,103,114,97,112,104,45,118,97,108,117,101,52,3,0,50,2,3,2,1,27,4,0,13,108,98,45,103,114,97,112,104,45,114,101,102,49,3,0,52,2,3,2,1,28,4,0,15,108,98,45,103,114,97,112,104,45,118,97,108,117,101,49,3,0,54,2,3,2,1,29,4,0,8,105,110,116,101,114,118,97,108,3,0,56,2,3,2,1,30,4,0,8,119,101,105,103,104,116,101,100,3,0,58,2,3,2,1,31,4,0,33,102,117,110,99,116,105,111,110,45,52,57,57,99,56,55,57,97,51,100,52,53,48,102,54,54,48,52,55,102,99,101,101,51,3,0,60,1,104,61,1,105,61,2,3,2,1,34,4,0,33,102,117,110,99,116,105,111,110,45,49,52,99,99,97,98,102,50,53,101,97,49,55,49,57,101,98,55,48,57,100,48,55,53,3,0,64,1,104,65,1,105,65,2,3,2,1,37,4,0,33,102,117,110,99,116,105,111,110,45,98,101,53,99,54,52,48,48,49,56,55,52,50,50,55,100,56,56,100,48,98,53,52,99,3,0,68,1,104,69,1,105,69,2,3,2,1,40,4,0,33,102,117,110,99,116,105,111,110,45,57,97,99,49,101,54,48,99,55,55,102,98,54,102,101,56,97,55,54,49,55,100,51,97,3,0,72,1,104,73,1,105,73,2,3,2,1,43,4,0,33,102,117,110,99,116,105,111,110,45,48,99,102,100,56,98,55,54,100,100,57,55,100,52,55,48,48,52,97,56,53,50,98,48,3,0,76,1,104,77,1,105,77,2,3,2,1,46,4,0,33,102,117,110,99,116,105,111,110,45,101,56,48,48,52,100,50,56,54,50,49,102,57,98,53,53,51,102,52,99,56,51,97,54,3,0,80,1,104,81,1,105,81,2,3,2,1,49,4,0,33,102,117,110,99,116,105,111,110,45,52,99,102,56,51,97,56,51,100,51,57,48,97,99,98,99,54,52,99,48,97,99,50,51,3,0,84,1,104,85,1,105,85,2,3,2,1,52,4,0,33,102,117,110,99,116,105,111,110,45,51,101,54,49,56,51,54,99,52,102,102,49,56,55,55,55,57,52,102,53,98,52,50,101,3,0,88,1,104,89,1,105,89,1,64,1,4,97,114,103,48,62,0,17,4,0,9,99,97,108,108,45,104,111,115,116,1,92,1,64,1,4,97,114,103,48,194,0,0,17,4,0,19,99,97,108,108,45,104,111,115,116,45,99,111,110,116,97,105,110,101,114,1,93,1,64,1,4,97,114,103,48,198,0,0,17,4,0,15,99,97,108,108,45,104,111,115,116,45,109,105,120,101,100,1,94,1,64,1,4,97,114,103,48,202,0,0,17,4,0,16,99,97,108,108,45,104,111,115,116,45,110,101,115,116,101,100,1,95,1,64,1,4,97,114,103,48,17,0,207,0,4,0,12,109,97,107,101,45,99,108,111,115,117,114,101,1,96,1,64,1,4,97,114,103,48,17,0,211,0,4,0,22,109,97,107,101,45,99,111,110,116,97,105,110,101,114,45,99,108,111,115,117,114,101,1,97,1,64,1,4,97,114,103,48,17,0,215,0,4,0,18,109,97,107,101,45,109,105,120,101,100,45,99,108,111,115,117,114,101,1,98,1,64,1,4,97,114,103,48,17,0,219,0,4,0,19,109,97,107,101,45,110,101,115,116,101,100,45,99,108,111,115,117,114,101,1,99,1,64,2,4,115,101,108,102,62,4,97,114,103,48,57,0,57,4,0,40,105,110,118,111,107,101,45,102,117,110,99,116,105,111,110,45,52,57,57,99,56,55,57,97,51,100,52,53,48,102,54,54,48,52,55,102,99,101,101,51,1,100,1,64,2,4,115,101,108,102,194,0,4,97,114,103,48,43,0,47,4,0,40,105,110,118,111,107,101,45,102,117,110,99,116,105,111,110,45,49,52,99,99,97,98,102,50,53,101,97,49,55,49,57,101,98,55,48,57,100,48,55,53,1,101,1,64,3,4,115,101,108,102,198,0,4,97,114,103,48,17,4,97,114,103,49,57,0,57,4,0,40,105,110,118,111,107,101,45,102,117,110,99,116,105,111,110,45,98,101,53,99,54,52,48,48,49,56,55,52,50,50,55,100,56,56,100,48,98,53,52,99,1,102,1,64,2,4,115,101,108,102,202,0,4,97,114,103,48,59,0,59,4,0,40,105,110,118,111,107,101,45,102,117,110,99,116,105,111,110,45,57,97,99,49,101,54,48,99,55,55,102,98,54,102,101,56,97,55,54,49,55,100,51,97,1,103,1,64,2,4,115,101,108,102,206,0,4,97,114,103,48,57,0,17,4,0,40,105,110,118,111,107,101,45,102,117,110,99,116,105,111,110,45,48,99,102,100,56,98,55,54,100,100,57,55,100,52,55,48,48,52,97,56,53,50,98,48,1,104,1,64,2,4,115,101,108,102,210,0,4,97,114,103,48,55,0,43,4,0,40,105,110,118,111,107,101,45,102,117,110,99,116,105,111,110,45,101,56,48,48,52,100,50,56,54,50,49,102,57,98,53,53,51,102,52,99,56,51,97,54,1,105,1,64,3,4,115,101,108,102,214,0,4,97,114,103,48,17,4,97,114,103,49,57,0,57,4,0,40,105,110,118,111,107,101,45,102,117,110,99,116,105,111,110,45,52,99,102,56,51,97,56,51,100,51,57,48,97,99,98,99,54,52,99,48,97,99,50,51,1,106,1,64,2,4,115,101,108,102,218,0,4,97,114,103,48,59,0,17,4,0,40,105,110,118,111,107,101,45,102,117,110,99,116,105,111,110,45,51,101,54,49,56,51,54,99,52,102,102,49,56,55,55,55,57,52,102,53,98,52,50,101,1,107,5,213,10,1,1,54,0,13,108,98,45,103,114,97,112,104,45,114,101,102,51,3,1,0,14,98,114,105,100,103,101,45,118,97,108,117,101,45,50,3,2,0,14,98,114,105,100,103,101,45,118,97,108,117,101,45,51,3,3,0,13,108,98,45,103,114,97,112,104,45,114,101,102,48,3,4,0,14,98,114,105,100,103,101,45,118,97,108,117,101,45,53,3,5,0,14,98,114,105,100,103,101,45,118,97,108,117,101,45,54,3,6,0,14,98,114,105,100,103,101,45,118,97,108,117,101,45,56,3,7,0,14,98,114,105,100,103,101,45,118,97,108,117,101,45,57,3,8,0,15,98,114,105,100,103,101,45,118,97,108,117,101,45,49,48,3,9,0,14,108,98,45,103,114,97,112,104,45,110,111,100,101,51,3,10,0,15,98,114,105,100,103,101,45,118,97,108,117,101,45,49,50,3,11,0,14,108,98,45,103,114,97,112,104,45,110,111,100,101,52,3,12,0,15,98,114,105,100,103,101,45,118,97,108,117,101,45,49,52,3,13,0,14,108,98,45,103,114,97,112,104,45,110,111,100,101,48,3,14,0,21,98,114,105,100,103,101,45,97,108,105,97,115,45,118,97,108,117,101,45,50,53,3,15,0,14,108,98,45,103,114,97,112,104,45,110,111,100,101,49,3,16,0,21,98,114,105,100,103,101,45,97,108,105,97,115,45,118,97,108,117,101,45,50,55,3,17,0,14,108,98,45,103,114,97,112,104,45,110,111,100,101,50,3,18,0,21,98,114,105,100,103,101,45,97,108,105,97,115,45,118,97,108,117,101,45,50,57,3,19,0,14,108,98,45,103,114,97,112,104,45,97,114,101,110,97,3,20,0,15,108,98,45,103,114,97,112,104,45,118,97,108,117,101,51,3,21,0,15,108,98,45,103,114,97,112,104,45,118,97,108,117,101,48,3,22,0,13,108,98,45,103,114,97,112,104,45,114,101,102,50,3,23,0,15,108,98,45,103,114,97,112,104,45,118,97,108,117,101,50,3,24,0,13,108,98,45,103,114,97,112,104,45,114,101,102,52,3,25,0,15,108,98,45,103,114,97,112,104,45,118,97,108,117,101,52,3,26,0,13,108,98,45,103,114,97,112,104,45,114,101,102,49,3,27,0,15,108,98,45,103,114,97,112,104,45,118,97,108,117,101,49,3,28,0,8,105,110,116,101,114,118,97,108,3,29,0,8,119,101,105,103,104,116,101,100,3,30,0,33,102,117,110,99,116,105,111,110,45,52,57,57,99,56,55,57,97,51,100,52,53,48,102,54,54,48,52,55,102,99,101,101,51,3,31,0,33,102,117,110,99,116,105,111,110,45,49,52,99,99,97,98,102,50,53,101,97,49,55,49,57,101,98,55,48,57,100,48,55,53,3,34,0,33,102,117,110,99,116,105,111,110,45,98,101,53,99,54,52,48,48,49,56,55,52,50,50,55,100,56,56,100,48,98,53,52,99,3,37,0,33,102,117,110,99,116,105,111,110,45,57,97,99,49,101,54,48,99,55,55,102,98,54,102,101,56,97,55,54,49,55,100,51,97,3,40,0,33,102,117,110,99,116,105,111,110,45,48,99,102,100,56,98,55,54,100,100,57,55,100,52,55,48,48,52,97,56,53,50,98,48,3,43,0,33,102,117,110,99,116,105,111,110,45,101,56,48,48,52,100,50,56,54,50,49,102,57,98,53,53,51,102,52,99,56,51,97,54,3,46,0,33,102,117,110,99,116,105,111,110,45,52,99,102,56,51,97,56,51,100,51,57,48,97,99,98,99,54,52,99,48,97,99,50,51,3,49,0,33,102,117,110,99,116,105,111,110,45,51,101,54,49,56,51,54,99,52,102,102,49,56,55,55,55,57,52,102,53,98,52,50,101,3,52,0,9,99,97,108,108,45,104,111,115,116,1,16,0,19,99,97,108,108,45,104,111,115,116,45,99,111,110,116,97,105,110,101,114,1,17,0,15,99,97,108,108,45,104,111,115,116,45,109,105,120,101,100,1,18,0,16,99,97,108,108,45,104,111,115,116,45,110,101,115,116,101,100,1,19,0,12,109,97,107,101,45,99,108,111,115,117,114,101,1,20,0,22,109,97,107,101,45,99,111,110,116,97,105,110,101,114,45,99,108,111,115,117,114,101,1,21,0,18,109,97,107,101,45,109,105,120,101,100,45,99,108,111,115,117,114,101,1,22,0,19,109,97,107,101,45,110,101,115,116,101,100,45,99,108,111,115,117,114,101,1,23,0,40,105,110,118,111,107,101,45,102,117,110,99,116,105,111,110,45,52,57,57,99,56,55,57,97,51,100,52,53,48,102,54,54,48,52,55,102,99,101,101,51,1,24,0,40,105,110,118,111,107,101,45,102,117,110,99,116,105,111,110,45,49,52,99,99,97,98,102,50,53,101,97,49,55,49,57,101,98,55,48,57,100,48,55,53,1,25,0,40,105,110,118,111,107,101,45,102,117,110,99,116,105,111,110,45,98,101,53,99,54,52,48,48,49,56,55,52,50,50,55,100,56,56,100,48,98,53,52,99,1,26,0,40,105,110,118,111,107,101,45,102,117,110,99,116,105,111,110,45,57,97,99,49,101,54,48,99,55,55,102,98,54,102,101,56,97,55,54,49,55,100,51,97,1,27,0,40,105,110,118,111,107,101,45,102,117,110,99,116,105,111,110,45,48,99,102,100,56,98,55,54,100,100,57,55,100,52,55,48,48,52,97,56,53,50,98,48,1,28,0,40,105,110,118,111,107,101,45,102,117,110,99,116,105,111,110,45,101,56,48,48,52,100,50,56,54,50,49,102,57,98,53,53,51,102,52,99,56,51,97,54,1,29,0,40,105,110,118,111,107,101,45,102,117,110,99,116,105,111,110,45,52,99,102,56,51,97,56,51,100,51,57,48,97,99,98,99,54,52,99,48,97,99,50,51,1,30,0,40,105,110,118,111,107,101,45,102,117,110,99,116,105,111,110,45,51,101,54,49,56,51,54,99,52,102,102,49,56,55,55,55,57,52,102,53,98,52,50,101,1,31,11,54,1,0,46,108,101,97,110,45,98,114,105,100,103,101,58,99,97,108,108,98,97,99,107,45,99,104,101,99,107,101,100,45,114,101,99,111,114,100,115,47,97,112,105,64,49,46,48,46,48,5,1,1,5,71,0,141,11,14,99,111,109,112,111,110,101,110,116,45,110,97,109,101,1,160,3,0,0,45,0,7,114,101,97,108,108,111,99,1,8,112,111,115,116,45,105,51,50,2,8,112,111,115,116,45,105,54,52,3,8,112,111,115,116,45,102,51,50,4,8,112,111,115,116,45,102,54,52,5,6,108,111,119,101,114,48,6,6,108,111,119,101,114,49,7,6,108,111,119,101,114,50,8,6,108,111,119,101,114,51,9,6,108,111,119,101,114,52,10,6,108,111,119,101,114,53,11,6,108,111,119,101,114,54,12,6,108,111,119,101,114,55,13,6,108,111,119,101,114,56,14,6,108,111,119,101,114,57,15,7,108,111,119,101,114,49,48,16,7,108,111,119,101,114,49,49,17,7,108,111,119,101,114,49,50,18,7,108,111,119,101,114,49,51,19,7,108,111,119,101,114,49,52,20,7,108,111,119,101,114,49,53,21,6,100,114,111,112,51,50,22,6,100,114,111,112,51,51,23,6,100,114,111,112,51,52,24,6,100,114,111,112,51,53,25,6,100,114,111,112,51,54,26,6,100,114,111,112,51,55,27,6,100,114,111,112,51,56,28,6,100,114,111,112,51,57,29,8,102,111,114,119,97,114,100,48,30,8,102,111,114,119,97,114,100,49,31,8,102,111,114,119,97,114,100,50,32,8,102,111,114,119,97,114,100,51,33,8,102,111,114,119,97,114,100,52,34,8,102,111,114,119,97,114,100,53,35,8,102,111,114,119,97,114,100,54,36,8,102,111,114,119,97,114,100,55,37,8,102,111,114,119,97,114,100,56,38,8,102,111,114,119,97,114,100,57,39,9,102,111,114,119,97,114,100,49,48,40,9,102,111,114,119,97,114,100,49,49,41,9,102,111,114,119,97,114,100,49,50,42,9,102,111,114,119,97,114,100,49,51,43,9,102,111,114,119,97,114,100,49,52,44,9,102,111,114,119,97,114,100,49,53,1,11,0,2,1,0,6,109,101,109,111,114,121,1,23,0,17,2,0,9,97,108,108,111,99,97,116,111,114,1,7,102,111,114,119,97,114,100,1,46,0,18,4,0,10,97,108,108,111,99,97,116,105,111,110,1,7,105,109,112,111,114,116,115,2,9,114,101,115,111,117,114,99,101,115,3,9,102,111,114,119,97,114,100,101,100,1,190,1,1,32,0,5,104,111,115,116,48,1,5,104,111,115,116,49,2,5,104,111,115,116,50,3,5,104,111,115,116,51,4,5,104,111,115,116,52,5,5,104,111,115,116,53,6,5,104,111,115,116,54,7,5,104,111,115,116,55,8,5,104,111,115,116,56,9,5,104,111,115,116,57,10,6,104,111,115,116,49,48,11,6,104,111,115,116,49,49,12,6,104,111,115,116,49,50,13,6,104,111,115,116,49,51,14,6,104,111,115,116,49,52,15,6,104,111,115,116,49,53,16,2,102,48,17,2,102,49,18,2,102,50,19,2,102,51,20,2,102,52,21,2,102,53,22,2,102,54,23,2,102,55,24,2,102,56,25,2,102,57,26,3,102,49,48,27,3,102,49,49,28,3,102,49,50,29,3,102,49,51,30,3,102,49,52,31,3,102,49,53,1,175,5,3,56,0,3,97,112,105,1,7,112,117,98,108,105,99,49,2,7,112,117,98,108,105,99,50,3,7,112,117,98,108,105,99,51,4,7,112,117,98,108,105,99,52,5,7,112,117,98,108,105,99,53,6,7,112,117,98,108,105,99,54,7,7,112,117,98,108,105,99,56,8,7,112,117,98,108,105,99,57,9,8,112,117,98,108,105,99,49,48,10,8,112,117,98,108,105,99,49,49,11,8,112,117,98,108,105,99,49,50,12,8,112,117,98,108,105,99,49,51,13,8,112,117,98,108,105,99,49,52,14,8,112,117,98,108,105,99,50,52,15,8,112,117,98,108,105,99,50,53,16,8,112,117,98,108,105,99,50,54,17,8,112,117,98,108,105,99,50,55,18,8,112,117,98,108,105,99,50,56,19,8,112,117,98,108,105,99,50,57,20,8,112,117,98,108,105,99,49,53,21,8,112,117,98,108,105,99,49,54,22,8,112,117,98,108,105,99,49,55,23,8,112,117,98,108,105,99,49,56,24,8,112,117,98,108,105,99,49,57,25,8,112,117,98,108,105,99,50,48,26,8,112,117,98,108,105,99,50,49,27,8,112,117,98,108,105,99,50,50,28,8,112,117,98,108,105,99,50,51,29,8,112,117,98,108,105,99,51,48,30,8,112,117,98,108,105,99,51,49,31,16,112,117,98,108,105,99,82,101,115,111,117,114,99,101,51,50,32,14,112,117,98,108,105,99,66,111,114,114,111,119,51,50,33,11,112,117,98,108,105,99,79,119,110,51,50,34,16,112,117,98,108,105,99,82,101,115,111,117,114,99,101,51,51,35,14,112,117,98,108,105,99,66,111,114,114,111,119,51,51,36,11,112,117,98,108,105,99,79,119,110,51,51,37,16,112,117,98,108,105,99,82,101,115,111,117,114,99,101,51,52,38,14,112,117,98,108,105,99,66,111,114,114,111,119,51,52,39,11,112,117,98,108,105,99,79,119,110,51,52,40,16,112,117,98,108,105,99,82,101,115,111,117,114,99,101,51,53,41,14,112,117,98,108,105,99,66,111,114,114,111,119,51,53,42,11,112,117,98,108,105,99,79,119,110,51,53,43,16,112,117,98,108,105,99,82,101,115,111,117,114,99,101,51,54,44,14,112,117,98,108,105,99,66,111,114,114,111,119,51,54,45,11,112,117,98,108,105,99,79,119,110,51,54,46,16,112,117,98,108,105,99,82,101,115,111,117,114,99,101,51,55,47,14,112,117,98,108,105,99,66,111,114,114,111,119,51,55,48,11,112,117,98,108,105,99,79,119,110,51,55,49,16,112,117,98,108,105,99,82,101,115,111,117,114,99,101,51,56,50,14,112,117,98,108,105,99,66,111,114,114,111,119,51,56,51,11,112,117,98,108,105,99,79,119,110,51,56,52,16,112,117,98,108,105,99,82,101,115,111,117,114,99,101,51,57,53,14,112,117,98,108,105,99,66,111,114,114,111,119,51,57,54,11,112,117,98,108,105,99,79,119,110,51,57,71,10,112,117,98,108,105,99,45,97,112,105,1,16,5,2,0,4,104,111,115,116,1,6,112,117,98,108,105,99};
static wasmtime_error_t *lb_link(callbackcheckedrecords_wasmtime *session) {
  wasmtime_component_linker_instance_t *root = wasmtime_component_linker_root(session->linker), *host = NULL;
  wasmtime_error_t *error = wasmtime_component_linker_instance_add_instance(root, "lean-bridge:callback-checked-records/native@1.0.0", 49, &host);
  if (!error) {
    if (!error) {
      wasmtime_component_resource_type_t *type = wasmtime_component_resource_type_new_host(1);
      error = wasmtime_component_linker_instance_add_resource(host, "function-499c879a3d450f66047fcee3", 33, type, lb_proxy_drop, session, NULL);
      wasmtime_component_resource_type_delete(type);
    }
    if (!error) {
      wasmtime_component_resource_type_t *type = wasmtime_component_resource_type_new_host(2);
      error = wasmtime_component_linker_instance_add_resource(host, "function-14ccabf25ea1719eb709d075", 33, type, lb_proxy_drop, session, NULL);
      wasmtime_component_resource_type_delete(type);
    }
    if (!error) {
      wasmtime_component_resource_type_t *type = wasmtime_component_resource_type_new_host(3);
      error = wasmtime_component_linker_instance_add_resource(host, "function-be5c64001874227d88d0b54c", 33, type, lb_proxy_drop, session, NULL);
      wasmtime_component_resource_type_delete(type);
    }
    if (!error) {
      wasmtime_component_resource_type_t *type = wasmtime_component_resource_type_new_host(4);
      error = wasmtime_component_linker_instance_add_resource(host, "function-9ac1e60c77fb6fe8a7617d3a", 33, type, lb_proxy_drop, session, NULL);
      wasmtime_component_resource_type_delete(type);
    }
    if (!error) {
      wasmtime_component_resource_type_t *type = wasmtime_component_resource_type_new_host(5);
      error = wasmtime_component_linker_instance_add_resource(host, "function-0cfd8b76dd97d47004a852b0", 33, type, lb_proxy_drop, session, NULL);
      wasmtime_component_resource_type_delete(type);
    }
    if (!error) {
      wasmtime_component_resource_type_t *type = wasmtime_component_resource_type_new_host(6);
      error = wasmtime_component_linker_instance_add_resource(host, "function-e8004d28621f9b553f4c83a6", 33, type, lb_proxy_drop, session, NULL);
      wasmtime_component_resource_type_delete(type);
    }
    if (!error) {
      wasmtime_component_resource_type_t *type = wasmtime_component_resource_type_new_host(7);
      error = wasmtime_component_linker_instance_add_resource(host, "function-4cf83a83d390acbc64c0ac23", 33, type, lb_proxy_drop, session, NULL);
      wasmtime_component_resource_type_delete(type);
    }
    if (!error) {
      wasmtime_component_resource_type_t *type = wasmtime_component_resource_type_new_host(8);
      error = wasmtime_component_linker_instance_add_resource(host, "function-3e61836c4ff1877794f5b42e", 33, type, lb_proxy_drop, session, NULL);
      wasmtime_component_resource_type_delete(type);
    }
    if (!error) error = wasmtime_component_linker_instance_add_func(host, "call-host", 9, lb_call_0, session, NULL);
    if (!error) error = wasmtime_component_linker_instance_add_func(host, "call-host-container", 19, lb_call_1, session, NULL);
    if (!error) error = wasmtime_component_linker_instance_add_func(host, "call-host-mixed", 15, lb_call_2, session, NULL);
    if (!error) error = wasmtime_component_linker_instance_add_func(host, "call-host-nested", 16, lb_call_3, session, NULL);
    if (!error) error = wasmtime_component_linker_instance_add_func(host, "make-closure", 12, lb_call_4, session, NULL);
    if (!error) error = wasmtime_component_linker_instance_add_func(host, "make-container-closure", 22, lb_call_5, session, NULL);
    if (!error) error = wasmtime_component_linker_instance_add_func(host, "make-mixed-closure", 18, lb_call_6, session, NULL);
    if (!error) error = wasmtime_component_linker_instance_add_func(host, "make-nested-closure", 19, lb_call_7, session, NULL);
    if (!error) error = wasmtime_component_linker_instance_add_func(host, "invoke-function-499c879a3d450f66047fcee3", 40, lb_call_8, session, NULL);
    if (!error) error = wasmtime_component_linker_instance_add_func(host, "invoke-function-14ccabf25ea1719eb709d075", 40, lb_call_9, session, NULL);
    if (!error) error = wasmtime_component_linker_instance_add_func(host, "invoke-function-be5c64001874227d88d0b54c", 40, lb_call_10, session, NULL);
    if (!error) error = wasmtime_component_linker_instance_add_func(host, "invoke-function-9ac1e60c77fb6fe8a7617d3a", 40, lb_call_11, session, NULL);
    if (!error) error = wasmtime_component_linker_instance_add_func(host, "invoke-function-0cfd8b76dd97d47004a852b0", 40, lb_call_12, session, NULL);
    if (!error) error = wasmtime_component_linker_instance_add_func(host, "invoke-function-e8004d28621f9b553f4c83a6", 40, lb_call_13, session, NULL);
    if (!error) error = wasmtime_component_linker_instance_add_func(host, "invoke-function-4cf83a83d390acbc64c0ac23", 40, lb_call_14, session, NULL);
    if (!error) error = wasmtime_component_linker_instance_add_func(host, "invoke-function-3e61836c4ff1877794f5b42e", 40, lb_call_15, session, NULL);
    wasmtime_component_linker_instance_delete(host);
  }
  wasmtime_component_linker_instance_delete(root); return error;
}
wasmtime_error_t *callbackcheckedrecords_wasmtime_link(wasmtime_component_linker_t *linker) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  (void)linker; return wasmtime_error_new("WIT callables require the owning session API");
}
static wasmtime_error_t *lb_refresh(callbackcheckedrecords_wasmtime *session) {
  if (session->store) wasmtime_store_delete(session->store);
  session->store = wasmtime_store_new(session->engine, NULL, NULL);
  wasmtime_error_t *error = wasmtime_component_linker_instantiate(session->linker, wasmtime_store_context(session->store), session->component, &session->instance);
  if (error) { wasmtime_store_delete(session->store); session->store = NULL; }
  return error;
}
static void lb_destroy(callbackcheckedrecords_wasmtime *session) {
  session->closing = true;
  for (size_t i = 0; i < LB_CAPACITY; ++i) { session->entries[i].closed = true; lb_entry_collect(&session->entries[i]); }
  if (session->linker) wasmtime_component_linker_delete(session->linker);
  if (session->store) wasmtime_store_delete(session->store);
  if (session->component) wasmtime_component_delete(session->component);
  if (session->engine) wasm_engine_delete(session->engine);
  free(session);
}
void callbackcheckedrecords_wasmtime_close(callbackcheckedrecords_wasmtime *session) {
  if (getpid() != lb_package_pid) return;
  if (!lb_thread(session)) return;
  session->closing = true;
  if (!session->depth) lb_destroy(session);
}
wasmtime_error_t *callbackcheckedrecords_wasmtime_open(callbackcheckedrecords_wasmtime **out) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(callbackcheckedrecords_wasmtime *)) || *out) return wasmtime_error_new("Session output requires a fresh initialized slot");
  if (callbackcheckedrecords_graph_initialize()) return wasmtime_error_new("Lean runtime is unavailable");
  callbackcheckedrecords_wasmtime *session = calloc(1, sizeof(*session));
  if (!session) return wasmtime_error_new("Cannot allocate Wasmtime session");
  session->thread = pthread_self(); session->process = getpid(); session->thread_serial = lb_thread_identity();
  if (!session->thread_serial) { free(session); return wasmtime_error_new("WIT thread identities exhausted"); }
  wasm_config_t *config = wasm_config_new();
  if (!config) { free(session); return wasmtime_error_new("Cannot allocate Wasmtime configuration"); }
  wasmtime_config_wasm_component_model_set(config, true);
  session->engine = wasm_engine_new_with_config(config);
  wasmtime_error_t *error = wasmtime_component_new(session->engine, lb_component, sizeof(lb_component), &session->component);
  if (!error) {
    session->linker = wasmtime_component_linker_new(session->engine);
    error = lb_link(session); if (!error) error = lb_refresh(session);
  }
  if (error) { lb_destroy(session); return error; }
  *out = session; return NULL;
}
wasmtime_error_t *callbackcheckedrecords_wasmtime_callback_create(callbackcheckedrecords_wasmtime *session, const char *signature,
    callbackcheckedrecords_wasmtime_callback callback, void *data, void (*release)(void *), callbackcheckedrecords_wasmtime_function *out) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  if (!lb_thread(session) || session->closing || !signature || !callback || !lb_buffer(out, 1, sizeof(*out), _Alignof(callbackcheckedrecords_wasmtime_function)) || *out)
    return wasmtime_error_new("Invalid WIT callback or wrong-thread session");
  if (!callbackcheckedrecords_graph_ready()) return wasmtime_error_new("Lean runtime is unavailable");
  uint32_t tag = 0;
  if (!strcmp(signature, "function-499c879a3d450f66047fcee3")) tag = 1;
  if (!strcmp(signature, "function-14ccabf25ea1719eb709d075")) tag = 2;
  if (!strcmp(signature, "function-be5c64001874227d88d0b54c")) tag = 3;
  if (!strcmp(signature, "function-9ac1e60c77fb6fe8a7617d3a")) tag = 4;
  if (!strcmp(signature, "function-0cfd8b76dd97d47004a852b0")) tag = 5;
  if (!strcmp(signature, "function-e8004d28621f9b553f4c83a6")) tag = 6;
  if (!strcmp(signature, "function-4cf83a83d390acbc64c0ac23")) tag = 7;
  if (!strcmp(signature, "function-3e61836c4ff1877794f5b42e")) tag = 8;
  if (!tag) return wasmtime_error_new("Unknown WIT callable signature");
  lb_entry *entry = lb_entry_new(session, tag);
  if (!entry) return wasmtime_error_new("WIT callable capacity exhausted");
  entry->callback = callback; entry->data = data; entry->release = release;
  *out = entry->token; return NULL;
}
wasmtime_error_t *callbackcheckedrecords_wasmtime_function_close(callbackcheckedrecords_wasmtime *session, callbackcheckedrecords_wasmtime_function *function) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  if (!lb_thread(session) || session->closing || !lb_buffer(function, 1, sizeof(*function), _Alignof(callbackcheckedrecords_wasmtime_function))) return wasmtime_error_new("Invalid WIT function close or wrong-thread session");
  if (!*function) return NULL;
  lb_entry *entry = lb_entry_find(session, *function);
  if (!entry) return wasmtime_error_new("Closed or wrong-session WIT callable");
  entry->closed = true; *function = 0; lb_entry_collect(entry); return NULL;
}
static int lb_export(const char *name) {
  if (!name) return -1;
  if (!strcmp(name, "call-host")) return 0;
  if (!strcmp(name, "call-host-container")) return 1;
  if (!strcmp(name, "call-host-mixed")) return 2;
  if (!strcmp(name, "call-host-nested")) return 3;
  if (!strcmp(name, "make-closure")) return 4;
  if (!strcmp(name, "make-container-closure")) return 5;
  if (!strcmp(name, "make-mixed-closure")) return 6;
  if (!strcmp(name, "make-nested-closure")) return 7;
  if (!strcmp(name, "invoke-function-499c879a3d450f66047fcee3")) return 8;
  if (!strcmp(name, "invoke-function-14ccabf25ea1719eb709d075")) return 9;
  if (!strcmp(name, "invoke-function-be5c64001874227d88d0b54c")) return 10;
  if (!strcmp(name, "invoke-function-9ac1e60c77fb6fe8a7617d3a")) return 11;
  if (!strcmp(name, "invoke-function-0cfd8b76dd97d47004a852b0")) return 12;
  if (!strcmp(name, "invoke-function-e8004d28621f9b553f4c83a6")) return 13;
  if (!strcmp(name, "invoke-function-4cf83a83d390acbc64c0ac23")) return 14;
  if (!strcmp(name, "invoke-function-3e61836c4ff1877794f5b42e")) return 15;
  return -1;
}
static const size_t lb_arities[] = {1,1,1,1,1,1,1,1,2,2,3,2,2,2,3,2};
static const uint32_t lb_returns[] = {0,0,0,0,5,6,7,8,0,0,0,0,0,0,0,0};
static const bool lb_copied[] = {false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false};
static bool lb_validate(callbackcheckedrecords_wasmtime *session, int function, const callbackcheckedrecords_wasmtime_value *args, lb_entry **entries) {
  lb_graph_scope scope = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  bool valid = false;
  (void)session; (void)args; (void)entries;
  switch (function) {
  case 0: valid = ((entries[0] = lb_entry_find(session, args[0].function)) && entries[0]->tag == 1 && entries[0]->recovery); break;
  case 1: valid = ((entries[0] = lb_entry_find(session, args[0].function)) && entries[0]->tag == 2 && entries[0]->recovery); break;
  case 2: valid = ((entries[0] = lb_entry_find(session, args[0].function)) && entries[0]->tag == 3 && entries[0]->recovery); break;
  case 3: valid = ((entries[0] = lb_entry_find(session, args[0].function)) && entries[0]->tag == 4 && entries[0]->recovery); break;
  case 4: valid = (!args[0].function && lb_graph_decode_5(&args[0].value, &scope, NULL)); break;
  case 5: valid = (!args[0].function && lb_graph_decode_5(&args[0].value, &scope, NULL)); break;
  case 6: valid = (!args[0].function && lb_graph_decode_5(&args[0].value, &scope, NULL)); break;
  case 7: valid = (!args[0].function && lb_graph_decode_5(&args[0].value, &scope, NULL)); break;
  case 8: valid = ((entries[0] = lb_entry_find(session, args[0].function)) && entries[0]->tag == 1 && entries[0]->recovery) && (!args[1].function && lb_graph_decode_3(&args[1].value, &scope, NULL)); break;
  case 9: valid = ((entries[0] = lb_entry_find(session, args[0].function)) && entries[0]->tag == 2 && entries[0]->recovery) && (!args[1].function && lb_graph_decode_0(&args[1].value, &scope, NULL)); break;
  case 10: valid = ((entries[0] = lb_entry_find(session, args[0].function)) && entries[0]->tag == 3 && entries[0]->recovery) && (!args[1].function && lb_graph_decode_5(&args[1].value, &scope, NULL)) && (!args[2].function && lb_graph_decode_3(&args[2].value, &scope, NULL)); break;
  case 11: valid = ((entries[0] = lb_entry_find(session, args[0].function)) && entries[0]->tag == 4 && entries[0]->recovery) && (!args[1].function && lb_graph_decode_4(&args[1].value, &scope, NULL)); break;
  case 12: valid = ((entries[0] = lb_entry_find(session, args[0].function)) && entries[0]->tag == 5) && (!args[1].function && lb_graph_decode_3(&args[1].value, &scope, NULL)); break;
  case 13: valid = ((entries[0] = lb_entry_find(session, args[0].function)) && entries[0]->tag == 6) && (!args[1].function && lb_graph_decode_1(&args[1].value, &scope, NULL)); break;
  case 14: valid = ((entries[0] = lb_entry_find(session, args[0].function)) && entries[0]->tag == 7) && (!args[1].function && lb_graph_decode_5(&args[1].value, &scope, NULL)) && (!args[2].function && lb_graph_decode_3(&args[2].value, &scope, NULL)); break;
  case 15: valid = ((entries[0] = lb_entry_find(session, args[0].function)) && entries[0]->tag == 8) && (!args[1].function && lb_graph_decode_4(&args[1].value, &scope, NULL)); break;
  default: break;
  }
  lb_scope_close(&scope.memory); return valid;
}
wasmtime_error_t *callbackcheckedrecords_wasmtime_invoke(callbackcheckedrecords_wasmtime *session, const char *name,
    const callbackcheckedrecords_wasmtime_value *args, size_t count, callbackcheckedrecords_wasmtime_value *out) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  if (!lb_thread(session) || session->closing || !out || (count && !args)) return wasmtime_error_new("Invalid WIT call or wrong-thread session");
  if (session->poisoned && session->depth) return wasmtime_error_new(session->first_error);
  int which = lb_export(name);
  if (which < 0 || count != lb_arities[which]) return wasmtime_error_new("Unknown WIT export or argument count");
  if (!lb_buffer(args, count, sizeof(*args), _Alignof(callbackcheckedrecords_wasmtime_value)) || !lb_buffer(out, 1, sizeof(*out), _Alignof(callbackcheckedrecords_wasmtime_value))) return wasmtime_error_new("Invalid WIT argument storage");
  lb_entry *entries[LB_MAX_ARGS] = {0};
  if (!lb_validate(session, which, args, entries)) return wasmtime_error_new("Invalid WIT input, closed/wrong-session callable, signature mismatch or conversion limit");
  if (session->depth == 64) return wasmtime_error_new("WIT callable reentry limit (64)");
  if (!session->depth) { session->poisoned = false; session->first_error[0] = 0; }
  wasmtime_error_t *error = NULL;
  if (!session->store && (error = lb_refresh(session))) return error;
  wasmtime_context_t *context = wasmtime_store_context(session->store);
  lb_frame frame = {.previous = session->frame, .thread_previous = lb_active_frame, .session = session}; session->frame = &frame; lb_active_frame = &frame; ++session->depth;
  wasmtime_component_val_t values[LB_MAX_ARGS] = {{0}}, result = {0};
  callbackcheckedrecords_wasmtime_value converted = {0};
  for (size_t i = 0; i < count; ++i) if (entries[i]) ++entries[i]->active;
  for (size_t i = 0; i < count; ++i) {
    if (entries[i]) { error = lb_proxy(session, context, entries[i], &values[i]); if (error) goto done; }
    else values[i] = args[i].value; /* Borrow copied inputs, never delete them. */
  }
  wasmtime_component_export_index_t *api = wasmtime_component_instance_get_export_index(&session->instance, context, NULL, "lean-bridge:callback-checked-records/api@1.0.0", 46);
  if (!api) { error = wasmtime_error_new("Missing WIT API export"); goto done; }
  wasmtime_component_export_index_t *index = wasmtime_component_instance_get_export_index(&session->instance, context, api, name, strlen(name));
  wasmtime_component_export_index_delete(api);
  if (!index) { error = wasmtime_error_new("Missing WIT function export"); goto done; }
  wasmtime_component_func_t function;
  bool found = wasmtime_component_instance_get_func(&session->instance, context, index, &function);
  wasmtime_component_export_index_delete(index);
  if (!found) { error = wasmtime_error_new("WIT export is not a function"); goto done; }
  error = wasmtime_component_func_call(&function, context, values, count, &result, 1);
  if (!error && !session->poisoned && !session->closing) {
    if (lb_returns[which]) {
      lb_entry *entry = NULL;
      error = lb_unwrap(session, context, &result, lb_returns[which], true, &entry);
      if (!error && entry != frame.pending) error = wasmtime_error_new("Unexpected WIT returned callable");
      if (!error) converted.function = entry->token;
    } else { converted.value = result; result = (wasmtime_component_val_t){0}; }
  }
done:
  if (error) { lb_record_error(session, error); wasmtime_error_delete(error); error = NULL; }
  /* A trapped borrow may not be removable. The outermost frame replaces the
   * poisoned store after every active native call has unwound. */
  for (size_t i = 0; i < count; ++i) if (entries[i]) {
    if (values[i].kind == WASMTIME_COMPONENT_RESOURCE && values[i].of.resource) {
      lb_entry *entry = NULL;
      wasmtime_error_t *cleanup = lb_unwrap(session, context, &values[i], entries[i]->tag, true, &entry);
      if (cleanup) { lb_record_error(session, cleanup); wasmtime_error_delete(cleanup); }
      wasmtime_component_val_delete(&values[i]);
    }
    --entries[i]->active; lb_entry_collect(entries[i]);
  }
  wasmtime_component_val_delete(&result);
  if (session->closing && !session->poisoned) lb_record_text(session, "WIT session closed during call", 30);
  if (session->poisoned) {
    wasmtime_component_val_delete(&converted.value);
    error = wasmtime_error_new(session->first_error);
    if (frame.pending) { frame.pending->closed = true; lb_entry_collect(frame.pending); }
  } else { *out = converted; frame.pending = NULL; }
  session->frame = frame.previous; lb_active_frame = frame.thread_previous; --session->depth;
  if (!session->depth) {
    if (session->closing) lb_destroy(session);
    else if (session->poisoned) {
      wasmtime_error_t *reset = lb_refresh(session); if (reset) wasmtime_error_delete(reset);
      session->poisoned = false;
    }
  }
  return error;
}
wasmtime_error_t *callbackcheckedrecords_wasmtime_call(callbackcheckedrecords_wasmtime *session, const char *name,
    const wasmtime_component_val_t *args, size_t count, wasmtime_component_val_t *out) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  int which = lb_export(name);
  if (!out || (count && !args) || which < 0 || !lb_copied[which] || count != lb_arities[which])
    return wasmtime_error_new("Use the checked WIT invoke API for callable exports");
  if (!lb_buffer(args, count, sizeof(*args), _Alignof(wasmtime_component_val_t)) || !lb_buffer(out, 1, sizeof(*out), _Alignof(wasmtime_component_val_t))) return wasmtime_error_new("Invalid WIT copied argument storage");
  callbackcheckedrecords_wasmtime_value values[LB_MAX_ARGS] = {0}, result = {0};
  for (size_t i = 0; i < count; ++i) values[i].value = args[i];
  wasmtime_error_t *error = callbackcheckedrecords_wasmtime_invoke(session, name, values, count, &result);
  if (!error) *out = result.value;
  return error;
}


wasmtime_error_t *callbackcheckedrecords_graph_38a8689c2f20ead532ea_t_wasmtime_copy(const callbackcheckedrecords_graph_38a8689c2f20ead532ea_t *value, callbackcheckedrecords_graph_38a8689c2f20ead532ea_t *out) {
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(callbackcheckedrecords_graph_38a8689c2f20ead532ea_t)) || out->_bridge_owner || out->_bridge_release) return wasmtime_error_new("Copied WIT result requires a fresh initialized slot");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  wasmtime_component_val_t wire = {0}; callbackcheckedrecords_graph_38a8689c2f20ead532ea_t converted = {0};
  wasmtime_error_t *failure = NULL;
  if (!lb_graph_encode_0(value, &input, &wire) || !lb_graph_decode_0(&wire, &output, &converted)) {
    failure = wasmtime_error_new("Invalid copied WIT value, conversion limit or allocation failure"); goto done;
  }
  converted._bridge_owner = output.memory.allocations; converted._bridge_release = output.memory.allocations ? lb_graph_release : NULL; output.memory.allocations = NULL;
  *out = converted;
done:
  wasmtime_component_val_delete(&wire); lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}

wasmtime_error_t *callbackcheckedrecords_graph_7ee21eb6b8ea120b53f0_t_wasmtime_copy(const callbackcheckedrecords_graph_7ee21eb6b8ea120b53f0_t *value, callbackcheckedrecords_graph_7ee21eb6b8ea120b53f0_t *out) {
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(callbackcheckedrecords_graph_7ee21eb6b8ea120b53f0_t)) || out->_bridge_owner || out->_bridge_release) return wasmtime_error_new("Copied WIT result requires a fresh initialized slot");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  wasmtime_component_val_t wire = {0}; callbackcheckedrecords_graph_7ee21eb6b8ea120b53f0_t converted = {0};
  wasmtime_error_t *failure = NULL;
  if (!lb_graph_encode_1(value, &input, &wire) || !lb_graph_decode_1(&wire, &output, &converted)) {
    failure = wasmtime_error_new("Invalid copied WIT value, conversion limit or allocation failure"); goto done;
  }
  converted._bridge_owner = output.memory.allocations; converted._bridge_release = output.memory.allocations ? lb_graph_release : NULL; output.memory.allocations = NULL;
  *out = converted;
done:
  wasmtime_component_val_delete(&wire); lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}

wasmtime_error_t *callbackcheckedrecords_graph_29468227bdfd05da1480_t_wasmtime_copy(const callbackcheckedrecords_graph_29468227bdfd05da1480_t *value, callbackcheckedrecords_graph_29468227bdfd05da1480_t *out) {
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(callbackcheckedrecords_graph_29468227bdfd05da1480_t)) || out->_bridge_owner || out->_bridge_release) return wasmtime_error_new("Copied WIT result requires a fresh initialized slot");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  wasmtime_component_val_t wire = {0}; callbackcheckedrecords_graph_29468227bdfd05da1480_t converted = {0};
  wasmtime_error_t *failure = NULL;
  if (!lb_graph_encode_2(value, &input, &wire) || !lb_graph_decode_2(&wire, &output, &converted)) {
    failure = wasmtime_error_new("Invalid copied WIT value, conversion limit or allocation failure"); goto done;
  }
  converted._bridge_owner = output.memory.allocations; converted._bridge_release = output.memory.allocations ? lb_graph_release : NULL; output.memory.allocations = NULL;
  *out = converted;
done:
  wasmtime_component_val_delete(&wire); lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}

wasmtime_error_t *callbackcheckedrecords_interval_t_wasmtime_copy(const callbackcheckedrecords_interval_t *value, callbackcheckedrecords_interval_t *out) {
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(callbackcheckedrecords_interval_t)) || out->_bridge_owner || out->_bridge_release) return wasmtime_error_new("Copied WIT result requires a fresh initialized slot");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  wasmtime_component_val_t wire = {0}; callbackcheckedrecords_interval_t converted = {0};
  wasmtime_error_t *failure = NULL;
  if (!lb_graph_encode_3(value, &input, &wire) || !lb_graph_decode_3(&wire, &output, &converted)) {
    failure = wasmtime_error_new("Invalid copied WIT value, conversion limit or allocation failure"); goto done;
  }
  converted._bridge_owner = output.memory.allocations; converted._bridge_release = output.memory.allocations ? lb_graph_release : NULL; output.memory.allocations = NULL;
  *out = converted;
done:
  wasmtime_component_val_delete(&wire); lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}

wasmtime_error_t *callbackcheckedrecords_weighted_t_wasmtime_copy(const callbackcheckedrecords_weighted_t *value, callbackcheckedrecords_weighted_t *out) {
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(callbackcheckedrecords_weighted_t)) || out->_bridge_owner || out->_bridge_release) return wasmtime_error_new("Copied WIT result requires a fresh initialized slot");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  wasmtime_component_val_t wire = {0}; callbackcheckedrecords_weighted_t converted = {0};
  wasmtime_error_t *failure = NULL;
  if (!lb_graph_encode_4(value, &input, &wire) || !lb_graph_decode_4(&wire, &output, &converted)) {
    failure = wasmtime_error_new("Invalid copied WIT value, conversion limit or allocation failure"); goto done;
  }
  converted._bridge_owner = output.memory.allocations; converted._bridge_release = output.memory.allocations ? lb_graph_release : NULL; output.memory.allocations = NULL;
  *out = converted;
done:
  wasmtime_component_val_delete(&wire); lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}

wasmtime_error_t *callbackcheckedrecords_scalar_nat_t_wasmtime_copy(const callbackcheckedrecords_scalar_nat_t *value, callbackcheckedrecords_scalar_nat_t *out) {
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(callbackcheckedrecords_scalar_nat_t)) || out->_bridge_owner || out->_bridge_release) return wasmtime_error_new("Copied WIT result requires a fresh initialized slot");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  wasmtime_component_val_t wire = {0}; callbackcheckedrecords_scalar_nat_t converted = {0};
  wasmtime_error_t *failure = NULL;
  if (!lb_graph_encode_5(value, &input, &wire) || !lb_graph_decode_5(&wire, &output, &converted)) {
    failure = wasmtime_error_new("Invalid copied WIT value, conversion limit or allocation failure"); goto done;
  }
  converted._bridge_owner = output.memory.allocations; converted._bridge_release = output.memory.allocations ? lb_graph_release : NULL; output.memory.allocations = NULL;
  *out = converted;
done:
  wasmtime_component_val_delete(&wire); lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}

wasmtime_error_t *callbackcheckedrecords_scalar_string_t_wasmtime_copy(const callbackcheckedrecords_scalar_string_t *value, callbackcheckedrecords_scalar_string_t *out) {
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(callbackcheckedrecords_scalar_string_t)) || out->_bridge_owner || out->_bridge_release) return wasmtime_error_new("Copied WIT result requires a fresh initialized slot");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  wasmtime_component_val_t wire = {0}; callbackcheckedrecords_scalar_string_t converted = {0};
  wasmtime_error_t *failure = NULL;
  if (!lb_graph_encode_6(value, &input, &wire) || !lb_graph_decode_6(&wire, &output, &converted)) {
    failure = wasmtime_error_new("Invalid copied WIT value, conversion limit or allocation failure"); goto done;
  }
  converted._bridge_owner = output.memory.allocations; converted._bridge_release = output.memory.allocations ? lb_graph_release : NULL; output.memory.allocations = NULL;
  *out = converted;
done:
  wasmtime_component_val_delete(&wire); lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}
wasmtime_error_t *callbackcheckedrecords_wasmtime_value_call_host(callbackcheckedrecords_wasmtime *session, callbackcheckedrecords_wasmtime_function arg0, callbackcheckedrecords_scalar_nat_t *out) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  if (!lb_thread(session) || session->closing) return wasmtime_error_new("Invalid typed WIT session or wrong thread");
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(callbackcheckedrecords_scalar_nat_t)) || out->_bridge_owner || out->_bridge_release) return wasmtime_error_new("Typed WIT result requires a fresh initialized slot");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  callbackcheckedrecords_wasmtime_value args[1] = {0}, value = {0};
  wasmtime_error_t *failure = NULL;
  callbackcheckedrecords_scalar_nat_t converted = {0};
  args[0].function = arg0;
  failure = callbackcheckedrecords_wasmtime_invoke(session, "call-host", args, 1, &value);
  if (failure) goto done;
  if (!lb_graph_decode_5(&value.value, &output, &converted)) {
    if (!output.memory.failure) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new(output.memory.failure ? "Typed WIT result conversion limit or allocation failure" : "Malformed WIT result; runtime retired"); goto done;
  }
  converted._bridge_owner = output.memory.allocations; converted._bridge_release = output.memory.allocations ? lb_graph_release : NULL; output.memory.allocations = NULL;
  *out = converted;
done:

  wasmtime_component_val_delete(&value.value); lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}

wasmtime_error_t *callbackcheckedrecords_wasmtime_value_call_host_container(callbackcheckedrecords_wasmtime *session, callbackcheckedrecords_wasmtime_function arg0, callbackcheckedrecords_scalar_nat_t *out) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  if (!lb_thread(session) || session->closing) return wasmtime_error_new("Invalid typed WIT session or wrong thread");
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(callbackcheckedrecords_scalar_nat_t)) || out->_bridge_owner || out->_bridge_release) return wasmtime_error_new("Typed WIT result requires a fresh initialized slot");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  callbackcheckedrecords_wasmtime_value args[1] = {0}, value = {0};
  wasmtime_error_t *failure = NULL;
  callbackcheckedrecords_scalar_nat_t converted = {0};
  args[0].function = arg0;
  failure = callbackcheckedrecords_wasmtime_invoke(session, "call-host-container", args, 1, &value);
  if (failure) goto done;
  if (!lb_graph_decode_5(&value.value, &output, &converted)) {
    if (!output.memory.failure) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new(output.memory.failure ? "Typed WIT result conversion limit or allocation failure" : "Malformed WIT result; runtime retired"); goto done;
  }
  converted._bridge_owner = output.memory.allocations; converted._bridge_release = output.memory.allocations ? lb_graph_release : NULL; output.memory.allocations = NULL;
  *out = converted;
done:

  wasmtime_component_val_delete(&value.value); lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}

wasmtime_error_t *callbackcheckedrecords_wasmtime_value_call_host_mixed(callbackcheckedrecords_wasmtime *session, callbackcheckedrecords_wasmtime_function arg0, callbackcheckedrecords_scalar_nat_t *out) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  if (!lb_thread(session) || session->closing) return wasmtime_error_new("Invalid typed WIT session or wrong thread");
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(callbackcheckedrecords_scalar_nat_t)) || out->_bridge_owner || out->_bridge_release) return wasmtime_error_new("Typed WIT result requires a fresh initialized slot");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  callbackcheckedrecords_wasmtime_value args[1] = {0}, value = {0};
  wasmtime_error_t *failure = NULL;
  callbackcheckedrecords_scalar_nat_t converted = {0};
  args[0].function = arg0;
  failure = callbackcheckedrecords_wasmtime_invoke(session, "call-host-mixed", args, 1, &value);
  if (failure) goto done;
  if (!lb_graph_decode_5(&value.value, &output, &converted)) {
    if (!output.memory.failure) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new(output.memory.failure ? "Typed WIT result conversion limit or allocation failure" : "Malformed WIT result; runtime retired"); goto done;
  }
  converted._bridge_owner = output.memory.allocations; converted._bridge_release = output.memory.allocations ? lb_graph_release : NULL; output.memory.allocations = NULL;
  *out = converted;
done:

  wasmtime_component_val_delete(&value.value); lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}

wasmtime_error_t *callbackcheckedrecords_wasmtime_value_call_host_nested(callbackcheckedrecords_wasmtime *session, callbackcheckedrecords_wasmtime_function arg0, callbackcheckedrecords_scalar_nat_t *out) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  if (!lb_thread(session) || session->closing) return wasmtime_error_new("Invalid typed WIT session or wrong thread");
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(callbackcheckedrecords_scalar_nat_t)) || out->_bridge_owner || out->_bridge_release) return wasmtime_error_new("Typed WIT result requires a fresh initialized slot");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  callbackcheckedrecords_wasmtime_value args[1] = {0}, value = {0};
  wasmtime_error_t *failure = NULL;
  callbackcheckedrecords_scalar_nat_t converted = {0};
  args[0].function = arg0;
  failure = callbackcheckedrecords_wasmtime_invoke(session, "call-host-nested", args, 1, &value);
  if (failure) goto done;
  if (!lb_graph_decode_5(&value.value, &output, &converted)) {
    if (!output.memory.failure) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new(output.memory.failure ? "Typed WIT result conversion limit or allocation failure" : "Malformed WIT result; runtime retired"); goto done;
  }
  converted._bridge_owner = output.memory.allocations; converted._bridge_release = output.memory.allocations ? lb_graph_release : NULL; output.memory.allocations = NULL;
  *out = converted;
done:

  wasmtime_component_val_delete(&value.value); lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}

wasmtime_error_t *callbackcheckedrecords_wasmtime_value_make_closure(callbackcheckedrecords_wasmtime *session, const callbackcheckedrecords_scalar_nat_t *arg0, callbackcheckedrecords_wasmtime_function *out) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  if (!lb_thread(session) || session->closing) return wasmtime_error_new("Invalid typed WIT session or wrong thread");
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(callbackcheckedrecords_wasmtime_function)) || *out) return wasmtime_error_new("Typed WIT result requires a fresh initialized slot");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  callbackcheckedrecords_wasmtime_value args[1] = {0}, value = {0};
  wasmtime_error_t *failure = NULL;

  if (!lb_graph_encode_5(arg0, &input, &args[0].value)) { failure = wasmtime_error_new("Invalid typed WIT input, conversion limit or allocation failure"); goto done; }
  failure = callbackcheckedrecords_wasmtime_invoke(session, "make-closure", args, 1, &value);
  if (failure) goto done;
  *out = value.function;
done:
  wasmtime_component_val_delete(&args[0].value);
  wasmtime_component_val_delete(&value.value); lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}

wasmtime_error_t *callbackcheckedrecords_wasmtime_value_make_container_closure(callbackcheckedrecords_wasmtime *session, const callbackcheckedrecords_scalar_nat_t *arg0, callbackcheckedrecords_wasmtime_function *out) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  if (!lb_thread(session) || session->closing) return wasmtime_error_new("Invalid typed WIT session or wrong thread");
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(callbackcheckedrecords_wasmtime_function)) || *out) return wasmtime_error_new("Typed WIT result requires a fresh initialized slot");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  callbackcheckedrecords_wasmtime_value args[1] = {0}, value = {0};
  wasmtime_error_t *failure = NULL;

  if (!lb_graph_encode_5(arg0, &input, &args[0].value)) { failure = wasmtime_error_new("Invalid typed WIT input, conversion limit or allocation failure"); goto done; }
  failure = callbackcheckedrecords_wasmtime_invoke(session, "make-container-closure", args, 1, &value);
  if (failure) goto done;
  *out = value.function;
done:
  wasmtime_component_val_delete(&args[0].value);
  wasmtime_component_val_delete(&value.value); lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}

wasmtime_error_t *callbackcheckedrecords_wasmtime_value_make_mixed_closure(callbackcheckedrecords_wasmtime *session, const callbackcheckedrecords_scalar_nat_t *arg0, callbackcheckedrecords_wasmtime_function *out) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  if (!lb_thread(session) || session->closing) return wasmtime_error_new("Invalid typed WIT session or wrong thread");
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(callbackcheckedrecords_wasmtime_function)) || *out) return wasmtime_error_new("Typed WIT result requires a fresh initialized slot");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  callbackcheckedrecords_wasmtime_value args[1] = {0}, value = {0};
  wasmtime_error_t *failure = NULL;

  if (!lb_graph_encode_5(arg0, &input, &args[0].value)) { failure = wasmtime_error_new("Invalid typed WIT input, conversion limit or allocation failure"); goto done; }
  failure = callbackcheckedrecords_wasmtime_invoke(session, "make-mixed-closure", args, 1, &value);
  if (failure) goto done;
  *out = value.function;
done:
  wasmtime_component_val_delete(&args[0].value);
  wasmtime_component_val_delete(&value.value); lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}

wasmtime_error_t *callbackcheckedrecords_wasmtime_value_make_nested_closure(callbackcheckedrecords_wasmtime *session, const callbackcheckedrecords_scalar_nat_t *arg0, callbackcheckedrecords_wasmtime_function *out) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  if (!lb_thread(session) || session->closing) return wasmtime_error_new("Invalid typed WIT session or wrong thread");
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(callbackcheckedrecords_wasmtime_function)) || *out) return wasmtime_error_new("Typed WIT result requires a fresh initialized slot");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  callbackcheckedrecords_wasmtime_value args[1] = {0}, value = {0};
  wasmtime_error_t *failure = NULL;

  if (!lb_graph_encode_5(arg0, &input, &args[0].value)) { failure = wasmtime_error_new("Invalid typed WIT input, conversion limit or allocation failure"); goto done; }
  failure = callbackcheckedrecords_wasmtime_invoke(session, "make-nested-closure", args, 1, &value);
  if (failure) goto done;
  *out = value.function;
done:
  wasmtime_component_val_delete(&args[0].value);
  wasmtime_component_val_delete(&value.value); lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}

wasmtime_error_t *callbackcheckedrecords_wasmtime_function_callback96775311ba874014bff2_call(callbackcheckedrecords_wasmtime *session, callbackcheckedrecords_wasmtime_function arg0, const callbackcheckedrecords_interval_t *arg1, callbackcheckedrecords_interval_t *out) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  if (!lb_thread(session) || session->closing) return wasmtime_error_new("Invalid typed WIT session or wrong thread");
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(callbackcheckedrecords_interval_t)) || out->_bridge_owner || out->_bridge_release) return wasmtime_error_new("Typed WIT result requires a fresh initialized slot");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  callbackcheckedrecords_wasmtime_value args[2] = {0}, value = {0};
  wasmtime_error_t *failure = NULL;
  callbackcheckedrecords_interval_t converted = {0};
  args[0].function = arg0;
  if (!lb_graph_encode_3(arg1, &input, &args[1].value)) { failure = wasmtime_error_new("Invalid typed WIT input, conversion limit or allocation failure"); goto done; }
  failure = callbackcheckedrecords_wasmtime_invoke(session, "invoke-function-499c879a3d450f66047fcee3", args, 2, &value);
  if (failure) goto done;
  if (!lb_graph_decode_3(&value.value, &output, &converted)) {
    if (!output.memory.failure) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new(output.memory.failure ? "Typed WIT result conversion limit or allocation failure" : "Malformed WIT result; runtime retired"); goto done;
  }
  converted._bridge_owner = output.memory.allocations; converted._bridge_release = output.memory.allocations ? lb_graph_release : NULL; output.memory.allocations = NULL;
  *out = converted;
done:
  wasmtime_component_val_delete(&args[1].value);
  wasmtime_component_val_delete(&value.value); lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}

wasmtime_error_t *callbackcheckedrecords_wasmtime_function_callback115f6922f8f3e5b91c8e_call(callbackcheckedrecords_wasmtime *session, callbackcheckedrecords_wasmtime_function arg0, const callbackcheckedrecords_graph_38a8689c2f20ead532ea_t *arg1, callbackcheckedrecords_graph_29468227bdfd05da1480_t *out) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  if (!lb_thread(session) || session->closing) return wasmtime_error_new("Invalid typed WIT session or wrong thread");
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(callbackcheckedrecords_graph_29468227bdfd05da1480_t)) || out->_bridge_owner || out->_bridge_release) return wasmtime_error_new("Typed WIT result requires a fresh initialized slot");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  callbackcheckedrecords_wasmtime_value args[2] = {0}, value = {0};
  wasmtime_error_t *failure = NULL;
  callbackcheckedrecords_graph_29468227bdfd05da1480_t converted = {0};
  args[0].function = arg0;
  if (!lb_graph_encode_0(arg1, &input, &args[1].value)) { failure = wasmtime_error_new("Invalid typed WIT input, conversion limit or allocation failure"); goto done; }
  failure = callbackcheckedrecords_wasmtime_invoke(session, "invoke-function-14ccabf25ea1719eb709d075", args, 2, &value);
  if (failure) goto done;
  if (!lb_graph_decode_2(&value.value, &output, &converted)) {
    if (!output.memory.failure) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new(output.memory.failure ? "Typed WIT result conversion limit or allocation failure" : "Malformed WIT result; runtime retired"); goto done;
  }
  converted._bridge_owner = output.memory.allocations; converted._bridge_release = output.memory.allocations ? lb_graph_release : NULL; output.memory.allocations = NULL;
  *out = converted;
done:
  wasmtime_component_val_delete(&args[1].value);
  wasmtime_component_val_delete(&value.value); lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}

wasmtime_error_t *callbackcheckedrecords_wasmtime_function_callback44d43ec6a49b0f13f8ab_call(callbackcheckedrecords_wasmtime *session, callbackcheckedrecords_wasmtime_function arg0, const callbackcheckedrecords_scalar_nat_t *arg1, const callbackcheckedrecords_interval_t *arg2, callbackcheckedrecords_interval_t *out) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  if (!lb_thread(session) || session->closing) return wasmtime_error_new("Invalid typed WIT session or wrong thread");
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(callbackcheckedrecords_interval_t)) || out->_bridge_owner || out->_bridge_release) return wasmtime_error_new("Typed WIT result requires a fresh initialized slot");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  callbackcheckedrecords_wasmtime_value args[3] = {0}, value = {0};
  wasmtime_error_t *failure = NULL;
  callbackcheckedrecords_interval_t converted = {0};
  args[0].function = arg0;
  if (!lb_graph_encode_5(arg1, &input, &args[1].value)) { failure = wasmtime_error_new("Invalid typed WIT input, conversion limit or allocation failure"); goto done; }
  if (!lb_graph_encode_3(arg2, &input, &args[2].value)) { failure = wasmtime_error_new("Invalid typed WIT input, conversion limit or allocation failure"); goto done; }
  failure = callbackcheckedrecords_wasmtime_invoke(session, "invoke-function-be5c64001874227d88d0b54c", args, 3, &value);
  if (failure) goto done;
  if (!lb_graph_decode_3(&value.value, &output, &converted)) {
    if (!output.memory.failure) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new(output.memory.failure ? "Typed WIT result conversion limit or allocation failure" : "Malformed WIT result; runtime retired"); goto done;
  }
  converted._bridge_owner = output.memory.allocations; converted._bridge_release = output.memory.allocations ? lb_graph_release : NULL; output.memory.allocations = NULL;
  *out = converted;
done:
  wasmtime_component_val_delete(&args[1].value);
  wasmtime_component_val_delete(&args[2].value);
  wasmtime_component_val_delete(&value.value); lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}

wasmtime_error_t *callbackcheckedrecords_wasmtime_function_callbackb782f62c1be9d8b0085a_call(callbackcheckedrecords_wasmtime *session, callbackcheckedrecords_wasmtime_function arg0, const callbackcheckedrecords_weighted_t *arg1, callbackcheckedrecords_weighted_t *out) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  if (!lb_thread(session) || session->closing) return wasmtime_error_new("Invalid typed WIT session or wrong thread");
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(callbackcheckedrecords_weighted_t)) || out->_bridge_owner || out->_bridge_release) return wasmtime_error_new("Typed WIT result requires a fresh initialized slot");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  callbackcheckedrecords_wasmtime_value args[2] = {0}, value = {0};
  wasmtime_error_t *failure = NULL;
  callbackcheckedrecords_weighted_t converted = {0};
  args[0].function = arg0;
  if (!lb_graph_encode_4(arg1, &input, &args[1].value)) { failure = wasmtime_error_new("Invalid typed WIT input, conversion limit or allocation failure"); goto done; }
  failure = callbackcheckedrecords_wasmtime_invoke(session, "invoke-function-9ac1e60c77fb6fe8a7617d3a", args, 2, &value);
  if (failure) goto done;
  if (!lb_graph_decode_4(&value.value, &output, &converted)) {
    if (!output.memory.failure) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new(output.memory.failure ? "Typed WIT result conversion limit or allocation failure" : "Malformed WIT result; runtime retired"); goto done;
  }
  converted._bridge_owner = output.memory.allocations; converted._bridge_release = output.memory.allocations ? lb_graph_release : NULL; output.memory.allocations = NULL;
  *out = converted;
done:
  wasmtime_component_val_delete(&args[1].value);
  wasmtime_component_val_delete(&value.value); lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}

wasmtime_error_t *callbackcheckedrecords_wasmtime_function_callback705cd2e64f6f37b7b3c5_call(callbackcheckedrecords_wasmtime *session, callbackcheckedrecords_wasmtime_function arg0, const callbackcheckedrecords_interval_t *arg1, callbackcheckedrecords_scalar_nat_t *out) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  if (!lb_thread(session) || session->closing) return wasmtime_error_new("Invalid typed WIT session or wrong thread");
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(callbackcheckedrecords_scalar_nat_t)) || out->_bridge_owner || out->_bridge_release) return wasmtime_error_new("Typed WIT result requires a fresh initialized slot");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  callbackcheckedrecords_wasmtime_value args[2] = {0}, value = {0};
  wasmtime_error_t *failure = NULL;
  callbackcheckedrecords_scalar_nat_t converted = {0};
  args[0].function = arg0;
  if (!lb_graph_encode_3(arg1, &input, &args[1].value)) { failure = wasmtime_error_new("Invalid typed WIT input, conversion limit or allocation failure"); goto done; }
  failure = callbackcheckedrecords_wasmtime_invoke(session, "invoke-function-0cfd8b76dd97d47004a852b0", args, 2, &value);
  if (failure) goto done;
  if (!lb_graph_decode_5(&value.value, &output, &converted)) {
    if (!output.memory.failure) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new(output.memory.failure ? "Typed WIT result conversion limit or allocation failure" : "Malformed WIT result; runtime retired"); goto done;
  }
  converted._bridge_owner = output.memory.allocations; converted._bridge_release = output.memory.allocations ? lb_graph_release : NULL; output.memory.allocations = NULL;
  *out = converted;
done:
  wasmtime_component_val_delete(&args[1].value);
  wasmtime_component_val_delete(&value.value); lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}

wasmtime_error_t *callbackcheckedrecords_wasmtime_function_callbacke974ad5f8e66387c6d39_call(callbackcheckedrecords_wasmtime *session, callbackcheckedrecords_wasmtime_function arg0, const callbackcheckedrecords_graph_7ee21eb6b8ea120b53f0_t *arg1, callbackcheckedrecords_graph_38a8689c2f20ead532ea_t *out) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  if (!lb_thread(session) || session->closing) return wasmtime_error_new("Invalid typed WIT session or wrong thread");
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(callbackcheckedrecords_graph_38a8689c2f20ead532ea_t)) || out->_bridge_owner || out->_bridge_release) return wasmtime_error_new("Typed WIT result requires a fresh initialized slot");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  callbackcheckedrecords_wasmtime_value args[2] = {0}, value = {0};
  wasmtime_error_t *failure = NULL;
  callbackcheckedrecords_graph_38a8689c2f20ead532ea_t converted = {0};
  args[0].function = arg0;
  if (!lb_graph_encode_1(arg1, &input, &args[1].value)) { failure = wasmtime_error_new("Invalid typed WIT input, conversion limit or allocation failure"); goto done; }
  failure = callbackcheckedrecords_wasmtime_invoke(session, "invoke-function-e8004d28621f9b553f4c83a6", args, 2, &value);
  if (failure) goto done;
  if (!lb_graph_decode_0(&value.value, &output, &converted)) {
    if (!output.memory.failure) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new(output.memory.failure ? "Typed WIT result conversion limit or allocation failure" : "Malformed WIT result; runtime retired"); goto done;
  }
  converted._bridge_owner = output.memory.allocations; converted._bridge_release = output.memory.allocations ? lb_graph_release : NULL; output.memory.allocations = NULL;
  *out = converted;
done:
  wasmtime_component_val_delete(&args[1].value);
  wasmtime_component_val_delete(&value.value); lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}

wasmtime_error_t *callbackcheckedrecords_wasmtime_function_callbacke7252f0aa280ee0b13ec_call(callbackcheckedrecords_wasmtime *session, callbackcheckedrecords_wasmtime_function arg0, const callbackcheckedrecords_scalar_nat_t *arg1, const callbackcheckedrecords_interval_t *arg2, callbackcheckedrecords_interval_t *out) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  if (!lb_thread(session) || session->closing) return wasmtime_error_new("Invalid typed WIT session or wrong thread");
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(callbackcheckedrecords_interval_t)) || out->_bridge_owner || out->_bridge_release) return wasmtime_error_new("Typed WIT result requires a fresh initialized slot");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  callbackcheckedrecords_wasmtime_value args[3] = {0}, value = {0};
  wasmtime_error_t *failure = NULL;
  callbackcheckedrecords_interval_t converted = {0};
  args[0].function = arg0;
  if (!lb_graph_encode_5(arg1, &input, &args[1].value)) { failure = wasmtime_error_new("Invalid typed WIT input, conversion limit or allocation failure"); goto done; }
  if (!lb_graph_encode_3(arg2, &input, &args[2].value)) { failure = wasmtime_error_new("Invalid typed WIT input, conversion limit or allocation failure"); goto done; }
  failure = callbackcheckedrecords_wasmtime_invoke(session, "invoke-function-4cf83a83d390acbc64c0ac23", args, 3, &value);
  if (failure) goto done;
  if (!lb_graph_decode_3(&value.value, &output, &converted)) {
    if (!output.memory.failure) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new(output.memory.failure ? "Typed WIT result conversion limit or allocation failure" : "Malformed WIT result; runtime retired"); goto done;
  }
  converted._bridge_owner = output.memory.allocations; converted._bridge_release = output.memory.allocations ? lb_graph_release : NULL; output.memory.allocations = NULL;
  *out = converted;
done:
  wasmtime_component_val_delete(&args[1].value);
  wasmtime_component_val_delete(&args[2].value);
  wasmtime_component_val_delete(&value.value); lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}

wasmtime_error_t *callbackcheckedrecords_wasmtime_function_callback9edd7fa9a1ed11043b7d_call(callbackcheckedrecords_wasmtime *session, callbackcheckedrecords_wasmtime_function arg0, const callbackcheckedrecords_weighted_t *arg1, callbackcheckedrecords_scalar_nat_t *out) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  if (!lb_thread(session) || session->closing) return wasmtime_error_new("Invalid typed WIT session or wrong thread");
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(callbackcheckedrecords_scalar_nat_t)) || out->_bridge_owner || out->_bridge_release) return wasmtime_error_new("Typed WIT result requires a fresh initialized slot");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  callbackcheckedrecords_wasmtime_value args[2] = {0}, value = {0};
  wasmtime_error_t *failure = NULL;
  callbackcheckedrecords_scalar_nat_t converted = {0};
  args[0].function = arg0;
  if (!lb_graph_encode_4(arg1, &input, &args[1].value)) { failure = wasmtime_error_new("Invalid typed WIT input, conversion limit or allocation failure"); goto done; }
  failure = callbackcheckedrecords_wasmtime_invoke(session, "invoke-function-3e61836c4ff1877794f5b42e", args, 2, &value);
  if (failure) goto done;
  if (!lb_graph_decode_5(&value.value, &output, &converted)) {
    if (!output.memory.failure) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new(output.memory.failure ? "Typed WIT result conversion limit or allocation failure" : "Malformed WIT result; runtime retired"); goto done;
  }
  converted._bridge_owner = output.memory.allocations; converted._bridge_release = output.memory.allocations ? lb_graph_release : NULL; output.memory.allocations = NULL;
  *out = converted;
done:
  wasmtime_component_val_delete(&args[1].value);
  wasmtime_component_val_delete(&value.value); lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}
typedef struct { callbackcheckedrecords_wasmtime_callback_callback115f6922f8f3e5b91c8e_fn callback; void *data; void (*release)(void *); callbackcheckedrecords_graph_29468227bdfd05da1480_t recovery; } callbackcheckedrecords_wasmtime_callback_callback115f6922f8f3e5b91c8e_context;
static void callbackcheckedrecords_wasmtime_callback_callback115f6922f8f3e5b91c8e_release(void *data) {
  callbackcheckedrecords_wasmtime_callback_callback115f6922f8f3e5b91c8e_context *context = data;
  if (context->release) context->release(context->data);
  callbackcheckedrecords_graph_29468227bdfd05da1480_t_clear(&context->recovery);
  free(context);
}
static wasmtime_error_t *callbackcheckedrecords_wasmtime_callback_callback115f6922f8f3e5b91c8e_invoke(void *data, const wasmtime_component_val_t *args, size_t count, wasmtime_component_val_t *out) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  callbackcheckedrecords_wasmtime_callback_callback115f6922f8f3e5b91c8e_context *context = data;
  if (count != 1) return wasmtime_error_new("Typed WIT callback arity mismatch");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  wasmtime_error_t *failure = NULL;
  callbackcheckedrecords_graph_29468227bdfd05da1480_t value = {0};
  callbackcheckedrecords_graph_38a8689c2f20ead532ea_t arg0 = {0};
  if (!lb_graph_decode_0(&args[0], &input, &arg0)) { failure = wasmtime_error_new("Invalid typed WIT callback input, conversion limit or allocation failure"); goto done; }
  failure = context->callback(context->data, &arg0, &value);
  if (failure) goto done;
  if (!lb_graph_encode_2(&value, &output, out)) failure = wasmtime_error_new("Invalid typed WIT callback result, conversion limit or allocation failure");
done:
  callbackcheckedrecords_graph_29468227bdfd05da1480_t_clear(&value);
  lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}
wasmtime_error_t *callbackcheckedrecords_wasmtime_callback_callback115f6922f8f3e5b91c8e_create(callbackcheckedrecords_wasmtime *session, callbackcheckedrecords_wasmtime_callback_callback115f6922f8f3e5b91c8e_fn callback, void *data, void (*release)(void *), const callbackcheckedrecords_graph_29468227bdfd05da1480_t *recovery, callbackcheckedrecords_wasmtime_function *out) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  if (!callback || !lb_thread(session) || session->closing || !lb_buffer(recovery, 1, sizeof(*recovery), _Alignof(callbackcheckedrecords_graph_29468227bdfd05da1480_t)) || !lb_buffer(out, 1, sizeof(*out), _Alignof(callbackcheckedrecords_wasmtime_function)) || *out) return wasmtime_error_new("Invalid typed WIT callback registration");
  callbackcheckedrecords_wasmtime_callback_callback115f6922f8f3e5b91c8e_context *context = malloc(sizeof(*context));
  if (!context) return wasmtime_error_new("Cannot allocate typed WIT callback context");
  *context = (callbackcheckedrecords_wasmtime_callback_callback115f6922f8f3e5b91c8e_context){.callback = callback, .data = data, .release = release};
  wasmtime_error_t *failure = NULL;
  failure = callbackcheckedrecords_graph_29468227bdfd05da1480_t_wasmtime_copy(recovery, &context->recovery);
  if (failure) { free(context); return failure; }
  failure = callbackcheckedrecords_wasmtime_callback_create(session, "function-14ccabf25ea1719eb709d075", callbackcheckedrecords_wasmtime_callback_callback115f6922f8f3e5b91c8e_invoke, context, callbackcheckedrecords_wasmtime_callback_callback115f6922f8f3e5b91c8e_release, out);
  if (failure) { callbackcheckedrecords_graph_29468227bdfd05da1480_t_clear(&context->recovery); free(context); }
  else {
    lb_entry *entry = lb_entry_find(session, *out);
    if (!entry) { failure = wasmtime_error_new("Missing typed WIT callback recovery owner"); callbackcheckedrecords_wasmtime_function_close(session, out); }
    else entry->recovery = &context->recovery;
  }
  return failure;
}

typedef struct { callbackcheckedrecords_wasmtime_callback_callback44d43ec6a49b0f13f8ab_fn callback; void *data; void (*release)(void *); callbackcheckedrecords_interval_t recovery; } callbackcheckedrecords_wasmtime_callback_callback44d43ec6a49b0f13f8ab_context;
static void callbackcheckedrecords_wasmtime_callback_callback44d43ec6a49b0f13f8ab_release(void *data) {
  callbackcheckedrecords_wasmtime_callback_callback44d43ec6a49b0f13f8ab_context *context = data;
  if (context->release) context->release(context->data);
  callbackcheckedrecords_interval_t_clear(&context->recovery);
  free(context);
}
static wasmtime_error_t *callbackcheckedrecords_wasmtime_callback_callback44d43ec6a49b0f13f8ab_invoke(void *data, const wasmtime_component_val_t *args, size_t count, wasmtime_component_val_t *out) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  callbackcheckedrecords_wasmtime_callback_callback44d43ec6a49b0f13f8ab_context *context = data;
  if (count != 2) return wasmtime_error_new("Typed WIT callback arity mismatch");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  wasmtime_error_t *failure = NULL;
  callbackcheckedrecords_interval_t value = {0};
  callbackcheckedrecords_scalar_nat_t arg0 = {0};
  callbackcheckedrecords_interval_t arg1 = {0};
  if (!lb_graph_decode_5(&args[0], &input, &arg0)) { failure = wasmtime_error_new("Invalid typed WIT callback input, conversion limit or allocation failure"); goto done; }
  if (!lb_graph_decode_3(&args[1], &input, &arg1)) { failure = wasmtime_error_new("Invalid typed WIT callback input, conversion limit or allocation failure"); goto done; }
  failure = context->callback(context->data, &arg0, &arg1, &value);
  if (failure) goto done;
  if (!lb_graph_encode_3(&value, &output, out)) failure = wasmtime_error_new("Invalid typed WIT callback result, conversion limit or allocation failure");
done:
  callbackcheckedrecords_interval_t_clear(&value);
  lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}
wasmtime_error_t *callbackcheckedrecords_wasmtime_callback_callback44d43ec6a49b0f13f8ab_create(callbackcheckedrecords_wasmtime *session, callbackcheckedrecords_wasmtime_callback_callback44d43ec6a49b0f13f8ab_fn callback, void *data, void (*release)(void *), const callbackcheckedrecords_interval_t *recovery, callbackcheckedrecords_wasmtime_function *out) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  if (!callback || !lb_thread(session) || session->closing || !lb_buffer(recovery, 1, sizeof(*recovery), _Alignof(callbackcheckedrecords_interval_t)) || !lb_buffer(out, 1, sizeof(*out), _Alignof(callbackcheckedrecords_wasmtime_function)) || *out) return wasmtime_error_new("Invalid typed WIT callback registration");
  callbackcheckedrecords_wasmtime_callback_callback44d43ec6a49b0f13f8ab_context *context = malloc(sizeof(*context));
  if (!context) return wasmtime_error_new("Cannot allocate typed WIT callback context");
  *context = (callbackcheckedrecords_wasmtime_callback_callback44d43ec6a49b0f13f8ab_context){.callback = callback, .data = data, .release = release};
  wasmtime_error_t *failure = NULL;
  failure = callbackcheckedrecords_interval_t_wasmtime_copy(recovery, &context->recovery);
  if (failure) { free(context); return failure; }
  failure = callbackcheckedrecords_wasmtime_callback_create(session, "function-be5c64001874227d88d0b54c", callbackcheckedrecords_wasmtime_callback_callback44d43ec6a49b0f13f8ab_invoke, context, callbackcheckedrecords_wasmtime_callback_callback44d43ec6a49b0f13f8ab_release, out);
  if (failure) { callbackcheckedrecords_interval_t_clear(&context->recovery); free(context); }
  else {
    lb_entry *entry = lb_entry_find(session, *out);
    if (!entry) { failure = wasmtime_error_new("Missing typed WIT callback recovery owner"); callbackcheckedrecords_wasmtime_function_close(session, out); }
    else entry->recovery = &context->recovery;
  }
  return failure;
}

typedef struct { callbackcheckedrecords_wasmtime_callback_callback705cd2e64f6f37b7b3c5_fn callback; void *data; void (*release)(void *); } callbackcheckedrecords_wasmtime_callback_callback705cd2e64f6f37b7b3c5_context;
static void callbackcheckedrecords_wasmtime_callback_callback705cd2e64f6f37b7b3c5_release(void *data) {
  callbackcheckedrecords_wasmtime_callback_callback705cd2e64f6f37b7b3c5_context *context = data;
  if (context->release) context->release(context->data);
  
  free(context);
}
static wasmtime_error_t *callbackcheckedrecords_wasmtime_callback_callback705cd2e64f6f37b7b3c5_invoke(void *data, const wasmtime_component_val_t *args, size_t count, wasmtime_component_val_t *out) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  callbackcheckedrecords_wasmtime_callback_callback705cd2e64f6f37b7b3c5_context *context = data;
  if (count != 1) return wasmtime_error_new("Typed WIT callback arity mismatch");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  wasmtime_error_t *failure = NULL;
  callbackcheckedrecords_scalar_nat_t value = {0};
  callbackcheckedrecords_interval_t arg0 = {0};
  if (!lb_graph_decode_3(&args[0], &input, &arg0)) { failure = wasmtime_error_new("Invalid typed WIT callback input, conversion limit or allocation failure"); goto done; }
  failure = context->callback(context->data, &arg0, &value);
  if (failure) goto done;
  if (!lb_graph_encode_5(&value, &output, out)) failure = wasmtime_error_new("Invalid typed WIT callback result, conversion limit or allocation failure");
done:
  callbackcheckedrecords_scalar_nat_t_clear(&value);
  lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}
wasmtime_error_t *callbackcheckedrecords_wasmtime_callback_callback705cd2e64f6f37b7b3c5_create(callbackcheckedrecords_wasmtime *session, callbackcheckedrecords_wasmtime_callback_callback705cd2e64f6f37b7b3c5_fn callback, void *data, void (*release)(void *), callbackcheckedrecords_wasmtime_function *out) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  if (!callback || !lb_thread(session) || session->closing || !lb_buffer(out, 1, sizeof(*out), _Alignof(callbackcheckedrecords_wasmtime_function)) || *out) return wasmtime_error_new("Invalid typed WIT callback registration");
  callbackcheckedrecords_wasmtime_callback_callback705cd2e64f6f37b7b3c5_context *context = malloc(sizeof(*context));
  if (!context) return wasmtime_error_new("Cannot allocate typed WIT callback context");
  *context = (callbackcheckedrecords_wasmtime_callback_callback705cd2e64f6f37b7b3c5_context){.callback = callback, .data = data, .release = release};
  wasmtime_error_t *failure = NULL;
  
  failure = callbackcheckedrecords_wasmtime_callback_create(session, "function-0cfd8b76dd97d47004a852b0", callbackcheckedrecords_wasmtime_callback_callback705cd2e64f6f37b7b3c5_invoke, context, callbackcheckedrecords_wasmtime_callback_callback705cd2e64f6f37b7b3c5_release, out);
  if (failure) { free(context); }
  
  return failure;
}

typedef struct { callbackcheckedrecords_wasmtime_callback_callback96775311ba874014bff2_fn callback; void *data; void (*release)(void *); callbackcheckedrecords_interval_t recovery; } callbackcheckedrecords_wasmtime_callback_callback96775311ba874014bff2_context;
static void callbackcheckedrecords_wasmtime_callback_callback96775311ba874014bff2_release(void *data) {
  callbackcheckedrecords_wasmtime_callback_callback96775311ba874014bff2_context *context = data;
  if (context->release) context->release(context->data);
  callbackcheckedrecords_interval_t_clear(&context->recovery);
  free(context);
}
static wasmtime_error_t *callbackcheckedrecords_wasmtime_callback_callback96775311ba874014bff2_invoke(void *data, const wasmtime_component_val_t *args, size_t count, wasmtime_component_val_t *out) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  callbackcheckedrecords_wasmtime_callback_callback96775311ba874014bff2_context *context = data;
  if (count != 1) return wasmtime_error_new("Typed WIT callback arity mismatch");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  wasmtime_error_t *failure = NULL;
  callbackcheckedrecords_interval_t value = {0};
  callbackcheckedrecords_interval_t arg0 = {0};
  if (!lb_graph_decode_3(&args[0], &input, &arg0)) { failure = wasmtime_error_new("Invalid typed WIT callback input, conversion limit or allocation failure"); goto done; }
  failure = context->callback(context->data, &arg0, &value);
  if (failure) goto done;
  if (!lb_graph_encode_3(&value, &output, out)) failure = wasmtime_error_new("Invalid typed WIT callback result, conversion limit or allocation failure");
done:
  callbackcheckedrecords_interval_t_clear(&value);
  lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}
wasmtime_error_t *callbackcheckedrecords_wasmtime_callback_callback96775311ba874014bff2_create(callbackcheckedrecords_wasmtime *session, callbackcheckedrecords_wasmtime_callback_callback96775311ba874014bff2_fn callback, void *data, void (*release)(void *), const callbackcheckedrecords_interval_t *recovery, callbackcheckedrecords_wasmtime_function *out) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  if (!callback || !lb_thread(session) || session->closing || !lb_buffer(recovery, 1, sizeof(*recovery), _Alignof(callbackcheckedrecords_interval_t)) || !lb_buffer(out, 1, sizeof(*out), _Alignof(callbackcheckedrecords_wasmtime_function)) || *out) return wasmtime_error_new("Invalid typed WIT callback registration");
  callbackcheckedrecords_wasmtime_callback_callback96775311ba874014bff2_context *context = malloc(sizeof(*context));
  if (!context) return wasmtime_error_new("Cannot allocate typed WIT callback context");
  *context = (callbackcheckedrecords_wasmtime_callback_callback96775311ba874014bff2_context){.callback = callback, .data = data, .release = release};
  wasmtime_error_t *failure = NULL;
  failure = callbackcheckedrecords_interval_t_wasmtime_copy(recovery, &context->recovery);
  if (failure) { free(context); return failure; }
  failure = callbackcheckedrecords_wasmtime_callback_create(session, "function-499c879a3d450f66047fcee3", callbackcheckedrecords_wasmtime_callback_callback96775311ba874014bff2_invoke, context, callbackcheckedrecords_wasmtime_callback_callback96775311ba874014bff2_release, out);
  if (failure) { callbackcheckedrecords_interval_t_clear(&context->recovery); free(context); }
  else {
    lb_entry *entry = lb_entry_find(session, *out);
    if (!entry) { failure = wasmtime_error_new("Missing typed WIT callback recovery owner"); callbackcheckedrecords_wasmtime_function_close(session, out); }
    else entry->recovery = &context->recovery;
  }
  return failure;
}

typedef struct { callbackcheckedrecords_wasmtime_callback_callback9edd7fa9a1ed11043b7d_fn callback; void *data; void (*release)(void *); } callbackcheckedrecords_wasmtime_callback_callback9edd7fa9a1ed11043b7d_context;
static void callbackcheckedrecords_wasmtime_callback_callback9edd7fa9a1ed11043b7d_release(void *data) {
  callbackcheckedrecords_wasmtime_callback_callback9edd7fa9a1ed11043b7d_context *context = data;
  if (context->release) context->release(context->data);
  
  free(context);
}
static wasmtime_error_t *callbackcheckedrecords_wasmtime_callback_callback9edd7fa9a1ed11043b7d_invoke(void *data, const wasmtime_component_val_t *args, size_t count, wasmtime_component_val_t *out) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  callbackcheckedrecords_wasmtime_callback_callback9edd7fa9a1ed11043b7d_context *context = data;
  if (count != 1) return wasmtime_error_new("Typed WIT callback arity mismatch");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  wasmtime_error_t *failure = NULL;
  callbackcheckedrecords_scalar_nat_t value = {0};
  callbackcheckedrecords_weighted_t arg0 = {0};
  if (!lb_graph_decode_4(&args[0], &input, &arg0)) { failure = wasmtime_error_new("Invalid typed WIT callback input, conversion limit or allocation failure"); goto done; }
  failure = context->callback(context->data, &arg0, &value);
  if (failure) goto done;
  if (!lb_graph_encode_5(&value, &output, out)) failure = wasmtime_error_new("Invalid typed WIT callback result, conversion limit or allocation failure");
done:
  callbackcheckedrecords_scalar_nat_t_clear(&value);
  lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}
wasmtime_error_t *callbackcheckedrecords_wasmtime_callback_callback9edd7fa9a1ed11043b7d_create(callbackcheckedrecords_wasmtime *session, callbackcheckedrecords_wasmtime_callback_callback9edd7fa9a1ed11043b7d_fn callback, void *data, void (*release)(void *), callbackcheckedrecords_wasmtime_function *out) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  if (!callback || !lb_thread(session) || session->closing || !lb_buffer(out, 1, sizeof(*out), _Alignof(callbackcheckedrecords_wasmtime_function)) || *out) return wasmtime_error_new("Invalid typed WIT callback registration");
  callbackcheckedrecords_wasmtime_callback_callback9edd7fa9a1ed11043b7d_context *context = malloc(sizeof(*context));
  if (!context) return wasmtime_error_new("Cannot allocate typed WIT callback context");
  *context = (callbackcheckedrecords_wasmtime_callback_callback9edd7fa9a1ed11043b7d_context){.callback = callback, .data = data, .release = release};
  wasmtime_error_t *failure = NULL;
  
  failure = callbackcheckedrecords_wasmtime_callback_create(session, "function-3e61836c4ff1877794f5b42e", callbackcheckedrecords_wasmtime_callback_callback9edd7fa9a1ed11043b7d_invoke, context, callbackcheckedrecords_wasmtime_callback_callback9edd7fa9a1ed11043b7d_release, out);
  if (failure) { free(context); }
  
  return failure;
}

typedef struct { callbackcheckedrecords_wasmtime_callback_callbackb782f62c1be9d8b0085a_fn callback; void *data; void (*release)(void *); callbackcheckedrecords_weighted_t recovery; } callbackcheckedrecords_wasmtime_callback_callbackb782f62c1be9d8b0085a_context;
static void callbackcheckedrecords_wasmtime_callback_callbackb782f62c1be9d8b0085a_release(void *data) {
  callbackcheckedrecords_wasmtime_callback_callbackb782f62c1be9d8b0085a_context *context = data;
  if (context->release) context->release(context->data);
  callbackcheckedrecords_weighted_t_clear(&context->recovery);
  free(context);
}
static wasmtime_error_t *callbackcheckedrecords_wasmtime_callback_callbackb782f62c1be9d8b0085a_invoke(void *data, const wasmtime_component_val_t *args, size_t count, wasmtime_component_val_t *out) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  callbackcheckedrecords_wasmtime_callback_callbackb782f62c1be9d8b0085a_context *context = data;
  if (count != 1) return wasmtime_error_new("Typed WIT callback arity mismatch");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  wasmtime_error_t *failure = NULL;
  callbackcheckedrecords_weighted_t value = {0};
  callbackcheckedrecords_weighted_t arg0 = {0};
  if (!lb_graph_decode_4(&args[0], &input, &arg0)) { failure = wasmtime_error_new("Invalid typed WIT callback input, conversion limit or allocation failure"); goto done; }
  failure = context->callback(context->data, &arg0, &value);
  if (failure) goto done;
  if (!lb_graph_encode_4(&value, &output, out)) failure = wasmtime_error_new("Invalid typed WIT callback result, conversion limit or allocation failure");
done:
  callbackcheckedrecords_weighted_t_clear(&value);
  lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}
wasmtime_error_t *callbackcheckedrecords_wasmtime_callback_callbackb782f62c1be9d8b0085a_create(callbackcheckedrecords_wasmtime *session, callbackcheckedrecords_wasmtime_callback_callbackb782f62c1be9d8b0085a_fn callback, void *data, void (*release)(void *), const callbackcheckedrecords_weighted_t *recovery, callbackcheckedrecords_wasmtime_function *out) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  if (!callback || !lb_thread(session) || session->closing || !lb_buffer(recovery, 1, sizeof(*recovery), _Alignof(callbackcheckedrecords_weighted_t)) || !lb_buffer(out, 1, sizeof(*out), _Alignof(callbackcheckedrecords_wasmtime_function)) || *out) return wasmtime_error_new("Invalid typed WIT callback registration");
  callbackcheckedrecords_wasmtime_callback_callbackb782f62c1be9d8b0085a_context *context = malloc(sizeof(*context));
  if (!context) return wasmtime_error_new("Cannot allocate typed WIT callback context");
  *context = (callbackcheckedrecords_wasmtime_callback_callbackb782f62c1be9d8b0085a_context){.callback = callback, .data = data, .release = release};
  wasmtime_error_t *failure = NULL;
  failure = callbackcheckedrecords_weighted_t_wasmtime_copy(recovery, &context->recovery);
  if (failure) { free(context); return failure; }
  failure = callbackcheckedrecords_wasmtime_callback_create(session, "function-9ac1e60c77fb6fe8a7617d3a", callbackcheckedrecords_wasmtime_callback_callbackb782f62c1be9d8b0085a_invoke, context, callbackcheckedrecords_wasmtime_callback_callbackb782f62c1be9d8b0085a_release, out);
  if (failure) { callbackcheckedrecords_weighted_t_clear(&context->recovery); free(context); }
  else {
    lb_entry *entry = lb_entry_find(session, *out);
    if (!entry) { failure = wasmtime_error_new("Missing typed WIT callback recovery owner"); callbackcheckedrecords_wasmtime_function_close(session, out); }
    else entry->recovery = &context->recovery;
  }
  return failure;
}

typedef struct { callbackcheckedrecords_wasmtime_callback_callbacke7252f0aa280ee0b13ec_fn callback; void *data; void (*release)(void *); } callbackcheckedrecords_wasmtime_callback_callbacke7252f0aa280ee0b13ec_context;
static void callbackcheckedrecords_wasmtime_callback_callbacke7252f0aa280ee0b13ec_release(void *data) {
  callbackcheckedrecords_wasmtime_callback_callbacke7252f0aa280ee0b13ec_context *context = data;
  if (context->release) context->release(context->data);
  
  free(context);
}
static wasmtime_error_t *callbackcheckedrecords_wasmtime_callback_callbacke7252f0aa280ee0b13ec_invoke(void *data, const wasmtime_component_val_t *args, size_t count, wasmtime_component_val_t *out) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  callbackcheckedrecords_wasmtime_callback_callbacke7252f0aa280ee0b13ec_context *context = data;
  if (count != 2) return wasmtime_error_new("Typed WIT callback arity mismatch");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  wasmtime_error_t *failure = NULL;
  callbackcheckedrecords_interval_t value = {0};
  callbackcheckedrecords_scalar_nat_t arg0 = {0};
  callbackcheckedrecords_interval_t arg1 = {0};
  if (!lb_graph_decode_5(&args[0], &input, &arg0)) { failure = wasmtime_error_new("Invalid typed WIT callback input, conversion limit or allocation failure"); goto done; }
  if (!lb_graph_decode_3(&args[1], &input, &arg1)) { failure = wasmtime_error_new("Invalid typed WIT callback input, conversion limit or allocation failure"); goto done; }
  failure = context->callback(context->data, &arg0, &arg1, &value);
  if (failure) goto done;
  if (!lb_graph_encode_3(&value, &output, out)) failure = wasmtime_error_new("Invalid typed WIT callback result, conversion limit or allocation failure");
done:
  callbackcheckedrecords_interval_t_clear(&value);
  lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}
wasmtime_error_t *callbackcheckedrecords_wasmtime_callback_callbacke7252f0aa280ee0b13ec_create(callbackcheckedrecords_wasmtime *session, callbackcheckedrecords_wasmtime_callback_callbacke7252f0aa280ee0b13ec_fn callback, void *data, void (*release)(void *), callbackcheckedrecords_wasmtime_function *out) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  if (!callback || !lb_thread(session) || session->closing || !lb_buffer(out, 1, sizeof(*out), _Alignof(callbackcheckedrecords_wasmtime_function)) || *out) return wasmtime_error_new("Invalid typed WIT callback registration");
  callbackcheckedrecords_wasmtime_callback_callbacke7252f0aa280ee0b13ec_context *context = malloc(sizeof(*context));
  if (!context) return wasmtime_error_new("Cannot allocate typed WIT callback context");
  *context = (callbackcheckedrecords_wasmtime_callback_callbacke7252f0aa280ee0b13ec_context){.callback = callback, .data = data, .release = release};
  wasmtime_error_t *failure = NULL;
  
  failure = callbackcheckedrecords_wasmtime_callback_create(session, "function-4cf83a83d390acbc64c0ac23", callbackcheckedrecords_wasmtime_callback_callbacke7252f0aa280ee0b13ec_invoke, context, callbackcheckedrecords_wasmtime_callback_callbacke7252f0aa280ee0b13ec_release, out);
  if (failure) { free(context); }
  
  return failure;
}

typedef struct { callbackcheckedrecords_wasmtime_callback_callbacke974ad5f8e66387c6d39_fn callback; void *data; void (*release)(void *); } callbackcheckedrecords_wasmtime_callback_callbacke974ad5f8e66387c6d39_context;
static void callbackcheckedrecords_wasmtime_callback_callbacke974ad5f8e66387c6d39_release(void *data) {
  callbackcheckedrecords_wasmtime_callback_callbacke974ad5f8e66387c6d39_context *context = data;
  if (context->release) context->release(context->data);
  
  free(context);
}
static wasmtime_error_t *callbackcheckedrecords_wasmtime_callback_callbacke974ad5f8e66387c6d39_invoke(void *data, const wasmtime_component_val_t *args, size_t count, wasmtime_component_val_t *out) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  callbackcheckedrecords_wasmtime_callback_callbacke974ad5f8e66387c6d39_context *context = data;
  if (count != 1) return wasmtime_error_new("Typed WIT callback arity mismatch");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  wasmtime_error_t *failure = NULL;
  callbackcheckedrecords_graph_38a8689c2f20ead532ea_t value = {0};
  callbackcheckedrecords_graph_7ee21eb6b8ea120b53f0_t arg0 = {0};
  if (!lb_graph_decode_1(&args[0], &input, &arg0)) { failure = wasmtime_error_new("Invalid typed WIT callback input, conversion limit or allocation failure"); goto done; }
  failure = context->callback(context->data, &arg0, &value);
  if (failure) goto done;
  if (!lb_graph_encode_0(&value, &output, out)) failure = wasmtime_error_new("Invalid typed WIT callback result, conversion limit or allocation failure");
done:
  callbackcheckedrecords_graph_38a8689c2f20ead532ea_t_clear(&value);
  lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}
wasmtime_error_t *callbackcheckedrecords_wasmtime_callback_callbacke974ad5f8e66387c6d39_create(callbackcheckedrecords_wasmtime *session, callbackcheckedrecords_wasmtime_callback_callbacke974ad5f8e66387c6d39_fn callback, void *data, void (*release)(void *), callbackcheckedrecords_wasmtime_function *out) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  if (!callback || !lb_thread(session) || session->closing || !lb_buffer(out, 1, sizeof(*out), _Alignof(callbackcheckedrecords_wasmtime_function)) || *out) return wasmtime_error_new("Invalid typed WIT callback registration");
  callbackcheckedrecords_wasmtime_callback_callbacke974ad5f8e66387c6d39_context *context = malloc(sizeof(*context));
  if (!context) return wasmtime_error_new("Cannot allocate typed WIT callback context");
  *context = (callbackcheckedrecords_wasmtime_callback_callbacke974ad5f8e66387c6d39_context){.callback = callback, .data = data, .release = release};
  wasmtime_error_t *failure = NULL;
  
  failure = callbackcheckedrecords_wasmtime_callback_create(session, "function-e8004d28621f9b553f4c83a6", callbackcheckedrecords_wasmtime_callback_callbacke974ad5f8e66387c6d39_invoke, context, callbackcheckedrecords_wasmtime_callback_callbacke974ad5f8e66387c6d39_release, out);
  if (failure) { free(context); }
  
  return failure;
}
