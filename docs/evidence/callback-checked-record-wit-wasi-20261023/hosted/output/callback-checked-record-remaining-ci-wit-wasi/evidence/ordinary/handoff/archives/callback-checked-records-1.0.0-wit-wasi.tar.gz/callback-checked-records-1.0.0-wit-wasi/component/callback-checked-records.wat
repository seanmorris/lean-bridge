(component
  (type $api (instance
    (type $limbs (list u32))
    (type $base1 (record (field "index" u32)))
    (export "lb-graph-ref3" (type $t1 (eq $base1)))
    (type $base2 (option $t1))
    (export "bridge-value-2" (type $t2 (eq $base2)))
    (type $base3 (list $t2))
    (export "bridge-value-3" (type $t3 (eq $base3)))
    (type $base4 (record (field "index" u32)))
    (export "lb-graph-ref0" (type $t4 (eq $base4)))
    (type $base5 (list $t4))
    (export "bridge-value-5" (type $t5 (eq $base5)))
    (type $base6 (list $t5))
    (export "bridge-value-6" (type $t6 (eq $base6)))
    (type $base8 (result $t4 (error string)))
    (export "bridge-value-8" (type $t8 (eq $base8)))
    (type $base9 (list $t8))
    (export "bridge-value-9" (type $t9 (eq $base9)))
    (type $base10 (list u32))
    (export "bridge-value-10" (type $t10 (eq $base10)))
    (type $base11 (record (field "lo" $t10) (field "hi" $t10)))
    (export "lb-graph-node3" (type $t11 (eq $base11)))
    (type $base12 (list $t11))
    (export "bridge-value-12" (type $t12 (eq $base12)))
    (type $base13 (record (field "weight" $t10) (field "limit" $t10)))
    (export "lb-graph-node4" (type $t13 (eq $base13)))
    (type $base14 (list $t13))
    (export "bridge-value-14" (type $t14 (eq $base14)))
    (export "lb-graph-node0" (type $t24 (eq $t2)))
    (type $base25 (list $t24))
    (export "bridge-alias-value-25" (type $t25 (eq $base25)))
    (export "lb-graph-node1" (type $t26 (eq $t5)))
    (type $base27 (list $t26))
    (export "bridge-alias-value-27" (type $t27 (eq $base27)))
    (export "lb-graph-node2" (type $t28 (eq $t8)))
    (type $base29 (list $t28))
    (export "bridge-alias-value-29" (type $t29 (eq $base29)))
    (type $base15 (record (field "nodes0" $t25) (field "nodes1" $t27) (field "nodes2" $t29) (field "nodes3" $t12) (field "nodes4" $t14)))
    (export "lb-graph-arena" (type $t15 (eq $base15)))
    (type $base16 (record (field "root" $t1) (field "nodes" $t15)))
    (export "lb-graph-value3" (type $t16 (eq $base16)))
    (type $base17 (record (field "root" $t4) (field "nodes" $t15)))
    (export "lb-graph-value0" (type $t17 (eq $base17)))
    (type $base18 (record (field "index" u32)))
    (export "lb-graph-ref2" (type $t18 (eq $base18)))
    (type $base19 (record (field "root" $t18) (field "nodes" $t15)))
    (export "lb-graph-value2" (type $t19 (eq $base19)))
    (type $base20 (record (field "index" u32)))
    (export "lb-graph-ref4" (type $t20 (eq $base20)))
    (type $base21 (record (field "root" $t20) (field "nodes" $t15)))
    (export "lb-graph-value4" (type $t21 (eq $base21)))
    (type $base22 (record (field "index" u32)))
    (export "lb-graph-ref1" (type $t22 (eq $base22)))
    (type $base23 (record (field "root" $t22) (field "nodes" $t15)))
    (export "lb-graph-value1" (type $t23 (eq $base23)))
    (export "interval" (type $t30 (eq $t16)))
    (export "weighted" (type $t31 (eq $t21)))
    (export "function-499c879a3d450f66047fcee3" (type $resource32 (sub resource)))
    (type $borrow32 (borrow $resource32))
    (type $own32 (own $resource32))
    (export "function-14ccabf25ea1719eb709d075" (type $resource33 (sub resource)))
    (type $borrow33 (borrow $resource33))
    (type $own33 (own $resource33))
    (export "function-be5c64001874227d88d0b54c" (type $resource34 (sub resource)))
    (type $borrow34 (borrow $resource34))
    (type $own34 (own $resource34))
    (export "function-9ac1e60c77fb6fe8a7617d3a" (type $resource35 (sub resource)))
    (type $borrow35 (borrow $resource35))
    (type $own35 (own $resource35))
    (export "function-0cfd8b76dd97d47004a852b0" (type $resource36 (sub resource)))
    (type $borrow36 (borrow $resource36))
    (type $own36 (own $resource36))
    (export "function-e8004d28621f9b553f4c83a6" (type $resource37 (sub resource)))
    (type $borrow37 (borrow $resource37))
    (type $own37 (own $resource37))
    (export "function-4cf83a83d390acbc64c0ac23" (type $resource38 (sub resource)))
    (type $borrow38 (borrow $resource38))
    (type $own38 (own $resource38))
    (export "function-3e61836c4ff1877794f5b42e" (type $resource39 (sub resource)))
    (type $borrow39 (borrow $resource39))
    (type $own39 (own $resource39))
    (export "call-host" (func (param "arg0" $borrow32) (result $t10)))
    (export "call-host-container" (func (param "arg0" $borrow33) (result $t10)))
    (export "call-host-mixed" (func (param "arg0" $borrow34) (result $t10)))
    (export "call-host-nested" (func (param "arg0" $borrow35) (result $t10)))
    (export "make-closure" (func (param "arg0" $t10) (result $own36)))
    (export "make-container-closure" (func (param "arg0" $t10) (result $own37)))
    (export "make-mixed-closure" (func (param "arg0" $t10) (result $own38)))
    (export "make-nested-closure" (func (param "arg0" $t10) (result $own39)))
    (export "invoke-function-499c879a3d450f66047fcee3" (func (param "self" $borrow32) (param "arg0" $t30) (result $t30)))
    (export "invoke-function-14ccabf25ea1719eb709d075" (func (param "self" $borrow33) (param "arg0" $t17) (result $t19)))
    (export "invoke-function-be5c64001874227d88d0b54c" (func (param "self" $borrow34) (param "arg0" $t10) (param "arg1" $t30) (result $t30)))
    (export "invoke-function-9ac1e60c77fb6fe8a7617d3a" (func (param "self" $borrow35) (param "arg0" $t31) (result $t31)))
    (export "invoke-function-0cfd8b76dd97d47004a852b0" (func (param "self" $borrow36) (param "arg0" $t30) (result $t10)))
    (export "invoke-function-e8004d28621f9b553f4c83a6" (func (param "self" $borrow37) (param "arg0" $t23) (result $t17)))
    (export "invoke-function-4cf83a83d390acbc64c0ac23" (func (param "self" $borrow38) (param "arg0" $t10) (param "arg1" $t30) (result $t30)))
    (export "invoke-function-3e61836c4ff1877794f5b42e" (func (param "self" $borrow39) (param "arg0" $t31) (result $t10)))
  ))
  (import "lean-bridge:callback-checked-records/native@1.0.0" (instance $host (type $api)))
  (alias export $host "lb-graph-ref3" (type $public1))
  (alias export $host "bridge-value-2" (type $public2))
  (alias export $host "bridge-value-3" (type $public3))
  (alias export $host "lb-graph-ref0" (type $public4))
  (alias export $host "bridge-value-5" (type $public5))
  (alias export $host "bridge-value-6" (type $public6))
  (alias export $host "bridge-value-8" (type $public8))
  (alias export $host "bridge-value-9" (type $public9))
  (alias export $host "bridge-value-10" (type $public10))
  (alias export $host "lb-graph-node3" (type $public11))
  (alias export $host "bridge-value-12" (type $public12))
  (alias export $host "lb-graph-node4" (type $public13))
  (alias export $host "bridge-value-14" (type $public14))
  (alias export $host "lb-graph-node0" (type $public24))
  (alias export $host "bridge-alias-value-25" (type $public25))
  (alias export $host "lb-graph-node1" (type $public26))
  (alias export $host "bridge-alias-value-27" (type $public27))
  (alias export $host "lb-graph-node2" (type $public28))
  (alias export $host "bridge-alias-value-29" (type $public29))
  (alias export $host "lb-graph-arena" (type $public15))
  (alias export $host "lb-graph-value3" (type $public16))
  (alias export $host "lb-graph-value0" (type $public17))
  (alias export $host "lb-graph-ref2" (type $public18))
  (alias export $host "lb-graph-value2" (type $public19))
  (alias export $host "lb-graph-ref4" (type $public20))
  (alias export $host "lb-graph-value4" (type $public21))
  (alias export $host "lb-graph-ref1" (type $public22))
  (alias export $host "lb-graph-value1" (type $public23))
  (alias export $host "interval" (type $public30))
  (alias export $host "weighted" (type $public31))
  (alias export $host "function-499c879a3d450f66047fcee3" (type $publicResource32))
  (type $publicBorrow32 (borrow $publicResource32))
  (type $publicOwn32 (own $publicResource32))
  (alias export $host "function-14ccabf25ea1719eb709d075" (type $publicResource33))
  (type $publicBorrow33 (borrow $publicResource33))
  (type $publicOwn33 (own $publicResource33))
  (alias export $host "function-be5c64001874227d88d0b54c" (type $publicResource34))
  (type $publicBorrow34 (borrow $publicResource34))
  (type $publicOwn34 (own $publicResource34))
  (alias export $host "function-9ac1e60c77fb6fe8a7617d3a" (type $publicResource35))
  (type $publicBorrow35 (borrow $publicResource35))
  (type $publicOwn35 (own $publicResource35))
  (alias export $host "function-0cfd8b76dd97d47004a852b0" (type $publicResource36))
  (type $publicBorrow36 (borrow $publicResource36))
  (type $publicOwn36 (own $publicResource36))
  (alias export $host "function-e8004d28621f9b553f4c83a6" (type $publicResource37))
  (type $publicBorrow37 (borrow $publicResource37))
  (type $publicOwn37 (own $publicResource37))
  (alias export $host "function-4cf83a83d390acbc64c0ac23" (type $publicResource38))
  (type $publicBorrow38 (borrow $publicResource38))
  (type $publicOwn38 (own $publicResource38))
  (alias export $host "function-3e61836c4ff1877794f5b42e" (type $publicResource39))
  (type $publicBorrow39 (borrow $publicResource39))
  (type $publicOwn39 (own $publicResource39))
  (alias export $host "call-host" (func $host0))
  (alias export $host "call-host-container" (func $host1))
  (alias export $host "call-host-mixed" (func $host2))
  (alias export $host "call-host-nested" (func $host3))
  (alias export $host "make-closure" (func $host4))
  (alias export $host "make-container-closure" (func $host5))
  (alias export $host "make-mixed-closure" (func $host6))
  (alias export $host "make-nested-closure" (func $host7))
  (alias export $host "invoke-function-499c879a3d450f66047fcee3" (func $host8))
  (alias export $host "invoke-function-14ccabf25ea1719eb709d075" (func $host9))
  (alias export $host "invoke-function-be5c64001874227d88d0b54c" (func $host10))
  (alias export $host "invoke-function-9ac1e60c77fb6fe8a7617d3a" (func $host11))
  (alias export $host "invoke-function-0cfd8b76dd97d47004a852b0" (func $host12))
  (alias export $host "invoke-function-e8004d28621f9b553f4c83a6" (func $host13))
  (alias export $host "invoke-function-4cf83a83d390acbc64c0ac23" (func $host14))
  (alias export $host "invoke-function-3e61836c4ff1877794f5b42e" (func $host15))
  (core module $allocator
    (memory (export "memory") 1 1024)
    (global $heap (mut i32) (i32.const 272))
    (global $depth (mut i32) (i32.const 0))
    (func (export "enter")
      (if (i32.ge_u (global.get $depth) (i32.const 64)) (then unreachable))
      (i32.store offset=16 (i32.shl (global.get $depth) (i32.const 2)) (global.get $heap))
      (global.set $depth (i32.add (global.get $depth) (i32.const 1))))
    (func $leave
      (if (i32.eqz (global.get $depth)) (then unreachable))
      (global.set $depth (i32.sub (global.get $depth) (i32.const 1)))
      (global.set $heap (if (result i32) (i32.eqz (global.get $depth))
        (then (i32.const 272))
        (else (i32.load offset=16 (i32.shl (global.get $depth) (i32.const 2)))))))
    (func (export "realloc") (param $old i32) (param $old-size i32) (param $alignment i32) (param $size i32) (result i32)
      (local $start i32) (local $end i32) (local $pages i32)
      (if (i32.eqz (local.get $size)) (then (return (i32.const 0))))
      (local.set $start (i32.and
        (i32.add (global.get $heap) (i32.sub (local.get $alignment) (i32.const 1)))
        (i32.sub (i32.const 0) (local.get $alignment))))
      (local.set $end (i32.add (local.get $start) (local.get $size)))
      (if (i32.or (i32.lt_u (local.get $end) (local.get $start)) (i32.gt_u (local.get $end) (i32.const 67108864))) (then unreachable))
      (local.set $pages (i32.shr_u (i32.add (local.get $end) (i32.const 65535)) (i32.const 16)))
      (if (i32.gt_u (local.get $pages) (memory.size))
        (then (if (i32.eq (memory.grow (i32.sub (local.get $pages) (memory.size))) (i32.const -1)) (then unreachable))))
      (if (local.get $old)
        (then (memory.copy (local.get $start) (local.get $old)
          (select (local.get $old-size) (local.get $size) (i32.lt_u (local.get $old-size) (local.get $size))))))
      (global.set $heap (local.get $end))
      (local.get $start))
    (func (export "post-i32") (param i32) (call $leave))
    (func (export "post-i64") (param i64) (call $leave))
    (func (export "post-f32") (param f32) (call $leave))
    (func (export "post-f64") (param f64) (call $leave))
  )
  (core instance $allocation (instantiate $allocator))
  (alias core export $allocation "memory" (core memory $memory))
  (alias core export $allocation "realloc" (core func $realloc))
  (alias core export $allocation "post-i32" (core func $post-i32))
  (alias core export $allocation "post-i64" (core func $post-i64))
  (alias core export $allocation "post-f32" (core func $post-f32))
  (alias core export $allocation "post-f64" (core func $post-f64))
  (core func $lower0 (canon lower (func $host0) (memory $memory) (realloc $realloc)))
  (core func $lower1 (canon lower (func $host1) (memory $memory) (realloc $realloc)))
  (core func $lower2 (canon lower (func $host2) (memory $memory) (realloc $realloc)))
  (core func $lower3 (canon lower (func $host3) (memory $memory) (realloc $realloc)))
  (core func $lower4 (canon lower (func $host4) (memory $memory) (realloc $realloc)))
  (core func $lower5 (canon lower (func $host5) (memory $memory) (realloc $realloc)))
  (core func $lower6 (canon lower (func $host6) (memory $memory) (realloc $realloc)))
  (core func $lower7 (canon lower (func $host7) (memory $memory) (realloc $realloc)))
  (core func $lower8 (canon lower (func $host8) (memory $memory) (realloc $realloc)))
  (core func $lower9 (canon lower (func $host9) (memory $memory) (realloc $realloc)))
  (core func $lower10 (canon lower (func $host10) (memory $memory) (realloc $realloc)))
  (core func $lower11 (canon lower (func $host11) (memory $memory) (realloc $realloc)))
  (core func $lower12 (canon lower (func $host12) (memory $memory) (realloc $realloc)))
  (core func $lower13 (canon lower (func $host13) (memory $memory) (realloc $realloc)))
  (core func $lower14 (canon lower (func $host14) (memory $memory) (realloc $realloc)))
  (core func $lower15 (canon lower (func $host15) (memory $memory) (realloc $realloc)))
  (core func $drop32 (canon resource.drop $publicResource32))
  (core func $drop33 (canon resource.drop $publicResource33))
  (core func $drop34 (canon resource.drop $publicResource34))
  (core func $drop35 (canon resource.drop $publicResource35))
  (core func $drop36 (canon resource.drop $publicResource36))
  (core func $drop37 (canon resource.drop $publicResource37))
  (core func $drop38 (canon resource.drop $publicResource38))
  (core func $drop39 (canon resource.drop $publicResource39))
  (core module $forward
    (import "allocation" "realloc" (func $allocate (param i32 i32 i32 i32) (result i32)))
    (import "allocation" "memory" (memory 1))
    (import "allocation" "enter" (func $enter))
    (import "resources" "drop32" (func $drop32 (param i32)))
    (import "resources" "drop33" (func $drop33 (param i32)))
    (import "resources" "drop34" (func $drop34 (param i32)))
    (import "resources" "drop35" (func $drop35 (param i32)))
    (import "resources" "drop36" (func $drop36 (param i32)))
    (import "resources" "drop37" (func $drop37 (param i32)))
    (import "resources" "drop38" (func $drop38 (param i32)))
    (import "resources" "drop39" (func $drop39 (param i32)))
    (import "host" "f0" (func $f0 (param i32 i32) ))
    (import "host" "f1" (func $f1 (param i32 i32) ))
    (import "host" "f2" (func $f2 (param i32 i32) ))
    (import "host" "f3" (func $f3 (param i32 i32) ))
    (import "host" "f4" (func $f4 (param i32 i32) (result i32)))
    (import "host" "f5" (func $f5 (param i32 i32) (result i32)))
    (import "host" "f6" (func $f6 (param i32 i32) (result i32)))
    (import "host" "f7" (func $f7 (param i32 i32) (result i32)))
    (import "host" "f8" (func $f8 (param i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32) ))
    (import "host" "f9" (func $f9 (param i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32) ))
    (import "host" "f10" (func $f10 (param i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32) ))
    (import "host" "f11" (func $f11 (param i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32) ))
    (import "host" "f12" (func $f12 (param i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32) ))
    (import "host" "f13" (func $f13 (param i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32) ))
    (import "host" "f14" (func $f14 (param i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32) ))
    (import "host" "f15" (func $f15 (param i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32) ))
    (func (export "f0") (param i32) (result i32) (local $result i32)
      call $enter
      (local.set $result (call $allocate (i32.const 0) (i32.const 0) (i32.const 4) (i32.const 8)))
      local.get 0
      local.get $result
      call $f0
      (call $drop32 (local.get 0))
      local.get $result
    )
    (func (export "f1") (param i32) (result i32) (local $result i32)
      call $enter
      (local.set $result (call $allocate (i32.const 0) (i32.const 0) (i32.const 4) (i32.const 8)))
      local.get 0
      local.get $result
      call $f1
      (call $drop33 (local.get 0))
      local.get $result
    )
    (func (export "f2") (param i32) (result i32) (local $result i32)
      call $enter
      (local.set $result (call $allocate (i32.const 0) (i32.const 0) (i32.const 4) (i32.const 8)))
      local.get 0
      local.get $result
      call $f2
      (call $drop34 (local.get 0))
      local.get $result
    )
    (func (export "f3") (param i32) (result i32) (local $result i32)
      call $enter
      (local.set $result (call $allocate (i32.const 0) (i32.const 0) (i32.const 4) (i32.const 8)))
      local.get 0
      local.get $result
      call $f3
      (call $drop35 (local.get 0))
      local.get $result
    )
    (func (export "f4") (param i32 i32) (result i32)
      call $enter
      local.get 0
      local.get 1
      call $f4
    )
    (func (export "f5") (param i32 i32) (result i32)
      call $enter
      local.get 0
      local.get 1
      call $f5
    )
    (func (export "f6") (param i32 i32) (result i32)
      call $enter
      local.get 0
      local.get 1
      call $f6
    )
    (func (export "f7") (param i32 i32) (result i32)
      call $enter
      local.get 0
      local.get 1
      call $f7
    )
    (func (export "f8") (param i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32) (result i32) (local $result i32)
      call $enter
      (local.set $result (call $allocate (i32.const 0) (i32.const 0) (i32.const 4) (i32.const 44)))
      local.get 0
      local.get 1
      local.get 2
      local.get 3
      local.get 4
      local.get 5
      local.get 6
      local.get 7
      local.get 8
      local.get 9
      local.get 10
      local.get 11
      local.get $result
      call $f8
      (call $drop32 (local.get 0))
      local.get $result
    )
    (func (export "f9") (param i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32) (result i32) (local $result i32)
      call $enter
      (local.set $result (call $allocate (i32.const 0) (i32.const 0) (i32.const 4) (i32.const 44)))
      local.get 0
      local.get 1
      local.get 2
      local.get 3
      local.get 4
      local.get 5
      local.get 6
      local.get 7
      local.get 8
      local.get 9
      local.get 10
      local.get 11
      local.get $result
      call $f9
      (call $drop33 (local.get 0))
      local.get $result
    )
    (func (export "f10") (param i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32) (result i32) (local $result i32)
      call $enter
      (local.set $result (call $allocate (i32.const 0) (i32.const 0) (i32.const 4) (i32.const 44)))
      local.get 0
      local.get 1
      local.get 2
      local.get 3
      local.get 4
      local.get 5
      local.get 6
      local.get 7
      local.get 8
      local.get 9
      local.get 10
      local.get 11
      local.get 12
      local.get 13
      local.get $result
      call $f10
      (call $drop34 (local.get 0))
      local.get $result
    )
    (func (export "f11") (param i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32) (result i32) (local $result i32)
      call $enter
      (local.set $result (call $allocate (i32.const 0) (i32.const 0) (i32.const 4) (i32.const 44)))
      local.get 0
      local.get 1
      local.get 2
      local.get 3
      local.get 4
      local.get 5
      local.get 6
      local.get 7
      local.get 8
      local.get 9
      local.get 10
      local.get 11
      local.get $result
      call $f11
      (call $drop35 (local.get 0))
      local.get $result
    )
    (func (export "f12") (param i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32) (result i32) (local $result i32)
      call $enter
      (local.set $result (call $allocate (i32.const 0) (i32.const 0) (i32.const 4) (i32.const 8)))
      local.get 0
      local.get 1
      local.get 2
      local.get 3
      local.get 4
      local.get 5
      local.get 6
      local.get 7
      local.get 8
      local.get 9
      local.get 10
      local.get 11
      local.get $result
      call $f12
      (call $drop36 (local.get 0))
      local.get $result
    )
    (func (export "f13") (param i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32) (result i32) (local $result i32)
      call $enter
      (local.set $result (call $allocate (i32.const 0) (i32.const 0) (i32.const 4) (i32.const 44)))
      local.get 0
      local.get 1
      local.get 2
      local.get 3
      local.get 4
      local.get 5
      local.get 6
      local.get 7
      local.get 8
      local.get 9
      local.get 10
      local.get 11
      local.get $result
      call $f13
      (call $drop37 (local.get 0))
      local.get $result
    )
    (func (export "f14") (param i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32) (result i32) (local $result i32)
      call $enter
      (local.set $result (call $allocate (i32.const 0) (i32.const 0) (i32.const 4) (i32.const 44)))
      local.get 0
      local.get 1
      local.get 2
      local.get 3
      local.get 4
      local.get 5
      local.get 6
      local.get 7
      local.get 8
      local.get 9
      local.get 10
      local.get 11
      local.get 12
      local.get 13
      local.get $result
      call $f14
      (call $drop38 (local.get 0))
      local.get $result
    )
    (func (export "f15") (param i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32) (result i32) (local $result i32)
      call $enter
      (local.set $result (call $allocate (i32.const 0) (i32.const 0) (i32.const 4) (i32.const 8)))
      local.get 0
      local.get 1
      local.get 2
      local.get 3
      local.get 4
      local.get 5
      local.get 6
      local.get 7
      local.get 8
      local.get 9
      local.get 10
      local.get 11
      local.get $result
      call $f15
      (call $drop39 (local.get 0))
      local.get $result
    )
  )
  (core instance $imports
    (export "f0" (func $lower0))
    (export "f1" (func $lower1))
    (export "f2" (func $lower2))
    (export "f3" (func $lower3))
    (export "f4" (func $lower4))
    (export "f5" (func $lower5))
    (export "f6" (func $lower6))
    (export "f7" (func $lower7))
    (export "f8" (func $lower8))
    (export "f9" (func $lower9))
    (export "f10" (func $lower10))
    (export "f11" (func $lower11))
    (export "f12" (func $lower12))
    (export "f13" (func $lower13))
    (export "f14" (func $lower14))
    (export "f15" (func $lower15))
  )
  (core instance $resources
    (export "drop32" (func $drop32))
    (export "drop33" (func $drop33))
    (export "drop34" (func $drop34))
    (export "drop35" (func $drop35))
    (export "drop36" (func $drop36))
    (export "drop37" (func $drop37))
    (export "drop38" (func $drop38))
    (export "drop39" (func $drop39))
  )
  (core instance $forwarded (instantiate $forward (with "allocation" (instance $allocation)) (with "host" (instance $imports)) (with "resources" (instance $resources))))
  (alias core export $forwarded "f0" (core func $forward0))
  (alias core export $forwarded "f1" (core func $forward1))
  (alias core export $forwarded "f2" (core func $forward2))
  (alias core export $forwarded "f3" (core func $forward3))
  (alias core export $forwarded "f4" (core func $forward4))
  (alias core export $forwarded "f5" (core func $forward5))
  (alias core export $forwarded "f6" (core func $forward6))
  (alias core export $forwarded "f7" (core func $forward7))
  (alias core export $forwarded "f8" (core func $forward8))
  (alias core export $forwarded "f9" (core func $forward9))
  (alias core export $forwarded "f10" (core func $forward10))
  (alias core export $forwarded "f11" (core func $forward11))
  (alias core export $forwarded "f12" (core func $forward12))
  (alias core export $forwarded "f13" (core func $forward13))
  (alias core export $forwarded "f14" (core func $forward14))
  (alias core export $forwarded "f15" (core func $forward15))
  (func $f0 (param "arg0" $publicBorrow32) (result $public10) (canon lift (core func $forward0) (memory $memory) (realloc $realloc) (post-return $post-i32)))
  (func $f1 (param "arg0" $publicBorrow33) (result $public10) (canon lift (core func $forward1) (memory $memory) (realloc $realloc) (post-return $post-i32)))
  (func $f2 (param "arg0" $publicBorrow34) (result $public10) (canon lift (core func $forward2) (memory $memory) (realloc $realloc) (post-return $post-i32)))
  (func $f3 (param "arg0" $publicBorrow35) (result $public10) (canon lift (core func $forward3) (memory $memory) (realloc $realloc) (post-return $post-i32)))
  (func $f4 (param "arg0" $public10) (result $publicOwn36) (canon lift (core func $forward4) (memory $memory) (realloc $realloc) (post-return $post-i32)))
  (func $f5 (param "arg0" $public10) (result $publicOwn37) (canon lift (core func $forward5) (memory $memory) (realloc $realloc) (post-return $post-i32)))
  (func $f6 (param "arg0" $public10) (result $publicOwn38) (canon lift (core func $forward6) (memory $memory) (realloc $realloc) (post-return $post-i32)))
  (func $f7 (param "arg0" $public10) (result $publicOwn39) (canon lift (core func $forward7) (memory $memory) (realloc $realloc) (post-return $post-i32)))
  (func $f8 (param "self" $publicBorrow32) (param "arg0" $public30) (result $public30) (canon lift (core func $forward8) (memory $memory) (realloc $realloc) (post-return $post-i32)))
  (func $f9 (param "self" $publicBorrow33) (param "arg0" $public17) (result $public19) (canon lift (core func $forward9) (memory $memory) (realloc $realloc) (post-return $post-i32)))
  (func $f10 (param "self" $publicBorrow34) (param "arg0" $public10) (param "arg1" $public30) (result $public30) (canon lift (core func $forward10) (memory $memory) (realloc $realloc) (post-return $post-i32)))
  (func $f11 (param "self" $publicBorrow35) (param "arg0" $public31) (result $public31) (canon lift (core func $forward11) (memory $memory) (realloc $realloc) (post-return $post-i32)))
  (func $f12 (param "self" $publicBorrow36) (param "arg0" $public30) (result $public10) (canon lift (core func $forward12) (memory $memory) (realloc $realloc) (post-return $post-i32)))
  (func $f13 (param "self" $publicBorrow37) (param "arg0" $public23) (result $public17) (canon lift (core func $forward13) (memory $memory) (realloc $realloc) (post-return $post-i32)))
  (func $f14 (param "self" $publicBorrow38) (param "arg0" $public10) (param "arg1" $public30) (result $public30) (canon lift (core func $forward14) (memory $memory) (realloc $realloc) (post-return $post-i32)))
  (func $f15 (param "self" $publicBorrow39) (param "arg0" $public31) (result $public10) (canon lift (core func $forward15) (memory $memory) (realloc $realloc) (post-return $post-i32)))
  (type $public-api (instance
    (alias outer 1 $public1 (type $outer1))
    (export "lb-graph-ref3" (type $public1 (eq $outer1)))
    (alias outer 1 $public2 (type $outer2))
    (export "bridge-value-2" (type $public2 (eq $outer2)))
    (alias outer 1 $public3 (type $outer3))
    (export "bridge-value-3" (type $public3 (eq $outer3)))
    (alias outer 1 $public4 (type $outer4))
    (export "lb-graph-ref0" (type $public4 (eq $outer4)))
    (alias outer 1 $public5 (type $outer5))
    (export "bridge-value-5" (type $public5 (eq $outer5)))
    (alias outer 1 $public6 (type $outer6))
    (export "bridge-value-6" (type $public6 (eq $outer6)))
    (alias outer 1 $public8 (type $outer8))
    (export "bridge-value-8" (type $public8 (eq $outer8)))
    (alias outer 1 $public9 (type $outer9))
    (export "bridge-value-9" (type $public9 (eq $outer9)))
    (alias outer 1 $public10 (type $outer10))
    (export "bridge-value-10" (type $public10 (eq $outer10)))
    (alias outer 1 $public11 (type $outer11))
    (export "lb-graph-node3" (type $public11 (eq $outer11)))
    (alias outer 1 $public12 (type $outer12))
    (export "bridge-value-12" (type $public12 (eq $outer12)))
    (alias outer 1 $public13 (type $outer13))
    (export "lb-graph-node4" (type $public13 (eq $outer13)))
    (alias outer 1 $public14 (type $outer14))
    (export "bridge-value-14" (type $public14 (eq $outer14)))
    (alias outer 1 $public24 (type $outer24))
    (export "lb-graph-node0" (type $public24 (eq $outer24)))
    (alias outer 1 $public25 (type $outer25))
    (export "bridge-alias-value-25" (type $public25 (eq $outer25)))
    (alias outer 1 $public26 (type $outer26))
    (export "lb-graph-node1" (type $public26 (eq $outer26)))
    (alias outer 1 $public27 (type $outer27))
    (export "bridge-alias-value-27" (type $public27 (eq $outer27)))
    (alias outer 1 $public28 (type $outer28))
    (export "lb-graph-node2" (type $public28 (eq $outer28)))
    (alias outer 1 $public29 (type $outer29))
    (export "bridge-alias-value-29" (type $public29 (eq $outer29)))
    (alias outer 1 $public15 (type $outer15))
    (export "lb-graph-arena" (type $public15 (eq $outer15)))
    (alias outer 1 $public16 (type $outer16))
    (export "lb-graph-value3" (type $public16 (eq $outer16)))
    (alias outer 1 $public17 (type $outer17))
    (export "lb-graph-value0" (type $public17 (eq $outer17)))
    (alias outer 1 $public18 (type $outer18))
    (export "lb-graph-ref2" (type $public18 (eq $outer18)))
    (alias outer 1 $public19 (type $outer19))
    (export "lb-graph-value2" (type $public19 (eq $outer19)))
    (alias outer 1 $public20 (type $outer20))
    (export "lb-graph-ref4" (type $public20 (eq $outer20)))
    (alias outer 1 $public21 (type $outer21))
    (export "lb-graph-value4" (type $public21 (eq $outer21)))
    (alias outer 1 $public22 (type $outer22))
    (export "lb-graph-ref1" (type $public22 (eq $outer22)))
    (alias outer 1 $public23 (type $outer23))
    (export "lb-graph-value1" (type $public23 (eq $outer23)))
    (alias outer 1 $public30 (type $outer30))
    (export "interval" (type $public30 (eq $outer30)))
    (alias outer 1 $public31 (type $outer31))
    (export "weighted" (type $public31 (eq $outer31)))
    (alias outer 1 $publicResource32 (type $outer32))
    (export "function-499c879a3d450f66047fcee3" (type $publicResource32 (eq $outer32)))
    (type $publicBorrow32 (borrow $publicResource32))
    (type $publicOwn32 (own $publicResource32))
    (alias outer 1 $publicResource33 (type $outer33))
    (export "function-14ccabf25ea1719eb709d075" (type $publicResource33 (eq $outer33)))
    (type $publicBorrow33 (borrow $publicResource33))
    (type $publicOwn33 (own $publicResource33))
    (alias outer 1 $publicResource34 (type $outer34))
    (export "function-be5c64001874227d88d0b54c" (type $publicResource34 (eq $outer34)))
    (type $publicBorrow34 (borrow $publicResource34))
    (type $publicOwn34 (own $publicResource34))
    (alias outer 1 $publicResource35 (type $outer35))
    (export "function-9ac1e60c77fb6fe8a7617d3a" (type $publicResource35 (eq $outer35)))
    (type $publicBorrow35 (borrow $publicResource35))
    (type $publicOwn35 (own $publicResource35))
    (alias outer 1 $publicResource36 (type $outer36))
    (export "function-0cfd8b76dd97d47004a852b0" (type $publicResource36 (eq $outer36)))
    (type $publicBorrow36 (borrow $publicResource36))
    (type $publicOwn36 (own $publicResource36))
    (alias outer 1 $publicResource37 (type $outer37))
    (export "function-e8004d28621f9b553f4c83a6" (type $publicResource37 (eq $outer37)))
    (type $publicBorrow37 (borrow $publicResource37))
    (type $publicOwn37 (own $publicResource37))
    (alias outer 1 $publicResource38 (type $outer38))
    (export "function-4cf83a83d390acbc64c0ac23" (type $publicResource38 (eq $outer38)))
    (type $publicBorrow38 (borrow $publicResource38))
    (type $publicOwn38 (own $publicResource38))
    (alias outer 1 $publicResource39 (type $outer39))
    (export "function-3e61836c4ff1877794f5b42e" (type $publicResource39 (eq $outer39)))
    (type $publicBorrow39 (borrow $publicResource39))
    (type $publicOwn39 (own $publicResource39))
    (export "call-host" (func (param "arg0" $publicBorrow32) (result $public10)))
    (export "call-host-container" (func (param "arg0" $publicBorrow33) (result $public10)))
    (export "call-host-mixed" (func (param "arg0" $publicBorrow34) (result $public10)))
    (export "call-host-nested" (func (param "arg0" $publicBorrow35) (result $public10)))
    (export "make-closure" (func (param "arg0" $public10) (result $publicOwn36)))
    (export "make-container-closure" (func (param "arg0" $public10) (result $publicOwn37)))
    (export "make-mixed-closure" (func (param "arg0" $public10) (result $publicOwn38)))
    (export "make-nested-closure" (func (param "arg0" $public10) (result $publicOwn39)))
    (export "invoke-function-499c879a3d450f66047fcee3" (func (param "self" $publicBorrow32) (param "arg0" $public30) (result $public30)))
    (export "invoke-function-14ccabf25ea1719eb709d075" (func (param "self" $publicBorrow33) (param "arg0" $public17) (result $public19)))
    (export "invoke-function-be5c64001874227d88d0b54c" (func (param "self" $publicBorrow34) (param "arg0" $public10) (param "arg1" $public30) (result $public30)))
    (export "invoke-function-9ac1e60c77fb6fe8a7617d3a" (func (param "self" $publicBorrow35) (param "arg0" $public31) (result $public31)))
    (export "invoke-function-0cfd8b76dd97d47004a852b0" (func (param "self" $publicBorrow36) (param "arg0" $public30) (result $public10)))
    (export "invoke-function-e8004d28621f9b553f4c83a6" (func (param "self" $publicBorrow37) (param "arg0" $public23) (result $public17)))
    (export "invoke-function-4cf83a83d390acbc64c0ac23" (func (param "self" $publicBorrow38) (param "arg0" $public10) (param "arg1" $public30) (result $public30)))
    (export "invoke-function-3e61836c4ff1877794f5b42e" (func (param "self" $publicBorrow39) (param "arg0" $public31) (result $public10)))
  ))
  (instance $public
    (export "lb-graph-ref3" (type $public1))
    (export "bridge-value-2" (type $public2))
    (export "bridge-value-3" (type $public3))
    (export "lb-graph-ref0" (type $public4))
    (export "bridge-value-5" (type $public5))
    (export "bridge-value-6" (type $public6))
    (export "bridge-value-8" (type $public8))
    (export "bridge-value-9" (type $public9))
    (export "bridge-value-10" (type $public10))
    (export "lb-graph-node3" (type $public11))
    (export "bridge-value-12" (type $public12))
    (export "lb-graph-node4" (type $public13))
    (export "bridge-value-14" (type $public14))
    (export "lb-graph-node0" (type $public24))
    (export "bridge-alias-value-25" (type $public25))
    (export "lb-graph-node1" (type $public26))
    (export "bridge-alias-value-27" (type $public27))
    (export "lb-graph-node2" (type $public28))
    (export "bridge-alias-value-29" (type $public29))
    (export "lb-graph-arena" (type $public15))
    (export "lb-graph-value3" (type $public16))
    (export "lb-graph-value0" (type $public17))
    (export "lb-graph-ref2" (type $public18))
    (export "lb-graph-value2" (type $public19))
    (export "lb-graph-ref4" (type $public20))
    (export "lb-graph-value4" (type $public21))
    (export "lb-graph-ref1" (type $public22))
    (export "lb-graph-value1" (type $public23))
    (export "interval" (type $public30))
    (export "weighted" (type $public31))
    (export "function-499c879a3d450f66047fcee3" (type $publicResource32))
    (export "function-14ccabf25ea1719eb709d075" (type $publicResource33))
    (export "function-be5c64001874227d88d0b54c" (type $publicResource34))
    (export "function-9ac1e60c77fb6fe8a7617d3a" (type $publicResource35))
    (export "function-0cfd8b76dd97d47004a852b0" (type $publicResource36))
    (export "function-e8004d28621f9b553f4c83a6" (type $publicResource37))
    (export "function-4cf83a83d390acbc64c0ac23" (type $publicResource38))
    (export "function-3e61836c4ff1877794f5b42e" (type $publicResource39))
    (export "call-host" (func $f0))
    (export "call-host-container" (func $f1))
    (export "call-host-mixed" (func $f2))
    (export "call-host-nested" (func $f3))
    (export "make-closure" (func $f4))
    (export "make-container-closure" (func $f5))
    (export "make-mixed-closure" (func $f6))
    (export "make-nested-closure" (func $f7))
    (export "invoke-function-499c879a3d450f66047fcee3" (func $f8))
    (export "invoke-function-14ccabf25ea1719eb709d075" (func $f9))
    (export "invoke-function-be5c64001874227d88d0b54c" (func $f10))
    (export "invoke-function-9ac1e60c77fb6fe8a7617d3a" (func $f11))
    (export "invoke-function-0cfd8b76dd97d47004a852b0" (func $f12))
    (export "invoke-function-e8004d28621f9b553f4c83a6" (func $f13))
    (export "invoke-function-4cf83a83d390acbc64c0ac23" (func $f14))
    (export "invoke-function-3e61836c4ff1877794f5b42e" (func $f15))
  )
  (export "lean-bridge:callback-checked-records/api@1.0.0" (instance $public) (instance (type $public-api)))
)
