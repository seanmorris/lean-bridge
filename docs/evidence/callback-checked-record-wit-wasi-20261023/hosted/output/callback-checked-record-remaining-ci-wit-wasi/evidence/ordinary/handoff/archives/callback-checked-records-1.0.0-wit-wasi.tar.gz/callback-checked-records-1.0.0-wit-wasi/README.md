# callback-checked-records 1.0.0

Compiled Lean recursive values, callbacks and returned functions for Linux x86-64, glibc 2.38 or newer. This archive includes Wasmtime 42.0.1, the Component Model binary, generated headers and the shared native Lean runtime. Consumers do not install Lean. Keep include/ and lib/ together.

## Call the installed package

Compile a C or C++ application with pkg-config callback-checked-records-wit and include callbackcheckedrecords_wasmtime.h. Open a session with callbackcheckedrecords_wasmtime_open. Call the typed callbackcheckedrecords_wasmtime_value_* helpers listed in binding-manifest.json. Each helper crosses the embedded Component Model binary before entering Lean. Typed copied values use the generated graph structs; the helpers create and read WIT's finite node tables internally.

Arguments borrow immutable values for the call. Initialize each result with {0}. A successful copied result owns independent storage and remains valid after closing its session or library handle. Release it with its type's _clear function. Repeated clear is harmless; do not duplicate an owned root and clear both copies. Fresh result slots are required. Failures leave them unchanged. Delete returned errors with wasmtime_error_delete.

## Callbacks and returned functions

Register a typed callback with the export's callbackcheckedrecords_wasmtime_*_callbackN_create helper, where N is its zero-based parameter position. The matching names appear in binding-manifest.json. Registration returns an opaque callbackcheckedrecords_wasmtime_function token. Pass that token to an export expecting the same signature. The callback borrows its arguments. Use the copied type's _wasmtime_copy helper to create an independent reply. The adapter consumes an owned reply on success and on failure. An unowned reply must remain valid until the adapter finishes copying it after the callback returns. Never return pointers to a callback's local stack objects.

A callback whose result contains a checked Lean Subtype or checked record must be registered with its typed create helper's recovery argument. Registration makes an owned checked copy before application execution; Lean uses it only when the callback reply fails the selected constructor.

Callback data transfers only when registration succeeds. Its optional release function runs once after active calls finish. Finalizers must not reenter the session. Lean borrows a registered host callback only during the exporting call. If Lean retains that borrow, later invocation fails even while its session token remains open.

Returned Lean functions use owned tokens. Invoke them with the returning export's callbackcheckedrecords_wasmtime_*_call helper from binding-manifest.json. Close a token with callbackcheckedrecords_wasmtime_function_close(session, &token). Successful close zeroes that variable. Closing zero is harmless. Closing a token invalidates its aliases immediately and defers cleanup of active uses. Wrong-session, wrong-signature and stale tokens fail before Wasmtime execution.

Close sessions with callbackcheckedrecords_wasmtime_close. Sessions and tokens belong to their creating thread and process. Wrong-thread close does nothing; the owner must still close the session. Closing inside a callback defers destruction until the outer call returns an error. Do not use a closed session. Separate sessions and packages share the native runtime automatically but cannot exchange tokens.

## Values and transport

Arrays and Lists preserve order and duplicates. Options, results and variants retain explicit tags, including nested options and present Unit. Strings use UTF-8 byte lengths and preserve embedded NUL. Nat and Int use least-significant-first uint32 limbs; trailing zero limbs and negative zero are rejected. Float values preserve NaN classification, infinity and signed zero. Binding metadata preserves original aliases and callable identities.

WIT cannot declare recursive types directly. Each copied wire value holds a typed root reference and finite typed node tables. References identify nodes within that value, never persistent resources. All rows must be reachable from the root. The adapter rejects cycles, invalid indices, constructors and noncanonical scalars. A shared acyclic child is copied independently at each occurrence. The manifest separates original Lean declarations and proof metadata from this generated transport.

The raw callbackcheckedrecords_wasmtime_invoke API takes WIT values and function tokens. Delete its copied results with wasmtime_component_val_delete. component/callback-checked-records.wasm requires this native host; it is not a standalone WASI command. Callable imports require the owning session. callbackcheckedrecords_wasmtime_link rejects custom linkers without modifying them.

## Limits and failures

Copied values permit 128 nested levels and 262,144 expanded node visits. Input and output conversions have separate 16 MiB copy budgets. The native carrier enforces its own bounded scopes. Canonical scratch memory is capped at 64 MiB. These limits do not bound Lean algorithm or Wasmtime engine working memory. Wasmtime allocation APIs do not expose recoverable out-of-memory errors.

Each session holds at most 1024 callable tokens. Native leases also consume the shared runtime's identity capacity. Synchronous callback reentry is bounded at 64 calls. The first callback error is preserved, with its message limited to 1023 bytes. Traps poison the active chain; after unwinding, the session replaces its store and preserves surviving tokens. Failed calls release temporary storage and unreturned leases. Malformed native outputs retire the shared Lean runtime. Resource-containing aggregates, nested callable payloads and asynchronous calls require separate contracts and are not admitted here.

## Exports

- callbackcheckedrecords_wasmtime_value_call_host: lean:CallbackCheckedRecords.callHost (WIT call-host)
- callbackcheckedrecords_wasmtime_value_call_host_container: lean:CallbackCheckedRecords.callHostContainer (WIT call-host-container)
- callbackcheckedrecords_wasmtime_value_call_host_mixed: lean:CallbackCheckedRecords.callHostMixed (WIT call-host-mixed)
- callbackcheckedrecords_wasmtime_value_call_host_nested: lean:CallbackCheckedRecords.callHostNested (WIT call-host-nested)
- callbackcheckedrecords_wasmtime_value_make_closure: lean:CallbackCheckedRecords.makeClosure (WIT make-closure)
- callbackcheckedrecords_wasmtime_value_make_container_closure: lean:CallbackCheckedRecords.makeContainerClosure (WIT make-container-closure)
- callbackcheckedrecords_wasmtime_value_make_mixed_closure: lean:CallbackCheckedRecords.makeMixedClosure (WIT make-mixed-closure)
- callbackcheckedrecords_wasmtime_value_make_nested_closure: lean:CallbackCheckedRecords.makeNestedClosure (WIT make-nested-closure)

## Loaded-library identity

The host checks the loaded native adapter, Lean component, both runtime libraries and Wasmtime against the sizes and SHA-256 hashes in its compiler receipts. A conflicting library already loaded under the same name makes session opens, calls and custom-linker imports return an error. Keep the installed library files unchanged while loading hosts. Inherited hosts reject calls and session opens after fork; exec a fresh consumer process. Closing an inherited session in the child does nothing. The parent still owns its session.
