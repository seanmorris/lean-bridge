#include "component.h"
#include "lean_bridge_native_runtime.h"
static _Thread_local int lean_bridge_owned_callback_failure_58757d343423a2b300ab_state;
int lean_bridge_owned_callback_failure_58757d343423a2b300ab(void) { int result = lean_bridge_owned_callback_failure_58757d343423a2b300ab_state; lean_bridge_owned_callback_failure_58757d343423a2b300ab_state = 0; return result; }
