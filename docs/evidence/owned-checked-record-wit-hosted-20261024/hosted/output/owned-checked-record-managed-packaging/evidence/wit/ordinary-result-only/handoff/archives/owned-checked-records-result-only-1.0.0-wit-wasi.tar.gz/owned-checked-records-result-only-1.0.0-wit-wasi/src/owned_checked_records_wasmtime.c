#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif
#include <dlfcn.h>
#include <link.h>

#include <errno.h>
#include <fcntl.h>
#include <stdint.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

typedef struct {
  uint32_t words[8];
  uint64_t bytes;
  size_t used;
  unsigned char block[64];
} lb_receipt_hash;

static uint32_t lb_receipt_rotr(uint32_t x, unsigned n) {
  return (x >> n) | (x << (32u - n));
}
static void lb_receipt_block(lb_receipt_hash *hash, const unsigned char *block) {
  static const uint32_t constants[64] = {
    0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
    0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
    0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
    0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
    0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
    0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
    0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
    0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2
  };
  uint32_t w[64];
  for (size_t i = 0; i < 16; ++i)
    w[i] = ((uint32_t)block[4*i] << 24) | ((uint32_t)block[4*i+1] << 16)
      | ((uint32_t)block[4*i+2] << 8) | block[4*i+3];
  for (size_t i = 16; i < 64; ++i) {
    uint32_t x = w[i-15], y = w[i-2];
    w[i] = w[i-16] + (lb_receipt_rotr(x,7) ^ lb_receipt_rotr(x,18) ^ (x >> 3))
      + w[i-7] + (lb_receipt_rotr(y,17) ^ lb_receipt_rotr(y,19) ^ (y >> 10));
  }
  uint32_t a=hash->words[0], b=hash->words[1], c=hash->words[2], d=hash->words[3];
  uint32_t e=hash->words[4], f=hash->words[5], g=hash->words[6], h=hash->words[7];
  for (size_t i = 0; i < 64; ++i) {
    uint32_t t1 = h + (lb_receipt_rotr(e,6) ^ lb_receipt_rotr(e,11) ^ lb_receipt_rotr(e,25))
      + ((e & f) ^ (~e & g)) + constants[i] + w[i];
    uint32_t t2 = (lb_receipt_rotr(a,2) ^ lb_receipt_rotr(a,13) ^ lb_receipt_rotr(a,22))
      + ((a & b) ^ (a & c) ^ (b & c));
    h=g; g=f; f=e; e=d+t1; d=c; c=b; b=a; a=t1+t2;
  }
  hash->words[0]+=a; hash->words[1]+=b; hash->words[2]+=c; hash->words[3]+=d;
  hash->words[4]+=e; hash->words[5]+=f; hash->words[6]+=g; hash->words[7]+=h;
}
static void lb_receipt_update(lb_receipt_hash *hash, const unsigned char *bytes, size_t count) {
  hash->bytes += count;
  while (count) {
    size_t take = 64 - hash->used;
    if (take > count) take = count;
    memcpy(hash->block + hash->used, bytes, take);
    hash->used += take; bytes += take; count -= take;
    if (hash->used == 64) { lb_receipt_block(hash, hash->block); hash->used = 0; }
  }
}
static void lb_receipt_finish(lb_receipt_hash *hash, char out[65]) {
  static const char hex[] = "0123456789abcdef";
  uint64_t bits = hash->bytes * UINT64_C(8);
  unsigned char padding[128] = {0x80};
  size_t count = hash->used < 56 ? 56 - hash->used : 120 - hash->used;
  for (size_t i = 0; i < 8; ++i) padding[count+i] = (unsigned char)(bits >> (56-8*i));
  lb_receipt_update(hash, padding, count + 8);
  for (size_t i = 0; i < 32; ++i) {
    unsigned byte = (hash->words[i/4] >> (24-8*(i%4))) & 255u;
    out[2*i] = hex[byte >> 4]; out[2*i+1] = hex[byte & 15];
  }
  out[64] = 0;
}
static int lb_receipt_file_matches(const char *path, uint64_t bytes, const char *expected) {
  int fd = open(path, O_RDONLY | O_CLOEXEC | O_NOFOLLOW | O_NONBLOCK);
  if (fd < 0) return 0;
  struct stat before, after;
  int valid = !fstat(fd, &before) && S_ISREG(before.st_mode) && before.st_size >= 0
    && (uint64_t)before.st_size == bytes && bytes <= UINT64_MAX/8;
  lb_receipt_hash hash = {.words = {0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,
    0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19}};
  unsigned char buffer[16384];
  while (valid) {
    ssize_t count = read(fd, buffer, sizeof(buffer));
    if (count < 0 && errno == EINTR) continue;
    if (count < 0) { valid = 0; break; }
    if (!count) break;
    if ((uint64_t)count > bytes - hash.bytes) { valid = 0; break; }
    lb_receipt_update(&hash, buffer, (size_t)count);
  }
  valid = valid && hash.bytes == bytes && !fstat(fd, &after)
    && before.st_size == after.st_size
    && before.st_mtim.tv_sec == after.st_mtim.tv_sec && before.st_mtim.tv_nsec == after.st_mtim.tv_nsec
    && before.st_ctim.tv_sec == after.st_ctim.tv_sec && before.st_ctim.tv_nsec == after.st_ctim.tv_nsec;
  if (close(fd)) valid = 0;
  char actual[65]; lb_receipt_finish(&hash, actual);
  return valid && !strcmp(actual, expected);
}


static pid_t lb_package_pid;
/* Private loader handshake, not a consumer API. Keep each host's origin local
 * even when another host exports the same handshake symbol. */
__attribute__((visibility("default"))) pid_t __lean_bridge_wit_host_process_origin_v1(void) {
  return lb_package_pid;
}
static const char *lb_package_problem = "WIT package dependencies have not been verified";
static const struct { const char *name; uint64_t bytes; const char *sha256; } lb_package_libraries[] = {
  {"libcomponent_161bdaa35ee11fef40c6.so", UINT64_C(60464), "689a97492369419c9781942b80657ace2f12ba44ddca57b865ad8de168157fba"},
  {"libgmp.so.10", UINT64_C(735208), "1980c7331f830ab5291a3ec606e03fdc4d00ce7b8a93da6c64da10806ea36cd7"},
  {"liblean_bridge_native.so", UINT64_C(21632), "459fcd2098d4b646ab6ae0f4cdccd1f222908cb162562bfc3940a533cd4e4e21"},
  {"libleanshared.so", UINT64_C(158401256), "d7768b88d8162736da4305777cd6f147676038fd885bd8a265c958b0ecea00b4"},
  {"libwasmtime.so", UINT64_C(22277728), "566e57cfeabafd6d44fab1b5e6660b4569a71aae4cff2e4d89563a424ee799f3"}
};
typedef struct { unsigned seen[5]; const char *failure; } lb_package_scan;
static int lb_package_process(struct dl_phdr_info *info, size_t size, void *data) {
  (void)size;
  lb_package_scan *scan = data;
  const char *path = info->dlpi_name;
  if (!path || !*path) return 0;
  const char *slash = strrchr(path, '/'), *name = slash ? slash+1 : path;
  const char suffix[] = "_wasmtime.so";
  size_t length = strlen(name);
  if (length <= 3 + sizeof(suffix)-1 || strncmp(name, "lib", 3)
      || strcmp(name+length-(sizeof(suffix)-1), suffix)) return 0;
  void *loaded = dlopen(path, RTLD_NOW | RTLD_NOLOAD);
  if (!loaded) { scan->failure = "Cannot inspect loaded WIT host"; return 1; }
  void *address = dlsym(loaded, "__lean_bridge_wit_host_process_origin_v1");
  Dl_info owner;
  /* dlsym also searches dependencies. Only use this library's own marker. */
  if (address && dladdr(address, &owner) && owner.dli_fbase == (void *)info->dlpi_addr) {
    pid_t (*origin)(void);
    _Static_assert(sizeof(origin) == sizeof(address), "POSIX function pointer");
    memcpy(&origin, &address, sizeof(origin));
    pid_t process = origin();
    /* A host whose constructor has not run yet has no Wasmtime state. */
    if (process && process != getpid())
      scan->failure = "WIT hosts cannot be used after fork; exec a fresh process";
  }
  dlclose(loaded);
  return scan->failure != NULL;
}
static int lb_package_library(struct dl_phdr_info *info, size_t size, void *data) {
  (void)size;
  lb_package_scan *scan = data;
  const char *path = info->dlpi_name;
  if (!path || !*path) return 0;
  const char *slash = strrchr(path, '/'), *name = slash ? slash+1 : path;
  for (size_t i = 0; i < sizeof(lb_package_libraries)/sizeof(lb_package_libraries[0]); ++i) {
    if (strcmp(name, lb_package_libraries[i].name)) continue;
    if (!lb_receipt_file_matches(path, lb_package_libraries[i].bytes, lb_package_libraries[i].sha256)) {
      scan->failure = "WIT package dependency conflict: loaded library differs from its receipt";
      return 1;
    }
    /* Resolve lazy dependency relocations before another host is loaded. */
    void *loaded = dlopen(path, RTLD_NOW | RTLD_NOLOAD);
    if (!loaded) { scan->failure = "Cannot bind verified WIT dependency"; return 1; }
    dlclose(loaded);
    scan->seen[i] = 1;
  }
  return 0;
}
__attribute__((constructor)) static void lb_package_verify(void) {
  lb_package_pid = getpid();
  lb_package_scan scan = {0};
  dl_iterate_phdr(lb_package_process, &scan);
  if (!scan.failure) dl_iterate_phdr(lb_package_library, &scan);
  for (size_t i = 0; i < sizeof(scan.seen)/sizeof(scan.seen[0]); ++i)
    if (!scan.seen[i] && !scan.failure) scan.failure = "WIT package dependency is missing from the loaded libraries";
  lb_package_problem = scan.failure;
}
static const char *lb_package_failure(void) {
  if (getpid() != lb_package_pid) return "WIT hosts cannot be used after fork; exec a fresh process";
  return lb_package_problem;
}
#include "owned_checked_records_wasmtime.h"
#include "owned-values.h"
#include "carriers.h"

#include <stddef.h>
#include <stdint.h>
#include <string.h>
#include "owned-leases.h"
_Static_assert(sizeof(void *) == 8 && sizeof(size_t) == 8, "owned native values require 64-bit Lean");
enum { OV_RESULT = 9 };
typedef struct {
  size_t bytes, visits;
  struct { const void *address; size_t type; } path[129];
} ov_budget;
typedef struct ov_allocation {
  struct ov_allocation *next;
  max_align_t alignment;
  unsigned char data[];
} ov_allocation;
typedef struct {
  lb_owned_scope scope;
  ov_budget budget;
  ov_allocation *allocations;
} ov_transaction;
typedef struct ov_result_owner {
  struct ov_result_owner *self;
  lb_owned_context *context;
  lb_owned_batch batch;
  ov_allocation *allocations;
} ov_result_owner;

static inline void ov_release(ov_allocation *allocation) {
  while (allocation) {
    ov_allocation *next = allocation->next; LB_OWNED_FREE(allocation); allocation = next;
  }
}
static inline int ov_pointer(const void *value, size_t bytes, size_t alignment) {
  return value && (uintptr_t)value % alignment == 0 && bytes <= UINTPTR_MAX - (uintptr_t)value;
}
static inline int ov_charge(ov_budget *budget, size_t count, size_t width) {
  if (!width || count > budget->bytes / width) return LB_OWNED_LIMIT;
  budget->bytes -= count * width; return LB_OWNED_OK;
}
static inline int ov_visit(ov_budget *budget, size_t depth) {
  if (depth > 128 || !budget->visits) return LB_OWNED_LIMIT;
  --budget->visits; return LB_OWNED_OK;
}
static inline int ov_enter(ov_budget *budget, const void *value, size_t type, size_t depth) {
  int status = ov_visit(budget, depth);
  if (status) return status;
  for (size_t i = 0; i < depth; ++i)
    if (budget->path[i].address == value && budget->path[i].type == type) return LB_OWNED_INVALID;
  budget->path[depth].address = value; budget->path[depth].type = type;
  return LB_OWNED_OK;
}
static inline int ov_span(ov_budget *budget, const void *value, size_t count, size_t width, size_t alignment) {
  int status = ov_charge(budget, count, width);
  if (status) return status;
  return !count || ov_pointer(value, count * width, alignment) ? LB_OWNED_OK : LB_OWNED_INVALID;
}
static inline int ov_allocate(ov_transaction *transaction, size_t count, size_t width, void **out) {
  *out = NULL; if (!count) return LB_OWNED_OK;
  int status = ov_charge(&transaction->budget, count, width);
  if (!status) status = ov_charge(&transaction->budget, 1, sizeof(ov_allocation));
  if (status) return status;
  ov_allocation *allocation = LB_OWNED_ALLOC(sizeof(*allocation) + count * width);
  if (!allocation) return LB_OWNED_ALLOC_FAILED;
  allocation->next = transaction->allocations; transaction->allocations = allocation;
  memset(allocation->data, 0, count * width); *out = allocation->data; return LB_OWNED_OK;
}
static inline int ov_utf8(const uint8_t *data, size_t length) {
  size_t i = 0;
  while (i < length) {
    uint32_t point = data[i++], minimum; size_t extra;
    if (point < 0x80) continue;
    if (point >= 0xc2 && point <= 0xdf) { point &= 0x1f; extra = 1; minimum = 0x80; }
    else if (point >= 0xe0 && point <= 0xef) { point &= 0x0f; extra = 2; minimum = 0x800; }
    else if (point >= 0xf0 && point <= 0xf4) { point &= 7; extra = 3; minimum = 0x10000; }
    else return 0;
    if (extra > length - i) return 0;
    while (extra--) { uint8_t next = data[i++]; if ((next & 0xc0) != 0x80) return 0; point = (point << 6) | (next & 0x3f); }
    if (point < minimum || point > 0x10ffff || (point >= 0xd800 && point <= 0xdfff)) return 0;
  }
  return 1;
}
static inline lean_object *ov_nat_in(const uint32_t *data, size_t length) {
  lean_object *value = lean_box(0);
  while (length) {
    lean_object *shifted = lean_nat_shiftl(value, lean_box(32)); lean_dec(value);
    lean_object *limb = lean_uint32_to_nat(data[--length]);
    value = lean_nat_add(shifted, limb); lean_dec(shifted); lean_dec(limb);
  }
  return value;
}
static inline int ov_nat_out(lean_object *value, ov_transaction *transaction, const uint32_t **data, size_t *length) {
  *data = NULL; *length = 0;
  if (lean_nat_eq(value, lean_box(0))) return LB_OWNED_OK;
  lean_object *bits = lean_nat_log2(value);
  if (!lean_is_scalar(bits)) { lean_dec(bits); return LB_OWNED_LIMIT; }
  size_t count = lean_unbox(bits) / 32 + 1; lean_dec(bits);
  void *raw = NULL; int status = ov_allocate(transaction, count, sizeof(uint32_t), &raw);
  if (status) return status;
  uint32_t *limbs = raw; lean_inc(value);
  for (size_t i = 0; i < count; ++i) {
    limbs[i] = lean_uint32_of_nat(value);
    lean_object *next = lean_nat_shiftr(value, lean_box(32)); lean_dec(value); value = next;
  }
  lean_dec(value); *data = limbs; *length = count; return LB_OWNED_OK;
}
static inline lean_object *ov_carry(lean_object *value) {
  lean_object *carrier = lean_alloc_array(1, 1); lean_array_set_core(carrier, 0, value); return carrier;
}
static inline int ov_carrier(lean_object *value) {
  return value && !lean_is_scalar(value) && lean_is_array(value) && lean_array_size(value) == 1;
}
static inline int ov_finish(lean_object *value, lean_object **out) {
  if (!ov_carrier(value)) { if (value) lean_dec(value); return OV_RESULT; }
  *out = value; return LB_OWNED_OK;
}
static inline int ov_owner_empty(const ov_result_owner *owner) {
  return owner && !owner->self && !owner->context && !owner->allocations
    && !owner->batch.context && !owner->batch.entries && !owner->batch.next;
}
static inline int ov_owner_clear(ov_result_owner *owner) {
  if (!owner) return LB_OWNED_INVALID;
  if (ov_owner_empty(owner)) return LB_OWNED_OK;
  if (owner->self != owner || !owner->context) return LB_OWNED_INVALID;
  lb_owned_context *context = owner->context;
  if (context->self != context) return LB_OWNED_INVALID;
  if (context->process != getpid()) return LB_OWNED_PROCESS;
  if (!pthread_equal(context->thread, pthread_self()) || context->thread_serial != lb_owned_thread_serial)
    return LB_OWNED_THREAD;
  int status = LB_OWNED_OK;
  if (owner->batch.context) status = lb_owned_batch_release(context, &owner->batch);
  /* A broker error can be reported after release has drained the batch. */
  if (owner->batch.context) return status;
  ov_release(owner->allocations); *owner = (ov_result_owner){0}; return status;
}
static inline int ov_begin(ov_transaction *transaction, lb_owned_context *context, ov_result_owner *owner, const char *component) {
  if (!ov_owner_empty(owner)) return LB_OWNED_INVALID;
  int status = lb_owned_ready(context);
  if (status) return status;
  if (strcmp(context->component, component)) return LB_OWNED_INVALID;
  *transaction = (ov_transaction){0};
  transaction->budget.bytes = 16777216; transaction->budget.visits = 262144;
  return lb_owned_scope_begin(context, &transaction->scope);
}
static inline int ov_abort(ov_transaction *transaction, int status) {
  ov_release(transaction->allocations); transaction->allocations = NULL;
  if (transaction->scope.context) {
    if (status == OV_RESULT) lean_bridge_native_runtime_retire();
    int cleanup = lb_owned_scope_abort(&transaction->scope);
    if (!status) status = cleanup;
  }
  return status;
}
static inline int ov_commit(ov_transaction *transaction, ov_result_owner *owner) {
  lb_owned_context *context = transaction->scope.context;
  int status = lb_owned_scope_ready(&transaction->scope);
  if (status) return ov_abort(transaction, status);
  if (!transaction->allocations && !transaction->scope.outputs)
    return ov_abort(transaction, LB_OWNED_OK);
  status = lb_owned_scope_commit(&transaction->scope, &owner->batch);
  if (status) {
    /* Commit may have transferred outputs before dropping a failing input pin. */
    if (owner->batch.context) lb_owned_batch_release(context, &owner->batch);
    return ov_abort(transaction, status);
  }
  owner->self = owner; owner->context = context; owner->allocations = transaction->allocations;
  transaction->allocations = NULL; return LB_OWNED_OK;
}


enum { OV_CALLBACK = 10 };
typedef struct ov_callback_frame {
  struct ov_callback_frame *parent;
  ov_transaction *transaction;
  int status;
} ov_callback_frame;
static _Thread_local ov_callback_frame *ov_active_callback_frame;
static inline void ov_callback_fail(ov_callback_frame *frame, int status) {
  if (frame && !frame->status) frame->status = status;
}

static inline int lbov_ac77c4cfe87b7cbcbb00_v160ce821a84f6887bbfd_in(const lbov_ac77c4cfe87b7cbcbb00_t160ce821a84f6887bbfd *, size_t, int, ov_transaction *, lean_object **);
static inline int lbov_ac77c4cfe87b7cbcbb00_v160ce821a84f6887bbfd_out(lbov_ac77c4cfe87b7cbcbb00_t160ce821a84f6887bbfd *, lean_object *, size_t, ov_transaction *);
static inline int lbov_ac77c4cfe87b7cbcbb00_vb2825946e038e653bd2b_in(const lbov_ac77c4cfe87b7cbcbb00_tb2825946e038e653bd2b *, size_t, int, ov_transaction *, lean_object **);
static inline int lbov_ac77c4cfe87b7cbcbb00_vb2825946e038e653bd2b_out(lbov_ac77c4cfe87b7cbcbb00_tb2825946e038e653bd2b *, lean_object *, size_t, ov_transaction *);
static inline int lbov_ac77c4cfe87b7cbcbb00_vd79b9bbde250ee1779da_in(const lbov_ac77c4cfe87b7cbcbb00_td79b9bbde250ee1779da *, size_t, int, ov_transaction *, lean_object **);
static inline int lbov_ac77c4cfe87b7cbcbb00_vd79b9bbde250ee1779da_out(lbov_ac77c4cfe87b7cbcbb00_td79b9bbde250ee1779da *, lean_object *, size_t, ov_transaction *);
static inline int lbov_ac77c4cfe87b7cbcbb00_v167081552b6f9c1d1afd_in(const lbov_ac77c4cfe87b7cbcbb00_t167081552b6f9c1d1afd *, size_t, int, ov_transaction *, lean_object **);
static inline int lbov_ac77c4cfe87b7cbcbb00_v167081552b6f9c1d1afd_out(lbov_ac77c4cfe87b7cbcbb00_t167081552b6f9c1d1afd *, lean_object *, size_t, ov_transaction *);
static inline int lbov_ac77c4cfe87b7cbcbb00_vdc0347e1f7f5c4d928f1_in(const lbov_ac77c4cfe87b7cbcbb00_tdc0347e1f7f5c4d928f1 *, size_t, int, ov_transaction *, lean_object **);
static inline int lbov_ac77c4cfe87b7cbcbb00_vdc0347e1f7f5c4d928f1_out(lbov_ac77c4cfe87b7cbcbb00_tdc0347e1f7f5c4d928f1 *, lean_object *, size_t, ov_transaction *);
static inline int lbov_ac77c4cfe87b7cbcbb00_v160ce821a84f6887bbfd_in(const lbov_ac77c4cfe87b7cbcbb00_t160ce821a84f6887bbfd *value, size_t depth, int storage, ov_transaction *transaction, lean_object **out) {
  *out = NULL;
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_ac77c4cfe87b7cbcbb00_t160ce821a84f6887bbfd))) return LB_OWNED_INVALID;
  int status = ov_enter(&transaction->budget, value, 0, depth);
  if (!status && storage) status = ov_charge(&transaction->budget, 1, sizeof(*value));
  if (status) return status;
  if (value->tag > 1) return LB_OWNED_INVALID;
  if (!value->tag) return ov_finish(lean_bridge_owned_85878987b062b3d15bbb3e20_t160ce821a84f6887bbfd_none(lean_box(0)), out);
  if (value->tag == 1) {
    lean_object *child = NULL;
    status = lbov_ac77c4cfe87b7cbcbb00_vb2825946e038e653bd2b_in(value->f0, depth + 1, 1, transaction, &child);
    if (status) return status;
    return ov_finish(lean_bridge_owned_85878987b062b3d15bbb3e20_t160ce821a84f6887bbfd_make0(child), out);
  }
  return LB_OWNED_INVALID;
}
static inline int lbov_ac77c4cfe87b7cbcbb00_v160ce821a84f6887bbfd_out(lbov_ac77c4cfe87b7cbcbb00_t160ce821a84f6887bbfd *out, lean_object *value, size_t depth, ov_transaction *transaction) {
  int status = ov_visit(&transaction->budget, depth);
  if (status) { if (value) lean_dec(value); return status; }
  if (!ov_carrier(value)) { if (value) lean_dec(value); return OV_RESULT; }
  lean_inc(value);
  uint32_t tag = lean_bridge_owned_85878987b062b3d15bbb3e20_t160ce821a84f6887bbfd_branch(value);
  if (tag > 1) { lean_dec(value); return OV_RESULT; }
  out->tag = (uint8_t)tag;
  if (out->tag == 1) {
  if (!status) {
    void *raw = NULL;
    status = ov_allocate(transaction, 1, sizeof(lbov_ac77c4cfe87b7cbcbb00_tb2825946e038e653bd2b), &raw);
    out->f0 = raw;
    if (!status) {
      lean_inc(value);
      status = lbov_ac77c4cfe87b7cbcbb00_vb2825946e038e653bd2b_out(raw, lean_bridge_owned_85878987b062b3d15bbb3e20_t160ce821a84f6887bbfd_field0(value), depth + 1, transaction);
    }
  }
  }
  lean_dec(value); return status;
}
__attribute__((noinline)) static lean_object *lbov_ac77c4cfe87b7cbcbb00_vb2825946e038e653bd2b_make(lean_object *items) {
  lean_object *a0 = lean_array_get_core(items, 0); lean_inc(a0);
  lean_object *a1 = lean_array_get_core(items, 1); lean_inc(a1);
  lean_dec(items);
  return lean_bridge_owned_85878987b062b3d15bbb3e20_tb2825946e038e653bd2b_make(a0, a1);
}
static inline int lbov_ac77c4cfe87b7cbcbb00_vb2825946e038e653bd2b_in(const lbov_ac77c4cfe87b7cbcbb00_tb2825946e038e653bd2b *value, size_t depth, int storage, ov_transaction *transaction, lean_object **out) {
  *out = NULL;
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_ac77c4cfe87b7cbcbb00_tb2825946e038e653bd2b))) return LB_OWNED_INVALID;
  int status = ov_enter(&transaction->budget, value, 1, depth);
  if (!status && storage) status = ov_charge(&transaction->budget, 1, sizeof(*value));
  if (status) return status;
  lean_object *items = lean_alloc_array(0, 2);
  lean_object *child = NULL;
  status = lbov_ac77c4cfe87b7cbcbb00_vd79b9bbde250ee1779da_in(&value->f0, depth + 1, 0, transaction, &child);
  if (status) { lean_dec(items); return status; }
  items = lean_array_push(items, child);
  status = lbov_ac77c4cfe87b7cbcbb00_v167081552b6f9c1d1afd_in(&value->f1, depth + 1, 0, transaction, &child);
  if (status) { lean_dec(items); return status; }
  items = lean_array_push(items, child);
  return ov_finish(lbov_ac77c4cfe87b7cbcbb00_vb2825946e038e653bd2b_make(items), out);
}
static inline int lbov_ac77c4cfe87b7cbcbb00_vb2825946e038e653bd2b_out(lbov_ac77c4cfe87b7cbcbb00_tb2825946e038e653bd2b *out, lean_object *value, size_t depth, ov_transaction *transaction) {
  int status = ov_visit(&transaction->budget, depth);
  if (status) { if (value) lean_dec(value); return status; }
  if (!ov_carrier(value)) { if (value) lean_dec(value); return OV_RESULT; }
  if (!status) {
    if (!status) {
      lean_inc(value);
      status = lbov_ac77c4cfe87b7cbcbb00_vd79b9bbde250ee1779da_out(&out->f0, lean_bridge_owned_85878987b062b3d15bbb3e20_tb2825946e038e653bd2b_field0(value), depth + 1, transaction);
    }
  }
  if (!status) {
    if (!status) {
      lean_inc(value);
      status = lbov_ac77c4cfe87b7cbcbb00_v167081552b6f9c1d1afd_out(&out->f1, lean_bridge_owned_85878987b062b3d15bbb3e20_tb2825946e038e653bd2b_field1(value), depth + 1, transaction);
    }
  }
  lean_dec(value); return status;
}
static inline int lbov_ac77c4cfe87b7cbcbb00_vd79b9bbde250ee1779da_in(const lbov_ac77c4cfe87b7cbcbb00_td79b9bbde250ee1779da *value, size_t depth, int storage, ov_transaction *transaction, lean_object **out) {
  *out = NULL;
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_ac77c4cfe87b7cbcbb00_td79b9bbde250ee1779da))) return LB_OWNED_INVALID;
  int status = ov_enter(&transaction->budget, value, 2, depth);
  if (!status && storage) status = ov_charge(&transaction->budget, 1, sizeof(*value));
  if (status) return status;
  lean_object *child = NULL;
  status = lb_owned_scope_borrow(&transaction->scope, "resource:OwnedCheckedRecords.Ticket", value->token, &child);
  if (status) return status;
  lean_inc(child); return ov_finish(ov_carry(child), out);
}
static inline int lbov_ac77c4cfe87b7cbcbb00_vd79b9bbde250ee1779da_out(lbov_ac77c4cfe87b7cbcbb00_td79b9bbde250ee1779da *out, lean_object *value, size_t depth, ov_transaction *transaction) {
  int status = ov_visit(&transaction->budget, depth);
  if (status) { if (value) lean_dec(value); return status; }
  if (!ov_carrier(value)) { if (value) lean_dec(value); return OV_RESULT; }
  lean_object *child = lean_array_get_core(value, 0);
  if (lean_is_scalar(child)) { lean_dec(value); return OV_RESULT; }
  status = lb_owned_scope_acquire(&transaction->scope, "resource:OwnedCheckedRecords.Ticket", child, &out->token);
  lean_dec(value); return status;
}
static inline int lbov_ac77c4cfe87b7cbcbb00_v167081552b6f9c1d1afd_in(const lbov_ac77c4cfe87b7cbcbb00_t167081552b6f9c1d1afd *value, size_t depth, int storage, ov_transaction *transaction, lean_object **out) {
  *out = NULL;
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_ac77c4cfe87b7cbcbb00_t167081552b6f9c1d1afd))) return LB_OWNED_INVALID;
  int status = ov_enter(&transaction->budget, value, 3, depth);
  if (!status && storage) status = ov_charge(&transaction->budget, 1, sizeof(*value));
  if (status) return status;
  status = ov_span(&transaction->budget, value->data, value->length, sizeof(uint32_t), _Alignof(uint32_t));
  if (status) return status;
  return ov_finish(ov_carry(ov_nat_in(value->data, value->length)), out);
}
static inline int lbov_ac77c4cfe87b7cbcbb00_v167081552b6f9c1d1afd_out(lbov_ac77c4cfe87b7cbcbb00_t167081552b6f9c1d1afd *out, lean_object *value, size_t depth, ov_transaction *transaction) {
  int status = ov_visit(&transaction->budget, depth);
  if (status) { if (value) lean_dec(value); return status; }
  if (!ov_carrier(value)) { if (value) lean_dec(value); return OV_RESULT; }
  lean_object *child = lean_array_get_core(value, 0); lean_inc(child); lean_dec(value);
  if (!lean_is_scalar(child) && !lean_is_mpz(child)) { lean_dec(child); return OV_RESULT; }
  status = ov_nat_out(child, transaction, &out->data, &out->length);
  lean_dec(child); return status;
}
static inline int lbov_ac77c4cfe87b7cbcbb00_vdc0347e1f7f5c4d928f1_in(const lbov_ac77c4cfe87b7cbcbb00_tdc0347e1f7f5c4d928f1 *value, size_t depth, int storage, ov_transaction *transaction, lean_object **out) {
  *out = NULL;
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_ac77c4cfe87b7cbcbb00_tdc0347e1f7f5c4d928f1))) return LB_OWNED_INVALID;
  int status = ov_enter(&transaction->budget, value, 4, depth);
  if (!status && storage) status = ov_charge(&transaction->budget, 1, sizeof(*value));
  if (status) return status;
  status = ov_span(&transaction->budget, value->data, value->length, 1, 1);
  if (status) return status;
  if (!ov_utf8((const uint8_t *)value->data, value->length)) return LB_OWNED_INVALID;
  return ov_finish(ov_carry(lean_mk_string_from_bytes(value->length ? value->data : "", value->length)), out);
}
static inline int lbov_ac77c4cfe87b7cbcbb00_vdc0347e1f7f5c4d928f1_out(lbov_ac77c4cfe87b7cbcbb00_tdc0347e1f7f5c4d928f1 *out, lean_object *value, size_t depth, ov_transaction *transaction) {
  int status = ov_visit(&transaction->budget, depth);
  if (status) { if (value) lean_dec(value); return status; }
  if (!ov_carrier(value)) { if (value) lean_dec(value); return OV_RESULT; }
  lean_object *child = lean_array_get_core(value, 0); lean_inc(child); lean_dec(value);
  if (lean_is_scalar(child) || !lean_is_string(child)) { lean_dec(child); return OV_RESULT; }
  size_t length = lean_string_size(child) - 1;
  if (!ov_utf8((const uint8_t *)lean_string_cstr(child), length)) { lean_dec(child); return OV_RESULT; }
  void *data = NULL;
  status = ov_allocate(transaction, length, 1, &data);
  if (!status) {
    if (length) memcpy(data, lean_string_cstr(child), length);
    out->data = data; out->length = length;
  }
  lean_dec(child); return status;
}
static inline int lbov_ac77c4cfe87b7cbcbb00_f483485736ace9af57086(lb_owned_context *context, const lbov_ac77c4cfe87b7cbcbb00_td79b9bbde250ee1779da *a0, lbov_ac77c4cfe87b7cbcbb00_t160ce821a84f6887bbfd *out, ov_result_owner *owner) {
  if (!ov_pointer(out, sizeof(*out), _Alignof(lbov_ac77c4cfe87b7cbcbb00_t160ce821a84f6887bbfd)) || !ov_pointer(owner, sizeof(*owner), _Alignof(ov_result_owner))) return LB_OWNED_INVALID;
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  status = ov_charge(&transaction.budget, 1, sizeof(*out));
  if (status) return ov_abort(&transaction, status);
  lean_object *arguments = lean_alloc_array(0, 1);
  {
    lean_object *child = NULL;
    status = lbov_ac77c4cfe87b7cbcbb00_vd79b9bbde250ee1779da_in(a0, 0, 1, &transaction, &child);
    if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
    arguments = lean_array_push(arguments, child);
  }
  lean_object *v0 = lean_array_get_core(arguments, 0); lean_inc(v0);
  lean_dec(arguments);
  ov_callback_frame frame = { .parent = ov_active_callback_frame, .transaction = &transaction };
  if (!frame.parent) { (void)lb_native_callback_take_error(); (void)lean_bridge_owned_callback_failure_ac77c4cfe87b7cbcbb00(); }
  ov_active_callback_frame = &frame;
  lean_object *returned = lean_bridge_owned_85878987b062b3d15bbb3e20_f483485736ace9af57086(v0);
  ov_active_callback_frame = frame.parent; status = frame.status;
  int callback_error = lb_native_callback_take_error();
  int refinement_error = lean_bridge_owned_callback_failure_ac77c4cfe87b7cbcbb00();
  if (refinement_error && !status) status = LB_OWNED_INVALID;
  else if (callback_error && !status) status = OV_CALLBACK;
  if (!status) status = lb_owned_scope_ready(&transaction.scope);
  if (status) { lean_dec(returned); return ov_abort(&transaction, status); }
  lbov_ac77c4cfe87b7cbcbb00_t160ce821a84f6887bbfd converted = {0};
  status = lbov_ac77c4cfe87b7cbcbb00_v160ce821a84f6887bbfd_out(&converted, returned, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  status = ov_commit(&transaction, owner);
  if (!status) *out = converted;
  return status;
}
static inline int lbov_ac77c4cfe87b7cbcbb00_fa1e5189bd92568e4b939(lb_owned_context *context, const lbov_ac77c4cfe87b7cbcbb00_t167081552b6f9c1d1afd *a0, const lbov_ac77c4cfe87b7cbcbb00_tdc0347e1f7f5c4d928f1 *a1, lbov_ac77c4cfe87b7cbcbb00_td79b9bbde250ee1779da *out, ov_result_owner *owner) {
  if (!ov_pointer(out, sizeof(*out), _Alignof(lbov_ac77c4cfe87b7cbcbb00_td79b9bbde250ee1779da)) || !ov_pointer(owner, sizeof(*owner), _Alignof(ov_result_owner))) return LB_OWNED_INVALID;
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  status = ov_charge(&transaction.budget, 1, sizeof(*out));
  if (status) return ov_abort(&transaction, status);
  lean_object *arguments = lean_alloc_array(0, 2);
  {
    lean_object *child = NULL;
    status = lbov_ac77c4cfe87b7cbcbb00_v167081552b6f9c1d1afd_in(a0, 0, 1, &transaction, &child);
    if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
    arguments = lean_array_push(arguments, child);
  }
  {
    lean_object *child = NULL;
    status = lbov_ac77c4cfe87b7cbcbb00_vdc0347e1f7f5c4d928f1_in(a1, 0, 1, &transaction, &child);
    if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
    arguments = lean_array_push(arguments, child);
  }
  lean_object *v0 = lean_array_get_core(arguments, 0); lean_inc(v0);
  lean_object *v1 = lean_array_get_core(arguments, 1); lean_inc(v1);
  lean_dec(arguments);
  ov_callback_frame frame = { .parent = ov_active_callback_frame, .transaction = &transaction };
  if (!frame.parent) { (void)lb_native_callback_take_error(); (void)lean_bridge_owned_callback_failure_ac77c4cfe87b7cbcbb00(); }
  ov_active_callback_frame = &frame;
  lean_object *returned = lean_bridge_owned_85878987b062b3d15bbb3e20_fa1e5189bd92568e4b939(v0, v1);
  ov_active_callback_frame = frame.parent; status = frame.status;
  int callback_error = lb_native_callback_take_error();
  int refinement_error = lean_bridge_owned_callback_failure_ac77c4cfe87b7cbcbb00();
  if (refinement_error && !status) status = LB_OWNED_INVALID;
  else if (callback_error && !status) status = OV_CALLBACK;
  if (!status) status = lb_owned_scope_ready(&transaction.scope);
  if (status) { lean_dec(returned); return ov_abort(&transaction, status); }
  lbov_ac77c4cfe87b7cbcbb00_td79b9bbde250ee1779da converted = {0};
  status = lbov_ac77c4cfe87b7cbcbb00_vd79b9bbde250ee1779da_out(&converted, returned, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  status = ov_commit(&transaction, owner);
  if (!status) *out = converted;
  return status;
}
static inline int lbov_ac77c4cfe87b7cbcbb00_fec926afda994fba3abe2(lb_owned_context *context, const lbov_ac77c4cfe87b7cbcbb00_td79b9bbde250ee1779da *a0, lbov_ac77c4cfe87b7cbcbb00_t167081552b6f9c1d1afd *out, ov_result_owner *owner) {
  if (!ov_pointer(out, sizeof(*out), _Alignof(lbov_ac77c4cfe87b7cbcbb00_t167081552b6f9c1d1afd)) || !ov_pointer(owner, sizeof(*owner), _Alignof(ov_result_owner))) return LB_OWNED_INVALID;
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  status = ov_charge(&transaction.budget, 1, sizeof(*out));
  if (status) return ov_abort(&transaction, status);
  lean_object *arguments = lean_alloc_array(0, 1);
  {
    lean_object *child = NULL;
    status = lbov_ac77c4cfe87b7cbcbb00_vd79b9bbde250ee1779da_in(a0, 0, 1, &transaction, &child);
    if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
    arguments = lean_array_push(arguments, child);
  }
  lean_object *v0 = lean_array_get_core(arguments, 0); lean_inc(v0);
  lean_dec(arguments);
  ov_callback_frame frame = { .parent = ov_active_callback_frame, .transaction = &transaction };
  if (!frame.parent) { (void)lb_native_callback_take_error(); (void)lean_bridge_owned_callback_failure_ac77c4cfe87b7cbcbb00(); }
  ov_active_callback_frame = &frame;
  lean_object *returned = lean_bridge_owned_85878987b062b3d15bbb3e20_fec926afda994fba3abe2(v0);
  ov_active_callback_frame = frame.parent; status = frame.status;
  int callback_error = lb_native_callback_take_error();
  int refinement_error = lean_bridge_owned_callback_failure_ac77c4cfe87b7cbcbb00();
  if (refinement_error && !status) status = LB_OWNED_INVALID;
  else if (callback_error && !status) status = OV_CALLBACK;
  if (!status) status = lb_owned_scope_ready(&transaction.scope);
  if (status) { lean_dec(returned); return ov_abort(&transaction, status); }
  lbov_ac77c4cfe87b7cbcbb00_t167081552b6f9c1d1afd converted = {0};
  status = lbov_ac77c4cfe87b7cbcbb00_v167081552b6f9c1d1afd_out(&converted, returned, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  status = ov_commit(&transaction, owner);
  if (!status) *out = converted;
  return status;
}

#define OW_GRAPH_ALLOC(bytes) LB_OWNED_ALLOC(bytes)
#define OW_GRAPH_FREE(pointer) LB_OWNED_FREE(pointer)
#include <wasmtime.h>
#include <wasmtime/component.h>
#ifndef OW_GRAPH_ALLOC
#define OW_GRAPH_ALLOC(bytes) calloc(1, bytes)
#endif
#ifndef OW_GRAPH_FREE
#define OW_GRAPH_FREE(pointer) free(pointer)
#endif

_Static_assert(sizeof(bool) == 1, "WIT bool validation requires a one-byte representation");
typedef struct lb_allocation { struct lb_allocation *next; } lb_allocation;
typedef struct { size_t remaining; lb_allocation *allocations; unsigned failure; } lb_scope;
/* Native callers still own valid backing storage; this checks shape, alignment
 * and address arithmetic, not the allocation extent of an arbitrary pointer. */
static inline bool lb_buffer(const void *data, size_t count, size_t width, size_t alignment) {
  if (!count) return true;
  if (!data || !width || !alignment || (uintptr_t)data % alignment || count > SIZE_MAX / width) return false;
  return count * width <= UINTPTR_MAX - (uintptr_t)data;
}
static inline bool lb_boolean(const void *data, bool *out) {
  uint8_t raw; memcpy(&raw, data, sizeof(raw));
  if (raw > 1) return false;
  *out = raw != 0; return true;
}
static inline bool lb_charge(lb_scope *scope, size_t count, size_t width) {
  if (count && width > scope->remaining / count) { scope->failure = 2; return false; }
  scope->remaining -= count * width; return true;
}
static inline void *lb_alloc(lb_scope *scope, size_t count, size_t width) {
  if (!count) return NULL;
  if (width > (SIZE_MAX - sizeof(lb_allocation)) / count) { scope->failure = 2; return NULL; }
  lb_allocation *allocation = OW_GRAPH_ALLOC(sizeof(*allocation) + count * width);
  if (!allocation) { scope->failure = 3; return NULL; }
  memset(allocation, 0, sizeof(*allocation) + count * width);
  allocation->next = scope->allocations; scope->allocations = allocation;
  return allocation + 1;
}
static inline void lb_scope_close(lb_scope *scope) {
  while (scope->allocations) { lb_allocation *next = scope->allocations->next; OW_GRAPH_FREE(scope->allocations); scope->allocations = next; }
}
static inline bool lb_name(const wasm_name_t *name, const char *expected) {
  size_t length = strlen(expected);
  return name->size == length && lb_buffer(name->data, length, 1, 1) && (!length || memcmp(name->data, expected, length) == 0);
}
static inline bool lb_utf8(const char *text, size_t length) {
  const uint8_t *p = (const uint8_t *)text;
  if (!lb_buffer(p, length, 1, 1)) return false;
  for (size_t i = 0; i < length;) {
    uint32_t c = p[i++]; size_t extra = 0; uint32_t minimum = 0;
    if (c < 0x80) continue;
    if (c >= 0xc2 && c <= 0xdf) { extra = 1; minimum = 0x80; c &= 0x1f; }
    else if (c >= 0xe0 && c <= 0xef) { extra = 2; minimum = 0x800; c &= 0x0f; }
    else if (c >= 0xf0 && c <= 0xf4) { extra = 3; minimum = 0x10000; c &= 7; }
    else return false;
    if (extra > length - i) return false;
    while (extra--) { uint8_t b = p[i++]; if ((b & 0xc0) != 0x80) return false; c = (c << 6) | (b & 0x3f); }
    if (c < minimum || c > 0x10ffff || (c >= 0xd800 && c <= 0xdfff)) return false;
  }
  return true;
}
static inline bool lb_limbs_in(const wasmtime_component_val_t *value, lb_scope *scope, uint32_t **out, size_t *length) {
  if (value->kind != WASMTIME_COMPONENT_LIST) return false;
  size_t count = value->of.list.size;
  if (!lb_buffer(value->of.list.data, count, sizeof(wasmtime_component_val_t), _Alignof(wasmtime_component_val_t)) || !lb_charge(scope, count, sizeof(wasmtime_component_val_t) + sizeof(uint32_t))) return false;
  for (size_t i = 0; i < count; ++i) if (value->of.list.data[i].kind != WASMTIME_COMPONENT_U32) return false;
  if (count && value->of.list.data[count - 1].of.u32 == 0) return false;
  if (out) {
    *out = lb_alloc(scope, count, sizeof(uint32_t)); if (count && !*out) return false;
    for (size_t i = 0; i < count; ++i) (*out)[i] = value->of.list.data[i].of.u32;
    *length = count;
  }
  return true;
}
static inline bool lb_limbs_out(const uint32_t *data, size_t length, lb_scope *scope, wasmtime_component_val_t *out) {
  if (!lb_buffer(data, length, sizeof(uint32_t), _Alignof(uint32_t)) || !lb_charge(scope, length, sizeof(wasmtime_component_val_t))) return false;
  if (length && (!data || !data[length - 1])) return false;
  out->kind = WASMTIME_COMPONENT_LIST;
  wasmtime_component_vallist_new_uninit(&out->of.list, length);
  for (size_t i = 0; i < length; ++i) out->of.list.data[i] = (wasmtime_component_val_t){.kind = WASMTIME_COMPONENT_U32, .of.u32 = data[i]};
  return true;
}

#define OW_TYPES 5
#define OW_DEPTH 128
#define OW_NODES 262144
#define OW_BYTES 16777216
typedef struct {
  void *data;
  bool (*read)(void *, size_t, bool, const wasmtime_component_val_t *, uint64_t *);
  bool (*write)(void *, size_t, bool, uint64_t, wasmtime_component_val_t *);
  void (*discard)(void *, wasmtime_component_resource_any_t *);
} ow_identities;
typedef struct { lb_scope memory; size_t visits; ow_identities identities; } ow_scope;
typedef struct { size_t type; const char *name; } ow_table_schema;
typedef struct { size_t count; const ow_table_schema *tables; } ow_schema;
typedef struct { size_t type; uint32_t index; const void *address; } ow_path;
typedef struct {
  ow_scope *scope; bool borrowed;
  const wasmtime_component_vallist_t *tables[OW_TYPES];
  size_t offsets[OW_TYPES], total, visited, active;
  uint8_t *seen;
  ow_path path[OW_DEPTH + 1];
} ow_input;
typedef struct ow_row { struct ow_row *next; wasmtime_component_val_t value; } ow_row;
typedef struct { ow_row *head, *tail; uint32_t count; } ow_table;
typedef struct {
  ow_scope *scope; bool borrowed; const ow_schema *schema;
  ow_table tables[OW_TYPES]; size_t active;
  ow_path path[OW_DEPTH + 1];
} ow_output;
static inline bool ow_visit(ow_scope *scope, unsigned depth, size_t bytes) {
  if (depth > OW_DEPTH || !scope->visits) { scope->memory.failure = 2; return false; }
  --scope->visits; return lb_charge(&scope->memory, 1, bytes);
}
static inline bool ow_count(ow_scope *scope, size_t count) {
  if (count > scope->visits) { scope->memory.failure = 2; return false; }
  return true;
}
/* Traverse only values constructed by these encoders, never unchecked inputs. */
static inline void ow_discard_resources(ow_scope *scope, wasmtime_component_val_t *value) {
  switch (value->kind) {
  case WASMTIME_COMPONENT_RESOURCE:
    if (value->of.resource && scope->identities.discard) scope->identities.discard(scope->identities.data, value->of.resource);
    break;
  case WASMTIME_COMPONENT_RECORD:
    for (size_t i = 0; i < value->of.record.size; ++i) ow_discard_resources(scope, &value->of.record.data[i].val);
    break;
  case WASMTIME_COMPONENT_LIST:
    for (size_t i = 0; i < value->of.list.size; ++i) ow_discard_resources(scope, &value->of.list.data[i]);
    break;
  case WASMTIME_COMPONENT_TUPLE:
    for (size_t i = 0; i < value->of.tuple.size; ++i) ow_discard_resources(scope, &value->of.tuple.data[i]);
    break;
  case WASMTIME_COMPONENT_VARIANT:
    if (value->of.variant.val) ow_discard_resources(scope, value->of.variant.val);
    break;
  case WASMTIME_COMPONENT_OPTION:
    if (value->of.option) ow_discard_resources(scope, value->of.option);
    break;
  case WASMTIME_COMPONENT_RESULT:
    if (value->of.result.val) ow_discard_resources(scope, value->of.result.val);
    break;
  default: break;
  }
}
static inline void ow_value_delete(ow_scope *scope, wasmtime_component_val_t *value) {
  ow_discard_resources(scope, value); wasmtime_component_val_delete(value);
  *value = (wasmtime_component_val_t){0};
}
static inline bool ow_record_in(const wasmtime_component_val_t *value, size_t count, ow_scope *scope) {
  return lb_buffer(value, 1, sizeof(*value), _Alignof(wasmtime_component_val_t))
    && value->kind == WASMTIME_COMPONENT_RECORD && value->of.record.size == count
    && lb_buffer(value->of.record.data, count, sizeof(*value->of.record.data), _Alignof(wasmtime_component_valrecord_entry_t))
    && lb_charge(&scope->memory, count, sizeof(*value->of.record.data));
}
static inline bool ow_record_out(wasmtime_component_val_t *value, size_t count, ow_scope *scope) {
  if (!lb_charge(&scope->memory, count, sizeof(wasmtime_component_valrecord_entry_t))) return false;
  value->kind = WASMTIME_COMPONENT_RECORD; wasmtime_component_valrecord_new_uninit(&value->of.record, count);
  if (count) memset(value->of.record.data, 0, count * sizeof(*value->of.record.data));
  return true;
}
static inline bool ow_field_out(wasmtime_component_valrecord_entry_t *field, const char *name, ow_scope *scope) {
  size_t length = strlen(name);
  if (!lb_charge(&scope->memory, length, 1)) return false;
  wasm_name_new(&field->name, length, name); return true;
}
static inline ow_input *ow_open(const wasmtime_component_val_t *value, ow_scope *scope, const ow_schema *schema, bool borrowed) {
  if (!ow_record_in(value, 2, scope) || !lb_name(&value->of.record.data[0].name, "root") || !lb_name(&value->of.record.data[1].name, "nodes")) return NULL;
  const wasmtime_component_val_t *arena = &value->of.record.data[1].val;
  if (!ow_record_in(arena, schema->count, scope) || !lb_charge(&scope->memory, 1, sizeof(ow_input))) return NULL;
  ow_input *context = lb_alloc(&scope->memory, 1, sizeof(*context));
  if (!context) return NULL;
  context->scope = scope; context->borrowed = borrowed;
  for (size_t i = 0; i < schema->count; ++i) {
    const wasmtime_component_valrecord_entry_t *field = &arena->of.record.data[i];
    size_t type = schema->tables[i].type;
    if (!lb_name(&field->name, schema->tables[i].name) || field->val.kind != WASMTIME_COMPONENT_LIST) return NULL;
    const wasmtime_component_vallist_t *table = &field->val.of.list;
    if (table->size > OW_NODES - context->total) { scope->memory.failure = 2; return NULL; }
    if (!lb_buffer(table->data, table->size, sizeof(*table->data), _Alignof(wasmtime_component_val_t)) || !lb_charge(&scope->memory, table->size, sizeof(*table->data) + 1)) return NULL;
    context->tables[type] = table; context->offsets[type] = context->total; context->total += table->size;
  }
  context->seen = lb_alloc(&scope->memory, context->total, 1);
  if (context->total && !context->seen) return NULL;
  return context;
}
static inline const wasmtime_component_val_t *ow_dereference(ow_input *context, size_t type, const wasmtime_component_val_t *value) {
  if (context->active > OW_DEPTH) { context->scope->memory.failure = 2; return NULL; }
  if (!ow_record_in(value, 1, context->scope) || !lb_name(&value->of.record.data[0].name, "index") || value->of.record.data[0].val.kind != WASMTIME_COMPONENT_U32) return NULL;
  uint32_t index = value->of.record.data[0].val.of.u32;
  if (!context->tables[type] || index >= context->tables[type]->size) return NULL;
  for (size_t i = 0; i < context->active; ++i) if (context->path[i].type == type && context->path[i].index == index) return NULL;
  context->path[context->active++] = (ow_path){.type = type, .index = index};
  size_t position = context->offsets[type] + index;
  if (!context->seen[position]) { context->seen[position] = 1; ++context->visited; }
  return &context->tables[type]->data[index];
}
static inline wasmtime_component_val_t *ow_append(ow_output *context, size_t type, const void *address, wasmtime_component_val_t *reference) {
  if (context->active > OW_DEPTH) { context->scope->memory.failure = 2; return NULL; }
  for (size_t i = 0; i < context->active; ++i) if (context->path[i].type == type && context->path[i].address == address) return NULL;
  ow_table *table = &context->tables[type];
  if (table->count >= OW_NODES) { context->scope->memory.failure = 2; return NULL; }
  if (!lb_charge(&context->scope->memory, 1, sizeof(ow_row))) return NULL;
  ow_row *row = lb_alloc(&context->scope->memory, 1, sizeof(*row));
  if (!row) return NULL;
  if (table->tail) table->tail->next = row; else table->head = row;
  table->tail = row;
  if (!ow_record_out(reference, 1, context->scope) || !ow_field_out(&reference->of.record.data[0], "index", context->scope)) return NULL;
  reference->of.record.data[0].val = (wasmtime_component_val_t){.kind = WASMTIME_COMPONENT_U32, .of.u32 = table->count++};
  context->path[context->active++] = (ow_path){.type = type, .address = address}; return &row->value;
}
static inline void ow_output_close(ow_output *context) {
  for (size_t i = 0; i < OW_TYPES; ++i)
    for (ow_row *row = context->tables[i].head; row; row = row->next) ow_value_delete(context->scope, &row->value);
}
static inline bool ow_finish(ow_output *context, wasmtime_component_val_t *arena) {
  if (!ow_record_out(arena, context->schema->count, context->scope)) return false;
  for (size_t i = 0; i < context->schema->count; ++i) {
    const ow_table_schema *schema = &context->schema->tables[i];
    wasmtime_component_valrecord_entry_t *field = &arena->of.record.data[i];
    ow_table *table = &context->tables[schema->type];
    if (!ow_field_out(field, schema->name, context->scope) || !lb_charge(&context->scope->memory, table->count, sizeof(wasmtime_component_val_t))) return false;
    field->val.kind = WASMTIME_COMPONENT_LIST;
    wasmtime_component_vallist_new_uninit(&field->val.of.list, table->count);
    size_t offset = 0;
    for (ow_row *row = table->head; row; row = row->next) { field->val.of.list.data[offset++] = row->value; row->value = (wasmtime_component_val_t){0}; }
  }
  return true;
}
static inline bool lb_in_3(const wasmtime_component_val_t *value, lb_scope *scope, lbov_ac77c4cfe87b7cbcbb00_t167081552b6f9c1d1afd *out) {
  (void)out;
  if (!lb_buffer(value, 1, sizeof(*value), _Alignof(wasmtime_component_val_t)) || (out && !lb_buffer(out, 1, sizeof(*out), _Alignof(lbov_ac77c4cfe87b7cbcbb00_t167081552b6f9c1d1afd))) || !lb_charge(scope, 1, sizeof(wasmtime_component_val_t))) return false;
  uint32_t *limbs = NULL; size_t length = 0;
  if (!lb_limbs_in(value, scope, out ? &limbs : NULL, &length)) return false;
  if (out) *out = (lbov_ac77c4cfe87b7cbcbb00_t167081552b6f9c1d1afd){.data = limbs, .length = length};
  return true;
}
static inline bool lb_out_3(const lbov_ac77c4cfe87b7cbcbb00_t167081552b6f9c1d1afd *value, lb_scope *scope, wasmtime_component_val_t *out) {
  (void)value;
  if (!lb_buffer(value, 1, sizeof(*value), _Alignof(lbov_ac77c4cfe87b7cbcbb00_t167081552b6f9c1d1afd)) || !lb_buffer(out, 1, sizeof(*out), _Alignof(wasmtime_component_val_t)) || !lb_charge(scope, 1, sizeof(wasmtime_component_val_t))) return false;
  return lb_limbs_out(value->data, value->length, scope, out);
  return true;
}

static inline bool lb_in_4(const wasmtime_component_val_t *value, lb_scope *scope, lbov_ac77c4cfe87b7cbcbb00_tdc0347e1f7f5c4d928f1 *out) {
  (void)out;
  if (!lb_buffer(value, 1, sizeof(*value), _Alignof(wasmtime_component_val_t)) || (out && !lb_buffer(out, 1, sizeof(*out), _Alignof(lbov_ac77c4cfe87b7cbcbb00_tdc0347e1f7f5c4d928f1))) || !lb_charge(scope, 1, sizeof(wasmtime_component_val_t))) return false;
  if (value->kind != WASMTIME_COMPONENT_STRING || !lb_charge(scope, value->of.string.size, 1) || !lb_utf8(value->of.string.data, value->of.string.size)) return false;
  if (out) *out = (lbov_ac77c4cfe87b7cbcbb00_tdc0347e1f7f5c4d928f1){.data = value->of.string.data, .length = value->of.string.size};
  return true;
}
static inline bool lb_out_4(const lbov_ac77c4cfe87b7cbcbb00_tdc0347e1f7f5c4d928f1 *value, lb_scope *scope, wasmtime_component_val_t *out) {
  (void)value;
  if (!lb_buffer(value, 1, sizeof(*value), _Alignof(lbov_ac77c4cfe87b7cbcbb00_tdc0347e1f7f5c4d928f1)) || !lb_buffer(out, 1, sizeof(*out), _Alignof(wasmtime_component_val_t)) || !lb_charge(scope, 1, sizeof(wasmtime_component_val_t))) return false;
  if (!lb_charge(scope, value->length, 1) || !lb_utf8(value->data, value->length)) return false;
  out->kind = WASMTIME_COMPONENT_STRING; wasm_name_new(&out->of.string, value->length, value->data);
  return true;
}static inline bool ow_read_0(const wasmtime_component_val_t *, ow_input *, unsigned, lbov_ac77c4cfe87b7cbcbb00_t160ce821a84f6887bbfd *);
static inline bool ow_write_0(const lbov_ac77c4cfe87b7cbcbb00_t160ce821a84f6887bbfd *, ow_output *, unsigned, wasmtime_component_val_t *);
static inline bool ow_read_1(const wasmtime_component_val_t *, ow_input *, unsigned, lbov_ac77c4cfe87b7cbcbb00_tb2825946e038e653bd2b *);
static inline bool ow_write_1(const lbov_ac77c4cfe87b7cbcbb00_tb2825946e038e653bd2b *, ow_output *, unsigned, wasmtime_component_val_t *);
static inline bool ow_read_2(const wasmtime_component_val_t *, ow_input *, unsigned, lbov_ac77c4cfe87b7cbcbb00_td79b9bbde250ee1779da *);
static inline bool ow_write_2(const lbov_ac77c4cfe87b7cbcbb00_td79b9bbde250ee1779da *, ow_output *, unsigned, wasmtime_component_val_t *);
static inline bool ow_read_3(const wasmtime_component_val_t *, ow_input *, unsigned, lbov_ac77c4cfe87b7cbcbb00_t167081552b6f9c1d1afd *);
static inline bool ow_write_3(const lbov_ac77c4cfe87b7cbcbb00_t167081552b6f9c1d1afd *, ow_output *, unsigned, wasmtime_component_val_t *);
static inline bool ow_read_4(const wasmtime_component_val_t *, ow_input *, unsigned, lbov_ac77c4cfe87b7cbcbb00_tdc0347e1f7f5c4d928f1 *);
static inline bool ow_write_4(const lbov_ac77c4cfe87b7cbcbb00_tdc0347e1f7f5c4d928f1 *, ow_output *, unsigned, wasmtime_component_val_t *);
static inline bool ow_read_0(const wasmtime_component_val_t *value, ow_input *context, unsigned depth, lbov_ac77c4cfe87b7cbcbb00_t160ce821a84f6887bbfd *out) {
  (void)out;
  if (!ow_visit(context->scope, depth, sizeof(lbov_ac77c4cfe87b7cbcbb00_t160ce821a84f6887bbfd) + sizeof(wasmtime_component_val_t)) || !lb_buffer(value, 1, sizeof(*value), _Alignof(wasmtime_component_val_t))) return false;
  value = ow_dereference(context, 0, value);
  if (!value) return false;
  if (value->kind != WASMTIME_COMPONENT_OPTION) return false;
  bool selected = value->of.option != NULL;
  if (out) out->tag = selected;
  if (selected) {
  if (!lb_charge(&context->scope->memory, 1, sizeof(lbov_ac77c4cfe87b7cbcbb00_tb2825946e038e653bd2b))) return false;
  lbov_ac77c4cfe87b7cbcbb00_tb2825946e038e653bd2b *child0 = out ? lb_alloc(&context->scope->memory, 1, sizeof(lbov_ac77c4cfe87b7cbcbb00_tb2825946e038e653bd2b)) : NULL;
  if (out && !child0) return false;
  if (out) out->f0 = child0;
  if (!ow_read_1(value->of.option, context, depth + 1, child0)) return false;
  }
  --context->active;
  return true;
}
static inline bool ow_write_0(const lbov_ac77c4cfe87b7cbcbb00_t160ce821a84f6887bbfd *value, ow_output *context, unsigned depth, wasmtime_component_val_t *out) {
  if (!ow_visit(context->scope, depth, sizeof(wasmtime_component_val_t)) || !lb_buffer(value, 1, sizeof(*value), _Alignof(lbov_ac77c4cfe87b7cbcbb00_t160ce821a84f6887bbfd))) return false;
  out = ow_append(context, 0, value, out);
  if (!out) return false;
  if (value->tag > 1) return false;
  out->kind = WASMTIME_COMPONENT_OPTION;
  out->of.option = NULL;
  if (value->tag) {
  if (!lb_charge(&context->scope->memory, 1, sizeof(wasmtime_component_val_t))) return false;
  wasmtime_component_val_t empty = {0}; out->of.option = wasmtime_component_val_new(&empty);
  if (!ow_write_1(value->f0, context, depth + 1, out->of.option)) return false;
  }
  --context->active;
  return true;
}

static inline bool ow_read_1(const wasmtime_component_val_t *value, ow_input *context, unsigned depth, lbov_ac77c4cfe87b7cbcbb00_tb2825946e038e653bd2b *out) {
  (void)out;
  if (!ow_visit(context->scope, depth, sizeof(lbov_ac77c4cfe87b7cbcbb00_tb2825946e038e653bd2b) + sizeof(wasmtime_component_val_t)) || !lb_buffer(value, 1, sizeof(*value), _Alignof(wasmtime_component_val_t))) return false;
  value = ow_dereference(context, 1, value);
  if (!value) return false;
  if (!ow_record_in(value, 2, context->scope)) return false;
  if (!lb_name(&value->of.record.data[0].name, "holder")) return false;
  if (!ow_read_2(&value->of.record.data[0].val, context, depth + 1, out ? &out->f0 : NULL)) return false;
  if (!lb_name(&value->of.record.data[1].name, "quota")) return false;
  if (!ow_read_3(&value->of.record.data[1].val, context, depth + 1, out ? &out->f1 : NULL)) return false;
  --context->active;
  return true;
}
static inline bool ow_write_1(const lbov_ac77c4cfe87b7cbcbb00_tb2825946e038e653bd2b *value, ow_output *context, unsigned depth, wasmtime_component_val_t *out) {
  if (!ow_visit(context->scope, depth, sizeof(wasmtime_component_val_t)) || !lb_buffer(value, 1, sizeof(*value), _Alignof(lbov_ac77c4cfe87b7cbcbb00_tb2825946e038e653bd2b))) return false;
  out = ow_append(context, 1, value, out);
  if (!out) return false;
  if (!ow_record_out(out, 2, context->scope)) return false;
  if (!ow_field_out(&out->of.record.data[0], "holder", context->scope)) return false;
  if (!ow_write_2(&value->f0, context, depth + 1, &out->of.record.data[0].val)) return false;
  if (!ow_field_out(&out->of.record.data[1], "quota", context->scope)) return false;
  if (!ow_write_3(&value->f1, context, depth + 1, &out->of.record.data[1].val)) return false;
  --context->active;
  return true;
}

static inline bool ow_read_2(const wasmtime_component_val_t *value, ow_input *context, unsigned depth, lbov_ac77c4cfe87b7cbcbb00_td79b9bbde250ee1779da *out) {
  (void)out;
  if (!ow_visit(context->scope, depth, sizeof(lbov_ac77c4cfe87b7cbcbb00_td79b9bbde250ee1779da) + sizeof(wasmtime_component_val_t)) || !lb_buffer(value, 1, sizeof(*value), _Alignof(wasmtime_component_val_t))) return false;
  if (value->kind != WASMTIME_COMPONENT_RESOURCE || !value->of.resource || !context->scope->identities.read) return false;
  if (!context->scope->identities.read(context->scope->identities.data, 2, context->borrowed, value, out ? &out->token : NULL)) return false;
  return !out || out->token != 0;
}
static inline bool ow_write_2(const lbov_ac77c4cfe87b7cbcbb00_td79b9bbde250ee1779da *value, ow_output *context, unsigned depth, wasmtime_component_val_t *out) {
  if (!ow_visit(context->scope, depth, sizeof(wasmtime_component_val_t)) || !lb_buffer(value, 1, sizeof(*value), _Alignof(lbov_ac77c4cfe87b7cbcbb00_td79b9bbde250ee1779da))) return false;
  if (!value->token || !context->scope->identities.write || !context->scope->identities.discard) return false;
  if (!context->scope->identities.write(context->scope->identities.data, 2, context->borrowed, value->token, out)) return false;
  return out->kind == WASMTIME_COMPONENT_RESOURCE && out->of.resource;
}

static inline bool ow_read_3(const wasmtime_component_val_t *value, ow_input *context, unsigned depth, lbov_ac77c4cfe87b7cbcbb00_t167081552b6f9c1d1afd *out) {
  (void)out;
  if (!ow_visit(context->scope, depth, sizeof(lbov_ac77c4cfe87b7cbcbb00_t167081552b6f9c1d1afd) + sizeof(wasmtime_component_val_t)) || !lb_buffer(value, 1, sizeof(*value), _Alignof(wasmtime_component_val_t))) return false;
  if (!lb_in_3(value, &context->scope->memory, out)) return false;
  return true;
}
static inline bool ow_write_3(const lbov_ac77c4cfe87b7cbcbb00_t167081552b6f9c1d1afd *value, ow_output *context, unsigned depth, wasmtime_component_val_t *out) {
  if (!ow_visit(context->scope, depth, sizeof(wasmtime_component_val_t)) || !lb_buffer(value, 1, sizeof(*value), _Alignof(lbov_ac77c4cfe87b7cbcbb00_t167081552b6f9c1d1afd))) return false;
  return lb_out_3(value, &context->scope->memory, out);
}

static inline bool ow_read_4(const wasmtime_component_val_t *value, ow_input *context, unsigned depth, lbov_ac77c4cfe87b7cbcbb00_tdc0347e1f7f5c4d928f1 *out) {
  (void)out;
  if (!ow_visit(context->scope, depth, sizeof(lbov_ac77c4cfe87b7cbcbb00_tdc0347e1f7f5c4d928f1) + sizeof(wasmtime_component_val_t)) || !lb_buffer(value, 1, sizeof(*value), _Alignof(wasmtime_component_val_t))) return false;
  if (!lb_in_4(value, &context->scope->memory, out)) return false;
  if (out && out->length) {
    char *text = lb_alloc(&context->scope->memory, out->length, 1);
    if (!text) return false;
    memcpy(text, out->data, out->length); out->data = text;
  }
  return true;
}
static inline bool ow_write_4(const lbov_ac77c4cfe87b7cbcbb00_tdc0347e1f7f5c4d928f1 *value, ow_output *context, unsigned depth, wasmtime_component_val_t *out) {
  if (!ow_visit(context->scope, depth, sizeof(wasmtime_component_val_t)) || !lb_buffer(value, 1, sizeof(*value), _Alignof(lbov_ac77c4cfe87b7cbcbb00_tdc0347e1f7f5c4d928f1))) return false;
  return lb_out_4(value, &context->scope->memory, out);
}static const ow_table_schema ow_schema_0_output_tables[] = {{0, "nodes0"}, {1, "nodes1"}};
static const ow_schema ow_schema_0_output = {2, ow_schema_0_output_tables};

static inline bool ow_decode_0_output(const wasmtime_component_val_t *value, ow_scope *scope, lbov_ac77c4cfe87b7cbcbb00_t160ce821a84f6887bbfd *out) {
  if (out && !lb_buffer(out, 1, sizeof(*out), _Alignof(lbov_ac77c4cfe87b7cbcbb00_t160ce821a84f6887bbfd))) return false;
  lbov_ac77c4cfe87b7cbcbb00_t160ce821a84f6887bbfd converted = {0};
  ow_input *context = ow_open(value, scope, &ow_schema_0_output, false);
  if (!context || !ow_read_0(&value->of.record.data[0].val, context, 0, out ? &converted : NULL) || context->visited != context->total) return false;
  if (out) *out = converted;
  return true;
}
static inline bool ow_encode_0_output(const lbov_ac77c4cfe87b7cbcbb00_t160ce821a84f6887bbfd *value, ow_scope *scope, wasmtime_component_val_t *out) {
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(wasmtime_component_val_t))) return false;
  wasmtime_component_val_t converted = {0};
  if (!lb_charge(&scope->memory, 1, sizeof(ow_output))) return false;
  ow_output *context = lb_alloc(&scope->memory, 1, sizeof(*context)); if (!context) return false;
  context->scope = scope; context->borrowed = false; context->schema = &ow_schema_0_output;
  bool valid = ow_record_out(&converted, 2, scope)
    && ow_field_out(&converted.of.record.data[0], "root", scope)
    && ow_field_out(&converted.of.record.data[1], "nodes", scope)
    && ow_write_0(value, context, 0, &converted.of.record.data[0].val)
    && ow_finish(context, &converted.of.record.data[1].val);
  ow_output_close(context);
  if (valid) *out = converted; else ow_value_delete(scope, &converted);
  return valid;
}


static inline bool ow_decode_2_input(const wasmtime_component_val_t *value, ow_scope *scope, lbov_ac77c4cfe87b7cbcbb00_td79b9bbde250ee1779da *out) {
  if (out && !lb_buffer(out, 1, sizeof(*out), _Alignof(lbov_ac77c4cfe87b7cbcbb00_td79b9bbde250ee1779da))) return false;
  lbov_ac77c4cfe87b7cbcbb00_td79b9bbde250ee1779da converted = {0};
  ow_input context = {.scope = scope, .borrowed = true};
  if (!ow_read_2(value, &context, 0, out ? &converted : NULL)) return false;
  if (out) *out = converted;
  return true;
}
static inline bool ow_encode_2_input(const lbov_ac77c4cfe87b7cbcbb00_td79b9bbde250ee1779da *value, ow_scope *scope, wasmtime_component_val_t *out) {
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(wasmtime_component_val_t))) return false;
  wasmtime_component_val_t converted = {0};
  ow_output context = {.scope = scope, .borrowed = true};
  bool valid = ow_write_2(value, &context, 0, &converted);
  if (valid) *out = converted; else ow_value_delete(scope, &converted);
  return valid;
}


static inline bool ow_decode_2_output(const wasmtime_component_val_t *value, ow_scope *scope, lbov_ac77c4cfe87b7cbcbb00_td79b9bbde250ee1779da *out) {
  if (out && !lb_buffer(out, 1, sizeof(*out), _Alignof(lbov_ac77c4cfe87b7cbcbb00_td79b9bbde250ee1779da))) return false;
  lbov_ac77c4cfe87b7cbcbb00_td79b9bbde250ee1779da converted = {0};
  ow_input context = {.scope = scope, .borrowed = false};
  if (!ow_read_2(value, &context, 0, out ? &converted : NULL)) return false;
  if (out) *out = converted;
  return true;
}
static inline bool ow_encode_2_output(const lbov_ac77c4cfe87b7cbcbb00_td79b9bbde250ee1779da *value, ow_scope *scope, wasmtime_component_val_t *out) {
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(wasmtime_component_val_t))) return false;
  wasmtime_component_val_t converted = {0};
  ow_output context = {.scope = scope, .borrowed = false};
  bool valid = ow_write_2(value, &context, 0, &converted);
  if (valid) *out = converted; else ow_value_delete(scope, &converted);
  return valid;
}


static inline bool ow_decode_3_input(const wasmtime_component_val_t *value, ow_scope *scope, lbov_ac77c4cfe87b7cbcbb00_t167081552b6f9c1d1afd *out) {
  if (out && !lb_buffer(out, 1, sizeof(*out), _Alignof(lbov_ac77c4cfe87b7cbcbb00_t167081552b6f9c1d1afd))) return false;
  lbov_ac77c4cfe87b7cbcbb00_t167081552b6f9c1d1afd converted = {0};
  ow_input context = {.scope = scope, .borrowed = true};
  if (!ow_read_3(value, &context, 0, out ? &converted : NULL)) return false;
  if (out) *out = converted;
  return true;
}
static inline bool ow_encode_3_input(const lbov_ac77c4cfe87b7cbcbb00_t167081552b6f9c1d1afd *value, ow_scope *scope, wasmtime_component_val_t *out) {
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(wasmtime_component_val_t))) return false;
  wasmtime_component_val_t converted = {0};
  ow_output context = {.scope = scope, .borrowed = true};
  bool valid = ow_write_3(value, &context, 0, &converted);
  if (valid) *out = converted; else ow_value_delete(scope, &converted);
  return valid;
}


static inline bool ow_decode_3_output(const wasmtime_component_val_t *value, ow_scope *scope, lbov_ac77c4cfe87b7cbcbb00_t167081552b6f9c1d1afd *out) {
  if (out && !lb_buffer(out, 1, sizeof(*out), _Alignof(lbov_ac77c4cfe87b7cbcbb00_t167081552b6f9c1d1afd))) return false;
  lbov_ac77c4cfe87b7cbcbb00_t167081552b6f9c1d1afd converted = {0};
  ow_input context = {.scope = scope, .borrowed = false};
  if (!ow_read_3(value, &context, 0, out ? &converted : NULL)) return false;
  if (out) *out = converted;
  return true;
}
static inline bool ow_encode_3_output(const lbov_ac77c4cfe87b7cbcbb00_t167081552b6f9c1d1afd *value, ow_scope *scope, wasmtime_component_val_t *out) {
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(wasmtime_component_val_t))) return false;
  wasmtime_component_val_t converted = {0};
  ow_output context = {.scope = scope, .borrowed = false};
  bool valid = ow_write_3(value, &context, 0, &converted);
  if (valid) *out = converted; else ow_value_delete(scope, &converted);
  return valid;
}


static inline bool ow_decode_4_input(const wasmtime_component_val_t *value, ow_scope *scope, lbov_ac77c4cfe87b7cbcbb00_tdc0347e1f7f5c4d928f1 *out) {
  if (out && !lb_buffer(out, 1, sizeof(*out), _Alignof(lbov_ac77c4cfe87b7cbcbb00_tdc0347e1f7f5c4d928f1))) return false;
  lbov_ac77c4cfe87b7cbcbb00_tdc0347e1f7f5c4d928f1 converted = {0};
  ow_input context = {.scope = scope, .borrowed = true};
  if (!ow_read_4(value, &context, 0, out ? &converted : NULL)) return false;
  if (out) *out = converted;
  return true;
}
static inline bool ow_encode_4_input(const lbov_ac77c4cfe87b7cbcbb00_tdc0347e1f7f5c4d928f1 *value, ow_scope *scope, wasmtime_component_val_t *out) {
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(wasmtime_component_val_t))) return false;
  wasmtime_component_val_t converted = {0};
  ow_output context = {.scope = scope, .borrowed = true};
  bool valid = ow_write_4(value, &context, 0, &converted);
  if (valid) *out = converted; else ow_value_delete(scope, &converted);
  return valid;
}


static inline bool ow_decode_4_output(const wasmtime_component_val_t *value, ow_scope *scope, lbov_ac77c4cfe87b7cbcbb00_tdc0347e1f7f5c4d928f1 *out) {
  if (out && !lb_buffer(out, 1, sizeof(*out), _Alignof(lbov_ac77c4cfe87b7cbcbb00_tdc0347e1f7f5c4d928f1))) return false;
  lbov_ac77c4cfe87b7cbcbb00_tdc0347e1f7f5c4d928f1 converted = {0};
  ow_input context = {.scope = scope, .borrowed = false};
  if (!ow_read_4(value, &context, 0, out ? &converted : NULL)) return false;
  if (out) *out = converted;
  return true;
}
static inline bool ow_encode_4_output(const lbov_ac77c4cfe87b7cbcbb00_tdc0347e1f7f5c4d928f1 *value, ow_scope *scope, wasmtime_component_val_t *out) {
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(wasmtime_component_val_t))) return false;
  wasmtime_component_val_t converted = {0};
  ow_output context = {.scope = scope, .borrowed = false};
  bool valid = ow_write_4(value, &context, 0, &converted);
  if (valid) *out = converted; else ow_value_delete(scope, &converted);
  return valid;
}


#define OW_RESOURCE_CAPACITY LB_OWNED_RETAINED_LIMIT
typedef struct ow_native_host ow_native_host;
typedef struct ow_native_call ow_native_call;
typedef struct {
  uint32_t rep;
  size_t type;
  uint64_t token;
  lb_owned_batch lease;
  ow_native_call *pending;
  bool transient;
} ow_native_entry;
struct ow_native_call { ow_native_host *host; ow_native_call *parent; };
struct ow_native_host {
  ow_native_host *self;
  lb_owned_context *native;
  wasmtime_context_t *context;
  ow_native_entry *entries;
  uint32_t tags[OW_TYPES], next_rep;
  size_t live, depth;
  int status;
  ow_native_call *call;
  bool closing;
  wasmtime_error_t *failure;
};
typedef struct ow_native_read {
  struct ow_native_read *next;
  const wasmtime_component_resource_any_t *handle;
  uint32_t rep;
  size_t type;
  bool borrowed;
} ow_native_read;
typedef struct { ow_native_host *host; ow_scope scope; ow_native_read *reads; } ow_native_conversion;
static _Atomic uint32_t ow_native_next_tag;
static const char *const ow_native_kinds[OW_TYPES] = {
  [2] = "resource:OwnedCheckedRecords.Ticket",
};
static inline bool ow_native_ready(ow_native_host *host) {
  return host && host->self == host && host->native && !host->closing
    && !lb_owned_ready(host->native) && host->context && host->entries;
}
static inline bool ow_native_affinity(ow_native_host *host) {
  return host && host->self == host && host->native && !lb_owned_affinity(host->native);
}
static inline int ow_native_status(ow_native_host *host, int status) {
  if (status && !host->status) host->status = status;
  return host->status;
}
static inline void ow_native_error(ow_native_host *host, wasmtime_error_t *error) {
  if (!error) return;
  (void)ow_native_status(host, LB_OWNED_RUNTIME);
  if (!host->failure) host->failure = error; else wasmtime_error_delete(error);
}
static inline ow_native_entry *ow_native_find(ow_native_host *host, uint32_t rep) {
  for (size_t i = 0; rep && i < OW_RESOURCE_CAPACITY; ++i)
    if (host->entries[i].rep == rep) return &host->entries[i];
  return NULL;
}
static inline bool ow_native_release(ow_native_host *host, ow_native_entry *entry) {
  if (!entry || !entry->rep || !ow_native_affinity(host)) return false;
  int status = lb_owned_batch_release(host->native, &entry->lease);
  if (entry->lease.context) return false;
  *entry = (ow_native_entry){0}; --host->live;
  if (status) ow_native_error(host, wasmtime_error_new("Native resource lease release failed"));
  return !status;
}
static inline bool ow_native_host_init(ow_native_host *host, lb_owned_context *native, wasmtime_context_t *context) {
  if (!host || host->self || host->entries || !context || lb_owned_ready(native)) return false;
  ow_native_entry *entries = LB_OWNED_ALLOC(OW_RESOURCE_CAPACITY * sizeof(*entries));
  if (!entries) { host->status = LB_OWNED_ALLOC_FAILED; return false; }
  memset(entries, 0, OW_RESOURCE_CAPACITY * sizeof(*entries));
  *host = (ow_native_host){.self = host, .native = native, .context = context, .entries = entries};
  for (size_t i = 0; i < OW_TYPES; ++i) if (ow_native_kinds[i]) {
    uint32_t previous = atomic_load(&ow_native_next_tag);
    do {
      if (previous == UINT32_MAX) { LB_OWNED_FREE(entries); *host = (ow_native_host){.status = LB_OWNED_LIMIT}; return false; }
    } while (!atomic_compare_exchange_weak(&ow_native_next_tag, &previous, previous + 1));
    host->tags[i] = previous + 1;
  }
  return true;
}
static inline bool ow_native_call_begin(ow_native_host *host, ow_native_call *call) {
  if (!ow_native_ready(host) || !call || call->host || call->parent || host->depth == LB_OWNED_SCOPE_LIMIT) return false;
  if (!host->call && host->failure) { wasmtime_error_delete(host->failure); host->failure = NULL; }
  if (!host->call) host->status = LB_OWNED_OK;
  if (host->failure) return false;
  *call = (ow_native_call){.host = host, .parent = host->call}; host->call = call; ++host->depth; return true;
}
static inline bool ow_native_call_end(ow_native_call *call, bool success) {
  if (!call || !ow_native_affinity(call->host) || call->host->call != call) return false;
  ow_native_host *host = call->host;
  /* Conversion status reports an atomic, recoverable failure. The caller can
   * still commit unrelated work; Wasmtime errors and close prevent commit. */
  success = success && !host->failure && !host->closing;
  /* Finish fallible temporary cleanup before publishing any pending owner. */
  if (success) for (size_t i = 0; i < OW_RESOURCE_CAPACITY; ++i) {
    ow_native_entry *entry = &host->entries[i];
    if (entry->rep && entry->pending == call && entry->transient && !ow_native_release(host, entry)) success = false;
  }
  for (size_t i = 0; i < OW_RESOURCE_CAPACITY; ++i) {
    ow_native_entry *entry = &host->entries[i];
    if (!entry->rep || entry->pending != call) continue;
    if (!success) {
      if (!ow_native_release(host, entry)) success = false;
    } else entry->pending = call->parent;
  }
  host->call = call->parent; --host->depth; *call = (ow_native_call){0}; return success;
}
/* Close native leases even when a trapped component store cannot drop borrows.
 * Store replacement/destruction belongs to the owning session, after unwind. */
static inline bool ow_native_host_close(ow_native_host *host) {
  if (!ow_native_affinity(host) || host->call) return false;
  host->closing = true;
  bool valid = true;
  for (size_t i = 0; i < OW_RESOURCE_CAPACITY; ++i)
    if (host->entries[i].rep && !ow_native_release(host, &host->entries[i])) valid = false;
  if (host->live) return false;
  LB_OWNED_FREE(host->entries);
  if (host->failure) wasmtime_error_delete(host->failure);
  *host = (ow_native_host){0}; return valid;
}
static inline bool ow_native_type(ow_native_host *host, size_t type, const wasmtime_component_resource_any_t *resource) {
  if (type >= OW_TYPES || !host->tags[type] || !resource) return false;
  wasmtime_component_resource_type_t *actual = wasmtime_component_resource_any_type(resource);
  wasmtime_component_resource_type_t *expected = wasmtime_component_resource_type_new_host(host->tags[type]);
  bool matches = wasmtime_component_resource_type_equal(actual, expected);
  wasmtime_component_resource_type_delete(actual); wasmtime_component_resource_type_delete(expected); return matches;
}
/* Import arguments have already crossed this host's store. Never call this
 * converter on an arbitrary resource from another Wasmtime store. */
static bool ow_native_read_identity(void *data, size_t type, bool borrowed,
    const wasmtime_component_val_t *value, uint64_t *out) {
  ow_native_conversion *conversion = data; ow_native_host *host = conversion->host;
  if (!ow_native_ready(host) || !host->call || host->failure || !borrowed
      || !ow_native_type(host, type, value->of.resource) || wasmtime_component_resource_any_owned(value->of.resource)) return false;
  ow_native_read *read = conversion->reads;
  while (read && read->handle != value->of.resource) read = read->next;
  if (!read) {
    if (!lb_charge(&conversion->scope.memory, 1, sizeof(*read))) return false;
    read = lb_alloc(&conversion->scope.memory, 1, sizeof(*read));
    if (!read) return false;
    wasmtime_component_resource_host_t *resource = NULL;
    wasmtime_error_t *error = wasmtime_component_resource_any_to_host(host->context, value->of.resource, &resource);
    if (error) { ow_native_error(host, error); return false; }
    *read = (ow_native_read){.next = conversion->reads, .handle = value->of.resource,
      .rep = wasmtime_component_resource_host_rep(resource), .type = type,
      .borrowed = !wasmtime_component_resource_host_owned(resource)};
    uint32_t tag = wasmtime_component_resource_host_type(resource);
    wasmtime_component_resource_host_delete(resource);
    conversion->reads = read;
    if (tag != host->tags[type]) return false;
  }
  ow_native_entry *entry = ow_native_find(host, read->rep);
  if (!entry || read->type != type || !read->borrowed || entry->type != type
      || !lb_owned_find(host->native, ow_native_kinds[type], entry->token)) return false;
  if (out) *out = entry->token;
  return true;
}
static bool ow_native_write_identity(void *data, size_t type, bool borrowed,
    uint64_t token, wasmtime_component_val_t *out) {
  ow_native_conversion *conversion = data; ow_native_host *host = conversion->host;
  if (!ow_native_ready(host) || !host->call || host->failure || type >= OW_TYPES || !host->tags[type] || !token) return false;
  if (host->live == OW_RESOURCE_CAPACITY || host->next_rep == UINT32_MAX) {
    (void)ow_native_status(host, LB_OWNED_LIMIT); return false;
  }
  ow_native_entry *entry = NULL;
  for (size_t i = 0; i < OW_RESOURCE_CAPACITY; ++i) if (!host->entries[i].rep) { entry = &host->entries[i]; break; }
  if (!entry) return false;
  lb_owned_scope scope = {0}; lean_object *object = NULL; uint64_t retained = 0;
  int status = lb_owned_scope_begin(host->native, &scope);
  if (!status) status = lb_owned_scope_borrow(&scope, ow_native_kinds[type], token, &object);
  if (!status) status = lb_owned_scope_acquire(&scope, ow_native_kinds[type], object, &retained);
  if (!status) status = lb_owned_scope_commit(&scope, &entry->lease);
  if (scope.context) (void)lb_owned_scope_abort(&scope);
  if (status) {
    (void)ow_native_status(host, status);
    if (entry->lease.context) (void)lb_owned_batch_release(host->native, &entry->lease);
    return false;
  }
  entry->rep = ++host->next_rep; entry->type = type; entry->token = retained;
  entry->pending = host->call; entry->transient = borrowed; ++host->live;
  wasmtime_component_resource_host_t *resource = wasmtime_component_resource_host_new(!borrowed, entry->rep, host->tags[type]);
  wasmtime_component_resource_any_t *handle = NULL;
  wasmtime_error_t *error = wasmtime_component_resource_host_to_any(host->context, resource, &handle);
  wasmtime_component_resource_host_delete(resource);
  if (error) { ow_native_error(host, error); (void)ow_native_release(host, entry); return false; }
  *out = (wasmtime_component_val_t){.kind = WASMTIME_COMPONENT_RESOURCE, .of.resource = handle}; return true;
}
/* Deleting an unpublished ResourceAny box alone does not release its native
 * lease. Extract its trusted host representation, then close that exact lease. */
static void ow_native_discard_identity(void *data, wasmtime_component_resource_any_t *value) {
  ow_native_conversion *conversion = data; ow_native_host *host = conversion->host;
  if (!ow_native_affinity(host)) return;
  wasmtime_component_resource_host_t *resource = NULL;
  wasmtime_error_t *error = wasmtime_component_resource_any_to_host(host->context, value, &resource);
  if (error) { ow_native_error(host, error); return; }
  uint32_t rep = wasmtime_component_resource_host_rep(resource), tag = wasmtime_component_resource_host_type(resource);
  ow_native_entry *entry = ow_native_find(host, rep);
  wasmtime_component_resource_host_delete(resource);
  if (!entry || host->tags[entry->type] != tag || !ow_native_release(host, entry))
    ow_native_error(host, wasmtime_error_new("Unknown or expired native WIT resource during cleanup"));
}
static inline void ow_native_conversion_init(ow_native_conversion *conversion, ow_native_host *host) {
  *conversion = (ow_native_conversion){.host = host, .scope = {
    .memory = {.remaining = OW_BYTES}, .visits = OW_NODES,
    .identities = {.data = conversion, .read = ow_native_read_identity,
      .write = ow_native_write_identity, .discard = ow_native_discard_identity}}};
}
static inline void ow_native_conversion_close(ow_native_conversion *conversion) {
  lb_scope_close(&conversion->scope.memory); conversion->reads = NULL;
}
static wasmtime_error_t *ow_native_resource_drop(void *data, wasmtime_context_t *context, uint32_t rep) {
  ow_native_host *host = data;
  if (!ow_native_affinity(host) || context != host->context) return wasmtime_error_new("Wrong native WIT resource session");
  ow_native_entry *entry = ow_native_find(host, rep);
  if (!entry || !ow_native_release(host, entry)) return wasmtime_error_new("Closed native WIT resource");
  return NULL;
}


static wasmtime_error_t *ow_native_import_0(void *data, wasmtime_context_t *context,
    const wasmtime_component_func_type_t *type, wasmtime_component_val_t *args, size_t count,
    wasmtime_component_val_t *results, size_t result_count) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  (void)type;
  ow_native_host *host = data;
  if (!ow_native_ready(host) || context != host->context || !host->call || host->failure
      || count != 1 || result_count != 1
      || !lb_buffer(args, count, sizeof(*args), _Alignof(wasmtime_component_val_t))
      || !lb_buffer(results, 1, sizeof(*results), _Alignof(wasmtime_component_val_t))) return wasmtime_error_new("Unavailable owned WIT import or signature mismatch");
  ow_native_conversion input, output;
  ow_native_conversion_init(&input, host); ow_native_conversion_init(&output, host);
  ov_result_owner owner = {0}; lbov_ac77c4cfe87b7cbcbb00_t160ce821a84f6887bbfd value = {0};
  wasmtime_component_val_t converted = {0}; wasmtime_error_t *failure = NULL;
  int status = 0;
  lbov_ac77c4cfe87b7cbcbb00_td79b9bbde250ee1779da arg0 = {0};
  if (!ow_decode_2_input(&args[0], &input.scope, &arg0)) {
    (void)ow_native_status(host, input.scope.memory.failure ? (int)input.scope.memory.failure : LB_OWNED_INVALID);
    failure = wasmtime_error_new("Invalid owned WIT input, expired resource or conversion limit"); goto done;
  }
  status = lbov_ac77c4cfe87b7cbcbb00_f483485736ace9af57086(host->native, &arg0, &value, &owner);
  if (status) {
    (void)ow_native_status(host, status);
    if (status == OV_RESULT) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new("Owned Lean call failed"); goto done;
  }
  if (!ow_encode_0_output(&value, &output.scope, &converted)) {
    (void)ow_native_status(host, output.scope.memory.failure ? (int)output.scope.memory.failure : OV_RESULT);
    failure = wasmtime_error_new("Owned WIT result conversion or resource acquisition failed"); goto done;
  }
  if (!ow_native_ready(host) || host->failure) { failure = wasmtime_error_new("Owned WIT session became unavailable"); goto done; }
  results[0] = converted; converted = (wasmtime_component_val_t){0};
done:
  ow_value_delete(&output.scope, &converted);
  status = ov_owner_clear(&owner);
  if (status) {
    (void)ow_native_status(host, status);
    if (!failure) failure = wasmtime_error_new("Owned Lean result release failed");
  }
  ow_native_conversion_close(&output); ow_native_conversion_close(&input);
  return failure;
}


static wasmtime_error_t *ow_native_import_1(void *data, wasmtime_context_t *context,
    const wasmtime_component_func_type_t *type, wasmtime_component_val_t *args, size_t count,
    wasmtime_component_val_t *results, size_t result_count) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  (void)type;
  ow_native_host *host = data;
  if (!ow_native_ready(host) || context != host->context || !host->call || host->failure
      || count != 2 || result_count != 1
      || !lb_buffer(args, count, sizeof(*args), _Alignof(wasmtime_component_val_t))
      || !lb_buffer(results, 1, sizeof(*results), _Alignof(wasmtime_component_val_t))) return wasmtime_error_new("Unavailable owned WIT import or signature mismatch");
  ow_native_conversion input, output;
  ow_native_conversion_init(&input, host); ow_native_conversion_init(&output, host);
  ov_result_owner owner = {0}; lbov_ac77c4cfe87b7cbcbb00_td79b9bbde250ee1779da value = {0};
  wasmtime_component_val_t converted = {0}; wasmtime_error_t *failure = NULL;
  int status = 0;
  lbov_ac77c4cfe87b7cbcbb00_t167081552b6f9c1d1afd arg0 = {0};
  lbov_ac77c4cfe87b7cbcbb00_tdc0347e1f7f5c4d928f1 arg1 = {0};
  if (!ow_decode_3_input(&args[0], &input.scope, &arg0)) {
    (void)ow_native_status(host, input.scope.memory.failure ? (int)input.scope.memory.failure : LB_OWNED_INVALID);
    failure = wasmtime_error_new("Invalid owned WIT input, expired resource or conversion limit"); goto done;
  }
  if (!ow_decode_4_input(&args[1], &input.scope, &arg1)) {
    (void)ow_native_status(host, input.scope.memory.failure ? (int)input.scope.memory.failure : LB_OWNED_INVALID);
    failure = wasmtime_error_new("Invalid owned WIT input, expired resource or conversion limit"); goto done;
  }
  status = lbov_ac77c4cfe87b7cbcbb00_fa1e5189bd92568e4b939(host->native, &arg0, &arg1, &value, &owner);
  if (status) {
    (void)ow_native_status(host, status);
    if (status == OV_RESULT) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new("Owned Lean call failed"); goto done;
  }
  if (!ow_encode_2_output(&value, &output.scope, &converted)) {
    (void)ow_native_status(host, output.scope.memory.failure ? (int)output.scope.memory.failure : OV_RESULT);
    failure = wasmtime_error_new("Owned WIT result conversion or resource acquisition failed"); goto done;
  }
  if (!ow_native_ready(host) || host->failure) { failure = wasmtime_error_new("Owned WIT session became unavailable"); goto done; }
  results[0] = converted; converted = (wasmtime_component_val_t){0};
done:
  ow_value_delete(&output.scope, &converted);
  status = ov_owner_clear(&owner);
  if (status) {
    (void)ow_native_status(host, status);
    if (!failure) failure = wasmtime_error_new("Owned Lean result release failed");
  }
  ow_native_conversion_close(&output); ow_native_conversion_close(&input);
  return failure;
}


static wasmtime_error_t *ow_native_import_2(void *data, wasmtime_context_t *context,
    const wasmtime_component_func_type_t *type, wasmtime_component_val_t *args, size_t count,
    wasmtime_component_val_t *results, size_t result_count) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  (void)type;
  ow_native_host *host = data;
  if (!ow_native_ready(host) || context != host->context || !host->call || host->failure
      || count != 1 || result_count != 1
      || !lb_buffer(args, count, sizeof(*args), _Alignof(wasmtime_component_val_t))
      || !lb_buffer(results, 1, sizeof(*results), _Alignof(wasmtime_component_val_t))) return wasmtime_error_new("Unavailable owned WIT import or signature mismatch");
  ow_native_conversion input, output;
  ow_native_conversion_init(&input, host); ow_native_conversion_init(&output, host);
  ov_result_owner owner = {0}; lbov_ac77c4cfe87b7cbcbb00_t167081552b6f9c1d1afd value = {0};
  wasmtime_component_val_t converted = {0}; wasmtime_error_t *failure = NULL;
  int status = 0;
  lbov_ac77c4cfe87b7cbcbb00_td79b9bbde250ee1779da arg0 = {0};
  if (!ow_decode_2_input(&args[0], &input.scope, &arg0)) {
    (void)ow_native_status(host, input.scope.memory.failure ? (int)input.scope.memory.failure : LB_OWNED_INVALID);
    failure = wasmtime_error_new("Invalid owned WIT input, expired resource or conversion limit"); goto done;
  }
  status = lbov_ac77c4cfe87b7cbcbb00_fec926afda994fba3abe2(host->native, &arg0, &value, &owner);
  if (status) {
    (void)ow_native_status(host, status);
    if (status == OV_RESULT) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new("Owned Lean call failed"); goto done;
  }
  if (!ow_encode_3_output(&value, &output.scope, &converted)) {
    (void)ow_native_status(host, output.scope.memory.failure ? (int)output.scope.memory.failure : OV_RESULT);
    failure = wasmtime_error_new("Owned WIT result conversion or resource acquisition failed"); goto done;
  }
  if (!ow_native_ready(host) || host->failure) { failure = wasmtime_error_new("Owned WIT session became unavailable"); goto done; }
  results[0] = converted; converted = (wasmtime_component_val_t){0};
done:
  ow_value_delete(&output.scope, &converted);
  status = ov_owner_clear(&owner);
  if (status) {
    (void)ow_native_status(host, status);
    if (!failure) failure = wasmtime_error_new("Owned Lean result release failed");
  }
  ow_native_conversion_close(&output); ow_native_conversion_close(&input);
  return failure;
}

static inline wasmtime_error_t *ow_native_link(ow_native_host *host, wasmtime_component_linker_t *linker) {
  if (!ow_native_ready(host) || !linker) return wasmtime_error_new("Invalid owned WIT host");
  wasmtime_component_linker_instance_t *root = wasmtime_component_linker_root(linker), *native = NULL;
  wasmtime_error_t *error = wasmtime_component_linker_instance_add_instance(root, "lean-bridge:owned-checked-records-result-only/native@1.0.0", 58, &native);
  if (!error) {
    if (!error) {
      wasmtime_component_resource_type_t *type = wasmtime_component_resource_type_new_host(host->tags[2]);
      error = wasmtime_component_linker_instance_add_resource(native, "identity-ticket", 15, type, ow_native_resource_drop, host, NULL);
      wasmtime_component_resource_type_delete(type);
    }
    if (!error) error = wasmtime_component_linker_instance_add_func(native, "claim-for", 9, ow_native_import_0, host, NULL);
    if (!error) error = wasmtime_component_linker_instance_add_func(native, "new-ticket", 10, ow_native_import_1, host, NULL);
    if (!error) error = wasmtime_component_linker_instance_add_func(native, "serial", 6, ow_native_import_2, host, NULL);
    wasmtime_component_linker_instance_delete(native);
  }
  wasmtime_component_linker_instance_delete(root); return error;
}

static const uint8_t ows_component_bytes[] = {0,97,115,109,13,0,1,0,7,151,3,1,66,27,4,0,15,105,100,101,110,116,105,116,121,45,116,105,99,107,101,116,3,1,1,104,0,1,105,0,1,114,1,5,105,110,100,101,120,121,4,0,12,98,114,105,100,103,101,45,114,101,102,45,48,3,0,3,1,114,1,5,105,110,100,101,120,121,4,0,12,98,114,105,100,103,101,45,114,101,102,45,49,3,0,5,1,112,121,4,0,10,98,114,105,100,103,101,45,110,97,116,3,0,7,1,107,6,4,0,19,98,114,105,100,103,101,45,114,111,119,45,48,45,111,117,116,112,117,116,3,0,9,1,114,2,6,104,111,108,100,101,114,2,5,113,117,111,116,97,8,4,0,19,98,114,105,100,103,101,45,114,111,119,45,49,45,111,117,116,112,117,116,3,0,11,1,112,10,4,0,23,98,114,105,100,103,101,45,116,97,98,108,101,45,48,45,48,45,111,117,116,112,117,116,3,0,13,1,112,12,4,0,23,98,114,105,100,103,101,45,116,97,98,108,101,45,48,45,49,45,111,117,116,112,117,116,3,0,15,1,114,2,6,110,111,100,101,115,48,14,6,110,111,100,101,115,49,16,4,0,21,98,114,105,100,103,101,45,97,114,101,110,97,45,48,45,111,117,116,112,117,116,3,0,17,1,114,2,4,114,111,111,116,4,5,110,111,100,101,115,18,4,0,21,98,114,105,100,103,101,45,118,97,108,117,101,45,48,45,111,117,116,112,117,116,3,0,19,1,64,1,4,97,114,103,48,1,0,20,4,0,9,99,108,97,105,109,45,102,111,114,1,21,1,64,2,4,97,114,103,48,8,4,97,114,103,49,115,0,2,4,0,10,110,101,119,45,116,105,99,107,101,116,1,22,1,64,1,4,97,114,103,48,1,0,8,4,0,6,115,101,114,105,97,108,1,23,10,63,1,0,58,108,101,97,110,45,98,114,105,100,103,101,58,111,119,110,101,100,45,99,104,101,99,107,101,100,45,114,101,99,111,114,100,115,45,114,101,115,117,108,116,45,111,110,108,121,47,110,97,116,105,118,101,64,49,46,48,46,48,5,0,6,216,1,10,3,0,0,12,98,114,105,100,103,101,45,114,101,102,45,48,3,0,0,12,98,114,105,100,103,101,45,114,101,102,45,49,3,0,0,10,98,114,105,100,103,101,45,110,97,116,3,0,0,19,98,114,105,100,103,101,45,114,111,119,45,48,45,111,117,116,112,117,116,3,0,0,19,98,114,105,100,103,101,45,114,111,119,45,49,45,111,117,116,112,117,116,3,0,0,23,98,114,105,100,103,101,45,116,97,98,108,101,45,48,45,48,45,111,117,116,112,117,116,3,0,0,23,98,114,105,100,103,101,45,116,97,98,108,101,45,48,45,49,45,111,117,116,112,117,116,3,0,0,21,98,114,105,100,103,101,45,97,114,101,110,97,45,48,45,111,117,116,112,117,116,3,0,0,21,98,114,105,100,103,101,45,118,97,108,117,101,45,48,45,111,117,116,112,117,116,3,0,0,15,105,100,101,110,116,105,116,121,45,116,105,99,107,101,116,7,5,2,104,10,105,10,6,38,3,1,0,0,9,99,108,97,105,109,45,102,111,114,1,0,0,10,110,101,119,45,116,105,99,107,101,116,1,0,0,6,115,101,114,105,97,108,1,197,3,0,97,115,109,1,0,0,0,1,28,6,96,0,0,96,4,127,127,127,127,1,127,96,1,127,0,96,1,126,0,96,1,125,0,96,1,124,0,3,8,7,0,0,1,2,3,4,5,5,5,1,1,1,128,8,6,12,2,127,1,65,144,2,11,127,1,65,0,11,7,72,7,6,109,101,109,111,114,121,2,0,5,101,110,116,101,114,0,0,7,114,101,97,108,108,111,99,0,2,8,112,111,115,116,45,105,51,50,0,3,8,112,111,115,116,45,105,54,52,0,4,8,112,111,115,116,45,102,51,50,0,5,8,112,111,115,116,45,102,54,52,0,6,10,206,1,7,29,0,35,1,65,192,0,79,4,64,0,11,35,1,65,2,116,35,0,54,2,16,35,1,65,1,106,36,1,11,36,0,35,1,69,4,64,0,11,35,1,65,1,107,36,1,35,1,69,4,127,65,144,2,5,35,1,65,2,116,40,2,16,11,36,0,11,117,1,3,127,32,3,69,4,64,65,0,15,11,35,0,32,2,65,1,107,106,65,0,32,2,107,113,33,4,32,4,32,3,106,33,5,32,5,32,4,73,32,5,65,128,128,128,32,75,114,4,64,0,11,32,5,65,255,255,3,106,65,16,118,33,6,32,6,63,0,75,4,64,32,6,63,0,107,64,0,65,127,70,4,64,0,11,11,32,0,4,64,32,4,32,0,32,1,32,3,32,1,32,3,73,27,252,10,0,0,11,32,5,36,0,32,4,11,4,0,16,1,11,4,0,16,1,11,4,0,16,1,11,4,0,16,1,11,0,99,4,110,97,109,101,0,10,9,97,108,108,111,99,97,116,111,114,1,8,1,1,5,108,101,97,118,101,2,54,1,2,7,0,3,111,108,100,1,8,111,108,100,45,115,105,122,101,2,9,97,108,105,103,110,109,101,110,116,3,4,115,105,122,101,4,5,115,116,97,114,116,5,3,101,110,100,6,5,112,97,103,101,115,7,14,2,0,4,104,101,97,112,1,5,100,101,112,116,104,2,4,1,0,0,0,6,76,6,0,2,1,0,6,109,101,109,111,114,121,0,0,1,0,7,114,101,97,108,108,111,99,0,0,1,0,8,112,111,115,116,45,105,51,50,0,0,1,0,8,112,111,115,116,45,105,54,52,0,0,1,0,8,112,111,115,116,45,102,51,50,0,0,1,0,8,112,111,115,116,45,102,54,52,8,27,4,1,0,0,2,3,0,4,0,1,0,1,2,3,0,4,0,1,0,2,2,3,0,4,0,3,10,1,203,2,0,97,115,109,1,0,0,0,1,26,5,96,4,127,127,127,127,1,127,96,0,0,96,1,127,0,96,2,127,127,0,96,1,127,1,127,2,110,7,10,97,108,108,111,99,97,116,105,111,110,7,114,101,97,108,108,111,99,0,0,10,97,108,108,111,99,97,116,105,111,110,6,109,101,109,111,114,121,2,0,1,10,97,108,108,111,99,97,116,105,111,110,5,101,110,116,101,114,0,1,9,114,101,115,111,117,114,99,101,115,5,100,114,111,112,57,0,2,4,104,111,115,116,2,102,48,0,3,4,104,111,115,116,2,102,49,0,0,4,104,111,115,116,2,102,50,0,3,3,4,3,4,0,4,7,16,3,2,102,48,0,6,2,102,49,0,7,2,102,50,0,8,10,78,3,30,1,1,127,16,1,65,0,65,0,65,4,65,20,16,0,33,1,32,0,32,1,16,3,32,0,16,2,32,1,11,14,0,16,1,32,0,32,1,32,2,32,3,16,4,11,30,1,1,127,16,1,65,0,65,0,65,4,65,8,16,0,33,1,32,0,32,1,16,5,32,0,16,2,32,1,11,0,77,4,110,97,109,101,0,8,7,102,111,114,119,97,114,100,1,37,6,0,8,97,108,108,111,99,97,116,101,1,5,101,110,116,101,114,2,5,100,114,111,112,57,3,2,102,48,4,2,102,49,5,2,102,50,2,21,2,6,1,1,6,114,101,115,117,108,116,8,1,1,6,114,101,115,117,108,116,2,63,3,1,3,2,102,48,0,5,2,102,49,0,6,2,102,50,0,7,1,1,5,100,114,111,112,57,0,8,0,1,3,10,97,108,108,111,99,97,116,105,111,110,18,0,4,104,111,115,116,18,1,9,114,101,115,111,117,114,99,101,115,18,2,6,22,3,0,0,1,3,2,102,48,0,0,1,3,2,102,49,0,0,1,3,2,102,50,7,11,1,64,1,4,97,114,103,48,11,0,9,8,12,1,0,0,9,3,3,0,4,0,5,1,13,7,17,1,64,2,4,97,114,103,48,3,4,97,114,103,49,115,0,12,8,12,1,0,0,10,3,3,0,4,0,5,1,14,7,11,1,64,1,4,97,114,103,48,11,0,3,8,12,1,0,0,11,3,3,0,4,0,5,1,15,7,245,2,1,66,28,2,3,2,1,1,4,0,12,98,114,105,100,103,101,45,114,101,102,45,48,3,0,0,2,3,2,1,2,4,0,12,98,114,105,100,103,101,45,114,101,102,45,49,3,0,2,2,3,2,1,3,4,0,10,98,114,105,100,103,101,45,110,97,116,3,0,4,2,3,2,1,4,4,0,19,98,114,105,100,103,101,45,114,111,119,45,48,45,111,117,116,112,117,116,3,0,6,2,3,2,1,5,4,0,19,98,114,105,100,103,101,45,114,111,119,45,49,45,111,117,116,112,117,116,3,0,8,2,3,2,1,6,4,0,23,98,114,105,100,103,101,45,116,97,98,108,101,45,48,45,48,45,111,117,116,112,117,116,3,0,10,2,3,2,1,7,4,0,23,98,114,105,100,103,101,45,116,97,98,108,101,45,48,45,49,45,111,117,116,112,117,116,3,0,12,2,3,2,1,8,4,0,21,98,114,105,100,103,101,45,97,114,101,110,97,45,48,45,111,117,116,112,117,116,3,0,14,2,3,2,1,9,4,0,21,98,114,105,100,103,101,45,118,97,108,117,101,45,48,45,111,117,116,112,117,116,3,0,16,2,3,2,1,10,4,0,15,105,100,101,110,116,105,116,121,45,116,105,99,107,101,116,3,0,18,1,104,19,1,105,19,1,64,1,4,97,114,103,48,20,0,17,4,0,9,99,108,97,105,109,45,102,111,114,1,22,1,64,2,4,97,114,103,48,5,4,97,114,103,49,115,0,21,4,0,10,110,101,119,45,116,105,99,107,101,116,1,23,1,64,1,4,97,114,103,48,20,0,5,4,0,6,115,101,114,105,97,108,1,24,5,255,1,1,1,13,0,12,98,114,105,100,103,101,45,114,101,102,45,48,3,1,0,12,98,114,105,100,103,101,45,114,101,102,45,49,3,2,0,10,98,114,105,100,103,101,45,110,97,116,3,3,0,19,98,114,105,100,103,101,45,114,111,119,45,48,45,111,117,116,112,117,116,3,4,0,19,98,114,105,100,103,101,45,114,111,119,45,49,45,111,117,116,112,117,116,3,5,0,23,98,114,105,100,103,101,45,116,97,98,108,101,45,48,45,48,45,111,117,116,112,117,116,3,6,0,23,98,114,105,100,103,101,45,116,97,98,108,101,45,48,45,49,45,111,117,116,112,117,116,3,7,0,21,98,114,105,100,103,101,45,97,114,101,110,97,45,48,45,111,117,116,112,117,116,3,8,0,21,98,114,105,100,103,101,45,118,97,108,117,101,45,48,45,111,117,116,112,117,116,3,9,0,15,105,100,101,110,116,105,116,121,45,116,105,99,107,101,116,3,10,0,9,99,108,97,105,109,45,102,111,114,1,3,0,10,110,101,119,45,116,105,99,107,101,116,1,4,0,6,115,101,114,105,97,108,1,5,11,63,1,0,55,108,101,97,110,45,98,114,105,100,103,101,58,111,119,110,101,100,45,99,104,101,99,107,101,100,45,114,101,99,111,114,100,115,45,114,101,115,117,108,116,45,111,110,108,121,47,97,112,105,64,49,46,48,46,48,5,1,1,5,16,0,162,3,14,99,111,109,112,111,110,101,110,116,45,110,97,109,101,1,113,0,0,12,0,7,114,101,97,108,108,111,99,1,8,112,111,115,116,45,105,51,50,2,8,112,111,115,116,45,105,54,52,3,8,112,111,115,116,45,102,51,50,4,8,112,111,115,116,45,102,54,52,5,6,108,111,119,101,114,48,6,6,108,111,119,101,114,49,7,6,108,111,119,101,114,50,8,5,100,114,111,112,57,9,8,102,111,114,119,97,114,100,48,10,8,102,111,114,119,97,114,100,49,11,8,102,111,114,119,97,114,100,50,1,11,0,2,1,0,6,109,101,109,111,114,121,1,23,0,17,2,0,9,97,108,108,111,99,97,116,111,114,1,7,102,111,114,119,97,114,100,1,46,0,18,4,0,10,97,108,108,111,99,97,116,105,111,110,1,7,105,109,112,111,114,116,115,2,9,114,101,115,111,117,114,99,101,115,3,9,102,111,114,119,97,114,100,101,100,1,35,1,6,0,5,104,111,115,116,48,1,5,104,111,115,116,49,2,5,104,111,115,116,50,3,2,102,48,4,2,102,49,5,2,102,50,1,144,1,3,14,0,3,97,112,105,1,7,112,117,98,108,105,99,48,2,7,112,117,98,108,105,99,49,3,7,112,117,98,108,105,99,50,4,7,112,117,98,108,105,99,51,5,7,112,117,98,108,105,99,52,6,7,112,117,98,108,105,99,53,7,7,112,117,98,108,105,99,54,8,7,112,117,98,108,105,99,55,9,7,112,117,98,108,105,99,56,10,15,112,117,98,108,105,99,82,101,115,111,117,114,99,101,57,11,13,112,117,98,108,105,99,66,111,114,114,111,119,57,12,10,112,117,98,108,105,99,79,119,110,57,16,10,112,117,98,108,105,99,45,97,112,105,1,16,5,2,0,4,104,111,115,116,1,6,112,117,98,108,105,99};
typedef struct ows_frame ows_frame;
typedef struct {
  lb_owned_context *native;
  wasm_engine_t *engine;
  wasmtime_component_t *component;
  ows_frame *frames;
  size_t depth;
  bool closing;
} ows_session;
struct ows_frame {
  ows_frame *parent;
  ows_session *session;
  wasmtime_store_t *store;
  wasmtime_component_linker_t *linker;
  wasmtime_component_instance_t instance;
  ow_native_host host;
  ow_native_call call;
};
static inline void ows_session_destroy(ows_session *session) {
  if (session->component) wasmtime_component_delete(session->component);
  if (session->engine) wasm_engine_delete(session->engine);
  LB_OWNED_FREE(session);
}
static inline int ows_session_open(lb_owned_context *native, ows_session **out) {
  int status = lb_owned_ready(native);
  if (status) return status;
  ows_session *session = LB_OWNED_ALLOC(sizeof(*session));
  if (!session) return LB_OWNED_ALLOC_FAILED;
  memset(session, 0, sizeof(*session)); session->native = native;
  wasm_config_t *config = wasm_config_new();
  if (!config) { ows_session_destroy(session); return LB_OWNED_ALLOC_FAILED; }
  wasmtime_config_wasm_component_model_set(config, true);
  session->engine = wasm_engine_new_with_config(config);
  if (!session->engine) { ows_session_destroy(session); return LB_OWNED_ALLOC_FAILED; }
  wasmtime_error_t *error = wasmtime_component_new(session->engine, ows_component_bytes, sizeof(ows_component_bytes), &session->component);
  if (error) { wasmtime_error_delete(error); ows_session_destroy(session); return LB_OWNED_RUNTIME; }
  *out = session; return LB_OWNED_OK;
}
static inline void ows_session_request_close(ows_session *session) {
  session->closing = true;
  for (ows_frame *frame = session->frames; frame; frame = frame->parent) {
    frame->host.closing = true; (void)ow_native_status(&frame->host, LB_OWNED_CLOSED);
  }
}
static inline int ows_frame_end(ows_frame *frame, int status) {
  ows_session *session = frame->session;
  if (frame->host.status && !status) status = frame->host.status;
  /* No canonical identity escapes this frame. Independently retained native
   * results are outside this ledger, so all proxy leases can be rolled back. */
  if (frame->call.host) (void)ow_native_call_end(&frame->call, false);
  if (frame->host.self && !ow_native_host_close(&frame->host) && !status) status = LB_OWNED_RUNTIME;
  if (frame->linker) wasmtime_component_linker_delete(frame->linker);
  if (frame->store) wasmtime_store_delete(frame->store);
  if (session) { session->frames = frame->parent; --session->depth; }
  *frame = (ows_frame){0}; return status;
}
static inline int ows_frame_begin(ows_session *session, ows_frame *frame) {
  int status = lb_owned_ready(session->native);
  if (status) return status;
  if (session->closing) return LB_OWNED_CLOSED;
  if (session->depth == LB_OWNED_SCOPE_LIMIT) return LB_OWNED_LIMIT;
  frame->parent = session->frames; frame->session = session;
  session->frames = frame; ++session->depth;
  frame->store = wasmtime_store_new(session->engine, NULL, NULL);
  if (!frame->store) return ows_frame_end(frame, LB_OWNED_ALLOC_FAILED);
  wasmtime_context_t *context = wasmtime_store_context(frame->store);
  if (!ow_native_host_init(&frame->host, session->native, context))
    return ows_frame_end(frame, frame->host.status ? frame->host.status : LB_OWNED_ALLOC_FAILED);
  frame->linker = wasmtime_component_linker_new(session->engine);
  if (!frame->linker) return ows_frame_end(frame, LB_OWNED_ALLOC_FAILED);
  wasmtime_error_t *error = ow_native_link(&frame->host, frame->linker);
  if (!error) error = wasmtime_component_linker_instantiate(frame->linker, context, session->component, &frame->instance);
  if (error) { wasmtime_error_delete(error); return ows_frame_end(frame, LB_OWNED_RUNTIME); }
  if (!ow_native_call_begin(&frame->host, &frame->call)) return ows_frame_end(frame, LB_OWNED_RUNTIME);
  return LB_OWNED_OK;
}
static inline int ows_invoke(ows_frame *frame, const char *name,
    const wasmtime_component_val_t *args, size_t count, wasmtime_component_val_t *out) {
  wasmtime_context_t *context = frame->host.context;
  wasmtime_component_export_index_t *api = wasmtime_component_instance_get_export_index(&frame->instance,
    context, NULL, "lean-bridge:owned-checked-records-result-only/api@1.0.0", 55);
  if (!api) return LB_OWNED_RUNTIME;
  wasmtime_component_export_index_t *index = wasmtime_component_instance_get_export_index(&frame->instance,
    context, api, name, strlen(name));
  wasmtime_component_export_index_delete(api);
  if (!index) return LB_OWNED_RUNTIME;
  wasmtime_component_func_t function;
  bool found = wasmtime_component_instance_get_func(&frame->instance, context, index, &function);
  wasmtime_component_export_index_delete(index);
  if (!found) return LB_OWNED_RUNTIME;
  wasmtime_error_t *error = wasmtime_component_func_call(&function, context, args, count, out, 1);
  int status = frame->host.status;
  if (error) { wasmtime_error_delete(error); if (!status) status = LB_OWNED_RUNTIME; }
  return status;
}
/* Canonical lowering borrows an owned host proxy. Creating ResourceAny borrows
 * here would require an already-active Component Model call frame. */
static bool ows_write_input(void *data, size_t type, bool borrowed, uint64_t token, wasmtime_component_val_t *out) {
  return borrowed && ow_native_write_identity(data, type, false, token, out);
}
/* Only results of this frame's trusted component enter this reader. An own is
 * consumed once, even when several graph references point to its table row. */
static bool ows_read_output(void *data, size_t type, bool borrowed,
    const wasmtime_component_val_t *value, uint64_t *out) {
  ow_native_conversion *conversion = data; ow_native_host *host = conversion->host;
  if (!ow_native_ready(host) || !host->call || host->failure || borrowed
      || !ow_native_type(host, type, value->of.resource) || !wasmtime_component_resource_any_owned(value->of.resource)) return false;
  ow_native_read *read = conversion->reads;
  while (read && read->handle != value->of.resource) read = read->next;
  if (!read) {
    if (!lb_charge(&conversion->scope.memory, 1, sizeof(*read))) return false;
    read = lb_alloc(&conversion->scope.memory, 1, sizeof(*read));
    if (!read) return false;
    wasmtime_component_resource_host_t *resource = NULL;
    wasmtime_error_t *error = wasmtime_component_resource_any_to_host(host->context, value->of.resource, &resource);
    if (error) { ow_native_error(host, error); return false; }
    *read = (ow_native_read){.next = conversion->reads, .handle = value->of.resource,
      .rep = wasmtime_component_resource_host_rep(resource), .type = type,
      .borrowed = !wasmtime_component_resource_host_owned(resource)};
    uint32_t tag = wasmtime_component_resource_host_type(resource);
    wasmtime_component_resource_host_delete(resource); conversion->reads = read;
    if (tag != host->tags[type]) return false;
  }
  ow_native_entry *entry = ow_native_find(host, read->rep);
  if (!entry || read->type != type || read->borrowed || entry->type != type
      || !lb_owned_find(host->native, ow_native_kinds[type], entry->token)) return false;
  if (out) *out = entry->token;
  return true;
}
static inline int ows_conversion_status(ow_native_conversion *conversion, int invalid) {
  if (conversion->host->status) return conversion->host->status;
  return conversion->scope.memory.failure ? (int)conversion->scope.memory.failure : invalid;
}
static inline int ows_dispatch_0(ows_session *session,
    const lbov_ac77c4cfe87b7cbcbb00_td79b9bbde250ee1779da *a0, lbov_ac77c4cfe87b7cbcbb00_t160ce821a84f6887bbfd *out, ov_result_owner *owner) {
  ows_frame frame = {0}; int status = ows_frame_begin(session, &frame);
  if (status) return status;
  ow_native_conversion input, output;
  ow_native_conversion_init(&input, &frame.host); ow_native_conversion_init(&output, &frame.host);
  input.scope.identities.write = ows_write_input; output.scope.identities.read = ows_read_output;
  wasmtime_component_val_t args[1] = {{0}}, reply = {0};
  lbov_ac77c4cfe87b7cbcbb00_t160ce821a84f6887bbfd decoded = {0}, converted = {0}; ov_transaction transaction = {0};
  if (!ow_encode_2_input(a0, &input.scope, &args[0])) {
    status = ows_conversion_status(&input, LB_OWNED_INVALID); goto done;
  }
  status = ows_invoke(&frame, "claim-for", args, 1, &reply);
  if (status) goto done;
  if (!ow_decode_0_output(&reply, &output.scope, &decoded)) {
    status = ows_conversion_status(&output, OV_RESULT); goto done;
  }
  status = ov_begin(&transaction, session->native, owner, "owned-checked-records@1.0.0");
  if (!status) {
    lean_object *value = NULL;
    status = lbov_ac77c4cfe87b7cbcbb00_v160ce821a84f6887bbfd_in(&decoded, 0, 1, &transaction, &value);
    if (!status) status = lbov_ac77c4cfe87b7cbcbb00_v160ce821a84f6887bbfd_out(&converted, value, 0, &transaction);
  }
  if (!status) status = ov_commit(&transaction, owner);
  else if (transaction.scope.context) status = ov_abort(&transaction, status);
done:
  /* The store may have trapped, and output reads consume resource metadata.
   * Delete boxes only; frame teardown drains the complete native proxy ledger. */
  for (size_t i = 0; i < 1; ++i) wasmtime_component_val_delete(&args[i]);
  wasmtime_component_val_delete(&reply);
  ow_native_conversion_close(&output); ow_native_conversion_close(&input);
  status = ows_frame_end(&frame, status);
  if (status) (void)ov_owner_clear(owner); else *out = converted;
  return status;
}

static inline int ows_dispatch_1(ows_session *session,
    const lbov_ac77c4cfe87b7cbcbb00_t167081552b6f9c1d1afd *a0, const lbov_ac77c4cfe87b7cbcbb00_tdc0347e1f7f5c4d928f1 *a1, lbov_ac77c4cfe87b7cbcbb00_td79b9bbde250ee1779da *out, ov_result_owner *owner) {
  ows_frame frame = {0}; int status = ows_frame_begin(session, &frame);
  if (status) return status;
  ow_native_conversion input, output;
  ow_native_conversion_init(&input, &frame.host); ow_native_conversion_init(&output, &frame.host);
  input.scope.identities.write = ows_write_input; output.scope.identities.read = ows_read_output;
  wasmtime_component_val_t args[2] = {{0}}, reply = {0};
  lbov_ac77c4cfe87b7cbcbb00_td79b9bbde250ee1779da decoded = {0}, converted = {0}; ov_transaction transaction = {0};
  if (!ow_encode_3_input(a0, &input.scope, &args[0])) {
    status = ows_conversion_status(&input, LB_OWNED_INVALID); goto done;
  }
  if (!ow_encode_4_input(a1, &input.scope, &args[1])) {
    status = ows_conversion_status(&input, LB_OWNED_INVALID); goto done;
  }
  status = ows_invoke(&frame, "new-ticket", args, 2, &reply);
  if (status) goto done;
  if (!ow_decode_2_output(&reply, &output.scope, &decoded)) {
    status = ows_conversion_status(&output, OV_RESULT); goto done;
  }
  status = ov_begin(&transaction, session->native, owner, "owned-checked-records@1.0.0");
  if (!status) {
    lean_object *value = NULL;
    status = lbov_ac77c4cfe87b7cbcbb00_vd79b9bbde250ee1779da_in(&decoded, 0, 1, &transaction, &value);
    if (!status) status = lbov_ac77c4cfe87b7cbcbb00_vd79b9bbde250ee1779da_out(&converted, value, 0, &transaction);
  }
  if (!status) status = ov_commit(&transaction, owner);
  else if (transaction.scope.context) status = ov_abort(&transaction, status);
done:
  /* The store may have trapped, and output reads consume resource metadata.
   * Delete boxes only; frame teardown drains the complete native proxy ledger. */
  for (size_t i = 0; i < 2; ++i) wasmtime_component_val_delete(&args[i]);
  wasmtime_component_val_delete(&reply);
  ow_native_conversion_close(&output); ow_native_conversion_close(&input);
  status = ows_frame_end(&frame, status);
  if (status) (void)ov_owner_clear(owner); else *out = converted;
  return status;
}

static inline int ows_dispatch_2(ows_session *session,
    const lbov_ac77c4cfe87b7cbcbb00_td79b9bbde250ee1779da *a0, lbov_ac77c4cfe87b7cbcbb00_t167081552b6f9c1d1afd *out, ov_result_owner *owner) {
  ows_frame frame = {0}; int status = ows_frame_begin(session, &frame);
  if (status) return status;
  ow_native_conversion input, output;
  ow_native_conversion_init(&input, &frame.host); ow_native_conversion_init(&output, &frame.host);
  input.scope.identities.write = ows_write_input; output.scope.identities.read = ows_read_output;
  wasmtime_component_val_t args[1] = {{0}}, reply = {0};
  lbov_ac77c4cfe87b7cbcbb00_t167081552b6f9c1d1afd decoded = {0}, converted = {0}; ov_transaction transaction = {0};
  if (!ow_encode_2_input(a0, &input.scope, &args[0])) {
    status = ows_conversion_status(&input, LB_OWNED_INVALID); goto done;
  }
  status = ows_invoke(&frame, "serial", args, 1, &reply);
  if (status) goto done;
  if (!ow_decode_3_output(&reply, &output.scope, &decoded)) {
    status = ows_conversion_status(&output, OV_RESULT); goto done;
  }
  status = ov_begin(&transaction, session->native, owner, "owned-checked-records@1.0.0");
  if (!status) {
    lean_object *value = NULL;
    status = lbov_ac77c4cfe87b7cbcbb00_v167081552b6f9c1d1afd_in(&decoded, 0, 1, &transaction, &value);
    if (!status) status = lbov_ac77c4cfe87b7cbcbb00_v167081552b6f9c1d1afd_out(&converted, value, 0, &transaction);
  }
  if (!status) status = ov_commit(&transaction, owner);
  else if (transaction.scope.context) status = ov_abort(&transaction, status);
done:
  /* The store may have trapped, and output reads consume resource metadata.
   * Delete boxes only; frame teardown drains the complete native proxy ledger. */
  for (size_t i = 0; i < 1; ++i) wasmtime_component_val_delete(&args[i]);
  wasmtime_component_val_delete(&reply);
  ow_native_conversion_close(&output); ow_native_conversion_close(&input);
  status = ows_frame_end(&frame, status);
  if (status) (void)ov_owner_clear(owner); else *out = converted;
  return status;
}


_Static_assert(sizeof(bool) == 1, "owned C values require one-byte bool storage");
typedef struct oc_block {
  struct oc_block *next;
  int integer_initialized;
  mpz_t integer;
  max_align_t alignment;
  unsigned char data[];
} oc_block;
typedef struct { oc_block *head; ov_budget *budget; } oc_arena;
typedef struct oc_session oc_session;
typedef struct oc_result {
  struct oc_result *next;
  uint64_t key;
  oc_session *session;
  ov_result_owner native;
  oc_block *blocks;
} oc_result;
struct oc_session {
  oc_session *next;
  uint64_t key;
  lb_owned_context native;
  ows_session *transport;
  size_t results, calls;
  int closed;
};
static _Thread_local oc_session *oc_sessions;
static _Thread_local oc_result *oc_results;
extern lean_object *initialize_LeanBridgeOwned65b619a1ed9b48a2(uint8_t);
static void *oc_initialize(uint8_t builtin) { return initialize_LeanBridgeOwned65b619a1ed9b48a2(builtin); }

static inline void oc_release(oc_block *block) {
  while (block) {
    oc_block *next = block->next;
    if (block->integer_initialized) mpz_clear(block->integer);
    LB_OWNED_FREE(block); block = next;
  }
}
static inline int oc_block_new(oc_arena *arena, size_t count, size_t width, oc_block **out) {
  int status = ov_charge(arena->budget, count, width);
  if (!status) status = ov_charge(arena->budget, 1, sizeof(oc_block));
  if (status) return status;
  oc_block *block = LB_OWNED_ALLOC(sizeof(*block) + count * width);
  if (!block) return LB_OWNED_ALLOC_FAILED;
  memset(block, 0, sizeof(*block) + count * width);
  block->next = arena->head; arena->head = block; *out = block;
  return LB_OWNED_OK;
}
static inline int oc_allocate(oc_arena *arena, size_t count, size_t width, void **out) {
  *out = NULL; if (!count) return LB_OWNED_OK;
  oc_block *block; int status = oc_block_new(arena, count, width, &block);
  if (!status) *out = block->data;
  return status;
}
static inline int oc_integer(oc_arena *arena, const uint32_t *limbs, size_t length, int negative, mpz_srcptr *out) {
  int status = ov_span(arena->budget, limbs, length, sizeof(uint32_t), _Alignof(uint32_t));
  if (status) return status;
  size_t bits = length * 32, count = bits / GMP_NUMB_BITS + (bits % GMP_NUMB_BITS != 0);
  status = ov_charge(arena->budget, count, sizeof(mp_limb_t));
  if (status) return status;
  oc_block *block; status = oc_block_new(arena, 0, 1, &block);
  if (status) return status;
  mpz_init(block->integer); block->integer_initialized = 1;
  if (length) mpz_import(block->integer, length, -1, sizeof(uint32_t), 0, 0, limbs);
  if (negative) mpz_neg(block->integer, block->integer);
  *out = block->integer; return LB_OWNED_OK;
}
static inline oc_session *oc_session_find(const owned_checked_records_wasmtime_session *key) {
  for (oc_session *item = oc_sessions; item; item = item->next)
    if (item->key == (uint64_t)(uintptr_t)key) return item;
  return NULL;
}
static inline int oc_session_get(const owned_checked_records_wasmtime_session *key, oc_session **out) {
  if (!lean_bridge_native_process_valid()) return LB_OWNED_PROCESS;
  oc_session *session = oc_session_find(key);
  if (!session) return LB_OWNED_INVALID;
  if (session->closed) return LB_OWNED_CLOSED;
  int status = lb_owned_ready(&session->native);
  if (!status) *out = session;
  return status;
}
static inline void oc_session_collect(oc_session *session) {
  if (!session->closed || session->calls) return;
  if (session->transport) { ows_session_destroy(session->transport); session->transport = NULL; }
  if (session->native.initialized) (void)lb_owned_context_close(&session->native);
  if (session->results) return;
  oc_session **slot = &oc_sessions;
  while (*slot != session) slot = &(*slot)->next;
  *slot = session->next;
  (void)lean_bridge_native_identity_release(session->key, "owned-c-session:owned-checked-records@1.0.0", session);
  LB_OWNED_FREE(session);
}
owned_checked_records_wasmtime_status owned_checked_records_wasmtime_session_open(owned_checked_records_wasmtime_session **out) {
  if (getpid() != lb_package_pid) return (owned_checked_records_wasmtime_status)LB_OWNED_PROCESS;
  if (lb_package_failure()) return (owned_checked_records_wasmtime_status)LB_OWNED_RUNTIME;
  if (!ov_pointer(out, sizeof(*out), _Alignof(owned_checked_records_wasmtime_session *)) || *out) return (owned_checked_records_wasmtime_status)LB_OWNED_INVALID;
  if (!lean_bridge_native_process_valid()) return (owned_checked_records_wasmtime_status)LB_OWNED_PROCESS;
  if (!lean_bridge_native_component_initialize("owned-checked-records@1.0.0", oc_initialize)) return (owned_checked_records_wasmtime_status)LB_OWNED_RUNTIME;
  oc_session *session = LB_OWNED_ALLOC(sizeof(*session));
  if (!session) return (owned_checked_records_wasmtime_status)LB_OWNED_ALLOC_FAILED;
  memset(session, 0, sizeof(*session));
  int status = lb_owned_context_init(&session->native, "owned-checked-records@1.0.0");
  if (status) { LB_OWNED_FREE(session); return (owned_checked_records_wasmtime_status)status; }
  status = ows_session_open(&session->native, &session->transport);
  if (status) { lb_owned_context_close(&session->native); LB_OWNED_FREE(session); return (owned_checked_records_wasmtime_status)status; }
  session->key = lean_bridge_native_identity_acquire("owned-c-session:owned-checked-records@1.0.0", session);
  if (!session->key) { ows_session_destroy(session->transport); lb_owned_context_close(&session->native); LB_OWNED_FREE(session); return (owned_checked_records_wasmtime_status)LB_OWNED_LIMIT; }
  session->next = oc_sessions; oc_sessions = session;
  *out = (owned_checked_records_wasmtime_session *)(uintptr_t)session->key;
  return (owned_checked_records_wasmtime_status)LB_OWNED_OK;
}
owned_checked_records_wasmtime_status owned_checked_records_wasmtime_session_close(owned_checked_records_wasmtime_session **value) {
  if (getpid() != lb_package_pid) return (owned_checked_records_wasmtime_status)LB_OWNED_PROCESS;
  if (lb_package_failure()) return (owned_checked_records_wasmtime_status)LB_OWNED_RUNTIME;
  if (!ov_pointer(value, sizeof(*value), _Alignof(owned_checked_records_wasmtime_session *))) return (owned_checked_records_wasmtime_status)LB_OWNED_INVALID;
  if (!lean_bridge_native_process_valid()) return (owned_checked_records_wasmtime_status)LB_OWNED_PROCESS;
  if (!*value) return (owned_checked_records_wasmtime_status)LB_OWNED_OK;
  oc_session *session = oc_session_find(*value);
  if (!session) return (owned_checked_records_wasmtime_status)LB_OWNED_INVALID;
  if (session->closed) return (owned_checked_records_wasmtime_status)LB_OWNED_CLOSED;
  int status = lb_owned_affinity(&session->native);
  if (status) return (owned_checked_records_wasmtime_status)status;
  session->closed = 1; *value = NULL;
  ows_session_request_close(session->transport);
  oc_session_collect(session); return (owned_checked_records_wasmtime_status)LB_OWNED_OK;
}
owned_checked_records_wasmtime_status owned_checked_records_wasmtime_result_release(owned_checked_records_wasmtime_result **value) {
  if (getpid() != lb_package_pid) return (owned_checked_records_wasmtime_status)LB_OWNED_PROCESS;
  if (lb_package_failure()) return (owned_checked_records_wasmtime_status)LB_OWNED_RUNTIME;
  if (!ov_pointer(value, sizeof(*value), _Alignof(owned_checked_records_wasmtime_result *))) return (owned_checked_records_wasmtime_status)LB_OWNED_INVALID;
  if (!lean_bridge_native_process_valid()) return (owned_checked_records_wasmtime_status)LB_OWNED_PROCESS;
  if (!*value) return (owned_checked_records_wasmtime_status)LB_OWNED_OK;
  oc_result **slot = &oc_results;
  while (*slot && (*slot)->key != (uint64_t)(uintptr_t)*value) slot = &(*slot)->next;
  if (!*slot) return (owned_checked_records_wasmtime_status)LB_OWNED_INVALID;
  oc_result *result = *slot; oc_session *session = result->session;
  int status = ov_owner_clear(&result->native);
  if (!ov_owner_empty(&result->native)) return (owned_checked_records_wasmtime_status)status;
  *slot = result->next; --session->results;
  if (lean_bridge_native_identity_release(result->key, "owned-c-result:owned-checked-records@1.0.0", result) < 0 && !status) status = LB_OWNED_RUNTIME;
  oc_release(result->blocks); LB_OWNED_FREE(result); *value = NULL;
  oc_session_collect(session); return (owned_checked_records_wasmtime_status)status;
}
static inline int oc_result_begin(oc_session *session, ov_budget *budget, oc_result **out) {
  if (session->calls == LB_OWNED_SCOPE_LIMIT) return LB_OWNED_LIMIT;
  int status = ov_charge(budget, 1, sizeof(oc_result));
  if (status) return status;
  oc_result *result = LB_OWNED_ALLOC(sizeof(*result));
  if (!result) return LB_OWNED_ALLOC_FAILED;
  memset(result, 0, sizeof(*result)); result->session = session;
  ++session->calls; *out = result; return LB_OWNED_OK;
}
static inline int oc_result_finish(oc_result *result, oc_arena *output, int status, owned_checked_records_wasmtime_result **owner) {
  oc_session *session = result->session;
  if (status == OV_RESULT) lean_bridge_native_runtime_retire();
  if (!status && session->closed) status = LB_OWNED_CLOSED;
  if (!status) status = lb_owned_ready(&session->native);
  if (!status) {
    result->key = lean_bridge_native_identity_acquire("owned-c-result:owned-checked-records@1.0.0", result);
    if (!result->key) status = LB_OWNED_LIMIT;
  }
  if (!status) {
    result->blocks = output->head; output->head = NULL;
    result->next = oc_results; oc_results = result; ++session->results;
    *owner = (owned_checked_records_wasmtime_result *)(uintptr_t)result->key;
  } else {
    (void)ov_owner_clear(&result->native);
    oc_release(output->head); output->head = NULL; LB_OWNED_FREE(result);
  }
  --session->calls; oc_session_collect(session); return status;
}
static inline ov_budget oc_budget(void) {
  return (ov_budget){ .bytes = 16777216, .visits = 262144 };
}
static inline int oc_outputs(const void *out, size_t bytes, size_t alignment, const void *owner) {
  if (!ov_pointer(out, bytes, alignment) || !ov_pointer(owner, sizeof(void *), _Alignof(void *))) return 0;
  uintptr_t a = (uintptr_t)out, b = (uintptr_t)owner;
  return a < b ? bytes <= b - a : sizeof(void *) <= a - b;
}

static inline int oc_v0_to(owned_checked_records_wasmtime_value_160ce821a84f6887bbfd_t const *, lbov_ac77c4cfe87b7cbcbb00_t160ce821a84f6887bbfd *, size_t, oc_arena *);
static inline int oc_v0_from(const lbov_ac77c4cfe87b7cbcbb00_t160ce821a84f6887bbfd *, owned_checked_records_wasmtime_value_160ce821a84f6887bbfd_t *, size_t, oc_arena *);
static inline int oc_v1_to(owned_checked_records_wasmtime_claim_t const *, lbov_ac77c4cfe87b7cbcbb00_tb2825946e038e653bd2b *, size_t, oc_arena *);
static inline int oc_v1_from(const lbov_ac77c4cfe87b7cbcbb00_tb2825946e038e653bd2b *, owned_checked_records_wasmtime_claim_t *, size_t, oc_arena *);
static inline int oc_v2_to(owned_checked_records_wasmtime_ticket_t const *, lbov_ac77c4cfe87b7cbcbb00_td79b9bbde250ee1779da *, size_t, oc_arena *);
static inline int oc_v2_from(const lbov_ac77c4cfe87b7cbcbb00_td79b9bbde250ee1779da *, owned_checked_records_wasmtime_ticket_t *, size_t, oc_arena *);
static inline int oc_v3_to(mpz_srcptr const *, lbov_ac77c4cfe87b7cbcbb00_t167081552b6f9c1d1afd *, size_t, oc_arena *);
static inline int oc_v3_from(const lbov_ac77c4cfe87b7cbcbb00_t167081552b6f9c1d1afd *, mpz_srcptr *, size_t, oc_arena *);
static inline int oc_v4_to(owned_checked_records_wasmtime_scalar_string_t const *, lbov_ac77c4cfe87b7cbcbb00_tdc0347e1f7f5c4d928f1 *, size_t, oc_arena *);
static inline int oc_v4_from(const lbov_ac77c4cfe87b7cbcbb00_tdc0347e1f7f5c4d928f1 *, owned_checked_records_wasmtime_scalar_string_t *, size_t, oc_arena *);
static inline int oc_v0_to(owned_checked_records_wasmtime_value_160ce821a84f6887bbfd_t const *value, lbov_ac77c4cfe87b7cbcbb00_t160ce821a84f6887bbfd *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(owned_checked_records_wasmtime_value_160ce821a84f6887bbfd_t))) return LB_OWNED_INVALID;
  int status = ov_enter(arena->budget, value, 0, depth);
  if (status) return status;
  (void)out;
  uint8_t selected; memcpy(&selected, &value->has_value, 1);
  if (selected > 1) return LB_OWNED_INVALID;
  out->tag = selected;
  if (out->tag == 1) {
  {
    void *data = NULL;
    status = oc_allocate(arena, 1, sizeof(lbov_ac77c4cfe87b7cbcbb00_tb2825946e038e653bd2b), &data);
    if (status) return status;
    out->f0 = data;
    status = oc_v1_to(value->value, data, depth + 1, arena);
    if (status) return status;
  }
  }
  return LB_OWNED_OK;
}
static inline int oc_v0_from(const lbov_ac77c4cfe87b7cbcbb00_t160ce821a84f6887bbfd *value, owned_checked_records_wasmtime_value_160ce821a84f6887bbfd_t *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_ac77c4cfe87b7cbcbb00_t160ce821a84f6887bbfd))) return OV_RESULT;
  int status = ov_enter(arena->budget, value, 0, depth);
  if (status) return status;
  (void)out;
  if (value->tag > 1) return OV_RESULT;
  out->has_value = value->tag != 0;
  if (value->tag == 1) {
  {
    void *data = NULL;
    status = oc_allocate(arena, 1, sizeof(owned_checked_records_wasmtime_claim_t), &data);
    if (status) return status;
    out->value = data;
    status = oc_v1_from(value->f0, data, depth + 1, arena);
    if (status) return status;
  }
  }
  return LB_OWNED_OK;
}
static inline int oc_v1_to(owned_checked_records_wasmtime_claim_t const *value, lbov_ac77c4cfe87b7cbcbb00_tb2825946e038e653bd2b *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(owned_checked_records_wasmtime_claim_t))) return LB_OWNED_INVALID;
  int status = ov_enter(arena->budget, value, 1, depth);
  if (status) return status;
  (void)out;
  {
    status = oc_v2_to(&value->holder, &out->f0, depth + 1, arena);
    if (status) return status;
  }
  {
    status = oc_v3_to(&value->quota, &out->f1, depth + 1, arena);
    if (status) return status;
  }
  return LB_OWNED_OK;
}
static inline int oc_v1_from(const lbov_ac77c4cfe87b7cbcbb00_tb2825946e038e653bd2b *value, owned_checked_records_wasmtime_claim_t *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_ac77c4cfe87b7cbcbb00_tb2825946e038e653bd2b))) return OV_RESULT;
  int status = ov_enter(arena->budget, value, 1, depth);
  if (status) return status;
  (void)out;
  {
    status = oc_v2_from(&value->f0, &out->holder, depth + 1, arena);
    if (status) return status;
  }
  {
    status = oc_v3_from(&value->f1, &out->quota, depth + 1, arena);
    if (status) return status;
  }
  return LB_OWNED_OK;
}
static inline int oc_v2_to(owned_checked_records_wasmtime_ticket_t const *value, lbov_ac77c4cfe87b7cbcbb00_td79b9bbde250ee1779da *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(owned_checked_records_wasmtime_ticket_t))) return LB_OWNED_INVALID;
  int status = ov_enter(arena->budget, value, 2, depth);
  if (status) return status;
  (void)out;
  if (!*value) return LB_OWNED_INVALID;
  out->token = (uint64_t)(uintptr_t)*value;
  return LB_OWNED_OK;
}
static inline int oc_v2_from(const lbov_ac77c4cfe87b7cbcbb00_td79b9bbde250ee1779da *value, owned_checked_records_wasmtime_ticket_t *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_ac77c4cfe87b7cbcbb00_td79b9bbde250ee1779da))) return OV_RESULT;
  int status = ov_enter(arena->budget, value, 2, depth);
  if (status) return status;
  (void)out;
  if (!value->token) return OV_RESULT;
  *out = (owned_checked_records_wasmtime_ticket_t)(uintptr_t)value->token;
  return LB_OWNED_OK;
}
static inline int oc_v3_to(mpz_srcptr const *value, lbov_ac77c4cfe87b7cbcbb00_t167081552b6f9c1d1afd *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(mpz_srcptr))) return LB_OWNED_INVALID;
  int status = ov_enter(arena->budget, value, 3, depth);
  if (status) return status;
  (void)out;
  if (!ov_pointer(*value, sizeof(**value), _Alignof(__mpz_struct))) return LB_OWNED_INVALID;
  if (mpz_sgn(*value) < 0) return LB_OWNED_INVALID;
  if (mpz_size(*value) > arena->budget->bytes / sizeof(mp_limb_t) + 1) return LB_OWNED_LIMIT;
  size_t length = mpz_sgn(*value) ? (mpz_sizeinbase(*value, 2) - 1) / 32 + 1 : 0;
  void *data = NULL; status = oc_allocate(arena, length, sizeof(uint32_t), &data);
  if (status) return status;
  if (length) mpz_export(data, &length, -1, sizeof(uint32_t), 0, 0, *value);
  out->data = data; out->length = length;
  return LB_OWNED_OK;
}
static inline int oc_v3_from(const lbov_ac77c4cfe87b7cbcbb00_t167081552b6f9c1d1afd *value, mpz_srcptr *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_ac77c4cfe87b7cbcbb00_t167081552b6f9c1d1afd))) return OV_RESULT;
  int status = ov_enter(arena->budget, value, 3, depth);
  if (status) return status;
  (void)out;
  return oc_integer(arena, value->data, value->length, 0, out);
  return LB_OWNED_OK;
}
static inline int oc_v4_to(owned_checked_records_wasmtime_scalar_string_t const *value, lbov_ac77c4cfe87b7cbcbb00_tdc0347e1f7f5c4d928f1 *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(owned_checked_records_wasmtime_scalar_string_t))) return LB_OWNED_INVALID;
  int status = ov_enter(arena->budget, value, 4, depth);
  if (status) return status;
  (void)out;
  status = ov_span(arena->budget, value->data, value->length, 1, 1);
  if (status) return status;
  if (!ov_utf8((const uint8_t *)value->data, value->length)) return LB_OWNED_INVALID;
  out->data = value->data; out->length = value->length;
  return LB_OWNED_OK;
}
static inline int oc_v4_from(const lbov_ac77c4cfe87b7cbcbb00_tdc0347e1f7f5c4d928f1 *value, owned_checked_records_wasmtime_scalar_string_t *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_ac77c4cfe87b7cbcbb00_tdc0347e1f7f5c4d928f1))) return OV_RESULT;
  int status = ov_enter(arena->budget, value, 4, depth);
  if (status) return status;
  (void)out;
  status = ov_span(arena->budget, value->data, value->length, 1, 1);
  if (status) return status;
  if (!ov_utf8((const uint8_t *)value->data, value->length)) return OV_RESULT;
  out->data = value->data; out->length = value->length;
  return LB_OWNED_OK;
}


static inline int lbov_ac77c4cfe87b7cbcbb00_vd79b9bbde250ee1779da_retain(lb_owned_context *context, const lbov_ac77c4cfe87b7cbcbb00_td79b9bbde250ee1779da *input, lbov_ac77c4cfe87b7cbcbb00_td79b9bbde250ee1779da *out, ov_result_owner *owner) {
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  lean_object *value = NULL;
  status = lbov_ac77c4cfe87b7cbcbb00_vd79b9bbde250ee1779da_in(input, 0, 1, &transaction, &value);
  if (status) return ov_abort(&transaction, status);
  status = lbov_ac77c4cfe87b7cbcbb00_vd79b9bbde250ee1779da_out(out, value, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  return ov_commit(&transaction, owner);
}
static inline int lbov_ac77c4cfe87b7cbcbb00_v160ce821a84f6887bbfd_retain(lb_owned_context *context, const lbov_ac77c4cfe87b7cbcbb00_t160ce821a84f6887bbfd *input, lbov_ac77c4cfe87b7cbcbb00_t160ce821a84f6887bbfd *out, ov_result_owner *owner) {
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  lean_object *value = NULL;
  status = lbov_ac77c4cfe87b7cbcbb00_v160ce821a84f6887bbfd_in(input, 0, 1, &transaction, &value);
  if (status) return ov_abort(&transaction, status);
  status = lbov_ac77c4cfe87b7cbcbb00_v160ce821a84f6887bbfd_out(out, value, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  return ov_commit(&transaction, owner);
}
static inline int lbov_ac77c4cfe87b7cbcbb00_vb2825946e038e653bd2b_retain(lb_owned_context *context, const lbov_ac77c4cfe87b7cbcbb00_tb2825946e038e653bd2b *input, lbov_ac77c4cfe87b7cbcbb00_tb2825946e038e653bd2b *out, ov_result_owner *owner) {
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  lean_object *value = NULL;
  status = lbov_ac77c4cfe87b7cbcbb00_vb2825946e038e653bd2b_in(input, 0, 1, &transaction, &value);
  if (status) return ov_abort(&transaction, status);
  status = lbov_ac77c4cfe87b7cbcbb00_vb2825946e038e653bd2b_out(out, value, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  return ov_commit(&transaction, owner);
}
static inline int lbov_ac77c4cfe87b7cbcbb00_v167081552b6f9c1d1afd_retain(lb_owned_context *context, const lbov_ac77c4cfe87b7cbcbb00_t167081552b6f9c1d1afd *input, lbov_ac77c4cfe87b7cbcbb00_t167081552b6f9c1d1afd *out, ov_result_owner *owner) {
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  lean_object *value = NULL;
  status = lbov_ac77c4cfe87b7cbcbb00_v167081552b6f9c1d1afd_in(input, 0, 1, &transaction, &value);
  if (status) return ov_abort(&transaction, status);
  status = lbov_ac77c4cfe87b7cbcbb00_v167081552b6f9c1d1afd_out(out, value, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  return ov_commit(&transaction, owner);
}
static inline int lbov_ac77c4cfe87b7cbcbb00_vdc0347e1f7f5c4d928f1_retain(lb_owned_context *context, const lbov_ac77c4cfe87b7cbcbb00_tdc0347e1f7f5c4d928f1 *input, lbov_ac77c4cfe87b7cbcbb00_tdc0347e1f7f5c4d928f1 *out, ov_result_owner *owner) {
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  lean_object *value = NULL;
  status = lbov_ac77c4cfe87b7cbcbb00_vdc0347e1f7f5c4d928f1_in(input, 0, 1, &transaction, &value);
  if (status) return ov_abort(&transaction, status);
  status = lbov_ac77c4cfe87b7cbcbb00_vdc0347e1f7f5c4d928f1_out(out, value, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  return ov_commit(&transaction, owner);
}
owned_checked_records_wasmtime_status owned_checked_records_wasmtime_claim_for(owned_checked_records_wasmtime_session *session, owned_checked_records_wasmtime_ticket_t a0, owned_checked_records_wasmtime_value_160ce821a84f6887bbfd_t *out, owned_checked_records_wasmtime_result **owner) {
  if (getpid() != lb_package_pid) return (owned_checked_records_wasmtime_status)LB_OWNED_PROCESS;
  if (lb_package_failure()) return (owned_checked_records_wasmtime_status)LB_OWNED_RUNTIME;
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_checked_records_wasmtime_value_160ce821a84f6887bbfd_t), owner) || *owner) return (owned_checked_records_wasmtime_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_wasmtime_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_wasmtime_status)status;
  lbov_ac77c4cfe87b7cbcbb00_td79b9bbde250ee1779da raw0 = {0};
  lbov_ac77c4cfe87b7cbcbb00_t160ce821a84f6887bbfd returned = {0};
  owned_checked_records_wasmtime_value_160ce821a84f6887bbfd_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v2_to(&a0, &raw0, 0, &input);
  if (!status) status = ows_dispatch_0(active->transport, &raw0, &returned, &result_owner->native);
  if (!status) {
    status = oc_v0_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_wasmtime_status)status;
}
owned_checked_records_wasmtime_status owned_checked_records_wasmtime_new_ticket(owned_checked_records_wasmtime_session *session, mpz_srcptr a0, owned_checked_records_wasmtime_scalar_string_t a1, owned_checked_records_wasmtime_ticket_t *out, owned_checked_records_wasmtime_result **owner) {
  if (getpid() != lb_package_pid) return (owned_checked_records_wasmtime_status)LB_OWNED_PROCESS;
  if (lb_package_failure()) return (owned_checked_records_wasmtime_status)LB_OWNED_RUNTIME;
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_checked_records_wasmtime_ticket_t), owner) || *owner) return (owned_checked_records_wasmtime_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_wasmtime_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_wasmtime_status)status;
  lbov_ac77c4cfe87b7cbcbb00_t167081552b6f9c1d1afd raw0 = {0};
  lbov_ac77c4cfe87b7cbcbb00_tdc0347e1f7f5c4d928f1 raw1 = {0};
  lbov_ac77c4cfe87b7cbcbb00_td79b9bbde250ee1779da returned = {0};
  owned_checked_records_wasmtime_ticket_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v3_to(&a0, &raw0, 0, &input);
  if (!status) status = oc_v4_to(&a1, &raw1, 0, &input);
  if (!status) status = ows_dispatch_1(active->transport, &raw0, &raw1, &returned, &result_owner->native);
  if (!status) {
    status = oc_v2_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_wasmtime_status)status;
}
owned_checked_records_wasmtime_status owned_checked_records_wasmtime_serial(owned_checked_records_wasmtime_session *session, owned_checked_records_wasmtime_ticket_t a0, mpz_srcptr *out, owned_checked_records_wasmtime_result **owner) {
  if (getpid() != lb_package_pid) return (owned_checked_records_wasmtime_status)LB_OWNED_PROCESS;
  if (lb_package_failure()) return (owned_checked_records_wasmtime_status)LB_OWNED_RUNTIME;
  if (!oc_outputs(out, sizeof(*out), _Alignof(mpz_srcptr), owner) || *owner) return (owned_checked_records_wasmtime_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_wasmtime_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_wasmtime_status)status;
  lbov_ac77c4cfe87b7cbcbb00_td79b9bbde250ee1779da raw0 = {0};
  lbov_ac77c4cfe87b7cbcbb00_t167081552b6f9c1d1afd returned = {0};
  mpz_srcptr converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v2_to(&a0, &raw0, 0, &input);
  if (!status) status = ows_dispatch_2(active->transport, &raw0, &returned, &result_owner->native);
  if (!status) {
    status = oc_v3_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_wasmtime_status)status;
}
owned_checked_records_wasmtime_status owned_checked_records_wasmtime_ticket_t_retain(owned_checked_records_wasmtime_session *session, owned_checked_records_wasmtime_ticket_t a0, owned_checked_records_wasmtime_ticket_t *out, owned_checked_records_wasmtime_result **owner) {
  if (getpid() != lb_package_pid) return (owned_checked_records_wasmtime_status)LB_OWNED_PROCESS;
  if (lb_package_failure()) return (owned_checked_records_wasmtime_status)LB_OWNED_RUNTIME;
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_checked_records_wasmtime_ticket_t), owner) || *owner) return (owned_checked_records_wasmtime_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_wasmtime_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_wasmtime_status)status;
  lbov_ac77c4cfe87b7cbcbb00_td79b9bbde250ee1779da raw0 = {0};
  lbov_ac77c4cfe87b7cbcbb00_td79b9bbde250ee1779da returned = {0};
  owned_checked_records_wasmtime_ticket_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v2_to(&a0, &raw0, 0, &input);
  if (!status) status = lbov_ac77c4cfe87b7cbcbb00_vd79b9bbde250ee1779da_retain(&active->native, &raw0, &returned, &result_owner->native);
  if (!status) {
    status = oc_v2_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_wasmtime_status)status;
}
owned_checked_records_wasmtime_status owned_checked_records_wasmtime_value_160ce821a84f6887bbfd_t_copy(owned_checked_records_wasmtime_session *session, owned_checked_records_wasmtime_value_160ce821a84f6887bbfd_t const * a0, owned_checked_records_wasmtime_value_160ce821a84f6887bbfd_t *out, owned_checked_records_wasmtime_result **owner) {
  if (getpid() != lb_package_pid) return (owned_checked_records_wasmtime_status)LB_OWNED_PROCESS;
  if (lb_package_failure()) return (owned_checked_records_wasmtime_status)LB_OWNED_RUNTIME;
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_checked_records_wasmtime_value_160ce821a84f6887bbfd_t), owner) || *owner) return (owned_checked_records_wasmtime_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_wasmtime_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_wasmtime_status)status;
  lbov_ac77c4cfe87b7cbcbb00_t160ce821a84f6887bbfd raw0 = {0};
  lbov_ac77c4cfe87b7cbcbb00_t160ce821a84f6887bbfd returned = {0};
  owned_checked_records_wasmtime_value_160ce821a84f6887bbfd_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v0_to(a0, &raw0, 0, &input);
  if (!status) status = lbov_ac77c4cfe87b7cbcbb00_v160ce821a84f6887bbfd_retain(&active->native, &raw0, &returned, &result_owner->native);
  if (!status) {
    status = oc_v0_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_wasmtime_status)status;
}
owned_checked_records_wasmtime_status owned_checked_records_wasmtime_claim_t_copy(owned_checked_records_wasmtime_session *session, owned_checked_records_wasmtime_claim_t const * a0, owned_checked_records_wasmtime_claim_t *out, owned_checked_records_wasmtime_result **owner) {
  if (getpid() != lb_package_pid) return (owned_checked_records_wasmtime_status)LB_OWNED_PROCESS;
  if (lb_package_failure()) return (owned_checked_records_wasmtime_status)LB_OWNED_RUNTIME;
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_checked_records_wasmtime_claim_t), owner) || *owner) return (owned_checked_records_wasmtime_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_wasmtime_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_wasmtime_status)status;
  lbov_ac77c4cfe87b7cbcbb00_tb2825946e038e653bd2b raw0 = {0};
  lbov_ac77c4cfe87b7cbcbb00_tb2825946e038e653bd2b returned = {0};
  owned_checked_records_wasmtime_claim_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v1_to(a0, &raw0, 0, &input);
  if (!status) status = lbov_ac77c4cfe87b7cbcbb00_vb2825946e038e653bd2b_retain(&active->native, &raw0, &returned, &result_owner->native);
  if (!status) {
    status = oc_v1_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_wasmtime_status)status;
}
owned_checked_records_wasmtime_status owned_checked_records_wasmtime_scalar_nat_copy(owned_checked_records_wasmtime_session *session, mpz_srcptr a0, mpz_srcptr *out, owned_checked_records_wasmtime_result **owner) {
  if (getpid() != lb_package_pid) return (owned_checked_records_wasmtime_status)LB_OWNED_PROCESS;
  if (lb_package_failure()) return (owned_checked_records_wasmtime_status)LB_OWNED_RUNTIME;
  if (!oc_outputs(out, sizeof(*out), _Alignof(mpz_srcptr), owner) || *owner) return (owned_checked_records_wasmtime_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_wasmtime_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_wasmtime_status)status;
  lbov_ac77c4cfe87b7cbcbb00_t167081552b6f9c1d1afd raw0 = {0};
  lbov_ac77c4cfe87b7cbcbb00_t167081552b6f9c1d1afd returned = {0};
  mpz_srcptr converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v3_to(&a0, &raw0, 0, &input);
  if (!status) status = lbov_ac77c4cfe87b7cbcbb00_v167081552b6f9c1d1afd_retain(&active->native, &raw0, &returned, &result_owner->native);
  if (!status) {
    status = oc_v3_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_wasmtime_status)status;
}
owned_checked_records_wasmtime_status owned_checked_records_wasmtime_scalar_string_copy(owned_checked_records_wasmtime_session *session, owned_checked_records_wasmtime_scalar_string_t a0, owned_checked_records_wasmtime_scalar_string_t *out, owned_checked_records_wasmtime_result **owner) {
  if (getpid() != lb_package_pid) return (owned_checked_records_wasmtime_status)LB_OWNED_PROCESS;
  if (lb_package_failure()) return (owned_checked_records_wasmtime_status)LB_OWNED_RUNTIME;
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_checked_records_wasmtime_scalar_string_t), owner) || *owner) return (owned_checked_records_wasmtime_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_wasmtime_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_wasmtime_status)status;
  lbov_ac77c4cfe87b7cbcbb00_tdc0347e1f7f5c4d928f1 raw0 = {0};
  lbov_ac77c4cfe87b7cbcbb00_tdc0347e1f7f5c4d928f1 returned = {0};
  owned_checked_records_wasmtime_scalar_string_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v4_to(&a0, &raw0, 0, &input);
  if (!status) status = lbov_ac77c4cfe87b7cbcbb00_vdc0347e1f7f5c4d928f1_retain(&active->native, &raw0, &returned, &result_owner->native);
  if (!status) {
    status = oc_v4_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_wasmtime_status)status;
}
