#include "component.h"
#include "lean_bridge_native_runtime.h"
static _Thread_local int lean_bridge_owned_callback_failure_ac77c4cfe87b7cbcbb00_state;
int lean_bridge_owned_callback_failure_ac77c4cfe87b7cbcbb00(void) { int result = lean_bridge_owned_callback_failure_ac77c4cfe87b7cbcbb00_state; lean_bridge_owned_callback_failure_ac77c4cfe87b7cbcbb00_state = 0; return result; }
