#pragma once
#include <lean/lean.h>
#include <stdint.h>
/* Private typed helpers consume their Array arguments and return an owned Array. */
uint32_t lean_bridge_owned_2264dfae97c107e72f410659_t160ce821a84f6887bbfd_branch(lean_object *);
lean_object * lean_bridge_owned_2264dfae97c107e72f410659_t160ce821a84f6887bbfd_none(lean_object *);
lean_object * lean_bridge_owned_2264dfae97c107e72f410659_t160ce821a84f6887bbfd_make0(lean_object *);
lean_object * lean_bridge_owned_2264dfae97c107e72f410659_t160ce821a84f6887bbfd_field0(lean_object *);
lean_object * lean_bridge_owned_2264dfae97c107e72f410659_tb2825946e038e653bd2b_make(lean_object *, lean_object *);
lean_object * lean_bridge_owned_2264dfae97c107e72f410659_tb2825946e038e653bd2b_field0(lean_object *);
lean_object * lean_bridge_owned_2264dfae97c107e72f410659_tb2825946e038e653bd2b_field1(lean_object *);
lean_object * lean_bridge_owned_2264dfae97c107e72f410659_f483485736ace9af57086(lean_object *);
lean_object * lean_bridge_owned_2264dfae97c107e72f410659_fa1e5189bd92568e4b939(lean_object *, lean_object *);
lean_object * lean_bridge_owned_2264dfae97c107e72f410659_fec926afda994fba3abe2(lean_object *);
int lean_bridge_owned_callback_failure_58757d343423a2b300ab(void);
