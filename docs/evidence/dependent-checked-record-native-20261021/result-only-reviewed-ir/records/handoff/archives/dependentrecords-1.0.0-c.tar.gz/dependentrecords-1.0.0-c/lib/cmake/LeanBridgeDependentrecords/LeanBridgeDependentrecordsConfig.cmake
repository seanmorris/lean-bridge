get_filename_component(_LB_PREFIX "${CMAKE_CURRENT_LIST_DIR}/../../.." ABSOLUTE)
if(NOT TARGET LeanBridge::dependentrecords)
  add_library(LeanBridge::dependentrecords SHARED IMPORTED)
  set_target_properties(LeanBridge::dependentrecords PROPERTIES
    IMPORTED_LOCATION "${_LB_PREFIX}/lib/libdependentrecords_gmp.so"
    INTERFACE_INCLUDE_DIRECTORIES "${_LB_PREFIX}/include"
    INTERFACE_COMPILE_FEATURES "c_std_11"
    INTERFACE_LINK_LIBRARIES "${_LB_PREFIX}/lib/libgmp.so.10"
  )
endif()
unset(_LB_PREFIX)
