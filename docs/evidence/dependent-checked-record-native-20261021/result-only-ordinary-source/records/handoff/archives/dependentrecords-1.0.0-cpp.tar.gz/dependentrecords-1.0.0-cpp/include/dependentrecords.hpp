#pragma once
#include "dependentrecords.h"
#include <stdexcept>
#include <memory>
#include <string>
#include <variant>
#include <optional>
#include <vector>
#include <utility>

#ifndef BOOST_MP_STANDALONE
#define BOOST_MP_STANDALONE
#endif
#include <boost/multiprecision/cpp_int.hpp>

namespace lean_bridge::dependentrecords {

using Nat = boost::multiprecision::cpp_int;
using Int = boost::multiprecision::cpp_int;
struct Dependent {
  Nat bound{};
  Nat below{};
  friend bool operator==(const Dependent&, const Dependent&) = default;
};
class Error final : public std::runtime_error {
public:
  dependentrecords_status status;
  dependentrecords_error_code code;
  Error(dependentrecords_status value, const dependentrecords_error& error)
    : std::runtime_error(error.message ? std::string(error.message, error.message_length) : "Lean call failed"), status(value), code(error.code) {}
};
namespace detail {
[[noreturn]] inline void invalid(const char* message) {
  const dependentrecords_error error{DEPENDENTRECORDS_ERROR_INVALID_ARGUMENT, message, std::char_traits<char>::length(message)};
  throw Error(DEPENDENTRECORDS_STATUS_INVALID_ARGUMENT, error);
}
inline void charge(size_t& budget, size_t count, size_t width) {
  if (count > budget / width) {
    const dependentrecords_error error{DEPENDENTRECORDS_ERROR_INVALID_ARGUMENT, "16 MiB call limit exceeded", 26};
    throw Error(DEPENDENTRECORDS_STATUS_INVALID_ARGUMENT, error);
  }
  budget -= count * width;
}
inline void check0(const Nat& source, size_t& budget) {
  (void)source; (void)budget;
  if (source < 0) invalid("Nat must be nonnegative");
  charge(budget, source == 0 ? 0 : (boost::multiprecision::msb(source < 0 ? -source : source) / 32 + 1), sizeof(uint32_t));
}
struct View0 {
  std::vector<uint32_t> limbs;
  dependentrecords_nat value{};
  explicit View0(const Nat& source) {
    (void)source;
    if (source != 0) boost::multiprecision::export_bits(source, std::back_inserter(limbs), 32, false);
    value = dependentrecords_nat{limbs.data(), limbs.size(), nullptr, nullptr};
  }
};
inline Nat from0(const dependentrecords_nat& source) {
  (void)source;
  Nat result = 0;
  if (source.length) boost::multiprecision::import_bits(result, source.data, source.data + source.length, 32, false);
  return result;
}

inline void check1(const Dependent& source, size_t& budget) {
  (void)source; (void)budget;
  charge(budget, 1, sizeof(dependentrecords_dependent));
  check0(source.bound, budget);
  check0(source.below, budget);
}
struct View1 {
  View0 field0;
  View0 field1;
  dependentrecords_dependent value{};
  explicit View1(const Dependent& source) : field0(source.bound), field1(source.below) {
    (void)source;
    value = dependentrecords_dependent{field0.value, field1.value};
  }
};
inline Dependent from1(const dependentrecords_dependent& source) {
  (void)source;
  return Dependent{from0(source.bound), from0(source.below)};
}
inline void check(dependentrecords_status status, const dependentrecords_error& error) {
  if (status != DEPENDENTRECORDS_STATUS_OK) throw Error(status, error);
}
template<class T, void (*Clear)(T*)> struct Owned {
  T* value;
  ~Owned() { Clear(value); }
  Owned(const Owned&) = delete;
  Owned& operator=(const Owned&) = delete;
  explicit Owned(T* input) : value(input) {}
};
}


inline Dependent dependent_result(Nat const& arg0) {
  dependentrecords_error _lb_error{}; size_t _lb_budget = 16u * 1024u * 1024u; (void)_lb_budget;
  detail::check0(arg0, _lb_budget);
  detail::View0 _lb_arg0{arg0};
  dependentrecords_dependent _lb_result{};
  detail::Owned<dependentrecords_dependent, dependentrecords_dependent_clear> _lb_owner{&_lb_result};
  const auto _lb_status = dependentrecords_dependent_result(&_lb_arg0.value, &_lb_result, &_lb_error);
  detail::check(_lb_status, _lb_error);
  return detail::from1(_lb_result);
}
}
