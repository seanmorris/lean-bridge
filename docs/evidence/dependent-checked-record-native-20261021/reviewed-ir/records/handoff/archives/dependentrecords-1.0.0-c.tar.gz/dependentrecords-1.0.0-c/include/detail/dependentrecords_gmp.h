#pragma once
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <gmp.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef enum dependentrecords_gmp_status { DEPENDENTRECORDS_GMP_STATUS_OK = 0, DEPENDENTRECORDS_GMP_STATUS_INVALID_ARGUMENT = 1, DEPENDENTRECORDS_GMP_STATUS_RUNTIME_UNAVAILABLE = 2, DEPENDENTRECORDS_GMP_STATUS_RUNTIME_REJECTED = 3, DEPENDENTRECORDS_GMP_STATUS_DECLARED_ERROR = 4, DEPENDENTRECORDS_GMP_STATUS_UNEXPECTED_ERROR = 5 } dependentrecords_gmp_status;
typedef enum dependentrecords_gmp_error_code { DEPENDENTRECORDS_GMP_ERROR_NONE = 0, DEPENDENTRECORDS_GMP_ERROR_INVALID_ARGUMENT = 1, DEPENDENTRECORDS_GMP_ERROR_RUNTIME_UNAVAILABLE = 2, DEPENDENTRECORDS_GMP_ERROR_UNEXPECTED = 65535 } dependentrecords_gmp_error_code;
typedef struct { dependentrecords_gmp_error_code code; const char* message; size_t message_length; } dependentrecords_gmp_error;
typedef mpz_t dependentrecords_gmp_nat;
typedef struct dependentrecords_gmp_dependent dependentrecords_gmp_dependent;
void dependentrecords_gmp_nat_init(mpz_ptr value);
void dependentrecords_gmp_nat_clear(mpz_ptr value);
struct dependentrecords_gmp_dependent {
  dependentrecords_gmp_nat bound;
  dependentrecords_gmp_nat below;
};
void dependentrecords_gmp_dependent_init(dependentrecords_gmp_dependent* value);
void dependentrecords_gmp_dependent_clear(dependentrecords_gmp_dependent* value);

dependentrecords_gmp_status dependentrecords_gmp_dependent_result(mpz_srcptr _lb_arg0, dependentrecords_gmp_dependent* out, dependentrecords_gmp_error* error);
dependentrecords_gmp_status dependentrecords_gmp_dependent_roundtrip(dependentrecords_gmp_dependent const* _lb_arg0, dependentrecords_gmp_dependent* out, dependentrecords_gmp_error* error);
dependentrecords_gmp_status dependentrecords_gmp_dependent_total(dependentrecords_gmp_dependent const* _lb_arg0, mpz_ptr out, dependentrecords_gmp_error* error);
#ifdef __cplusplus
}
#endif
