#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif
#include <dlfcn.h>
#include <link.h>

#include <errno.h>
#include <fcntl.h>
#include <stdint.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

typedef struct {
  uint32_t words[8];
  uint64_t bytes;
  size_t used;
  unsigned char block[64];
} lb_receipt_hash;

static uint32_t lb_receipt_rotr(uint32_t x, unsigned n) {
  return (x >> n) | (x << (32u - n));
}
static void lb_receipt_block(lb_receipt_hash *hash, const unsigned char *block) {
  static const uint32_t constants[64] = {
    0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
    0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
    0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
    0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
    0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
    0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
    0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
    0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2
  };
  uint32_t w[64];
  for (size_t i = 0; i < 16; ++i)
    w[i] = ((uint32_t)block[4*i] << 24) | ((uint32_t)block[4*i+1] << 16)
      | ((uint32_t)block[4*i+2] << 8) | block[4*i+3];
  for (size_t i = 16; i < 64; ++i) {
    uint32_t x = w[i-15], y = w[i-2];
    w[i] = w[i-16] + (lb_receipt_rotr(x,7) ^ lb_receipt_rotr(x,18) ^ (x >> 3))
      + w[i-7] + (lb_receipt_rotr(y,17) ^ lb_receipt_rotr(y,19) ^ (y >> 10));
  }
  uint32_t a=hash->words[0], b=hash->words[1], c=hash->words[2], d=hash->words[3];
  uint32_t e=hash->words[4], f=hash->words[5], g=hash->words[6], h=hash->words[7];
  for (size_t i = 0; i < 64; ++i) {
    uint32_t t1 = h + (lb_receipt_rotr(e,6) ^ lb_receipt_rotr(e,11) ^ lb_receipt_rotr(e,25))
      + ((e & f) ^ (~e & g)) + constants[i] + w[i];
    uint32_t t2 = (lb_receipt_rotr(a,2) ^ lb_receipt_rotr(a,13) ^ lb_receipt_rotr(a,22))
      + ((a & b) ^ (a & c) ^ (b & c));
    h=g; g=f; f=e; e=d+t1; d=c; c=b; b=a; a=t1+t2;
  }
  hash->words[0]+=a; hash->words[1]+=b; hash->words[2]+=c; hash->words[3]+=d;
  hash->words[4]+=e; hash->words[5]+=f; hash->words[6]+=g; hash->words[7]+=h;
}
static void lb_receipt_update(lb_receipt_hash *hash, const unsigned char *bytes, size_t count) {
  hash->bytes += count;
  while (count) {
    size_t take = 64 - hash->used;
    if (take > count) take = count;
    memcpy(hash->block + hash->used, bytes, take);
    hash->used += take; bytes += take; count -= take;
    if (hash->used == 64) { lb_receipt_block(hash, hash->block); hash->used = 0; }
  }
}
static void lb_receipt_finish(lb_receipt_hash *hash, char out[65]) {
  static const char hex[] = "0123456789abcdef";
  uint64_t bits = hash->bytes * UINT64_C(8);
  unsigned char padding[128] = {0x80};
  size_t count = hash->used < 56 ? 56 - hash->used : 120 - hash->used;
  for (size_t i = 0; i < 8; ++i) padding[count+i] = (unsigned char)(bits >> (56-8*i));
  lb_receipt_update(hash, padding, count + 8);
  for (size_t i = 0; i < 32; ++i) {
    unsigned byte = (hash->words[i/4] >> (24-8*(i%4))) & 255u;
    out[2*i] = hex[byte >> 4]; out[2*i+1] = hex[byte & 15];
  }
  out[64] = 0;
}
static int lb_receipt_file_matches(const char *path, uint64_t bytes, const char *expected) {
  int fd = open(path, O_RDONLY | O_CLOEXEC | O_NOFOLLOW | O_NONBLOCK);
  if (fd < 0) return 0;
  struct stat before, after;
  int valid = !fstat(fd, &before) && S_ISREG(before.st_mode) && before.st_size >= 0
    && (uint64_t)before.st_size == bytes && bytes <= UINT64_MAX/8;
  lb_receipt_hash hash = {.words = {0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,
    0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19}};
  unsigned char buffer[16384];
  while (valid) {
    ssize_t count = read(fd, buffer, sizeof(buffer));
    if (count < 0 && errno == EINTR) continue;
    if (count < 0) { valid = 0; break; }
    if (!count) break;
    if ((uint64_t)count > bytes - hash.bytes) { valid = 0; break; }
    lb_receipt_update(&hash, buffer, (size_t)count);
  }
  valid = valid && hash.bytes == bytes && !fstat(fd, &after)
    && before.st_size == after.st_size
    && before.st_mtim.tv_sec == after.st_mtim.tv_sec && before.st_mtim.tv_nsec == after.st_mtim.tv_nsec
    && before.st_ctim.tv_sec == after.st_ctim.tv_sec && before.st_ctim.tv_nsec == after.st_ctim.tv_nsec;
  if (close(fd)) valid = 0;
  char actual[65]; lb_receipt_finish(&hash, actual);
  return valid && !strcmp(actual, expected);
}


static pid_t lb_package_pid;
/* Private loader handshake, not a consumer API. Keep each host's origin local
 * even when another host exports the same handshake symbol. */
__attribute__((visibility("default"))) pid_t __lean_bridge_wit_host_process_origin_v1(void) {
  return lb_package_pid;
}
static const char *lb_package_problem = "WIT package dependencies have not been verified";
static const struct { const char *name; uint64_t bytes; const char *sha256; } lb_package_libraries[] = {
  {"libcallbacksubtypes.so", UINT64_C(51936), "823e4a3d1fe266c3b72a1bc8eeff4c0b9f88abd3853379912f631f0e056fc296"},
  {"libcomponent_730462696d8af341b48a.so", UINT64_C(109616), "839154183007ffb79cbb7071ba40955d9fb28103f2c1d778d7e5744b713275e4"},
  {"liblean_bridge_native.so", UINT64_C(21632), "459fcd2098d4b646ab6ae0f4cdccd1f222908cb162562bfc3940a533cd4e4e21"},
  {"libleanshared.so", UINT64_C(158401256), "d7768b88d8162736da4305777cd6f147676038fd885bd8a265c958b0ecea00b4"},
  {"libwasmtime.so", UINT64_C(22277728), "566e57cfeabafd6d44fab1b5e6660b4569a71aae4cff2e4d89563a424ee799f3"}
};
typedef struct { unsigned seen[5]; const char *failure; } lb_package_scan;
static int lb_package_process(struct dl_phdr_info *info, size_t size, void *data) {
  (void)size;
  lb_package_scan *scan = data;
  const char *path = info->dlpi_name;
  if (!path || !*path) return 0;
  const char *slash = strrchr(path, '/'), *name = slash ? slash+1 : path;
  const char suffix[] = "_wasmtime.so";
  size_t length = strlen(name);
  if (length <= 3 + sizeof(suffix)-1 || strncmp(name, "lib", 3)
      || strcmp(name+length-(sizeof(suffix)-1), suffix)) return 0;
  void *loaded = dlopen(path, RTLD_NOW | RTLD_NOLOAD);
  if (!loaded) { scan->failure = "Cannot inspect loaded WIT host"; return 1; }
  void *address = dlsym(loaded, "__lean_bridge_wit_host_process_origin_v1");
  Dl_info owner;
  /* dlsym also searches dependencies. Only use this library's own marker. */
  if (address && dladdr(address, &owner) && owner.dli_fbase == (void *)info->dlpi_addr) {
    pid_t (*origin)(void);
    _Static_assert(sizeof(origin) == sizeof(address), "POSIX function pointer");
    memcpy(&origin, &address, sizeof(origin));
    pid_t process = origin();
    /* A host whose constructor has not run yet has no Wasmtime state. */
    if (process && process != getpid())
      scan->failure = "WIT hosts cannot be used after fork; exec a fresh process";
  }
  dlclose(loaded);
  return scan->failure != NULL;
}
static int lb_package_library(struct dl_phdr_info *info, size_t size, void *data) {
  (void)size;
  lb_package_scan *scan = data;
  const char *path = info->dlpi_name;
  if (!path || !*path) return 0;
  const char *slash = strrchr(path, '/'), *name = slash ? slash+1 : path;
  for (size_t i = 0; i < sizeof(lb_package_libraries)/sizeof(lb_package_libraries[0]); ++i) {
    if (strcmp(name, lb_package_libraries[i].name)) continue;
    if (!lb_receipt_file_matches(path, lb_package_libraries[i].bytes, lb_package_libraries[i].sha256)) {
      scan->failure = "WIT package dependency conflict: loaded library differs from its receipt";
      return 1;
    }
    /* Resolve lazy dependency relocations before another host is loaded. */
    void *loaded = dlopen(path, RTLD_NOW | RTLD_NOLOAD);
    if (!loaded) { scan->failure = "Cannot bind verified WIT dependency"; return 1; }
    dlclose(loaded);
    scan->seen[i] = 1;
  }
  return 0;
}
__attribute__((constructor)) static void lb_package_verify(void) {
  lb_package_pid = getpid();
  lb_package_scan scan = {0};
  dl_iterate_phdr(lb_package_process, &scan);
  if (!scan.failure) dl_iterate_phdr(lb_package_library, &scan);
  for (size_t i = 0; i < sizeof(scan.seen)/sizeof(scan.seen[0]); ++i)
    if (!scan.seen[i] && !scan.failure) scan.failure = "WIT package dependency is missing from the loaded libraries";
  lb_package_problem = scan.failure;
}
static const char *lb_package_failure(void) {
  if (getpid() != lb_package_pid) return "WIT hosts cannot be used after fork; exec a fresh process";
  return lb_package_problem;
}
#include "callbacksubtypes_wasmtime.h"
#include "callbacksubtypes-graph.h"
#include "lean_bridge_native_runtime.h"
#include <pthread.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

_Static_assert(sizeof(bool) == 1, "WIT bool validation requires a one-byte representation");
typedef struct lb_allocation { struct lb_allocation *next; } lb_allocation;
typedef struct { size_t remaining; lb_allocation *allocations; unsigned failure; } lb_scope;
/* Native callers still own valid backing storage; this checks shape, alignment
 * and address arithmetic, not the allocation extent of an arbitrary pointer. */
static inline bool lb_buffer(const void *data, size_t count, size_t width, size_t alignment) {
  if (!count) return true;
  if (!data || !width || !alignment || (uintptr_t)data % alignment || count > SIZE_MAX / width) return false;
  return count * width <= UINTPTR_MAX - (uintptr_t)data;
}
static inline bool lb_boolean(const void *data, bool *out) {
  uint8_t raw; memcpy(&raw, data, sizeof(raw));
  if (raw > 1) return false;
  *out = raw != 0; return true;
}
static inline bool lb_charge(lb_scope *scope, size_t count, size_t width) {
  if (count && width > scope->remaining / count) { scope->failure = 2; return false; }
  scope->remaining -= count * width; return true;
}
static inline void *lb_alloc(lb_scope *scope, size_t count, size_t width) {
  if (!count) return NULL;
  if (width > (SIZE_MAX - sizeof(lb_allocation)) / count) { scope->failure = 2; return NULL; }
  lb_allocation *allocation = calloc(1, sizeof(*allocation) + count * width);
  if (!allocation) { scope->failure = 3; return NULL; }
  allocation->next = scope->allocations; scope->allocations = allocation;
  return allocation + 1;
}
static inline void lb_scope_close(lb_scope *scope) {
  while (scope->allocations) { lb_allocation *next = scope->allocations->next; free(scope->allocations); scope->allocations = next; }
}
static inline bool lb_name(const wasm_name_t *name, const char *expected) {
  size_t length = strlen(expected);
  return name->size == length && lb_buffer(name->data, length, 1, 1) && (!length || memcmp(name->data, expected, length) == 0);
}
static inline bool lb_utf8(const char *text, size_t length) {
  const uint8_t *p = (const uint8_t *)text;
  if (!lb_buffer(p, length, 1, 1)) return false;
  for (size_t i = 0; i < length;) {
    uint32_t c = p[i++]; size_t extra = 0; uint32_t minimum = 0;
    if (c < 0x80) continue;
    if (c >= 0xc2 && c <= 0xdf) { extra = 1; minimum = 0x80; c &= 0x1f; }
    else if (c >= 0xe0 && c <= 0xef) { extra = 2; minimum = 0x800; c &= 0x0f; }
    else if (c >= 0xf0 && c <= 0xf4) { extra = 3; minimum = 0x10000; c &= 7; }
    else return false;
    if (extra > length - i) return false;
    while (extra--) { uint8_t b = p[i++]; if ((b & 0xc0) != 0x80) return false; c = (c << 6) | (b & 0x3f); }
    if (c < minimum || c > 0x10ffff || (c >= 0xd800 && c <= 0xdfff)) return false;
  }
  return true;
}
static inline bool lb_limbs_in(const wasmtime_component_val_t *value, lb_scope *scope, uint32_t **out, size_t *length) {
  if (value->kind != WASMTIME_COMPONENT_LIST) return false;
  size_t count = value->of.list.size;
  if (!lb_buffer(value->of.list.data, count, sizeof(wasmtime_component_val_t), _Alignof(wasmtime_component_val_t)) || !lb_charge(scope, count, sizeof(wasmtime_component_val_t) + sizeof(uint32_t))) return false;
  for (size_t i = 0; i < count; ++i) if (value->of.list.data[i].kind != WASMTIME_COMPONENT_U32) return false;
  if (count && value->of.list.data[count - 1].of.u32 == 0) return false;
  if (out) {
    *out = lb_alloc(scope, count, sizeof(uint32_t)); if (count && !*out) return false;
    for (size_t i = 0; i < count; ++i) (*out)[i] = value->of.list.data[i].of.u32;
    *length = count;
  }
  return true;
}
static inline bool lb_limbs_out(const uint32_t *data, size_t length, lb_scope *scope, wasmtime_component_val_t *out) {
  if (!lb_buffer(data, length, sizeof(uint32_t), _Alignof(uint32_t)) || !lb_charge(scope, length, sizeof(wasmtime_component_val_t))) return false;
  if (length && (!data || !data[length - 1])) return false;
  out->kind = WASMTIME_COMPONENT_LIST;
  wasmtime_component_vallist_new_uninit(&out->of.list, length);
  for (size_t i = 0; i < length; ++i) out->of.list.data[i] = (wasmtime_component_val_t){.kind = WASMTIME_COMPONENT_U32, .of.u32 = data[i]};
  return true;
}
static inline bool lb_in_3(const wasmtime_component_val_t *value, lb_scope *scope, callbacksubtypes_scalar_nat_t *out) {
  (void)out;
  if (!lb_buffer(value, 1, sizeof(*value), _Alignof(wasmtime_component_val_t)) || (out && !lb_buffer(out, 1, sizeof(*out), _Alignof(callbacksubtypes_scalar_nat_t))) || !lb_charge(scope, 1, sizeof(wasmtime_component_val_t))) return false;
  uint32_t *limbs = NULL; size_t length = 0;
  if (!lb_limbs_in(value, scope, out ? &limbs : NULL, &length)) return false;
  if (out) *out = (callbacksubtypes_scalar_nat_t){.data = limbs, .length = length};
  return true;
}
static inline bool lb_out_3(const callbacksubtypes_scalar_nat_t *value, lb_scope *scope, wasmtime_component_val_t *out) {
  (void)value;
  if (!lb_buffer(value, 1, sizeof(*value), _Alignof(callbacksubtypes_scalar_nat_t)) || !lb_buffer(out, 1, sizeof(*out), _Alignof(wasmtime_component_val_t)) || !lb_charge(scope, 1, sizeof(wasmtime_component_val_t))) return false;
  return lb_limbs_out(value->data, value->length, scope, out);
  return true;
}

static inline bool lb_in_5(const wasmtime_component_val_t *value, lb_scope *scope, uint8_t *out) {
  (void)out;
  if (!lb_buffer(value, 1, sizeof(*value), _Alignof(wasmtime_component_val_t)) || (out && !lb_buffer(out, 1, sizeof(*out), _Alignof(uint8_t))) || !lb_charge(scope, 1, sizeof(wasmtime_component_val_t))) return false;
  if (value->kind != WASMTIME_COMPONENT_ENUM || !lb_name(&value->of.enumeration, "unit")) return false;
  if (out) *out = 0;
  return true;
}
static inline bool lb_out_5(const uint8_t *value, lb_scope *scope, wasmtime_component_val_t *out) {
  (void)value;
  if (!lb_buffer(value, 1, sizeof(*value), _Alignof(uint8_t)) || !lb_buffer(out, 1, sizeof(*out), _Alignof(wasmtime_component_val_t)) || !lb_charge(scope, 1, sizeof(wasmtime_component_val_t))) return false;
  if (*value) return false;
  out->kind = WASMTIME_COMPONENT_ENUM; wasm_name_new(&out->of.enumeration, 4, "unit");
  return true;
}
static inline bool lb_in_4(const wasmtime_component_val_t *value, lb_scope *scope, callbacksubtypes_scalar_string_t *out) {
  if (!lb_buffer(value, 1, sizeof(*value), _Alignof(wasmtime_component_val_t)) || value->kind != WASMTIME_COMPONENT_STRING || !lb_charge(scope, 1, sizeof(*value)) || !lb_charge(scope, value->of.string.size, 2) || !lb_utf8(value->of.string.data, value->of.string.size)) return false;
  if (out) {
    char *text = lb_alloc(scope, value->of.string.size, 1);
    if (value->of.string.size && !text) return false;
    if (value->of.string.size) memcpy(text, value->of.string.data, value->of.string.size);
    *out = (callbacksubtypes_scalar_string_t){.data = text, .length = value->of.string.size};
  }
  return true;
}
static inline bool lb_out_4(const callbacksubtypes_scalar_string_t *value, lb_scope *scope, wasmtime_component_val_t *out) {
  if (!lb_buffer(value, 1, sizeof(*value), _Alignof(callbacksubtypes_scalar_string_t)) || !lb_charge(scope, 1, sizeof(*out)) || !lb_charge(scope, value->length, 1) || !lb_utf8(value->data, value->length)) return false;
  out->kind = WASMTIME_COMPONENT_STRING; wasm_name_new(&out->of.string, value->length, value->data); return true;
}

#define LB_GRAPH_TABLES 3
#define LB_GRAPH_DEPTH 128
#define LB_GRAPH_NODES 262144
#define LB_GRAPH_BYTES 16777216
typedef struct { lb_scope memory; size_t nodes; } lb_graph_scope;
typedef struct { size_t type; uint32_t index; const void *address; } lb_graph_path;
typedef struct {
  lb_graph_scope *scope;
  const wasmtime_component_vallist_t *tables[LB_GRAPH_TABLES];
  size_t offsets[LB_GRAPH_TABLES], total, visited, active;
  uint8_t *seen;
  lb_graph_path path[LB_GRAPH_DEPTH + 1];
} lb_graph_input;
typedef struct lb_graph_row {
  struct lb_graph_row *next;
  wasmtime_component_val_t value;
} lb_graph_row;
typedef struct { lb_graph_row *head, *tail; uint32_t count; } lb_graph_table;
typedef struct {
  lb_graph_scope *scope;
  lb_graph_table tables[LB_GRAPH_TABLES];
  size_t active;
  lb_graph_path path[LB_GRAPH_DEPTH + 1];
} lb_graph_output;
static inline bool lb_graph_visit(lb_graph_scope *scope, unsigned depth, size_t bytes) {
  if (depth > LB_GRAPH_DEPTH || !scope->nodes) { scope->memory.failure = 2; return false; }
  if (!lb_charge(&scope->memory, 1, bytes)) return false;
  --scope->nodes; return true;
}
static inline bool lb_graph_count(lb_graph_scope *scope, size_t count) {
  if (count > scope->nodes) { scope->memory.failure = 2; return false; }
  return true;
}
static inline void lb_graph_release(void *owner) {
  lb_scope memory = {.allocations = owner}; lb_scope_close(&memory);
}
static inline bool lb_graph_record_in(const wasmtime_component_val_t *value, size_t count, lb_graph_scope *scope) {
  return lb_buffer(value, 1, sizeof(*value), _Alignof(wasmtime_component_val_t)) && value->kind == WASMTIME_COMPONENT_RECORD && value->of.record.size == count
    && lb_buffer(value->of.record.data, count, sizeof(*value->of.record.data), _Alignof(wasmtime_component_valrecord_entry_t))
    && lb_charge(&scope->memory, count, sizeof(*value->of.record.data));
}
static inline bool lb_graph_index(const wasmtime_component_val_t *value, lb_graph_scope *scope, uint32_t *out) {
  if (!lb_graph_record_in(value, 1, scope) || !lb_name(&value->of.record.data[0].name, "index") || value->of.record.data[0].val.kind != WASMTIME_COMPONENT_U32) return false;
  *out = value->of.record.data[0].val.of.u32; return true;
}
static inline lb_graph_input *lb_graph_open(const wasmtime_component_val_t *value, lb_graph_scope *scope) {
  if (!lb_graph_record_in(value, 2, scope) || !lb_name(&value->of.record.data[0].name, "root") || !lb_name(&value->of.record.data[1].name, "nodes")) return NULL;
  const wasmtime_component_val_t *arena = &value->of.record.data[1].val;
  if (!lb_graph_record_in(arena, 3, scope) || !lb_charge(&scope->memory, 1, sizeof(lb_graph_input))) return NULL;
  lb_graph_input *context = lb_alloc(&scope->memory, 1, sizeof(*context));
  if (!context) return NULL;
  context->scope = scope;
  {
    const wasmtime_component_valrecord_entry_t *field = &arena->of.record.data[0];
    if (!lb_name(&field->name, "nodes0") || field->val.kind != WASMTIME_COMPONENT_LIST) return NULL;
    const wasmtime_component_vallist_t *table = &field->val.of.list;
    if (table->size > LB_GRAPH_NODES - context->total) { scope->memory.failure = 2; return NULL; }
    if (!lb_buffer(table->data, table->size, sizeof(*table->data), _Alignof(wasmtime_component_val_t)) || !lb_charge(&scope->memory, table->size, sizeof(*table->data) + 1)) return NULL;
    context->tables[0] = table; context->offsets[0] = context->total; context->total += table->size;
  }
  {
    const wasmtime_component_valrecord_entry_t *field = &arena->of.record.data[1];
    if (!lb_name(&field->name, "nodes1") || field->val.kind != WASMTIME_COMPONENT_LIST) return NULL;
    const wasmtime_component_vallist_t *table = &field->val.of.list;
    if (table->size > LB_GRAPH_NODES - context->total) { scope->memory.failure = 2; return NULL; }
    if (!lb_buffer(table->data, table->size, sizeof(*table->data), _Alignof(wasmtime_component_val_t)) || !lb_charge(&scope->memory, table->size, sizeof(*table->data) + 1)) return NULL;
    context->tables[1] = table; context->offsets[1] = context->total; context->total += table->size;
  }
  {
    const wasmtime_component_valrecord_entry_t *field = &arena->of.record.data[2];
    if (!lb_name(&field->name, "nodes2") || field->val.kind != WASMTIME_COMPONENT_LIST) return NULL;
    const wasmtime_component_vallist_t *table = &field->val.of.list;
    if (table->size > LB_GRAPH_NODES - context->total) { scope->memory.failure = 2; return NULL; }
    if (!lb_buffer(table->data, table->size, sizeof(*table->data), _Alignof(wasmtime_component_val_t)) || !lb_charge(&scope->memory, table->size, sizeof(*table->data) + 1)) return NULL;
    context->tables[2] = table; context->offsets[2] = context->total; context->total += table->size;
  }
  context->seen = lb_alloc(&scope->memory, context->total, 1);
  if (context->total && !context->seen) return NULL;
  return context;
}
static inline const wasmtime_component_val_t *lb_graph_dereference(lb_graph_input *context, size_t type, const wasmtime_component_val_t *reference) {
  uint32_t index;
  if (context->active > LB_GRAPH_DEPTH) { context->scope->memory.failure = 2; return NULL; }
  if (!lb_graph_index(reference, context->scope, &index) || index >= context->tables[type]->size) return NULL;
  for (size_t i = 0; i < context->active; ++i) if (context->path[i].type == type && context->path[i].index == index) return NULL;
  context->path[context->active++] = (lb_graph_path){.type = type, .index = index};
  size_t position = context->offsets[type] + index;
  if (!context->seen[position]) { context->seen[position] = 1; ++context->visited; }
  return &context->tables[type]->data[index];
}
static inline bool lb_graph_record_out(wasmtime_component_val_t *out, size_t count, lb_graph_scope *scope) {
  if (!lb_charge(&scope->memory, count, sizeof(wasmtime_component_valrecord_entry_t))) return false;
  out->kind = WASMTIME_COMPONENT_RECORD;
  wasmtime_component_valrecord_new_uninit(&out->of.record, count);
  if (count) memset(out->of.record.data, 0, count * sizeof(*out->of.record.data));
  return true;
}
static inline bool lb_graph_field_out(wasmtime_component_valrecord_entry_t *field, const char *name, lb_graph_scope *scope) {
  size_t length = strlen(name);
  if (!lb_charge(&scope->memory, length, 1)) return false;
  wasm_name_new(&field->name, length, name); return true;
}
static inline wasmtime_component_val_t *lb_graph_append(lb_graph_output *context, size_t type, const void *address, wasmtime_component_val_t *reference) {
  if (context->active > LB_GRAPH_DEPTH) { context->scope->memory.failure = 2; return NULL; }
  for (size_t i = 0; i < context->active; ++i) if (context->path[i].type == type && context->path[i].address == address) return NULL;
  lb_graph_table *table = &context->tables[type];
  if (table->count >= LB_GRAPH_NODES) { context->scope->memory.failure = 2; return NULL; }
  if (!lb_charge(&context->scope->memory, 1, sizeof(lb_graph_row))) return NULL;
  lb_graph_row *row = lb_alloc(&context->scope->memory, 1, sizeof(*row));
  if (!row) return NULL;
  if (table->tail) table->tail->next = row; else table->head = row;
  table->tail = row;
  if (!lb_graph_record_out(reference, 1, context->scope) || !lb_graph_field_out(&reference->of.record.data[0], "index", context->scope)) return NULL;
  reference->of.record.data[0].val = (wasmtime_component_val_t){.kind = WASMTIME_COMPONENT_U32, .of.u32 = table->count++};
  context->path[context->active++] = (lb_graph_path){.type = type, .address = address};
  return &row->value;
}
static inline void lb_graph_output_close(lb_graph_output *context) {
  for (size_t i = 0; i < 3; ++i) for (lb_graph_row *row = context->tables[i].head; row; row = row->next) wasmtime_component_val_delete(&row->value);
}
static inline bool lb_graph_finish(lb_graph_output *context, wasmtime_component_val_t *arena) {
  if (!lb_graph_record_out(arena, 3, context->scope)) return false;
  {
    wasmtime_component_valrecord_entry_t *field = &arena->of.record.data[0];
    lb_graph_table *table = &context->tables[0];
    if (!lb_graph_field_out(field, "nodes0", context->scope) || !lb_charge(&context->scope->memory, table->count, sizeof(wasmtime_component_val_t))) return false;
    field->val.kind = WASMTIME_COMPONENT_LIST;
    wasmtime_component_vallist_new_uninit(&field->val.of.list, table->count);
    size_t offset = 0;
    for (lb_graph_row *row = table->head; row; row = row->next) { field->val.of.list.data[offset++] = row->value; row->value = (wasmtime_component_val_t){0}; }
  }
  {
    wasmtime_component_valrecord_entry_t *field = &arena->of.record.data[1];
    lb_graph_table *table = &context->tables[1];
    if (!lb_graph_field_out(field, "nodes1", context->scope) || !lb_charge(&context->scope->memory, table->count, sizeof(wasmtime_component_val_t))) return false;
    field->val.kind = WASMTIME_COMPONENT_LIST;
    wasmtime_component_vallist_new_uninit(&field->val.of.list, table->count);
    size_t offset = 0;
    for (lb_graph_row *row = table->head; row; row = row->next) { field->val.of.list.data[offset++] = row->value; row->value = (wasmtime_component_val_t){0}; }
  }
  {
    wasmtime_component_valrecord_entry_t *field = &arena->of.record.data[2];
    lb_graph_table *table = &context->tables[2];
    if (!lb_graph_field_out(field, "nodes2", context->scope) || !lb_charge(&context->scope->memory, table->count, sizeof(wasmtime_component_val_t))) return false;
    field->val.kind = WASMTIME_COMPONENT_LIST;
    wasmtime_component_vallist_new_uninit(&field->val.of.list, table->count);
    size_t offset = 0;
    for (lb_graph_row *row = table->head; row; row = row->next) { field->val.of.list.data[offset++] = row->value; row->value = (wasmtime_component_val_t){0}; }
  }
  return true;
}
static inline bool lb_graph_read_0(const wasmtime_component_val_t *, lb_graph_input *, unsigned, callbacksubtypes_graph_743764d1b67e81fcae92_t *);
static inline bool lb_graph_write_0(const callbacksubtypes_graph_743764d1b67e81fcae92_t *, lb_graph_output *, unsigned, wasmtime_component_val_t *);
static inline bool lb_graph_read_1(const wasmtime_component_val_t *, lb_graph_input *, unsigned, callbacksubtypes_graph_2c6f4131c8731fa67588_t *);
static inline bool lb_graph_write_1(const callbacksubtypes_graph_2c6f4131c8731fa67588_t *, lb_graph_output *, unsigned, wasmtime_component_val_t *);
static inline bool lb_graph_read_2(const wasmtime_component_val_t *, lb_graph_input *, unsigned, callbacksubtypes_graph_6c9c0cf3d3abf9adeb4b_t *);
static inline bool lb_graph_write_2(const callbacksubtypes_graph_6c9c0cf3d3abf9adeb4b_t *, lb_graph_output *, unsigned, wasmtime_component_val_t *);
static inline bool lb_graph_read_3(const wasmtime_component_val_t *, lb_graph_input *, unsigned, callbacksubtypes_scalar_nat_t *);
static inline bool lb_graph_write_3(const callbacksubtypes_scalar_nat_t *, lb_graph_output *, unsigned, wasmtime_component_val_t *);
static inline bool lb_graph_read_4(const wasmtime_component_val_t *, lb_graph_input *, unsigned, callbacksubtypes_scalar_string_t *);
static inline bool lb_graph_write_4(const callbacksubtypes_scalar_string_t *, lb_graph_output *, unsigned, wasmtime_component_val_t *);
static inline bool lb_graph_read_5(const wasmtime_component_val_t *, lb_graph_input *, unsigned, uint8_t *);
static inline bool lb_graph_write_5(const uint8_t *, lb_graph_output *, unsigned, wasmtime_component_val_t *);
static inline bool lb_graph_read_0(const wasmtime_component_val_t *value, lb_graph_input *context, unsigned depth, callbacksubtypes_graph_743764d1b67e81fcae92_t *out) {
  (void)out;
  if (!lb_graph_visit(context->scope, depth, sizeof(callbacksubtypes_graph_743764d1b67e81fcae92_t) + sizeof(wasmtime_component_val_t)) || !lb_buffer(value, 1, sizeof(*value), _Alignof(wasmtime_component_val_t))) return false;
  value = lb_graph_dereference(context, 0, value);
  if (!value) return false;
  if (value->kind != WASMTIME_COMPONENT_OPTION) return false;
  bool present = value->of.option != NULL;
  if (out) out->has_value = present;
  if (present) {
  if (!lb_graph_read_3(value->of.option, context, depth + 1, out ? &out->value : NULL)) return false;
  }
  --context->active;
  return true;
}
static inline bool lb_graph_write_0(const callbacksubtypes_graph_743764d1b67e81fcae92_t *value, lb_graph_output *context, unsigned depth, wasmtime_component_val_t *out) {
  if (!lb_graph_visit(context->scope, depth, sizeof(wasmtime_component_val_t)) || !lb_buffer(value, 1, sizeof(*value), _Alignof(callbacksubtypes_graph_743764d1b67e81fcae92_t))) return false;
  out = lb_graph_append(context, 0, value, out);
  if (!out) return false;
  if (value->has_value > 1) return false;
  out->kind = WASMTIME_COMPONENT_OPTION;
  out->of.option = NULL;
  if (value->has_value) {
  if (!lb_charge(&context->scope->memory, 1, sizeof(wasmtime_component_val_t))) return false;
  wasmtime_component_val_t empty = {0}; out->of.option = wasmtime_component_val_new(&empty);
  if (!lb_graph_write_3(&value->value, context, depth + 1, out->of.option)) return false;
  }
  --context->active;
  return true;
}

static inline bool lb_graph_read_1(const wasmtime_component_val_t *value, lb_graph_input *context, unsigned depth, callbacksubtypes_graph_2c6f4131c8731fa67588_t *out) {
  (void)out;
  if (!lb_graph_visit(context->scope, depth, sizeof(callbacksubtypes_graph_2c6f4131c8731fa67588_t) + sizeof(wasmtime_component_val_t)) || !lb_buffer(value, 1, sizeof(*value), _Alignof(wasmtime_component_val_t))) return false;
  value = lb_graph_dereference(context, 1, value);
  if (!value) return false;
  if (value->kind != WASMTIME_COMPONENT_RESULT) return false;
  bool present; if (!value->of.result.val || !lb_boolean(&value->of.result.is_ok, &present)) return false;
  if (out) out->is_ok = present;
  if (present) {
  if (!lb_graph_read_0(value->of.result.val, context, depth + 1, out ? &out->ok : NULL)) return false;
  }
  else if (!present) {
  if (!lb_graph_read_4(value->of.result.val, context, depth + 1, out ? &out->error : NULL)) return false;
  }
  --context->active;
  return true;
}
static inline bool lb_graph_write_1(const callbacksubtypes_graph_2c6f4131c8731fa67588_t *value, lb_graph_output *context, unsigned depth, wasmtime_component_val_t *out) {
  if (!lb_graph_visit(context->scope, depth, sizeof(wasmtime_component_val_t)) || !lb_buffer(value, 1, sizeof(*value), _Alignof(callbacksubtypes_graph_2c6f4131c8731fa67588_t))) return false;
  out = lb_graph_append(context, 1, value, out);
  if (!out) return false;
  if (value->is_ok > 1) return false;
  out->kind = WASMTIME_COMPONENT_RESULT;
  out->of.result.is_ok = value->is_ok;
  if (!lb_charge(&context->scope->memory, 1, sizeof(wasmtime_component_val_t))) return false;
  wasmtime_component_val_t empty = {0}; out->of.result.val = wasmtime_component_val_new(&empty);
  if (value->is_ok) {
  if (!lb_graph_write_0(&value->ok, context, depth + 1, out->of.result.val)) return false;
  }
  else if (!value->is_ok) {
  if (!lb_graph_write_4(&value->error, context, depth + 1, out->of.result.val)) return false;
  }
  --context->active;
  return true;
}

static inline bool lb_graph_read_2(const wasmtime_component_val_t *value, lb_graph_input *context, unsigned depth, callbacksubtypes_graph_6c9c0cf3d3abf9adeb4b_t *out) {
  (void)out;
  if (!lb_graph_visit(context->scope, depth, sizeof(callbacksubtypes_graph_6c9c0cf3d3abf9adeb4b_t) + sizeof(wasmtime_component_val_t)) || !lb_buffer(value, 1, sizeof(*value), _Alignof(wasmtime_component_val_t))) return false;
  value = lb_graph_dereference(context, 2, value);
  if (!value) return false;
  if (value->kind != WASMTIME_COMPONENT_LIST) return false;
  size_t count = value->of.list.size;
  if (!lb_graph_count(context->scope, count) || !lb_buffer(value->of.list.data, count, sizeof(wasmtime_component_val_t), _Alignof(wasmtime_component_val_t)) || !lb_charge(&context->scope->memory, count, sizeof(callbacksubtypes_graph_743764d1b67e81fcae92_t) + sizeof(wasmtime_component_val_t))) return false;
  callbacksubtypes_graph_743764d1b67e81fcae92_t *items = out ? lb_alloc(&context->scope->memory, count, sizeof(callbacksubtypes_graph_743764d1b67e81fcae92_t)) : NULL;
  if (out && count && !items) return false;
  if (out) { out->data = items; out->length = count; }
  for (size_t i = 0; i < count; ++i) if (!lb_graph_read_0(&value->of.list.data[i], context, depth + 1, out ? &items[i] : NULL)) return false;
  --context->active;
  return true;
}
static inline bool lb_graph_write_2(const callbacksubtypes_graph_6c9c0cf3d3abf9adeb4b_t *value, lb_graph_output *context, unsigned depth, wasmtime_component_val_t *out) {
  if (!lb_graph_visit(context->scope, depth, sizeof(wasmtime_component_val_t)) || !lb_buffer(value, 1, sizeof(*value), _Alignof(callbacksubtypes_graph_6c9c0cf3d3abf9adeb4b_t))) return false;
  out = lb_graph_append(context, 2, value, out);
  if (!out) return false;
  if (!lb_graph_count(context->scope, value->length) || !lb_buffer(value->data, value->length, sizeof(callbacksubtypes_graph_743764d1b67e81fcae92_t), _Alignof(callbacksubtypes_graph_743764d1b67e81fcae92_t)) || !lb_charge(&context->scope->memory, value->length, sizeof(wasmtime_component_val_t))) return false;
  out->kind = WASMTIME_COMPONENT_LIST;
  wasmtime_component_vallist_new_uninit(&out->of.list, value->length);
  if (value->length) memset(out->of.list.data, 0, value->length * sizeof(*out->of.list.data));
  for (size_t i = 0; i < value->length; ++i) if (!lb_graph_write_0(&value->data[i], context, depth + 1, &out->of.list.data[i])) return false;
  --context->active;
  return true;
}

static inline bool lb_graph_read_3(const wasmtime_component_val_t *value, lb_graph_input *context, unsigned depth, callbacksubtypes_scalar_nat_t *out) {
  (void)out;
  if (!lb_graph_visit(context->scope, depth, sizeof(callbacksubtypes_scalar_nat_t) + sizeof(wasmtime_component_val_t)) || !lb_buffer(value, 1, sizeof(*value), _Alignof(wasmtime_component_val_t))) return false;
  return lb_in_3(value, &context->scope->memory, out);
}
static inline bool lb_graph_write_3(const callbacksubtypes_scalar_nat_t *value, lb_graph_output *context, unsigned depth, wasmtime_component_val_t *out) {
  if (!lb_graph_visit(context->scope, depth, sizeof(wasmtime_component_val_t)) || !lb_buffer(value, 1, sizeof(*value), _Alignof(callbacksubtypes_scalar_nat_t))) return false;
  return lb_out_3(value, &context->scope->memory, out);
}

static inline bool lb_graph_read_4(const wasmtime_component_val_t *value, lb_graph_input *context, unsigned depth, callbacksubtypes_scalar_string_t *out) {
  (void)out;
  if (!lb_graph_visit(context->scope, depth, sizeof(callbacksubtypes_scalar_string_t) + sizeof(wasmtime_component_val_t)) || !lb_buffer(value, 1, sizeof(*value), _Alignof(wasmtime_component_val_t))) return false;
  return lb_in_4(value, &context->scope->memory, out);
}
static inline bool lb_graph_write_4(const callbacksubtypes_scalar_string_t *value, lb_graph_output *context, unsigned depth, wasmtime_component_val_t *out) {
  if (!lb_graph_visit(context->scope, depth, sizeof(wasmtime_component_val_t)) || !lb_buffer(value, 1, sizeof(*value), _Alignof(callbacksubtypes_scalar_string_t))) return false;
  return lb_out_4(value, &context->scope->memory, out);
}

static inline bool lb_graph_read_5(const wasmtime_component_val_t *value, lb_graph_input *context, unsigned depth, uint8_t *out) {
  (void)out;
  if (!lb_graph_visit(context->scope, depth, sizeof(uint8_t) + sizeof(wasmtime_component_val_t)) || !lb_buffer(value, 1, sizeof(*value), _Alignof(wasmtime_component_val_t))) return false;
  return lb_in_5(value, &context->scope->memory, out);
}
static inline bool lb_graph_write_5(const uint8_t *value, lb_graph_output *context, unsigned depth, wasmtime_component_val_t *out) {
  if (!lb_graph_visit(context->scope, depth, sizeof(wasmtime_component_val_t)) || !lb_buffer(value, 1, sizeof(*value), _Alignof(uint8_t))) return false;
  return lb_out_5(value, &context->scope->memory, out);
}
static inline bool lb_graph_decode_0(const wasmtime_component_val_t *value, lb_graph_scope *scope, callbacksubtypes_graph_743764d1b67e81fcae92_t *out) {
  if (out && !lb_buffer(out, 1, sizeof(*out), _Alignof(callbacksubtypes_graph_743764d1b67e81fcae92_t))) return false;
  callbacksubtypes_graph_743764d1b67e81fcae92_t converted = {0};
  lb_graph_input *context = lb_graph_open(value, scope);
  if (!context || !lb_graph_read_0(&value->of.record.data[0].val, context, 0, out ? &converted : NULL) || context->visited != context->total) return false;
  if (out) *out = converted;
  return true;
}
static inline bool lb_graph_encode_0(const callbacksubtypes_graph_743764d1b67e81fcae92_t *value, lb_graph_scope *scope, wasmtime_component_val_t *out) {
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(wasmtime_component_val_t))) return false;
  wasmtime_component_val_t converted = {0};
  if (!lb_charge(&scope->memory, 1, sizeof(lb_graph_output))) return false;
  lb_graph_output *context = lb_alloc(&scope->memory, 1, sizeof(*context));
  if (!context) return false;
  context->scope = scope;
  bool valid = lb_graph_record_out(&converted, 2, scope)
    && lb_graph_field_out(&converted.of.record.data[0], "root", scope)
    && lb_graph_field_out(&converted.of.record.data[1], "nodes", scope)
    && lb_graph_write_0(value, context, 0, &converted.of.record.data[0].val)
    && lb_graph_finish(context, &converted.of.record.data[1].val);
  lb_graph_output_close(context);
  if (valid) *out = converted; else wasmtime_component_val_delete(&converted);
  return valid;
}


static inline bool lb_graph_decode_1(const wasmtime_component_val_t *value, lb_graph_scope *scope, callbacksubtypes_graph_2c6f4131c8731fa67588_t *out) {
  if (out && !lb_buffer(out, 1, sizeof(*out), _Alignof(callbacksubtypes_graph_2c6f4131c8731fa67588_t))) return false;
  callbacksubtypes_graph_2c6f4131c8731fa67588_t converted = {0};
  lb_graph_input *context = lb_graph_open(value, scope);
  if (!context || !lb_graph_read_1(&value->of.record.data[0].val, context, 0, out ? &converted : NULL) || context->visited != context->total) return false;
  if (out) *out = converted;
  return true;
}
static inline bool lb_graph_encode_1(const callbacksubtypes_graph_2c6f4131c8731fa67588_t *value, lb_graph_scope *scope, wasmtime_component_val_t *out) {
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(wasmtime_component_val_t))) return false;
  wasmtime_component_val_t converted = {0};
  if (!lb_charge(&scope->memory, 1, sizeof(lb_graph_output))) return false;
  lb_graph_output *context = lb_alloc(&scope->memory, 1, sizeof(*context));
  if (!context) return false;
  context->scope = scope;
  bool valid = lb_graph_record_out(&converted, 2, scope)
    && lb_graph_field_out(&converted.of.record.data[0], "root", scope)
    && lb_graph_field_out(&converted.of.record.data[1], "nodes", scope)
    && lb_graph_write_1(value, context, 0, &converted.of.record.data[0].val)
    && lb_graph_finish(context, &converted.of.record.data[1].val);
  lb_graph_output_close(context);
  if (valid) *out = converted; else wasmtime_component_val_delete(&converted);
  return valid;
}


static inline bool lb_graph_decode_2(const wasmtime_component_val_t *value, lb_graph_scope *scope, callbacksubtypes_graph_6c9c0cf3d3abf9adeb4b_t *out) {
  if (out && !lb_buffer(out, 1, sizeof(*out), _Alignof(callbacksubtypes_graph_6c9c0cf3d3abf9adeb4b_t))) return false;
  callbacksubtypes_graph_6c9c0cf3d3abf9adeb4b_t converted = {0};
  lb_graph_input *context = lb_graph_open(value, scope);
  if (!context || !lb_graph_read_2(&value->of.record.data[0].val, context, 0, out ? &converted : NULL) || context->visited != context->total) return false;
  if (out) *out = converted;
  return true;
}
static inline bool lb_graph_encode_2(const callbacksubtypes_graph_6c9c0cf3d3abf9adeb4b_t *value, lb_graph_scope *scope, wasmtime_component_val_t *out) {
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(wasmtime_component_val_t))) return false;
  wasmtime_component_val_t converted = {0};
  if (!lb_charge(&scope->memory, 1, sizeof(lb_graph_output))) return false;
  lb_graph_output *context = lb_alloc(&scope->memory, 1, sizeof(*context));
  if (!context) return false;
  context->scope = scope;
  bool valid = lb_graph_record_out(&converted, 2, scope)
    && lb_graph_field_out(&converted.of.record.data[0], "root", scope)
    && lb_graph_field_out(&converted.of.record.data[1], "nodes", scope)
    && lb_graph_write_2(value, context, 0, &converted.of.record.data[0].val)
    && lb_graph_finish(context, &converted.of.record.data[1].val);
  lb_graph_output_close(context);
  if (valid) *out = converted; else wasmtime_component_val_delete(&converted);
  return valid;
}


static inline bool lb_graph_decode_3(const wasmtime_component_val_t *value, lb_graph_scope *scope, callbacksubtypes_scalar_nat_t *out) {
  if (out && !lb_buffer(out, 1, sizeof(*out), _Alignof(callbacksubtypes_scalar_nat_t))) return false;
  callbacksubtypes_scalar_nat_t converted = {0};
  lb_graph_input context = {.scope = scope};
  if (!lb_graph_read_3(value, &context, 0, out ? &converted : NULL)) return false;
  if (out) *out = converted;
  return true;
}
static inline bool lb_graph_encode_3(const callbacksubtypes_scalar_nat_t *value, lb_graph_scope *scope, wasmtime_component_val_t *out) {
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(wasmtime_component_val_t))) return false;
  wasmtime_component_val_t converted = {0};
  lb_graph_output context = {.scope = scope};
  bool valid = lb_graph_write_3(value, &context, 0, &converted);
  if (valid) *out = converted; else wasmtime_component_val_delete(&converted);
  return valid;
}


static inline bool lb_graph_decode_4(const wasmtime_component_val_t *value, lb_graph_scope *scope, callbacksubtypes_scalar_string_t *out) {
  if (out && !lb_buffer(out, 1, sizeof(*out), _Alignof(callbacksubtypes_scalar_string_t))) return false;
  callbacksubtypes_scalar_string_t converted = {0};
  lb_graph_input context = {.scope = scope};
  if (!lb_graph_read_4(value, &context, 0, out ? &converted : NULL)) return false;
  if (out) *out = converted;
  return true;
}
static inline bool lb_graph_encode_4(const callbacksubtypes_scalar_string_t *value, lb_graph_scope *scope, wasmtime_component_val_t *out) {
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(wasmtime_component_val_t))) return false;
  wasmtime_component_val_t converted = {0};
  lb_graph_output context = {.scope = scope};
  bool valid = lb_graph_write_4(value, &context, 0, &converted);
  if (valid) *out = converted; else wasmtime_component_val_delete(&converted);
  return valid;
}


static inline bool lb_graph_decode_5(const wasmtime_component_val_t *value, lb_graph_scope *scope, uint8_t *out) {
  if (out && !lb_buffer(out, 1, sizeof(*out), _Alignof(uint8_t))) return false;
  uint8_t converted = {0};
  lb_graph_input context = {.scope = scope};
  if (!lb_graph_read_5(value, &context, 0, out ? &converted : NULL)) return false;
  if (out) *out = converted;
  return true;
}
static inline bool lb_graph_encode_5(const uint8_t *value, lb_graph_scope *scope, wasmtime_component_val_t *out) {
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(wasmtime_component_val_t))) return false;
  wasmtime_component_val_t converted = {0};
  lb_graph_output context = {.scope = scope};
  bool valid = lb_graph_write_5(value, &context, 0, &converted);
  if (valid) *out = converted; else wasmtime_component_val_delete(&converted);
  return valid;
}


#define LB_CAPACITY 1024
#define LB_BUDGET (16u * 1024u * 1024u)
#define LB_MAX_ARGS 3
typedef struct lb_entry lb_entry;
typedef struct lb_frame { struct lb_frame *previous, *thread_previous; callbacksubtypes_wasmtime *session; lb_entry *pending; } lb_frame;
static _Thread_local lb_frame *lb_active_frame;
static _Thread_local uint64_t lb_thread_serial;
static uint64_t lb_thread_counter;
static pthread_mutex_t lb_thread_mutex = PTHREAD_MUTEX_INITIALIZER;
static uint64_t lb_thread_identity(void) {
  if (!lb_thread_serial) {
    pthread_mutex_lock(&lb_thread_mutex);
    if (lb_thread_counter != UINT64_MAX) lb_thread_serial = ++lb_thread_counter;
    pthread_mutex_unlock(&lb_thread_mutex);
  }
  return lb_thread_serial;
}
struct lb_entry {
  uint64_t token;
  uint32_t tag;
  unsigned active;
  bool closed;
  callbacksubtypes_wasmtime *session;
  callbacksubtypes_wasmtime_callback callback;
  void *data, *owned, *recovery;
  void (*release)(void *);
};
struct callbacksubtypes_wasmtime {
  wasm_engine_t *engine;
  wasmtime_component_t *component;
  wasmtime_store_t *store;
  wasmtime_component_linker_t *linker;
  wasmtime_component_instance_t instance;
  pthread_t thread;
  uint64_t thread_serial;
  pid_t process;
  unsigned depth, finalizing;
  bool poisoned, closing;
  char first_error[1024];
  lb_frame *frame;
  lb_entry entries[LB_CAPACITY];
};
static const char lb_identity_kind[] = "callbacksubtypes:wit-callable";
static bool lb_thread(callbacksubtypes_wasmtime *session) {
  return session && session->process == getpid() && session->thread_serial == lb_thread_identity() && pthread_equal(session->thread, pthread_self()) && !session->finalizing;
}
static void lb_record_text(callbacksubtypes_wasmtime *session, const char *text, size_t length) {
  if (!session->poisoned) {
    if (length >= sizeof(session->first_error)) length = sizeof(session->first_error) - 1;
    memcpy(session->first_error, text, length); session->first_error[length] = 0;
  }
  session->poisoned = true;
}
static void lb_record_error(callbacksubtypes_wasmtime *session, wasmtime_error_t *error) {
  if (session->poisoned) return;
  wasm_name_t message; wasmtime_error_message(error, &message);
  lb_record_text(session, message.data, message.size); wasm_name_delete(&message);
}
static lb_entry *lb_entry_find(callbacksubtypes_wasmtime *session, uint64_t token) {
  for (size_t i = 0; token && i < LB_CAPACITY; ++i)
    if (session->entries[i].token == token && !session->entries[i].closed) return &session->entries[i];
  return NULL;
}
static lb_entry *lb_entry_new(callbacksubtypes_wasmtime *session, uint32_t tag) {
  for (size_t i = 0; i < LB_CAPACITY; ++i) {
    lb_entry *entry = &session->entries[i];
    if (entry->token) continue;
    uint64_t token = lean_bridge_native_identity_acquire(lb_identity_kind, entry);
    if (!token) return NULL;
    *entry = (lb_entry){.token = token, .tag = tag, .session = session}; return entry;
  }
  return NULL;
}
static void lb_entry_collect(lb_entry *entry) {
  if (!entry->token || !entry->closed || entry->active) return;
  callbacksubtypes_wasmtime *session = entry->session;
  void (*release)(void *) = entry->release;
  void *data = entry->owned ? entry->owned : entry->data;
  (void)lean_bridge_native_identity_release(entry->token, lb_identity_kind, entry);
  *entry = (lb_entry){0};
  if (release) { ++session->finalizing; release(data); --session->finalizing; }
}
typedef struct { lb_scope scope; wasmtime_component_val_t value; } lb_result;
static inline void lb_result_release(void *data) {
  lb_result *owner = data;
  lb_scope_close(&owner->scope); wasmtime_component_val_delete(&owner->value); free(owner);
}
/* Proxies never own a persistent lease. A call frame owns unreturned leases;
 * the session owns published tokens. Dropping a proxy cannot close an alias. */
static wasmtime_error_t *lb_proxy_drop(void *data, wasmtime_context_t *context, uint32_t rep) {
  (void)data; (void)context; (void)rep; return NULL;
}
static wasmtime_error_t *lb_proxy(callbacksubtypes_wasmtime *session, wasmtime_context_t *context,
    lb_entry *entry, wasmtime_component_val_t *out) {
  uint32_t rep = (uint32_t)(entry - session->entries) + 1;
  wasmtime_component_resource_host_t *host = wasmtime_component_resource_host_new(true, rep, entry->tag);
  out->kind = WASMTIME_COMPONENT_RESOURCE;
  wasmtime_error_t *error = wasmtime_component_resource_host_to_any(context, host, &out->of.resource);
  wasmtime_component_resource_host_delete(host);
  if (error) *out = (wasmtime_component_val_t){0};
  return error;
}
static wasmtime_error_t *lb_unwrap(callbacksubtypes_wasmtime *session, wasmtime_context_t *context,
    const wasmtime_component_val_t *value, uint32_t tag, bool owned, lb_entry **out) {
  if (value->kind != WASMTIME_COMPONENT_RESOURCE || !value->of.resource || wasmtime_component_resource_any_owned(value->of.resource) != owned)
    return wasmtime_error_new("Invalid WIT callable resource ownership");
  wasmtime_component_resource_host_t *host = NULL;
  wasmtime_error_t *error = wasmtime_component_resource_any_to_host(context, value->of.resource, &host);
  if (error) return error;
  uint32_t rep = wasmtime_component_resource_host_rep(host), actual = wasmtime_component_resource_host_type(host);
  wasmtime_component_resource_host_delete(host);
  if (!rep || rep > LB_CAPACITY || actual != tag) return wasmtime_error_new("Invalid WIT callable representation");
  lb_entry *entry = &session->entries[rep - 1];
  if (!entry->token || entry->tag != tag) return wasmtime_error_new("Expired WIT callable resource");
  *out = entry; return NULL;
}
static wasmtime_error_t *lb_borrow(callbacksubtypes_wasmtime *session, wasmtime_context_t *context,
    const wasmtime_component_val_t *value, uint32_t tag, lb_entry **out) {
  wasmtime_error_t *error = lb_unwrap(session, context, value, tag, false, out);
  if (!error && !(*out)->active) error = wasmtime_error_new("WIT callable has no active borrow");
  return error;
}

/* Validate a callback context against active frames before dereferencing it.
 * A stale, foreign, wrong-thread or wrong-signature context owns no borrow. */
static lb_entry *lb_graph_callback_entry(void *raw, uint32_t tag) {
  uintptr_t address = (uintptr_t)raw;
  for (lb_frame *frame = lb_active_frame; frame; frame = frame->thread_previous) {
    callbacksubtypes_wasmtime *session = frame->session;
    uintptr_t first = (uintptr_t)&session->entries[0];
    if (address < first || address - first >= sizeof(session->entries) || (address - first) % sizeof(lb_entry)) continue;
    lb_entry *entry = raw;
    if (entry->session == session && entry->active && entry->token && entry->tag == tag && lb_thread(session)) return entry;
  }
  return NULL;
}

typedef struct { uint64_t token; } lb_graph_lease;

static uint32_t lb_graph_callback_2(void *data, const callbacksubtypes_graph_743764d1b67e81fcae92_t *arg0, callbacksubtypes_graph_2c6f4131c8731fa67588_t *out) {
  lb_entry *entry = lb_graph_callback_entry(data, 2);
  if (!entry) return 1;
  callbacksubtypes_wasmtime *session = entry->session;
  if (session->poisoned || session->closing) return 1;
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(callbacksubtypes_graph_2c6f4131c8731fa67588_t)) || out->_bridge_owner || out->_bridge_release) return 1;
  
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  wasmtime_component_val_t args[1] = {{0}}, reply = {0};
  wasmtime_error_t *failure = NULL;
  uint32_t status = 0;
  callbacksubtypes_graph_2c6f4131c8731fa67588_t converted = {0};
  lb_result *owner = NULL;
  if (!lb_graph_encode_0(arg0, &input, &args[0])) {
    if (!input.memory.failure) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new(input.memory.failure ? "WIT callback input conversion limit or allocation failure" : "Malformed native callback input; runtime retired"); goto done;
  }
  failure = entry->callback(entry->data, args, 1, &reply);
  if (failure || session->poisoned || session->closing) goto done;
  if (!lb_graph_decode_1(&reply, &output, &converted)) { failure = wasmtime_error_new("Invalid WIT callback result, conversion limit or allocation failure"); goto done; }
  if (!lean_bridge_native_component_ready("callbacksubtypes@1.0.0")) { failure = wasmtime_error_new("Lean runtime is unavailable"); goto done; }
  if (!lb_charge(&output.memory, 1, sizeof(*owner))) { failure = wasmtime_error_new("WIT callback reply ownership limit"); goto done; }
  owner = calloc(1, sizeof(*owner));
  if (!owner) { failure = wasmtime_error_new("Cannot allocate WIT callback reply owner"); goto done; }
  owner->scope = output.memory; output.memory.allocations = NULL;
  owner->value = reply; reply = (wasmtime_component_val_t){0};
  converted._bridge_owner = owner; converted._bridge_release = lb_result_release;
  *out = converted;
done:
  if (failure) { lb_record_error(session, failure); wasmtime_error_delete(failure); }
  if (session->closing && !session->poisoned) lb_record_text(session, "WIT session closed during callback", sizeof("WIT session closed during callback") - 1);
  if (session->poisoned) status = 1;
  for (size_t i = 0; i < 1; ++i) wasmtime_component_val_delete(&args[i]);
  wasmtime_component_val_delete(&reply); lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return status;
}


static uint32_t lb_graph_callback_4(void *data, const callbacksubtypes_scalar_nat_t *arg0, callbacksubtypes_scalar_nat_t *out) {
  lb_entry *entry = lb_graph_callback_entry(data, 4);
  if (!entry) return 1;
  callbacksubtypes_wasmtime *session = entry->session;
  if (session->poisoned || session->closing) return 1;
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(callbacksubtypes_scalar_nat_t)) || out->_bridge_owner || out->_bridge_release) return 1;
  if (entry->owned) {
    uint32_t status = callbacksubtypes_callback_c27fa7df7f1805196544d398fb121b21c179beb1_lease_call(((lb_graph_lease *)entry->owned)->token, arg0, out);
    if (status) { const char *refusal = status == 1 ? callbacksubtypes_callable_graph_error() : NULL;
      if (refusal) lb_record_text(session, refusal, strlen(refusal));
      else lb_record_text(session, "Native Lean closure call failed", sizeof("Native Lean closure call failed") - 1); }
    return status;
  }
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  wasmtime_component_val_t args[1] = {{0}}, reply = {0};
  wasmtime_error_t *failure = NULL;
  uint32_t status = 0;
  callbacksubtypes_scalar_nat_t converted = {0};
  lb_result *owner = NULL;
  if (!lb_graph_encode_3(arg0, &input, &args[0])) {
    if (!input.memory.failure) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new(input.memory.failure ? "WIT callback input conversion limit or allocation failure" : "Malformed native callback input; runtime retired"); goto done;
  }
  failure = entry->callback(entry->data, args, 1, &reply);
  if (failure || session->poisoned || session->closing) goto done;
  if (!lb_graph_decode_3(&reply, &output, &converted)) { failure = wasmtime_error_new("Invalid WIT callback result, conversion limit or allocation failure"); goto done; }
  if (!lean_bridge_native_component_ready("callbacksubtypes@1.0.0")) { failure = wasmtime_error_new("Lean runtime is unavailable"); goto done; }
  if (!lb_charge(&output.memory, 1, sizeof(*owner))) { failure = wasmtime_error_new("WIT callback reply ownership limit"); goto done; }
  owner = calloc(1, sizeof(*owner));
  if (!owner) { failure = wasmtime_error_new("Cannot allocate WIT callback reply owner"); goto done; }
  owner->scope = output.memory; output.memory.allocations = NULL;
  owner->value = reply; reply = (wasmtime_component_val_t){0};
  converted._bridge_owner = owner; converted._bridge_release = lb_result_release;
  *out = converted;
done:
  if (failure) { lb_record_error(session, failure); wasmtime_error_delete(failure); }
  if (session->closing && !session->poisoned) lb_record_text(session, "WIT session closed during callback", sizeof("WIT session closed during callback") - 1);
  if (session->poisoned) status = 1;
  for (size_t i = 0; i < 1; ++i) wasmtime_component_val_delete(&args[i]);
  wasmtime_component_val_delete(&reply); lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return status;
}
static inline void lb_graph_owned_drop_4(void *data) {
  lb_graph_lease *lease = data; callbacksubtypes_callback_c27fa7df7f1805196544d398fb121b21c179beb1_lease_dispose(lease->token); free(lease);
}

static uint32_t lb_graph_callback_3(void *data, const callbacksubtypes_scalar_nat_t *arg0, const callbacksubtypes_scalar_nat_t *arg1, callbacksubtypes_scalar_nat_t *out) {
  lb_entry *entry = lb_graph_callback_entry(data, 3);
  if (!entry) return 1;
  callbacksubtypes_wasmtime *session = entry->session;
  if (session->poisoned || session->closing) return 1;
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(callbacksubtypes_scalar_nat_t)) || out->_bridge_owner || out->_bridge_release) return 1;
  
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  wasmtime_component_val_t args[2] = {{0}}, reply = {0};
  wasmtime_error_t *failure = NULL;
  uint32_t status = 0;
  callbacksubtypes_scalar_nat_t converted = {0};
  lb_result *owner = NULL;
  if (!lb_graph_encode_3(arg0, &input, &args[0])) {
    if (!input.memory.failure) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new(input.memory.failure ? "WIT callback input conversion limit or allocation failure" : "Malformed native callback input; runtime retired"); goto done;
  }
  if (!lb_graph_encode_3(arg1, &input, &args[1])) {
    if (!input.memory.failure) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new(input.memory.failure ? "WIT callback input conversion limit or allocation failure" : "Malformed native callback input; runtime retired"); goto done;
  }
  failure = entry->callback(entry->data, args, 2, &reply);
  if (failure || session->poisoned || session->closing) goto done;
  if (!lb_graph_decode_3(&reply, &output, &converted)) { failure = wasmtime_error_new("Invalid WIT callback result, conversion limit or allocation failure"); goto done; }
  if (!lean_bridge_native_component_ready("callbacksubtypes@1.0.0")) { failure = wasmtime_error_new("Lean runtime is unavailable"); goto done; }
  if (!lb_charge(&output.memory, 1, sizeof(*owner))) { failure = wasmtime_error_new("WIT callback reply ownership limit"); goto done; }
  owner = calloc(1, sizeof(*owner));
  if (!owner) { failure = wasmtime_error_new("Cannot allocate WIT callback reply owner"); goto done; }
  owner->scope = output.memory; output.memory.allocations = NULL;
  owner->value = reply; reply = (wasmtime_component_val_t){0};
  converted._bridge_owner = owner; converted._bridge_release = lb_result_release;
  *out = converted;
done:
  if (failure) { lb_record_error(session, failure); wasmtime_error_delete(failure); }
  if (session->closing && !session->poisoned) lb_record_text(session, "WIT session closed during callback", sizeof("WIT session closed during callback") - 1);
  if (session->poisoned) status = 1;
  for (size_t i = 0; i < 2; ++i) wasmtime_component_val_delete(&args[i]);
  wasmtime_component_val_delete(&reply); lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return status;
}


static uint32_t lb_graph_callback_6(void *data, const callbacksubtypes_scalar_nat_t *arg0, const callbacksubtypes_scalar_nat_t *arg1, callbacksubtypes_scalar_nat_t *out) {
  lb_entry *entry = lb_graph_callback_entry(data, 6);
  if (!entry) return 1;
  callbacksubtypes_wasmtime *session = entry->session;
  if (session->poisoned || session->closing) return 1;
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(callbacksubtypes_scalar_nat_t)) || out->_bridge_owner || out->_bridge_release) return 1;
  if (entry->owned) {
    uint32_t status = callbacksubtypes_callback_51bfd752726fcfd8a9187a7c3a979ace51f7c1be_lease_call(((lb_graph_lease *)entry->owned)->token, arg0, arg1, out);
    if (status) { const char *refusal = status == 1 ? callbacksubtypes_callable_graph_error() : NULL;
      if (refusal) lb_record_text(session, refusal, strlen(refusal));
      else lb_record_text(session, "Native Lean closure call failed", sizeof("Native Lean closure call failed") - 1); }
    return status;
  }
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  wasmtime_component_val_t args[2] = {{0}}, reply = {0};
  wasmtime_error_t *failure = NULL;
  uint32_t status = 0;
  callbacksubtypes_scalar_nat_t converted = {0};
  lb_result *owner = NULL;
  if (!lb_graph_encode_3(arg0, &input, &args[0])) {
    if (!input.memory.failure) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new(input.memory.failure ? "WIT callback input conversion limit or allocation failure" : "Malformed native callback input; runtime retired"); goto done;
  }
  if (!lb_graph_encode_3(arg1, &input, &args[1])) {
    if (!input.memory.failure) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new(input.memory.failure ? "WIT callback input conversion limit or allocation failure" : "Malformed native callback input; runtime retired"); goto done;
  }
  failure = entry->callback(entry->data, args, 2, &reply);
  if (failure || session->poisoned || session->closing) goto done;
  if (!lb_graph_decode_3(&reply, &output, &converted)) { failure = wasmtime_error_new("Invalid WIT callback result, conversion limit or allocation failure"); goto done; }
  if (!lean_bridge_native_component_ready("callbacksubtypes@1.0.0")) { failure = wasmtime_error_new("Lean runtime is unavailable"); goto done; }
  if (!lb_charge(&output.memory, 1, sizeof(*owner))) { failure = wasmtime_error_new("WIT callback reply ownership limit"); goto done; }
  owner = calloc(1, sizeof(*owner));
  if (!owner) { failure = wasmtime_error_new("Cannot allocate WIT callback reply owner"); goto done; }
  owner->scope = output.memory; output.memory.allocations = NULL;
  owner->value = reply; reply = (wasmtime_component_val_t){0};
  converted._bridge_owner = owner; converted._bridge_release = lb_result_release;
  *out = converted;
done:
  if (failure) { lb_record_error(session, failure); wasmtime_error_delete(failure); }
  if (session->closing && !session->poisoned) lb_record_text(session, "WIT session closed during callback", sizeof("WIT session closed during callback") - 1);
  if (session->poisoned) status = 1;
  for (size_t i = 0; i < 2; ++i) wasmtime_component_val_delete(&args[i]);
  wasmtime_component_val_delete(&reply); lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return status;
}
static inline void lb_graph_owned_drop_6(void *data) {
  lb_graph_lease *lease = data; callbacksubtypes_callback_51bfd752726fcfd8a9187a7c3a979ace51f7c1be_lease_dispose(lease->token); free(lease);
}

static uint32_t lb_graph_callback_5(void *data, const callbacksubtypes_graph_6c9c0cf3d3abf9adeb4b_t *arg0, callbacksubtypes_graph_743764d1b67e81fcae92_t *out) {
  lb_entry *entry = lb_graph_callback_entry(data, 5);
  if (!entry) return 1;
  callbacksubtypes_wasmtime *session = entry->session;
  if (session->poisoned || session->closing) return 1;
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(callbacksubtypes_graph_743764d1b67e81fcae92_t)) || out->_bridge_owner || out->_bridge_release) return 1;
  if (entry->owned) {
    uint32_t status = callbacksubtypes_callback_6cdd9c3be7604978d190e4f9d3a70db0539487ba_lease_call(((lb_graph_lease *)entry->owned)->token, arg0, out);
    if (status) { const char *refusal = status == 1 ? callbacksubtypes_callable_graph_error() : NULL;
      if (refusal) lb_record_text(session, refusal, strlen(refusal));
      else lb_record_text(session, "Native Lean closure call failed", sizeof("Native Lean closure call failed") - 1); }
    return status;
  }
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  wasmtime_component_val_t args[1] = {{0}}, reply = {0};
  wasmtime_error_t *failure = NULL;
  uint32_t status = 0;
  callbacksubtypes_graph_743764d1b67e81fcae92_t converted = {0};
  lb_result *owner = NULL;
  if (!lb_graph_encode_2(arg0, &input, &args[0])) {
    if (!input.memory.failure) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new(input.memory.failure ? "WIT callback input conversion limit or allocation failure" : "Malformed native callback input; runtime retired"); goto done;
  }
  failure = entry->callback(entry->data, args, 1, &reply);
  if (failure || session->poisoned || session->closing) goto done;
  if (!lb_graph_decode_0(&reply, &output, &converted)) { failure = wasmtime_error_new("Invalid WIT callback result, conversion limit or allocation failure"); goto done; }
  if (!lean_bridge_native_component_ready("callbacksubtypes@1.0.0")) { failure = wasmtime_error_new("Lean runtime is unavailable"); goto done; }
  if (!lb_charge(&output.memory, 1, sizeof(*owner))) { failure = wasmtime_error_new("WIT callback reply ownership limit"); goto done; }
  owner = calloc(1, sizeof(*owner));
  if (!owner) { failure = wasmtime_error_new("Cannot allocate WIT callback reply owner"); goto done; }
  owner->scope = output.memory; output.memory.allocations = NULL;
  owner->value = reply; reply = (wasmtime_component_val_t){0};
  converted._bridge_owner = owner; converted._bridge_release = lb_result_release;
  *out = converted;
done:
  if (failure) { lb_record_error(session, failure); wasmtime_error_delete(failure); }
  if (session->closing && !session->poisoned) lb_record_text(session, "WIT session closed during callback", sizeof("WIT session closed during callback") - 1);
  if (session->poisoned) status = 1;
  for (size_t i = 0; i < 1; ++i) wasmtime_component_val_delete(&args[i]);
  wasmtime_component_val_delete(&reply); lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return status;
}
static inline void lb_graph_owned_drop_5(void *data) {
  lb_graph_lease *lease = data; callbacksubtypes_callback_6cdd9c3be7604978d190e4f9d3a70db0539487ba_lease_dispose(lease->token); free(lease);
}

static uint32_t lb_graph_callback_1(void *data, const callbacksubtypes_scalar_nat_t *arg0, callbacksubtypes_scalar_nat_t *out) {
  lb_entry *entry = lb_graph_callback_entry(data, 1);
  if (!entry) return 1;
  callbacksubtypes_wasmtime *session = entry->session;
  if (session->poisoned || session->closing) return 1;
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(callbacksubtypes_scalar_nat_t)) || out->_bridge_owner || out->_bridge_release) return 1;
  
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  wasmtime_component_val_t args[1] = {{0}}, reply = {0};
  wasmtime_error_t *failure = NULL;
  uint32_t status = 0;
  callbacksubtypes_scalar_nat_t converted = {0};
  lb_result *owner = NULL;
  if (!lb_graph_encode_3(arg0, &input, &args[0])) {
    if (!input.memory.failure) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new(input.memory.failure ? "WIT callback input conversion limit or allocation failure" : "Malformed native callback input; runtime retired"); goto done;
  }
  failure = entry->callback(entry->data, args, 1, &reply);
  if (failure || session->poisoned || session->closing) goto done;
  if (!lb_graph_decode_3(&reply, &output, &converted)) { failure = wasmtime_error_new("Invalid WIT callback result, conversion limit or allocation failure"); goto done; }
  if (!lean_bridge_native_component_ready("callbacksubtypes@1.0.0")) { failure = wasmtime_error_new("Lean runtime is unavailable"); goto done; }
  if (!lb_charge(&output.memory, 1, sizeof(*owner))) { failure = wasmtime_error_new("WIT callback reply ownership limit"); goto done; }
  owner = calloc(1, sizeof(*owner));
  if (!owner) { failure = wasmtime_error_new("Cannot allocate WIT callback reply owner"); goto done; }
  owner->scope = output.memory; output.memory.allocations = NULL;
  owner->value = reply; reply = (wasmtime_component_val_t){0};
  converted._bridge_owner = owner; converted._bridge_release = lb_result_release;
  *out = converted;
done:
  if (failure) { lb_record_error(session, failure); wasmtime_error_delete(failure); }
  if (session->closing && !session->poisoned) lb_record_text(session, "WIT session closed during callback", sizeof("WIT session closed during callback") - 1);
  if (session->poisoned) status = 1;
  for (size_t i = 0; i < 1; ++i) wasmtime_component_val_delete(&args[i]);
  wasmtime_component_val_delete(&reply); lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return status;
}


static wasmtime_error_t *lb_call_0(void *data, wasmtime_context_t *context,
    const wasmtime_component_func_type_t *type, wasmtime_component_val_t *args, size_t count,
    wasmtime_component_val_t *results, size_t result_count) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  (void)type; (void)context;
  callbacksubtypes_wasmtime *session = data;
  if (!session->frame || session->poisoned || session->closing || count != 1 || result_count != 1
      || !lb_buffer(args, count, sizeof(*args), _Alignof(wasmtime_component_val_t))
      || !lb_buffer(results, 1, sizeof(*results), _Alignof(wasmtime_component_val_t))) return wasmtime_error_new("Unavailable WIT graph import or signature mismatch");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  wasmtime_error_t *failure = NULL;
  callbacksubtypes_scalar_nat_t value = {0};
  wasmtime_component_val_t converted = {0};
  lb_entry *entry0 = NULL;
  callbacksubtypes_callback_6bc98ee774b20d3238b9e42a92309a51ce9dad0a arg0 = {0};
  failure = lb_borrow(session, context, &args[0], 1, &entry0);
  if (failure) goto done;
  if (!entry0->recovery) { failure = wasmtime_error_new("Missing callback Subtype recovery"); goto done; }
  arg0 = (callbacksubtypes_callback_6bc98ee774b20d3238b9e42a92309a51ce9dad0a){.call = lb_graph_callback_1, .context = entry0, .recovery = entry0->recovery};
  uint32_t native_status = lean_bridge_23220a30761b2d3716c5b4ed_graph(&arg0, &value);
  if (native_status) { failure = wasmtime_error_new(native_status == 10 ? "Host callback result failed its Lean constructor" : "Native Lean graph call failed"); goto done; }
  if (session->poisoned || session->closing) { failure = wasmtime_error_new("WIT callback failed or session closed"); goto done; }
  if (!lb_graph_encode_3(&value, &output, &converted)) {
    if (!output.memory.failure) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new(output.memory.failure ? "WIT graph result conversion limit or allocation failure" : "Malformed native graph result; runtime retired"); goto done;
  }
  if (!lean_bridge_native_component_ready("callbacksubtypes@1.0.0")) { failure = wasmtime_error_new("Lean runtime is unavailable"); goto done; }
  results[0] = converted; converted = (wasmtime_component_val_t){0};
done:
  if (failure) lb_record_error(session, failure);
  wasmtime_component_val_delete(&converted);
  callbacksubtypes_scalar_nat_t_clear(&value);
  lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}

static wasmtime_error_t *lb_call_1(void *data, wasmtime_context_t *context,
    const wasmtime_component_func_type_t *type, wasmtime_component_val_t *args, size_t count,
    wasmtime_component_val_t *results, size_t result_count) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  (void)type; (void)context;
  callbacksubtypes_wasmtime *session = data;
  if (!session->frame || session->poisoned || session->closing || count != 1 || result_count != 1
      || !lb_buffer(args, count, sizeof(*args), _Alignof(wasmtime_component_val_t))
      || !lb_buffer(results, 1, sizeof(*results), _Alignof(wasmtime_component_val_t))) return wasmtime_error_new("Unavailable WIT graph import or signature mismatch");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  wasmtime_error_t *failure = NULL;
  callbacksubtypes_graph_2c6f4131c8731fa67588_t value = {0};
  wasmtime_component_val_t converted = {0};
  lb_entry *entry0 = NULL;
  callbacksubtypes_callback_14cd8f1b0d065ede9a36f8590000c62c12d8e99c arg0 = {0};
  failure = lb_borrow(session, context, &args[0], 2, &entry0);
  if (failure) goto done;
  if (!entry0->recovery) { failure = wasmtime_error_new("Missing callback Subtype recovery"); goto done; }
  arg0 = (callbacksubtypes_callback_14cd8f1b0d065ede9a36f8590000c62c12d8e99c){.call = lb_graph_callback_2, .context = entry0, .recovery = entry0->recovery};
  uint32_t native_status = lean_bridge_8ffe188578f9a7b74003cf3c_graph(&arg0, &value);
  if (native_status) { failure = wasmtime_error_new(native_status == 10 ? "Host callback result failed its Lean constructor" : "Native Lean graph call failed"); goto done; }
  if (session->poisoned || session->closing) { failure = wasmtime_error_new("WIT callback failed or session closed"); goto done; }
  if (!lb_graph_encode_1(&value, &output, &converted)) {
    if (!output.memory.failure) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new(output.memory.failure ? "WIT graph result conversion limit or allocation failure" : "Malformed native graph result; runtime retired"); goto done;
  }
  if (!lean_bridge_native_component_ready("callbacksubtypes@1.0.0")) { failure = wasmtime_error_new("Lean runtime is unavailable"); goto done; }
  results[0] = converted; converted = (wasmtime_component_val_t){0};
done:
  if (failure) lb_record_error(session, failure);
  wasmtime_component_val_delete(&converted);
  callbacksubtypes_graph_2c6f4131c8731fa67588_t_clear(&value);
  lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}

static wasmtime_error_t *lb_call_2(void *data, wasmtime_context_t *context,
    const wasmtime_component_func_type_t *type, wasmtime_component_val_t *args, size_t count,
    wasmtime_component_val_t *results, size_t result_count) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  (void)type; (void)context;
  callbacksubtypes_wasmtime *session = data;
  if (!session->frame || session->poisoned || session->closing || count != 1 || result_count != 1
      || !lb_buffer(args, count, sizeof(*args), _Alignof(wasmtime_component_val_t))
      || !lb_buffer(results, 1, sizeof(*results), _Alignof(wasmtime_component_val_t))) return wasmtime_error_new("Unavailable WIT graph import or signature mismatch");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  wasmtime_error_t *failure = NULL;
  callbacksubtypes_scalar_nat_t value = {0};
  wasmtime_component_val_t converted = {0};
  lb_entry *entry0 = NULL;
  callbacksubtypes_callback_197d5bf19058d37bc5547c33a8e0bed3bf121ea7 arg0 = {0};
  failure = lb_borrow(session, context, &args[0], 3, &entry0);
  if (failure) goto done;
  if (!entry0->recovery) { failure = wasmtime_error_new("Missing callback Subtype recovery"); goto done; }
  arg0 = (callbacksubtypes_callback_197d5bf19058d37bc5547c33a8e0bed3bf121ea7){.call = lb_graph_callback_3, .context = entry0, .recovery = entry0->recovery};
  uint32_t native_status = lean_bridge_4f106adfac5064464a2a8e3f_graph(&arg0, &value);
  if (native_status) { failure = wasmtime_error_new(native_status == 10 ? "Host callback result failed its Lean constructor" : "Native Lean graph call failed"); goto done; }
  if (session->poisoned || session->closing) { failure = wasmtime_error_new("WIT callback failed or session closed"); goto done; }
  if (!lb_graph_encode_3(&value, &output, &converted)) {
    if (!output.memory.failure) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new(output.memory.failure ? "WIT graph result conversion limit or allocation failure" : "Malformed native graph result; runtime retired"); goto done;
  }
  if (!lean_bridge_native_component_ready("callbacksubtypes@1.0.0")) { failure = wasmtime_error_new("Lean runtime is unavailable"); goto done; }
  results[0] = converted; converted = (wasmtime_component_val_t){0};
done:
  if (failure) lb_record_error(session, failure);
  wasmtime_component_val_delete(&converted);
  callbacksubtypes_scalar_nat_t_clear(&value);
  lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}

static wasmtime_error_t *lb_call_3(void *data, wasmtime_context_t *context,
    const wasmtime_component_func_type_t *type, wasmtime_component_val_t *args, size_t count,
    wasmtime_component_val_t *results, size_t result_count) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  (void)type; (void)context;
  callbacksubtypes_wasmtime *session = data;
  if (!session->frame || session->poisoned || session->closing || count != 1 || result_count != 1
      || !lb_buffer(args, count, sizeof(*args), _Alignof(wasmtime_component_val_t))
      || !lb_buffer(results, 1, sizeof(*results), _Alignof(wasmtime_component_val_t))) return wasmtime_error_new("Unavailable WIT graph import or signature mismatch");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  wasmtime_error_t *failure = NULL;
  uint64_t value = {0};
  wasmtime_component_val_t converted = {0};
  callbacksubtypes_scalar_nat_t arg0 = {0};
  if (!lb_graph_decode_3(&args[0], &input, &arg0)) { failure = wasmtime_error_new("Invalid WIT graph input, conversion limit or allocation failure"); goto done; }
  uint32_t native_status = lean_bridge_e2d5407c03792441cb368ec1_graph(&arg0, &value);
  if (native_status) { failure = wasmtime_error_new(native_status == 10 ? "Host callback result failed its Lean constructor" : "Native Lean graph call failed"); goto done; }
  if (session->poisoned || session->closing) { failure = wasmtime_error_new("WIT callback failed or session closed"); goto done; }
  if (!value) { lean_bridge_native_runtime_retire(); failure = wasmtime_error_new("Missing native closure identity; runtime retired"); goto done; }
  session->frame->pending = lb_entry_new(session, 4);
  if (!session->frame->pending) { failure = wasmtime_error_new("WIT callable capacity exhausted"); goto done; }
  lb_graph_lease *lease = malloc(sizeof(*lease));
  if (!lease) { failure = wasmtime_error_new("Cannot allocate WIT closure identity owner"); goto done; }
  lease->token = value; value = 0;
  session->frame->pending->owned = lease; session->frame->pending->release = lb_graph_owned_drop_4;
  failure = lb_proxy(session, context, session->frame->pending, &converted);
  if (failure) goto done;
  if (!lean_bridge_native_component_ready("callbacksubtypes@1.0.0")) { failure = wasmtime_error_new("Lean runtime is unavailable"); goto done; }
  results[0] = converted; converted = (wasmtime_component_val_t){0};
done:
  if (failure) lb_record_error(session, failure);
  wasmtime_component_val_delete(&converted);
  if (value) callbacksubtypes_callback_c27fa7df7f1805196544d398fb121b21c179beb1_lease_dispose(value);
  lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}

static wasmtime_error_t *lb_call_4(void *data, wasmtime_context_t *context,
    const wasmtime_component_func_type_t *type, wasmtime_component_val_t *args, size_t count,
    wasmtime_component_val_t *results, size_t result_count) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  (void)type; (void)context;
  callbacksubtypes_wasmtime *session = data;
  if (!session->frame || session->poisoned || session->closing || count != 1 || result_count != 1
      || !lb_buffer(args, count, sizeof(*args), _Alignof(wasmtime_component_val_t))
      || !lb_buffer(results, 1, sizeof(*results), _Alignof(wasmtime_component_val_t))) return wasmtime_error_new("Unavailable WIT graph import or signature mismatch");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  wasmtime_error_t *failure = NULL;
  uint64_t value = {0};
  wasmtime_component_val_t converted = {0};
  callbacksubtypes_scalar_nat_t arg0 = {0};
  if (!lb_graph_decode_3(&args[0], &input, &arg0)) { failure = wasmtime_error_new("Invalid WIT graph input, conversion limit or allocation failure"); goto done; }
  uint32_t native_status = lean_bridge_07d8425a546c7304b285ddcd_graph(&arg0, &value);
  if (native_status) { failure = wasmtime_error_new(native_status == 10 ? "Host callback result failed its Lean constructor" : "Native Lean graph call failed"); goto done; }
  if (session->poisoned || session->closing) { failure = wasmtime_error_new("WIT callback failed or session closed"); goto done; }
  if (!value) { lean_bridge_native_runtime_retire(); failure = wasmtime_error_new("Missing native closure identity; runtime retired"); goto done; }
  session->frame->pending = lb_entry_new(session, 5);
  if (!session->frame->pending) { failure = wasmtime_error_new("WIT callable capacity exhausted"); goto done; }
  lb_graph_lease *lease = malloc(sizeof(*lease));
  if (!lease) { failure = wasmtime_error_new("Cannot allocate WIT closure identity owner"); goto done; }
  lease->token = value; value = 0;
  session->frame->pending->owned = lease; session->frame->pending->release = lb_graph_owned_drop_5;
  failure = lb_proxy(session, context, session->frame->pending, &converted);
  if (failure) goto done;
  if (!lean_bridge_native_component_ready("callbacksubtypes@1.0.0")) { failure = wasmtime_error_new("Lean runtime is unavailable"); goto done; }
  results[0] = converted; converted = (wasmtime_component_val_t){0};
done:
  if (failure) lb_record_error(session, failure);
  wasmtime_component_val_delete(&converted);
  if (value) callbacksubtypes_callback_6cdd9c3be7604978d190e4f9d3a70db0539487ba_lease_dispose(value);
  lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}

static wasmtime_error_t *lb_call_5(void *data, wasmtime_context_t *context,
    const wasmtime_component_func_type_t *type, wasmtime_component_val_t *args, size_t count,
    wasmtime_component_val_t *results, size_t result_count) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  (void)type; (void)context;
  callbacksubtypes_wasmtime *session = data;
  if (!session->frame || session->poisoned || session->closing || count != 1 || result_count != 1
      || !lb_buffer(args, count, sizeof(*args), _Alignof(wasmtime_component_val_t))
      || !lb_buffer(results, 1, sizeof(*results), _Alignof(wasmtime_component_val_t))) return wasmtime_error_new("Unavailable WIT graph import or signature mismatch");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  wasmtime_error_t *failure = NULL;
  uint64_t value = {0};
  wasmtime_component_val_t converted = {0};
  callbacksubtypes_scalar_nat_t arg0 = {0};
  if (!lb_graph_decode_3(&args[0], &input, &arg0)) { failure = wasmtime_error_new("Invalid WIT graph input, conversion limit or allocation failure"); goto done; }
  uint32_t native_status = lean_bridge_36fd9c74c3921bfb2ead3644_graph(&arg0, &value);
  if (native_status) { failure = wasmtime_error_new(native_status == 10 ? "Host callback result failed its Lean constructor" : "Native Lean graph call failed"); goto done; }
  if (session->poisoned || session->closing) { failure = wasmtime_error_new("WIT callback failed or session closed"); goto done; }
  if (!value) { lean_bridge_native_runtime_retire(); failure = wasmtime_error_new("Missing native closure identity; runtime retired"); goto done; }
  session->frame->pending = lb_entry_new(session, 6);
  if (!session->frame->pending) { failure = wasmtime_error_new("WIT callable capacity exhausted"); goto done; }
  lb_graph_lease *lease = malloc(sizeof(*lease));
  if (!lease) { failure = wasmtime_error_new("Cannot allocate WIT closure identity owner"); goto done; }
  lease->token = value; value = 0;
  session->frame->pending->owned = lease; session->frame->pending->release = lb_graph_owned_drop_6;
  failure = lb_proxy(session, context, session->frame->pending, &converted);
  if (failure) goto done;
  if (!lean_bridge_native_component_ready("callbacksubtypes@1.0.0")) { failure = wasmtime_error_new("Lean runtime is unavailable"); goto done; }
  results[0] = converted; converted = (wasmtime_component_val_t){0};
done:
  if (failure) lb_record_error(session, failure);
  wasmtime_component_val_delete(&converted);
  if (value) callbacksubtypes_callback_51bfd752726fcfd8a9187a7c3a979ace51f7c1be_lease_dispose(value);
  lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}

static wasmtime_error_t *lb_call_6(void *data, wasmtime_context_t *context,
    const wasmtime_component_func_type_t *type, wasmtime_component_val_t *args, size_t count,
    wasmtime_component_val_t *results, size_t result_count) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  (void)type; (void)context;
  callbacksubtypes_wasmtime *session = data;
  if (!session->frame || session->poisoned || session->closing || count != 2 || result_count != 1
      || !lb_buffer(args, count, sizeof(*args), _Alignof(wasmtime_component_val_t))
      || !lb_buffer(results, 1, sizeof(*results), _Alignof(wasmtime_component_val_t))) return wasmtime_error_new("Unavailable WIT graph import or signature mismatch");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  wasmtime_error_t *failure = NULL;
  callbacksubtypes_scalar_nat_t value = {0};
  wasmtime_component_val_t converted = {0};
  lb_entry *entry0 = NULL;
  callbacksubtypes_scalar_nat_t arg1 = {0};
  failure = lb_borrow(session, context, &args[0], 1, &entry0);
  if (failure) goto done;

  if (!lb_graph_decode_3(&args[1], &input, &arg1)) { failure = wasmtime_error_new("Invalid WIT graph input, conversion limit or allocation failure"); goto done; }
  uint32_t native_status = lb_graph_callback_1(entry0, &arg1, &value);
  if (native_status) { failure = wasmtime_error_new("WIT callback failed"); goto done; }
  if (session->poisoned || session->closing) { failure = wasmtime_error_new("WIT callback failed or session closed"); goto done; }
  if (!lb_graph_encode_3(&value, &output, &converted)) {
    if (!output.memory.failure) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new(output.memory.failure ? "WIT graph result conversion limit or allocation failure" : "Malformed native graph result; runtime retired"); goto done;
  }
  if (!lean_bridge_native_component_ready("callbacksubtypes@1.0.0")) { failure = wasmtime_error_new("Lean runtime is unavailable"); goto done; }
  results[0] = converted; converted = (wasmtime_component_val_t){0};
done:
  if (failure) lb_record_error(session, failure);
  wasmtime_component_val_delete(&converted);
  callbacksubtypes_scalar_nat_t_clear(&value);
  lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}

static wasmtime_error_t *lb_call_7(void *data, wasmtime_context_t *context,
    const wasmtime_component_func_type_t *type, wasmtime_component_val_t *args, size_t count,
    wasmtime_component_val_t *results, size_t result_count) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  (void)type; (void)context;
  callbacksubtypes_wasmtime *session = data;
  if (!session->frame || session->poisoned || session->closing || count != 2 || result_count != 1
      || !lb_buffer(args, count, sizeof(*args), _Alignof(wasmtime_component_val_t))
      || !lb_buffer(results, 1, sizeof(*results), _Alignof(wasmtime_component_val_t))) return wasmtime_error_new("Unavailable WIT graph import or signature mismatch");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  wasmtime_error_t *failure = NULL;
  callbacksubtypes_graph_2c6f4131c8731fa67588_t value = {0};
  wasmtime_component_val_t converted = {0};
  lb_entry *entry0 = NULL;
  callbacksubtypes_graph_743764d1b67e81fcae92_t arg1 = {0};
  failure = lb_borrow(session, context, &args[0], 2, &entry0);
  if (failure) goto done;

  if (!lb_graph_decode_0(&args[1], &input, &arg1)) { failure = wasmtime_error_new("Invalid WIT graph input, conversion limit or allocation failure"); goto done; }
  uint32_t native_status = lb_graph_callback_2(entry0, &arg1, &value);
  if (native_status) { failure = wasmtime_error_new("WIT callback failed"); goto done; }
  if (session->poisoned || session->closing) { failure = wasmtime_error_new("WIT callback failed or session closed"); goto done; }
  if (!lb_graph_encode_1(&value, &output, &converted)) {
    if (!output.memory.failure) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new(output.memory.failure ? "WIT graph result conversion limit or allocation failure" : "Malformed native graph result; runtime retired"); goto done;
  }
  if (!lean_bridge_native_component_ready("callbacksubtypes@1.0.0")) { failure = wasmtime_error_new("Lean runtime is unavailable"); goto done; }
  results[0] = converted; converted = (wasmtime_component_val_t){0};
done:
  if (failure) lb_record_error(session, failure);
  wasmtime_component_val_delete(&converted);
  callbacksubtypes_graph_2c6f4131c8731fa67588_t_clear(&value);
  lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}

static wasmtime_error_t *lb_call_8(void *data, wasmtime_context_t *context,
    const wasmtime_component_func_type_t *type, wasmtime_component_val_t *args, size_t count,
    wasmtime_component_val_t *results, size_t result_count) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  (void)type; (void)context;
  callbacksubtypes_wasmtime *session = data;
  if (!session->frame || session->poisoned || session->closing || count != 3 || result_count != 1
      || !lb_buffer(args, count, sizeof(*args), _Alignof(wasmtime_component_val_t))
      || !lb_buffer(results, 1, sizeof(*results), _Alignof(wasmtime_component_val_t))) return wasmtime_error_new("Unavailable WIT graph import or signature mismatch");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  wasmtime_error_t *failure = NULL;
  callbacksubtypes_scalar_nat_t value = {0};
  wasmtime_component_val_t converted = {0};
  lb_entry *entry0 = NULL;
  callbacksubtypes_scalar_nat_t arg1 = {0};
  callbacksubtypes_scalar_nat_t arg2 = {0};
  failure = lb_borrow(session, context, &args[0], 3, &entry0);
  if (failure) goto done;

  if (!lb_graph_decode_3(&args[1], &input, &arg1)) { failure = wasmtime_error_new("Invalid WIT graph input, conversion limit or allocation failure"); goto done; }
  if (!lb_graph_decode_3(&args[2], &input, &arg2)) { failure = wasmtime_error_new("Invalid WIT graph input, conversion limit or allocation failure"); goto done; }
  uint32_t native_status = lb_graph_callback_3(entry0, &arg1, &arg2, &value);
  if (native_status) { failure = wasmtime_error_new("WIT callback failed"); goto done; }
  if (session->poisoned || session->closing) { failure = wasmtime_error_new("WIT callback failed or session closed"); goto done; }
  if (!lb_graph_encode_3(&value, &output, &converted)) {
    if (!output.memory.failure) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new(output.memory.failure ? "WIT graph result conversion limit or allocation failure" : "Malformed native graph result; runtime retired"); goto done;
  }
  if (!lean_bridge_native_component_ready("callbacksubtypes@1.0.0")) { failure = wasmtime_error_new("Lean runtime is unavailable"); goto done; }
  results[0] = converted; converted = (wasmtime_component_val_t){0};
done:
  if (failure) lb_record_error(session, failure);
  wasmtime_component_val_delete(&converted);
  callbacksubtypes_scalar_nat_t_clear(&value);
  lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}

static wasmtime_error_t *lb_call_9(void *data, wasmtime_context_t *context,
    const wasmtime_component_func_type_t *type, wasmtime_component_val_t *args, size_t count,
    wasmtime_component_val_t *results, size_t result_count) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  (void)type; (void)context;
  callbacksubtypes_wasmtime *session = data;
  if (!session->frame || session->poisoned || session->closing || count != 2 || result_count != 1
      || !lb_buffer(args, count, sizeof(*args), _Alignof(wasmtime_component_val_t))
      || !lb_buffer(results, 1, sizeof(*results), _Alignof(wasmtime_component_val_t))) return wasmtime_error_new("Unavailable WIT graph import or signature mismatch");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  wasmtime_error_t *failure = NULL;
  callbacksubtypes_scalar_nat_t value = {0};
  wasmtime_component_val_t converted = {0};
  lb_entry *entry0 = NULL;
  callbacksubtypes_scalar_nat_t arg1 = {0};
  failure = lb_borrow(session, context, &args[0], 4, &entry0);
  if (failure) goto done;

  if (!lb_graph_decode_3(&args[1], &input, &arg1)) { failure = wasmtime_error_new("Invalid WIT graph input, conversion limit or allocation failure"); goto done; }
  uint32_t native_status = lb_graph_callback_4(entry0, &arg1, &value);
  if (native_status) { failure = wasmtime_error_new("WIT callback failed"); goto done; }
  if (session->poisoned || session->closing) { failure = wasmtime_error_new("WIT callback failed or session closed"); goto done; }
  if (!lb_graph_encode_3(&value, &output, &converted)) {
    if (!output.memory.failure) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new(output.memory.failure ? "WIT graph result conversion limit or allocation failure" : "Malformed native graph result; runtime retired"); goto done;
  }
  if (!lean_bridge_native_component_ready("callbacksubtypes@1.0.0")) { failure = wasmtime_error_new("Lean runtime is unavailable"); goto done; }
  results[0] = converted; converted = (wasmtime_component_val_t){0};
done:
  if (failure) lb_record_error(session, failure);
  wasmtime_component_val_delete(&converted);
  callbacksubtypes_scalar_nat_t_clear(&value);
  lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}

static wasmtime_error_t *lb_call_10(void *data, wasmtime_context_t *context,
    const wasmtime_component_func_type_t *type, wasmtime_component_val_t *args, size_t count,
    wasmtime_component_val_t *results, size_t result_count) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  (void)type; (void)context;
  callbacksubtypes_wasmtime *session = data;
  if (!session->frame || session->poisoned || session->closing || count != 2 || result_count != 1
      || !lb_buffer(args, count, sizeof(*args), _Alignof(wasmtime_component_val_t))
      || !lb_buffer(results, 1, sizeof(*results), _Alignof(wasmtime_component_val_t))) return wasmtime_error_new("Unavailable WIT graph import or signature mismatch");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  wasmtime_error_t *failure = NULL;
  callbacksubtypes_graph_743764d1b67e81fcae92_t value = {0};
  wasmtime_component_val_t converted = {0};
  lb_entry *entry0 = NULL;
  callbacksubtypes_graph_6c9c0cf3d3abf9adeb4b_t arg1 = {0};
  failure = lb_borrow(session, context, &args[0], 5, &entry0);
  if (failure) goto done;

  if (!lb_graph_decode_2(&args[1], &input, &arg1)) { failure = wasmtime_error_new("Invalid WIT graph input, conversion limit or allocation failure"); goto done; }
  uint32_t native_status = lb_graph_callback_5(entry0, &arg1, &value);
  if (native_status) { failure = wasmtime_error_new("WIT callback failed"); goto done; }
  if (session->poisoned || session->closing) { failure = wasmtime_error_new("WIT callback failed or session closed"); goto done; }
  if (!lb_graph_encode_0(&value, &output, &converted)) {
    if (!output.memory.failure) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new(output.memory.failure ? "WIT graph result conversion limit or allocation failure" : "Malformed native graph result; runtime retired"); goto done;
  }
  if (!lean_bridge_native_component_ready("callbacksubtypes@1.0.0")) { failure = wasmtime_error_new("Lean runtime is unavailable"); goto done; }
  results[0] = converted; converted = (wasmtime_component_val_t){0};
done:
  if (failure) lb_record_error(session, failure);
  wasmtime_component_val_delete(&converted);
  callbacksubtypes_graph_743764d1b67e81fcae92_t_clear(&value);
  lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}

static wasmtime_error_t *lb_call_11(void *data, wasmtime_context_t *context,
    const wasmtime_component_func_type_t *type, wasmtime_component_val_t *args, size_t count,
    wasmtime_component_val_t *results, size_t result_count) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  (void)type; (void)context;
  callbacksubtypes_wasmtime *session = data;
  if (!session->frame || session->poisoned || session->closing || count != 3 || result_count != 1
      || !lb_buffer(args, count, sizeof(*args), _Alignof(wasmtime_component_val_t))
      || !lb_buffer(results, 1, sizeof(*results), _Alignof(wasmtime_component_val_t))) return wasmtime_error_new("Unavailable WIT graph import or signature mismatch");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  wasmtime_error_t *failure = NULL;
  callbacksubtypes_scalar_nat_t value = {0};
  wasmtime_component_val_t converted = {0};
  lb_entry *entry0 = NULL;
  callbacksubtypes_scalar_nat_t arg1 = {0};
  callbacksubtypes_scalar_nat_t arg2 = {0};
  failure = lb_borrow(session, context, &args[0], 6, &entry0);
  if (failure) goto done;

  if (!lb_graph_decode_3(&args[1], &input, &arg1)) { failure = wasmtime_error_new("Invalid WIT graph input, conversion limit or allocation failure"); goto done; }
  if (!lb_graph_decode_3(&args[2], &input, &arg2)) { failure = wasmtime_error_new("Invalid WIT graph input, conversion limit or allocation failure"); goto done; }
  uint32_t native_status = lb_graph_callback_6(entry0, &arg1, &arg2, &value);
  if (native_status) { failure = wasmtime_error_new("WIT callback failed"); goto done; }
  if (session->poisoned || session->closing) { failure = wasmtime_error_new("WIT callback failed or session closed"); goto done; }
  if (!lb_graph_encode_3(&value, &output, &converted)) {
    if (!output.memory.failure) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new(output.memory.failure ? "WIT graph result conversion limit or allocation failure" : "Malformed native graph result; runtime retired"); goto done;
  }
  if (!lean_bridge_native_component_ready("callbacksubtypes@1.0.0")) { failure = wasmtime_error_new("Lean runtime is unavailable"); goto done; }
  results[0] = converted; converted = (wasmtime_component_val_t){0};
done:
  if (failure) lb_record_error(session, failure);
  wasmtime_component_val_delete(&converted);
  callbacksubtypes_scalar_nat_t_clear(&value);
  lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}

static const uint8_t lb_component[] = {0,97,115,109,13,0,1,0,7,252,10,1,66,80,1,112,121,1,112,121,4,0,14,98,114,105,100,103,101,45,118,97,108,117,101,45,48,3,0,1,1,114,1,5,105,110,100,101,120,121,4,0,13,108,98,45,103,114,97,112,104,45,114,101,102,48,3,0,3,1,107,2,4,0,14,98,114,105,100,103,101,45,118,97,108,117,101,45,51,3,0,5,1,112,6,4,0,14,98,114,105,100,103,101,45,118,97,108,117,101,45,52,3,0,7,1,106,1,4,1,115,4,0,14,98,114,105,100,103,101,45,118,97,108,117,101,45,54,3,0,9,1,112,10,4,0,14,98,114,105,100,103,101,45,118,97,108,117,101,45,55,3,0,11,1,112,4,4,0,14,98,114,105,100,103,101,45,118,97,108,117,101,45,56,3,0,13,1,112,14,4,0,14,98,114,105,100,103,101,45,118,97,108,117,101,45,57,3,0,15,4,0,14,108,98,45,103,114,97,112,104,45,110,111,100,101,48,3,0,6,1,112,17,4,0,21,98,114,105,100,103,101,45,97,108,105,97,115,45,118,97,108,117,101,45,49,55,3,0,18,4,0,14,108,98,45,103,114,97,112,104,45,110,111,100,101,49,3,0,10,1,112,20,4,0,21,98,114,105,100,103,101,45,97,108,105,97,115,45,118,97,108,117,101,45,49,57,3,0,21,4,0,14,108,98,45,103,114,97,112,104,45,110,111,100,101,50,3,0,14,1,112,23,4,0,21,98,114,105,100,103,101,45,97,108,105,97,115,45,118,97,108,117,101,45,50,49,3,0,24,1,114,3,6,110,111,100,101,115,48,19,6,110,111,100,101,115,49,22,6,110,111,100,101,115,50,25,4,0,14,108,98,45,103,114,97,112,104,45,97,114,101,110,97,3,0,26,1,114,2,4,114,111,111,116,4,5,110,111,100,101,115,27,4,0,15,108,98,45,103,114,97,112,104,45,118,97,108,117,101,48,3,0,28,1,114,1,5,105,110,100,101,120,121,4,0,13,108,98,45,103,114,97,112,104,45,114,101,102,49,3,0,30,1,114,2,4,114,111,111,116,31,5,110,111,100,101,115,27,4,0,15,108,98,45,103,114,97,112,104,45,118,97,108,117,101,49,3,0,32,1,114,1,5,105,110,100,101,120,121,4,0,13,108,98,45,103,114,97,112,104,45,114,101,102,50,3,0,34,1,114,2,4,114,111,111,116,35,5,110,111,100,101,115,27,4,0,15,108,98,45,103,114,97,112,104,45,118,97,108,117,101,50,3,0,36,4,0,33,102,117,110,99,116,105,111,110,45,55,49,51,99,52,50,56,52,100,56,52,52,56,51,99,51,102,56,50,100,53,98,56,100,3,1,1,104,38,1,105,38,4,0,33,102,117,110,99,116,105,111,110,45,97,50,54,55,97,55,102,101,100,51,102,102,50,51,99,102,52,54,102,49,51,55,98,98,3,1,1,104,41,1,105,41,4,0,33,102,117,110,99,116,105,111,110,45,49,49,53,55,100,100,49,50,100,99,48,98,56,100,102,55,98,51,56,101,50,99,101,49,3,1,1,104,44,1,105,44,4,0,33,102,117,110,99,116,105,111,110,45,54,52,101,52,48,101,55,97,101,102,52,98,56,99,51,51,98,100,53,57,99,48,101,98,3,1,1,104,47,1,105,47,4,0,33,102,117,110,99,116,105,111,110,45,50,48,56,54,51,100,57,99,102,54,56,102,101,54,52,102,53,48,53,48,48,52,57,49,3,1,1,104,50,1,105,50,4,0,33,102,117,110,99,116,105,111,110,45,98,54,100,53,48,100,51,53,100,51,101,102,53,55,49,52,100,55,102,54,98,49,55,101,3,1,1,104,53,1,105,53,1,64,1,4,97,114,103,48,39,0,2,4,0,9,99,97,108,108,45,104,111,115,116,1,56,1,64,1,4,97,114,103,48,42,0,33,4,0,19,99,97,108,108,45,104,111,115,116,45,99,111,110,116,97,105,110,101,114,1,57,1,64,1,4,97,114,103,48,45,0,2,4,0,15,99,97,108,108,45,104,111,115,116,45,109,105,120,101,100,1,58,1,64,1,4,97,114,103,48,2,0,49,4,0,12,109,97,107,101,45,99,108,111,115,117,114,101,1,59,1,64,1,4,97,114,103,48,2,0,52,4,0,22,109,97,107,101,45,99,111,110,116,97,105,110,101,114,45,99,108,111,115,117,114,101,1,60,1,64,1,4,97,114,103,48,2,0,55,4,0,18,109,97,107,101,45,109,105,120,101,100,45,99,108,111,115,117,114,101,1,61,1,64,2,4,115,101,108,102,39,4,97,114,103,48,2,0,2,4,0,40,105,110,118,111,107,101,45,102,117,110,99,116,105,111,110,45,55,49,51,99,52,50,56,52,100,56,52,52,56,51,99,51,102,56,50,100,53,98,56,100,1,62,1,64,2,4,115,101,108,102,42,4,97,114,103,48,29,0,33,4,0,40,105,110,118,111,107,101,45,102,117,110,99,116,105,111,110,45,97,50,54,55,97,55,102,101,100,51,102,102,50,51,99,102,52,54,102,49,51,55,98,98,1,63,1,64,3,4,115,101,108,102,45,4,97,114,103,48,2,4,97,114,103,49,2,0,2,4,0,40,105,110,118,111,107,101,45,102,117,110,99,116,105,111,110,45,49,49,53,55,100,100,49,50,100,99,48,98,56,100,102,55,98,51,56,101,50,99,101,49,1,64,1,64,2,4,115,101,108,102,48,4,97,114,103,48,2,0,2,4,0,40,105,110,118,111,107,101,45,102,117,110,99,116,105,111,110,45,54,52,101,52,48,101,55,97,101,102,52,98,56,99,51,51,98,100,53,57,99,48,101,98,1,65,1,64,2,4,115,101,108,102,51,4,97,114,103,48,37,0,29,4,0,40,105,110,118,111,107,101,45,102,117,110,99,116,105,111,110,45,50,48,56,54,51,100,57,99,102,54,56,102,101,54,52,102,53,48,53,48,48,52,57,49,1,66,1,64,3,4,115,101,108,102,54,4,97,114,103,48,2,4,97,114,103,49,2,0,2,4,0,40,105,110,118,111,107,101,45,102,117,110,99,116,105,111,110,45,98,54,100,53,48,100,51,53,100,51,101,102,53,55,49,52,100,55,102,54,98,49,55,101,1,67,10,47,1,0,42,108,101,97,110,45,98,114,105,100,103,101,58,99,97,108,108,98,97,99,107,45,115,117,98,116,121,112,101,115,47,110,97,116,105,118,101,64,49,46,48,46,48,5,0,6,163,3,21,3,0,0,14,98,114,105,100,103,101,45,118,97,108,117,101,45,48,3,0,0,13,108,98,45,103,114,97,112,104,45,114,101,102,48,3,0,0,14,98,114,105,100,103,101,45,118,97,108,117,101,45,51,3,0,0,14,98,114,105,100,103,101,45,118,97,108,117,101,45,52,3,0,0,14,98,114,105,100,103,101,45,118,97,108,117,101,45,54,3,0,0,14,98,114,105,100,103,101,45,118,97,108,117,101,45,55,3,0,0,14,98,114,105,100,103,101,45,118,97,108,117,101,45,56,3,0,0,14,98,114,105,100,103,101,45,118,97,108,117,101,45,57,3,0,0,14,108,98,45,103,114,97,112,104,45,110,111,100,101,48,3,0,0,21,98,114,105,100,103,101,45,97,108,105,97,115,45,118,97,108,117,101,45,49,55,3,0,0,14,108,98,45,103,114,97,112,104,45,110,111,100,101,49,3,0,0,21,98,114,105,100,103,101,45,97,108,105,97,115,45,118,97,108,117,101,45,49,57,3,0,0,14,108,98,45,103,114,97,112,104,45,110,111,100,101,50,3,0,0,21,98,114,105,100,103,101,45,97,108,105,97,115,45,118,97,108,117,101,45,50,49,3,0,0,14,108,98,45,103,114,97,112,104,45,97,114,101,110,97,3,0,0,15,108,98,45,103,114,97,112,104,45,118,97,108,117,101,48,3,0,0,13,108,98,45,103,114,97,112,104,45,114,101,102,49,3,0,0,15,108,98,45,103,114,97,112,104,45,118,97,108,117,101,49,3,0,0,13,108,98,45,103,114,97,112,104,45,114,101,102,50,3,0,0,15,108,98,45,103,114,97,112,104,45,118,97,108,117,101,50,3,0,0,33,102,117,110,99,116,105,111,110,45,55,49,51,99,52,50,56,52,100,56,52,52,56,51,99,51,102,56,50,100,53,98,56,100,7,5,2,104,21,105,21,6,38,1,3,0,0,33,102,117,110,99,116,105,111,110,45,97,50,54,55,97,55,102,101,100,51,102,102,50,51,99,102,52,54,102,49,51,55,98,98,7,5,2,104,24,105,24,6,38,1,3,0,0,33,102,117,110,99,116,105,111,110,45,49,49,53,55,100,100,49,50,100,99,48,98,56,100,102,55,98,51,56,101,50,99,101,49,7,5,2,104,27,105,27,6,38,1,3,0,0,33,102,117,110,99,116,105,111,110,45,54,52,101,52,48,101,55,97,101,102,52,98,56,99,51,51,98,100,53,57,99,48,101,98,7,5,2,104,30,105,30,6,38,1,3,0,0,33,102,117,110,99,116,105,111,110,45,50,48,56,54,51,100,57,99,102,54,56,102,101,54,52,102,53,48,53,48,48,52,57,49,7,5,2,104,33,105,33,6,38,1,3,0,0,33,102,117,110,99,116,105,111,110,45,98,54,100,53,48,100,51,53,100,51,101,102,53,55,49,52,100,55,102,54,98,49,55,101,7,5,2,104,36,105,36,6,128,3,12,1,0,0,9,99,97,108,108,45,104,111,115,116,1,0,0,19,99,97,108,108,45,104,111,115,116,45,99,111,110,116,97,105,110,101,114,1,0,0,15,99,97,108,108,45,104,111,115,116,45,109,105,120,101,100,1,0,0,12,109,97,107,101,45,99,108,111,115,117,114,101,1,0,0,22,109,97,107,101,45,99,111,110,116,97,105,110,101,114,45,99,108,111,115,117,114,101,1,0,0,18,109,97,107,101,45,109,105,120,101,100,45,99,108,111,115,117,114,101,1,0,0,40,105,110,118,111,107,101,45,102,117,110,99,116,105,111,110,45,55,49,51,99,52,50,56,52,100,56,52,52,56,51,99,51,102,56,50,100,53,98,56,100,1,0,0,40,105,110,118,111,107,101,45,102,117,110,99,116,105,111,110,45,97,50,54,55,97,55,102,101,100,51,102,102,50,51,99,102,52,54,102,49,51,55,98,98,1,0,0,40,105,110,118,111,107,101,45,102,117,110,99,116,105,111,110,45,49,49,53,55,100,100,49,50,100,99,48,98,56,100,102,55,98,51,56,101,50,99,101,49,1,0,0,40,105,110,118,111,107,101,45,102,117,110,99,116,105,111,110,45,54,52,101,52,48,101,55,97,101,102,52,98,56,99,51,51,98,100,53,57,99,48,101,98,1,0,0,40,105,110,118,111,107,101,45,102,117,110,99,116,105,111,110,45,50,48,56,54,51,100,57,99,102,54,56,102,101,54,52,102,53,48,53,48,48,52,57,49,1,0,0,40,105,110,118,111,107,101,45,102,117,110,99,116,105,111,110,45,98,54,100,53,48,100,51,53,100,51,101,102,53,55,49,52,100,55,102,54,98,49,55,101,1,197,3,0,97,115,109,1,0,0,0,1,28,6,96,0,0,96,4,127,127,127,127,1,127,96,1,127,0,96,1,126,0,96,1,125,0,96,1,124,0,3,8,7,0,0,1,2,3,4,5,5,5,1,1,1,128,8,6,12,2,127,1,65,144,2,11,127,1,65,0,11,7,72,7,6,109,101,109,111,114,121,2,0,5,101,110,116,101,114,0,0,7,114,101,97,108,108,111,99,0,2,8,112,111,115,116,45,105,51,50,0,3,8,112,111,115,116,45,105,54,52,0,4,8,112,111,115,116,45,102,51,50,0,5,8,112,111,115,116,45,102,54,52,0,6,10,206,1,7,29,0,35,1,65,192,0,79,4,64,0,11,35,1,65,2,116,35,0,54,2,16,35,1,65,1,106,36,1,11,36,0,35,1,69,4,64,0,11,35,1,65,1,107,36,1,35,1,69,4,127,65,144,2,5,35,1,65,2,116,40,2,16,11,36,0,11,117,1,3,127,32,3,69,4,64,65,0,15,11,35,0,32,2,65,1,107,106,65,0,32,2,107,113,33,4,32,4,32,3,106,33,5,32,5,32,4,73,32,5,65,128,128,128,32,75,114,4,64,0,11,32,5,65,255,255,3,106,65,16,118,33,6,32,6,63,0,75,4,64,32,6,63,0,107,64,0,65,127,70,4,64,0,11,11,32,0,4,64,32,4,32,0,32,1,32,3,32,1,32,3,73,27,252,10,0,0,11,32,5,36,0,32,4,11,4,0,16,1,11,4,0,16,1,11,4,0,16,1,11,4,0,16,1,11,0,99,4,110,97,109,101,0,10,9,97,108,108,111,99,97,116,111,114,1,8,1,1,5,108,101,97,118,101,2,54,1,2,7,0,3,111,108,100,1,8,111,108,100,45,115,105,122,101,2,9,97,108,105,103,110,109,101,110,116,3,4,115,105,122,101,4,5,115,116,97,114,116,5,3,101,110,100,6,5,112,97,103,101,115,7,14,2,0,4,104,101,97,112,1,5,100,101,112,116,104,2,4,1,0,0,0,6,76,6,0,2,1,0,6,109,101,109,111,114,121,0,0,1,0,7,114,101,97,108,108,111,99,0,0,1,0,8,112,111,115,116,45,105,51,50,0,0,1,0,8,112,111,115,116,45,105,54,52,0,0,1,0,8,112,111,115,116,45,102,51,50,0,0,1,0,8,112,111,115,116,45,102,54,52,8,109,18,1,0,0,2,3,0,4,0,1,0,1,2,3,0,4,0,1,0,2,2,3,0,4,0,1,0,3,2,3,0,4,0,1,0,4,2,3,0,4,0,1,0,5,2,3,0,4,0,1,0,6,2,3,0,4,0,1,0,7,2,3,0,4,0,1,0,8,2,3,0,4,0,1,0,9,2,3,0,4,0,1,0,10,2,3,0,4,0,1,0,11,2,3,0,4,0,3,21,3,24,3,27,3,30,3,33,3,36,1,180,8,0,97,115,109,1,0,0,0,1,88,12,96,4,127,127,127,127,1,127,96,0,0,96,1,127,0,96,2,127,127,0,96,2,127,127,1,127,96,4,127,127,127,127,0,96,9,127,127,127,127,127,127,127,127,127,0,96,6,127,127,127,127,127,127,0,96,1,127,1,127,96,3,127,127,127,1,127,96,8,127,127,127,127,127,127,127,127,1,127,96,5,127,127,127,127,127,1,127,2,170,2,21,10,97,108,108,111,99,97,116,105,111,110,7,114,101,97,108,108,111,99,0,0,10,97,108,108,111,99,97,116,105,111,110,6,109,101,109,111,114,121,2,0,1,10,97,108,108,111,99,97,116,105,111,110,5,101,110,116,101,114,0,1,9,114,101,115,111,117,114,99,101,115,6,100,114,111,112,50,50,0,2,9,114,101,115,111,117,114,99,101,115,6,100,114,111,112,50,51,0,2,9,114,101,115,111,117,114,99,101,115,6,100,114,111,112,50,52,0,2,9,114,101,115,111,117,114,99,101,115,6,100,114,111,112,50,53,0,2,9,114,101,115,111,117,114,99,101,115,6,100,114,111,112,50,54,0,2,9,114,101,115,111,117,114,99,101,115,6,100,114,111,112,50,55,0,2,4,104,111,115,116,2,102,48,0,3,4,104,111,115,116,2,102,49,0,3,4,104,111,115,116,2,102,50,0,3,4,104,111,115,116,2,102,51,0,4,4,104,111,115,116,2,102,52,0,4,4,104,111,115,116,2,102,53,0,4,4,104,111,115,116,2,102,54,0,5,4,104,111,115,116,2,102,55,0,6,4,104,111,115,116,2,102,56,0,7,4,104,111,115,116,2,102,57,0,5,4,104,111,115,116,3,102,49,48,0,6,4,104,111,115,116,3,102,49,49,0,7,3,13,12,8,8,8,4,4,4,9,10,11,9,10,11,7,63,12,2,102,48,0,20,2,102,49,0,21,2,102,50,0,22,2,102,51,0,23,2,102,52,0,24,2,102,53,0,25,2,102,54,0,26,2,102,55,0,27,2,102,56,0,28,2,102,57,0,29,3,102,49,48,0,30,3,102,49,49,0,31,10,237,2,12,30,1,1,127,16,1,65,0,65,0,65,4,65,8,16,0,33,1,32,0,32,1,16,8,32,0,16,2,32,1,11,30,1,1,127,16,1,65,0,65,0,65,4,65,28,16,0,33,1,32,0,32,1,16,9,32,0,16,3,32,1,11,30,1,1,127,16,1,65,0,65,0,65,4,65,8,16,0,33,1,32,0,32,1,16,10,32,0,16,4,32,1,11,10,0,16,1,32,0,32,1,16,11,11,10,0,16,1,32,0,32,1,16,12,11,10,0,16,1,32,0,32,1,16,13,11,34,1,1,127,16,1,65,0,65,0,65,4,65,8,16,0,33,3,32,0,32,1,32,2,32,3,16,14,32,0,16,2,32,3,11,44,1,1,127,16,1,65,0,65,0,65,4,65,28,16,0,33,8,32,0,32,1,32,2,32,3,32,4,32,5,32,6,32,7,32,8,16,15,32,0,16,3,32,8,11,38,1,1,127,16,1,65,0,65,0,65,4,65,8,16,0,33,5,32,0,32,1,32,2,32,3,32,4,32,5,16,16,32,0,16,4,32,5,11,34,1,1,127,16,1,65,0,65,0,65,4,65,8,16,0,33,3,32,0,32,1,32,2,32,3,16,17,32,0,16,5,32,3,11,44,1,1,127,16,1,65,0,65,0,65,4,65,28,16,0,33,8,32,0,32,1,32,2,32,3,32,4,32,5,32,6,32,7,32,8,16,18,32,0,16,6,32,8,11,38,1,1,127,16,1,65,0,65,0,65,4,65,8,16,0,33,5,32,0,32,1,32,2,32,3,32,4,32,5,16,19,32,0,16,7,32,5,11,0,226,1,4,110,97,109,101,0,8,7,102,111,114,119,97,114,100,1,116,20,0,8,97,108,108,111,99,97,116,101,1,5,101,110,116,101,114,2,6,100,114,111,112,50,50,3,6,100,114,111,112,50,51,4,6,100,114,111,112,50,52,5,6,100,114,111,112,50,53,6,6,100,114,111,112,50,54,7,6,100,114,111,112,50,55,8,2,102,48,9,2,102,49,10,2,102,50,11,2,102,51,12,2,102,52,13,2,102,53,14,2,102,54,15,2,102,55,16,2,102,56,17,2,102,57,18,3,102,49,48,19,3,102,49,49,2,91,9,20,1,1,6,114,101,115,117,108,116,21,1,1,6,114,101,115,117,108,116,22,1,1,6,114,101,115,117,108,116,26,1,3,6,114,101,115,117,108,116,27,1,8,6,114,101,115,117,108,116,28,1,5,6,114,101,115,117,108,116,29,1,3,6,114,101,115,117,108,116,30,1,8,6,114,101,115,117,108,116,31,1,5,6,114,101,115,117,108,116,2,156,1,3,1,12,2,102,48,0,5,2,102,49,0,6,2,102,50,0,7,2,102,51,0,8,2,102,52,0,9,2,102,53,0,10,2,102,54,0,11,2,102,55,0,12,2,102,56,0,13,2,102,57,0,14,3,102,49,48,0,15,3,102,49,49,0,16,1,6,6,100,114,111,112,50,50,0,17,6,100,114,111,112,50,51,0,18,6,100,114,111,112,50,52,0,19,6,100,114,111,112,50,53,0,20,6,100,114,111,112,50,54,0,21,6,100,114,111,112,50,55,0,22,0,1,3,10,97,108,108,111,99,97,116,105,111,110,18,0,4,104,111,115,116,18,1,9,114,101,115,111,117,114,99,101,115,18,2,6,87,12,0,0,1,3,2,102,48,0,0,1,3,2,102,49,0,0,1,3,2,102,50,0,0,1,3,2,102,51,0,0,1,3,2,102,52,0,0,1,3,2,102,53,0,0,1,3,2,102,54,0,0,1,3,2,102,55,0,0,1,3,2,102,56,0,0,1,3,2,102,57,0,0,1,3,3,102,49,48,0,0,1,3,3,102,49,49,7,11,1,64,1,4,97,114,103,48,22,0,1,8,12,1,0,0,23,3,3,0,4,0,5,1,39,7,11,1,64,1,4,97,114,103,48,25,0,18,8,12,1,0,0,24,3,3,0,4,0,5,1,40,7,11,1,64,1,4,97,114,103,48,28,0,1,8,12,1,0,0,25,3,3,0,4,0,5,1,41,7,11,1,64,1,4,97,114,103,48,1,0,32,8,12,1,0,0,26,3,3,0,4,0,5,1,42,7,11,1,64,1,4,97,114,103,48,1,0,35,8,12,1,0,0,27,3,3,0,4,0,5,1,43,7,11,1,64,1,4,97,114,103,48,1,0,38,8,12,1,0,0,28,3,3,0,4,0,5,1,44,7,17,1,64,2,4,115,101,108,102,22,4,97,114,103,48,1,0,1,8,12,1,0,0,29,3,3,0,4,0,5,1,45,7,17,1,64,2,4,115,101,108,102,25,4,97,114,103,48,16,0,18,8,12,1,0,0,30,3,3,0,4,0,5,1,46,7,23,1,64,3,4,115,101,108,102,28,4,97,114,103,48,1,4,97,114,103,49,1,0,1,8,12,1,0,0,31,3,3,0,4,0,5,1,47,7,17,1,64,2,4,115,101,108,102,31,4,97,114,103,48,1,0,1,8,12,1,0,0,32,3,3,0,4,0,5,1,48,7,17,1,64,2,4,115,101,108,102,34,4,97,114,103,48,20,0,16,8,12,1,0,0,33,3,3,0,4,0,5,1,49,7,23,1,64,3,4,115,101,108,102,37,4,97,114,103,48,1,4,97,114,103,49,1,0,1,8,12,1,0,0,34,3,3,0,4,0,5,1,50,7,247,10,1,66,88,2,3,2,1,1,4,0,14,98,114,105,100,103,101,45,118,97,108,117,101,45,48,3,0,0,2,3,2,1,2,4,0,13,108,98,45,103,114,97,112,104,45,114,101,102,48,3,0,2,2,3,2,1,3,4,0,14,98,114,105,100,103,101,45,118,97,108,117,101,45,51,3,0,4,2,3,2,1,4,4,0,14,98,114,105,100,103,101,45,118,97,108,117,101,45,52,3,0,6,2,3,2,1,5,4,0,14,98,114,105,100,103,101,45,118,97,108,117,101,45,54,3,0,8,2,3,2,1,6,4,0,14,98,114,105,100,103,101,45,118,97,108,117,101,45,55,3,0,10,2,3,2,1,7,4,0,14,98,114,105,100,103,101,45,118,97,108,117,101,45,56,3,0,12,2,3,2,1,8,4,0,14,98,114,105,100,103,101,45,118,97,108,117,101,45,57,3,0,14,2,3,2,1,9,4,0,14,108,98,45,103,114,97,112,104,45,110,111,100,101,48,3,0,16,2,3,2,1,10,4,0,21,98,114,105,100,103,101,45,97,108,105,97,115,45,118,97,108,117,101,45,49,55,3,0,18,2,3,2,1,11,4,0,14,108,98,45,103,114,97,112,104,45,110,111,100,101,49,3,0,20,2,3,2,1,12,4,0,21,98,114,105,100,103,101,45,97,108,105,97,115,45,118,97,108,117,101,45,49,57,3,0,22,2,3,2,1,13,4,0,14,108,98,45,103,114,97,112,104,45,110,111,100,101,50,3,0,24,2,3,2,1,14,4,0,21,98,114,105,100,103,101,45,97,108,105,97,115,45,118,97,108,117,101,45,50,49,3,0,26,2,3,2,1,15,4,0,14,108,98,45,103,114,97,112,104,45,97,114,101,110,97,3,0,28,2,3,2,1,16,4,0,15,108,98,45,103,114,97,112,104,45,118,97,108,117,101,48,3,0,30,2,3,2,1,17,4,0,13,108,98,45,103,114,97,112,104,45,114,101,102,49,3,0,32,2,3,2,1,18,4,0,15,108,98,45,103,114,97,112,104,45,118,97,108,117,101,49,3,0,34,2,3,2,1,19,4,0,13,108,98,45,103,114,97,112,104,45,114,101,102,50,3,0,36,2,3,2,1,20,4,0,15,108,98,45,103,114,97,112,104,45,118,97,108,117,101,50,3,0,38,2,3,2,1,21,4,0,33,102,117,110,99,116,105,111,110,45,55,49,51,99,52,50,56,52,100,56,52,52,56,51,99,51,102,56,50,100,53,98,56,100,3,0,40,1,104,41,1,105,41,2,3,2,1,24,4,0,33,102,117,110,99,116,105,111,110,45,97,50,54,55,97,55,102,101,100,51,102,102,50,51,99,102,52,54,102,49,51,55,98,98,3,0,44,1,104,45,1,105,45,2,3,2,1,27,4,0,33,102,117,110,99,116,105,111,110,45,49,49,53,55,100,100,49,50,100,99,48,98,56,100,102,55,98,51,56,101,50,99,101,49,3,0,48,1,104,49,1,105,49,2,3,2,1,30,4,0,33,102,117,110,99,116,105,111,110,45,54,52,101,52,48,101,55,97,101,102,52,98,56,99,51,51,98,100,53,57,99,48,101,98,3,0,52,1,104,53,1,105,53,2,3,2,1,33,4,0,33,102,117,110,99,116,105,111,110,45,50,48,56,54,51,100,57,99,102,54,56,102,101,54,52,102,53,48,53,48,48,52,57,49,3,0,56,1,104,57,1,105,57,2,3,2,1,36,4,0,33,102,117,110,99,116,105,111,110,45,98,54,100,53,48,100,51,53,100,51,101,102,53,55,49,52,100,55,102,54,98,49,55,101,3,0,60,1,104,61,1,105,61,1,64,1,4,97,114,103,48,42,0,1,4,0,9,99,97,108,108,45,104,111,115,116,1,64,1,64,1,4,97,114,103,48,46,0,35,4,0,19,99,97,108,108,45,104,111,115,116,45,99,111,110,116,97,105,110,101,114,1,65,1,64,1,4,97,114,103,48,50,0,1,4,0,15,99,97,108,108,45,104,111,115,116,45,109,105,120,101,100,1,66,1,64,1,4,97,114,103,48,1,0,55,4,0,12,109,97,107,101,45,99,108,111,115,117,114,101,1,67,1,64,1,4,97,114,103,48,1,0,59,4,0,22,109,97,107,101,45,99,111,110,116,97,105,110,101,114,45,99,108,111,115,117,114,101,1,68,1,64,1,4,97,114,103,48,1,0,63,4,0,18,109,97,107,101,45,109,105,120,101,100,45,99,108,111,115,117,114,101,1,69,1,64,2,4,115,101,108,102,42,4,97,114,103,48,1,0,1,4,0,40,105,110,118,111,107,101,45,102,117,110,99,116,105,111,110,45,55,49,51,99,52,50,56,52,100,56,52,52,56,51,99,51,102,56,50,100,53,98,56,100,1,70,1,64,2,4,115,101,108,102,46,4,97,114,103,48,31,0,35,4,0,40,105,110,118,111,107,101,45,102,117,110,99,116,105,111,110,45,97,50,54,55,97,55,102,101,100,51,102,102,50,51,99,102,52,54,102,49,51,55,98,98,1,71,1,64,3,4,115,101,108,102,50,4,97,114,103,48,1,4,97,114,103,49,1,0,1,4,0,40,105,110,118,111,107,101,45,102,117,110,99,116,105,111,110,45,49,49,53,55,100,100,49,50,100,99,48,98,56,100,102,55,98,51,56,101,50,99,101,49,1,72,1,64,2,4,115,101,108,102,54,4,97,114,103,48,1,0,1,4,0,40,105,110,118,111,107,101,45,102,117,110,99,116,105,111,110,45,54,52,101,52,48,101,55,97,101,102,52,98,56,99,51,51,98,100,53,57,99,48,101,98,1,73,1,64,2,4,115,101,108,102,58,4,97,114,103,48,39,0,31,4,0,40,105,110,118,111,107,101,45,102,117,110,99,116,105,111,110,45,50,48,56,54,51,100,57,99,102,54,56,102,101,54,52,102,53,48,53,48,48,52,57,49,1,74,1,64,3,4,115,101,108,102,62,4,97,114,103,48,1,4,97,114,103,49,1,0,1,4,0,40,105,110,118,111,107,101,45,102,117,110,99,116,105,111,110,45,98,54,100,53,48,100,51,53,100,51,101,102,53,55,49,52,100,55,102,54,98,49,55,101,1,75,5,221,7,1,1,38,0,14,98,114,105,100,103,101,45,118,97,108,117,101,45,48,3,1,0,13,108,98,45,103,114,97,112,104,45,114,101,102,48,3,2,0,14,98,114,105,100,103,101,45,118,97,108,117,101,45,51,3,3,0,14,98,114,105,100,103,101,45,118,97,108,117,101,45,52,3,4,0,14,98,114,105,100,103,101,45,118,97,108,117,101,45,54,3,5,0,14,98,114,105,100,103,101,45,118,97,108,117,101,45,55,3,6,0,14,98,114,105,100,103,101,45,118,97,108,117,101,45,56,3,7,0,14,98,114,105,100,103,101,45,118,97,108,117,101,45,57,3,8,0,14,108,98,45,103,114,97,112,104,45,110,111,100,101,48,3,9,0,21,98,114,105,100,103,101,45,97,108,105,97,115,45,118,97,108,117,101,45,49,55,3,10,0,14,108,98,45,103,114,97,112,104,45,110,111,100,101,49,3,11,0,21,98,114,105,100,103,101,45,97,108,105,97,115,45,118,97,108,117,101,45,49,57,3,12,0,14,108,98,45,103,114,97,112,104,45,110,111,100,101,50,3,13,0,21,98,114,105,100,103,101,45,97,108,105,97,115,45,118,97,108,117,101,45,50,49,3,14,0,14,108,98,45,103,114,97,112,104,45,97,114,101,110,97,3,15,0,15,108,98,45,103,114,97,112,104,45,118,97,108,117,101,48,3,16,0,13,108,98,45,103,114,97,112,104,45,114,101,102,49,3,17,0,15,108,98,45,103,114,97,112,104,45,118,97,108,117,101,49,3,18,0,13,108,98,45,103,114,97,112,104,45,114,101,102,50,3,19,0,15,108,98,45,103,114,97,112,104,45,118,97,108,117,101,50,3,20,0,33,102,117,110,99,116,105,111,110,45,55,49,51,99,52,50,56,52,100,56,52,52,56,51,99,51,102,56,50,100,53,98,56,100,3,21,0,33,102,117,110,99,116,105,111,110,45,97,50,54,55,97,55,102,101,100,51,102,102,50,51,99,102,52,54,102,49,51,55,98,98,3,24,0,33,102,117,110,99,116,105,111,110,45,49,49,53,55,100,100,49,50,100,99,48,98,56,100,102,55,98,51,56,101,50,99,101,49,3,27,0,33,102,117,110,99,116,105,111,110,45,54,52,101,52,48,101,55,97,101,102,52,98,56,99,51,51,98,100,53,57,99,48,101,98,3,30,0,33,102,117,110,99,116,105,111,110,45,50,48,56,54,51,100,57,99,102,54,56,102,101,54,52,102,53,48,53,48,48,52,57,49,3,33,0,33,102,117,110,99,116,105,111,110,45,98,54,100,53,48,100,51,53,100,51,101,102,53,55,49,52,100,55,102,54,98,49,55,101,3,36,0,9,99,97,108,108,45,104,111,115,116,1,12,0,19,99,97,108,108,45,104,111,115,116,45,99,111,110,116,97,105,110,101,114,1,13,0,15,99,97,108,108,45,104,111,115,116,45,109,105,120,101,100,1,14,0,12,109,97,107,101,45,99,108,111,115,117,114,101,1,15,0,22,109,97,107,101,45,99,111,110,116,97,105,110,101,114,45,99,108,111,115,117,114,101,1,16,0,18,109,97,107,101,45,109,105,120,101,100,45,99,108,111,115,117,114,101,1,17,0,40,105,110,118,111,107,101,45,102,117,110,99,116,105,111,110,45,55,49,51,99,52,50,56,52,100,56,52,52,56,51,99,51,102,56,50,100,53,98,56,100,1,18,0,40,105,110,118,111,107,101,45,102,117,110,99,116,105,111,110,45,97,50,54,55,97,55,102,101,100,51,102,102,50,51,99,102,52,54,102,49,51,55,98,98,1,19,0,40,105,110,118,111,107,101,45,102,117,110,99,116,105,111,110,45,49,49,53,55,100,100,49,50,100,99,48,98,56,100,102,55,98,51,56,101,50,99,101,49,1,20,0,40,105,110,118,111,107,101,45,102,117,110,99,116,105,111,110,45,54,52,101,52,48,101,55,97,101,102,52,98,56,99,51,51,98,100,53,57,99,48,101,98,1,21,0,40,105,110,118,111,107,101,45,102,117,110,99,116,105,111,110,45,50,48,56,54,51,100,57,99,102,54,56,102,101,54,52,102,53,48,53,48,48,52,57,49,1,22,0,40,105,110,118,111,107,101,45,102,117,110,99,116,105,111,110,45,98,54,100,53,48,100,51,53,100,51,101,102,53,55,49,52,100,55,102,54,98,49,55,101,1,23,11,47,1,0,39,108,101,97,110,45,98,114,105,100,103,101,58,99,97,108,108,98,97,99,107,45,115,117,98,116,121,112,101,115,47,97,112,105,64,49,46,48,46,48,5,1,1,5,51,0,183,8,14,99,111,109,112,111,110,101,110,116,45,110,97,109,101,1,192,2,0,0,35,0,7,114,101,97,108,108,111,99,1,8,112,111,115,116,45,105,51,50,2,8,112,111,115,116,45,105,54,52,3,8,112,111,115,116,45,102,51,50,4,8,112,111,115,116,45,102,54,52,5,6,108,111,119,101,114,48,6,6,108,111,119,101,114,49,7,6,108,111,119,101,114,50,8,6,108,111,119,101,114,51,9,6,108,111,119,101,114,52,10,6,108,111,119,101,114,53,11,6,108,111,119,101,114,54,12,6,108,111,119,101,114,55,13,6,108,111,119,101,114,56,14,6,108,111,119,101,114,57,15,7,108,111,119,101,114,49,48,16,7,108,111,119,101,114,49,49,17,6,100,114,111,112,50,50,18,6,100,114,111,112,50,51,19,6,100,114,111,112,50,52,20,6,100,114,111,112,50,53,21,6,100,114,111,112,50,54,22,6,100,114,111,112,50,55,23,8,102,111,114,119,97,114,100,48,24,8,102,111,114,119,97,114,100,49,25,8,102,111,114,119,97,114,100,50,26,8,102,111,114,119,97,114,100,51,27,8,102,111,114,119,97,114,100,52,28,8,102,111,114,119,97,114,100,53,29,8,102,111,114,119,97,114,100,54,30,8,102,111,114,119,97,114,100,55,31,8,102,111,114,119,97,114,100,56,32,8,102,111,114,119,97,114,100,57,33,9,102,111,114,119,97,114,100,49,48,34,9,102,111,114,119,97,114,100,49,49,1,11,0,2,1,0,6,109,101,109,111,114,121,1,23,0,17,2,0,9,97,108,108,111,99,97,116,111,114,1,7,102,111,114,119,97,114,100,1,46,0,18,4,0,10,97,108,108,111,99,97,116,105,111,110,1,7,105,109,112,111,114,116,115,2,9,114,101,115,111,117,114,99,101,115,3,9,102,111,114,119,97,114,100,101,100,1,138,1,1,24,0,5,104,111,115,116,48,1,5,104,111,115,116,49,2,5,104,111,115,116,50,3,5,104,111,115,116,51,4,5,104,111,115,116,52,5,5,104,111,115,116,53,6,5,104,111,115,116,54,7,5,104,111,115,116,55,8,5,104,111,115,116,56,9,5,104,111,115,116,57,10,6,104,111,115,116,49,48,11,6,104,111,115,116,49,49,12,2,102,48,13,2,102,49,14,2,102,50,15,2,102,51,16,2,102,52,17,2,102,53,18,2,102,54,19,2,102,55,20,2,102,56,21,2,102,57,22,3,102,49,48,23,3,102,49,49,1,237,3,3,40,0,3,97,112,105,1,7,112,117,98,108,105,99,48,2,7,112,117,98,108,105,99,50,3,7,112,117,98,108,105,99,51,4,7,112,117,98,108,105,99,52,5,7,112,117,98,108,105,99,54,6,7,112,117,98,108,105,99,55,7,7,112,117,98,108,105,99,56,8,7,112,117,98,108,105,99,57,9,8,112,117,98,108,105,99,49,54,10,8,112,117,98,108,105,99,49,55,11,8,112,117,98,108,105,99,49,56,12,8,112,117,98,108,105,99,49,57,13,8,112,117,98,108,105,99,50,48,14,8,112,117,98,108,105,99,50,49,15,8,112,117,98,108,105,99,49,48,16,8,112,117,98,108,105,99,49,49,17,8,112,117,98,108,105,99,49,50,18,8,112,117,98,108,105,99,49,51,19,8,112,117,98,108,105,99,49,52,20,8,112,117,98,108,105,99,49,53,21,16,112,117,98,108,105,99,82,101,115,111,117,114,99,101,50,50,22,14,112,117,98,108,105,99,66,111,114,114,111,119,50,50,23,11,112,117,98,108,105,99,79,119,110,50,50,24,16,112,117,98,108,105,99,82,101,115,111,117,114,99,101,50,51,25,14,112,117,98,108,105,99,66,111,114,114,111,119,50,51,26,11,112,117,98,108,105,99,79,119,110,50,51,27,16,112,117,98,108,105,99,82,101,115,111,117,114,99,101,50,52,28,14,112,117,98,108,105,99,66,111,114,114,111,119,50,52,29,11,112,117,98,108,105,99,79,119,110,50,52,30,16,112,117,98,108,105,99,82,101,115,111,117,114,99,101,50,53,31,14,112,117,98,108,105,99,66,111,114,114,111,119,50,53,32,11,112,117,98,108,105,99,79,119,110,50,53,33,16,112,117,98,108,105,99,82,101,115,111,117,114,99,101,50,54,34,14,112,117,98,108,105,99,66,111,114,114,111,119,50,54,35,11,112,117,98,108,105,99,79,119,110,50,54,36,16,112,117,98,108,105,99,82,101,115,111,117,114,99,101,50,55,37,14,112,117,98,108,105,99,66,111,114,114,111,119,50,55,38,11,112,117,98,108,105,99,79,119,110,50,55,51,10,112,117,98,108,105,99,45,97,112,105,1,16,5,2,0,4,104,111,115,116,1,6,112,117,98,108,105,99};
static wasmtime_error_t *lb_link(callbacksubtypes_wasmtime *session) {
  wasmtime_component_linker_instance_t *root = wasmtime_component_linker_root(session->linker), *host = NULL;
  wasmtime_error_t *error = wasmtime_component_linker_instance_add_instance(root, "lean-bridge:callback-subtypes/native@1.0.0", 42, &host);
  if (!error) {
    if (!error) {
      wasmtime_component_resource_type_t *type = wasmtime_component_resource_type_new_host(1);
      error = wasmtime_component_linker_instance_add_resource(host, "function-713c4284d84483c3f82d5b8d", 33, type, lb_proxy_drop, session, NULL);
      wasmtime_component_resource_type_delete(type);
    }
    if (!error) {
      wasmtime_component_resource_type_t *type = wasmtime_component_resource_type_new_host(2);
      error = wasmtime_component_linker_instance_add_resource(host, "function-a267a7fed3ff23cf46f137bb", 33, type, lb_proxy_drop, session, NULL);
      wasmtime_component_resource_type_delete(type);
    }
    if (!error) {
      wasmtime_component_resource_type_t *type = wasmtime_component_resource_type_new_host(3);
      error = wasmtime_component_linker_instance_add_resource(host, "function-1157dd12dc0b8df7b38e2ce1", 33, type, lb_proxy_drop, session, NULL);
      wasmtime_component_resource_type_delete(type);
    }
    if (!error) {
      wasmtime_component_resource_type_t *type = wasmtime_component_resource_type_new_host(4);
      error = wasmtime_component_linker_instance_add_resource(host, "function-64e40e7aef4b8c33bd59c0eb", 33, type, lb_proxy_drop, session, NULL);
      wasmtime_component_resource_type_delete(type);
    }
    if (!error) {
      wasmtime_component_resource_type_t *type = wasmtime_component_resource_type_new_host(5);
      error = wasmtime_component_linker_instance_add_resource(host, "function-20863d9cf68fe64f50500491", 33, type, lb_proxy_drop, session, NULL);
      wasmtime_component_resource_type_delete(type);
    }
    if (!error) {
      wasmtime_component_resource_type_t *type = wasmtime_component_resource_type_new_host(6);
      error = wasmtime_component_linker_instance_add_resource(host, "function-b6d50d35d3ef5714d7f6b17e", 33, type, lb_proxy_drop, session, NULL);
      wasmtime_component_resource_type_delete(type);
    }
    if (!error) error = wasmtime_component_linker_instance_add_func(host, "call-host", 9, lb_call_0, session, NULL);
    if (!error) error = wasmtime_component_linker_instance_add_func(host, "call-host-container", 19, lb_call_1, session, NULL);
    if (!error) error = wasmtime_component_linker_instance_add_func(host, "call-host-mixed", 15, lb_call_2, session, NULL);
    if (!error) error = wasmtime_component_linker_instance_add_func(host, "make-closure", 12, lb_call_3, session, NULL);
    if (!error) error = wasmtime_component_linker_instance_add_func(host, "make-container-closure", 22, lb_call_4, session, NULL);
    if (!error) error = wasmtime_component_linker_instance_add_func(host, "make-mixed-closure", 18, lb_call_5, session, NULL);
    if (!error) error = wasmtime_component_linker_instance_add_func(host, "invoke-function-713c4284d84483c3f82d5b8d", 40, lb_call_6, session, NULL);
    if (!error) error = wasmtime_component_linker_instance_add_func(host, "invoke-function-a267a7fed3ff23cf46f137bb", 40, lb_call_7, session, NULL);
    if (!error) error = wasmtime_component_linker_instance_add_func(host, "invoke-function-1157dd12dc0b8df7b38e2ce1", 40, lb_call_8, session, NULL);
    if (!error) error = wasmtime_component_linker_instance_add_func(host, "invoke-function-64e40e7aef4b8c33bd59c0eb", 40, lb_call_9, session, NULL);
    if (!error) error = wasmtime_component_linker_instance_add_func(host, "invoke-function-20863d9cf68fe64f50500491", 40, lb_call_10, session, NULL);
    if (!error) error = wasmtime_component_linker_instance_add_func(host, "invoke-function-b6d50d35d3ef5714d7f6b17e", 40, lb_call_11, session, NULL);
    wasmtime_component_linker_instance_delete(host);
  }
  wasmtime_component_linker_instance_delete(root); return error;
}
wasmtime_error_t *callbacksubtypes_wasmtime_link(wasmtime_component_linker_t *linker) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  (void)linker; return wasmtime_error_new("WIT callables require the owning session API");
}
static wasmtime_error_t *lb_refresh(callbacksubtypes_wasmtime *session) {
  if (session->store) wasmtime_store_delete(session->store);
  session->store = wasmtime_store_new(session->engine, NULL, NULL);
  wasmtime_error_t *error = wasmtime_component_linker_instantiate(session->linker, wasmtime_store_context(session->store), session->component, &session->instance);
  if (error) { wasmtime_store_delete(session->store); session->store = NULL; }
  return error;
}
static void lb_destroy(callbacksubtypes_wasmtime *session) {
  session->closing = true;
  for (size_t i = 0; i < LB_CAPACITY; ++i) { session->entries[i].closed = true; lb_entry_collect(&session->entries[i]); }
  if (session->linker) wasmtime_component_linker_delete(session->linker);
  if (session->store) wasmtime_store_delete(session->store);
  if (session->component) wasmtime_component_delete(session->component);
  if (session->engine) wasm_engine_delete(session->engine);
  free(session);
}
void callbacksubtypes_wasmtime_close(callbacksubtypes_wasmtime *session) {
  if (getpid() != lb_package_pid) return;
  if (!lb_thread(session)) return;
  session->closing = true;
  if (!session->depth) lb_destroy(session);
}
wasmtime_error_t *callbacksubtypes_wasmtime_open(callbacksubtypes_wasmtime **out) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(callbacksubtypes_wasmtime *)) || *out) return wasmtime_error_new("Session output requires a fresh initialized slot");
  if (callbacksubtypes_graph_initialize()) return wasmtime_error_new("Lean runtime is unavailable");
  callbacksubtypes_wasmtime *session = calloc(1, sizeof(*session));
  if (!session) return wasmtime_error_new("Cannot allocate Wasmtime session");
  session->thread = pthread_self(); session->process = getpid(); session->thread_serial = lb_thread_identity();
  if (!session->thread_serial) { free(session); return wasmtime_error_new("WIT thread identities exhausted"); }
  wasm_config_t *config = wasm_config_new();
  if (!config) { free(session); return wasmtime_error_new("Cannot allocate Wasmtime configuration"); }
  wasmtime_config_wasm_component_model_set(config, true);
  session->engine = wasm_engine_new_with_config(config);
  wasmtime_error_t *error = wasmtime_component_new(session->engine, lb_component, sizeof(lb_component), &session->component);
  if (!error) {
    session->linker = wasmtime_component_linker_new(session->engine);
    error = lb_link(session); if (!error) error = lb_refresh(session);
  }
  if (error) { lb_destroy(session); return error; }
  *out = session; return NULL;
}
wasmtime_error_t *callbacksubtypes_wasmtime_callback_create(callbacksubtypes_wasmtime *session, const char *signature,
    callbacksubtypes_wasmtime_callback callback, void *data, void (*release)(void *), callbacksubtypes_wasmtime_function *out) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  if (!lb_thread(session) || session->closing || !signature || !callback || !lb_buffer(out, 1, sizeof(*out), _Alignof(callbacksubtypes_wasmtime_function)) || *out)
    return wasmtime_error_new("Invalid WIT callback or wrong-thread session");
  if (!callbacksubtypes_graph_ready()) return wasmtime_error_new("Lean runtime is unavailable");
  uint32_t tag = 0;
  if (!strcmp(signature, "function-713c4284d84483c3f82d5b8d")) tag = 1;
  if (!strcmp(signature, "function-a267a7fed3ff23cf46f137bb")) tag = 2;
  if (!strcmp(signature, "function-1157dd12dc0b8df7b38e2ce1")) tag = 3;
  if (!strcmp(signature, "function-64e40e7aef4b8c33bd59c0eb")) tag = 4;
  if (!strcmp(signature, "function-20863d9cf68fe64f50500491")) tag = 5;
  if (!strcmp(signature, "function-b6d50d35d3ef5714d7f6b17e")) tag = 6;
  if (!tag) return wasmtime_error_new("Unknown WIT callable signature");
  lb_entry *entry = lb_entry_new(session, tag);
  if (!entry) return wasmtime_error_new("WIT callable capacity exhausted");
  entry->callback = callback; entry->data = data; entry->release = release;
  *out = entry->token; return NULL;
}
wasmtime_error_t *callbacksubtypes_wasmtime_function_close(callbacksubtypes_wasmtime *session, callbacksubtypes_wasmtime_function *function) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  if (!lb_thread(session) || session->closing || !lb_buffer(function, 1, sizeof(*function), _Alignof(callbacksubtypes_wasmtime_function))) return wasmtime_error_new("Invalid WIT function close or wrong-thread session");
  if (!*function) return NULL;
  lb_entry *entry = lb_entry_find(session, *function);
  if (!entry) return wasmtime_error_new("Closed or wrong-session WIT callable");
  entry->closed = true; *function = 0; lb_entry_collect(entry); return NULL;
}
static int lb_export(const char *name) {
  if (!name) return -1;
  if (!strcmp(name, "call-host")) return 0;
  if (!strcmp(name, "call-host-container")) return 1;
  if (!strcmp(name, "call-host-mixed")) return 2;
  if (!strcmp(name, "make-closure")) return 3;
  if (!strcmp(name, "make-container-closure")) return 4;
  if (!strcmp(name, "make-mixed-closure")) return 5;
  if (!strcmp(name, "invoke-function-713c4284d84483c3f82d5b8d")) return 6;
  if (!strcmp(name, "invoke-function-a267a7fed3ff23cf46f137bb")) return 7;
  if (!strcmp(name, "invoke-function-1157dd12dc0b8df7b38e2ce1")) return 8;
  if (!strcmp(name, "invoke-function-64e40e7aef4b8c33bd59c0eb")) return 9;
  if (!strcmp(name, "invoke-function-20863d9cf68fe64f50500491")) return 10;
  if (!strcmp(name, "invoke-function-b6d50d35d3ef5714d7f6b17e")) return 11;
  return -1;
}
static const size_t lb_arities[] = {1,1,1,1,1,1,2,2,3,2,2,3};
static const uint32_t lb_returns[] = {0,0,0,4,5,6,0,0,0,0,0,0};
static const bool lb_copied[] = {false,false,false,false,false,false,false,false,false,false,false,false};
static bool lb_validate(callbacksubtypes_wasmtime *session, int function, const callbacksubtypes_wasmtime_value *args, lb_entry **entries) {
  lb_graph_scope scope = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  bool valid = false;
  (void)session; (void)args; (void)entries;
  switch (function) {
  case 0: valid = ((entries[0] = lb_entry_find(session, args[0].function)) && entries[0]->tag == 1 && entries[0]->recovery); break;
  case 1: valid = ((entries[0] = lb_entry_find(session, args[0].function)) && entries[0]->tag == 2 && entries[0]->recovery); break;
  case 2: valid = ((entries[0] = lb_entry_find(session, args[0].function)) && entries[0]->tag == 3 && entries[0]->recovery); break;
  case 3: valid = (!args[0].function && lb_graph_decode_3(&args[0].value, &scope, NULL)); break;
  case 4: valid = (!args[0].function && lb_graph_decode_3(&args[0].value, &scope, NULL)); break;
  case 5: valid = (!args[0].function && lb_graph_decode_3(&args[0].value, &scope, NULL)); break;
  case 6: valid = ((entries[0] = lb_entry_find(session, args[0].function)) && entries[0]->tag == 1 && entries[0]->recovery) && (!args[1].function && lb_graph_decode_3(&args[1].value, &scope, NULL)); break;
  case 7: valid = ((entries[0] = lb_entry_find(session, args[0].function)) && entries[0]->tag == 2 && entries[0]->recovery) && (!args[1].function && lb_graph_decode_0(&args[1].value, &scope, NULL)); break;
  case 8: valid = ((entries[0] = lb_entry_find(session, args[0].function)) && entries[0]->tag == 3 && entries[0]->recovery) && (!args[1].function && lb_graph_decode_3(&args[1].value, &scope, NULL)) && (!args[2].function && lb_graph_decode_3(&args[2].value, &scope, NULL)); break;
  case 9: valid = ((entries[0] = lb_entry_find(session, args[0].function)) && entries[0]->tag == 4) && (!args[1].function && lb_graph_decode_3(&args[1].value, &scope, NULL)); break;
  case 10: valid = ((entries[0] = lb_entry_find(session, args[0].function)) && entries[0]->tag == 5) && (!args[1].function && lb_graph_decode_2(&args[1].value, &scope, NULL)); break;
  case 11: valid = ((entries[0] = lb_entry_find(session, args[0].function)) && entries[0]->tag == 6) && (!args[1].function && lb_graph_decode_3(&args[1].value, &scope, NULL)) && (!args[2].function && lb_graph_decode_3(&args[2].value, &scope, NULL)); break;
  default: break;
  }
  lb_scope_close(&scope.memory); return valid;
}
wasmtime_error_t *callbacksubtypes_wasmtime_invoke(callbacksubtypes_wasmtime *session, const char *name,
    const callbacksubtypes_wasmtime_value *args, size_t count, callbacksubtypes_wasmtime_value *out) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  if (!lb_thread(session) || session->closing || !out || (count && !args)) return wasmtime_error_new("Invalid WIT call or wrong-thread session");
  if (session->poisoned && session->depth) return wasmtime_error_new(session->first_error);
  int which = lb_export(name);
  if (which < 0 || count != lb_arities[which]) return wasmtime_error_new("Unknown WIT export or argument count");
  if (!lb_buffer(args, count, sizeof(*args), _Alignof(callbacksubtypes_wasmtime_value)) || !lb_buffer(out, 1, sizeof(*out), _Alignof(callbacksubtypes_wasmtime_value))) return wasmtime_error_new("Invalid WIT argument storage");
  lb_entry *entries[LB_MAX_ARGS] = {0};
  if (!lb_validate(session, which, args, entries)) return wasmtime_error_new("Invalid WIT input, closed/wrong-session callable, signature mismatch or conversion limit");
  if (session->depth == 64) return wasmtime_error_new("WIT callable reentry limit (64)");
  if (!session->depth) { session->poisoned = false; session->first_error[0] = 0; }
  wasmtime_error_t *error = NULL;
  if (!session->store && (error = lb_refresh(session))) return error;
  wasmtime_context_t *context = wasmtime_store_context(session->store);
  lb_frame frame = {.previous = session->frame, .thread_previous = lb_active_frame, .session = session}; session->frame = &frame; lb_active_frame = &frame; ++session->depth;
  wasmtime_component_val_t values[LB_MAX_ARGS] = {{0}}, result = {0};
  callbacksubtypes_wasmtime_value converted = {0};
  for (size_t i = 0; i < count; ++i) if (entries[i]) ++entries[i]->active;
  for (size_t i = 0; i < count; ++i) {
    if (entries[i]) { error = lb_proxy(session, context, entries[i], &values[i]); if (error) goto done; }
    else values[i] = args[i].value; /* Borrow copied inputs, never delete them. */
  }
  wasmtime_component_export_index_t *api = wasmtime_component_instance_get_export_index(&session->instance, context, NULL, "lean-bridge:callback-subtypes/api@1.0.0", 39);
  if (!api) { error = wasmtime_error_new("Missing WIT API export"); goto done; }
  wasmtime_component_export_index_t *index = wasmtime_component_instance_get_export_index(&session->instance, context, api, name, strlen(name));
  wasmtime_component_export_index_delete(api);
  if (!index) { error = wasmtime_error_new("Missing WIT function export"); goto done; }
  wasmtime_component_func_t function;
  bool found = wasmtime_component_instance_get_func(&session->instance, context, index, &function);
  wasmtime_component_export_index_delete(index);
  if (!found) { error = wasmtime_error_new("WIT export is not a function"); goto done; }
  error = wasmtime_component_func_call(&function, context, values, count, &result, 1);
  if (!error && !session->poisoned && !session->closing) {
    if (lb_returns[which]) {
      lb_entry *entry = NULL;
      error = lb_unwrap(session, context, &result, lb_returns[which], true, &entry);
      if (!error && entry != frame.pending) error = wasmtime_error_new("Unexpected WIT returned callable");
      if (!error) converted.function = entry->token;
    } else { converted.value = result; result = (wasmtime_component_val_t){0}; }
  }
done:
  if (error) { lb_record_error(session, error); wasmtime_error_delete(error); error = NULL; }
  /* A trapped borrow may not be removable. The outermost frame replaces the
   * poisoned store after every active native call has unwound. */
  for (size_t i = 0; i < count; ++i) if (entries[i]) {
    if (values[i].kind == WASMTIME_COMPONENT_RESOURCE && values[i].of.resource) {
      lb_entry *entry = NULL;
      wasmtime_error_t *cleanup = lb_unwrap(session, context, &values[i], entries[i]->tag, true, &entry);
      if (cleanup) { lb_record_error(session, cleanup); wasmtime_error_delete(cleanup); }
      wasmtime_component_val_delete(&values[i]);
    }
    --entries[i]->active; lb_entry_collect(entries[i]);
  }
  wasmtime_component_val_delete(&result);
  if (session->closing && !session->poisoned) lb_record_text(session, "WIT session closed during call", 30);
  if (session->poisoned) {
    wasmtime_component_val_delete(&converted.value);
    error = wasmtime_error_new(session->first_error);
    if (frame.pending) { frame.pending->closed = true; lb_entry_collect(frame.pending); }
  } else { *out = converted; frame.pending = NULL; }
  session->frame = frame.previous; lb_active_frame = frame.thread_previous; --session->depth;
  if (!session->depth) {
    if (session->closing) lb_destroy(session);
    else if (session->poisoned) {
      wasmtime_error_t *reset = lb_refresh(session); if (reset) wasmtime_error_delete(reset);
      session->poisoned = false;
    }
  }
  return error;
}
wasmtime_error_t *callbacksubtypes_wasmtime_call(callbacksubtypes_wasmtime *session, const char *name,
    const wasmtime_component_val_t *args, size_t count, wasmtime_component_val_t *out) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  int which = lb_export(name);
  if (!out || (count && !args) || which < 0 || !lb_copied[which] || count != lb_arities[which])
    return wasmtime_error_new("Use the checked WIT invoke API for callable exports");
  if (!lb_buffer(args, count, sizeof(*args), _Alignof(wasmtime_component_val_t)) || !lb_buffer(out, 1, sizeof(*out), _Alignof(wasmtime_component_val_t))) return wasmtime_error_new("Invalid WIT copied argument storage");
  callbacksubtypes_wasmtime_value values[LB_MAX_ARGS] = {0}, result = {0};
  for (size_t i = 0; i < count; ++i) values[i].value = args[i];
  wasmtime_error_t *error = callbacksubtypes_wasmtime_invoke(session, name, values, count, &result);
  if (!error) *out = result.value;
  return error;
}


wasmtime_error_t *callbacksubtypes_graph_743764d1b67e81fcae92_t_wasmtime_copy(const callbacksubtypes_graph_743764d1b67e81fcae92_t *value, callbacksubtypes_graph_743764d1b67e81fcae92_t *out) {
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(callbacksubtypes_graph_743764d1b67e81fcae92_t)) || out->_bridge_owner || out->_bridge_release) return wasmtime_error_new("Copied WIT result requires a fresh initialized slot");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  wasmtime_component_val_t wire = {0}; callbacksubtypes_graph_743764d1b67e81fcae92_t converted = {0};
  wasmtime_error_t *failure = NULL;
  if (!lb_graph_encode_0(value, &input, &wire) || !lb_graph_decode_0(&wire, &output, &converted)) {
    failure = wasmtime_error_new("Invalid copied WIT value, conversion limit or allocation failure"); goto done;
  }
  converted._bridge_owner = output.memory.allocations; converted._bridge_release = output.memory.allocations ? lb_graph_release : NULL; output.memory.allocations = NULL;
  *out = converted;
done:
  wasmtime_component_val_delete(&wire); lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}

wasmtime_error_t *callbacksubtypes_graph_2c6f4131c8731fa67588_t_wasmtime_copy(const callbacksubtypes_graph_2c6f4131c8731fa67588_t *value, callbacksubtypes_graph_2c6f4131c8731fa67588_t *out) {
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(callbacksubtypes_graph_2c6f4131c8731fa67588_t)) || out->_bridge_owner || out->_bridge_release) return wasmtime_error_new("Copied WIT result requires a fresh initialized slot");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  wasmtime_component_val_t wire = {0}; callbacksubtypes_graph_2c6f4131c8731fa67588_t converted = {0};
  wasmtime_error_t *failure = NULL;
  if (!lb_graph_encode_1(value, &input, &wire) || !lb_graph_decode_1(&wire, &output, &converted)) {
    failure = wasmtime_error_new("Invalid copied WIT value, conversion limit or allocation failure"); goto done;
  }
  converted._bridge_owner = output.memory.allocations; converted._bridge_release = output.memory.allocations ? lb_graph_release : NULL; output.memory.allocations = NULL;
  *out = converted;
done:
  wasmtime_component_val_delete(&wire); lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}

wasmtime_error_t *callbacksubtypes_graph_6c9c0cf3d3abf9adeb4b_t_wasmtime_copy(const callbacksubtypes_graph_6c9c0cf3d3abf9adeb4b_t *value, callbacksubtypes_graph_6c9c0cf3d3abf9adeb4b_t *out) {
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(callbacksubtypes_graph_6c9c0cf3d3abf9adeb4b_t)) || out->_bridge_owner || out->_bridge_release) return wasmtime_error_new("Copied WIT result requires a fresh initialized slot");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  wasmtime_component_val_t wire = {0}; callbacksubtypes_graph_6c9c0cf3d3abf9adeb4b_t converted = {0};
  wasmtime_error_t *failure = NULL;
  if (!lb_graph_encode_2(value, &input, &wire) || !lb_graph_decode_2(&wire, &output, &converted)) {
    failure = wasmtime_error_new("Invalid copied WIT value, conversion limit or allocation failure"); goto done;
  }
  converted._bridge_owner = output.memory.allocations; converted._bridge_release = output.memory.allocations ? lb_graph_release : NULL; output.memory.allocations = NULL;
  *out = converted;
done:
  wasmtime_component_val_delete(&wire); lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}

wasmtime_error_t *callbacksubtypes_scalar_nat_t_wasmtime_copy(const callbacksubtypes_scalar_nat_t *value, callbacksubtypes_scalar_nat_t *out) {
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(callbacksubtypes_scalar_nat_t)) || out->_bridge_owner || out->_bridge_release) return wasmtime_error_new("Copied WIT result requires a fresh initialized slot");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  wasmtime_component_val_t wire = {0}; callbacksubtypes_scalar_nat_t converted = {0};
  wasmtime_error_t *failure = NULL;
  if (!lb_graph_encode_3(value, &input, &wire) || !lb_graph_decode_3(&wire, &output, &converted)) {
    failure = wasmtime_error_new("Invalid copied WIT value, conversion limit or allocation failure"); goto done;
  }
  converted._bridge_owner = output.memory.allocations; converted._bridge_release = output.memory.allocations ? lb_graph_release : NULL; output.memory.allocations = NULL;
  *out = converted;
done:
  wasmtime_component_val_delete(&wire); lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}

wasmtime_error_t *callbacksubtypes_scalar_string_t_wasmtime_copy(const callbacksubtypes_scalar_string_t *value, callbacksubtypes_scalar_string_t *out) {
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(callbacksubtypes_scalar_string_t)) || out->_bridge_owner || out->_bridge_release) return wasmtime_error_new("Copied WIT result requires a fresh initialized slot");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  wasmtime_component_val_t wire = {0}; callbacksubtypes_scalar_string_t converted = {0};
  wasmtime_error_t *failure = NULL;
  if (!lb_graph_encode_4(value, &input, &wire) || !lb_graph_decode_4(&wire, &output, &converted)) {
    failure = wasmtime_error_new("Invalid copied WIT value, conversion limit or allocation failure"); goto done;
  }
  converted._bridge_owner = output.memory.allocations; converted._bridge_release = output.memory.allocations ? lb_graph_release : NULL; output.memory.allocations = NULL;
  *out = converted;
done:
  wasmtime_component_val_delete(&wire); lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}
wasmtime_error_t *callbacksubtypes_wasmtime_value_call_host(callbacksubtypes_wasmtime *session, callbacksubtypes_wasmtime_function arg0, callbacksubtypes_scalar_nat_t *out) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  if (!lb_thread(session) || session->closing) return wasmtime_error_new("Invalid typed WIT session or wrong thread");
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(callbacksubtypes_scalar_nat_t)) || out->_bridge_owner || out->_bridge_release) return wasmtime_error_new("Typed WIT result requires a fresh initialized slot");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  callbacksubtypes_wasmtime_value args[1] = {0}, value = {0};
  wasmtime_error_t *failure = NULL;
  callbacksubtypes_scalar_nat_t converted = {0};
  args[0].function = arg0;
  failure = callbacksubtypes_wasmtime_invoke(session, "call-host", args, 1, &value);
  if (failure) goto done;
  if (!lb_graph_decode_3(&value.value, &output, &converted)) {
    if (!output.memory.failure) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new(output.memory.failure ? "Typed WIT result conversion limit or allocation failure" : "Malformed WIT result; runtime retired"); goto done;
  }
  converted._bridge_owner = output.memory.allocations; converted._bridge_release = output.memory.allocations ? lb_graph_release : NULL; output.memory.allocations = NULL;
  *out = converted;
done:

  wasmtime_component_val_delete(&value.value); lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}

wasmtime_error_t *callbacksubtypes_wasmtime_value_call_host_container(callbacksubtypes_wasmtime *session, callbacksubtypes_wasmtime_function arg0, callbacksubtypes_graph_2c6f4131c8731fa67588_t *out) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  if (!lb_thread(session) || session->closing) return wasmtime_error_new("Invalid typed WIT session or wrong thread");
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(callbacksubtypes_graph_2c6f4131c8731fa67588_t)) || out->_bridge_owner || out->_bridge_release) return wasmtime_error_new("Typed WIT result requires a fresh initialized slot");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  callbacksubtypes_wasmtime_value args[1] = {0}, value = {0};
  wasmtime_error_t *failure = NULL;
  callbacksubtypes_graph_2c6f4131c8731fa67588_t converted = {0};
  args[0].function = arg0;
  failure = callbacksubtypes_wasmtime_invoke(session, "call-host-container", args, 1, &value);
  if (failure) goto done;
  if (!lb_graph_decode_1(&value.value, &output, &converted)) {
    if (!output.memory.failure) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new(output.memory.failure ? "Typed WIT result conversion limit or allocation failure" : "Malformed WIT result; runtime retired"); goto done;
  }
  converted._bridge_owner = output.memory.allocations; converted._bridge_release = output.memory.allocations ? lb_graph_release : NULL; output.memory.allocations = NULL;
  *out = converted;
done:

  wasmtime_component_val_delete(&value.value); lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}

wasmtime_error_t *callbacksubtypes_wasmtime_value_call_host_mixed(callbacksubtypes_wasmtime *session, callbacksubtypes_wasmtime_function arg0, callbacksubtypes_scalar_nat_t *out) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  if (!lb_thread(session) || session->closing) return wasmtime_error_new("Invalid typed WIT session or wrong thread");
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(callbacksubtypes_scalar_nat_t)) || out->_bridge_owner || out->_bridge_release) return wasmtime_error_new("Typed WIT result requires a fresh initialized slot");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  callbacksubtypes_wasmtime_value args[1] = {0}, value = {0};
  wasmtime_error_t *failure = NULL;
  callbacksubtypes_scalar_nat_t converted = {0};
  args[0].function = arg0;
  failure = callbacksubtypes_wasmtime_invoke(session, "call-host-mixed", args, 1, &value);
  if (failure) goto done;
  if (!lb_graph_decode_3(&value.value, &output, &converted)) {
    if (!output.memory.failure) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new(output.memory.failure ? "Typed WIT result conversion limit or allocation failure" : "Malformed WIT result; runtime retired"); goto done;
  }
  converted._bridge_owner = output.memory.allocations; converted._bridge_release = output.memory.allocations ? lb_graph_release : NULL; output.memory.allocations = NULL;
  *out = converted;
done:

  wasmtime_component_val_delete(&value.value); lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}

wasmtime_error_t *callbacksubtypes_wasmtime_value_make_closure(callbacksubtypes_wasmtime *session, const callbacksubtypes_scalar_nat_t *arg0, callbacksubtypes_wasmtime_function *out) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  if (!lb_thread(session) || session->closing) return wasmtime_error_new("Invalid typed WIT session or wrong thread");
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(callbacksubtypes_wasmtime_function)) || *out) return wasmtime_error_new("Typed WIT result requires a fresh initialized slot");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  callbacksubtypes_wasmtime_value args[1] = {0}, value = {0};
  wasmtime_error_t *failure = NULL;

  if (!lb_graph_encode_3(arg0, &input, &args[0].value)) { failure = wasmtime_error_new("Invalid typed WIT input, conversion limit or allocation failure"); goto done; }
  failure = callbacksubtypes_wasmtime_invoke(session, "make-closure", args, 1, &value);
  if (failure) goto done;
  *out = value.function;
done:
  wasmtime_component_val_delete(&args[0].value);
  wasmtime_component_val_delete(&value.value); lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}

wasmtime_error_t *callbacksubtypes_wasmtime_value_make_container_closure(callbacksubtypes_wasmtime *session, const callbacksubtypes_scalar_nat_t *arg0, callbacksubtypes_wasmtime_function *out) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  if (!lb_thread(session) || session->closing) return wasmtime_error_new("Invalid typed WIT session or wrong thread");
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(callbacksubtypes_wasmtime_function)) || *out) return wasmtime_error_new("Typed WIT result requires a fresh initialized slot");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  callbacksubtypes_wasmtime_value args[1] = {0}, value = {0};
  wasmtime_error_t *failure = NULL;

  if (!lb_graph_encode_3(arg0, &input, &args[0].value)) { failure = wasmtime_error_new("Invalid typed WIT input, conversion limit or allocation failure"); goto done; }
  failure = callbacksubtypes_wasmtime_invoke(session, "make-container-closure", args, 1, &value);
  if (failure) goto done;
  *out = value.function;
done:
  wasmtime_component_val_delete(&args[0].value);
  wasmtime_component_val_delete(&value.value); lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}

wasmtime_error_t *callbacksubtypes_wasmtime_value_make_mixed_closure(callbacksubtypes_wasmtime *session, const callbacksubtypes_scalar_nat_t *arg0, callbacksubtypes_wasmtime_function *out) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  if (!lb_thread(session) || session->closing) return wasmtime_error_new("Invalid typed WIT session or wrong thread");
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(callbacksubtypes_wasmtime_function)) || *out) return wasmtime_error_new("Typed WIT result requires a fresh initialized slot");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  callbacksubtypes_wasmtime_value args[1] = {0}, value = {0};
  wasmtime_error_t *failure = NULL;

  if (!lb_graph_encode_3(arg0, &input, &args[0].value)) { failure = wasmtime_error_new("Invalid typed WIT input, conversion limit or allocation failure"); goto done; }
  failure = callbacksubtypes_wasmtime_invoke(session, "make-mixed-closure", args, 1, &value);
  if (failure) goto done;
  *out = value.function;
done:
  wasmtime_component_val_delete(&args[0].value);
  wasmtime_component_val_delete(&value.value); lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}

wasmtime_error_t *callbacksubtypes_wasmtime_function_callbacke84eef4c26bca64196e6_call(callbacksubtypes_wasmtime *session, callbacksubtypes_wasmtime_function arg0, const callbacksubtypes_scalar_nat_t *arg1, callbacksubtypes_scalar_nat_t *out) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  if (!lb_thread(session) || session->closing) return wasmtime_error_new("Invalid typed WIT session or wrong thread");
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(callbacksubtypes_scalar_nat_t)) || out->_bridge_owner || out->_bridge_release) return wasmtime_error_new("Typed WIT result requires a fresh initialized slot");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  callbacksubtypes_wasmtime_value args[2] = {0}, value = {0};
  wasmtime_error_t *failure = NULL;
  callbacksubtypes_scalar_nat_t converted = {0};
  args[0].function = arg0;
  if (!lb_graph_encode_3(arg1, &input, &args[1].value)) { failure = wasmtime_error_new("Invalid typed WIT input, conversion limit or allocation failure"); goto done; }
  failure = callbacksubtypes_wasmtime_invoke(session, "invoke-function-713c4284d84483c3f82d5b8d", args, 2, &value);
  if (failure) goto done;
  if (!lb_graph_decode_3(&value.value, &output, &converted)) {
    if (!output.memory.failure) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new(output.memory.failure ? "Typed WIT result conversion limit or allocation failure" : "Malformed WIT result; runtime retired"); goto done;
  }
  converted._bridge_owner = output.memory.allocations; converted._bridge_release = output.memory.allocations ? lb_graph_release : NULL; output.memory.allocations = NULL;
  *out = converted;
done:
  wasmtime_component_val_delete(&args[1].value);
  wasmtime_component_val_delete(&value.value); lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}

wasmtime_error_t *callbacksubtypes_wasmtime_function_callback0cd085da803af7102cc3_call(callbacksubtypes_wasmtime *session, callbacksubtypes_wasmtime_function arg0, const callbacksubtypes_graph_743764d1b67e81fcae92_t *arg1, callbacksubtypes_graph_2c6f4131c8731fa67588_t *out) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  if (!lb_thread(session) || session->closing) return wasmtime_error_new("Invalid typed WIT session or wrong thread");
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(callbacksubtypes_graph_2c6f4131c8731fa67588_t)) || out->_bridge_owner || out->_bridge_release) return wasmtime_error_new("Typed WIT result requires a fresh initialized slot");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  callbacksubtypes_wasmtime_value args[2] = {0}, value = {0};
  wasmtime_error_t *failure = NULL;
  callbacksubtypes_graph_2c6f4131c8731fa67588_t converted = {0};
  args[0].function = arg0;
  if (!lb_graph_encode_0(arg1, &input, &args[1].value)) { failure = wasmtime_error_new("Invalid typed WIT input, conversion limit or allocation failure"); goto done; }
  failure = callbacksubtypes_wasmtime_invoke(session, "invoke-function-a267a7fed3ff23cf46f137bb", args, 2, &value);
  if (failure) goto done;
  if (!lb_graph_decode_1(&value.value, &output, &converted)) {
    if (!output.memory.failure) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new(output.memory.failure ? "Typed WIT result conversion limit or allocation failure" : "Malformed WIT result; runtime retired"); goto done;
  }
  converted._bridge_owner = output.memory.allocations; converted._bridge_release = output.memory.allocations ? lb_graph_release : NULL; output.memory.allocations = NULL;
  *out = converted;
done:
  wasmtime_component_val_delete(&args[1].value);
  wasmtime_component_val_delete(&value.value); lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}

wasmtime_error_t *callbacksubtypes_wasmtime_function_callback2ad56570215cca826b8e_call(callbacksubtypes_wasmtime *session, callbacksubtypes_wasmtime_function arg0, const callbacksubtypes_scalar_nat_t *arg1, const callbacksubtypes_scalar_nat_t *arg2, callbacksubtypes_scalar_nat_t *out) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  if (!lb_thread(session) || session->closing) return wasmtime_error_new("Invalid typed WIT session or wrong thread");
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(callbacksubtypes_scalar_nat_t)) || out->_bridge_owner || out->_bridge_release) return wasmtime_error_new("Typed WIT result requires a fresh initialized slot");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  callbacksubtypes_wasmtime_value args[3] = {0}, value = {0};
  wasmtime_error_t *failure = NULL;
  callbacksubtypes_scalar_nat_t converted = {0};
  args[0].function = arg0;
  if (!lb_graph_encode_3(arg1, &input, &args[1].value)) { failure = wasmtime_error_new("Invalid typed WIT input, conversion limit or allocation failure"); goto done; }
  if (!lb_graph_encode_3(arg2, &input, &args[2].value)) { failure = wasmtime_error_new("Invalid typed WIT input, conversion limit or allocation failure"); goto done; }
  failure = callbacksubtypes_wasmtime_invoke(session, "invoke-function-1157dd12dc0b8df7b38e2ce1", args, 3, &value);
  if (failure) goto done;
  if (!lb_graph_decode_3(&value.value, &output, &converted)) {
    if (!output.memory.failure) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new(output.memory.failure ? "Typed WIT result conversion limit or allocation failure" : "Malformed WIT result; runtime retired"); goto done;
  }
  converted._bridge_owner = output.memory.allocations; converted._bridge_release = output.memory.allocations ? lb_graph_release : NULL; output.memory.allocations = NULL;
  *out = converted;
done:
  wasmtime_component_val_delete(&args[1].value);
  wasmtime_component_val_delete(&args[2].value);
  wasmtime_component_val_delete(&value.value); lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}

wasmtime_error_t *callbacksubtypes_wasmtime_function_callback0f78910188dae34fd8b0_call(callbacksubtypes_wasmtime *session, callbacksubtypes_wasmtime_function arg0, const callbacksubtypes_scalar_nat_t *arg1, callbacksubtypes_scalar_nat_t *out) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  if (!lb_thread(session) || session->closing) return wasmtime_error_new("Invalid typed WIT session or wrong thread");
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(callbacksubtypes_scalar_nat_t)) || out->_bridge_owner || out->_bridge_release) return wasmtime_error_new("Typed WIT result requires a fresh initialized slot");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  callbacksubtypes_wasmtime_value args[2] = {0}, value = {0};
  wasmtime_error_t *failure = NULL;
  callbacksubtypes_scalar_nat_t converted = {0};
  args[0].function = arg0;
  if (!lb_graph_encode_3(arg1, &input, &args[1].value)) { failure = wasmtime_error_new("Invalid typed WIT input, conversion limit or allocation failure"); goto done; }
  failure = callbacksubtypes_wasmtime_invoke(session, "invoke-function-64e40e7aef4b8c33bd59c0eb", args, 2, &value);
  if (failure) goto done;
  if (!lb_graph_decode_3(&value.value, &output, &converted)) {
    if (!output.memory.failure) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new(output.memory.failure ? "Typed WIT result conversion limit or allocation failure" : "Malformed WIT result; runtime retired"); goto done;
  }
  converted._bridge_owner = output.memory.allocations; converted._bridge_release = output.memory.allocations ? lb_graph_release : NULL; output.memory.allocations = NULL;
  *out = converted;
done:
  wasmtime_component_val_delete(&args[1].value);
  wasmtime_component_val_delete(&value.value); lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}

wasmtime_error_t *callbacksubtypes_wasmtime_function_callbackc2ff96fa00e1ff712eba_call(callbacksubtypes_wasmtime *session, callbacksubtypes_wasmtime_function arg0, const callbacksubtypes_graph_6c9c0cf3d3abf9adeb4b_t *arg1, callbacksubtypes_graph_743764d1b67e81fcae92_t *out) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  if (!lb_thread(session) || session->closing) return wasmtime_error_new("Invalid typed WIT session or wrong thread");
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(callbacksubtypes_graph_743764d1b67e81fcae92_t)) || out->_bridge_owner || out->_bridge_release) return wasmtime_error_new("Typed WIT result requires a fresh initialized slot");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  callbacksubtypes_wasmtime_value args[2] = {0}, value = {0};
  wasmtime_error_t *failure = NULL;
  callbacksubtypes_graph_743764d1b67e81fcae92_t converted = {0};
  args[0].function = arg0;
  if (!lb_graph_encode_2(arg1, &input, &args[1].value)) { failure = wasmtime_error_new("Invalid typed WIT input, conversion limit or allocation failure"); goto done; }
  failure = callbacksubtypes_wasmtime_invoke(session, "invoke-function-20863d9cf68fe64f50500491", args, 2, &value);
  if (failure) goto done;
  if (!lb_graph_decode_0(&value.value, &output, &converted)) {
    if (!output.memory.failure) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new(output.memory.failure ? "Typed WIT result conversion limit or allocation failure" : "Malformed WIT result; runtime retired"); goto done;
  }
  converted._bridge_owner = output.memory.allocations; converted._bridge_release = output.memory.allocations ? lb_graph_release : NULL; output.memory.allocations = NULL;
  *out = converted;
done:
  wasmtime_component_val_delete(&args[1].value);
  wasmtime_component_val_delete(&value.value); lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}

wasmtime_error_t *callbacksubtypes_wasmtime_function_callback34f6a3c1043662b01ed6_call(callbacksubtypes_wasmtime *session, callbacksubtypes_wasmtime_function arg0, const callbacksubtypes_scalar_nat_t *arg1, const callbacksubtypes_scalar_nat_t *arg2, callbacksubtypes_scalar_nat_t *out) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  if (!lb_thread(session) || session->closing) return wasmtime_error_new("Invalid typed WIT session or wrong thread");
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(callbacksubtypes_scalar_nat_t)) || out->_bridge_owner || out->_bridge_release) return wasmtime_error_new("Typed WIT result requires a fresh initialized slot");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  callbacksubtypes_wasmtime_value args[3] = {0}, value = {0};
  wasmtime_error_t *failure = NULL;
  callbacksubtypes_scalar_nat_t converted = {0};
  args[0].function = arg0;
  if (!lb_graph_encode_3(arg1, &input, &args[1].value)) { failure = wasmtime_error_new("Invalid typed WIT input, conversion limit or allocation failure"); goto done; }
  if (!lb_graph_encode_3(arg2, &input, &args[2].value)) { failure = wasmtime_error_new("Invalid typed WIT input, conversion limit or allocation failure"); goto done; }
  failure = callbacksubtypes_wasmtime_invoke(session, "invoke-function-b6d50d35d3ef5714d7f6b17e", args, 3, &value);
  if (failure) goto done;
  if (!lb_graph_decode_3(&value.value, &output, &converted)) {
    if (!output.memory.failure) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new(output.memory.failure ? "Typed WIT result conversion limit or allocation failure" : "Malformed WIT result; runtime retired"); goto done;
  }
  converted._bridge_owner = output.memory.allocations; converted._bridge_release = output.memory.allocations ? lb_graph_release : NULL; output.memory.allocations = NULL;
  *out = converted;
done:
  wasmtime_component_val_delete(&args[1].value);
  wasmtime_component_val_delete(&args[2].value);
  wasmtime_component_val_delete(&value.value); lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}
typedef struct { callbacksubtypes_wasmtime_callback_callback0cd085da803af7102cc3_fn callback; void *data; void (*release)(void *); callbacksubtypes_graph_2c6f4131c8731fa67588_t recovery; } callbacksubtypes_wasmtime_callback_callback0cd085da803af7102cc3_context;
static void callbacksubtypes_wasmtime_callback_callback0cd085da803af7102cc3_release(void *data) {
  callbacksubtypes_wasmtime_callback_callback0cd085da803af7102cc3_context *context = data;
  if (context->release) context->release(context->data);
  callbacksubtypes_graph_2c6f4131c8731fa67588_t_clear(&context->recovery);
  free(context);
}
static wasmtime_error_t *callbacksubtypes_wasmtime_callback_callback0cd085da803af7102cc3_invoke(void *data, const wasmtime_component_val_t *args, size_t count, wasmtime_component_val_t *out) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  callbacksubtypes_wasmtime_callback_callback0cd085da803af7102cc3_context *context = data;
  if (count != 1) return wasmtime_error_new("Typed WIT callback arity mismatch");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  wasmtime_error_t *failure = NULL;
  callbacksubtypes_graph_2c6f4131c8731fa67588_t value = {0};
  callbacksubtypes_graph_743764d1b67e81fcae92_t arg0 = {0};
  if (!lb_graph_decode_0(&args[0], &input, &arg0)) { failure = wasmtime_error_new("Invalid typed WIT callback input, conversion limit or allocation failure"); goto done; }
  failure = context->callback(context->data, &arg0, &value);
  if (failure) goto done;
  if (!lb_graph_encode_1(&value, &output, out)) failure = wasmtime_error_new("Invalid typed WIT callback result, conversion limit or allocation failure");
done:
  callbacksubtypes_graph_2c6f4131c8731fa67588_t_clear(&value);
  lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}
wasmtime_error_t *callbacksubtypes_wasmtime_callback_callback0cd085da803af7102cc3_create(callbacksubtypes_wasmtime *session, callbacksubtypes_wasmtime_callback_callback0cd085da803af7102cc3_fn callback, void *data, void (*release)(void *), const callbacksubtypes_graph_2c6f4131c8731fa67588_t *recovery, callbacksubtypes_wasmtime_function *out) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  if (!callback || !lb_thread(session) || session->closing || !lb_buffer(recovery, 1, sizeof(*recovery), _Alignof(callbacksubtypes_graph_2c6f4131c8731fa67588_t)) || !lb_buffer(out, 1, sizeof(*out), _Alignof(callbacksubtypes_wasmtime_function)) || *out) return wasmtime_error_new("Invalid typed WIT callback registration");
  callbacksubtypes_wasmtime_callback_callback0cd085da803af7102cc3_context *context = malloc(sizeof(*context));
  if (!context) return wasmtime_error_new("Cannot allocate typed WIT callback context");
  *context = (callbacksubtypes_wasmtime_callback_callback0cd085da803af7102cc3_context){.callback = callback, .data = data, .release = release};
  wasmtime_error_t *failure = NULL;
  failure = callbacksubtypes_graph_2c6f4131c8731fa67588_t_wasmtime_copy(recovery, &context->recovery);
  if (failure) { free(context); return failure; }
  failure = callbacksubtypes_wasmtime_callback_create(session, "function-a267a7fed3ff23cf46f137bb", callbacksubtypes_wasmtime_callback_callback0cd085da803af7102cc3_invoke, context, callbacksubtypes_wasmtime_callback_callback0cd085da803af7102cc3_release, out);
  if (failure) { callbacksubtypes_graph_2c6f4131c8731fa67588_t_clear(&context->recovery); free(context); }
  else {
    lb_entry *entry = lb_entry_find(session, *out);
    if (!entry) { failure = wasmtime_error_new("Missing typed WIT callback recovery owner"); callbacksubtypes_wasmtime_function_close(session, out); }
    else entry->recovery = &context->recovery;
  }
  return failure;
}

typedef struct { callbacksubtypes_wasmtime_callback_callback0f78910188dae34fd8b0_fn callback; void *data; void (*release)(void *); } callbacksubtypes_wasmtime_callback_callback0f78910188dae34fd8b0_context;
static void callbacksubtypes_wasmtime_callback_callback0f78910188dae34fd8b0_release(void *data) {
  callbacksubtypes_wasmtime_callback_callback0f78910188dae34fd8b0_context *context = data;
  if (context->release) context->release(context->data);
  
  free(context);
}
static wasmtime_error_t *callbacksubtypes_wasmtime_callback_callback0f78910188dae34fd8b0_invoke(void *data, const wasmtime_component_val_t *args, size_t count, wasmtime_component_val_t *out) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  callbacksubtypes_wasmtime_callback_callback0f78910188dae34fd8b0_context *context = data;
  if (count != 1) return wasmtime_error_new("Typed WIT callback arity mismatch");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  wasmtime_error_t *failure = NULL;
  callbacksubtypes_scalar_nat_t value = {0};
  callbacksubtypes_scalar_nat_t arg0 = {0};
  if (!lb_graph_decode_3(&args[0], &input, &arg0)) { failure = wasmtime_error_new("Invalid typed WIT callback input, conversion limit or allocation failure"); goto done; }
  failure = context->callback(context->data, &arg0, &value);
  if (failure) goto done;
  if (!lb_graph_encode_3(&value, &output, out)) failure = wasmtime_error_new("Invalid typed WIT callback result, conversion limit or allocation failure");
done:
  callbacksubtypes_scalar_nat_t_clear(&value);
  lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}
wasmtime_error_t *callbacksubtypes_wasmtime_callback_callback0f78910188dae34fd8b0_create(callbacksubtypes_wasmtime *session, callbacksubtypes_wasmtime_callback_callback0f78910188dae34fd8b0_fn callback, void *data, void (*release)(void *), callbacksubtypes_wasmtime_function *out) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  if (!callback || !lb_thread(session) || session->closing || !lb_buffer(out, 1, sizeof(*out), _Alignof(callbacksubtypes_wasmtime_function)) || *out) return wasmtime_error_new("Invalid typed WIT callback registration");
  callbacksubtypes_wasmtime_callback_callback0f78910188dae34fd8b0_context *context = malloc(sizeof(*context));
  if (!context) return wasmtime_error_new("Cannot allocate typed WIT callback context");
  *context = (callbacksubtypes_wasmtime_callback_callback0f78910188dae34fd8b0_context){.callback = callback, .data = data, .release = release};
  wasmtime_error_t *failure = NULL;
  
  failure = callbacksubtypes_wasmtime_callback_create(session, "function-64e40e7aef4b8c33bd59c0eb", callbacksubtypes_wasmtime_callback_callback0f78910188dae34fd8b0_invoke, context, callbacksubtypes_wasmtime_callback_callback0f78910188dae34fd8b0_release, out);
  if (failure) { free(context); }
  
  return failure;
}

typedef struct { callbacksubtypes_wasmtime_callback_callback2ad56570215cca826b8e_fn callback; void *data; void (*release)(void *); callbacksubtypes_scalar_nat_t recovery; } callbacksubtypes_wasmtime_callback_callback2ad56570215cca826b8e_context;
static void callbacksubtypes_wasmtime_callback_callback2ad56570215cca826b8e_release(void *data) {
  callbacksubtypes_wasmtime_callback_callback2ad56570215cca826b8e_context *context = data;
  if (context->release) context->release(context->data);
  callbacksubtypes_scalar_nat_t_clear(&context->recovery);
  free(context);
}
static wasmtime_error_t *callbacksubtypes_wasmtime_callback_callback2ad56570215cca826b8e_invoke(void *data, const wasmtime_component_val_t *args, size_t count, wasmtime_component_val_t *out) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  callbacksubtypes_wasmtime_callback_callback2ad56570215cca826b8e_context *context = data;
  if (count != 2) return wasmtime_error_new("Typed WIT callback arity mismatch");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  wasmtime_error_t *failure = NULL;
  callbacksubtypes_scalar_nat_t value = {0};
  callbacksubtypes_scalar_nat_t arg0 = {0};
  callbacksubtypes_scalar_nat_t arg1 = {0};
  if (!lb_graph_decode_3(&args[0], &input, &arg0)) { failure = wasmtime_error_new("Invalid typed WIT callback input, conversion limit or allocation failure"); goto done; }
  if (!lb_graph_decode_3(&args[1], &input, &arg1)) { failure = wasmtime_error_new("Invalid typed WIT callback input, conversion limit or allocation failure"); goto done; }
  failure = context->callback(context->data, &arg0, &arg1, &value);
  if (failure) goto done;
  if (!lb_graph_encode_3(&value, &output, out)) failure = wasmtime_error_new("Invalid typed WIT callback result, conversion limit or allocation failure");
done:
  callbacksubtypes_scalar_nat_t_clear(&value);
  lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}
wasmtime_error_t *callbacksubtypes_wasmtime_callback_callback2ad56570215cca826b8e_create(callbacksubtypes_wasmtime *session, callbacksubtypes_wasmtime_callback_callback2ad56570215cca826b8e_fn callback, void *data, void (*release)(void *), const callbacksubtypes_scalar_nat_t *recovery, callbacksubtypes_wasmtime_function *out) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  if (!callback || !lb_thread(session) || session->closing || !lb_buffer(recovery, 1, sizeof(*recovery), _Alignof(callbacksubtypes_scalar_nat_t)) || !lb_buffer(out, 1, sizeof(*out), _Alignof(callbacksubtypes_wasmtime_function)) || *out) return wasmtime_error_new("Invalid typed WIT callback registration");
  callbacksubtypes_wasmtime_callback_callback2ad56570215cca826b8e_context *context = malloc(sizeof(*context));
  if (!context) return wasmtime_error_new("Cannot allocate typed WIT callback context");
  *context = (callbacksubtypes_wasmtime_callback_callback2ad56570215cca826b8e_context){.callback = callback, .data = data, .release = release};
  wasmtime_error_t *failure = NULL;
  failure = callbacksubtypes_scalar_nat_t_wasmtime_copy(recovery, &context->recovery);
  if (failure) { free(context); return failure; }
  failure = callbacksubtypes_wasmtime_callback_create(session, "function-1157dd12dc0b8df7b38e2ce1", callbacksubtypes_wasmtime_callback_callback2ad56570215cca826b8e_invoke, context, callbacksubtypes_wasmtime_callback_callback2ad56570215cca826b8e_release, out);
  if (failure) { callbacksubtypes_scalar_nat_t_clear(&context->recovery); free(context); }
  else {
    lb_entry *entry = lb_entry_find(session, *out);
    if (!entry) { failure = wasmtime_error_new("Missing typed WIT callback recovery owner"); callbacksubtypes_wasmtime_function_close(session, out); }
    else entry->recovery = &context->recovery;
  }
  return failure;
}

typedef struct { callbacksubtypes_wasmtime_callback_callback34f6a3c1043662b01ed6_fn callback; void *data; void (*release)(void *); } callbacksubtypes_wasmtime_callback_callback34f6a3c1043662b01ed6_context;
static void callbacksubtypes_wasmtime_callback_callback34f6a3c1043662b01ed6_release(void *data) {
  callbacksubtypes_wasmtime_callback_callback34f6a3c1043662b01ed6_context *context = data;
  if (context->release) context->release(context->data);
  
  free(context);
}
static wasmtime_error_t *callbacksubtypes_wasmtime_callback_callback34f6a3c1043662b01ed6_invoke(void *data, const wasmtime_component_val_t *args, size_t count, wasmtime_component_val_t *out) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  callbacksubtypes_wasmtime_callback_callback34f6a3c1043662b01ed6_context *context = data;
  if (count != 2) return wasmtime_error_new("Typed WIT callback arity mismatch");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  wasmtime_error_t *failure = NULL;
  callbacksubtypes_scalar_nat_t value = {0};
  callbacksubtypes_scalar_nat_t arg0 = {0};
  callbacksubtypes_scalar_nat_t arg1 = {0};
  if (!lb_graph_decode_3(&args[0], &input, &arg0)) { failure = wasmtime_error_new("Invalid typed WIT callback input, conversion limit or allocation failure"); goto done; }
  if (!lb_graph_decode_3(&args[1], &input, &arg1)) { failure = wasmtime_error_new("Invalid typed WIT callback input, conversion limit or allocation failure"); goto done; }
  failure = context->callback(context->data, &arg0, &arg1, &value);
  if (failure) goto done;
  if (!lb_graph_encode_3(&value, &output, out)) failure = wasmtime_error_new("Invalid typed WIT callback result, conversion limit or allocation failure");
done:
  callbacksubtypes_scalar_nat_t_clear(&value);
  lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}
wasmtime_error_t *callbacksubtypes_wasmtime_callback_callback34f6a3c1043662b01ed6_create(callbacksubtypes_wasmtime *session, callbacksubtypes_wasmtime_callback_callback34f6a3c1043662b01ed6_fn callback, void *data, void (*release)(void *), callbacksubtypes_wasmtime_function *out) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  if (!callback || !lb_thread(session) || session->closing || !lb_buffer(out, 1, sizeof(*out), _Alignof(callbacksubtypes_wasmtime_function)) || *out) return wasmtime_error_new("Invalid typed WIT callback registration");
  callbacksubtypes_wasmtime_callback_callback34f6a3c1043662b01ed6_context *context = malloc(sizeof(*context));
  if (!context) return wasmtime_error_new("Cannot allocate typed WIT callback context");
  *context = (callbacksubtypes_wasmtime_callback_callback34f6a3c1043662b01ed6_context){.callback = callback, .data = data, .release = release};
  wasmtime_error_t *failure = NULL;
  
  failure = callbacksubtypes_wasmtime_callback_create(session, "function-b6d50d35d3ef5714d7f6b17e", callbacksubtypes_wasmtime_callback_callback34f6a3c1043662b01ed6_invoke, context, callbacksubtypes_wasmtime_callback_callback34f6a3c1043662b01ed6_release, out);
  if (failure) { free(context); }
  
  return failure;
}

typedef struct { callbacksubtypes_wasmtime_callback_callbackc2ff96fa00e1ff712eba_fn callback; void *data; void (*release)(void *); } callbacksubtypes_wasmtime_callback_callbackc2ff96fa00e1ff712eba_context;
static void callbacksubtypes_wasmtime_callback_callbackc2ff96fa00e1ff712eba_release(void *data) {
  callbacksubtypes_wasmtime_callback_callbackc2ff96fa00e1ff712eba_context *context = data;
  if (context->release) context->release(context->data);
  
  free(context);
}
static wasmtime_error_t *callbacksubtypes_wasmtime_callback_callbackc2ff96fa00e1ff712eba_invoke(void *data, const wasmtime_component_val_t *args, size_t count, wasmtime_component_val_t *out) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  callbacksubtypes_wasmtime_callback_callbackc2ff96fa00e1ff712eba_context *context = data;
  if (count != 1) return wasmtime_error_new("Typed WIT callback arity mismatch");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  wasmtime_error_t *failure = NULL;
  callbacksubtypes_graph_743764d1b67e81fcae92_t value = {0};
  callbacksubtypes_graph_6c9c0cf3d3abf9adeb4b_t arg0 = {0};
  if (!lb_graph_decode_2(&args[0], &input, &arg0)) { failure = wasmtime_error_new("Invalid typed WIT callback input, conversion limit or allocation failure"); goto done; }
  failure = context->callback(context->data, &arg0, &value);
  if (failure) goto done;
  if (!lb_graph_encode_0(&value, &output, out)) failure = wasmtime_error_new("Invalid typed WIT callback result, conversion limit or allocation failure");
done:
  callbacksubtypes_graph_743764d1b67e81fcae92_t_clear(&value);
  lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}
wasmtime_error_t *callbacksubtypes_wasmtime_callback_callbackc2ff96fa00e1ff712eba_create(callbacksubtypes_wasmtime *session, callbacksubtypes_wasmtime_callback_callbackc2ff96fa00e1ff712eba_fn callback, void *data, void (*release)(void *), callbacksubtypes_wasmtime_function *out) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  if (!callback || !lb_thread(session) || session->closing || !lb_buffer(out, 1, sizeof(*out), _Alignof(callbacksubtypes_wasmtime_function)) || *out) return wasmtime_error_new("Invalid typed WIT callback registration");
  callbacksubtypes_wasmtime_callback_callbackc2ff96fa00e1ff712eba_context *context = malloc(sizeof(*context));
  if (!context) return wasmtime_error_new("Cannot allocate typed WIT callback context");
  *context = (callbacksubtypes_wasmtime_callback_callbackc2ff96fa00e1ff712eba_context){.callback = callback, .data = data, .release = release};
  wasmtime_error_t *failure = NULL;
  
  failure = callbacksubtypes_wasmtime_callback_create(session, "function-20863d9cf68fe64f50500491", callbacksubtypes_wasmtime_callback_callbackc2ff96fa00e1ff712eba_invoke, context, callbacksubtypes_wasmtime_callback_callbackc2ff96fa00e1ff712eba_release, out);
  if (failure) { free(context); }
  
  return failure;
}

typedef struct { callbacksubtypes_wasmtime_callback_callbacke84eef4c26bca64196e6_fn callback; void *data; void (*release)(void *); callbacksubtypes_scalar_nat_t recovery; } callbacksubtypes_wasmtime_callback_callbacke84eef4c26bca64196e6_context;
static void callbacksubtypes_wasmtime_callback_callbacke84eef4c26bca64196e6_release(void *data) {
  callbacksubtypes_wasmtime_callback_callbacke84eef4c26bca64196e6_context *context = data;
  if (context->release) context->release(context->data);
  callbacksubtypes_scalar_nat_t_clear(&context->recovery);
  free(context);
}
static wasmtime_error_t *callbacksubtypes_wasmtime_callback_callbacke84eef4c26bca64196e6_invoke(void *data, const wasmtime_component_val_t *args, size_t count, wasmtime_component_val_t *out) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  callbacksubtypes_wasmtime_callback_callbacke84eef4c26bca64196e6_context *context = data;
  if (count != 1) return wasmtime_error_new("Typed WIT callback arity mismatch");
  lb_graph_scope input = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  lb_graph_scope output = {.memory = {.remaining = LB_GRAPH_BYTES}, .nodes = LB_GRAPH_NODES};
  wasmtime_error_t *failure = NULL;
  callbacksubtypes_scalar_nat_t value = {0};
  callbacksubtypes_scalar_nat_t arg0 = {0};
  if (!lb_graph_decode_3(&args[0], &input, &arg0)) { failure = wasmtime_error_new("Invalid typed WIT callback input, conversion limit or allocation failure"); goto done; }
  failure = context->callback(context->data, &arg0, &value);
  if (failure) goto done;
  if (!lb_graph_encode_3(&value, &output, out)) failure = wasmtime_error_new("Invalid typed WIT callback result, conversion limit or allocation failure");
done:
  callbacksubtypes_scalar_nat_t_clear(&value);
  lb_scope_close(&output.memory); lb_scope_close(&input.memory);
  return failure;
}
wasmtime_error_t *callbacksubtypes_wasmtime_callback_callbacke84eef4c26bca64196e6_create(callbacksubtypes_wasmtime *session, callbacksubtypes_wasmtime_callback_callbacke84eef4c26bca64196e6_fn callback, void *data, void (*release)(void *), const callbacksubtypes_scalar_nat_t *recovery, callbacksubtypes_wasmtime_function *out) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  if (!callback || !lb_thread(session) || session->closing || !lb_buffer(recovery, 1, sizeof(*recovery), _Alignof(callbacksubtypes_scalar_nat_t)) || !lb_buffer(out, 1, sizeof(*out), _Alignof(callbacksubtypes_wasmtime_function)) || *out) return wasmtime_error_new("Invalid typed WIT callback registration");
  callbacksubtypes_wasmtime_callback_callbacke84eef4c26bca64196e6_context *context = malloc(sizeof(*context));
  if (!context) return wasmtime_error_new("Cannot allocate typed WIT callback context");
  *context = (callbacksubtypes_wasmtime_callback_callbacke84eef4c26bca64196e6_context){.callback = callback, .data = data, .release = release};
  wasmtime_error_t *failure = NULL;
  failure = callbacksubtypes_scalar_nat_t_wasmtime_copy(recovery, &context->recovery);
  if (failure) { free(context); return failure; }
  failure = callbacksubtypes_wasmtime_callback_create(session, "function-713c4284d84483c3f82d5b8d", callbacksubtypes_wasmtime_callback_callbacke84eef4c26bca64196e6_invoke, context, callbacksubtypes_wasmtime_callback_callbacke84eef4c26bca64196e6_release, out);
  if (failure) { callbacksubtypes_scalar_nat_t_clear(&context->recovery); free(context); }
  else {
    lb_entry *entry = lb_entry_find(session, *out);
    if (!entry) { failure = wasmtime_error_new("Missing typed WIT callback recovery owner"); callbacksubtypes_wasmtime_function_close(session, out); }
    else entry->recovery = &context->recovery;
  }
  return failure;
}
