#ifndef CALLBACKSUBTYPES_WASMTIME_CALLABLE_GRAPH_PACKAGE_H
#define CALLBACKSUBTYPES_WASMTIME_CALLABLE_GRAPH_PACKAGE_H
#ifndef CALLBACKSUBTYPES_WASMTIME_CALLABLE_GRAPH_H
#define CALLBACKSUBTYPES_WASMTIME_CALLABLE_GRAPH_H
#ifndef CALLBACKSUBTYPES_WASMTIME_H
#define CALLBACKSUBTYPES_WASMTIME_H
#include <stdint.h>
#include <wasmtime.h>
#include <wasmtime/component.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef struct callbacksubtypes_wasmtime callbacksubtypes_wasmtime;
/* Opaque, generation-checked identity. Never cast this token to a pointer. */
typedef uint64_t callbacksubtypes_wasmtime_function;
typedef struct {
  wasmtime_component_val_t value;
  callbacksubtypes_wasmtime_function function; /* Nonzero for a callable; value is unused. */
} callbacksubtypes_wasmtime_value;
/* Arguments are borrowed. Set out to an independently owned Wasmtime value,
 * or return an owned error. The adapter deletes either, including on failure.
 * Callbacks may reenter their session. Finalizers must not reenter it. */
typedef wasmtime_error_t *(*callbacksubtypes_wasmtime_callback)(void *data,
    const wasmtime_component_val_t *args, size_t count, wasmtime_component_val_t *out);
wasmtime_error_t *callbacksubtypes_wasmtime_open(callbacksubtypes_wasmtime **out);
/* Callable imports require an owning session. This returns an error; it never
 * partially populates a caller-owned linker. Copied-only packages support link. */
wasmtime_error_t *callbacksubtypes_wasmtime_link(wasmtime_component_linker_t *linker);
/* signature is the resource name from this package's WIT interface.
 * data transfers only on success; release(data) runs once after active calls. */
wasmtime_error_t *callbacksubtypes_wasmtime_callback_create(callbacksubtypes_wasmtime *session,
    const char *signature, callbacksubtypes_wasmtime_callback callback, void *data,
    void (*release)(void *), callbacksubtypes_wasmtime_function *out);
/* Calls exports, including invoke-function-* exports, through the component.
 * Arguments borrow values/tokens. On success out owns a copied value or token.
 * On error out is unchanged. Use a fresh result slot. */
wasmtime_error_t *callbacksubtypes_wasmtime_invoke(callbacksubtypes_wasmtime *session, const char *name,
    const callbacksubtypes_wasmtime_value *args, size_t count, callbacksubtypes_wasmtime_value *out);
/* Compatibility API for exports without callable arguments or results. */
wasmtime_error_t *callbacksubtypes_wasmtime_call(callbacksubtypes_wasmtime *session, const char *name,
    const wasmtime_component_val_t *args, size_t count, wasmtime_component_val_t *out);
/* Zeroes the caller's token on success. Closing zero is harmless. Aliases become
 * invalid immediately; calls already in progress retain their inputs. */
wasmtime_error_t *callbacksubtypes_wasmtime_function_close(callbacksubtypes_wasmtime *session,
    callbacksubtypes_wasmtime_function *function);
/* Sessions/tokens are confined to their creating thread and process.
 * Close releases every token. During a call, destruction waits for its return.
 * No session API may be used after close; copied results remain independent. */
void callbacksubtypes_wasmtime_close(callbacksubtypes_wasmtime *session);
#ifdef __cplusplus
}
#endif
#endif

#include "callbacksubtypes-graph.h"
#ifdef __cplusplus
extern "C" {
#endif
/* These helpers cross the compiled component. Inputs borrow immutable copied
 * values and function tokens; outputs require fresh initialized slots. Copied
 * results own independent storage and use the generated type's _clear function.
 * Returned function tokens use callbacksubtypes_wasmtime_function_close. */
wasmtime_error_t *callbacksubtypes_wasmtime_value_call_host(callbacksubtypes_wasmtime *session, callbacksubtypes_wasmtime_function arg0, callbacksubtypes_scalar_nat_t *out);
wasmtime_error_t *callbacksubtypes_wasmtime_value_call_host_container(callbacksubtypes_wasmtime *session, callbacksubtypes_wasmtime_function arg0, callbacksubtypes_graph_2c6f4131c8731fa67588_t *out);
wasmtime_error_t *callbacksubtypes_wasmtime_value_call_host_mixed(callbacksubtypes_wasmtime *session, callbacksubtypes_wasmtime_function arg0, callbacksubtypes_scalar_nat_t *out);
wasmtime_error_t *callbacksubtypes_wasmtime_value_make_closure(callbacksubtypes_wasmtime *session, const callbacksubtypes_scalar_nat_t *arg0, callbacksubtypes_wasmtime_function *out);
wasmtime_error_t *callbacksubtypes_wasmtime_value_make_container_closure(callbacksubtypes_wasmtime *session, const callbacksubtypes_scalar_nat_t *arg0, callbacksubtypes_wasmtime_function *out);
wasmtime_error_t *callbacksubtypes_wasmtime_value_make_mixed_closure(callbacksubtypes_wasmtime *session, const callbacksubtypes_scalar_nat_t *arg0, callbacksubtypes_wasmtime_function *out);
wasmtime_error_t *callbacksubtypes_wasmtime_function_callbacke84eef4c26bca64196e6_call(callbacksubtypes_wasmtime *session, callbacksubtypes_wasmtime_function arg0, const callbacksubtypes_scalar_nat_t *arg1, callbacksubtypes_scalar_nat_t *out);
wasmtime_error_t *callbacksubtypes_wasmtime_function_callback0cd085da803af7102cc3_call(callbacksubtypes_wasmtime *session, callbacksubtypes_wasmtime_function arg0, const callbacksubtypes_graph_743764d1b67e81fcae92_t *arg1, callbacksubtypes_graph_2c6f4131c8731fa67588_t *out);
wasmtime_error_t *callbacksubtypes_wasmtime_function_callback2ad56570215cca826b8e_call(callbacksubtypes_wasmtime *session, callbacksubtypes_wasmtime_function arg0, const callbacksubtypes_scalar_nat_t *arg1, const callbacksubtypes_scalar_nat_t *arg2, callbacksubtypes_scalar_nat_t *out);
wasmtime_error_t *callbacksubtypes_wasmtime_function_callback0f78910188dae34fd8b0_call(callbacksubtypes_wasmtime *session, callbacksubtypes_wasmtime_function arg0, const callbacksubtypes_scalar_nat_t *arg1, callbacksubtypes_scalar_nat_t *out);
wasmtime_error_t *callbacksubtypes_wasmtime_function_callbackc2ff96fa00e1ff712eba_call(callbacksubtypes_wasmtime *session, callbacksubtypes_wasmtime_function arg0, const callbacksubtypes_graph_6c9c0cf3d3abf9adeb4b_t *arg1, callbacksubtypes_graph_743764d1b67e81fcae92_t *out);
wasmtime_error_t *callbacksubtypes_wasmtime_function_callback34f6a3c1043662b01ed6_call(callbacksubtypes_wasmtime *session, callbacksubtypes_wasmtime_function arg0, const callbacksubtypes_scalar_nat_t *arg1, const callbacksubtypes_scalar_nat_t *arg2, callbacksubtypes_scalar_nat_t *out);
/* Make an independently owned copy for callback results. The source may borrow
 * callback arguments. A fresh destination is required; failure leaves it alone. */
wasmtime_error_t *callbacksubtypes_graph_743764d1b67e81fcae92_t_wasmtime_copy(const callbacksubtypes_graph_743764d1b67e81fcae92_t *value, callbacksubtypes_graph_743764d1b67e81fcae92_t *out);
wasmtime_error_t *callbacksubtypes_graph_2c6f4131c8731fa67588_t_wasmtime_copy(const callbacksubtypes_graph_2c6f4131c8731fa67588_t *value, callbacksubtypes_graph_2c6f4131c8731fa67588_t *out);
wasmtime_error_t *callbacksubtypes_graph_6c9c0cf3d3abf9adeb4b_t_wasmtime_copy(const callbacksubtypes_graph_6c9c0cf3d3abf9adeb4b_t *value, callbacksubtypes_graph_6c9c0cf3d3abf9adeb4b_t *out);
wasmtime_error_t *callbacksubtypes_scalar_nat_t_wasmtime_copy(const callbacksubtypes_scalar_nat_t *value, callbacksubtypes_scalar_nat_t *out);
wasmtime_error_t *callbacksubtypes_scalar_string_t_wasmtime_copy(const callbacksubtypes_scalar_string_t *value, callbacksubtypes_scalar_string_t *out);
/* Typed callbacks borrow their arguments. Return an owned error, or place a
 * valid graph in out that survives until the adapter copies it. An owned root
 * transfers to the adapter on both success and failure. Use _wasmtime_copy to
 * return an independent graph. Callback data transfers only if create succeeds;
 * release(data) runs exactly once after active calls finish. */
typedef wasmtime_error_t *(*callbacksubtypes_wasmtime_callback_callback0cd085da803af7102cc3_fn)(void *data, const callbacksubtypes_graph_743764d1b67e81fcae92_t *arg0, callbacksubtypes_graph_2c6f4131c8731fa67588_t *out);
wasmtime_error_t *callbacksubtypes_wasmtime_callback_callback0cd085da803af7102cc3_create(callbacksubtypes_wasmtime *session, callbacksubtypes_wasmtime_callback_callback0cd085da803af7102cc3_fn callback, void *data, void (*release)(void *), const callbacksubtypes_graph_2c6f4131c8731fa67588_t *recovery, callbacksubtypes_wasmtime_function *out);
typedef wasmtime_error_t *(*callbacksubtypes_wasmtime_callback_callback0f78910188dae34fd8b0_fn)(void *data, const callbacksubtypes_scalar_nat_t *arg0, callbacksubtypes_scalar_nat_t *out);
wasmtime_error_t *callbacksubtypes_wasmtime_callback_callback0f78910188dae34fd8b0_create(callbacksubtypes_wasmtime *session, callbacksubtypes_wasmtime_callback_callback0f78910188dae34fd8b0_fn callback, void *data, void (*release)(void *), callbacksubtypes_wasmtime_function *out);
typedef wasmtime_error_t *(*callbacksubtypes_wasmtime_callback_callback2ad56570215cca826b8e_fn)(void *data, const callbacksubtypes_scalar_nat_t *arg0, const callbacksubtypes_scalar_nat_t *arg1, callbacksubtypes_scalar_nat_t *out);
wasmtime_error_t *callbacksubtypes_wasmtime_callback_callback2ad56570215cca826b8e_create(callbacksubtypes_wasmtime *session, callbacksubtypes_wasmtime_callback_callback2ad56570215cca826b8e_fn callback, void *data, void (*release)(void *), const callbacksubtypes_scalar_nat_t *recovery, callbacksubtypes_wasmtime_function *out);
typedef wasmtime_error_t *(*callbacksubtypes_wasmtime_callback_callback34f6a3c1043662b01ed6_fn)(void *data, const callbacksubtypes_scalar_nat_t *arg0, const callbacksubtypes_scalar_nat_t *arg1, callbacksubtypes_scalar_nat_t *out);
wasmtime_error_t *callbacksubtypes_wasmtime_callback_callback34f6a3c1043662b01ed6_create(callbacksubtypes_wasmtime *session, callbacksubtypes_wasmtime_callback_callback34f6a3c1043662b01ed6_fn callback, void *data, void (*release)(void *), callbacksubtypes_wasmtime_function *out);
typedef wasmtime_error_t *(*callbacksubtypes_wasmtime_callback_callbackc2ff96fa00e1ff712eba_fn)(void *data, const callbacksubtypes_graph_6c9c0cf3d3abf9adeb4b_t *arg0, callbacksubtypes_graph_743764d1b67e81fcae92_t *out);
wasmtime_error_t *callbacksubtypes_wasmtime_callback_callbackc2ff96fa00e1ff712eba_create(callbacksubtypes_wasmtime *session, callbacksubtypes_wasmtime_callback_callbackc2ff96fa00e1ff712eba_fn callback, void *data, void (*release)(void *), callbacksubtypes_wasmtime_function *out);
typedef wasmtime_error_t *(*callbacksubtypes_wasmtime_callback_callbacke84eef4c26bca64196e6_fn)(void *data, const callbacksubtypes_scalar_nat_t *arg0, callbacksubtypes_scalar_nat_t *out);
wasmtime_error_t *callbacksubtypes_wasmtime_callback_callbacke84eef4c26bca64196e6_create(callbacksubtypes_wasmtime *session, callbacksubtypes_wasmtime_callback_callbacke84eef4c26bca64196e6_fn callback, void *data, void (*release)(void *), const callbacksubtypes_scalar_nat_t *recovery, callbacksubtypes_wasmtime_function *out);
#ifdef __cplusplus
}
#endif

#endif /* CALLBACKSUBTYPES_WASMTIME_CALLABLE_GRAPH_H */

/* Stable names for copied containers in fields and callable signatures. */
typedef callbacksubtypes_graph_2c6f4131c8731fa67588_t callbacksubtypes_call_host_container_result_t;
static inline void callbacksubtypes_call_host_container_result_t_init(callbacksubtypes_call_host_container_result_t *value) { callbacksubtypes_graph_2c6f4131c8731fa67588_t_init(value); }
static inline void callbacksubtypes_call_host_container_result_t_clear(callbacksubtypes_call_host_container_result_t *value) { callbacksubtypes_graph_2c6f4131c8731fa67588_t_clear(value); }
typedef callbacksubtypes_graph_743764d1b67e81fcae92_t callbacksubtypes_call_host_container_result_ok_t;
static inline void callbacksubtypes_call_host_container_result_ok_t_init(callbacksubtypes_call_host_container_result_ok_t *value) { callbacksubtypes_graph_743764d1b67e81fcae92_t_init(value); }
static inline void callbacksubtypes_call_host_container_result_ok_t_clear(callbacksubtypes_call_host_container_result_ok_t *value) { callbacksubtypes_graph_743764d1b67e81fcae92_t_clear(value); }
typedef callbacksubtypes_graph_743764d1b67e81fcae92_t callbacksubtypes_callback0cd085da803af7102cc3_argument0_t;
static inline void callbacksubtypes_callback0cd085da803af7102cc3_argument0_t_init(callbacksubtypes_callback0cd085da803af7102cc3_argument0_t *value) { callbacksubtypes_graph_743764d1b67e81fcae92_t_init(value); }
static inline void callbacksubtypes_callback0cd085da803af7102cc3_argument0_t_clear(callbacksubtypes_callback0cd085da803af7102cc3_argument0_t *value) { callbacksubtypes_graph_743764d1b67e81fcae92_t_clear(value); }
typedef callbacksubtypes_graph_2c6f4131c8731fa67588_t callbacksubtypes_callback0cd085da803af7102cc3_result_t;
static inline void callbacksubtypes_callback0cd085da803af7102cc3_result_t_init(callbacksubtypes_callback0cd085da803af7102cc3_result_t *value) { callbacksubtypes_graph_2c6f4131c8731fa67588_t_init(value); }
static inline void callbacksubtypes_callback0cd085da803af7102cc3_result_t_clear(callbacksubtypes_callback0cd085da803af7102cc3_result_t *value) { callbacksubtypes_graph_2c6f4131c8731fa67588_t_clear(value); }
typedef callbacksubtypes_graph_743764d1b67e81fcae92_t callbacksubtypes_callback0cd085da803af7102cc3_result_ok_t;
static inline void callbacksubtypes_callback0cd085da803af7102cc3_result_ok_t_init(callbacksubtypes_callback0cd085da803af7102cc3_result_ok_t *value) { callbacksubtypes_graph_743764d1b67e81fcae92_t_init(value); }
static inline void callbacksubtypes_callback0cd085da803af7102cc3_result_ok_t_clear(callbacksubtypes_callback0cd085da803af7102cc3_result_ok_t *value) { callbacksubtypes_graph_743764d1b67e81fcae92_t_clear(value); }
typedef callbacksubtypes_graph_6c9c0cf3d3abf9adeb4b_t callbacksubtypes_callbackc2ff96fa00e1ff712eba_argument0_t;
static inline void callbacksubtypes_callbackc2ff96fa00e1ff712eba_argument0_t_init(callbacksubtypes_callbackc2ff96fa00e1ff712eba_argument0_t *value) { callbacksubtypes_graph_6c9c0cf3d3abf9adeb4b_t_init(value); }
static inline void callbacksubtypes_callbackc2ff96fa00e1ff712eba_argument0_t_clear(callbacksubtypes_callbackc2ff96fa00e1ff712eba_argument0_t *value) { callbacksubtypes_graph_6c9c0cf3d3abf9adeb4b_t_clear(value); }
typedef callbacksubtypes_graph_743764d1b67e81fcae92_t callbacksubtypes_callbackc2ff96fa00e1ff712eba_argument0_element_t;
static inline void callbacksubtypes_callbackc2ff96fa00e1ff712eba_argument0_element_t_init(callbacksubtypes_callbackc2ff96fa00e1ff712eba_argument0_element_t *value) { callbacksubtypes_graph_743764d1b67e81fcae92_t_init(value); }
static inline void callbacksubtypes_callbackc2ff96fa00e1ff712eba_argument0_element_t_clear(callbacksubtypes_callbackc2ff96fa00e1ff712eba_argument0_element_t *value) { callbacksubtypes_graph_743764d1b67e81fcae92_t_clear(value); }
typedef callbacksubtypes_graph_743764d1b67e81fcae92_t callbacksubtypes_callbackc2ff96fa00e1ff712eba_result_t;
static inline void callbacksubtypes_callbackc2ff96fa00e1ff712eba_result_t_init(callbacksubtypes_callbackc2ff96fa00e1ff712eba_result_t *value) { callbacksubtypes_graph_743764d1b67e81fcae92_t_init(value); }
static inline void callbacksubtypes_callbackc2ff96fa00e1ff712eba_result_t_clear(callbacksubtypes_callbackc2ff96fa00e1ff712eba_result_t *value) { callbacksubtypes_graph_743764d1b67e81fcae92_t_clear(value); }
static inline wasmtime_error_t *callbacksubtypes_call_host_container_result_t_wasmtime_copy(const callbacksubtypes_call_host_container_result_t *value, callbacksubtypes_call_host_container_result_t *out) { return callbacksubtypes_graph_2c6f4131c8731fa67588_t_wasmtime_copy(value, out); }
static inline wasmtime_error_t *callbacksubtypes_call_host_container_result_ok_t_wasmtime_copy(const callbacksubtypes_call_host_container_result_ok_t *value, callbacksubtypes_call_host_container_result_ok_t *out) { return callbacksubtypes_graph_743764d1b67e81fcae92_t_wasmtime_copy(value, out); }
static inline wasmtime_error_t *callbacksubtypes_callback0cd085da803af7102cc3_argument0_t_wasmtime_copy(const callbacksubtypes_callback0cd085da803af7102cc3_argument0_t *value, callbacksubtypes_callback0cd085da803af7102cc3_argument0_t *out) { return callbacksubtypes_graph_743764d1b67e81fcae92_t_wasmtime_copy(value, out); }
static inline wasmtime_error_t *callbacksubtypes_callback0cd085da803af7102cc3_result_t_wasmtime_copy(const callbacksubtypes_callback0cd085da803af7102cc3_result_t *value, callbacksubtypes_callback0cd085da803af7102cc3_result_t *out) { return callbacksubtypes_graph_2c6f4131c8731fa67588_t_wasmtime_copy(value, out); }
static inline wasmtime_error_t *callbacksubtypes_callback0cd085da803af7102cc3_result_ok_t_wasmtime_copy(const callbacksubtypes_callback0cd085da803af7102cc3_result_ok_t *value, callbacksubtypes_callback0cd085da803af7102cc3_result_ok_t *out) { return callbacksubtypes_graph_743764d1b67e81fcae92_t_wasmtime_copy(value, out); }
static inline wasmtime_error_t *callbacksubtypes_callbackc2ff96fa00e1ff712eba_argument0_t_wasmtime_copy(const callbacksubtypes_callbackc2ff96fa00e1ff712eba_argument0_t *value, callbacksubtypes_callbackc2ff96fa00e1ff712eba_argument0_t *out) { return callbacksubtypes_graph_6c9c0cf3d3abf9adeb4b_t_wasmtime_copy(value, out); }
static inline wasmtime_error_t *callbacksubtypes_callbackc2ff96fa00e1ff712eba_argument0_element_t_wasmtime_copy(const callbacksubtypes_callbackc2ff96fa00e1ff712eba_argument0_element_t *value, callbacksubtypes_callbackc2ff96fa00e1ff712eba_argument0_element_t *out) { return callbacksubtypes_graph_743764d1b67e81fcae92_t_wasmtime_copy(value, out); }
static inline wasmtime_error_t *callbacksubtypes_callbackc2ff96fa00e1ff712eba_result_t_wasmtime_copy(const callbacksubtypes_callbackc2ff96fa00e1ff712eba_result_t *value, callbacksubtypes_callbackc2ff96fa00e1ff712eba_result_t *out) { return callbacksubtypes_graph_743764d1b67e81fcae92_t_wasmtime_copy(value, out); }
/* Export-specific names do not expose signature hashes to ordinary callers. */
typedef callbacksubtypes_wasmtime_callback_callbacke84eef4c26bca64196e6_fn callbacksubtypes_wasmtime_call_host_callback0_fn;
static inline wasmtime_error_t *callbacksubtypes_wasmtime_call_host_callback0_create(callbacksubtypes_wasmtime *session, callbacksubtypes_wasmtime_call_host_callback0_fn callback, void *data, void (*release)(void *), const callbacksubtypes_scalar_nat_t *recovery, callbacksubtypes_wasmtime_function *out) {
  return callbacksubtypes_wasmtime_callback_callbacke84eef4c26bca64196e6_create(session, callback, data, release, recovery, out);
}
typedef callbacksubtypes_wasmtime_callback_callback0cd085da803af7102cc3_fn callbacksubtypes_wasmtime_call_host_container_callback0_fn;
static inline wasmtime_error_t *callbacksubtypes_wasmtime_call_host_container_callback0_create(callbacksubtypes_wasmtime *session, callbacksubtypes_wasmtime_call_host_container_callback0_fn callback, void *data, void (*release)(void *), const callbacksubtypes_graph_2c6f4131c8731fa67588_t *recovery, callbacksubtypes_wasmtime_function *out) {
  return callbacksubtypes_wasmtime_callback_callback0cd085da803af7102cc3_create(session, callback, data, release, recovery, out);
}
typedef callbacksubtypes_wasmtime_callback_callback2ad56570215cca826b8e_fn callbacksubtypes_wasmtime_call_host_mixed_callback0_fn;
static inline wasmtime_error_t *callbacksubtypes_wasmtime_call_host_mixed_callback0_create(callbacksubtypes_wasmtime *session, callbacksubtypes_wasmtime_call_host_mixed_callback0_fn callback, void *data, void (*release)(void *), const callbacksubtypes_scalar_nat_t *recovery, callbacksubtypes_wasmtime_function *out) {
  return callbacksubtypes_wasmtime_callback_callback2ad56570215cca826b8e_create(session, callback, data, release, recovery, out);
}
static inline wasmtime_error_t *callbacksubtypes_wasmtime_make_closure_call(callbacksubtypes_wasmtime *session, callbacksubtypes_wasmtime_function self, const callbacksubtypes_scalar_nat_t *arg0, callbacksubtypes_scalar_nat_t *out) {
  return callbacksubtypes_wasmtime_function_callback0f78910188dae34fd8b0_call(session, self, arg0, out);
}
static inline wasmtime_error_t *callbacksubtypes_wasmtime_make_container_closure_call(callbacksubtypes_wasmtime *session, callbacksubtypes_wasmtime_function self, const callbacksubtypes_graph_6c9c0cf3d3abf9adeb4b_t *arg0, callbacksubtypes_graph_743764d1b67e81fcae92_t *out) {
  return callbacksubtypes_wasmtime_function_callbackc2ff96fa00e1ff712eba_call(session, self, arg0, out);
}
static inline wasmtime_error_t *callbacksubtypes_wasmtime_make_mixed_closure_call(callbacksubtypes_wasmtime *session, callbacksubtypes_wasmtime_function self, const callbacksubtypes_scalar_nat_t *arg0, const callbacksubtypes_scalar_nat_t *arg1, callbacksubtypes_scalar_nat_t *out) {
  return callbacksubtypes_wasmtime_function_callback34f6a3c1043662b01ed6_call(session, self, arg0, arg1, out);
}
#endif /* CALLBACKSUBTYPES_WASMTIME_CALLABLE_GRAPH_PACKAGE_H */
