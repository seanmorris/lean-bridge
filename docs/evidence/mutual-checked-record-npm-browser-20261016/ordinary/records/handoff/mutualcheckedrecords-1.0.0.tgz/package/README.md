# mutualcheckedrecords

Compiler-checked exports for mutualcheckedrecords.

Binding IR SHA-256: `5a794d0c15d10efc26ed3f5ef79f701356523cb78ebaaf9bc9d5bbdf32cc095a`

## Exports

### echo

Call MutualCheckedRecords.echo.

### echoGroups

Call MutualCheckedRecords.echoGroups.

### first

Call MutualCheckedRecords.first.

### groups

Call MutualCheckedRecords.groups.

### produce

Call MutualCheckedRecords.produce.

### second

Call MutualCheckedRecords.second.

## Assurance

