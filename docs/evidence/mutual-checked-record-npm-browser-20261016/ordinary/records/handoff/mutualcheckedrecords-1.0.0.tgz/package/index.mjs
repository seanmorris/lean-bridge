// Generated from Binding IR SHA-256 5a794d0c15d10efc26ed3f5ef79f701356523cb78ebaaf9bc9d5bbdf32cc095a.
import { runtime } from "./internal/runtime.mjs";
import * as validate from "./internal/validators.mjs";

/**
 * Call MutualCheckedRecords.echo.
 */
export function echo(arg0) {
  validate.assertEnvelope(arg0, "echo.arg0");
  const result = runtime.call("lean:MutualCheckedRecords.echo", [arg0]);
  validate.assertEnvelope(result, "echo.result");
  return result;
}

/**
 * Call MutualCheckedRecords.echoGroups.
 */
export function echoGroups(arg0) {
  validate.assertArrayOfApplied$b13e71fc9d55433b5b85(arg0, "echoGroups.arg0");
  validate.assertNestedFin(arg0, {"arguments":[{"arguments":[{"constructor":"MutualCheckedRecords.normalizeEnvelope","fields":[{"name":"value","refinement":{"constructor":"MutualCheckedRecords.plusTwo","kind":"subtype"}},{"name":"mode","refinement":{"bound":"3","kind":"fin"}},{"name":"next","refinement":null}],"kind":"checked-record","name":"MutualCheckedRecords.Envelope"}],"kind":"option"}],"kind":"array"}, "echoGroups.arg0");
  const result = runtime.call("lean:MutualCheckedRecords.echoGroups", [arg0]);
  validate.assertArrayOfApplied$b13e71fc9d55433b5b85(result, "echoGroups.result");
  validate.assertNestedFin(result, {"arguments":[{"arguments":[{"constructor":null,"fields":[{"name":"value","refinement":{"constructor":null,"kind":"subtype"}},{"name":"mode","refinement":{"bound":"3","kind":"fin"}},{"name":"next","refinement":null}],"kind":"checked-record","name":"MutualCheckedRecords.Envelope"}],"kind":"option"}],"kind":"array"}, "echoGroups.result");
  return result;
}

/**
 * Call MutualCheckedRecords.first.
 */
export function first(arg0) {
  validate.assertEnvelope(arg0, "first.arg0");
  const result = runtime.call("lean:MutualCheckedRecords.first", [arg0]);
  validate.assertNat(result, "first.result");
  return result;
}

/**
 * Call MutualCheckedRecords.groups.
 */
export function groups(arg0) {
  validate.assertArrayOfApplied$b13e71fc9d55433b5b85(arg0, "groups.arg0");
  validate.assertNestedFin(arg0, {"arguments":[{"arguments":[{"constructor":"MutualCheckedRecords.mkEnvelope","fields":[{"name":"value","refinement":{"constructor":"MutualCheckedRecords.plusOne","kind":"subtype"}},{"name":"mode","refinement":{"bound":"3","kind":"fin"}},{"name":"next","refinement":null}],"kind":"checked-record","name":"MutualCheckedRecords.Envelope"}],"kind":"option"}],"kind":"array"}, "groups.arg0");
  const result = runtime.call("lean:MutualCheckedRecords.groups", [arg0]);
  validate.assertNat(result, "groups.result");
  return result;
}

/**
 * Call MutualCheckedRecords.produce.
 */
export function produce(arg0) {
  validate.assertNat(arg0, "produce.arg0");
  const result = runtime.call("lean:MutualCheckedRecords.produce", [arg0]);
  validate.assertEnvelope(result, "produce.result");
  return result;
}

/**
 * Call MutualCheckedRecords.second.
 */
export function second(arg0) {
  validate.assertEnvelope(arg0, "second.arg0");
  const result = runtime.call("lean:MutualCheckedRecords.second", [arg0]);
  validate.assertNat(result, "second.result");
  return result;
}

export default Object.freeze({ echo, echoGroups, first, groups, produce, second });
