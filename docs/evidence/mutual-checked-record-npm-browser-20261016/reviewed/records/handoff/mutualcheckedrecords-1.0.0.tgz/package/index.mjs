// Generated from Binding IR SHA-256 0b023197b9eda95e08827f1f8487879ce65ed2dc74218fadbcaa0aa1d4427d4a.
import { runtime } from "./internal/runtime.mjs";
import * as validate from "./internal/validators.mjs";

/**
 * Independent corpus contract.
 */
export function echo(value0) {
  validate.assertEnvelope(value0, "echo.value0");
  const result = runtime.call("lean:MutualCheckedRecords.echo", [value0]);
  validate.assertEnvelope(result, "echo.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function echoGroups(value0) {
  validate.assertArrayOfApplied$b13e71fc9d55433b5b85(value0, "echoGroups.value0");
  validate.assertNestedFin(value0, {"arguments":[{"arguments":[{"constructor":"MutualCheckedRecords.normalizeEnvelope","fields":[{"name":"value","refinement":{"constructor":"MutualCheckedRecords.plusTwo","kind":"subtype"}},{"name":"mode","refinement":{"bound":"3","kind":"fin"}},{"name":"next","refinement":null}],"kind":"checked-record","name":"MutualCheckedRecords.Envelope"}],"kind":"option"}],"kind":"array"}, "echoGroups.value0");
  const result = runtime.call("lean:MutualCheckedRecords.echoGroups", [value0]);
  validate.assertArrayOfApplied$b13e71fc9d55433b5b85(result, "echoGroups.result");
  validate.assertNestedFin(result, {"arguments":[{"arguments":[{"constructor":null,"fields":[{"name":"value","refinement":{"constructor":null,"kind":"subtype"}},{"name":"mode","refinement":{"bound":"3","kind":"fin"}},{"name":"next","refinement":null}],"kind":"checked-record","name":"MutualCheckedRecords.Envelope"}],"kind":"option"}],"kind":"array"}, "echoGroups.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function first(value0) {
  validate.assertEnvelope(value0, "first.value0");
  const result = runtime.call("lean:MutualCheckedRecords.first", [value0]);
  validate.assertNat(result, "first.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function groups(value0) {
  validate.assertArrayOfApplied$b13e71fc9d55433b5b85(value0, "groups.value0");
  validate.assertNestedFin(value0, {"arguments":[{"arguments":[{"constructor":"MutualCheckedRecords.mkEnvelope","fields":[{"name":"value","refinement":{"constructor":"MutualCheckedRecords.plusOne","kind":"subtype"}},{"name":"mode","refinement":{"bound":"3","kind":"fin"}},{"name":"next","refinement":null}],"kind":"checked-record","name":"MutualCheckedRecords.Envelope"}],"kind":"option"}],"kind":"array"}, "groups.value0");
  const result = runtime.call("lean:MutualCheckedRecords.groups", [value0]);
  validate.assertNat(result, "groups.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function produce(value0) {
  validate.assertNat(value0, "produce.value0");
  const result = runtime.call("lean:MutualCheckedRecords.produce", [value0]);
  validate.assertEnvelope(result, "produce.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function second(value0) {
  validate.assertEnvelope(value0, "second.value0");
  const result = runtime.call("lean:MutualCheckedRecords.second", [value0]);
  validate.assertNat(result, "second.result");
  return result;
}

export default Object.freeze({ echo, echoGroups, first, groups, produce, second });
