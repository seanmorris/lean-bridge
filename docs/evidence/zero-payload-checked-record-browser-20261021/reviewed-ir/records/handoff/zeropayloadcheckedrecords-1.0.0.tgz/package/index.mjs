// Generated from Binding IR SHA-256 ff3debc404b0f2f2bcfeedb5ee08cce29f12df1a1c7cf35c33aa34fc5e51e9e5.
import { runtime } from "./internal/runtime.mjs";
import * as validate from "./internal/validators.mjs";

/**
 * Independent corpus contract.
 */
export function absentCount(value0) {
  validate.assertWitness(value0, "absentCount.value0");
  const result = runtime.call("lean:ZeroPayloadCheckedRecords.absentCount", [value0]);
  validate.assertNat(result, "absentCount.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function markCount(value0) {
  validate.assertMark(value0, "markCount.value0");
  validate.assertNestedFin(value0, {"cases":[{"fields":[],"name":"blank"},{"fields":[{"name":"witness","refinement":{"constructor":"ZeroPayloadCheckedRecords.mkWitness","fields":[],"kind":"checked-record","name":"ZeroPayloadCheckedRecords.Witness"}}],"name":"marked"}],"kind":"variant","name":"ZeroPayloadCheckedRecords.Mark"}, "markCount.value0");
  const result = runtime.call("lean:ZeroPayloadCheckedRecords.markCount", [value0]);
  validate.assertNat(result, "markCount.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function markerCount(value0) {
  validate.assertMarker(value0, "markerCount.value0");
  const result = runtime.call("lean:ZeroPayloadCheckedRecords.markerCount", [value0]);
  validate.assertNat(result, "markerCount.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function maybeWitness(value0) {
  validate.assertBool(value0, "maybeWitness.value0");
  const result = runtime.call("lean:ZeroPayloadCheckedRecords.maybeWitness", [value0]);
  validate.assertApplied$e0ea668eafb357a31934(result, "maybeWitness.result");
  validate.assertNestedFin(result, {"arguments":[{"constructor":null,"fields":[],"kind":"checked-record","name":"ZeroPayloadCheckedRecords.Witness"}],"kind":"option"}, "maybeWitness.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function produceMark(value0) {
  validate.assertBool(value0, "produceMark.value0");
  const result = runtime.call("lean:ZeroPayloadCheckedRecords.produceMark", [value0]);
  validate.assertMark(result, "produceMark.result");
  validate.assertNestedFin(result, {"cases":[{"fields":[],"name":"blank"},{"fields":[{"name":"witness","refinement":{"constructor":null,"fields":[],"kind":"checked-record","name":"ZeroPayloadCheckedRecords.Witness"}}],"name":"marked"}],"kind":"variant","name":"ZeroPayloadCheckedRecords.Mark"}, "produceMark.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function produceMarker() {
  const result = runtime.call("lean:ZeroPayloadCheckedRecords.produceMarker", []);
  validate.assertMarker(result, "produceMarker.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function produceToken() {
  const result = runtime.call("lean:ZeroPayloadCheckedRecords.produceToken", []);
  validate.assertToken(result, "produceToken.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function produceWitness() {
  const result = runtime.call("lean:ZeroPayloadCheckedRecords.produceWitness", []);
  validate.assertWitness(result, "produceWitness.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function tokenTag(value0) {
  validate.assertToken(value0, "tokenTag.value0");
  const result = runtime.call("lean:ZeroPayloadCheckedRecords.tokenTag", [value0]);
  validate.assertUnit(result, "tokenTag.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function witnessCount(value0) {
  validate.assertWitness(value0, "witnessCount.value0");
  const result = runtime.call("lean:ZeroPayloadCheckedRecords.witnessCount", [value0]);
  validate.assertNat(result, "witnessCount.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function witnesses(value0) {
  validate.assertNat(value0, "witnesses.value0");
  const result = runtime.call("lean:ZeroPayloadCheckedRecords.witnesses", [value0]);
  validate.assertArrayOfWitness(result, "witnesses.result");
  validate.assertNestedFin(result, {"arguments":[{"constructor":null,"fields":[],"kind":"checked-record","name":"ZeroPayloadCheckedRecords.Witness"}],"kind":"array"}, "witnesses.result");
  return result;
}

export default Object.freeze({ absentCount, markCount, markerCount, maybeWitness, produceMark, produceMarker, produceToken, produceWitness, tokenTag, witnessCount, witnesses });
