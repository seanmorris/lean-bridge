# zeropayloadcheckedrecords

Independent corpus contract.

Binding IR SHA-256: `ff3debc404b0f2f2bcfeedb5ee08cce29f12df1a1c7cf35c33aa34fc5e51e9e5`

## Exports

### absentCount

Independent corpus contract.

### markCount

Independent corpus contract.

### markerCount

Independent corpus contract.

### maybeWitness

Independent corpus contract.

### produceMark

Independent corpus contract.

### produceMarker

Independent corpus contract.

### produceToken

Independent corpus contract.

### produceWitness

Independent corpus contract.

### tokenTag

Independent corpus contract.

### witnessCount

Independent corpus contract.

### witnesses

Independent corpus contract.

## Assurance

