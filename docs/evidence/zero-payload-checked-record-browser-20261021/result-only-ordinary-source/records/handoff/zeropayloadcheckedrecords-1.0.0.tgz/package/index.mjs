// Generated from Binding IR SHA-256 5f06dbec168e81ab085000c1bf77072f86f69a08263c6e7cea195720c52b56d2.
import { runtime } from "./internal/runtime.mjs";
import * as validate from "./internal/validators.mjs";

/**
 * Call ZeroPayloadCheckedRecords.maybeWitness.
 */
export function maybeWitness(arg0) {
  validate.assertBool(arg0, "maybeWitness.arg0");
  const result = runtime.call("lean:ZeroPayloadCheckedRecords.maybeWitness", [arg0]);
  validate.assertApplied$e0ea668eafb357a31934(result, "maybeWitness.result");
  validate.assertNestedFin(result, {"arguments":[{"constructor":null,"fields":[],"kind":"checked-record","name":"ZeroPayloadCheckedRecords.Witness"}],"kind":"option"}, "maybeWitness.result");
  return result;
}

/**
 * Call ZeroPayloadCheckedRecords.produceMark.
 */
export function produceMark(arg0) {
  validate.assertBool(arg0, "produceMark.arg0");
  const result = runtime.call("lean:ZeroPayloadCheckedRecords.produceMark", [arg0]);
  validate.assertMark(result, "produceMark.result");
  validate.assertNestedFin(result, {"cases":[{"fields":[],"name":"blank"},{"fields":[{"name":"witness","refinement":{"constructor":null,"fields":[],"kind":"checked-record","name":"ZeroPayloadCheckedRecords.Witness"}}],"name":"marked"}],"kind":"variant","name":"ZeroPayloadCheckedRecords.Mark"}, "produceMark.result");
  return result;
}

/**
 * Call ZeroPayloadCheckedRecords.produceMarker.
 */
export function produceMarker() {
  const result = runtime.call("lean:ZeroPayloadCheckedRecords.produceMarker", []);
  validate.assertMarker(result, "produceMarker.result");
  return result;
}

/**
 * Call ZeroPayloadCheckedRecords.produceToken.
 */
export function produceToken() {
  const result = runtime.call("lean:ZeroPayloadCheckedRecords.produceToken", []);
  validate.assertToken(result, "produceToken.result");
  return result;
}

/**
 * Lean produces the proof; the host receives the empty carrier. 
 */
export function produceWitness() {
  const result = runtime.call("lean:ZeroPayloadCheckedRecords.produceWitness", []);
  validate.assertWitness(result, "produceWitness.result");
  return result;
}

/**
 * Containers of zero-payload results keep their length and presence. 
 */
export function witnesses(arg0) {
  validate.assertNat(arg0, "witnesses.arg0");
  const result = runtime.call("lean:ZeroPayloadCheckedRecords.witnesses", [arg0]);
  validate.assertArrayOfWitness(result, "witnesses.result");
  validate.assertNestedFin(result, {"arguments":[{"constructor":null,"fields":[],"kind":"checked-record","name":"ZeroPayloadCheckedRecords.Witness"}],"kind":"array"}, "witnesses.result");
  return result;
}

export default Object.freeze({ maybeWitness, produceMark, produceMarker, produceToken, produceWitness, witnesses });
