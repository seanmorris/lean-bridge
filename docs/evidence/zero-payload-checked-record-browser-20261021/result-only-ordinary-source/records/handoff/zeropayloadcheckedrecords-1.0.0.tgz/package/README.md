# zeropayloadcheckedrecords

Compiler-checked exports for zeropayloadcheckedrecords.

Binding IR SHA-256: `5f06dbec168e81ab085000c1bf77072f86f69a08263c6e7cea195720c52b56d2`

## Exports

### maybeWitness

Call ZeroPayloadCheckedRecords.maybeWitness.

### produceMark

Call ZeroPayloadCheckedRecords.produceMark.

### produceMarker

Call ZeroPayloadCheckedRecords.produceMarker.

### produceToken

Call ZeroPayloadCheckedRecords.produceToken.

### produceWitness

Lean produces the proof; the host receives the empty carrier. 

### witnesses

Containers of zero-payload results keep their length and presence. 

## Assurance

