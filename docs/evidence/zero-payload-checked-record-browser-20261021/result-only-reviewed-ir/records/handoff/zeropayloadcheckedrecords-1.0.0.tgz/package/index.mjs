// Generated from Binding IR SHA-256 57bd0af332c6ed6dd3f53859cce38bed912683b030a9cb896af12ac613040804.
import { runtime } from "./internal/runtime.mjs";
import * as validate from "./internal/validators.mjs";

/**
 * Independent corpus contract.
 */
export function maybeWitness(value0) {
  validate.assertBool(value0, "maybeWitness.value0");
  const result = runtime.call("lean:ZeroPayloadCheckedRecords.maybeWitness", [value0]);
  validate.assertApplied$e0ea668eafb357a31934(result, "maybeWitness.result");
  validate.assertNestedFin(result, {"arguments":[{"constructor":null,"fields":[],"kind":"checked-record","name":"ZeroPayloadCheckedRecords.Witness"}],"kind":"option"}, "maybeWitness.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function produceMark(value0) {
  validate.assertBool(value0, "produceMark.value0");
  const result = runtime.call("lean:ZeroPayloadCheckedRecords.produceMark", [value0]);
  validate.assertMark(result, "produceMark.result");
  validate.assertNestedFin(result, {"cases":[{"fields":[],"name":"blank"},{"fields":[{"name":"witness","refinement":{"constructor":null,"fields":[],"kind":"checked-record","name":"ZeroPayloadCheckedRecords.Witness"}}],"name":"marked"}],"kind":"variant","name":"ZeroPayloadCheckedRecords.Mark"}, "produceMark.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function produceMarker() {
  const result = runtime.call("lean:ZeroPayloadCheckedRecords.produceMarker", []);
  validate.assertMarker(result, "produceMarker.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function produceToken() {
  const result = runtime.call("lean:ZeroPayloadCheckedRecords.produceToken", []);
  validate.assertToken(result, "produceToken.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function produceWitness() {
  const result = runtime.call("lean:ZeroPayloadCheckedRecords.produceWitness", []);
  validate.assertWitness(result, "produceWitness.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function witnesses(value0) {
  validate.assertNat(value0, "witnesses.value0");
  const result = runtime.call("lean:ZeroPayloadCheckedRecords.witnesses", [value0]);
  validate.assertArrayOfWitness(result, "witnesses.result");
  validate.assertNestedFin(result, {"arguments":[{"constructor":null,"fields":[],"kind":"checked-record","name":"ZeroPayloadCheckedRecords.Witness"}],"kind":"array"}, "witnesses.result");
  return result;
}

export default Object.freeze({ maybeWitness, produceMark, produceMarker, produceToken, produceWitness, witnesses });
