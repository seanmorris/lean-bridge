# zeropayloadcheckedrecords

Independent corpus contract.

Binding IR SHA-256: `57bd0af332c6ed6dd3f53859cce38bed912683b030a9cb896af12ac613040804`

## Exports

### maybeWitness

Independent corpus contract.

### produceMark

Independent corpus contract.

### produceMarker

Independent corpus contract.

### produceToken

Independent corpus contract.

### produceWitness

Independent corpus contract.

### witnesses

Independent corpus contract.

## Assurance

