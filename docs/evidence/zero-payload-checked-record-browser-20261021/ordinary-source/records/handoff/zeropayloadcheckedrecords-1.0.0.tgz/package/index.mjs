// Generated from Binding IR SHA-256 e4d803a36e29c17e2798c52261ff35266262d52b8733f6c5321f4b7018f7c784.
import { runtime } from "./internal/runtime.mjs";
import * as validate from "./internal/validators.mjs";

/**
 * The same input site under the refusing constructor. 
 */
export function absentCount(arg0) {
  validate.assertWitness(arg0, "absentCount.arg0");
  const result = runtime.call("lean:ZeroPayloadCheckedRecords.absentCount", [arg0]);
  validate.assertNat(result, "absentCount.result");
  return result;
}

/**
 * Both variant branches remain distinct after the nested proof has been erased. 
 */
export function markCount(arg0) {
  validate.assertMark(arg0, "markCount.arg0");
  validate.assertNestedFin(arg0, {"cases":[{"fields":[],"name":"blank"},{"fields":[{"name":"witness","refinement":{"constructor":"ZeroPayloadCheckedRecords.mkWitness","fields":[],"kind":"checked-record","name":"ZeroPayloadCheckedRecords.Witness"}}],"name":"marked"}],"kind":"variant","name":"ZeroPayloadCheckedRecords.Mark"}, "markCount.arg0");
  const result = runtime.call("lean:ZeroPayloadCheckedRecords.markCount", [arg0]);
  validate.assertNat(result, "markCount.result");
  return result;
}

/**
 * A plain empty record crosses as an ordinary copied record in both directions. 
 */
export function markerCount(arg0) {
  validate.assertMarker(arg0, "markerCount.arg0");
  const result = runtime.call("lean:ZeroPayloadCheckedRecords.markerCount", [arg0]);
  validate.assertNat(result, "markerCount.result");
  return result;
}

/**
 * Call ZeroPayloadCheckedRecords.maybeWitness.
 */
export function maybeWitness(arg0) {
  validate.assertBool(arg0, "maybeWitness.arg0");
  const result = runtime.call("lean:ZeroPayloadCheckedRecords.maybeWitness", [arg0]);
  validate.assertApplied$e0ea668eafb357a31934(result, "maybeWitness.result");
  validate.assertNestedFin(result, {"arguments":[{"constructor":null,"fields":[],"kind":"checked-record","name":"ZeroPayloadCheckedRecords.Witness"}],"kind":"option"}, "maybeWitness.result");
  return result;
}

/**
 * Call ZeroPayloadCheckedRecords.produceMark.
 */
export function produceMark(arg0) {
  validate.assertBool(arg0, "produceMark.arg0");
  const result = runtime.call("lean:ZeroPayloadCheckedRecords.produceMark", [arg0]);
  validate.assertMark(result, "produceMark.result");
  validate.assertNestedFin(result, {"cases":[{"fields":[],"name":"blank"},{"fields":[{"name":"witness","refinement":{"constructor":null,"fields":[],"kind":"checked-record","name":"ZeroPayloadCheckedRecords.Witness"}}],"name":"marked"}],"kind":"variant","name":"ZeroPayloadCheckedRecords.Mark"}, "produceMark.result");
  return result;
}

/**
 * Call ZeroPayloadCheckedRecords.produceMarker.
 */
export function produceMarker() {
  const result = runtime.call("lean:ZeroPayloadCheckedRecords.produceMarker", []);
  validate.assertMarker(result, "produceMarker.result");
  return result;
}

/**
 * Call ZeroPayloadCheckedRecords.produceToken.
 */
export function produceToken() {
  const result = runtime.call("lean:ZeroPayloadCheckedRecords.produceToken", []);
  validate.assertToken(result, "produceToken.result");
  return result;
}

/**
 * Lean produces the proof; the host receives the empty carrier. 
 */
export function produceWitness() {
  const result = runtime.call("lean:ZeroPayloadCheckedRecords.produceWitness", []);
  validate.assertWitness(result, "produceWitness.result");
  return result;
}

/**
 * Read the unit tag of a checked token input. 
 */
export function tokenTag(arg0) {
  validate.assertToken(arg0, "tokenTag.arg0");
  const result = runtime.call("lean:ZeroPayloadCheckedRecords.tokenTag", [arg0]);
  validate.assertUnit(result, "tokenTag.result");
  return result;
}

/**
 * Count a checked proof-only input. 
 */
export function witnessCount(arg0) {
  validate.assertWitness(arg0, "witnessCount.arg0");
  const result = runtime.call("lean:ZeroPayloadCheckedRecords.witnessCount", [arg0]);
  validate.assertNat(result, "witnessCount.result");
  return result;
}

/**
 * Containers of zero-payload results keep their length and presence. 
 */
export function witnesses(arg0) {
  validate.assertNat(arg0, "witnesses.arg0");
  const result = runtime.call("lean:ZeroPayloadCheckedRecords.witnesses", [arg0]);
  validate.assertArrayOfWitness(result, "witnesses.result");
  validate.assertNestedFin(result, {"arguments":[{"constructor":null,"fields":[],"kind":"checked-record","name":"ZeroPayloadCheckedRecords.Witness"}],"kind":"array"}, "witnesses.result");
  return result;
}

export default Object.freeze({ absentCount, markCount, markerCount, maybeWitness, produceMark, produceMarker, produceToken, produceWitness, tokenTag, witnessCount, witnesses });
