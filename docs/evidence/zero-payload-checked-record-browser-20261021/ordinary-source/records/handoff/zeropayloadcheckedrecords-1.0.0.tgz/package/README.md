# zeropayloadcheckedrecords

Compiler-checked exports for zeropayloadcheckedrecords.

Binding IR SHA-256: `e4d803a36e29c17e2798c52261ff35266262d52b8733f6c5321f4b7018f7c784`

## Exports

### absentCount

The same input site under the refusing constructor. 

### markCount

Both variant branches remain distinct after the nested proof has been erased. 

### markerCount

A plain empty record crosses as an ordinary copied record in both directions. 

### maybeWitness

Call ZeroPayloadCheckedRecords.maybeWitness.

### produceMark

Call ZeroPayloadCheckedRecords.produceMark.

### produceMarker

Call ZeroPayloadCheckedRecords.produceMarker.

### produceToken

Call ZeroPayloadCheckedRecords.produceToken.

### produceWitness

Lean produces the proof; the host receives the empty carrier. 

### tokenTag

Read the unit tag of a checked token input. 

### witnessCount

Count a checked proof-only input. 

### witnesses

Containers of zero-payload results keep their length and presence. 

## Assurance

