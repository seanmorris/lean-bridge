<?php
declare(strict_types=1);
namespace LeanOwnedSubtypes;

require_once __DIR__ . '/Internal/Values.php';



final class LeanBridgeError extends \RuntimeException {}

final readonly class Bytes implements \Stringable, \Countable
{
    private function __construct(private string $value) {}
    public static function fromString(mixed $value): self {
        if (!\is_string($value)) throw new \TypeError('Bytes requires a string');
        return new self($value);
    }
    public function toString(): string { return $this->value; }
    public function __toString(): string { return $this->value; }
    public function count(): int { return \strlen($this->value); }

    public function equals(mixed $other): bool {
        return $other instanceof self && Internal\Values::equal($this, $other);
    }
    public function hashCode(): string { return Internal\Values::hash($this); }

}


/** @template T */
final readonly class Some
{
    /** @var T */
    public mixed $value;
    /** @param T $value */
    public function __construct(mixed $value) {
        if (\func_num_args() !== 1) throw new \ArgumentCountError('Some requires one payload');
        $this->value = $value;
    }

    public function equals(mixed $other): bool {
        return $other instanceof self && Internal\Values::equal($this, $other);
    }
    public function hashCode(): string { return Internal\Values::hash($this); }

}

/** @template T */
final readonly class Ok
{
    /** @var T */
    public mixed $value;
    /** @param T $value */
    public function __construct(mixed $value) {
        if (\func_num_args() !== 1) throw new \ArgumentCountError('Ok requires one payload');
        $this->value = $value;
    }

    public function equals(mixed $other): bool {
        return $other instanceof self && Internal\Values::equal($this, $other);
    }
    public function hashCode(): string { return Internal\Values::hash($this); }

}

/** @template T */
final readonly class Err
{
    /** @var T */
    public mixed $value;
    /** @param T $value */
    public function __construct(mixed $value) {
        if (\func_num_args() !== 1) throw new \ArgumentCountError('Err requires one payload');
        $this->value = $value;
    }

    public function equals(mixed $other): bool {
        return $other instanceof self && Internal\Values::equal($this, $other);
    }
    public function hashCode(): string { return Internal\Values::hash($this); }

}

final readonly class Bundle
{
    /** @var Ticket */
    public Ticket $primary;
    /** @var Some<Ticket>|null */
    public Some|null $spare;
    /** @var list<Ticket> */
    public array $peers;
    /** @var list<Ticket> */
    public array $history;
    /** @var Payload */
    public Payload $payload;
    public function __construct(mixed $primary, mixed $spare, mixed $peers, mixed $history, mixed $payload) {
        if (\func_num_args() !== 5) throw new \ArgumentCountError('Bundle requires exactly 5 fields');
        Internal\Values::checkFields(self::class, [$primary, $spare, $peers, $history, $payload]);
        $this->primary = $primary;
        $this->spare = $spare;
        $this->peers = $peers;
        $this->history = $history;
        $this->payload = $payload;
    }

    public function equals(mixed $other): bool {
        return $other instanceof self && Internal\Values::equal($this, $other);
    }
    public function hashCode(): string { return Internal\Values::hash($this); }

}

final readonly class Payload
{
    /** @var \Brick\Math\BigInteger */
    public \Brick\Math\BigInteger $count;
    /** @var Bytes */
    public Bytes $bytes;
    public function __construct(mixed $count, mixed $bytes) {
        if (\func_num_args() !== 2) throw new \ArgumentCountError('Payload requires exactly 2 fields');
        Internal\Values::checkFields(self::class, [$count, $bytes]);
        $this->count = $count;
        $this->bytes = $bytes;
    }

    public function equals(mixed $other): bool {
        return $other instanceof self && Internal\Values::equal($this, $other);
    }
    public function hashCode(): string { return Internal\Values::hash($this); }

}
final class Ticket extends Internal\Resource
{
}

final readonly class WithRecovery
{
    public function __construct(public mixed $callback, public mixed $value) {
        if (\func_num_args() !== 2) throw new \ArgumentCountError('WithRecovery requires a callback and typed value');
    }
}
function with_recovery(mixed $callback, mixed $value): WithRecovery {
    if (\func_num_args() !== 2) throw new \ArgumentCountError('with_recovery requires two arguments');
    return new WithRecovery($callback, $value);
}
require_once __DIR__ . '/Internal/OwnedCalls.php';
/**
 * @param Bundle $arg0
 * @return Bundle
 */
function echo_record(mixed $arg0): Bundle {
    if (\func_num_args() !== 1) throw new \ArgumentCountError('echo_record requires exactly 1 arguments');
    return Internal\Native::call('echo_record', [$arg0]);
}

/**
 * @param Bundle $arg0
 * @return Bundle
 */
function echo_record_alternate(mixed $arg0): Bundle {
    if (\func_num_args() !== 1) throw new \ArgumentCountError('echo_record_alternate requires exactly 1 arguments');
    return Internal\Native::call('echo_record_alternate', [$arg0]);
}

/**
 * @param \Brick\Math\BigInteger $arg0
 * @param string $arg1
 * @return Ticket
 */
function new_ticket(mixed $arg0, mixed $arg1): Ticket {
    if (\func_num_args() !== 2) throw new \ArgumentCountError('new_ticket requires exactly 2 arguments');
    return Internal\Native::call('new_ticket', [$arg0, $arg1]);
}

/**
 * @param Ticket $arg0
 * @return \Brick\Math\BigInteger
 */
function serial(mixed $arg0): \Brick\Math\BigInteger {
    if (\func_num_args() !== 1) throw new \ArgumentCountError('serial requires exactly 1 arguments');
    return Internal\Native::call('serial', [$arg0]);
}

/**
 * @param Bundle $arg0
 * Consumes resource leases in $arg0 at the Lean call boundary.
 * @return Bundle
 */
function transfer_record(mixed $arg0): Bundle {
    if (\func_num_args() !== 1) throw new \ArgumentCountError('transfer_record requires exactly 1 arguments');
    return Internal\Native::call('transfer_record', [$arg0]);
}

require_once __DIR__ . '/Internal/OwnedBootstrap.php';
