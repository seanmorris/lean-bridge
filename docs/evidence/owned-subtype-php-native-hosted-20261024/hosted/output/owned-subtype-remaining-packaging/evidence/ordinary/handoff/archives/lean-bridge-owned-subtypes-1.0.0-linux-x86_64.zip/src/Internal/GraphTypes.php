<?php
declare(strict_types=1);
namespace LeanOwnedSubtypes\Internal;

final class GraphTypes
{
    public const NODES = [['kind' => 'list', 'element' => 5, 'fields' => [], 'classes' => []], ['kind' => 'array', 'element' => 5, 'fields' => [], 'classes' => []], ['kind' => 'option', 'element' => null, 'fields' => [[0, 5]], 'classes' => ['LeanOwnedSubtypes\\Some']], ['kind' => 'record', 'element' => null, 'fields' => [['primary', 5], ['spare', 2], ['peers', 1], ['history', 0], ['payload', 4]], 'classes' => ['LeanOwnedSubtypes\\Bundle']], ['kind' => 'record', 'element' => null, 'fields' => [['count', 7], ['bytes', 6]], 'classes' => ['LeanOwnedSubtypes\\Payload']], ['kind' => 'resource', 'element' => null, 'fields' => [], 'classes' => ['LeanOwnedSubtypes\\Ticket']], ['kind' => 'primitive', 'name' => 'bytes'], ['kind' => 'primitive', 'name' => 'int', 'host' => 'bigint', 'min' => null, 'max' => null], ['kind' => 'primitive', 'name' => 'nat', 'host' => 'bigint', 'min' => '0', 'max' => null], ['kind' => 'primitive', 'name' => 'string']];
    public const CLASSES = ['LeanOwnedSubtypes\\Bundle' => ['fields' => [['primary', 5], ['spare', 2], ['peers', 1], ['history', 0], ['payload', 4]]], 'LeanOwnedSubtypes\\Payload' => ['fields' => [['count', 7], ['bytes', 6]]], 'LeanOwnedSubtypes\\Some' => ['fields' => [['value', null]]], 'LeanOwnedSubtypes\\Ok' => ['fields' => [['value', null]]], 'LeanOwnedSubtypes\\Err' => ['fields' => [['value', null]]]];
    public const IDENTITIES = ['LeanOwnedSubtypes\\Ticket' => 5];
}
