<?php
declare(strict_types=1);
namespace LeanOwnedSubtypes\Internal;

require_once __DIR__ . '/Runtime.php';
require_once __DIR__ . '/OwnedAssets.php';

final class OwnedAssets
{
    private const DEFINITIONS = OwnedCallTypes::DEFINITIONS;
    public static function load(): \FFI {
        return \LeanBridge\OwnedNativeV1\Runtime::load(__DIR__ . '/../../native/linux-x64', json_decode(<<<'EVIDENCE'
{
  "componentId": "owned-subtypes@1.0.0",
  "componentLibrary": "libcomponent_df500c005a7a829ba06c.so",
  "componentReceiptSha256": "b0bcde444e7204cd01d3b4a4f86e1c13a3f58a881d82d5b1e4441ceec5e74dc8",
  "identity": "f49bb2bacc091cabb8abfdf0ea3b7670723659bf310993d69f0cae0c6a7c1664",
  "libraries": {
    "libcomponent_df500c005a7a829ba06c.so": "4176de3f0437e1271e7f2274036d46b1bcf398412ebc5d01d5281e1281970734",
    "libgmp-lean-bridge.so.10": "9687f8d50f5c413728d4fcc8d96328912239ce8b1269cbb9a1ff793e430a7b27",
    "liblean_bridge_native.so": "459fcd2098d4b646ab6ae0f4cdccd1f222908cb162562bfc3940a533cd4e4e21",
    "libleanshared.so": "d7768b88d8162736da4305777cd6f147676038fd885bd8a265c958b0ecea00b4",
    "libowned_subtypes_php.so": "ba9dfa5658207c0b6d2196d56fd8037545dc0a8e93a53b64ebb597f06958160d"
  },
  "library": "libowned_subtypes_php.so",
  "ownedValues": {
    "callbackFailure": "raise-after-native-return",
    "callbackLifetime": "call",
    "exactIntegers": "brick-math",
    "explicitRetention": "retain",
    "gmp": "libgmp-lean-bridge.so.10",
    "headerSha256": "bf929aa2e746fe0fb16ba117b594f3667e287efc79733d686bbfb2b005aec1ba",
    "inputTransfers": {
      "aliases": "shared-lease",
      "arguments": "ordinary-values",
      "borrowedInputs": "reject",
      "consumption": "before-lean-call",
      "failure": "consumed-after-handoff",
      "independentRetains": "preserved",
      "schemaVersion": 1,
      "validation": "before-consumption"
    },
    "integerDecimalDigits": 16384,
    "language": "php-8.2-nts-cli",
    "limits": {
      "bytes": 16777216,
      "depth": 128,
      "retained": 4096,
      "visits": 262144
    },
    "loaderSha256": "e6974d3de49f085510405fca4a888732e238debd4b9e6a46ebde4ec39b61ca35",
    "loadingPolicy": "linux-x64-deepbind-v1",
    "nativeSha256": "ba200797d3b7ab4fcd2ab561862caefb2a8e83672710627a2fb6f3b321d5efd2",
    "ownership": "checked-result-leases",
    "schemaVersion": 2,
    "sharedLoaderSha256": "057d6f64a05c18766d6b10663de7aeb70714818ce06f96c74d3f3894644dfc14",
    "sourcesSha256": {
      "src/Api.php": "a1d7c00a738a473f93bafb294854dcda8e9340c620333442bfba9a7a3bc4a810",
      "src/Internal/GraphTypes.php": "4be3886ebf866c5807ac9cfc7f30dd355aa49feeee672506c5b31fa6c4ea65d8",
      "src/Internal/OwnedCallTypes.php": "3fba5eddbbc7a7575be5a5722c6b452384ede47689d8f6662f24bdaf60dbedd8",
      "src/Internal/OwnedCalls.php": "50dcb4d9459b11762f6dba1619530352aa74b78d32944cb44533335380c00b45",
      "src/Internal/OwnedConversions.php": "c218c30933206887ace28cdb0a2f4cdc1464db62c3eec66329d877e5ede6ac53",
      "src/Internal/OwnedNativeTypes.php": "775356ea46bed644b1fe144189650d5ccace555df0c46047c06aceb9a2b1dac1",
      "src/Internal/OwnedRuntime.php": "b9fc50d4f186e0798c5b5958e9c5080c4f852920de5590ce0f2256b1ee58cf49",
      "src/Internal/Values.php": "c34e5dda6058b16c4300482fcf7ab2ab69670821301e63eace9eb23ccb1d00c0"
    }
  },
  "runtimeIdentity": "4b5a7fdf0cb11d4bb429181cfd50b330c5622ed8f5f5382a293955a439b595b5"
}
EVIDENCE, true, 512, JSON_THROW_ON_ERROR), self::DEFINITIONS);
    }
}

Native::configure(static fn(): OwnedRuntime => new OwnedRuntime(OwnedAssets::load(),
    \LeanBridge\CopiedNativeV1\Runtime::ensureProcess(...)));
