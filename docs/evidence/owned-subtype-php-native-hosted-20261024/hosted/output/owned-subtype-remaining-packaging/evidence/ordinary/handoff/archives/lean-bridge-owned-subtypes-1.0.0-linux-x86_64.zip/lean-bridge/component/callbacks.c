#include "component.h"
#include "lean_bridge_native_runtime.h"
static _Thread_local int lean_bridge_owned_callback_failure_dd714bf29d9e4fbd0f6b_state;
int lean_bridge_owned_callback_failure_dd714bf29d9e4fbd0f6b(void) { int result = lean_bridge_owned_callback_failure_dd714bf29d9e4fbd0f6b_state; lean_bridge_owned_callback_failure_dd714bf29d9e4fbd0f6b_state = 0; return result; }
