#include "component.h"
#include "lean_bridge_native_runtime.h"
static _Thread_local int lean_bridge_owned_callback_failure_a94af6a527ddca9450e2_state;
int lean_bridge_owned_callback_failure_a94af6a527ddca9450e2(void) { int result = lean_bridge_owned_callback_failure_a94af6a527ddca9450e2_state; lean_bridge_owned_callback_failure_a94af6a527ddca9450e2_state = 0; return result; }
