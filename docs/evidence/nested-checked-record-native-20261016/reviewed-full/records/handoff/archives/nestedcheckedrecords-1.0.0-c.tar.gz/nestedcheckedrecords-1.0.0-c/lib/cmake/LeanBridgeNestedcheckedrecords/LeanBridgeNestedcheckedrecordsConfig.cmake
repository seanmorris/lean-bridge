get_filename_component(_LB_PREFIX "${CMAKE_CURRENT_LIST_DIR}/../../.." ABSOLUTE)
if(NOT TARGET LeanBridge::nestedcheckedrecords)
  add_library(LeanBridge::nestedcheckedrecords SHARED IMPORTED)
  set_target_properties(LeanBridge::nestedcheckedrecords PROPERTIES
    IMPORTED_LOCATION "${_LB_PREFIX}/lib/libnestedcheckedrecords_gmp.so"
    INTERFACE_INCLUDE_DIRECTORIES "${_LB_PREFIX}/include"
    INTERFACE_COMPILE_FEATURES "c_std_11"
    INTERFACE_LINK_LIBRARIES "${_LB_PREFIX}/lib/libgmp.so.10"
  )
endif()
unset(_LB_PREFIX)
