#pragma once
#include "nestedcheckedrecords.h"
#include <stdexcept>
#include <memory>
#include <string>
#include <variant>
#include <optional>
#include <vector>
#include <utility>

#ifndef BOOST_MP_STANDALONE
#define BOOST_MP_STANDALONE
#endif
#include <boost/multiprecision/cpp_int.hpp>

namespace lean_bridge::nestedcheckedrecords {
template<class T> struct Ok { T value; friend bool operator==(const Ok&, const Ok&) = default; };
template<class E> struct Err { E value; friend bool operator==(const Err&, const Err&) = default; };
template<class T, class E> using Result = std::variant<Ok<T>, Err<E>>;
using Nat = boost::multiprecision::cpp_int;
using Int = boost::multiprecision::cpp_int;
struct Packet {
  Nat digit{};
  Nat word{};
  friend bool operator==(const Packet&, const Packet&) = default;
};
struct ChoiceEmpty {

  friend bool operator==(const ChoiceEmpty&, const ChoiceEmpty&) = default;
};
struct ChoicePacket {
  Packet value{};
  friend bool operator==(const ChoicePacket&, const ChoicePacket&) = default;
};
using Choice = std::variant<ChoiceEmpty, ChoicePacket>;
struct Holder {
  Packet packet{};
  Nat tag{};
  friend bool operator==(const Holder&, const Holder&) = default;
};
class Error final : public std::runtime_error {
public:
  nestedcheckedrecords_status status;
  nestedcheckedrecords_error_code code;
  Error(nestedcheckedrecords_status value, const nestedcheckedrecords_error& error)
    : std::runtime_error(error.message ? std::string(error.message, error.message_length) : "Lean call failed"), status(value), code(error.code) {}
};
namespace detail {
[[noreturn]] inline void invalid(const char* message) {
  const nestedcheckedrecords_error error{NESTEDCHECKEDRECORDS_ERROR_INVALID_ARGUMENT, message, std::char_traits<char>::length(message)};
  throw Error(NESTEDCHECKEDRECORDS_STATUS_INVALID_ARGUMENT, error);
}
inline void charge(size_t& budget, size_t count, size_t width) {
  if (count > budget / width) {
    const nestedcheckedrecords_error error{NESTEDCHECKEDRECORDS_ERROR_INVALID_ARGUMENT, "16 MiB call limit exceeded", 26};
    throw Error(NESTEDCHECKEDRECORDS_STATUS_INVALID_ARGUMENT, error);
  }
  budget -= count * width;
}
inline void check0(const Nat& source, size_t& budget) {
  (void)source; (void)budget;
  if (source < 0) invalid("Nat must be nonnegative");
  charge(budget, source == 0 ? 0 : (boost::multiprecision::msb(source < 0 ? -source : source) / 32 + 1), sizeof(uint32_t));
}
struct View0 {
  std::vector<uint32_t> limbs;
  nestedcheckedrecords_nat value{};
  explicit View0(const Nat& source) {
    (void)source;
    if (source != 0) boost::multiprecision::export_bits(source, std::back_inserter(limbs), 32, false);
    value = nestedcheckedrecords_nat{limbs.data(), limbs.size(), nullptr, nullptr};
  }
};
inline Nat from0(const nestedcheckedrecords_nat& source) {
  (void)source;
  Nat result = 0;
  if (source.length) boost::multiprecision::import_bits(result, source.data, source.data + source.length, 32, false);
  return result;
}

inline void check1(const Packet& source, size_t& budget) {
  (void)source; (void)budget;
  charge(budget, 1, sizeof(nestedcheckedrecords_packet));
  check0(source.digit, budget);
  check0(source.word, budget);
}
struct View1 {
  View0 field0;
  View0 field1;
  nestedcheckedrecords_packet value{};
  explicit View1(const Packet& source) : field0(source.digit), field1(source.word) {
    (void)source;
    value = nestedcheckedrecords_packet{field0.value, field1.value};
  }
};
inline Packet from1(const nestedcheckedrecords_packet& source) {
  (void)source;
  return Packet{from0(source.digit), from0(source.word)};
}

inline void check2(const std::vector<Packet>& source, size_t& budget) {
  (void)source; (void)budget;
  charge(budget, source.size(), sizeof(nestedcheckedrecords_packet) > sizeof(void*) ? sizeof(nestedcheckedrecords_packet) : sizeof(void*));
  for (const auto& item : source) check1(item, budget);
}
struct View2 {
  std::vector<View1> items;
  std::unique_ptr<nestedcheckedrecords_packet[]> values;
  nestedcheckedrecords_array_lean_nested_checked_records_packet_span value{};
  explicit View2(const std::vector<Packet>& source) {
    (void)source;
    items.reserve(source.size()); values = std::make_unique<nestedcheckedrecords_packet[]>(source.size());
    for (const auto& item : source) items.emplace_back(item);
    for (size_t i = 0; i < source.size(); ++i) values[i] = items[i].value;
    value = nestedcheckedrecords_array_lean_nested_checked_records_packet_span{values.get(), source.size(), nullptr, nullptr};
  }
};
inline std::vector<Packet> from2(const nestedcheckedrecords_array_lean_nested_checked_records_packet_span& source) {
  (void)source;
  std::vector<Packet> result; result.reserve(source.length);
  for (size_t i = 0; i < source.length; ++i) result.push_back(from1(source.data[i]));
  return result;
}

inline void check3(const Choice& source, size_t& budget) {
  (void)source; (void)budget;
  charge(budget, 1, sizeof(nestedcheckedrecords_choice));
  if (source.valueless_by_exception()) invalid("Variant has no active branch");
  switch (source.index()) {
  case 0:
    break;
  case 1:
    check1(std::get<ChoicePacket>(source).value, budget);
    break;
  default: invalid("Variant has no active branch");
  }
}
struct View3 {
  std::unique_ptr<View1> field1_0;
  nestedcheckedrecords_choice value{};
  explicit View3(const Choice& source) {
    (void)source;
    value.kind = static_cast<uint32_t>(source.index());
    switch (source.index()) {
    case 0:
      break;
    case 1:
      field1_0 = std::make_unique<View1>(std::get<ChoicePacket>(source).value); value.cases.packet.value = field1_0->value;
      break;
    default: invalid("Variant has no active branch");
    }
  }
};
inline Choice from3(const nestedcheckedrecords_choice& source) {
  (void)source;
  switch (source.kind) {
  case 0: return ChoiceEmpty{};
  case 1: return ChoicePacket{from1(source.cases.packet.value)};
  default: invalid("Native variant has an invalid tag");
  }
}

inline void check4(const Result<Packet, Packet>& source, size_t& budget) {
  (void)source; (void)budget;
  charge(budget, 1, sizeof(nestedcheckedrecords_result_lean_nested_checked_records_packet_lean_nested_checked_records_packet_value));
  if (source.valueless_by_exception()) invalid("Result has no active branch");
  if (source.index() == 0) check1(std::get<0>(source).value, budget);
  if (source.index() == 1) check1(std::get<1>(source).value, budget);
}
struct View4 {
  std::unique_ptr<View1> field0;
  std::unique_ptr<View1> field1;
  nestedcheckedrecords_result_lean_nested_checked_records_packet_lean_nested_checked_records_packet_value value{};
  explicit View4(const Result<Packet, Packet>& source) {
    (void)source;
    if (source.index() == 0) { field0 = std::make_unique<View1>(std::get<0>(source).value); value.ok = field0->value; }
    if (source.index() == 1) { field1 = std::make_unique<View1>(std::get<1>(source).value); value.error = field1->value; }
    value.is_ok = source.index() == 0;
  }
};
inline Result<Packet, Packet> from4(const nestedcheckedrecords_result_lean_nested_checked_records_packet_lean_nested_checked_records_packet_value& source) {
  (void)source;
  if (source.is_ok) return Result<Packet, Packet>{Ok<Packet>{from1(source.ok)}};
  return Result<Packet, Packet>{Err<Packet>{from1(source.error)}};
}

inline void check5(const Holder& source, size_t& budget) {
  (void)source; (void)budget;
  charge(budget, 1, sizeof(nestedcheckedrecords_holder));
  check1(source.packet, budget);
  check0(source.tag, budget);
}
struct View5 {
  View1 field0;
  View0 field1;
  nestedcheckedrecords_holder value{};
  explicit View5(const Holder& source) : field0(source.packet), field1(source.tag) {
    (void)source;
    value = nestedcheckedrecords_holder{field0.value, field1.value};
  }
};
inline Holder from5(const nestedcheckedrecords_holder& source) {
  (void)source;
  return Holder{from1(source.packet), from0(source.tag)};
}

inline void check6(const std::vector<Packet>& source, size_t& budget) {
  (void)source; (void)budget;
  charge(budget, source.size(), sizeof(nestedcheckedrecords_packet) > sizeof(void*) ? sizeof(nestedcheckedrecords_packet) : sizeof(void*));
  for (const auto& item : source) check1(item, budget);
}
struct View6 {
  std::vector<View1> items;
  std::unique_ptr<nestedcheckedrecords_packet[]> values;
  nestedcheckedrecords_list_lean_nested_checked_records_packet_span value{};
  explicit View6(const std::vector<Packet>& source) {
    (void)source;
    items.reserve(source.size()); values = std::make_unique<nestedcheckedrecords_packet[]>(source.size());
    for (const auto& item : source) items.emplace_back(item);
    for (size_t i = 0; i < source.size(); ++i) values[i] = items[i].value;
    value = nestedcheckedrecords_list_lean_nested_checked_records_packet_span{values.get(), source.size(), nullptr, nullptr};
  }
};
inline std::vector<Packet> from6(const nestedcheckedrecords_list_lean_nested_checked_records_packet_span& source) {
  (void)source;
  std::vector<Packet> result; result.reserve(source.length);
  for (size_t i = 0; i < source.length; ++i) result.push_back(from1(source.data[i]));
  return result;
}

inline void check7(const std::optional<Packet>& source, size_t& budget) {
  (void)source; (void)budget;
  charge(budget, 1, sizeof(nestedcheckedrecords_option_lean_nested_checked_records_packet_value));
  if (source.has_value()) check1(*source, budget);
}
struct View7 {
  std::unique_ptr<View1> field0;
  nestedcheckedrecords_option_lean_nested_checked_records_packet_value value{};
  explicit View7(const std::optional<Packet>& source) {
    (void)source;
    if (source.has_value()) { field0 = std::make_unique<View1>(*source); value.value = field0->value; }
    value.has_value = source.has_value();
  }
};
inline std::optional<Packet> from7(const nestedcheckedrecords_option_lean_nested_checked_records_packet_value& source) {
  (void)source;
  if (!source.has_value) return std::nullopt;
  return std::optional<Packet>{std::in_place, from1(source.value)};
}

inline void check8(const std::pair<Packet, Packet>& source, size_t& budget) {
  (void)source; (void)budget;
  charge(budget, 1, sizeof(nestedcheckedrecords_tuple_lean_nested_checked_records_packet_lean_nested_checked_records_packet_value));
  check1(source.first, budget);
  check1(source.second, budget);
}
struct View8 {
  View1 field0;
  View1 field1;
  nestedcheckedrecords_tuple_lean_nested_checked_records_packet_lean_nested_checked_records_packet_value value{};
  explicit View8(const std::pair<Packet, Packet>& source) : field0(source.first), field1(source.second) {
    (void)source;
    value = nestedcheckedrecords_tuple_lean_nested_checked_records_packet_lean_nested_checked_records_packet_value{field0.value, field1.value};
  }
};
inline std::pair<Packet, Packet> from8(const nestedcheckedrecords_tuple_lean_nested_checked_records_packet_lean_nested_checked_records_packet_value& source) {
  (void)source;
  return std::pair<Packet, Packet>{from1(source.fst), from1(source.snd)};
}
inline void check(nestedcheckedrecords_status status, const nestedcheckedrecords_error& error) {
  if (status != NESTEDCHECKEDRECORDS_STATUS_OK) throw Error(status, error);
}
template<class T, void (*Clear)(T*)> struct Owned {
  T* value;
  ~Owned() { Clear(value); }
  Owned(const Owned&) = delete;
  Owned& operator=(const Owned&) = delete;
  explicit Owned(T* input) : value(input) {}
};
}


inline std::vector<Packet> echo_array(std::vector<Packet> const& arg0) {
  nestedcheckedrecords_error _lb_error{}; size_t _lb_budget = 16u * 1024u * 1024u; (void)_lb_budget;
  detail::check2(arg0, _lb_budget);
  detail::View2 _lb_arg0{arg0};
  nestedcheckedrecords_array_lean_nested_checked_records_packet_span _lb_result{};
  detail::Owned<nestedcheckedrecords_array_lean_nested_checked_records_packet_span, nestedcheckedrecords_array_lean_nested_checked_records_packet_span_clear> _lb_owner{&_lb_result};
  const auto _lb_status = nestedcheckedrecords_echo_array(&_lb_arg0.value, &_lb_result, &_lb_error);
  detail::check(_lb_status, _lb_error);
  return detail::from2(_lb_result);
}

inline Nat first(Packet const& arg0) {
  nestedcheckedrecords_error _lb_error{}; size_t _lb_budget = 16u * 1024u * 1024u; (void)_lb_budget;
  detail::check1(arg0, _lb_budget);
  detail::View1 _lb_arg0{arg0};
  nestedcheckedrecords_nat _lb_result{};
  detail::Owned<nestedcheckedrecords_nat, nestedcheckedrecords_nat_clear> _lb_owner{&_lb_result};
  const auto _lb_status = nestedcheckedrecords_first(&_lb_arg0.value, &_lb_result, &_lb_error);
  detail::check(_lb_status, _lb_error);
  return detail::from0(_lb_result);
}

inline Nat in_array(std::vector<Packet> const& arg0) {
  nestedcheckedrecords_error _lb_error{}; size_t _lb_budget = 16u * 1024u * 1024u; (void)_lb_budget;
  detail::check2(arg0, _lb_budget);
  detail::View2 _lb_arg0{arg0};
  nestedcheckedrecords_nat _lb_result{};
  detail::Owned<nestedcheckedrecords_nat, nestedcheckedrecords_nat_clear> _lb_owner{&_lb_result};
  const auto _lb_status = nestedcheckedrecords_in_array(&_lb_arg0.value, &_lb_result, &_lb_error);
  detail::check(_lb_status, _lb_error);
  return detail::from0(_lb_result);
}

inline Nat in_choice(Choice const& arg0) {
  nestedcheckedrecords_error _lb_error{}; size_t _lb_budget = 16u * 1024u * 1024u; (void)_lb_budget;
  detail::check3(arg0, _lb_budget);
  detail::View3 _lb_arg0{arg0};
  nestedcheckedrecords_nat _lb_result{};
  detail::Owned<nestedcheckedrecords_nat, nestedcheckedrecords_nat_clear> _lb_owner{&_lb_result};
  const auto _lb_status = nestedcheckedrecords_in_choice(&_lb_arg0.value, &_lb_result, &_lb_error);
  detail::check(_lb_status, _lb_error);
  return detail::from0(_lb_result);
}

inline Nat in_except(Result<Packet, Packet> const& arg0) {
  nestedcheckedrecords_error _lb_error{}; size_t _lb_budget = 16u * 1024u * 1024u; (void)_lb_budget;
  detail::check4(arg0, _lb_budget);
  detail::View4 _lb_arg0{arg0};
  nestedcheckedrecords_nat _lb_result{};
  detail::Owned<nestedcheckedrecords_nat, nestedcheckedrecords_nat_clear> _lb_owner{&_lb_result};
  const auto _lb_status = nestedcheckedrecords_in_except(&_lb_arg0.value, &_lb_result, &_lb_error);
  detail::check(_lb_status, _lb_error);
  return detail::from0(_lb_result);
}

inline Nat in_holder(Holder const& arg0) {
  nestedcheckedrecords_error _lb_error{}; size_t _lb_budget = 16u * 1024u * 1024u; (void)_lb_budget;
  detail::check5(arg0, _lb_budget);
  detail::View5 _lb_arg0{arg0};
  nestedcheckedrecords_nat _lb_result{};
  detail::Owned<nestedcheckedrecords_nat, nestedcheckedrecords_nat_clear> _lb_owner{&_lb_result};
  const auto _lb_status = nestedcheckedrecords_in_holder(&_lb_arg0.value, &_lb_result, &_lb_error);
  detail::check(_lb_status, _lb_error);
  return detail::from0(_lb_result);
}

inline Nat in_list(std::vector<Packet> const& arg0) {
  nestedcheckedrecords_error _lb_error{}; size_t _lb_budget = 16u * 1024u * 1024u; (void)_lb_budget;
  detail::check6(arg0, _lb_budget);
  detail::View6 _lb_arg0{arg0};
  nestedcheckedrecords_nat _lb_result{};
  detail::Owned<nestedcheckedrecords_nat, nestedcheckedrecords_nat_clear> _lb_owner{&_lb_result};
  const auto _lb_status = nestedcheckedrecords_in_list(&_lb_arg0.value, &_lb_result, &_lb_error);
  detail::check(_lb_status, _lb_error);
  return detail::from0(_lb_result);
}

inline Nat in_option(std::optional<Packet> const& arg0) {
  nestedcheckedrecords_error _lb_error{}; size_t _lb_budget = 16u * 1024u * 1024u; (void)_lb_budget;
  detail::check7(arg0, _lb_budget);
  detail::View7 _lb_arg0{arg0};
  nestedcheckedrecords_nat _lb_result{};
  detail::Owned<nestedcheckedrecords_nat, nestedcheckedrecords_nat_clear> _lb_owner{&_lb_result};
  const auto _lb_status = nestedcheckedrecords_in_option(&_lb_arg0.value, &_lb_result, &_lb_error);
  detail::check(_lb_status, _lb_error);
  return detail::from0(_lb_result);
}

inline Nat in_product(std::pair<Packet, Packet> const& arg0) {
  nestedcheckedrecords_error _lb_error{}; size_t _lb_budget = 16u * 1024u * 1024u; (void)_lb_budget;
  detail::check8(arg0, _lb_budget);
  detail::View8 _lb_arg0{arg0};
  nestedcheckedrecords_nat _lb_result{};
  detail::Owned<nestedcheckedrecords_nat, nestedcheckedrecords_nat_clear> _lb_owner{&_lb_result};
  const auto _lb_status = nestedcheckedrecords_in_product(&_lb_arg0.value, &_lb_result, &_lb_error);
  detail::check(_lb_status, _lb_error);
  return detail::from0(_lb_result);
}

inline Nat pair(Packet const& arg0, Packet const& arg1) {
  nestedcheckedrecords_error _lb_error{}; size_t _lb_budget = 16u * 1024u * 1024u; (void)_lb_budget;
  detail::check1(arg0, _lb_budget);
  detail::check1(arg1, _lb_budget);
  detail::View1 _lb_arg0{arg0};
  detail::View1 _lb_arg1{arg1};
  nestedcheckedrecords_nat _lb_result{};
  detail::Owned<nestedcheckedrecords_nat, nestedcheckedrecords_nat_clear> _lb_owner{&_lb_result};
  const auto _lb_status = nestedcheckedrecords_pair(&_lb_arg0.value, &_lb_arg1.value, &_lb_result, &_lb_error);
  detail::check(_lb_status, _lb_error);
  return detail::from0(_lb_result);
}

inline std::vector<Packet> produce_array(Nat const& arg0) {
  nestedcheckedrecords_error _lb_error{}; size_t _lb_budget = 16u * 1024u * 1024u; (void)_lb_budget;
  detail::check0(arg0, _lb_budget);
  detail::View0 _lb_arg0{arg0};
  nestedcheckedrecords_array_lean_nested_checked_records_packet_span _lb_result{};
  detail::Owned<nestedcheckedrecords_array_lean_nested_checked_records_packet_span, nestedcheckedrecords_array_lean_nested_checked_records_packet_span_clear> _lb_owner{&_lb_result};
  const auto _lb_status = nestedcheckedrecords_produce_array(&_lb_arg0.value, &_lb_result, &_lb_error);
  detail::check(_lb_status, _lb_error);
  return detail::from2(_lb_result);
}

inline std::optional<Packet> produce_option(Nat const& arg0) {
  nestedcheckedrecords_error _lb_error{}; size_t _lb_budget = 16u * 1024u * 1024u; (void)_lb_budget;
  detail::check0(arg0, _lb_budget);
  detail::View0 _lb_arg0{arg0};
  nestedcheckedrecords_option_lean_nested_checked_records_packet_value _lb_result{};
  detail::Owned<nestedcheckedrecords_option_lean_nested_checked_records_packet_value, nestedcheckedrecords_option_lean_nested_checked_records_packet_value_clear> _lb_owner{&_lb_result};
  const auto _lb_status = nestedcheckedrecords_produce_option(&_lb_arg0.value, &_lb_result, &_lb_error);
  detail::check(_lb_status, _lb_error);
  return detail::from7(_lb_result);
}

inline Nat second(Packet const& arg0) {
  nestedcheckedrecords_error _lb_error{}; size_t _lb_budget = 16u * 1024u * 1024u; (void)_lb_budget;
  detail::check1(arg0, _lb_budget);
  detail::View1 _lb_arg0{arg0};
  nestedcheckedrecords_nat _lb_result{};
  detail::Owned<nestedcheckedrecords_nat, nestedcheckedrecords_nat_clear> _lb_owner{&_lb_result};
  const auto _lb_status = nestedcheckedrecords_second(&_lb_arg0.value, &_lb_result, &_lb_error);
  detail::check(_lb_status, _lb_error);
  return detail::from0(_lb_result);
}
}
