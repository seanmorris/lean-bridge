import { createPhpWasmCopiedDescriptor } from './host.mjs';
const runtime = Object.freeze({"identity":"fbc32dc75641fc5d381ab6bddd05671cb59cad725d631e433cda14469ae1f25a","loaderIdentity":"0cde19a3de4c31ab80d8b97e8dcdcde8cc5dcc5cc79dcacb3fbdbfd1cc1f9744","library":"liblean_bridge_php_wasm_copied_488de83b725bba40a9b4.so"});
export const createDescriptor = (component, assets) => createPhpWasmCopiedDescriptor({ ...runtime, url: new URL("./compiled/lib/liblean_bridge_php_wasm_copied_488de83b725bba40a9b4.so", import.meta.url) }, component, assets);
