<?php
declare(strict_types=1);
namespace LeanBridge\CopiedPhpWasmV1 {
if (!class_exists(Loader::class, false)) {
    final class Loader {
        private static ?string $failure = null;
        private static bool $loading = false;
        private static int $callbacks = 0;
        public static function enterCallback(): void { ++self::$callbacks; }
        public static function leaveCallback(): void { --self::$callbacks; }
        public static function load(string $library, string $function): void {
            if (self::$failure !== null) throw new \RuntimeException(self::$failure);
            if (self::$loading) throw new \RuntimeException('Reentrant PHP-Wasm extension loading is not supported');
            // dl may suspend the host to fetch or instantiate a side module.
            // The synchronous Lean stack cannot participate in that unwind.
            if (self::$callbacks !== 0) throw new \RuntimeException('Cannot load a PHP-Wasm extension inside a synchronous Lean callback. Use its startup descriptor or call that package before entering the callback.');
            $registration = '/__lean_bridge/php_wasm_lazy/' . $library . '.txt';
            if (!is_file($registration) || file_get_contents($registration) !== $library) {
                throw new \RuntimeException('Register this package lazy descriptor in dynamicLibs before PHP starts');
            }
            if (!function_exists('dl') || !ini_get('enable_dl')) {
                throw new \RuntimeException('PHP-Wasm lazy loading requires enable_dl=1');
            }
            self::$loading = true;
            try {
                set_error_handler(static function (int $severity, string $message): never {
                    throw new \RuntimeException($message);
                });
                try {
                    if (!dl($library) || !function_exists($function)) {
                        throw new \RuntimeException('The generated Zend transport did not load');
                    }
                } finally { restore_error_handler(); }
            } catch (\Throwable $error) {
                // Emscripten may retain a partially linked DSO after failure.
                // Do not attempt another lazy load in that PHP instance.
                self::$failure = 'PHP-Wasm extension loading failed; create a new PHP instance. ' . $error->getMessage();
                throw new \RuntimeException(self::$failure, 0, $error);
            } finally { self::$loading = false; }
        }
    }
}
}

namespace LeanNominalprimitivesubtypes\Internal {

final class Budget
{
    private int $remaining = 16 * 1024 * 1024;
    public function charge(int $count, int $width = 1): void {
        if ($count < 0 || $width < 1 || $count > intdiv($this->remaining, $width)) {
            throw new \ValueError('16 MiB PHP conversion limit exceeded');
        }
        $this->remaining -= $count * $width;
    }
}
final class Checks
{
    public static function check0(mixed $value, Budget $budget): mixed {
        $budget->charge(1, 16);
        if ($value !== null) throw new \TypeError('Unit requires null');
        return $value;
    }
    public static function check1(mixed $value, Budget $budget): mixed {
        $budget->charge(1, 16);
        if (!is_bool($value)) throw new \TypeError('Bool requires bool');
        return $value;
    }
    public static function check2(mixed $value, Budget $budget): mixed {
        $budget->charge(1, 16);
        if (!is_int($value)) throw new \TypeError('Expected an int without numeric coercion');
        if ($value < 0 || $value > 255) throw new \ValueError('Integer is outside the declared Lean range');
        return $value;
    }
    public static function check3(mixed $value, Budget $budget): mixed {
        $budget->charge(1, 16);
        if (!is_int($value)) throw new \TypeError('Expected an int without numeric coercion');
        if ($value < 0 || $value > 65535) throw new \ValueError('Integer is outside the declared Lean range');
        return $value;
    }
    public static function check4(mixed $value, Budget $budget): mixed {
        $budget->charge(1, 16);
        if (!$value instanceof \Brick\Math\BigInteger) throw new \TypeError('Expected Brick Math BigInteger');
        $decimal = (string) $value;
        if (strlen($decimal) > 16385 || strlen(ltrim($decimal, '-')) > 16384 || preg_match('/^(?:0|-?[1-9][0-9]*)$/D', $decimal) !== 1) throw new \ValueError('BigInteger requires canonical decimal text of at most 16384 digits');
        $budget->charge(strlen($decimal));
        if ($decimal[0] === '-') throw new \ValueError('Expected an unsigned integer');
        if (strlen($decimal) > 10 || (strlen($decimal) === 10 && strcmp($decimal, '4294967295') > 0)) throw new \ValueError('Integer is outside the UInt32 range');
        return $value;
    }
    public static function check5(mixed $value, Budget $budget): mixed {
        $budget->charge(1, 16);
        if (!$value instanceof \Brick\Math\BigInteger) throw new \TypeError('Expected Brick Math BigInteger');
        $decimal = (string) $value;
        if (strlen($decimal) > 16385 || strlen(ltrim($decimal, '-')) > 16384 || preg_match('/^(?:0|-?[1-9][0-9]*)$/D', $decimal) !== 1) throw new \ValueError('BigInteger requires canonical decimal text of at most 16384 digits');
        $budget->charge(strlen($decimal));
        if ($decimal[0] === '-') throw new \ValueError('Expected an unsigned integer');
        if (strlen($decimal) > 20 || (strlen($decimal) === 20 && strcmp($decimal, '18446744073709551615') > 0)) throw new \ValueError('Integer is outside the UInt64 range');
        return $value;
    }
    public static function check6(mixed $value, Budget $budget): mixed {
        $budget->charge(1, 16);
        if (!is_int($value)) throw new \TypeError('Expected an int without numeric coercion');
        if ($value < -128 || $value > 127) throw new \ValueError('Integer is outside the declared Lean range');
        return $value;
    }
    public static function check7(mixed $value, Budget $budget): mixed {
        $budget->charge(1, 16);
        if (!is_int($value)) throw new \TypeError('Expected an int without numeric coercion');
        if ($value < -32768 || $value > 32767) throw new \ValueError('Integer is outside the declared Lean range');
        return $value;
    }
    public static function check8(mixed $value, Budget $budget): mixed {
        $budget->charge(1, 16);
        if (!is_int($value)) throw new \TypeError('Expected an int without numeric coercion');
        if ($value < -2147483648 || $value > 2147483647) throw new \ValueError('Integer is outside the declared Lean range');
        return $value;
    }
    public static function check9(mixed $value, Budget $budget): mixed {
        $budget->charge(1, 16);
        if (!$value instanceof \Brick\Math\BigInteger) throw new \TypeError('Expected Brick Math BigInteger');
        $decimal = (string) $value;
        if (strlen($decimal) > 16385 || strlen(ltrim($decimal, '-')) > 16384 || preg_match('/^(?:0|-?[1-9][0-9]*)$/D', $decimal) !== 1) throw new \ValueError('BigInteger requires canonical decimal text of at most 16384 digits');
        $budget->charge(strlen($decimal));
        $magnitude = ltrim($decimal, '-');
        $limit = $decimal[0] === '-' ? '9223372036854775808' : '9223372036854775807';
        if (strlen($magnitude) > 19 || (strlen($magnitude) === 19 && strcmp($magnitude, $limit) > 0)) throw new \ValueError('Integer is outside the Int64 range');
        return $value;
    }
    public static function check10(mixed $value, Budget $budget): mixed {
        $budget->charge(1, 16);
        if (!$value instanceof \Brick\Math\BigInteger) throw new \TypeError('Expected Brick Math BigInteger');
        $decimal = (string) $value;
        if (strlen($decimal) > 16385 || strlen(ltrim($decimal, '-')) > 16384 || preg_match('/^(?:0|-?[1-9][0-9]*)$/D', $decimal) !== 1) throw new \ValueError('BigInteger requires canonical decimal text of at most 16384 digits');
        $budget->charge(strlen($decimal));
        if ($decimal[0] === '-') throw new \ValueError('Expected an unsigned integer');
        return $value;
    }
    public static function check11(mixed $value, Budget $budget): mixed {
        $budget->charge(1, 16);
        if (!$value instanceof \Brick\Math\BigInteger) throw new \TypeError('Expected Brick Math BigInteger');
        $decimal = (string) $value;
        if (strlen($decimal) > 16385 || strlen(ltrim($decimal, '-')) > 16384 || preg_match('/^(?:0|-?[1-9][0-9]*)$/D', $decimal) !== 1) throw new \ValueError('BigInteger requires canonical decimal text of at most 16384 digits');
        $budget->charge(strlen($decimal));
        return $value;
    }
    public static function check12(mixed $value, Budget $budget): mixed {
        $budget->charge(1, 16);
        if (!is_float($value)) throw new \TypeError('Expected a float without numeric coercion');
        return $value;
    }
    public static function check13(mixed $value, Budget $budget): mixed {
        $budget->charge(1, 16);
        if (!is_float($value)) throw new \TypeError('Expected a float without numeric coercion');
        return $value;
    }
    public static function check14(mixed $value, Budget $budget): mixed {
        $budget->charge(1, 16);
        if (!is_string($value)) throw new \TypeError('Expected a UTF-8 string');
        $budget->charge(strlen($value));
        if (preg_match('//u', $value) !== 1) throw new \ValueError('String requires valid UTF-8');
        return $value;
    }
    public static function check15(mixed $value, Budget $budget): mixed {
        $budget->charge(1, 16);
        if (!$value instanceof \LeanNominalprimitivesubtypes\Bytes) throw new \TypeError('Expected Bytes');
        $budget->charge(strlen($value->toString()));
        return $value;
    }
    public static function check16(mixed $value, Budget $budget): mixed {
        $budget->charge(1, 16);
        if (!is_string($value)) throw new \TypeError('Char requires a string');
        if (strlen($value) < 1 || strlen($value) > 4 || preg_match('/\\A.\\z/us', $value) !== 1) throw new \ValueError('Char requires one Unicode scalar');
        return $value;
    }
    public static function check17(mixed $value, Budget $budget): mixed {
        $budget->charge(1, 16);
        if (!$value instanceof \Brick\Math\BigInteger) throw new \TypeError('Expected Brick Math BigInteger');
        $decimal = (string) $value;
        if (strlen($decimal) > 16385 || strlen(ltrim($decimal, '-')) > 16384 || preg_match('/^(?:0|-?[1-9][0-9]*)$/D', $decimal) !== 1) throw new \ValueError('BigInteger requires canonical decimal text of at most 16384 digits');
        $budget->charge(strlen($decimal));
        if ($decimal[0] === '-') throw new \ValueError('Expected an unsigned integer');
        if (strlen($decimal) > 10 || (strlen($decimal) === 10 && strcmp($decimal, '4294967295') > 0)) throw new \ValueError('Integer is outside the UInt32 range');
        return $value;
    }
    public static function check18(mixed $value, Budget $budget): mixed {
        $budget->charge(1, 16);
        if (!is_int($value)) throw new \TypeError('Expected an int without numeric coercion');
        if ($value < -2147483648 || $value > 2147483647) throw new \ValueError('Integer is outside the declared Lean range');
        return $value;
    }
    public static function check19(mixed $value, Budget $budget): mixed {
        $budget->charge(1, 16);
        if (!$value instanceof \LeanNominalprimitivesubtypes\Packet) throw new \TypeError('Expected Packet');
        if (array_keys(get_object_vars($value)) !== ['unitValue', 'boolValue', 'uint8Value', 'uint16Value', 'uint32Value', 'uint64Value', 'int8Value', 'int16Value', 'int32Value', 'int64Value', 'natValue', 'intValue', 'float32Value', 'float64Value', 'textValue', 'bytesValue', 'charValue', 'usizeValue', 'isizeValue', 'digit']) throw new \TypeError('Packet requires exactly its initialized fields');
        self::check0($value->unitValue, $budget);
        self::check1($value->boolValue, $budget);
        self::check2($value->uint8Value, $budget);
        self::check3($value->uint16Value, $budget);
        self::check4($value->uint32Value, $budget);
        self::check5($value->uint64Value, $budget);
        self::check6($value->int8Value, $budget);
        self::check7($value->int16Value, $budget);
        self::check8($value->int32Value, $budget);
        self::check9($value->int64Value, $budget);
        self::check10($value->natValue, $budget);
        self::check11($value->intValue, $budget);
        self::check12($value->float32Value, $budget);
        self::check13($value->float64Value, $budget);
        self::check14($value->textValue, $budget);
        self::check15($value->bytesValue, $budget);
        self::check16($value->charValue, $budget);
        self::check17($value->usizeValue, $budget);
        self::check18($value->isizeValue, $budget);
        self::check10($value->digit, $budget);
        return $value;
    }
    public static function check20(mixed $value, Budget $budget): mixed {
        $budget->charge(1, 16);
        if ($value === null) return null;
        if ($value instanceof \LeanNominalprimitivesubtypes\Some) {
            if (array_keys(get_object_vars($value)) !== ['value']) throw new \TypeError('Some requires one initialized value field');
            return new \LeanNominalprimitivesubtypes\Some(self::check19($value->value, $budget));
        }
        throw new \TypeError('Expected Some');
    }
    public static function check21(mixed $value, Budget $budget): mixed {
        $budget->charge(1, 16);
        if (!is_array($value) || !array_is_list($value)) throw new \TypeError('Expected a list with consecutive integer keys');
        $budget->charge(count($value), 32);
        $result = [];
        foreach ($value as $item) $result[] = self::check20($item, $budget);
        return $result;
    }
    public static function check22(mixed $value, Budget $budget): mixed {
        $budget->charge(1, 16);
        if (!is_array($value) || !array_is_list($value) || count($value) !== 2) throw new \TypeError('Prod requires a two-element list');
        $budget->charge(2, 32);
        return [self::check19($value[0], $budget), self::check19($value[1], $budget)];
    }
    public static function check23(mixed $value, Budget $budget): mixed {
        $budget->charge(1, 16);
        if ($value instanceof \LeanNominalprimitivesubtypes\Ok) {
            if (array_keys(get_object_vars($value)) !== ['value']) throw new \TypeError('Ok requires one initialized value field');
            return new \LeanNominalprimitivesubtypes\Ok(self::check19($value->value, $budget));
        }
        if ($value instanceof \LeanNominalprimitivesubtypes\Err) {
            if (array_keys(get_object_vars($value)) !== ['value']) throw new \TypeError('Err requires one initialized value field');
            return new \LeanNominalprimitivesubtypes\Err(self::check19($value->value, $budget));
        }
        throw new \TypeError('Expected Ok or Err');
    }
    public static function check24(mixed $value, Budget $budget): mixed {
        $budget->charge(1, 16);
        if ($value === null) return null;
        if ($value instanceof \LeanNominalprimitivesubtypes\Some) {
            if (array_keys(get_object_vars($value)) !== ['value']) throw new \TypeError('Some requires one initialized value field');
            return new \LeanNominalprimitivesubtypes\Some(self::check23($value->value, $budget));
        }
        throw new \TypeError('Expected Some');
    }
    public static function check25(mixed $value, Budget $budget): mixed {
        $budget->charge(1, 16);
        if (!is_array($value) || !array_is_list($value)) throw new \TypeError('Expected a list with consecutive integer keys');
        $budget->charge(count($value), 32);
        $result = [];
        foreach ($value as $item) $result[] = self::check24($item, $budget);
        return $result;
    }
    public static function check26(mixed $value, Budget $budget): mixed {
        $budget->charge(1, 16);
        if ($value instanceof \LeanNominalprimitivesubtypes\EventEmpty) {
            if (array_keys(get_object_vars($value)) !== []) throw new \TypeError('EventEmpty requires exactly its initialized payload fields');
            return $value;
        }
        if ($value instanceof \LeanNominalprimitivesubtypes\EventBox) {
            if (array_keys(get_object_vars($value)) !== ['value']) throw new \TypeError('EventBox requires exactly its initialized payload fields');
            self::check19($value->value, $budget);
            return $value;
        }
        if ($value instanceof \LeanNominalprimitivesubtypes\EventChoices) {
            if (array_keys(get_object_vars($value)) !== ['values']) throw new \TypeError('EventChoices requires exactly its initialized payload fields');
            self::check25($value->values, $budget);
            return $value;
        }
        throw new \TypeError('Expected an exact Event constructor');
    }
    public static function check27(mixed $value, Budget $budget): mixed {
        $budget->charge(1, 16);
        if (!$value instanceof \LeanNominalprimitivesubtypes\Pair) throw new \TypeError('Expected Pair');
        if (array_keys(get_object_vars($value)) !== ['left', 'right']) throw new \TypeError('Pair requires exactly its initialized fields');
        self::check21($value->left, $budget);
        self::check21($value->right, $budget);
        return $value;
    }
    public static function check28(mixed $value, Budget $budget): mixed {
        $budget->charge(1, 16);
        if (!$value instanceof \LeanNominalprimitivesubtypes\RawPacket) throw new \TypeError('Expected RawPacket');
        if (array_keys(get_object_vars($value)) !== ['unitValue', 'boolValue', 'uint8Value', 'uint16Value', 'uint32Value', 'uint64Value', 'int8Value', 'int16Value', 'int32Value', 'int64Value', 'natValue', 'intValue', 'float32Value', 'float64Value', 'textValue', 'bytesValue', 'charValue', 'usizeValue', 'isizeValue', 'digit']) throw new \TypeError('RawPacket requires exactly its initialized fields');
        self::check0($value->unitValue, $budget);
        self::check1($value->boolValue, $budget);
        self::check2($value->uint8Value, $budget);
        self::check3($value->uint16Value, $budget);
        self::check4($value->uint32Value, $budget);
        self::check5($value->uint64Value, $budget);
        self::check6($value->int8Value, $budget);
        self::check7($value->int16Value, $budget);
        self::check8($value->int32Value, $budget);
        self::check9($value->int64Value, $budget);
        self::check10($value->natValue, $budget);
        self::check11($value->intValue, $budget);
        self::check12($value->float32Value, $budget);
        self::check13($value->float64Value, $budget);
        self::check14($value->textValue, $budget);
        self::check15($value->bytesValue, $budget);
        self::check16($value->charValue, $budget);
        self::check17($value->usizeValue, $budget);
        self::check18($value->isizeValue, $budget);
        self::check10($value->digit, $budget);
        return $value;
    }
}
final class Values
{
    private static function step(Budget $budget, int $depth): void {
        if ($depth > 32) throw new \ValueError('Value comparison exceeds 32 nesting levels');
        $budget->charge(1, 32);
    }
    private static function fields(object $value, Budget $budget): array {
        $expected = match ($value::class) {
            \LeanNominalprimitivesubtypes\Some::class => ['value'],
            \LeanNominalprimitivesubtypes\Ok::class => ['value'],
            \LeanNominalprimitivesubtypes\Err::class => ['value'],
            \LeanNominalprimitivesubtypes\Packet::class => ['unitValue', 'boolValue', 'uint8Value', 'uint16Value', 'uint32Value', 'uint64Value', 'int8Value', 'int16Value', 'int32Value', 'int64Value', 'natValue', 'intValue', 'float32Value', 'float64Value', 'textValue', 'bytesValue', 'charValue', 'usizeValue', 'isizeValue', 'digit'],
            \LeanNominalprimitivesubtypes\Pair::class => ['left', 'right'],
            \LeanNominalprimitivesubtypes\RawPacket::class => ['unitValue', 'boolValue', 'uint8Value', 'uint16Value', 'uint32Value', 'uint64Value', 'int8Value', 'int16Value', 'int32Value', 'int64Value', 'natValue', 'intValue', 'float32Value', 'float64Value', 'textValue', 'bytesValue', 'charValue', 'usizeValue', 'isizeValue', 'digit'],
            \LeanNominalprimitivesubtypes\EventEmpty::class => [],
            \LeanNominalprimitivesubtypes\EventBox::class => ['value'],
            \LeanNominalprimitivesubtypes\EventChoices::class => ['values'],
            default => throw new \TypeError('Value comparison requires generated copied values'),
        };
        $budget->charge(count($expected), 32);
        $fields = get_object_vars($value);
        if (array_keys($fields) !== $expected) throw new \TypeError('Value comparison requires initialized fields');
        return $fields;
    }
    public static function equal(mixed $left, mixed $right): bool {
        return self::same($left, $right, new Budget(), 0);
    }
    private static function same(mixed $left, mixed $right, Budget $budget, int $depth): bool {
        self::step($budget, $depth);
        if (get_debug_type($left) !== get_debug_type($right)) return false;
        if (is_float($left)) return is_nan($left) ? is_nan($right) : pack('E', $left) === pack('E', $right);
        if ($left instanceof \Brick\Math\BigInteger) { $left = (string) $left; $right = (string) $right; }
        elseif ($left instanceof \LeanNominalprimitivesubtypes\Bytes) { $left = $left->toString(); $right = $right->toString(); }
        elseif (is_object($left)) {
            $left = self::fields($left, $budget); $right = self::fields($right, $budget);
            foreach ($left as $name => $value) if (!self::same($value, $right[$name], $budget, $depth + 1)) return false;
            return true;
        }
        if (is_string($left)) { $budget->charge(strlen($left)); $budget->charge(strlen($right)); return $left === $right; }
        if (is_array($left)) {
            $budget->charge(count($left), 32); $budget->charge(count($right), 32);
            if (!array_is_list($left) || !array_is_list($right)) throw new \TypeError('Value comparison requires consecutive-key lists');
            if (count($left) !== count($right)) return false;
            foreach ($left as $index => $value) if (!self::same($value, $right[$index], $budget, $depth + 1)) return false;
            return true;
        }
        if ($left === null || is_bool($left) || is_int($left)) return $left === $right;
        throw new \TypeError('Value comparison requires copied values');
    }
    private static function text(\HashContext $hash, string $tag, string $text, Budget $budget): void {
        $budget->charge(strlen($text));
        hash_update($hash, $tag . pack('N', strlen($text))); hash_update($hash, $text);
    }
    public static function hash(mixed $value): string {
        $hash = hash_init('sha256'); self::append($hash, $value, new Budget(), 0); return hash_final($hash);
    }
    private static function append(\HashContext $hash, mixed $value, Budget $budget, int $depth): void {
        self::step($budget, $depth);
        if ($value === null) hash_update($hash, 'n');
        elseif (is_bool($value)) hash_update($hash, $value ? 't' : 'f');
        elseif (is_int($value)) self::text($hash, 'i', (string) $value, $budget);
        elseif (is_float($value)) hash_update($hash, is_nan($value) ? 'q' : 'd' . pack('E', $value));
        elseif (is_string($value)) self::text($hash, 's', $value, $budget);
        elseif ($value instanceof \Brick\Math\BigInteger) self::text($hash, 'b', (string) $value, $budget);
        elseif ($value instanceof \LeanNominalprimitivesubtypes\Bytes) self::text($hash, 'y', $value->toString(), $budget);
        elseif (is_array($value)) {
            $budget->charge(count($value), 32);
            if (!array_is_list($value)) throw new \TypeError('Value hashing requires consecutive-key lists');
            hash_update($hash, 'a' . pack('N', count($value)));
            foreach ($value as $item) self::append($hash, $item, $budget, $depth + 1);
        } elseif (is_object($value)) {
            $fields = self::fields($value, $budget);
            self::text($hash, 'o', $value::class, $budget);
            foreach ($fields as $name => $item) { self::text($hash, 'k', $name, $budget); self::append($hash, $item, $budget, $depth + 1); }
        } else throw new \TypeError('Value hashing requires copied values');
    }
}


final class Native
{
    private static function to0(mixed $value): mixed { return $value; }
    private static function from0(mixed $value): mixed { return $value; }
    private static function to1(mixed $value): mixed { return $value; }
    private static function from1(mixed $value): mixed { return $value; }
    private static function to2(mixed $value): mixed { return $value; }
    private static function from2(mixed $value): mixed { return $value; }
    private static function to3(mixed $value): mixed { return $value; }
    private static function from3(mixed $value): mixed { return $value; }
    private static function to4(mixed $value): mixed { return (string) $value; }
    private static function from4(mixed $value): mixed { return \Brick\Math\BigInteger::of($value); }
    private static function to5(mixed $value): mixed { return (string) $value; }
    private static function from5(mixed $value): mixed { return \Brick\Math\BigInteger::of($value); }
    private static function to6(mixed $value): mixed { return $value; }
    private static function from6(mixed $value): mixed { return $value; }
    private static function to7(mixed $value): mixed { return $value; }
    private static function from7(mixed $value): mixed { return $value; }
    private static function to8(mixed $value): mixed { return $value; }
    private static function from8(mixed $value): mixed { return $value; }
    private static function to9(mixed $value): mixed { return (string) $value; }
    private static function from9(mixed $value): mixed { return \Brick\Math\BigInteger::of($value); }
    private static function to10(mixed $value): mixed { return (string) $value; }
    private static function from10(mixed $value): mixed { return \Brick\Math\BigInteger::of($value); }
    private static function to11(mixed $value): mixed { return (string) $value; }
    private static function from11(mixed $value): mixed { return \Brick\Math\BigInteger::of($value); }
    private static function to12(mixed $value): mixed { return $value; }
    private static function from12(mixed $value): mixed { return $value; }
    private static function to13(mixed $value): mixed { return $value; }
    private static function from13(mixed $value): mixed { return $value; }
    private static function to14(mixed $value): mixed { return $value; }
    private static function from14(mixed $value): mixed { return $value; }
    private static function to15(mixed $value): mixed { return $value->toString(); }
    private static function from15(mixed $value): mixed { return \LeanNominalprimitivesubtypes\Bytes::fromString($value); }
    private static function to16(mixed $value): mixed { return $value; }
    private static function from16(mixed $value): mixed { return $value; }
    private static function to17(mixed $value): mixed { return (string) $value; }
    private static function from17(mixed $value): mixed { return \Brick\Math\BigInteger::of($value); }
    private static function to18(mixed $value): mixed { return $value; }
    private static function from18(mixed $value): mixed { return $value; }
    private static function to19(mixed $value): mixed { return [self::to0($value->unitValue), self::to1($value->boolValue), self::to2($value->uint8Value), self::to3($value->uint16Value), self::to4($value->uint32Value), self::to5($value->uint64Value), self::to6($value->int8Value), self::to7($value->int16Value), self::to8($value->int32Value), self::to9($value->int64Value), self::to10($value->natValue), self::to11($value->intValue), self::to12($value->float32Value), self::to13($value->float64Value), self::to14($value->textValue), self::to15($value->bytesValue), self::to16($value->charValue), self::to17($value->usizeValue), self::to18($value->isizeValue), self::to10($value->digit)]; }
    private static function from19(mixed $value): mixed { return new \LeanNominalprimitivesubtypes\Packet(self::from0($value[0]), self::from1($value[1]), self::from2($value[2]), self::from3($value[3]), self::from4($value[4]), self::from5($value[5]), self::from6($value[6]), self::from7($value[7]), self::from8($value[8]), self::from9($value[9]), self::from10($value[10]), self::from11($value[11]), self::from12($value[12]), self::from13($value[13]), self::from14($value[14]), self::from15($value[15]), self::from16($value[16]), self::from17($value[17]), self::from18($value[18]), self::from10($value[19])); }
    private static function to20(mixed $value): mixed { return $value === null ? null : [self::to19($value->value)]; }
    private static function from20(mixed $value): mixed { return $value === null ? null : new \LeanNominalprimitivesubtypes\Some(self::from19($value[0])); }
    private static function to21(mixed $value): mixed { return array_map(self::to20(...), $value); }
    private static function from21(mixed $value): mixed { return array_map(self::from20(...), $value); }
    private static function to22(mixed $value): mixed { return [self::to19($value[0]), self::to19($value[1])]; }
    private static function from22(mixed $value): mixed { return [self::from19($value[0]), self::from19($value[1])]; }
    private static function to23(mixed $value): mixed { return $value instanceof \LeanNominalprimitivesubtypes\Ok ? [true, self::to19($value->value)] : [false, self::to19($value->value)]; }
    private static function from23(mixed $value): mixed { return $value[0] ? new \LeanNominalprimitivesubtypes\Ok(self::from19($value[1])) : new \LeanNominalprimitivesubtypes\Err(self::from19($value[1])); }
    private static function to24(mixed $value): mixed { return $value === null ? null : [self::to23($value->value)]; }
    private static function from24(mixed $value): mixed { return $value === null ? null : new \LeanNominalprimitivesubtypes\Some(self::from23($value[0])); }
    private static function to25(mixed $value): mixed { return array_map(self::to24(...), $value); }
    private static function from25(mixed $value): mixed { return array_map(self::from24(...), $value); }
    private static function to26(mixed $value): mixed {
        if ($value instanceof \LeanNominalprimitivesubtypes\EventEmpty) return [0];
        if ($value instanceof \LeanNominalprimitivesubtypes\EventBox) return [1, self::to19($value->value)];
        if ($value instanceof \LeanNominalprimitivesubtypes\EventChoices) return [2, self::to25($value->values)];
        throw new \TypeError('Expected an exact Event constructor');
    }
    private static function from26(mixed $value): mixed {
        if (!is_array($value) || !array_is_list($value) || !isset($value[0]) || !is_int($value[0])) throw new \RuntimeException('Invalid Event wire tag');
        switch ($value[0]) {
        case 0:
            if (count($value) !== 1) throw new \RuntimeException('Invalid EventEmpty wire fields');
            return new \LeanNominalprimitivesubtypes\EventEmpty();
        case 1:
            if (count($value) !== 2) throw new \RuntimeException('Invalid EventBox wire fields');
            return new \LeanNominalprimitivesubtypes\EventBox(self::from19($value[1]));
        case 2:
            if (count($value) !== 2) throw new \RuntimeException('Invalid EventChoices wire fields');
            return new \LeanNominalprimitivesubtypes\EventChoices(self::from25($value[1]));
        default: throw new \RuntimeException('Invalid Event wire constructor');
        }
    }
    private static function to27(mixed $value): mixed { return [self::to21($value->left), self::to21($value->right)]; }
    private static function from27(mixed $value): mixed { return new \LeanNominalprimitivesubtypes\Pair(self::from21($value[0]), self::from21($value[1])); }
    private static function to28(mixed $value): mixed { return [self::to0($value->unitValue), self::to1($value->boolValue), self::to2($value->uint8Value), self::to3($value->uint16Value), self::to4($value->uint32Value), self::to5($value->uint64Value), self::to6($value->int8Value), self::to7($value->int16Value), self::to8($value->int32Value), self::to9($value->int64Value), self::to10($value->natValue), self::to11($value->intValue), self::to12($value->float32Value), self::to13($value->float64Value), self::to14($value->textValue), self::to15($value->bytesValue), self::to16($value->charValue), self::to17($value->usizeValue), self::to18($value->isizeValue), self::to10($value->digit)]; }
    private static function from28(mixed $value): mixed { return new \LeanNominalprimitivesubtypes\RawPacket(self::from0($value[0]), self::from1($value[1]), self::from2($value[2]), self::from3($value[3]), self::from4($value[4]), self::from5($value[5]), self::from6($value[6]), self::from7($value[7]), self::from8($value[8]), self::from9($value[9]), self::from10($value[10]), self::from11($value[11]), self::from12($value[12]), self::from13($value[13]), self::from14($value[14]), self::from15($value[15]), self::from16($value[16]), self::from17($value[17]), self::from18($value[18]), self::from10($value[19])); }

    public static function call0(mixed $arg0, mixed $arg1): mixed {
        $budget = new Budget();
        $input0 = self::to21(Checks::check21($arg0, $budget));
        $input1 = self::to21(Checks::check21($arg1, $budget));
        if (!function_exists('LeanNominalprimitivesubtypes\Internal\Zenda01a8f62166f7ae3\\call0')) {
            try { \LeanBridge\CopiedPhpWasmV1\Loader::load('php8.4-lb_nominalprimitivesubtypes_a01a8f62166f7ae3.so', 'LeanNominalprimitivesubtypes\Internal\Zenda01a8f62166f7ae3\\call0'); }
            catch (\Throwable $error) { throw new \LeanNominalprimitivesubtypes\LeanBridgeError($error->getMessage(), 0, $error); }
        }
        try { $output = \LeanNominalprimitivesubtypes\Internal\Zenda01a8f62166f7ae3\call0($input0, $input1); }
        catch (\Exception $error) { throw new \LeanNominalprimitivesubtypes\LeanBridgeError($error->getMessage(), $error->getCode(), $error); }
        return self::from21($output);
    }
    public static function call1(mixed $arg0, mixed $arg1): mixed {
        $budget = new Budget();
        $input0 = self::to19(Checks::check19($arg0, $budget));
        $input1 = self::to19(Checks::check19($arg1, $budget));
        if (!function_exists('LeanNominalprimitivesubtypes\Internal\Zenda01a8f62166f7ae3\\call1')) {
            try { \LeanBridge\CopiedPhpWasmV1\Loader::load('php8.4-lb_nominalprimitivesubtypes_a01a8f62166f7ae3.so', 'LeanNominalprimitivesubtypes\Internal\Zenda01a8f62166f7ae3\\call1'); }
            catch (\Throwable $error) { throw new \LeanNominalprimitivesubtypes\LeanBridgeError($error->getMessage(), 0, $error); }
        }
        try { $output = \LeanNominalprimitivesubtypes\Internal\Zenda01a8f62166f7ae3\call1($input0, $input1); }
        catch (\Exception $error) { throw new \LeanNominalprimitivesubtypes\LeanBridgeError($error->getMessage(), $error->getCode(), $error); }
        return self::from22($output);
    }
    public static function call2(mixed $arg0): mixed {
        $budget = new Budget();
        $input0 = self::to19(Checks::check19($arg0, $budget));
        if (!function_exists('LeanNominalprimitivesubtypes\Internal\Zenda01a8f62166f7ae3\\call2')) {
            try { \LeanBridge\CopiedPhpWasmV1\Loader::load('php8.4-lb_nominalprimitivesubtypes_a01a8f62166f7ae3.so', 'LeanNominalprimitivesubtypes\Internal\Zenda01a8f62166f7ae3\\call2'); }
            catch (\Throwable $error) { throw new \LeanNominalprimitivesubtypes\LeanBridgeError($error->getMessage(), 0, $error); }
        }
        try { $output = \LeanNominalprimitivesubtypes\Internal\Zenda01a8f62166f7ae3\call2($input0); }
        catch (\Exception $error) { throw new \LeanNominalprimitivesubtypes\LeanBridgeError($error->getMessage(), $error->getCode(), $error); }
        return self::from19($output);
    }
    public static function call3(mixed $arg0): mixed {
        $budget = new Budget();
        $input0 = self::to19(Checks::check19($arg0, $budget));
        if (!function_exists('LeanNominalprimitivesubtypes\Internal\Zenda01a8f62166f7ae3\\call3')) {
            try { \LeanBridge\CopiedPhpWasmV1\Loader::load('php8.4-lb_nominalprimitivesubtypes_a01a8f62166f7ae3.so', 'LeanNominalprimitivesubtypes\Internal\Zenda01a8f62166f7ae3\\call3'); }
            catch (\Throwable $error) { throw new \LeanNominalprimitivesubtypes\LeanBridgeError($error->getMessage(), 0, $error); }
        }
        try { $output = \LeanNominalprimitivesubtypes\Internal\Zenda01a8f62166f7ae3\call3($input0); }
        catch (\Exception $error) { throw new \LeanNominalprimitivesubtypes\LeanBridgeError($error->getMessage(), $error->getCode(), $error); }
        return self::from19($output);
    }
    public static function call4(mixed $arg0): mixed {
        $budget = new Budget();
        $input0 = self::to26(Checks::check26($arg0, $budget));
        if (!function_exists('LeanNominalprimitivesubtypes\Internal\Zenda01a8f62166f7ae3\\call4')) {
            try { \LeanBridge\CopiedPhpWasmV1\Loader::load('php8.4-lb_nominalprimitivesubtypes_a01a8f62166f7ae3.so', 'LeanNominalprimitivesubtypes\Internal\Zenda01a8f62166f7ae3\\call4'); }
            catch (\Throwable $error) { throw new \LeanNominalprimitivesubtypes\LeanBridgeError($error->getMessage(), 0, $error); }
        }
        try { $output = \LeanNominalprimitivesubtypes\Internal\Zenda01a8f62166f7ae3\call4($input0); }
        catch (\Exception $error) { throw new \LeanNominalprimitivesubtypes\LeanBridgeError($error->getMessage(), $error->getCode(), $error); }
        return self::from26($output);
    }
    public static function call5(mixed $arg0): mixed {
        $budget = new Budget();
        $input0 = self::to26(Checks::check26($arg0, $budget));
        if (!function_exists('LeanNominalprimitivesubtypes\Internal\Zenda01a8f62166f7ae3\\call5')) {
            try { \LeanBridge\CopiedPhpWasmV1\Loader::load('php8.4-lb_nominalprimitivesubtypes_a01a8f62166f7ae3.so', 'LeanNominalprimitivesubtypes\Internal\Zenda01a8f62166f7ae3\\call5'); }
            catch (\Throwable $error) { throw new \LeanNominalprimitivesubtypes\LeanBridgeError($error->getMessage(), 0, $error); }
        }
        try { $output = \LeanNominalprimitivesubtypes\Internal\Zenda01a8f62166f7ae3\call5($input0); }
        catch (\Exception $error) { throw new \LeanNominalprimitivesubtypes\LeanBridgeError($error->getMessage(), $error->getCode(), $error); }
        return self::from26($output);
    }
    public static function call6(mixed $arg0): mixed {
        $budget = new Budget();
        $input0 = self::to27(Checks::check27($arg0, $budget));
        if (!function_exists('LeanNominalprimitivesubtypes\Internal\Zenda01a8f62166f7ae3\\call6')) {
            try { \LeanBridge\CopiedPhpWasmV1\Loader::load('php8.4-lb_nominalprimitivesubtypes_a01a8f62166f7ae3.so', 'LeanNominalprimitivesubtypes\Internal\Zenda01a8f62166f7ae3\\call6'); }
            catch (\Throwable $error) { throw new \LeanNominalprimitivesubtypes\LeanBridgeError($error->getMessage(), 0, $error); }
        }
        try { $output = \LeanNominalprimitivesubtypes\Internal\Zenda01a8f62166f7ae3\call6($input0); }
        catch (\Exception $error) { throw new \LeanNominalprimitivesubtypes\LeanBridgeError($error->getMessage(), $error->getCode(), $error); }
        return self::from27($output);
    }
    public static function call7(mixed $arg0): mixed {
        $budget = new Budget();
        $input0 = self::to28(Checks::check28($arg0, $budget));
        if (!function_exists('LeanNominalprimitivesubtypes\Internal\Zenda01a8f62166f7ae3\\call7')) {
            try { \LeanBridge\CopiedPhpWasmV1\Loader::load('php8.4-lb_nominalprimitivesubtypes_a01a8f62166f7ae3.so', 'LeanNominalprimitivesubtypes\Internal\Zenda01a8f62166f7ae3\\call7'); }
            catch (\Throwable $error) { throw new \LeanNominalprimitivesubtypes\LeanBridgeError($error->getMessage(), 0, $error); }
        }
        try { $output = \LeanNominalprimitivesubtypes\Internal\Zenda01a8f62166f7ae3\call7($input0); }
        catch (\Exception $error) { throw new \LeanNominalprimitivesubtypes\LeanBridgeError($error->getMessage(), $error->getCode(), $error); }
        return self::from20($output);
    }
    public static function call8(mixed $arg0): mixed {
        $budget = new Budget();
        $input0 = self::to28(Checks::check28($arg0, $budget));
        if (!function_exists('LeanNominalprimitivesubtypes\Internal\Zenda01a8f62166f7ae3\\call8')) {
            try { \LeanBridge\CopiedPhpWasmV1\Loader::load('php8.4-lb_nominalprimitivesubtypes_a01a8f62166f7ae3.so', 'LeanNominalprimitivesubtypes\Internal\Zenda01a8f62166f7ae3\\call8'); }
            catch (\Throwable $error) { throw new \LeanNominalprimitivesubtypes\LeanBridgeError($error->getMessage(), 0, $error); }
        }
        try { $output = \LeanNominalprimitivesubtypes\Internal\Zenda01a8f62166f7ae3\call8($input0); }
        catch (\Exception $error) { throw new \LeanNominalprimitivesubtypes\LeanBridgeError($error->getMessage(), $error->getCode(), $error); }
        return self::from26($output);
    }
    public static function call9(mixed $arg0): mixed {
        $budget = new Budget();
        $input0 = self::to28(Checks::check28($arg0, $budget));
        if (!function_exists('LeanNominalprimitivesubtypes\Internal\Zenda01a8f62166f7ae3\\call9')) {
            try { \LeanBridge\CopiedPhpWasmV1\Loader::load('php8.4-lb_nominalprimitivesubtypes_a01a8f62166f7ae3.so', 'LeanNominalprimitivesubtypes\Internal\Zenda01a8f62166f7ae3\\call9'); }
            catch (\Throwable $error) { throw new \LeanNominalprimitivesubtypes\LeanBridgeError($error->getMessage(), 0, $error); }
        }
        try { $output = \LeanNominalprimitivesubtypes\Internal\Zenda01a8f62166f7ae3\call9($input0); }
        catch (\Exception $error) { throw new \LeanNominalprimitivesubtypes\LeanBridgeError($error->getMessage(), $error->getCode(), $error); }
        return self::from26($output);
    }
    public static function call10(mixed $arg0): mixed {
        $budget = new Budget();
        $input0 = self::to28(Checks::check28($arg0, $budget));
        if (!function_exists('LeanNominalprimitivesubtypes\Internal\Zenda01a8f62166f7ae3\\call10')) {
            try { \LeanBridge\CopiedPhpWasmV1\Loader::load('php8.4-lb_nominalprimitivesubtypes_a01a8f62166f7ae3.so', 'LeanNominalprimitivesubtypes\Internal\Zenda01a8f62166f7ae3\\call10'); }
            catch (\Throwable $error) { throw new \LeanNominalprimitivesubtypes\LeanBridgeError($error->getMessage(), 0, $error); }
        }
        try { $output = \LeanNominalprimitivesubtypes\Internal\Zenda01a8f62166f7ae3\call10($input0); }
        catch (\Exception $error) { throw new \LeanNominalprimitivesubtypes\LeanBridgeError($error->getMessage(), $error->getCode(), $error); }
        return self::from21($output);
    }
    public static function call11(mixed $arg0): mixed {
        $budget = new Budget();
        $input0 = self::to28(Checks::check28($arg0, $budget));
        if (!function_exists('LeanNominalprimitivesubtypes\Internal\Zenda01a8f62166f7ae3\\call11')) {
            try { \LeanBridge\CopiedPhpWasmV1\Loader::load('php8.4-lb_nominalprimitivesubtypes_a01a8f62166f7ae3.so', 'LeanNominalprimitivesubtypes\Internal\Zenda01a8f62166f7ae3\\call11'); }
            catch (\Throwable $error) { throw new \LeanNominalprimitivesubtypes\LeanBridgeError($error->getMessage(), 0, $error); }
        }
        try { $output = \LeanNominalprimitivesubtypes\Internal\Zenda01a8f62166f7ae3\call11($input0); }
        catch (\Exception $error) { throw new \LeanNominalprimitivesubtypes\LeanBridgeError($error->getMessage(), $error->getCode(), $error); }
        return self::from27($output);
    }
    public static function call12(mixed $arg0): mixed {
        $budget = new Budget();
        $input0 = self::to19(Checks::check19($arg0, $budget));
        if (!function_exists('LeanNominalprimitivesubtypes\Internal\Zenda01a8f62166f7ae3\\call12')) {
            try { \LeanBridge\CopiedPhpWasmV1\Loader::load('php8.4-lb_nominalprimitivesubtypes_a01a8f62166f7ae3.so', 'LeanNominalprimitivesubtypes\Internal\Zenda01a8f62166f7ae3\\call12'); }
            catch (\Throwable $error) { throw new \LeanNominalprimitivesubtypes\LeanBridgeError($error->getMessage(), 0, $error); }
        }
        try { $output = \LeanNominalprimitivesubtypes\Internal\Zenda01a8f62166f7ae3\call12($input0); }
        catch (\Exception $error) { throw new \LeanNominalprimitivesubtypes\LeanBridgeError($error->getMessage(), $error->getCode(), $error); }
        return self::from19($output);
    }
    public static function call13(): mixed {
        $budget = new Budget();

        if (!function_exists('LeanNominalprimitivesubtypes\Internal\Zenda01a8f62166f7ae3\\call13')) {
            try { \LeanBridge\CopiedPhpWasmV1\Loader::load('php8.4-lb_nominalprimitivesubtypes_a01a8f62166f7ae3.so', 'LeanNominalprimitivesubtypes\Internal\Zenda01a8f62166f7ae3\\call13'); }
            catch (\Throwable $error) { throw new \LeanNominalprimitivesubtypes\LeanBridgeError($error->getMessage(), 0, $error); }
        }
        try { $output = \LeanNominalprimitivesubtypes\Internal\Zenda01a8f62166f7ae3\call13(); }
        catch (\Exception $error) { throw new \LeanNominalprimitivesubtypes\LeanBridgeError($error->getMessage(), $error->getCode(), $error); }
        return self::from4($output);
    }
}
}
