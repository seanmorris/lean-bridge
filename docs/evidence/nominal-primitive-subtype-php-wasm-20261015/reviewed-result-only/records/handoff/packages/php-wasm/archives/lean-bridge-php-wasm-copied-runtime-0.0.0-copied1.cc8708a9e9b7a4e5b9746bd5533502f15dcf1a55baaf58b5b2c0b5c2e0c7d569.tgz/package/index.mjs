import { createPhpWasmCopiedDescriptor } from './host.mjs';
const runtime = Object.freeze({"identity":"44535fd7b0e510b50f3aae5e2134970012d90e9f6be04048a04dce85bddbd966","loaderIdentity":"cc8708a9e9b7a4e5b9746bd5533502f15dcf1a55baaf58b5b2c0b5c2e0c7d569","library":"liblean_bridge_php_wasm_copied_abe4dea500dab9519b8d.so"});
export const createDescriptor = (component, assets) => createPhpWasmCopiedDescriptor({ ...runtime, url: new URL("./compiled/lib/liblean_bridge_php_wasm_copied_abe4dea500dab9519b8d.so", import.meta.url) }, component, assets);
