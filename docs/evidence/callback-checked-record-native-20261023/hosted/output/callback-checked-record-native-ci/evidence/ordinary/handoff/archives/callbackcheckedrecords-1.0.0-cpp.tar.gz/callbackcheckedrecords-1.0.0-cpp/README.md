# callbackcheckedrecords 1.0.0

Compiled C++20 API from callbackcheckedrecords@1.0.0. Linux x86-64, glibc 2.38 or newer. Lean is not required by consumers. The shared native runtime is included in lib/ and loads automatically.

Include callbackcheckedrecords.hpp. Use pkg-config package callbackcheckedrecords, or find_package(LeanBridgeCallbackcheckedrecords CONFIG REQUIRED) and link LeanBridge::callbackcheckedrecords. C++ functions live in lean_bridge::callbackcheckedrecords.

C++ results own their memory and release native buffers automatically, including when a C++ allocation throws.

Strings are length-delimited UTF-8, including embedded NUL. Byte arrays are uninterpreted bytes. Nat and Int are Boost.Multiprecision cpp_int values. Negative Nat inputs reject. Packages using these types include Boost 1.90.0 standalone headers, license and source hashes; CMake and pkg-config configure them automatically. Unit parameters are zero in C and std::monostate in C++; Unit results have no output. Fixed-width integers use exact-width host types; floating-point values retain IEEE special values. Input and output copies share a 16 MiB per-call budget. Invalid input leaves the output unchanged and returns a status (C) or throws Error (C++).

Recursive copied records and named variants use a finite type graph. Values must be finite and acyclic, with at most 128 levels and 262,144 visited nodes per call. All inputs and the result share a 16 MiB native-copy budget; host conversion storage has a separate 16 MiB budget. Limits include container slots and ownership bookkeeping, not the Lean algorithm's working memory. Invalid arguments and limit failures report INVALID_ARGUMENT. Bridge allocation failures report UNEXPECTED_ERROR; malformed native results retire the shared runtime and later calls reject. Already owned results can still be released.

C++ uses owned strings, vectors, optional values, pairs and named structs. Variants have a named struct for each constructor; inspect value with std::get, std::holds_alternative or std::visit. Recursive fields that require indirection use Box<T>; copying a box makes an independent deep copy. Empty required boxes reject. None, Some(None), Unit and empty constructors remain distinct. Calls return owned values, throw Error with status/code on bridge failures, or propagate std::bad_alloc for C++ allocation failures. Input and native output views are released during exception unwinding. Do not mutate input values concurrently with a call.

Pass typed C++ lambdas or functions for synchronous callbacks. Arguments are owned values and results must match the declared type exactly; Unit results return void. Move-only callbacks are supported. Exceptions are contained before C and rethrown after the native call returns. The first failure suppresses later host invocations. Returned LeanClosure<Result(Args...)> values are move-only: call(...) or operator() invokes them, close() releases explicitly, and destruction releases automatically. Invoke and close on the creating thread. Moving a closure does not change its creating thread. Calls after close and inherited calls after fork reject. Closing invalidates the handle immediately; an active invocation keeps its own reference until return. Call-scoped host callbacks cannot be retained by Lean. Nested callable calls are limited to 64; the 16 MiB budget includes callback conversions. Closure leases share the runtime's 4096-identity capacity.

A host callback whose result contains a checked Lean Subtype or checked record must be passed through with_recovery(callback, value). The recovery has the callback's exact erased result type, a generated value record carrying only payload fields for a checked record, and is validated before Lean or the callback runs. Lean applies the selected checked constructor to every host-produced Subtype leaf and checked record, nested checked fields before their record. Constructor rejection, a thrown exception or another callback failure fails the enclosing call, suppresses later callbacks and leaves its output unchanged; the recovery is used only inside Lean's failure path and is never returned as a successful result. Subtype and checked-record arguments to returned LeanClosure values are checked before the closure body runs; checked records Lean produces for the host carry payload fields only.

- call_host: lean:CallbackCheckedRecords.callHost
- call_host_container: lean:CallbackCheckedRecords.callHostContainer
- call_host_mixed: lean:CallbackCheckedRecords.callHostMixed
- call_host_nested: lean:CallbackCheckedRecords.callHostNested
- make_closure: lean:CallbackCheckedRecords.makeClosure
- make_container_closure: lean:CallbackCheckedRecords.makeContainerClosure
- make_mixed_closure: lean:CallbackCheckedRecords.makeMixedClosure
- make_nested_closure: lean:CallbackCheckedRecords.makeNestedClosure
