#pragma once
#include "detail/callbackcheckedrecords-status.h"
#include <stdbool.h>
#include <string.h>
namespace lean_bridge::callbackcheckedrecords::detail {
struct callbackcheckedrecords_graph_38a8689c2f20ead532ea_t;
struct callbackcheckedrecords_graph_7ee21eb6b8ea120b53f0_t;
struct callbackcheckedrecords_graph_29468227bdfd05da1480_t;
struct callbackcheckedrecords_interval_t;
struct callbackcheckedrecords_weighted_t;
struct callbackcheckedrecords_scalar_nat_t;
struct callbackcheckedrecords_scalar_string_t;
#include "detail/callbackcheckedrecords-graph.h"
}
#include "detail/callbackcheckedrecords-conversions.hpp"
#include <concepts>
#include <exception>
#include <functional>
#include <unistd.h>
namespace lean_bridge::callbackcheckedrecords {

class Error final : public std::runtime_error {
public:
  callbackcheckedrecords_status status; callbackcheckedrecords_error_code code;
  Error(callbackcheckedrecords_status status, const callbackcheckedrecords_error& error)
    : std::runtime_error(error.message ? std::string(error.message, error.message_length) : "Lean call failed"), status(status), code(error.code) {}
};
namespace detail {
[[noreturn]] inline void callable_fail(uint32_t status) {
  if (status == 4) callbackcheckedrecords_graph_retire();
  if (status == 10) {
    static constexpr char message[] = "Host callback result failed its Lean constructor";
    callbackcheckedrecords_error error{CALLBACKCHECKEDRECORDS_ERROR_INVALID_ARGUMENT, message, sizeof(message) - 1};
    throw Error(CALLBACKCHECKEDRECORDS_STATUS_INVALID_ARGUMENT, error);
  }
  callbackcheckedrecords_error error{}; auto code = callbackcheckedrecords_graph_finish(status, &error);
  if (status == 6) { code = CALLBACKCHECKEDRECORDS_STATUS_DECLARED_ERROR; error = {CALLBACKCHECKEDRECORDS_ERROR_UNEXPECTED, "Host callback failed", 20}; }
  throw Error(code, error);
}
inline const std::shared_ptr<const char>& callable_thread() {
  static thread_local const auto value = std::make_shared<const char>(); return value;
}
struct GraphLease {
  uint64_t token = 0;
  void (*dispose)(uint64_t);
  const pid_t process = ::getpid();
  const std::shared_ptr<const char> thread = callable_thread();
  bool closed = false;
  explicit GraphLease(void (*release)(uint64_t)) : dispose(release) {}
  ~GraphLease() { if (process == ::getpid() && token) dispose(token); }
  void require() const {
    if (process != ::getpid() || thread != callable_thread() || closed || !token) callable_fail(1);
  }
  void close() {
    if (process != ::getpid() || thread != callable_thread()) callable_fail(1);
    closed = true; uint64_t previous = std::exchange(token, 0); if (previous) dispose(previous);
  }
};
struct GraphCallbackState {
  GraphBudget budget;
  std::exception_ptr failure;
  void finish(uint32_t status) const {
    if (failure) std::rethrow_exception(failure);
    if (status) callable_fail(status);
    if (!callbackcheckedrecords_graph_ready()) callable_fail(5);
  }
};
template<class F, class R> struct GraphRecoveredCallback { F function; R recovery; };
template<class F> constexpr bool graph_has_recovery = false;
template<class F, class R> constexpr bool graph_has_recovery<GraphRecoveredCallback<F, R>> = true;
template<class F, class Expected> constexpr bool graph_recovery_matches = false;
template<class F, class R, class Expected> constexpr bool graph_recovery_matches<GraphRecoveredCallback<F, R>, Expected> = std::same_as<R, Expected>;
template<class F> inline F& graph_function(F& function) { return function; }
template<class F, class R> inline F& graph_function(GraphRecoveredCallback<F, R>& function) { return function.function; }
template<class F, class R> inline const R& graph_recovery(const GraphRecoveredCallback<F, R>& function) { return function.recovery; }
struct GraphClosureFactory;
}
template<class Signature> class LeanClosure;
template<class Result, class... Args> class LeanClosure<Result(Args...)> final {
  std::shared_ptr<detail::GraphLease> lease_;
  Result (*invoke_)(detail::GraphLease&, const Args&...);
  LeanClosure(std::shared_ptr<detail::GraphLease> lease, Result (*invoke)(detail::GraphLease&, const Args&...)) noexcept
    : lease_(std::move(lease)), invoke_(invoke) {}
  friend struct detail::GraphClosureFactory;
public:
  LeanClosure(const LeanClosure&) = delete;
  LeanClosure& operator=(const LeanClosure&) = delete;
  LeanClosure(LeanClosure&&) noexcept = default;
  LeanClosure& operator=(LeanClosure&&) noexcept = default;
  Result call(const Args&... args) const {
    auto active = lease_; if (!active) detail::callable_fail(1); active->require();
    return invoke_(*active, args...);
  }
  Result operator()(const Args&... args) const { return call(args...); }
  void close() const { if (lease_) lease_->close(); }
  bool is_closed() const noexcept { return !lease_ || lease_->closed; }
};
namespace detail {
struct GraphClosureFactory {
  template<class Signature, class Invoke> static LeanClosure<Signature> make(std::shared_ptr<GraphLease> lease, Invoke invoke) noexcept {
    return LeanClosure<Signature>(std::move(lease), invoke);
  }
};

template<class Function> concept GraphAccepts0 = graph_recovery_matches<std::remove_cvref_t<Function>, Graph29468227bdfd05da1480> && requires(Function& function, const Graph38a8689c2f20ead532ea& a0) {
	  { std::invoke(graph_function(function), a0) } -> std::same_as<Graph29468227bdfd05da1480>;
};
template<class Function> struct GraphCallback0 {
  Function& function; GraphCallbackState& state;
  std::unique_ptr<GraphView2> recovery;
  GraphCallback0(Function& input, GraphCallbackState& shared) : function(input), state(shared), recovery(std::make_unique<GraphView2>(graph_recovery(input))) {}
  struct Reply {
    Graph29468227bdfd05da1480 data; GraphView2 view;
    explicit Reply(Graph29468227bdfd05da1480 input) : data(std::move(input)), view(data) {}
    static void release(void *owner) noexcept { delete static_cast<Reply*>(owner); }
  };
  static uint32_t invoke(void *context, const callbackcheckedrecords_graph_38a8689c2f20ead532ea_t *a0, callbackcheckedrecords_graph_29468227bdfd05da1480_t *out) noexcept {
    auto& self = *static_cast<GraphCallback0*>(context);
    if (self.state.failure) return 6;
    try {
	  Graph29468227bdfd05da1480 returned = std::invoke(graph_function(self.function), graph_from0(graph_read(a0), 0, true, true, self.state.budget));
      graph_check2(returned, 0, true, self.state.budget);
      auto owner = std::make_unique<Reply>(std::move(returned));
      *out = owner->view.value; out->_bridge_owner = owner.release(); out->_bridge_release = Reply::release;
      return 0;
    } catch (const GraphConversionError& error) {
      try { callable_fail(error.status); } catch (...) { if (!self.state.failure) self.state.failure = std::current_exception(); }
    } catch (...) { if (!self.state.failure) self.state.failure = std::current_exception(); }
    return 6;
  }
};
template<class Function> concept GraphAccepts1 = graph_recovery_matches<std::remove_cvref_t<Function>, Interval> && requires(Function& function, const Nat& a0, const Interval& a1) {
	  { std::invoke(graph_function(function), a0, a1) } -> std::same_as<Interval>;
};
template<class Function> struct GraphCallback1 {
  Function& function; GraphCallbackState& state;
  std::unique_ptr<GraphView3> recovery;
  GraphCallback1(Function& input, GraphCallbackState& shared) : function(input), state(shared), recovery(std::make_unique<GraphView3>(graph_recovery(input))) {}
  struct Reply {
    Interval data; GraphView3 view;
    explicit Reply(Interval input) : data(std::move(input)), view(data) {}
    static void release(void *owner) noexcept { delete static_cast<Reply*>(owner); }
  };
  static uint32_t invoke(void *context, const callbackcheckedrecords_scalar_nat_t *a0, const callbackcheckedrecords_interval_t *a1, callbackcheckedrecords_interval_t *out) noexcept {
    auto& self = *static_cast<GraphCallback1*>(context);
    if (self.state.failure) return 6;
    try {
	  Interval returned = std::invoke(graph_function(self.function), graph_from5(graph_read(a0), 0, true, true, self.state.budget), graph_from3(graph_read(a1), 0, true, true, self.state.budget));
      graph_check3(returned, 0, true, self.state.budget);
      auto owner = std::make_unique<Reply>(std::move(returned));
      *out = owner->view.value; out->_bridge_owner = owner.release(); out->_bridge_release = Reply::release;
      return 0;
    } catch (const GraphConversionError& error) {
      try { callable_fail(error.status); } catch (...) { if (!self.state.failure) self.state.failure = std::current_exception(); }
    } catch (...) { if (!self.state.failure) self.state.failure = std::current_exception(); }
    return 6;
  }
};
template<class Function> concept GraphAccepts2 = requires(Function& function, const Interval& a0) {
	  { std::invoke(graph_function(function), a0) } -> std::same_as<Nat>;
};
template<class Function> struct GraphCallback2 {
  Function& function; GraphCallbackState& state;
  GraphCallback2(Function& input, GraphCallbackState& shared) : function(input), state(shared) {}
  struct Reply {
    Nat data; GraphView5 view;
    explicit Reply(Nat input) : data(std::move(input)), view(data) {}
    static void release(void *owner) noexcept { delete static_cast<Reply*>(owner); }
  };
  static uint32_t invoke(void *context, const callbackcheckedrecords_interval_t *a0, callbackcheckedrecords_scalar_nat_t *out) noexcept {
    auto& self = *static_cast<GraphCallback2*>(context);
    if (self.state.failure) return 6;
    try {
	  Nat returned = std::invoke(graph_function(self.function), graph_from3(graph_read(a0), 0, true, true, self.state.budget));
      graph_check5(returned, 0, true, self.state.budget);
      auto owner = std::make_unique<Reply>(std::move(returned));
      *out = owner->view.value; out->_bridge_owner = owner.release(); out->_bridge_release = Reply::release;
      return 0;
    } catch (const GraphConversionError& error) {
      try { callable_fail(error.status); } catch (...) { if (!self.state.failure) self.state.failure = std::current_exception(); }
    } catch (...) { if (!self.state.failure) self.state.failure = std::current_exception(); }
    return 6;
  }
};
template<class Function> concept GraphAccepts3 = graph_recovery_matches<std::remove_cvref_t<Function>, Interval> && requires(Function& function, const Interval& a0) {
	  { std::invoke(graph_function(function), a0) } -> std::same_as<Interval>;
};
template<class Function> struct GraphCallback3 {
  Function& function; GraphCallbackState& state;
  std::unique_ptr<GraphView3> recovery;
  GraphCallback3(Function& input, GraphCallbackState& shared) : function(input), state(shared), recovery(std::make_unique<GraphView3>(graph_recovery(input))) {}
  struct Reply {
    Interval data; GraphView3 view;
    explicit Reply(Interval input) : data(std::move(input)), view(data) {}
    static void release(void *owner) noexcept { delete static_cast<Reply*>(owner); }
  };
  static uint32_t invoke(void *context, const callbackcheckedrecords_interval_t *a0, callbackcheckedrecords_interval_t *out) noexcept {
    auto& self = *static_cast<GraphCallback3*>(context);
    if (self.state.failure) return 6;
    try {
	  Interval returned = std::invoke(graph_function(self.function), graph_from3(graph_read(a0), 0, true, true, self.state.budget));
      graph_check3(returned, 0, true, self.state.budget);
      auto owner = std::make_unique<Reply>(std::move(returned));
      *out = owner->view.value; out->_bridge_owner = owner.release(); out->_bridge_release = Reply::release;
      return 0;
    } catch (const GraphConversionError& error) {
      try { callable_fail(error.status); } catch (...) { if (!self.state.failure) self.state.failure = std::current_exception(); }
    } catch (...) { if (!self.state.failure) self.state.failure = std::current_exception(); }
    return 6;
  }
};
template<class Function> concept GraphAccepts4 = requires(Function& function, const Weighted& a0) {
	  { std::invoke(graph_function(function), a0) } -> std::same_as<Nat>;
};
template<class Function> struct GraphCallback4 {
  Function& function; GraphCallbackState& state;
  GraphCallback4(Function& input, GraphCallbackState& shared) : function(input), state(shared) {}
  struct Reply {
    Nat data; GraphView5 view;
    explicit Reply(Nat input) : data(std::move(input)), view(data) {}
    static void release(void *owner) noexcept { delete static_cast<Reply*>(owner); }
  };
  static uint32_t invoke(void *context, const callbackcheckedrecords_weighted_t *a0, callbackcheckedrecords_scalar_nat_t *out) noexcept {
    auto& self = *static_cast<GraphCallback4*>(context);
    if (self.state.failure) return 6;
    try {
	  Nat returned = std::invoke(graph_function(self.function), graph_from4(graph_read(a0), 0, true, true, self.state.budget));
      graph_check5(returned, 0, true, self.state.budget);
      auto owner = std::make_unique<Reply>(std::move(returned));
      *out = owner->view.value; out->_bridge_owner = owner.release(); out->_bridge_release = Reply::release;
      return 0;
    } catch (const GraphConversionError& error) {
      try { callable_fail(error.status); } catch (...) { if (!self.state.failure) self.state.failure = std::current_exception(); }
    } catch (...) { if (!self.state.failure) self.state.failure = std::current_exception(); }
    return 6;
  }
};
template<class Function> concept GraphAccepts5 = graph_recovery_matches<std::remove_cvref_t<Function>, Weighted> && requires(Function& function, const Weighted& a0) {
	  { std::invoke(graph_function(function), a0) } -> std::same_as<Weighted>;
};
template<class Function> struct GraphCallback5 {
  Function& function; GraphCallbackState& state;
  std::unique_ptr<GraphView4> recovery;
  GraphCallback5(Function& input, GraphCallbackState& shared) : function(input), state(shared), recovery(std::make_unique<GraphView4>(graph_recovery(input))) {}
  struct Reply {
    Weighted data; GraphView4 view;
    explicit Reply(Weighted input) : data(std::move(input)), view(data) {}
    static void release(void *owner) noexcept { delete static_cast<Reply*>(owner); }
  };
  static uint32_t invoke(void *context, const callbackcheckedrecords_weighted_t *a0, callbackcheckedrecords_weighted_t *out) noexcept {
    auto& self = *static_cast<GraphCallback5*>(context);
    if (self.state.failure) return 6;
    try {
	  Weighted returned = std::invoke(graph_function(self.function), graph_from4(graph_read(a0), 0, true, true, self.state.budget));
      graph_check4(returned, 0, true, self.state.budget);
      auto owner = std::make_unique<Reply>(std::move(returned));
      *out = owner->view.value; out->_bridge_owner = owner.release(); out->_bridge_release = Reply::release;
      return 0;
    } catch (const GraphConversionError& error) {
      try { callable_fail(error.status); } catch (...) { if (!self.state.failure) self.state.failure = std::current_exception(); }
    } catch (...) { if (!self.state.failure) self.state.failure = std::current_exception(); }
    return 6;
  }
};
template<class Function> concept GraphAccepts6 = requires(Function& function, const Nat& a0, const Interval& a1) {
	  { std::invoke(graph_function(function), a0, a1) } -> std::same_as<Interval>;
};
template<class Function> struct GraphCallback6 {
  Function& function; GraphCallbackState& state;
  GraphCallback6(Function& input, GraphCallbackState& shared) : function(input), state(shared) {}
  struct Reply {
    Interval data; GraphView3 view;
    explicit Reply(Interval input) : data(std::move(input)), view(data) {}
    static void release(void *owner) noexcept { delete static_cast<Reply*>(owner); }
  };
  static uint32_t invoke(void *context, const callbackcheckedrecords_scalar_nat_t *a0, const callbackcheckedrecords_interval_t *a1, callbackcheckedrecords_interval_t *out) noexcept {
    auto& self = *static_cast<GraphCallback6*>(context);
    if (self.state.failure) return 6;
    try {
	  Interval returned = std::invoke(graph_function(self.function), graph_from5(graph_read(a0), 0, true, true, self.state.budget), graph_from3(graph_read(a1), 0, true, true, self.state.budget));
      graph_check3(returned, 0, true, self.state.budget);
      auto owner = std::make_unique<Reply>(std::move(returned));
      *out = owner->view.value; out->_bridge_owner = owner.release(); out->_bridge_release = Reply::release;
      return 0;
    } catch (const GraphConversionError& error) {
      try { callable_fail(error.status); } catch (...) { if (!self.state.failure) self.state.failure = std::current_exception(); }
    } catch (...) { if (!self.state.failure) self.state.failure = std::current_exception(); }
    return 6;
  }
};
template<class Function> concept GraphAccepts7 = requires(Function& function, const Graph7ee21eb6b8ea120b53f0& a0) {
	  { std::invoke(graph_function(function), a0) } -> std::same_as<Graph38a8689c2f20ead532ea>;
};
template<class Function> struct GraphCallback7 {
  Function& function; GraphCallbackState& state;
  GraphCallback7(Function& input, GraphCallbackState& shared) : function(input), state(shared) {}
  struct Reply {
    Graph38a8689c2f20ead532ea data; GraphView0 view;
    explicit Reply(Graph38a8689c2f20ead532ea input) : data(std::move(input)), view(data) {}
    static void release(void *owner) noexcept { delete static_cast<Reply*>(owner); }
  };
  static uint32_t invoke(void *context, const callbackcheckedrecords_graph_7ee21eb6b8ea120b53f0_t *a0, callbackcheckedrecords_graph_38a8689c2f20ead532ea_t *out) noexcept {
    auto& self = *static_cast<GraphCallback7*>(context);
    if (self.state.failure) return 6;
    try {
	  Graph38a8689c2f20ead532ea returned = std::invoke(graph_function(self.function), graph_from1(graph_read(a0), 0, true, true, self.state.budget));
      graph_check0(returned, 0, true, self.state.budget);
      auto owner = std::make_unique<Reply>(std::move(returned));
      *out = owner->view.value; out->_bridge_owner = owner.release(); out->_bridge_release = Reply::release;
      return 0;
    } catch (const GraphConversionError& error) {
      try { callable_fail(error.status); } catch (...) { if (!self.state.failure) self.state.failure = std::current_exception(); }
    } catch (...) { if (!self.state.failure) self.state.failure = std::current_exception(); }
    return 6;
  }
};
inline Nat graph_invoke2(GraphLease& lease, const Interval& a0) {
  try {
    detail::GraphCallbackState state;
    detail::graph_check3(a0, 0, true, state.budget);
    detail::GraphView3 view0(a0);
    detail::callbackcheckedrecords_scalar_nat_t out{};
    detail::GraphOwned<detail::callbackcheckedrecords_scalar_nat_t, detail::callbackcheckedrecords_scalar_nat_t_clear> owner(&out);
    state.finish(detail::callbackcheckedrecords_callback_e014092ff0a1ee8527eeeb58a78e2de63bdf09fa_lease_call(lease.token, &view0.value, &out));
    auto value = detail::graph_from5(out, 0, true, true, state.budget);
    state.finish(0);
    return value;
  } catch (const detail::GraphConversionError& error) { detail::callable_fail(error.status); }
}
inline Nat graph_invoke4(GraphLease& lease, const Weighted& a0) {
  try {
    detail::GraphCallbackState state;
    detail::graph_check4(a0, 0, true, state.budget);
    detail::GraphView4 view0(a0);
    detail::callbackcheckedrecords_scalar_nat_t out{};
    detail::GraphOwned<detail::callbackcheckedrecords_scalar_nat_t, detail::callbackcheckedrecords_scalar_nat_t_clear> owner(&out);
    state.finish(detail::callbackcheckedrecords_callback_d885a7d82ec894d17b81e7a67a36bc2930adca13_lease_call(lease.token, &view0.value, &out));
    auto value = detail::graph_from5(out, 0, true, true, state.budget);
    state.finish(0);
    return value;
  } catch (const detail::GraphConversionError& error) { detail::callable_fail(error.status); }
}
inline Interval graph_invoke6(GraphLease& lease, const Nat& a0, const Interval& a1) {
  try {
    detail::GraphCallbackState state;
    detail::graph_check5(a0, 0, true, state.budget);
    detail::GraphView5 view0(a0);
    detail::graph_check3(a1, 0, true, state.budget);
    detail::GraphView3 view1(a1);
    detail::callbackcheckedrecords_interval_t out{};
    detail::GraphOwned<detail::callbackcheckedrecords_interval_t, detail::callbackcheckedrecords_interval_t_clear> owner(&out);
    state.finish(detail::callbackcheckedrecords_callback_2e292aebff8c53f6a465ec3d5745e74400590434_lease_call(lease.token, &view0.value, &view1.value, &out));
    auto value = detail::graph_from3(out, 0, true, true, state.budget);
    state.finish(0);
    return value;
  } catch (const detail::GraphConversionError& error) { detail::callable_fail(error.status); }
}
inline Graph38a8689c2f20ead532ea graph_invoke7(GraphLease& lease, const Graph7ee21eb6b8ea120b53f0& a0) {
  try {
    detail::GraphCallbackState state;
    detail::graph_check1(a0, 0, true, state.budget);
    detail::GraphView1 view0(a0);
    detail::callbackcheckedrecords_graph_38a8689c2f20ead532ea_t out{};
    detail::GraphOwned<detail::callbackcheckedrecords_graph_38a8689c2f20ead532ea_t, detail::callbackcheckedrecords_graph_38a8689c2f20ead532ea_t_clear> owner(&out);
    state.finish(detail::callbackcheckedrecords_callback_8994592329ecba032f0abfaa9703e59a57f3c6a1_lease_call(lease.token, &view0.value, &out));
    auto value = detail::graph_from0(out, 0, true, true, state.budget);
    state.finish(0);
    return value;
  } catch (const detail::GraphConversionError& error) { detail::callable_fail(error.status); }
}
}
// Recovery is a typed failure-path value and is never published as a successful callback result.
template<class F, class R> inline auto with_recovery(F&& function, R&& recovery) {
  return detail::GraphRecoveredCallback<std::decay_t<F>, std::decay_t<R>>{std::forward<F>(function), std::forward<R>(recovery)};
}
template<class Function0>
requires (detail::GraphAccepts3<std::remove_reference_t<Function0>>)
inline Nat call_host(Function0&& a0) {
  try {
    detail::GraphCallbackState state;
    detail::graph_check3(detail::graph_recovery(a0), 0, true, state.budget);
    detail::GraphCallback3<std::remove_reference_t<Function0>> callback0(a0, state);
    detail::callbackcheckedrecords_callback_00652748bed3eb7036c9091f570efa39888f5490 view0{decltype(callback0)::invoke, &callback0, &callback0.recovery->value};
    detail::callbackcheckedrecords_scalar_nat_t out{};
    detail::GraphOwned<detail::callbackcheckedrecords_scalar_nat_t, detail::callbackcheckedrecords_scalar_nat_t_clear> owner(&out);
    state.finish(detail::lean_bridge_697151f2fc3cf6b95ff12b69_graph(&view0, &out));
    auto value = detail::graph_from5(out, 0, true, true, state.budget);
    state.finish(0);
    return value;
  } catch (const detail::GraphConversionError& error) { detail::callable_fail(error.status); }
}
template<class Function0>
requires (detail::GraphAccepts0<std::remove_reference_t<Function0>>)
inline Nat call_host_container(Function0&& a0) {
  try {
    detail::GraphCallbackState state;
    detail::graph_check2(detail::graph_recovery(a0), 0, true, state.budget);
    detail::GraphCallback0<std::remove_reference_t<Function0>> callback0(a0, state);
    detail::callbackcheckedrecords_callback_2663a58c7c0e71654db1d87936875f8677e197b2 view0{decltype(callback0)::invoke, &callback0, &callback0.recovery->value};
    detail::callbackcheckedrecords_scalar_nat_t out{};
    detail::GraphOwned<detail::callbackcheckedrecords_scalar_nat_t, detail::callbackcheckedrecords_scalar_nat_t_clear> owner(&out);
    state.finish(detail::lean_bridge_413afe4aaf66162bb3ba3d3c_graph(&view0, &out));
    auto value = detail::graph_from5(out, 0, true, true, state.budget);
    state.finish(0);
    return value;
  } catch (const detail::GraphConversionError& error) { detail::callable_fail(error.status); }
}
template<class Function0>
requires (detail::GraphAccepts1<std::remove_reference_t<Function0>>)
inline Nat call_host_mixed(Function0&& a0) {
  try {
    detail::GraphCallbackState state;
    detail::graph_check3(detail::graph_recovery(a0), 0, true, state.budget);
    detail::GraphCallback1<std::remove_reference_t<Function0>> callback0(a0, state);
    detail::callbackcheckedrecords_callback_526ba4a0f03797057c1f9a17ca435a5a42131510 view0{decltype(callback0)::invoke, &callback0, &callback0.recovery->value};
    detail::callbackcheckedrecords_scalar_nat_t out{};
    detail::GraphOwned<detail::callbackcheckedrecords_scalar_nat_t, detail::callbackcheckedrecords_scalar_nat_t_clear> owner(&out);
    state.finish(detail::lean_bridge_184bfb6b98fb39095f0bfec8_graph(&view0, &out));
    auto value = detail::graph_from5(out, 0, true, true, state.budget);
    state.finish(0);
    return value;
  } catch (const detail::GraphConversionError& error) { detail::callable_fail(error.status); }
}
template<class Function0>
requires (detail::GraphAccepts5<std::remove_reference_t<Function0>>)
inline Nat call_host_nested(Function0&& a0) {
  try {
    detail::GraphCallbackState state;
    detail::graph_check4(detail::graph_recovery(a0), 0, true, state.budget);
    detail::GraphCallback5<std::remove_reference_t<Function0>> callback0(a0, state);
    detail::callbackcheckedrecords_callback_cd01d463066ae86d043223e65eab1640e16b22ab view0{decltype(callback0)::invoke, &callback0, &callback0.recovery->value};
    detail::callbackcheckedrecords_scalar_nat_t out{};
    detail::GraphOwned<detail::callbackcheckedrecords_scalar_nat_t, detail::callbackcheckedrecords_scalar_nat_t_clear> owner(&out);
    state.finish(detail::lean_bridge_f168e18f231fdb7eb1733b0e_graph(&view0, &out));
    auto value = detail::graph_from5(out, 0, true, true, state.budget);
    state.finish(0);
    return value;
  } catch (const detail::GraphConversionError& error) { detail::callable_fail(error.status); }
}
inline LeanClosure<Nat(Interval)> make_closure(const Nat& a0) {
  try {
    detail::GraphCallbackState state;
    auto owned = std::make_shared<detail::GraphLease>(detail::callbackcheckedrecords_callback_e014092ff0a1ee8527eeeb58a78e2de63bdf09fa_lease_dispose);
    detail::graph_check5(a0, 0, true, state.budget);
    detail::GraphView5 view0(a0);
    state.finish(detail::lean_bridge_97d7a19c3e5ee22681017ca9_graph(&view0.value, &owned->token));
    return detail::GraphClosureFactory::make<Nat(Interval)>(std::move(owned), detail::graph_invoke2);
  } catch (const detail::GraphConversionError& error) { detail::callable_fail(error.status); }
}
inline LeanClosure<Graph38a8689c2f20ead532ea(Graph7ee21eb6b8ea120b53f0)> make_container_closure(const Nat& a0) {
  try {
    detail::GraphCallbackState state;
    auto owned = std::make_shared<detail::GraphLease>(detail::callbackcheckedrecords_callback_8994592329ecba032f0abfaa9703e59a57f3c6a1_lease_dispose);
    detail::graph_check5(a0, 0, true, state.budget);
    detail::GraphView5 view0(a0);
    state.finish(detail::lean_bridge_74ed57fc03e7ed555389a3ab_graph(&view0.value, &owned->token));
    return detail::GraphClosureFactory::make<Graph38a8689c2f20ead532ea(Graph7ee21eb6b8ea120b53f0)>(std::move(owned), detail::graph_invoke7);
  } catch (const detail::GraphConversionError& error) { detail::callable_fail(error.status); }
}
inline LeanClosure<Interval(Nat, Interval)> make_mixed_closure(const Nat& a0) {
  try {
    detail::GraphCallbackState state;
    auto owned = std::make_shared<detail::GraphLease>(detail::callbackcheckedrecords_callback_2e292aebff8c53f6a465ec3d5745e74400590434_lease_dispose);
    detail::graph_check5(a0, 0, true, state.budget);
    detail::GraphView5 view0(a0);
    state.finish(detail::lean_bridge_bbabc0c3fa2252f4f7a67708_graph(&view0.value, &owned->token));
    return detail::GraphClosureFactory::make<Interval(Nat, Interval)>(std::move(owned), detail::graph_invoke6);
  } catch (const detail::GraphConversionError& error) { detail::callable_fail(error.status); }
}
inline LeanClosure<Nat(Weighted)> make_nested_closure(const Nat& a0) {
  try {
    detail::GraphCallbackState state;
    auto owned = std::make_shared<detail::GraphLease>(detail::callbackcheckedrecords_callback_d885a7d82ec894d17b81e7a67a36bc2930adca13_lease_dispose);
    detail::graph_check5(a0, 0, true, state.budget);
    detail::GraphView5 view0(a0);
    state.finish(detail::lean_bridge_77496697d09177e0d1ebadfd_graph(&view0.value, &owned->token));
    return detail::GraphClosureFactory::make<Nat(Weighted)>(std::move(owned), detail::graph_invoke4);
  } catch (const detail::GraphConversionError& error) { detail::callable_fail(error.status); }
}
}
