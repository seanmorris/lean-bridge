#ifndef CALLBACKCHECKEDRECORDS_COPIED_GRAPH_STATUS_H
#define CALLBACKCHECKEDRECORDS_COPIED_GRAPH_STATUS_H
#include <stddef.h>
#include <stdint.h>
typedef enum callbackcheckedrecords_status {
  CALLBACKCHECKEDRECORDS_STATUS_OK = 0, CALLBACKCHECKEDRECORDS_STATUS_INVALID_ARGUMENT = 1,
  CALLBACKCHECKEDRECORDS_STATUS_RUNTIME_UNAVAILABLE = 2, CALLBACKCHECKEDRECORDS_STATUS_RUNTIME_REJECTED = 3,
  CALLBACKCHECKEDRECORDS_STATUS_DECLARED_ERROR = 4, CALLBACKCHECKEDRECORDS_STATUS_UNEXPECTED_ERROR = 5
} callbackcheckedrecords_status;
typedef enum callbackcheckedrecords_error_code {
  CALLBACKCHECKEDRECORDS_ERROR_NONE = 0, CALLBACKCHECKEDRECORDS_ERROR_INVALID_ARGUMENT = 1,
  CALLBACKCHECKEDRECORDS_ERROR_RUNTIME_UNAVAILABLE = 2, CALLBACKCHECKEDRECORDS_ERROR_UNEXPECTED = 65535
} callbackcheckedrecords_error_code;
typedef struct callbackcheckedrecords_error { callbackcheckedrecords_error_code code; const char *message; size_t message_length; } callbackcheckedrecords_error;
static inline callbackcheckedrecords_status callbackcheckedrecords_graph_finish(uint32_t status, callbackcheckedrecords_error *error) {
  static const char *const messages[] = {"", "Invalid copied value", "Copied value limit exceeded", "Copied value allocation failed", "Malformed native result", "Lean runtime initialization failed or runtime retired"};
  const char *message = messages[status <= 5 ? status : 4];
  size_t length = 0; while (message[length]) ++length;
  callbackcheckedrecords_status result = status == 0 ? CALLBACKCHECKEDRECORDS_STATUS_OK
    : status <= 2 ? CALLBACKCHECKEDRECORDS_STATUS_INVALID_ARGUMENT : CALLBACKCHECKEDRECORDS_STATUS_UNEXPECTED_ERROR;
  if (error) { error->code = status == 0 ? CALLBACKCHECKEDRECORDS_ERROR_NONE
    : status <= 2 ? CALLBACKCHECKEDRECORDS_ERROR_INVALID_ARGUMENT : CALLBACKCHECKEDRECORDS_ERROR_UNEXPECTED;
    error->message = message; error->message_length = length; }
  return result;
}
#endif
