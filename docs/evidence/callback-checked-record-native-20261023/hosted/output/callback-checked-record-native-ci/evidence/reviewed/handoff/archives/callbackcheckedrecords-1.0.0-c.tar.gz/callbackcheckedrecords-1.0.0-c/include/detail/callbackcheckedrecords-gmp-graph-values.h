#ifndef CALLBACKCHECKEDRECORDS_GMP_GRAPH_VALUES_H
#define CALLBACKCHECKEDRECORDS_GMP_GRAPH_VALUES_H
#include <gmp.h>
#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>
#include <string.h>

/* Inputs borrow pointer/span children. Owning results must not be
   shallow-copied and cleared twice. The two _bridge fields are private.
   Clear/select the root of an owned result, never a borrowed child.
   Do not overwrite initialized GMP storage or inactive branch fields. */
typedef struct callbackcheckedrecords_gmp_graph_38a8689c2f20ead532ea_t callbackcheckedrecords_gmp_graph_38a8689c2f20ead532ea_t;
typedef struct callbackcheckedrecords_gmp_graph_7ee21eb6b8ea120b53f0_t callbackcheckedrecords_gmp_graph_7ee21eb6b8ea120b53f0_t;
typedef struct callbackcheckedrecords_gmp_graph_29468227bdfd05da1480_t callbackcheckedrecords_gmp_graph_29468227bdfd05da1480_t;
typedef struct callbackcheckedrecords_gmp_interval_t callbackcheckedrecords_gmp_interval_t;
typedef struct callbackcheckedrecords_gmp_weighted_t callbackcheckedrecords_gmp_weighted_t;
typedef mpz_t callbackcheckedrecords_gmp_scalar_nat_t;
typedef struct callbackcheckedrecords_gmp_scalar_string_t callbackcheckedrecords_gmp_scalar_string_t;
static inline void callbackcheckedrecords_gmp_scalar_nat_t_init(mpz_ptr value) { if (value) mpz_init(value); }
static inline void callbackcheckedrecords_gmp_scalar_nat_t_clear(mpz_ptr value) { if (value) { mpz_clear(value); mpz_init(value); } }
struct callbackcheckedrecords_gmp_interval_t {
  void *_bridge_owner;
  void (*_bridge_release)(void *owner, void *root);
  callbackcheckedrecords_gmp_scalar_nat_t lo;
  callbackcheckedrecords_gmp_scalar_nat_t hi;
};
static inline void callbackcheckedrecords_gmp_interval_t_init(callbackcheckedrecords_gmp_interval_t *value) {
  if (!value) return;
  memset(value, 0, sizeof(*value));
  callbackcheckedrecords_gmp_scalar_nat_t_init(value->lo);
  callbackcheckedrecords_gmp_scalar_nat_t_init(value->hi);
}
static inline void callbackcheckedrecords_gmp_interval_t_destroy_inline(callbackcheckedrecords_gmp_interval_t *value) {
  (void)value;
  mpz_clear(value->lo);
  mpz_clear(value->hi);
}
static inline void callbackcheckedrecords_gmp_interval_t_dispose(callbackcheckedrecords_gmp_interval_t *value) {
  if (!value) return;
  if (value->_bridge_owner && value->_bridge_release) value->_bridge_release(value->_bridge_owner, value);
  else callbackcheckedrecords_gmp_interval_t_destroy_inline(value);
}
static inline void callbackcheckedrecords_gmp_interval_t_clear(callbackcheckedrecords_gmp_interval_t *value) {
  if (!value) return;
  callbackcheckedrecords_gmp_interval_t_dispose(value);
  callbackcheckedrecords_gmp_interval_t_init(value);
}

struct callbackcheckedrecords_gmp_graph_38a8689c2f20ead532ea_t {
  void *_bridge_owner;
  void (*_bridge_release)(void *owner, void *root);
  uint8_t has_value;
  callbackcheckedrecords_gmp_interval_t value;
};
static inline void callbackcheckedrecords_gmp_graph_38a8689c2f20ead532ea_t_init(callbackcheckedrecords_gmp_graph_38a8689c2f20ead532ea_t *value) {
  if (!value) return;
  memset(value, 0, sizeof(*value));
  callbackcheckedrecords_gmp_interval_t_init(&value->value);
}
static inline void callbackcheckedrecords_gmp_graph_38a8689c2f20ead532ea_t_destroy_inline(callbackcheckedrecords_gmp_graph_38a8689c2f20ead532ea_t *value) {
  (void)value;
  callbackcheckedrecords_gmp_interval_t_dispose(&value->value);
}
static inline void callbackcheckedrecords_gmp_graph_38a8689c2f20ead532ea_t_dispose(callbackcheckedrecords_gmp_graph_38a8689c2f20ead532ea_t *value) {
  if (!value) return;
  if (value->_bridge_owner && value->_bridge_release) value->_bridge_release(value->_bridge_owner, value);
  else callbackcheckedrecords_gmp_graph_38a8689c2f20ead532ea_t_destroy_inline(value);
}
static inline void callbackcheckedrecords_gmp_graph_38a8689c2f20ead532ea_t_clear(callbackcheckedrecords_gmp_graph_38a8689c2f20ead532ea_t *value) {
  if (!value) return;
  callbackcheckedrecords_gmp_graph_38a8689c2f20ead532ea_t_dispose(value);
  callbackcheckedrecords_gmp_graph_38a8689c2f20ead532ea_t_init(value);
}

struct callbackcheckedrecords_gmp_graph_7ee21eb6b8ea120b53f0_t {
  void *_bridge_owner;
  void (*_bridge_release)(void *owner, void *root);
  const callbackcheckedrecords_gmp_graph_38a8689c2f20ead532ea_t *data;
  size_t length;
};
static inline void callbackcheckedrecords_gmp_graph_7ee21eb6b8ea120b53f0_t_init(callbackcheckedrecords_gmp_graph_7ee21eb6b8ea120b53f0_t *value) {
  if (!value) return;
  memset(value, 0, sizeof(*value));
}
static inline void callbackcheckedrecords_gmp_graph_7ee21eb6b8ea120b53f0_t_destroy_inline(callbackcheckedrecords_gmp_graph_7ee21eb6b8ea120b53f0_t *value) {
  (void)value;
}
static inline void callbackcheckedrecords_gmp_graph_7ee21eb6b8ea120b53f0_t_dispose(callbackcheckedrecords_gmp_graph_7ee21eb6b8ea120b53f0_t *value) {
  if (!value) return;
  if (value->_bridge_owner && value->_bridge_release) value->_bridge_release(value->_bridge_owner, value);
  else callbackcheckedrecords_gmp_graph_7ee21eb6b8ea120b53f0_t_destroy_inline(value);
}
static inline void callbackcheckedrecords_gmp_graph_7ee21eb6b8ea120b53f0_t_clear(callbackcheckedrecords_gmp_graph_7ee21eb6b8ea120b53f0_t *value) {
  if (!value) return;
  callbackcheckedrecords_gmp_graph_7ee21eb6b8ea120b53f0_t_dispose(value);
  callbackcheckedrecords_gmp_graph_7ee21eb6b8ea120b53f0_t_init(value);
}

struct callbackcheckedrecords_gmp_scalar_string_t {
  void *_bridge_owner;
  void (*_bridge_release)(void *owner, void *root);
  const char *data;
  size_t length;
};
static inline void callbackcheckedrecords_gmp_scalar_string_t_init(callbackcheckedrecords_gmp_scalar_string_t *value) {
  if (!value) return;
  memset(value, 0, sizeof(*value));
}
static inline void callbackcheckedrecords_gmp_scalar_string_t_destroy_inline(callbackcheckedrecords_gmp_scalar_string_t *value) {
  (void)value;
}
static inline void callbackcheckedrecords_gmp_scalar_string_t_dispose(callbackcheckedrecords_gmp_scalar_string_t *value) {
  if (!value) return;
  if (value->_bridge_owner && value->_bridge_release) value->_bridge_release(value->_bridge_owner, value);
  else callbackcheckedrecords_gmp_scalar_string_t_destroy_inline(value);
}
static inline void callbackcheckedrecords_gmp_scalar_string_t_clear(callbackcheckedrecords_gmp_scalar_string_t *value) {
  if (!value) return;
  callbackcheckedrecords_gmp_scalar_string_t_dispose(value);
  callbackcheckedrecords_gmp_scalar_string_t_init(value);
}

struct callbackcheckedrecords_gmp_graph_29468227bdfd05da1480_t {
  void *_bridge_owner;
  void (*_bridge_release)(void *owner, void *root);
  uint8_t is_ok;
  callbackcheckedrecords_gmp_graph_38a8689c2f20ead532ea_t ok;
  callbackcheckedrecords_gmp_scalar_string_t error;
};
static inline void callbackcheckedrecords_gmp_graph_29468227bdfd05da1480_t_init(callbackcheckedrecords_gmp_graph_29468227bdfd05da1480_t *value) {
  if (!value) return;
  memset(value, 0, sizeof(*value));
  callbackcheckedrecords_gmp_graph_38a8689c2f20ead532ea_t_init(&value->ok);
  callbackcheckedrecords_gmp_scalar_string_t_init(&value->error);
}
static inline void callbackcheckedrecords_gmp_graph_29468227bdfd05da1480_t_destroy_inline(callbackcheckedrecords_gmp_graph_29468227bdfd05da1480_t *value) {
  (void)value;
  callbackcheckedrecords_gmp_graph_38a8689c2f20ead532ea_t_dispose(&value->ok);
  callbackcheckedrecords_gmp_scalar_string_t_dispose(&value->error);
}
static inline void callbackcheckedrecords_gmp_graph_29468227bdfd05da1480_t_dispose(callbackcheckedrecords_gmp_graph_29468227bdfd05da1480_t *value) {
  if (!value) return;
  if (value->_bridge_owner && value->_bridge_release) value->_bridge_release(value->_bridge_owner, value);
  else callbackcheckedrecords_gmp_graph_29468227bdfd05da1480_t_destroy_inline(value);
}
static inline void callbackcheckedrecords_gmp_graph_29468227bdfd05da1480_t_clear(callbackcheckedrecords_gmp_graph_29468227bdfd05da1480_t *value) {
  if (!value) return;
  callbackcheckedrecords_gmp_graph_29468227bdfd05da1480_t_dispose(value);
  callbackcheckedrecords_gmp_graph_29468227bdfd05da1480_t_init(value);
}

struct callbackcheckedrecords_gmp_weighted_t {
  void *_bridge_owner;
  void (*_bridge_release)(void *owner, void *root);
  callbackcheckedrecords_gmp_scalar_nat_t weight;
  callbackcheckedrecords_gmp_scalar_nat_t limit;
};
static inline void callbackcheckedrecords_gmp_weighted_t_init(callbackcheckedrecords_gmp_weighted_t *value) {
  if (!value) return;
  memset(value, 0, sizeof(*value));
  callbackcheckedrecords_gmp_scalar_nat_t_init(value->weight);
  callbackcheckedrecords_gmp_scalar_nat_t_init(value->limit);
}
static inline void callbackcheckedrecords_gmp_weighted_t_destroy_inline(callbackcheckedrecords_gmp_weighted_t *value) {
  (void)value;
  mpz_clear(value->weight);
  mpz_clear(value->limit);
}
static inline void callbackcheckedrecords_gmp_weighted_t_dispose(callbackcheckedrecords_gmp_weighted_t *value) {
  if (!value) return;
  if (value->_bridge_owner && value->_bridge_release) value->_bridge_release(value->_bridge_owner, value);
  else callbackcheckedrecords_gmp_weighted_t_destroy_inline(value);
}
static inline void callbackcheckedrecords_gmp_weighted_t_clear(callbackcheckedrecords_gmp_weighted_t *value) {
  if (!value) return;
  callbackcheckedrecords_gmp_weighted_t_dispose(value);
  callbackcheckedrecords_gmp_weighted_t_init(value);
}


#endif /* CALLBACKCHECKEDRECORDS_GMP_GRAPH_VALUES_H */
