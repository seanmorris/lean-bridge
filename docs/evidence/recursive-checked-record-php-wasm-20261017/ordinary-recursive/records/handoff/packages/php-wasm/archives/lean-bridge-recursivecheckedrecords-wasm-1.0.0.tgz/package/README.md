# recursivecheckedrecords for PHP-Wasm

Import this package's default descriptor and include it in PHP-Wasm's `sharedLibs` array. npm installs the matching Lean runtime dependency. The descriptor registers that runtime once per PHP host and mounts the generated PHP files.

```js
import { PhpNode } from 'php-wasm/PhpNode';
import api from 'lean-bridge-recursivecheckedrecords-wasm';

const php = new PhpNode({ version: '8.4', sharedLibs: [api] });
await php.run(`<?php require '${api.autoload}';`);
```

Call the generated functions in the `LeanRecursivecheckedrecords` PHP namespace. The `compiled/src/Api.php` file contains their typed declarations. Other descriptors can share the same `sharedLibs` list. Conflicting runtime, component and PHP namespace identities are rejected before startup.

For a Composer application, install the companion `lean-bridge-recursivecheckedrecords/wasm:1.0.0` ZIP, mount your application's `vendor` directory into PHP-Wasm, and use the named `extensions` export in `sharedLibs` instead of the default descriptor. Require your normal `vendor/autoload.php`. This export registers the native libraries without preloading a second copy of the PHP files.

For first-call loading, import `{ lazy as api }` from this package and pass `dynamicLibs: [api]` instead. With Composer, use `api.extensions` in `dynamicLibs`. The host loads PHP declarations at startup but fetches the Lean runtime and this component only on its first valid API call. An unused component stays unloaded. Different components may choose different modes; registering the same component in both modes is rejected.

This package uses PHP-Wasm 0.1.0, PHP 8.4.1 and the default host variant in Node or Chromium. Register descriptors before constructing the host. Lazy loading requires `enable_dl=1`; await each host request before starting another. After an extension-loading failure, create a new PHP instance. No compiler, FFI extension or install script is required. The handoff receipt verifies package bytes; the descriptor checks compatibility identities, not downloaded byte integrity.

Records and variant cases are final readonly classes. List and Array use consecutive-key PHP arrays while retaining distinct Lean types. Products use nested two-element arrays. Option uses null for None and Some(value) for Some; Some(null) and nested Some preserve their declared nesting. Except uses Ok(value) or Err(error). Aliases use their target PHP values without extra wrappers. Generated PHPDoc describes nested types. Functions and constructors check exact arity and values in both weak and strict callers.

On this 32-bit host, UInt32, UInt64, Int64, Nat, Int and USize use Brick\Math\BigInteger. ISize is a signed 32-bit PHP int. Unit is null; Char is one UTF-8 Unicode scalar. String preserves UTF-8 and NUL; Bytes::fromString preserves arbitrary bytes. Float values require PHP float; Float32 rounds to binary32. Big integers have a 16384-decimal-digit limit.

Recursive values may share acyclic subvalues; returned values own independent copies. Cycles, malformed branches, unknown subclasses and uninitialized values reject. Each call permits 128 value levels and 262144 visits, with separate 16 MiB PHP, Zend and native-copy accounting limits. These do not measure all PHP overhead or Lean working memory. All arguments validate and convert before first-call extension loading. Output owners are released before PHP reconstruction, including on Zend bailout. Allocation and limit failures recover; malformed native results retire the shared runtime. Previously copied PHP values remain usable.

Generated records, variants, Some/Ok/Err and Bytes provide equals($other) and hashCode(). Comparisons preserve nominal and branch identity, compare NaNs as equal and distinguish signed zero. Readonly properties do not recursively freeze arbitrary payloads. Do not mutate values during a call or while using their hashes as lookup keys. Structured callbacks, closures, resource-containing aggregates and asynchronous values are not admitted by this copied graph profile.



## Checked refinements

Lean Fin n parameters and results are Brick\Math\BigInteger values below n. The PHP-Wasm side module compares each argument with its exact bound, including bounds wider than 64 bits, before any Lean code runs; a value at or above its bound throws LeanBridgeError with code 1 whose message names the Lean parameter and bound. Fin 0 has no values, so every call to a function taking one is rejected. Results are BigInteger values below their declared bound. Fin inside arrays, lists and options is checked element by element before Lean runs; an empty array or an absent option is valid even for Fin 0. Bounds below list every element as name[*] and a present option value as name?. Fin inside callbacks or generic record instantiations is not supported in PHP-Wasm packages.

Lean Subtype parameters cross as their base value. The PHP-Wasm side module runs the author's checked constructor, named below, before the export runs; a value the constructor rejects fails the call with the invalid-argument error naming the parameter and constructor, and the export receives the constructed value, which may differ from the input. Arrays, Lists, options, products and active result branches apply the same constructor checks to each Subtype leaf. Rejections identify the argument and nested element path. Subtype results are the base value. Reviewed APIs select the constructor and reconcile it with fresh Lean compilation. Copied plain records check each selected field; variants check only the active case. Repeated uses of one type retain their own constructor choices, and every Fin bound is checked before any constructor. Recursive fields and active cases repeat those checks at every reachable occurrence; a rejection names the actual field or case path. Generic, owned and callback Subtype positions remain unsupported.

Checked records cross as generated record values containing only their payload fields. The bundled native library validates each input through the constructor selected for that exact occurrence before calling the export. Nested arrays, Lists, options, products, Except values, plain records and active variant cases retain their own checked-record constructors. Fin and Subtype payload fields run their checks before the outer record constructor. A rejection names the argument, nested path and failing constructor or bound. A normalizing constructor changes the copied value received by Lean without changing the caller's record. Results recursively project the payload fields and refined base values of records whose proofs Lean has already constructed. No proof object or input constructor is needed for a result-only export. Ordinary and reviewed APIs retain every per-occurrence constructor choice. Recursive, generic, owned and callback checked-record positions remain unsupported.

- LeanRecursivecheckedrecords\echo_: $arg0 checked by RecursiveCheckedRecords.mkPacket; $arg0.value checked by RecursiveCheckedRecords.plusOne; $arg0.digit < 3; result projects proof-backed record payload fields; result.value projects the Subtype base value; result.digit < 3
- LeanRecursivecheckedrecords\echo_groups: $arg0[*]? checked by RecursiveCheckedRecords.normalizePacket; $arg0[*]?.value checked by RecursiveCheckedRecords.plusTwo; $arg0[*]?.digit < 3; result[*]? projects proof-backed record payload fields; result[*]?.value projects the Subtype base value; result[*]?.digit < 3
- LeanRecursivecheckedrecords\first: $arg0 checked by RecursiveCheckedRecords.mkPacket; $arg0.value checked by RecursiveCheckedRecords.plusOne; $arg0.digit < 3
- LeanRecursivecheckedrecords\groups: $arg0[*]? checked by RecursiveCheckedRecords.mkPacket; $arg0[*]?.value checked by RecursiveCheckedRecords.plusOne; $arg0[*]?.digit < 3
- LeanRecursivecheckedrecords\produce: result projects proof-backed record payload fields; result.value projects the Subtype base value; result.digit < 3
- LeanRecursivecheckedrecords\second: $arg0 checked by RecursiveCheckedRecords.normalizePacket; $arg0.value checked by RecursiveCheckedRecords.plusTwo; $arg0.digit < 3
