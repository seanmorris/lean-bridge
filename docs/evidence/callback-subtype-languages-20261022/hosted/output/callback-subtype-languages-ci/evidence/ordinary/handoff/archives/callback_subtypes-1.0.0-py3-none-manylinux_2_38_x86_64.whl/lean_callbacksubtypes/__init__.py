from __future__ import annotations
from dataclasses import dataclass as _dataclass
from typing import ClassVar as _ClassVar, Literal as _Literal, TypeAlias as _TypeAlias

try:
    from typing import TypeAliasType as _TypeAliasType
except ImportError:
    from typing_extensions import TypeAliasType as _TypeAliasType

__all__ = ("LeanBridgeError", "LeanClosure", "WithRecovery", "with_recovery", "Some", "Option", "Ok", "Err", "Result", "Callback0cd085da803af7102cc3", "Callback0f78910188dae34fd8b0", "Callback2ad56570215cca826b8e", "Callback34f6a3c1043662b01ed6", "Callbackc2ff96fa00e1ff712eba", "Callbacke84eef4c26bca64196e6", "call_host", "call_host_container", "call_host_mixed", "make_closure", "make_container_closure", "make_mixed_closure",)

from typing import Generic as _Generic, TypeVar as _TypeVar

_T = _TypeVar("_T", covariant=True)
_E = _TypeVar("_E", covariant=True)

@_dataclass(frozen=True)
class Some(_Generic[_T]):
    value: _T

@_dataclass(frozen=True)
class Ok(_Generic[_T]):
    value: _T

@_dataclass(frozen=True)
class Err(_Generic[_E]):
    value: _E

Option = Some[_T] | None

Result = Ok[_T] | Err[_E]

_Value0 = _TypeAliasType("_Value0", Option[int])
_Input0 = _TypeAliasType("_Input0", Option[int])
_Value1 = _TypeAliasType("_Value1", Result[_Value0, str])
_Input1 = _TypeAliasType("_Input1", Result[_Input0, str])
_Value2 = _TypeAliasType("_Value2", tuple[_Value0, ...])
_Input2 = _TypeAliasType("_Input2", tuple[_Input0, ...] | list[_Input0])

class LeanBridgeError(RuntimeError):
    status: int
    def __init__(self, status: int, message: str):
        super().__init__(message)
        self.status = status

from typing import Never as _Never
from typing import Callable as _Callable, Generic as _Generic, ParamSpec as _ParamSpec, TypeVar as _TypeVar
from types import TracebackType as _TracebackType

_P = _ParamSpec("_P")
_R = _TypeVar("_R")

class LeanClosure(_Generic[_P, _R]):
    """A same-thread Lean callable. Use with or close() to release it."""
    __slots__ = ("_lease", "__weakref__")

    def __init__(self) -> None:
        raise TypeError("Lean closures are returned by generated functions")

    def __call__(self, *args: _P.args, **kwargs: _P.kwargs) -> _R:
        return self._lease(*args, **kwargs)

    @property
    def closed(self) -> bool:
        return self._lease.closed

    def close(self) -> None:
        self._lease.close()

    def __enter__(self) -> LeanClosure[_P, _R]:
        self._lease.ensure_open()
        return self

    def __exit__(self, exc_type: type[BaseException] | None, exc: BaseException | None, traceback: _TracebackType | None) -> None:
        self.close()

    def __copy__(self) -> _Never:
        raise TypeError("Lean closures cannot be copied")

    def __deepcopy__(self, memo: dict[int, object]) -> _Never:
        raise TypeError("Lean closures cannot be copied")

    def __reduce__(self) -> _Never:
        raise TypeError("Lean closures cannot be serialized")


@_dataclass(frozen=True, slots=True)
class WithRecovery(_Generic[_P, _R]):
    function: _Callable[_P, _R]
    recovery: _R

def with_recovery(function: _Callable[_P, _R], recovery: _R) -> WithRecovery[_P, _R]:
    return WithRecovery(function, recovery)

Callback0cd085da803af7102cc3: _TypeAlias = WithRecovery[[_Value0], _Input1]
Callback0f78910188dae34fd8b0: _TypeAlias = _Callable[[int], int]
Callback2ad56570215cca826b8e: _TypeAlias = WithRecovery[[int, int], int]
Callback34f6a3c1043662b01ed6: _TypeAlias = _Callable[[int, int], int]
Callbackc2ff96fa00e1ff712eba: _TypeAlias = _Callable[[_Value2], _Input0]
Callbacke84eef4c26bca64196e6: _TypeAlias = WithRecovery[[int], int]

def call_host(arg0: Callbacke84eef4c26bca64196e6) -> int:
    return _GraphNative._call0(arg0)

def call_host_container(arg0: Callback0cd085da803af7102cc3) -> _Value1:
    return _GraphNative._call1(arg0)

def call_host_mixed(arg0: Callback2ad56570215cca826b8e) -> int:
    return _GraphNative._call2(arg0)

def make_closure(arg0: int) -> LeanClosure[[int], int]:
    return _GraphNative._call3(arg0)

def make_container_closure(arg0: int) -> LeanClosure[[_Input2], _Value0]:
    return _GraphNative._call4(arg0)

def make_mixed_closure(arg0: int) -> LeanClosure[[int, int], int]:
    return _GraphNative._call5(arg0)

from . import _native as _GraphNative
