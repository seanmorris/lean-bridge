#ifndef CALLBACKSUBTYPES_GMP_GRAPH_VALUES_H
#define CALLBACKSUBTYPES_GMP_GRAPH_VALUES_H
#include <gmp.h>
#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>
#include <string.h>

/* Inputs borrow pointer/span children. Owning results must not be
   shallow-copied and cleared twice. The two _bridge fields are private.
   Clear/select the root of an owned result, never a borrowed child.
   Do not overwrite initialized GMP storage or inactive branch fields. */
typedef struct callbacksubtypes_gmp_graph_743764d1b67e81fcae92_t callbacksubtypes_gmp_graph_743764d1b67e81fcae92_t;
typedef struct callbacksubtypes_gmp_graph_2c6f4131c8731fa67588_t callbacksubtypes_gmp_graph_2c6f4131c8731fa67588_t;
typedef struct callbacksubtypes_gmp_graph_6c9c0cf3d3abf9adeb4b_t callbacksubtypes_gmp_graph_6c9c0cf3d3abf9adeb4b_t;
typedef mpz_t callbacksubtypes_gmp_scalar_nat_t;
typedef struct callbacksubtypes_gmp_scalar_string_t callbacksubtypes_gmp_scalar_string_t;
static inline void callbacksubtypes_gmp_scalar_nat_t_init(mpz_ptr value) { if (value) mpz_init(value); }
static inline void callbacksubtypes_gmp_scalar_nat_t_clear(mpz_ptr value) { if (value) { mpz_clear(value); mpz_init(value); } }
struct callbacksubtypes_gmp_graph_743764d1b67e81fcae92_t {
  void *_bridge_owner;
  void (*_bridge_release)(void *owner, void *root);
  uint8_t has_value;
  callbacksubtypes_gmp_scalar_nat_t value;
};
static inline void callbacksubtypes_gmp_graph_743764d1b67e81fcae92_t_init(callbacksubtypes_gmp_graph_743764d1b67e81fcae92_t *value) {
  if (!value) return;
  memset(value, 0, sizeof(*value));
  callbacksubtypes_gmp_scalar_nat_t_init(value->value);
}
static inline void callbacksubtypes_gmp_graph_743764d1b67e81fcae92_t_destroy_inline(callbacksubtypes_gmp_graph_743764d1b67e81fcae92_t *value) {
  (void)value;
  mpz_clear(value->value);
}
static inline void callbacksubtypes_gmp_graph_743764d1b67e81fcae92_t_dispose(callbacksubtypes_gmp_graph_743764d1b67e81fcae92_t *value) {
  if (!value) return;
  if (value->_bridge_owner && value->_bridge_release) value->_bridge_release(value->_bridge_owner, value);
  else callbacksubtypes_gmp_graph_743764d1b67e81fcae92_t_destroy_inline(value);
}
static inline void callbacksubtypes_gmp_graph_743764d1b67e81fcae92_t_clear(callbacksubtypes_gmp_graph_743764d1b67e81fcae92_t *value) {
  if (!value) return;
  callbacksubtypes_gmp_graph_743764d1b67e81fcae92_t_dispose(value);
  callbacksubtypes_gmp_graph_743764d1b67e81fcae92_t_init(value);
}

struct callbacksubtypes_gmp_scalar_string_t {
  void *_bridge_owner;
  void (*_bridge_release)(void *owner, void *root);
  const char *data;
  size_t length;
};
static inline void callbacksubtypes_gmp_scalar_string_t_init(callbacksubtypes_gmp_scalar_string_t *value) {
  if (!value) return;
  memset(value, 0, sizeof(*value));
}
static inline void callbacksubtypes_gmp_scalar_string_t_destroy_inline(callbacksubtypes_gmp_scalar_string_t *value) {
  (void)value;
}
static inline void callbacksubtypes_gmp_scalar_string_t_dispose(callbacksubtypes_gmp_scalar_string_t *value) {
  if (!value) return;
  if (value->_bridge_owner && value->_bridge_release) value->_bridge_release(value->_bridge_owner, value);
  else callbacksubtypes_gmp_scalar_string_t_destroy_inline(value);
}
static inline void callbacksubtypes_gmp_scalar_string_t_clear(callbacksubtypes_gmp_scalar_string_t *value) {
  if (!value) return;
  callbacksubtypes_gmp_scalar_string_t_dispose(value);
  callbacksubtypes_gmp_scalar_string_t_init(value);
}

struct callbacksubtypes_gmp_graph_2c6f4131c8731fa67588_t {
  void *_bridge_owner;
  void (*_bridge_release)(void *owner, void *root);
  uint8_t is_ok;
  callbacksubtypes_gmp_graph_743764d1b67e81fcae92_t ok;
  callbacksubtypes_gmp_scalar_string_t error;
};
static inline void callbacksubtypes_gmp_graph_2c6f4131c8731fa67588_t_init(callbacksubtypes_gmp_graph_2c6f4131c8731fa67588_t *value) {
  if (!value) return;
  memset(value, 0, sizeof(*value));
  callbacksubtypes_gmp_graph_743764d1b67e81fcae92_t_init(&value->ok);
  callbacksubtypes_gmp_scalar_string_t_init(&value->error);
}
static inline void callbacksubtypes_gmp_graph_2c6f4131c8731fa67588_t_destroy_inline(callbacksubtypes_gmp_graph_2c6f4131c8731fa67588_t *value) {
  (void)value;
  callbacksubtypes_gmp_graph_743764d1b67e81fcae92_t_dispose(&value->ok);
  callbacksubtypes_gmp_scalar_string_t_dispose(&value->error);
}
static inline void callbacksubtypes_gmp_graph_2c6f4131c8731fa67588_t_dispose(callbacksubtypes_gmp_graph_2c6f4131c8731fa67588_t *value) {
  if (!value) return;
  if (value->_bridge_owner && value->_bridge_release) value->_bridge_release(value->_bridge_owner, value);
  else callbacksubtypes_gmp_graph_2c6f4131c8731fa67588_t_destroy_inline(value);
}
static inline void callbacksubtypes_gmp_graph_2c6f4131c8731fa67588_t_clear(callbacksubtypes_gmp_graph_2c6f4131c8731fa67588_t *value) {
  if (!value) return;
  callbacksubtypes_gmp_graph_2c6f4131c8731fa67588_t_dispose(value);
  callbacksubtypes_gmp_graph_2c6f4131c8731fa67588_t_init(value);
}

struct callbacksubtypes_gmp_graph_6c9c0cf3d3abf9adeb4b_t {
  void *_bridge_owner;
  void (*_bridge_release)(void *owner, void *root);
  const callbacksubtypes_gmp_graph_743764d1b67e81fcae92_t *data;
  size_t length;
};
static inline void callbacksubtypes_gmp_graph_6c9c0cf3d3abf9adeb4b_t_init(callbacksubtypes_gmp_graph_6c9c0cf3d3abf9adeb4b_t *value) {
  if (!value) return;
  memset(value, 0, sizeof(*value));
}
static inline void callbacksubtypes_gmp_graph_6c9c0cf3d3abf9adeb4b_t_destroy_inline(callbacksubtypes_gmp_graph_6c9c0cf3d3abf9adeb4b_t *value) {
  (void)value;
}
static inline void callbacksubtypes_gmp_graph_6c9c0cf3d3abf9adeb4b_t_dispose(callbacksubtypes_gmp_graph_6c9c0cf3d3abf9adeb4b_t *value) {
  if (!value) return;
  if (value->_bridge_owner && value->_bridge_release) value->_bridge_release(value->_bridge_owner, value);
  else callbacksubtypes_gmp_graph_6c9c0cf3d3abf9adeb4b_t_destroy_inline(value);
}
static inline void callbacksubtypes_gmp_graph_6c9c0cf3d3abf9adeb4b_t_clear(callbacksubtypes_gmp_graph_6c9c0cf3d3abf9adeb4b_t *value) {
  if (!value) return;
  callbacksubtypes_gmp_graph_6c9c0cf3d3abf9adeb4b_t_dispose(value);
  callbacksubtypes_gmp_graph_6c9c0cf3d3abf9adeb4b_t_init(value);
}


#endif /* CALLBACKSUBTYPES_GMP_GRAPH_VALUES_H */
