#pragma once
#include "detail/callbacksubtypes-status.h"
#include <stdbool.h>
#include <string.h>
namespace lean_bridge::callbacksubtypes::detail {
struct callbacksubtypes_graph_743764d1b67e81fcae92_t;
struct callbacksubtypes_graph_2c6f4131c8731fa67588_t;
struct callbacksubtypes_graph_6c9c0cf3d3abf9adeb4b_t;
struct callbacksubtypes_scalar_nat_t;
struct callbacksubtypes_scalar_string_t;
#include "detail/callbacksubtypes-graph.h"
}
#include "detail/callbacksubtypes-conversions.hpp"
#include <concepts>
#include <exception>
#include <functional>
#include <unistd.h>
namespace lean_bridge::callbacksubtypes {

class Error final : public std::runtime_error {
public:
  callbacksubtypes_status status; callbacksubtypes_error_code code;
  Error(callbacksubtypes_status status, const callbacksubtypes_error& error)
    : std::runtime_error(error.message ? std::string(error.message, error.message_length) : "Lean call failed"), status(status), code(error.code) {}
};
namespace detail {
[[noreturn]] inline void callable_fail(uint32_t status) {
  if (status == 4) callbacksubtypes_graph_retire();
  if (status == 10) {
    static constexpr char message[] = "Host callback result failed its Lean constructor";
    callbacksubtypes_error error{CALLBACKSUBTYPES_ERROR_INVALID_ARGUMENT, message, sizeof(message) - 1};
    throw Error(CALLBACKSUBTYPES_STATUS_INVALID_ARGUMENT, error);
  }
  callbacksubtypes_error error{}; auto code = callbacksubtypes_graph_finish(status, &error);
  if (status == 6) { code = CALLBACKSUBTYPES_STATUS_DECLARED_ERROR; error = {CALLBACKSUBTYPES_ERROR_UNEXPECTED, "Host callback failed", 20}; }
  throw Error(code, error);
}
inline const std::shared_ptr<const char>& callable_thread() {
  static thread_local const auto value = std::make_shared<const char>(); return value;
}
struct GraphLease {
  uint64_t token = 0;
  void (*dispose)(uint64_t);
  const pid_t process = ::getpid();
  const std::shared_ptr<const char> thread = callable_thread();
  bool closed = false;
  explicit GraphLease(void (*release)(uint64_t)) : dispose(release) {}
  ~GraphLease() { if (process == ::getpid() && token) dispose(token); }
  void require() const {
    if (process != ::getpid() || thread != callable_thread() || closed || !token) callable_fail(1);
  }
  void close() {
    if (process != ::getpid() || thread != callable_thread()) callable_fail(1);
    closed = true; uint64_t previous = std::exchange(token, 0); if (previous) dispose(previous);
  }
};
struct GraphCallbackState {
  GraphBudget budget;
  std::exception_ptr failure;
  void finish(uint32_t status) const {
    if (failure) std::rethrow_exception(failure);
    if (status) callable_fail(status);
    if (!callbacksubtypes_graph_ready()) callable_fail(5);
  }
};
template<class F, class R> struct GraphRecoveredCallback { F function; R recovery; };
template<class F> constexpr bool graph_has_recovery = false;
template<class F, class R> constexpr bool graph_has_recovery<GraphRecoveredCallback<F, R>> = true;
template<class F, class Expected> constexpr bool graph_recovery_matches = false;
template<class F, class R, class Expected> constexpr bool graph_recovery_matches<GraphRecoveredCallback<F, R>, Expected> = std::same_as<R, Expected>;
template<class F> inline F& graph_function(F& function) { return function; }
template<class F, class R> inline F& graph_function(GraphRecoveredCallback<F, R>& function) { return function.function; }
template<class F, class R> inline const R& graph_recovery(const GraphRecoveredCallback<F, R>& function) { return function.recovery; }
struct GraphClosureFactory;
}
template<class Signature> class LeanClosure;
template<class Result, class... Args> class LeanClosure<Result(Args...)> final {
  std::shared_ptr<detail::GraphLease> lease_;
  Result (*invoke_)(detail::GraphLease&, const Args&...);
  LeanClosure(std::shared_ptr<detail::GraphLease> lease, Result (*invoke)(detail::GraphLease&, const Args&...)) noexcept
    : lease_(std::move(lease)), invoke_(invoke) {}
  friend struct detail::GraphClosureFactory;
public:
  LeanClosure(const LeanClosure&) = delete;
  LeanClosure& operator=(const LeanClosure&) = delete;
  LeanClosure(LeanClosure&&) noexcept = default;
  LeanClosure& operator=(LeanClosure&&) noexcept = default;
  Result call(const Args&... args) const {
    auto active = lease_; if (!active) detail::callable_fail(1); active->require();
    return invoke_(*active, args...);
  }
  Result operator()(const Args&... args) const { return call(args...); }
  void close() const { if (lease_) lease_->close(); }
  bool is_closed() const noexcept { return !lease_ || lease_->closed; }
};
namespace detail {
struct GraphClosureFactory {
  template<class Signature, class Invoke> static LeanClosure<Signature> make(std::shared_ptr<GraphLease> lease, Invoke invoke) noexcept {
    return LeanClosure<Signature>(std::move(lease), invoke);
  }
};

template<class Function> concept GraphAccepts0 = graph_recovery_matches<std::remove_cvref_t<Function>, Graph2c6f4131c8731fa67588> && requires(Function& function, const Graph743764d1b67e81fcae92& a0) {
	  { std::invoke(graph_function(function), a0) } -> std::same_as<Graph2c6f4131c8731fa67588>;
};
template<class Function> struct GraphCallback0 {
  Function& function; GraphCallbackState& state;
  std::unique_ptr<GraphView1> recovery;
  GraphCallback0(Function& input, GraphCallbackState& shared) : function(input), state(shared), recovery(std::make_unique<GraphView1>(graph_recovery(input))) {}
  struct Reply {
    Graph2c6f4131c8731fa67588 data; GraphView1 view;
    explicit Reply(Graph2c6f4131c8731fa67588 input) : data(std::move(input)), view(data) {}
    static void release(void *owner) noexcept { delete static_cast<Reply*>(owner); }
  };
  static uint32_t invoke(void *context, const callbacksubtypes_graph_743764d1b67e81fcae92_t *a0, callbacksubtypes_graph_2c6f4131c8731fa67588_t *out) noexcept {
    auto& self = *static_cast<GraphCallback0*>(context);
    if (self.state.failure) return 6;
    try {
	  Graph2c6f4131c8731fa67588 returned = std::invoke(graph_function(self.function), graph_from0(graph_read(a0), 0, true, true, self.state.budget));
      graph_check1(returned, 0, true, self.state.budget);
      auto owner = std::make_unique<Reply>(std::move(returned));
      *out = owner->view.value; out->_bridge_owner = owner.release(); out->_bridge_release = Reply::release;
      return 0;
    } catch (const GraphConversionError& error) {
      try { callable_fail(error.status); } catch (...) { if (!self.state.failure) self.state.failure = std::current_exception(); }
    } catch (...) { if (!self.state.failure) self.state.failure = std::current_exception(); }
    return 6;
  }
};
template<class Function> concept GraphAccepts1 = requires(Function& function, const Nat& a0) {
	  { std::invoke(graph_function(function), a0) } -> std::same_as<Nat>;
};
template<class Function> struct GraphCallback1 {
  Function& function; GraphCallbackState& state;
  GraphCallback1(Function& input, GraphCallbackState& shared) : function(input), state(shared) {}
  struct Reply {
    Nat data; GraphView3 view;
    explicit Reply(Nat input) : data(std::move(input)), view(data) {}
    static void release(void *owner) noexcept { delete static_cast<Reply*>(owner); }
  };
  static uint32_t invoke(void *context, const callbacksubtypes_scalar_nat_t *a0, callbacksubtypes_scalar_nat_t *out) noexcept {
    auto& self = *static_cast<GraphCallback1*>(context);
    if (self.state.failure) return 6;
    try {
	  Nat returned = std::invoke(graph_function(self.function), graph_from3(graph_read(a0), 0, true, true, self.state.budget));
      graph_check3(returned, 0, true, self.state.budget);
      auto owner = std::make_unique<Reply>(std::move(returned));
      *out = owner->view.value; out->_bridge_owner = owner.release(); out->_bridge_release = Reply::release;
      return 0;
    } catch (const GraphConversionError& error) {
      try { callable_fail(error.status); } catch (...) { if (!self.state.failure) self.state.failure = std::current_exception(); }
    } catch (...) { if (!self.state.failure) self.state.failure = std::current_exception(); }
    return 6;
  }
};
template<class Function> concept GraphAccepts2 = graph_recovery_matches<std::remove_cvref_t<Function>, Nat> && requires(Function& function, const Nat& a0, const Nat& a1) {
	  { std::invoke(graph_function(function), a0, a1) } -> std::same_as<Nat>;
};
template<class Function> struct GraphCallback2 {
  Function& function; GraphCallbackState& state;
  std::unique_ptr<GraphView3> recovery;
  GraphCallback2(Function& input, GraphCallbackState& shared) : function(input), state(shared), recovery(std::make_unique<GraphView3>(graph_recovery(input))) {}
  struct Reply {
    Nat data; GraphView3 view;
    explicit Reply(Nat input) : data(std::move(input)), view(data) {}
    static void release(void *owner) noexcept { delete static_cast<Reply*>(owner); }
  };
  static uint32_t invoke(void *context, const callbacksubtypes_scalar_nat_t *a0, const callbacksubtypes_scalar_nat_t *a1, callbacksubtypes_scalar_nat_t *out) noexcept {
    auto& self = *static_cast<GraphCallback2*>(context);
    if (self.state.failure) return 6;
    try {
	  Nat returned = std::invoke(graph_function(self.function), graph_from3(graph_read(a0), 0, true, true, self.state.budget), graph_from3(graph_read(a1), 0, true, true, self.state.budget));
      graph_check3(returned, 0, true, self.state.budget);
      auto owner = std::make_unique<Reply>(std::move(returned));
      *out = owner->view.value; out->_bridge_owner = owner.release(); out->_bridge_release = Reply::release;
      return 0;
    } catch (const GraphConversionError& error) {
      try { callable_fail(error.status); } catch (...) { if (!self.state.failure) self.state.failure = std::current_exception(); }
    } catch (...) { if (!self.state.failure) self.state.failure = std::current_exception(); }
    return 6;
  }
};
template<class Function> concept GraphAccepts3 = requires(Function& function, const Nat& a0, const Nat& a1) {
	  { std::invoke(graph_function(function), a0, a1) } -> std::same_as<Nat>;
};
template<class Function> struct GraphCallback3 {
  Function& function; GraphCallbackState& state;
  GraphCallback3(Function& input, GraphCallbackState& shared) : function(input), state(shared) {}
  struct Reply {
    Nat data; GraphView3 view;
    explicit Reply(Nat input) : data(std::move(input)), view(data) {}
    static void release(void *owner) noexcept { delete static_cast<Reply*>(owner); }
  };
  static uint32_t invoke(void *context, const callbacksubtypes_scalar_nat_t *a0, const callbacksubtypes_scalar_nat_t *a1, callbacksubtypes_scalar_nat_t *out) noexcept {
    auto& self = *static_cast<GraphCallback3*>(context);
    if (self.state.failure) return 6;
    try {
	  Nat returned = std::invoke(graph_function(self.function), graph_from3(graph_read(a0), 0, true, true, self.state.budget), graph_from3(graph_read(a1), 0, true, true, self.state.budget));
      graph_check3(returned, 0, true, self.state.budget);
      auto owner = std::make_unique<Reply>(std::move(returned));
      *out = owner->view.value; out->_bridge_owner = owner.release(); out->_bridge_release = Reply::release;
      return 0;
    } catch (const GraphConversionError& error) {
      try { callable_fail(error.status); } catch (...) { if (!self.state.failure) self.state.failure = std::current_exception(); }
    } catch (...) { if (!self.state.failure) self.state.failure = std::current_exception(); }
    return 6;
  }
};
template<class Function> concept GraphAccepts4 = requires(Function& function, const Graph6c9c0cf3d3abf9adeb4b& a0) {
	  { std::invoke(graph_function(function), a0) } -> std::same_as<Graph743764d1b67e81fcae92>;
};
template<class Function> struct GraphCallback4 {
  Function& function; GraphCallbackState& state;
  GraphCallback4(Function& input, GraphCallbackState& shared) : function(input), state(shared) {}
  struct Reply {
    Graph743764d1b67e81fcae92 data; GraphView0 view;
    explicit Reply(Graph743764d1b67e81fcae92 input) : data(std::move(input)), view(data) {}
    static void release(void *owner) noexcept { delete static_cast<Reply*>(owner); }
  };
  static uint32_t invoke(void *context, const callbacksubtypes_graph_6c9c0cf3d3abf9adeb4b_t *a0, callbacksubtypes_graph_743764d1b67e81fcae92_t *out) noexcept {
    auto& self = *static_cast<GraphCallback4*>(context);
    if (self.state.failure) return 6;
    try {
	  Graph743764d1b67e81fcae92 returned = std::invoke(graph_function(self.function), graph_from2(graph_read(a0), 0, true, true, self.state.budget));
      graph_check0(returned, 0, true, self.state.budget);
      auto owner = std::make_unique<Reply>(std::move(returned));
      *out = owner->view.value; out->_bridge_owner = owner.release(); out->_bridge_release = Reply::release;
      return 0;
    } catch (const GraphConversionError& error) {
      try { callable_fail(error.status); } catch (...) { if (!self.state.failure) self.state.failure = std::current_exception(); }
    } catch (...) { if (!self.state.failure) self.state.failure = std::current_exception(); }
    return 6;
  }
};
template<class Function> concept GraphAccepts5 = graph_recovery_matches<std::remove_cvref_t<Function>, Nat> && requires(Function& function, const Nat& a0) {
	  { std::invoke(graph_function(function), a0) } -> std::same_as<Nat>;
};
template<class Function> struct GraphCallback5 {
  Function& function; GraphCallbackState& state;
  std::unique_ptr<GraphView3> recovery;
  GraphCallback5(Function& input, GraphCallbackState& shared) : function(input), state(shared), recovery(std::make_unique<GraphView3>(graph_recovery(input))) {}
  struct Reply {
    Nat data; GraphView3 view;
    explicit Reply(Nat input) : data(std::move(input)), view(data) {}
    static void release(void *owner) noexcept { delete static_cast<Reply*>(owner); }
  };
  static uint32_t invoke(void *context, const callbacksubtypes_scalar_nat_t *a0, callbacksubtypes_scalar_nat_t *out) noexcept {
    auto& self = *static_cast<GraphCallback5*>(context);
    if (self.state.failure) return 6;
    try {
	  Nat returned = std::invoke(graph_function(self.function), graph_from3(graph_read(a0), 0, true, true, self.state.budget));
      graph_check3(returned, 0, true, self.state.budget);
      auto owner = std::make_unique<Reply>(std::move(returned));
      *out = owner->view.value; out->_bridge_owner = owner.release(); out->_bridge_release = Reply::release;
      return 0;
    } catch (const GraphConversionError& error) {
      try { callable_fail(error.status); } catch (...) { if (!self.state.failure) self.state.failure = std::current_exception(); }
    } catch (...) { if (!self.state.failure) self.state.failure = std::current_exception(); }
    return 6;
  }
};
inline Nat graph_invoke1(GraphLease& lease, const Nat& a0) {
  try {
    detail::GraphCallbackState state;
    detail::graph_check3(a0, 0, true, state.budget);
    detail::GraphView3 view0(a0);
    detail::callbacksubtypes_scalar_nat_t out{};
    detail::GraphOwned<detail::callbacksubtypes_scalar_nat_t, detail::callbacksubtypes_scalar_nat_t_clear> owner(&out);
    state.finish(detail::callbacksubtypes_callback_c27fa7df7f1805196544d398fb121b21c179beb1_lease_call(lease.token, &view0.value, &out));
    auto value = detail::graph_from3(out, 0, true, true, state.budget);
    state.finish(0);
    return value;
  } catch (const detail::GraphConversionError& error) { detail::callable_fail(error.status); }
}
inline Nat graph_invoke3(GraphLease& lease, const Nat& a0, const Nat& a1) {
  try {
    detail::GraphCallbackState state;
    detail::graph_check3(a0, 0, true, state.budget);
    detail::GraphView3 view0(a0);
    detail::graph_check3(a1, 0, true, state.budget);
    detail::GraphView3 view1(a1);
    detail::callbacksubtypes_scalar_nat_t out{};
    detail::GraphOwned<detail::callbacksubtypes_scalar_nat_t, detail::callbacksubtypes_scalar_nat_t_clear> owner(&out);
    state.finish(detail::callbacksubtypes_callback_51bfd752726fcfd8a9187a7c3a979ace51f7c1be_lease_call(lease.token, &view0.value, &view1.value, &out));
    auto value = detail::graph_from3(out, 0, true, true, state.budget);
    state.finish(0);
    return value;
  } catch (const detail::GraphConversionError& error) { detail::callable_fail(error.status); }
}
inline Graph743764d1b67e81fcae92 graph_invoke4(GraphLease& lease, const Graph6c9c0cf3d3abf9adeb4b& a0) {
  try {
    detail::GraphCallbackState state;
    detail::graph_check2(a0, 0, true, state.budget);
    detail::GraphView2 view0(a0);
    detail::callbacksubtypes_graph_743764d1b67e81fcae92_t out{};
    detail::GraphOwned<detail::callbacksubtypes_graph_743764d1b67e81fcae92_t, detail::callbacksubtypes_graph_743764d1b67e81fcae92_t_clear> owner(&out);
    state.finish(detail::callbacksubtypes_callback_6cdd9c3be7604978d190e4f9d3a70db0539487ba_lease_call(lease.token, &view0.value, &out));
    auto value = detail::graph_from0(out, 0, true, true, state.budget);
    state.finish(0);
    return value;
  } catch (const detail::GraphConversionError& error) { detail::callable_fail(error.status); }
}
}
// Recovery is a typed failure-path value and is never published as a successful callback result.
template<class F, class R> inline auto with_recovery(F&& function, R&& recovery) {
  return detail::GraphRecoveredCallback<std::decay_t<F>, std::decay_t<R>>{std::forward<F>(function), std::forward<R>(recovery)};
}
template<class Function0>
requires (detail::GraphAccepts5<std::remove_reference_t<Function0>>)
inline Nat call_host(Function0&& a0) {
  try {
    detail::GraphCallbackState state;
    detail::graph_check3(detail::graph_recovery(a0), 0, true, state.budget);
    detail::GraphCallback5<std::remove_reference_t<Function0>> callback0(a0, state);
    detail::callbacksubtypes_callback_6bc98ee774b20d3238b9e42a92309a51ce9dad0a view0{decltype(callback0)::invoke, &callback0, &callback0.recovery->value};
    detail::callbacksubtypes_scalar_nat_t out{};
    detail::GraphOwned<detail::callbacksubtypes_scalar_nat_t, detail::callbacksubtypes_scalar_nat_t_clear> owner(&out);
    state.finish(detail::lean_bridge_23220a30761b2d3716c5b4ed_graph(&view0, &out));
    auto value = detail::graph_from3(out, 0, true, true, state.budget);
    state.finish(0);
    return value;
  } catch (const detail::GraphConversionError& error) { detail::callable_fail(error.status); }
}
template<class Function0>
requires (detail::GraphAccepts0<std::remove_reference_t<Function0>>)
inline Graph2c6f4131c8731fa67588 call_host_container(Function0&& a0) {
  try {
    detail::GraphCallbackState state;
    detail::graph_check1(detail::graph_recovery(a0), 0, true, state.budget);
    detail::GraphCallback0<std::remove_reference_t<Function0>> callback0(a0, state);
    detail::callbacksubtypes_callback_14cd8f1b0d065ede9a36f8590000c62c12d8e99c view0{decltype(callback0)::invoke, &callback0, &callback0.recovery->value};
    detail::callbacksubtypes_graph_2c6f4131c8731fa67588_t out{};
    detail::GraphOwned<detail::callbacksubtypes_graph_2c6f4131c8731fa67588_t, detail::callbacksubtypes_graph_2c6f4131c8731fa67588_t_clear> owner(&out);
    state.finish(detail::lean_bridge_8ffe188578f9a7b74003cf3c_graph(&view0, &out));
    auto value = detail::graph_from1(out, 0, true, true, state.budget);
    state.finish(0);
    return value;
  } catch (const detail::GraphConversionError& error) { detail::callable_fail(error.status); }
}
template<class Function0>
requires (detail::GraphAccepts2<std::remove_reference_t<Function0>>)
inline Nat call_host_mixed(Function0&& a0) {
  try {
    detail::GraphCallbackState state;
    detail::graph_check3(detail::graph_recovery(a0), 0, true, state.budget);
    detail::GraphCallback2<std::remove_reference_t<Function0>> callback0(a0, state);
    detail::callbacksubtypes_callback_197d5bf19058d37bc5547c33a8e0bed3bf121ea7 view0{decltype(callback0)::invoke, &callback0, &callback0.recovery->value};
    detail::callbacksubtypes_scalar_nat_t out{};
    detail::GraphOwned<detail::callbacksubtypes_scalar_nat_t, detail::callbacksubtypes_scalar_nat_t_clear> owner(&out);
    state.finish(detail::lean_bridge_4f106adfac5064464a2a8e3f_graph(&view0, &out));
    auto value = detail::graph_from3(out, 0, true, true, state.budget);
    state.finish(0);
    return value;
  } catch (const detail::GraphConversionError& error) { detail::callable_fail(error.status); }
}
inline LeanClosure<Nat(Nat)> make_closure(const Nat& a0) {
  try {
    detail::GraphCallbackState state;
    auto owned = std::make_shared<detail::GraphLease>(detail::callbacksubtypes_callback_c27fa7df7f1805196544d398fb121b21c179beb1_lease_dispose);
    detail::graph_check3(a0, 0, true, state.budget);
    detail::GraphView3 view0(a0);
    state.finish(detail::lean_bridge_e2d5407c03792441cb368ec1_graph(&view0.value, &owned->token));
    return detail::GraphClosureFactory::make<Nat(Nat)>(std::move(owned), detail::graph_invoke1);
  } catch (const detail::GraphConversionError& error) { detail::callable_fail(error.status); }
}
inline LeanClosure<Graph743764d1b67e81fcae92(Graph6c9c0cf3d3abf9adeb4b)> make_container_closure(const Nat& a0) {
  try {
    detail::GraphCallbackState state;
    auto owned = std::make_shared<detail::GraphLease>(detail::callbacksubtypes_callback_6cdd9c3be7604978d190e4f9d3a70db0539487ba_lease_dispose);
    detail::graph_check3(a0, 0, true, state.budget);
    detail::GraphView3 view0(a0);
    state.finish(detail::lean_bridge_07d8425a546c7304b285ddcd_graph(&view0.value, &owned->token));
    return detail::GraphClosureFactory::make<Graph743764d1b67e81fcae92(Graph6c9c0cf3d3abf9adeb4b)>(std::move(owned), detail::graph_invoke4);
  } catch (const detail::GraphConversionError& error) { detail::callable_fail(error.status); }
}
inline LeanClosure<Nat(Nat, Nat)> make_mixed_closure(const Nat& a0) {
  try {
    detail::GraphCallbackState state;
    auto owned = std::make_shared<detail::GraphLease>(detail::callbacksubtypes_callback_51bfd752726fcfd8a9187a7c3a979ace51f7c1be_lease_dispose);
    detail::graph_check3(a0, 0, true, state.budget);
    detail::GraphView3 view0(a0);
    state.finish(detail::lean_bridge_36fd9c74c3921bfb2ead3644_graph(&view0.value, &owned->token));
    return detail::GraphClosureFactory::make<Nat(Nat, Nat)>(std::move(owned), detail::graph_invoke3);
  } catch (const detail::GraphConversionError& error) { detail::callable_fail(error.status); }
}
}
