#pragma once
#include <cstdint>
#include <memory>
#include <optional>
#include <stdexcept>
#include <string>
#include <type_traits>
#include <utility>
#include <variant>
#include <vector>
#ifndef BOOST_MP_STANDALONE
#define BOOST_MP_STANDALONE
#endif
#include <boost/multiprecision/cpp_int.hpp>
namespace lean_bridge::callbacksubtypes {
namespace detail {
template<class T, class U> struct BoxInput : std::is_same<T, U> {};
template<class... T, class U> struct BoxInput<std::variant<T...>, U>
  : std::bool_constant<std::is_same_v<std::variant<T...>, U> || (std::is_same_v<T, U> || ...)> {};
template<class T, class U> struct BoxInput<std::optional<T>, U>
  : std::bool_constant<std::is_same_v<std::optional<T>, U> || std::is_same_v<T, U> || std::is_same_v<std::nullopt_t, U>> {};
}
template<class T> class Box {
  std::unique_ptr<T> value_;
public:
  Box() noexcept = default;
  template<class U>
  requires detail::BoxInput<T, std::remove_cvref_t<U>>::value
  Box(U&& value) : value_(std::make_unique<T>(std::forward<U>(value))) {}
  Box(const Box& other) : value_(other ? std::make_unique<T>(*other) : nullptr) {}
  Box(Box&&) noexcept = default;
  Box& operator=(const Box& other) {
    if (this != &other) { Box copy(other); value_.swap(copy.value_); }
    return *this;
  }
  Box& operator=(Box&&) noexcept = default;
  template<class U>
  requires detail::BoxInput<T, std::remove_cvref_t<U>>::value
  Box& operator=(U&& value) {
    Box copy(std::forward<U>(value)); value_.swap(copy.value_); return *this;
  }
  explicit operator bool() const noexcept { return static_cast<bool>(value_); }
  T& operator*() { if (!value_) throw std::logic_error("Empty Lean value box"); return *value_; }
  const T& operator*() const { if (!value_) throw std::logic_error("Empty Lean value box"); return *value_; }
  T* operator->() { return &**this; }
  const T* operator->() const { return &**this; }
  friend bool operator==(const Box& a, const Box& b) {
    return a ? b && *a == *b : !b;
  }
};
template<class T> struct Ok { T value; friend bool operator==(const Ok&, const Ok&) = default; };
template<class E> struct Err { E value; friend bool operator==(const Err&, const Err&) = default; };
template<class T, class E> using Result = std::variant<Ok<T>, Err<E>>;
using Nat = boost::multiprecision::cpp_int;
using Int = boost::multiprecision::cpp_int;
using Graph743764d1b67e81fcae92 = std::optional<Nat>;
using Graph2c6f4131c8731fa67588 = Result<Graph743764d1b67e81fcae92, std::string>;
using Graph6c9c0cf3d3abf9adeb4b = std::vector<Graph743764d1b67e81fcae92>;
}
