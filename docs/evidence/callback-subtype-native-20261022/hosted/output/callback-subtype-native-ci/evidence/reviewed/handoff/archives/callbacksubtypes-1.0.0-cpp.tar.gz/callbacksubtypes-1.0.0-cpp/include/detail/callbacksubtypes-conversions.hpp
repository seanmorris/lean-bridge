#pragma once
#include "callbacksubtypes-values.hpp"
#include "callbacksubtypes-graph-types.h"
#include <climits>
#include <cstring>
#include <iterator>
namespace lean_bridge::callbacksubtypes::detail {
static_assert(sizeof(size_t) == 8 && sizeof(void*) == 8 && sizeof(bool) == 1 && CHAR_BIT == 8, "Native graph conversion requires the verified 64-bit byte ABI");
class GraphConversionError : public std::runtime_error {
public:
  uint32_t status;
  bool native_status;
  GraphConversionError(uint32_t code, const char* message, bool native = false)
    : std::runtime_error(message), status(code), native_status(native) {}
};
[[noreturn]] inline void graph_fail(uint32_t status, const char* text, bool native = false) {
  throw GraphConversionError(status, text, native);
}
struct GraphBudget {
  size_t nodes = 262144;
  size_t native_bytes = 16u * 1024u * 1024u;
  size_t storage_bytes = 16u * 1024u * 1024u;
  static void charge(size_t& budget, size_t count, size_t width) {
    if (count > budget / width) graph_fail(2, "Copied graph byte limit exceeded");
    budget -= count * width;
  }
  void enter(size_t depth) {
    if (depth > 128 || !nodes) graph_fail(2, "Copied graph depth or node limit exceeded");
    --nodes;
  }
  void native(size_t count, size_t width) { charge(native_bytes, count, width); }
  void storage(size_t count, size_t width) { charge(storage_bytes, count, width); }
};
template<class T> inline const T& graph_read(const T* pointer) {
  const uintptr_t address = reinterpret_cast<uintptr_t>(pointer);
  if (!pointer || address % alignof(T) || sizeof(T) > UINTPTR_MAX - address) graph_fail(4, "Invalid native graph pointer");
  return *pointer;
}
template<class T> inline void graph_span(const T* pointer, size_t count) {
  if (count) {
    if (count > (UINTPTR_MAX - reinterpret_cast<uintptr_t>(pointer)) / sizeof(T)) graph_fail(4, "Invalid native graph span");
    (void)graph_read(pointer);
  }
}
inline void graph_utf8(const char* data, size_t length, uint32_t status) {
  size_t i = 0;
  while (i < length) {
    uint32_t point = static_cast<uint8_t>(data[i++]), minimum; size_t extra;
    if (point < 0x80) continue;
    if (point >= 0xc2 && point <= 0xdf) { point &= 0x1f; extra = 1; minimum = 0x80; }
    else if (point >= 0xe0 && point <= 0xef) { point &= 0x0f; extra = 2; minimum = 0x800; }
    else if (point >= 0xf0 && point <= 0xf4) { point &= 7; extra = 3; minimum = 0x10000; }
    else graph_fail(status, "Invalid UTF-8 text");
    if (extra > length - i) graph_fail(status, "Incomplete UTF-8 text");
    while (extra--) {
      uint8_t next = static_cast<uint8_t>(data[i++]);
      if ((next & 0xc0) != 0x80) graph_fail(status, "Invalid UTF-8 continuation");
      point = (point << 6) | (next & 0x3f);
    }
    if (point < minimum || point > 0x10ffff || (point >= 0xd800 && point <= 0xdfff)) graph_fail(status, "Invalid UTF-8 scalar");
  }
}
template<class Integer> inline size_t graph_limb_count(const Integer& source) {
  auto high = source.backend().limbs()[source.backend().size() - 1]; size_t high_bits = 0;
  while (high) { ++high_bits; high >>= 1; }
  const size_t bits = (source.backend().size() - 1) * sizeof(*source.backend().limbs()) * CHAR_BIT + high_bits;
  return (bits + 31) / 32;
}
template<class T, void (*Clear)(T*)> struct GraphOwned {
  T* value;
  explicit GraphOwned(T* input) : value(input) {}
  GraphOwned(const GraphOwned&) = delete;
  GraphOwned& operator=(const GraphOwned&) = delete;
  ~GraphOwned() { Clear(value); }
};
struct GraphView0;
inline void graph_check0(const Graph743764d1b67e81fcae92&, size_t, bool, GraphBudget&);
inline Graph743764d1b67e81fcae92 graph_from0(const callbacksubtypes_graph_743764d1b67e81fcae92_t&, size_t, bool, bool, GraphBudget&);
struct GraphView1;
inline void graph_check1(const Graph2c6f4131c8731fa67588&, size_t, bool, GraphBudget&);
inline Graph2c6f4131c8731fa67588 graph_from1(const callbacksubtypes_graph_2c6f4131c8731fa67588_t&, size_t, bool, bool, GraphBudget&);
struct GraphView2;
inline void graph_check2(const Graph6c9c0cf3d3abf9adeb4b&, size_t, bool, GraphBudget&);
inline Graph6c9c0cf3d3abf9adeb4b graph_from2(const callbacksubtypes_graph_6c9c0cf3d3abf9adeb4b_t&, size_t, bool, bool, GraphBudget&);
struct GraphView3;
inline void graph_check3(const Nat&, size_t, bool, GraphBudget&);
inline Nat graph_from3(const callbacksubtypes_scalar_nat_t&, size_t, bool, bool, GraphBudget&);
struct GraphView4;
inline void graph_check4(const std::string&, size_t, bool, GraphBudget&);
inline std::string graph_from4(const callbacksubtypes_scalar_string_t&, size_t, bool, bool, GraphBudget&);
struct GraphView5;
inline void graph_check5(const std::monostate&, size_t, bool, GraphBudget&);
inline std::monostate graph_from5(const uint8_t&, size_t, bool, bool, GraphBudget&);
struct GraphView0 {
  std::unique_ptr<GraphView3> field0;
  callbacksubtypes_graph_743764d1b67e81fcae92_t value{};
  explicit GraphView0(const Graph743764d1b67e81fcae92&);
  ~GraphView0();
  GraphView0(GraphView0&&) noexcept;
  GraphView0(const GraphView0&) = delete;
};
struct GraphView1 {
  std::unique_ptr<GraphView0> field0;
  std::unique_ptr<GraphView4> field1;
  callbacksubtypes_graph_2c6f4131c8731fa67588_t value{};
  explicit GraphView1(const Graph2c6f4131c8731fa67588&);
  ~GraphView1();
  GraphView1(GraphView1&&) noexcept;
  GraphView1(const GraphView1&) = delete;
};
struct GraphView2 {
  std::vector<GraphView0> items;
  std::unique_ptr<callbacksubtypes_graph_743764d1b67e81fcae92_t[]> data;
  callbacksubtypes_graph_6c9c0cf3d3abf9adeb4b_t value{};
  explicit GraphView2(const Graph6c9c0cf3d3abf9adeb4b&);
  ~GraphView2();
  GraphView2(GraphView2&&) noexcept;
  GraphView2(const GraphView2&) = delete;
};
struct GraphView3 {
  std::vector<uint32_t> limbs;
  callbacksubtypes_scalar_nat_t value{};
  explicit GraphView3(const Nat&);
  ~GraphView3();
  GraphView3(GraphView3&&) noexcept;
  GraphView3(const GraphView3&) = delete;
};
struct GraphView4 {
  callbacksubtypes_scalar_string_t value{};
  explicit GraphView4(const std::string&);
  ~GraphView4();
  GraphView4(GraphView4&&) noexcept;
  GraphView4(const GraphView4&) = delete;
};
struct GraphView5 {
  uint8_t value{};
  explicit GraphView5(const std::monostate&);
  ~GraphView5();
  GraphView5(GraphView5&&) noexcept;
  GraphView5(const GraphView5&) = delete;
};
inline GraphView0::~GraphView0() = default;
inline GraphView0::GraphView0(GraphView0&&) noexcept = default;
inline void graph_check0(const Graph743764d1b67e81fcae92& source, size_t depth, bool storage, GraphBudget& budget) {
  (void)source; budget.enter(depth);
  if (storage) budget.native(1, sizeof(callbacksubtypes_graph_743764d1b67e81fcae92_t));
  budget.storage(1, sizeof(GraphView0));
  if (source.has_value()) {
  graph_check3(*source, depth + 1, false, budget);
  }
}
inline GraphView0::GraphView0(const Graph743764d1b67e81fcae92& source) {
  (void)source;
  value.has_value = source.has_value();
  if (source.has_value()) {
  field0 = std::make_unique<GraphView3>(*source);
  value.value = field0->value;
  }
}
inline Graph743764d1b67e81fcae92 graph_from0(const callbacksubtypes_graph_743764d1b67e81fcae92_t& source, size_t depth, bool native_storage, bool host_storage, GraphBudget& budget) {
  (void)source; budget.enter(depth);
  if (native_storage) budget.native(1, sizeof(callbacksubtypes_graph_743764d1b67e81fcae92_t));
  if (host_storage) budget.storage(1, sizeof(Graph743764d1b67e81fcae92));
  if (source.has_value > 1) graph_fail(4, "Invalid native optional/result tag");
  if (source.has_value) return Graph743764d1b67e81fcae92{std::in_place, graph_from3(source.value, depth + 1, false, false, budget)};
  return std::nullopt;
}
inline GraphView1::~GraphView1() = default;
inline GraphView1::GraphView1(GraphView1&&) noexcept = default;
inline void graph_check1(const Graph2c6f4131c8731fa67588& source, size_t depth, bool storage, GraphBudget& budget) {
  (void)source; budget.enter(depth);
  if (storage) budget.native(1, sizeof(callbacksubtypes_graph_2c6f4131c8731fa67588_t));
  budget.storage(1, sizeof(GraphView1));
  if (source.valueless_by_exception()) graph_fail(1, "Result has no active branch");
  if (source.index() == 0) {
  graph_check0(std::get<0>(source).value, depth + 1, false, budget);
  }
  if (source.index() == 1) {
  graph_check4(std::get<1>(source).value, depth + 1, false, budget);
  }
}
inline GraphView1::GraphView1(const Graph2c6f4131c8731fa67588& source) {
  (void)source;
  value.is_ok = source.index() == 0;
  if (source.index() == 0) {
  field0 = std::make_unique<GraphView0>(std::get<0>(source).value);
  value.ok = field0->value;
  }
  if (source.index() == 1) {
  field1 = std::make_unique<GraphView4>(std::get<1>(source).value);
  value.error = field1->value;
  }
}
inline Graph2c6f4131c8731fa67588 graph_from1(const callbacksubtypes_graph_2c6f4131c8731fa67588_t& source, size_t depth, bool native_storage, bool host_storage, GraphBudget& budget) {
  (void)source; budget.enter(depth);
  if (native_storage) budget.native(1, sizeof(callbacksubtypes_graph_2c6f4131c8731fa67588_t));
  if (host_storage) budget.storage(1, sizeof(Graph2c6f4131c8731fa67588));
  if (source.is_ok > 1) graph_fail(4, "Invalid native optional/result tag");
  if (source.is_ok) return Graph2c6f4131c8731fa67588{Ok<Graph743764d1b67e81fcae92>{graph_from0(source.ok, depth + 1, false, false, budget)}};
  if (!source.is_ok) return Graph2c6f4131c8731fa67588{Err<std::string>{graph_from4(source.error, depth + 1, false, false, budget)}};
  graph_fail(4, "Invalid native result branch");
}
inline GraphView2::~GraphView2() = default;
inline GraphView2::GraphView2(GraphView2&&) noexcept = default;
inline void graph_check2(const Graph6c9c0cf3d3abf9adeb4b& source, size_t depth, bool storage, GraphBudget& budget) {
  (void)source; budget.enter(depth);
  if (storage) budget.native(1, sizeof(callbacksubtypes_graph_6c9c0cf3d3abf9adeb4b_t));
  budget.storage(1, sizeof(GraphView2));
  if (source.size() > budget.nodes) graph_fail(2, "Copied sequence node limit exceeded");
  budget.native(source.size(), sizeof(callbacksubtypes_graph_743764d1b67e81fcae92_t)); budget.storage(source.size(), sizeof(callbacksubtypes_graph_743764d1b67e81fcae92_t));
  for (const auto& child : source) graph_check0(child, depth + 1, false, budget);
}
inline GraphView2::GraphView2(const Graph6c9c0cf3d3abf9adeb4b& source) {
  (void)source;
  items.reserve(source.size());
  data = source.empty() ? nullptr : std::make_unique<callbacksubtypes_graph_743764d1b67e81fcae92_t[]>(source.size());
  for (const auto& child : source) items.emplace_back(child);
  for (size_t j = 0; j < source.size(); ++j) data[j] = items[j].value;
  value.data = data.get(); value.length = source.size();
}
inline Graph6c9c0cf3d3abf9adeb4b graph_from2(const callbacksubtypes_graph_6c9c0cf3d3abf9adeb4b_t& source, size_t depth, bool native_storage, bool host_storage, GraphBudget& budget) {
  (void)source; budget.enter(depth);
  if (native_storage) budget.native(1, sizeof(callbacksubtypes_graph_6c9c0cf3d3abf9adeb4b_t));
  if (host_storage) budget.storage(1, sizeof(Graph6c9c0cf3d3abf9adeb4b));
  if (source.length > budget.nodes) graph_fail(2, "Copied sequence node limit exceeded");
  budget.native(source.length, sizeof(callbacksubtypes_graph_743764d1b67e81fcae92_t)); budget.storage(source.length, sizeof(Graph743764d1b67e81fcae92));
  graph_span(source.data, source.length);
  Graph6c9c0cf3d3abf9adeb4b result; result.reserve(source.length);
  for (size_t j = 0; j < source.length; ++j) result.push_back(graph_from0(source.data[j], depth + 1, false, false, budget));
  return result;
}
inline GraphView3::~GraphView3() = default;
inline GraphView3::GraphView3(GraphView3&&) noexcept = default;
inline void graph_check3(const Nat& source, size_t depth, bool storage, GraphBudget& budget) {
  (void)source; budget.enter(depth);
  if (storage) budget.native(1, sizeof(callbacksubtypes_scalar_nat_t));
  budget.storage(1, sizeof(GraphView3));
  if (source < 0) graph_fail(1, "Nat must be nonnegative");
  if (source.backend().size() > budget.native_bytes / sizeof(boost::multiprecision::limb_type) + 1) graph_fail(2, "Copied integer limit exceeded");
  const size_t limbs = graph_limb_count(source);
  budget.native(limbs, sizeof(uint32_t)); budget.storage(limbs, sizeof(uint32_t));
}
inline GraphView3::GraphView3(const Nat& source) {
  (void)source;
  limbs.reserve(graph_limb_count(source));
  if (source != 0) boost::multiprecision::export_bits(source, std::back_inserter(limbs), 32, false);
  value.data = limbs.data(); value.length = limbs.size();
}
inline Nat graph_from3(const callbacksubtypes_scalar_nat_t& source, size_t depth, bool native_storage, bool host_storage, GraphBudget& budget) {
  (void)source; budget.enter(depth);
  if (native_storage) budget.native(1, sizeof(callbacksubtypes_scalar_nat_t));
  if (host_storage) budget.storage(1, sizeof(Nat));
  budget.native(source.length, sizeof(uint32_t)); budget.storage(source.length, sizeof(uint32_t));
  graph_span(source.data, source.length);
  Nat result = 0;
  if (source.length) boost::multiprecision::import_bits(result, source.data, source.data + source.length, 32, false);
  return result;
}
inline GraphView4::~GraphView4() = default;
inline GraphView4::GraphView4(GraphView4&&) noexcept = default;
inline void graph_check4(const std::string& source, size_t depth, bool storage, GraphBudget& budget) {
  (void)source; budget.enter(depth);
  if (storage) budget.native(1, sizeof(callbacksubtypes_scalar_string_t));
  budget.storage(1, sizeof(GraphView4));
  budget.native(source.size(), 1);
  graph_utf8(source.data(), source.size(), 1);
}
inline GraphView4::GraphView4(const std::string& source) {
  (void)source;
  value.data = source.data(); value.length = source.size();
}
inline std::string graph_from4(const callbacksubtypes_scalar_string_t& source, size_t depth, bool native_storage, bool host_storage, GraphBudget& budget) {
  (void)source; budget.enter(depth);
  if (native_storage) budget.native(1, sizeof(callbacksubtypes_scalar_string_t));
  if (host_storage) budget.storage(1, sizeof(std::string));
  budget.native(source.length, 1); graph_span(source.data, source.length);
  graph_utf8(source.data, source.length, 4);
  budget.storage(source.length + 1, 1);
  return source.length ? std::string(source.data, source.length) : std::string{};
}
inline GraphView5::~GraphView5() = default;
inline GraphView5::GraphView5(GraphView5&&) noexcept = default;
inline void graph_check5(const std::monostate& source, size_t depth, bool storage, GraphBudget& budget) {
  (void)source; budget.enter(depth);
  if (storage) budget.native(1, sizeof(uint8_t));
  budget.storage(1, sizeof(GraphView5));
}
inline GraphView5::GraphView5(const std::monostate& source) {
  (void)source;
  value = 0;
}
inline std::monostate graph_from5(const uint8_t& source, size_t depth, bool native_storage, bool host_storage, GraphBudget& budget) {
  (void)source; budget.enter(depth);
  if (native_storage) budget.native(1, sizeof(uint8_t));
  if (host_storage) budget.storage(1, sizeof(std::monostate));
  if (source) graph_fail(4, "Invalid native Unit");
  return {};
}
template<class Invoke> inline std::monostate graph_call_copied_payload0(Invoke&& invoke, const Nat& arg0, const Graph2c6f4131c8731fa67588& arg1, const Graph743764d1b67e81fcae92& arg2, const Graph6c9c0cf3d3abf9adeb4b& arg3) {
  GraphBudget budget;
  graph_check3(arg0, 0, true, budget);
  graph_check1(arg1, 0, true, budget);
  graph_check0(arg2, 0, true, budget);
  graph_check2(arg3, 0, true, budget);
  GraphView3 view0(arg0);
  GraphView1 view1(arg1);
  GraphView0 view2(arg2);
  GraphView2 view3(arg3);
  uint8_t result{};
  const uint32_t status = std::forward<Invoke>(invoke)(&view0.value, &view1.value, &view2.value, &view3.value, &result);
  if (status) graph_fail(status, "Native copied graph call failed", true);
  return graph_from5(result, 0, true, true, budget);
}
}
