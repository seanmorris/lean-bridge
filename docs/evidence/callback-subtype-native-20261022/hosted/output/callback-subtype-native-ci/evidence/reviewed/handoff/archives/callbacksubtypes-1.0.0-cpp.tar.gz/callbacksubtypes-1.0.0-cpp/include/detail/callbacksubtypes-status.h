#ifndef CALLBACKSUBTYPES_COPIED_GRAPH_STATUS_H
#define CALLBACKSUBTYPES_COPIED_GRAPH_STATUS_H
#include <stddef.h>
#include <stdint.h>
typedef enum callbacksubtypes_status {
  CALLBACKSUBTYPES_STATUS_OK = 0, CALLBACKSUBTYPES_STATUS_INVALID_ARGUMENT = 1,
  CALLBACKSUBTYPES_STATUS_RUNTIME_UNAVAILABLE = 2, CALLBACKSUBTYPES_STATUS_RUNTIME_REJECTED = 3,
  CALLBACKSUBTYPES_STATUS_DECLARED_ERROR = 4, CALLBACKSUBTYPES_STATUS_UNEXPECTED_ERROR = 5
} callbacksubtypes_status;
typedef enum callbacksubtypes_error_code {
  CALLBACKSUBTYPES_ERROR_NONE = 0, CALLBACKSUBTYPES_ERROR_INVALID_ARGUMENT = 1,
  CALLBACKSUBTYPES_ERROR_RUNTIME_UNAVAILABLE = 2, CALLBACKSUBTYPES_ERROR_UNEXPECTED = 65535
} callbacksubtypes_error_code;
typedef struct callbacksubtypes_error { callbacksubtypes_error_code code; const char *message; size_t message_length; } callbacksubtypes_error;
static inline callbacksubtypes_status callbacksubtypes_graph_finish(uint32_t status, callbacksubtypes_error *error) {
  static const char *const messages[] = {"", "Invalid copied value", "Copied value limit exceeded", "Copied value allocation failed", "Malformed native result", "Lean runtime initialization failed or runtime retired"};
  const char *message = messages[status <= 5 ? status : 4];
  size_t length = 0; while (message[length]) ++length;
  callbacksubtypes_status result = status == 0 ? CALLBACKSUBTYPES_STATUS_OK
    : status <= 2 ? CALLBACKSUBTYPES_STATUS_INVALID_ARGUMENT : CALLBACKSUBTYPES_STATUS_UNEXPECTED_ERROR;
  if (error) { error->code = status == 0 ? CALLBACKSUBTYPES_ERROR_NONE
    : status <= 2 ? CALLBACKSUBTYPES_ERROR_INVALID_ARGUMENT : CALLBACKSUBTYPES_ERROR_UNEXPECTED;
    error->message = message; error->message_length = length; }
  return result;
}
#endif
