#include "component.h"
#include "lean_bridge_native_runtime.h"
static _Thread_local int lean_bridge_owned_callback_failure_ba4f0d0528c6905f7b80_state;
int lean_bridge_owned_callback_failure_ba4f0d0528c6905f7b80(void) { int result = lean_bridge_owned_callback_failure_ba4f0d0528c6905f7b80_state; lean_bridge_owned_callback_failure_ba4f0d0528c6905f7b80_state = 0; return result; }
