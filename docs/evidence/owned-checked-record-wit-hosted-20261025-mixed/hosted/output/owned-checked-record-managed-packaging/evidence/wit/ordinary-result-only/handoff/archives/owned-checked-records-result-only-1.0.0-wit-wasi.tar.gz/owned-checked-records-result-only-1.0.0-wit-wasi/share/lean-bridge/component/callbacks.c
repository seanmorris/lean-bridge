#include "component.h"
#include "lean_bridge_native_runtime.h"
static _Thread_local int lean_bridge_owned_callback_failure_cb768cf0982559d1f090_state;
int lean_bridge_owned_callback_failure_cb768cf0982559d1f090(void) { int result = lean_bridge_owned_callback_failure_cb768cf0982559d1f090_state; lean_bridge_owned_callback_failure_cb768cf0982559d1f090_state = 0; return result; }
