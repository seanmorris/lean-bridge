#pragma once
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <gmp.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef enum owned_checked_records_wasmtime_status { OWNED_CHECKED_RECORDS_WASMTIME_OK = 0, OWNED_CHECKED_RECORDS_WASMTIME_INVALID_ARGUMENT = 1, OWNED_CHECKED_RECORDS_WASMTIME_LIMIT = 2, OWNED_CHECKED_RECORDS_WASMTIME_ALLOCATION_FAILED = 3, OWNED_CHECKED_RECORDS_WASMTIME_CLOSED = 4, OWNED_CHECKED_RECORDS_WASMTIME_WRONG_THREAD = 5, OWNED_CHECKED_RECORDS_WASMTIME_WRONG_PROCESS = 6, OWNED_CHECKED_RECORDS_WASMTIME_RUNTIME_UNAVAILABLE = 7, OWNED_CHECKED_RECORDS_WASMTIME_CALL_ORDER = 8, OWNED_CHECKED_RECORDS_WASMTIME_MALFORMED_RESULT = 9, OWNED_CHECKED_RECORDS_WASMTIME_CALLBACK_FAILED = 10 } owned_checked_records_wasmtime_status;
typedef struct owned_checked_records_wasmtime_session owned_checked_records_wasmtime_session;
typedef struct owned_checked_records_wasmtime_result owned_checked_records_wasmtime_result;
/* Immutable views: input children borrow caller storage for one call.
   Output children, including GMP integers, remain valid until result_release.
   Never free a child or mutate a returned GMP integer. Retain an identity
   before releasing its last owning result. Sessions are thread/process bound.
   Close invalidates resource use; result_release still frees copied storage.
   Output/result slots must not overlap and *owner must initially be NULL.
   GMP retains its normal fatal out-of-memory policy. */
owned_checked_records_wasmtime_status owned_checked_records_wasmtime_session_open(owned_checked_records_wasmtime_session **out);
owned_checked_records_wasmtime_status owned_checked_records_wasmtime_session_close(owned_checked_records_wasmtime_session **value);
owned_checked_records_wasmtime_status owned_checked_records_wasmtime_result_release(owned_checked_records_wasmtime_result **value);
typedef struct owned_checked_records_wasmtime_value_160ce821a84f6887bbfd_t owned_checked_records_wasmtime_value_160ce821a84f6887bbfd_t;
typedef struct owned_checked_records_wasmtime_claim_t owned_checked_records_wasmtime_claim_t;
typedef struct owned_checked_records_wasmtime_ticket_t_handle *owned_checked_records_wasmtime_ticket_t;
typedef struct owned_checked_records_wasmtime_scalar_string_t owned_checked_records_wasmtime_scalar_string_t;
struct owned_checked_records_wasmtime_scalar_string_t {
  const char *data;
  size_t length;
};
struct owned_checked_records_wasmtime_value_160ce821a84f6887bbfd_t {
  bool has_value;
  owned_checked_records_wasmtime_claim_t const *value;
};
struct owned_checked_records_wasmtime_claim_t {
  owned_checked_records_wasmtime_ticket_t holder;
  mpz_srcptr quota;
};
typedef owned_checked_records_wasmtime_value_160ce821a84f6887bbfd_t owned_checked_records_wasmtime_claim_for_result_t;
/* Host callbacks borrow their context for the enclosing call only.
   Set exactly one of call or closure. recovery is an optional typed value;
   it is required if the signature has no finite recovery from its inputs.
   Failure never publishes recovery as a successful result.
   Callback arguments expire on return. Replies may borrow those arguments
   or context storage, or transfer an owning result (also released on error).
   Use a generated copy function to snapshot callback-local storage.
   Do not let C++ exceptions or longjmp cross a callback boundary. */
owned_checked_records_wasmtime_status owned_checked_records_wasmtime_claim_for(owned_checked_records_wasmtime_session *session, owned_checked_records_wasmtime_ticket_t a0, owned_checked_records_wasmtime_value_160ce821a84f6887bbfd_t *out, owned_checked_records_wasmtime_result **owner);
owned_checked_records_wasmtime_status owned_checked_records_wasmtime_new_ticket(owned_checked_records_wasmtime_session *session, mpz_srcptr a0, owned_checked_records_wasmtime_scalar_string_t a1, owned_checked_records_wasmtime_ticket_t *out, owned_checked_records_wasmtime_result **owner);
owned_checked_records_wasmtime_status owned_checked_records_wasmtime_serial(owned_checked_records_wasmtime_session *session, owned_checked_records_wasmtime_ticket_t a0, mpz_srcptr *out, owned_checked_records_wasmtime_result **owner);
owned_checked_records_wasmtime_status owned_checked_records_wasmtime_ticket_t_retain(owned_checked_records_wasmtime_session *session, owned_checked_records_wasmtime_ticket_t a0, owned_checked_records_wasmtime_ticket_t *out, owned_checked_records_wasmtime_result **owner);
owned_checked_records_wasmtime_status owned_checked_records_wasmtime_value_160ce821a84f6887bbfd_t_copy(owned_checked_records_wasmtime_session *session, owned_checked_records_wasmtime_value_160ce821a84f6887bbfd_t const * a0, owned_checked_records_wasmtime_value_160ce821a84f6887bbfd_t *out, owned_checked_records_wasmtime_result **owner);
owned_checked_records_wasmtime_status owned_checked_records_wasmtime_claim_t_copy(owned_checked_records_wasmtime_session *session, owned_checked_records_wasmtime_claim_t const * a0, owned_checked_records_wasmtime_claim_t *out, owned_checked_records_wasmtime_result **owner);
owned_checked_records_wasmtime_status owned_checked_records_wasmtime_scalar_nat_copy(owned_checked_records_wasmtime_session *session, mpz_srcptr a0, mpz_srcptr *out, owned_checked_records_wasmtime_result **owner);
owned_checked_records_wasmtime_status owned_checked_records_wasmtime_scalar_string_copy(owned_checked_records_wasmtime_session *session, owned_checked_records_wasmtime_scalar_string_t a0, owned_checked_records_wasmtime_scalar_string_t *out, owned_checked_records_wasmtime_result **owner);
#ifdef __cplusplus
}
#endif
