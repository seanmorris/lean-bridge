#include "owned_subtypes.h"
#include "owned-values.h"
#include "carriers.h"

#include <stddef.h>
#include <stdint.h>
#include <string.h>
#include "owned-leases.h"
_Static_assert(sizeof(void *) == 8 && sizeof(size_t) == 8, "owned native values require 64-bit Lean");
enum { OV_RESULT = 9 };
typedef struct {
  size_t bytes, visits;
  struct { const void *address; size_t type; } path[129];
} ov_budget;
typedef struct ov_allocation {
  struct ov_allocation *next;
  max_align_t alignment;
  unsigned char data[];
} ov_allocation;
typedef struct {
  lb_owned_scope scope;
  lb_owned_batch *input_owner;
  int input_transfer;
  ov_budget budget;
  ov_allocation *allocations;
} ov_transaction;
typedef struct ov_result_owner {
  struct ov_result_owner *self;
  lb_owned_context *context;
  lb_owned_batch batch;
  ov_allocation *allocations;
} ov_result_owner;

static inline void ov_release(ov_allocation *allocation) {
  while (allocation) {
    ov_allocation *next = allocation->next; LB_OWNED_FREE(allocation); allocation = next;
  }
}
static inline int ov_pointer(const void *value, size_t bytes, size_t alignment) {
  return value && (uintptr_t)value % alignment == 0 && bytes <= UINTPTR_MAX - (uintptr_t)value;
}
static inline int ov_charge(ov_budget *budget, size_t count, size_t width) {
  if (!width || count > budget->bytes / width) return LB_OWNED_LIMIT;
  budget->bytes -= count * width; return LB_OWNED_OK;
}
static inline int ov_visit(ov_budget *budget, size_t depth) {
  if (depth > 128 || !budget->visits) return LB_OWNED_LIMIT;
  --budget->visits; return LB_OWNED_OK;
}
static inline int ov_enter(ov_budget *budget, const void *value, size_t type, size_t depth) {
  int status = ov_visit(budget, depth);
  if (status) return status;
  for (size_t i = 0; i < depth; ++i)
    if (budget->path[i].address == value && budget->path[i].type == type) return LB_OWNED_INVALID;
  budget->path[depth].address = value; budget->path[depth].type = type;
  return LB_OWNED_OK;
}
static inline int ov_span(ov_budget *budget, const void *value, size_t count, size_t width, size_t alignment) {
  int status = ov_charge(budget, count, width);
  if (status) return status;
  return !count || ov_pointer(value, count * width, alignment) ? LB_OWNED_OK : LB_OWNED_INVALID;
}
static inline int ov_allocate(ov_transaction *transaction, size_t count, size_t width, void **out) {
  *out = NULL; if (!count) return LB_OWNED_OK;
  int status = ov_charge(&transaction->budget, count, width);
  if (!status) status = ov_charge(&transaction->budget, 1, sizeof(ov_allocation));
  if (status) return status;
  ov_allocation *allocation = LB_OWNED_ALLOC(sizeof(*allocation) + count * width);
  if (!allocation) return LB_OWNED_ALLOC_FAILED;
  allocation->next = transaction->allocations; transaction->allocations = allocation;
  memset(allocation->data, 0, count * width); *out = allocation->data; return LB_OWNED_OK;
}
static inline int ov_utf8(const uint8_t *data, size_t length) {
  size_t i = 0;
  while (i < length) {
    uint32_t point = data[i++], minimum; size_t extra;
    if (point < 0x80) continue;
    if (point >= 0xc2 && point <= 0xdf) { point &= 0x1f; extra = 1; minimum = 0x80; }
    else if (point >= 0xe0 && point <= 0xef) { point &= 0x0f; extra = 2; minimum = 0x800; }
    else if (point >= 0xf0 && point <= 0xf4) { point &= 7; extra = 3; minimum = 0x10000; }
    else return 0;
    if (extra > length - i) return 0;
    while (extra--) { uint8_t next = data[i++]; if ((next & 0xc0) != 0x80) return 0; point = (point << 6) | (next & 0x3f); }
    if (point < minimum || point > 0x10ffff || (point >= 0xd800 && point <= 0xdfff)) return 0;
  }
  return 1;
}
static inline lean_object *ov_nat_in(const uint32_t *data, size_t length) {
  lean_object *value = lean_box(0);
  while (length) {
    lean_object *shifted = lean_nat_shiftl(value, lean_box(32)); lean_dec(value);
    lean_object *limb = lean_uint32_to_nat(data[--length]);
    value = lean_nat_add(shifted, limb); lean_dec(shifted); lean_dec(limb);
  }
  return value;
}
static inline int ov_nat_out(lean_object *value, ov_transaction *transaction, const uint32_t **data, size_t *length) {
  *data = NULL; *length = 0;
  if (lean_nat_eq(value, lean_box(0))) return LB_OWNED_OK;
  lean_object *bits = lean_nat_log2(value);
  if (!lean_is_scalar(bits)) { lean_dec(bits); return LB_OWNED_LIMIT; }
  size_t count = lean_unbox(bits) / 32 + 1; lean_dec(bits);
  void *raw = NULL; int status = ov_allocate(transaction, count, sizeof(uint32_t), &raw);
  if (status) return status;
  uint32_t *limbs = raw; lean_inc(value);
  for (size_t i = 0; i < count; ++i) {
    limbs[i] = lean_uint32_of_nat(value);
    lean_object *next = lean_nat_shiftr(value, lean_box(32)); lean_dec(value); value = next;
  }
  lean_dec(value); *data = limbs; *length = count; return LB_OWNED_OK;
}
static inline lean_object *ov_carry(lean_object *value) {
  lean_object *carrier = lean_alloc_array(1, 1); lean_array_set_core(carrier, 0, value); return carrier;
}
static inline int ov_carrier(lean_object *value) {
  return value && !lean_is_scalar(value) && lean_is_array(value) && lean_array_size(value) == 1;
}
static inline int ov_finish(lean_object *value, lean_object **out) {
  if (!ov_carrier(value)) { if (value) lean_dec(value); return OV_RESULT; }
  *out = value; return LB_OWNED_OK;
}
static inline int ov_owner_empty(const ov_result_owner *owner) {
  return owner && !owner->self && !owner->context && !owner->allocations
    && !owner->batch.context && !owner->batch.entries && !owner->batch.next;
}
static inline int ov_owner_clear(ov_result_owner *owner) {
  if (!owner) return LB_OWNED_INVALID;
  if (ov_owner_empty(owner)) return LB_OWNED_OK;
  if (owner->self != owner || !owner->context) return LB_OWNED_INVALID;
  lb_owned_context *context = owner->context;
  if (context->self != context) return LB_OWNED_INVALID;
  if (context->process != getpid()) return LB_OWNED_PROCESS;
  if (!pthread_equal(context->thread, pthread_self()) || context->thread_serial != lb_owned_thread_serial)
    return LB_OWNED_THREAD;
  int status = LB_OWNED_OK;
  if (owner->batch.context) status = lb_owned_batch_release(context, &owner->batch);
  /* A broker error can be reported after release has drained the batch. */
  if (owner->batch.context) return status;
  ov_release(owner->allocations); *owner = (ov_result_owner){0}; return status;
}
static inline int ov_begin(ov_transaction *transaction, lb_owned_context *context, ov_result_owner *owner, const char *component) {
  if (!ov_owner_empty(owner)) return LB_OWNED_INVALID;
  int status = lb_owned_ready(context);
  if (status) return status;
  if (strcmp(context->component, component)) return LB_OWNED_INVALID;
  *transaction = (ov_transaction){0};
  transaction->budget.bytes = 16777216; transaction->budget.visits = 262144;
  return lb_owned_scope_begin(context, &transaction->scope);
}
static inline int ov_abort(ov_transaction *transaction, int status) {
  ov_release(transaction->allocations); transaction->allocations = NULL;
  if (transaction->scope.context) {
    if (status == OV_RESULT) lean_bridge_native_runtime_retire();
    int cleanup = lb_owned_scope_abort(&transaction->scope);
    if (!status) status = cleanup;
  }
  return status;
}
static inline int ov_commit(ov_transaction *transaction, ov_result_owner *owner) {
  lb_owned_context *context = transaction->scope.context;
  int status = lb_owned_scope_ready(&transaction->scope);
  if (status) return ov_abort(transaction, status);
  if (!transaction->allocations && !transaction->scope.outputs)
    return ov_abort(transaction, LB_OWNED_OK);
  status = lb_owned_scope_commit(&transaction->scope, &owner->batch);
  if (status) {
    /* Commit may have transferred outputs before dropping a failing input pin. */
    if (owner->batch.context) lb_owned_batch_release(context, &owner->batch);
    return ov_abort(transaction, status);
  }
  owner->self = owner; owner->context = context; owner->allocations = transaction->allocations;
  transaction->allocations = NULL; return LB_OWNED_OK;
}


typedef struct {
  ov_result_owner *const *owners;
  size_t count;
  void (*consume)(void *context);
  void *context;
  int consumed;
} ov_input_transfers;

static inline int ov_transfers_prepare(ov_transaction *transaction,
    ov_input_transfers *transfer, size_t expected, lb_owned_batch **batches,
    size_t *batch_count) {
  int status = lb_owned_scope_ready(&transaction->scope);
  if (status) return status;
  if (!ov_pointer(transfer, sizeof(*transfer), _Alignof(ov_input_transfers)) ||
      transfer->count != expected || transfer->consumed || !transfer->consume)
    return LB_OWNED_INVALID;
  if (expected > LB_OWNED_RETAINED_LIMIT) return LB_OWNED_LIMIT;
  status = ov_span(&transaction->budget, transfer->owners, expected,
      sizeof(ov_result_owner *), _Alignof(ov_result_owner *));
  if (status) return status;
  *batch_count = 0;
  for (size_t i = 0; i < expected; ++i) {
    ov_result_owner *owner = transfer->owners[i];
    if (!ov_pointer(owner, sizeof(*owner), _Alignof(ov_result_owner))) return LB_OWNED_INVALID;
    for (size_t j = 0; j < i; ++j)
      if (owner == transfer->owners[j]) return LB_OWNED_INVALID;
    /* Empty variants can have a public owner but no native allocation or batch.
       Its registration and session are validated by the public adapter. */
    if (ov_owner_empty(owner)) continue;
    if (owner->self != owner || owner->context != transaction->scope.context)
      return LB_OWNED_INVALID;
    lb_owned_batch *batch = transaction->scope.context->batches;
    while (batch && batch != &owner->batch) batch = batch->next;
    if (!batch) return LB_OWNED_INVALID;
    batches[(*batch_count)++] = batch;
  }
  return LB_OWNED_OK;
}


enum { OV_CALLBACK = 10 };
typedef struct ov_callback_frame {
  struct ov_callback_frame *parent;
  ov_transaction *transaction;
  int status;
} ov_callback_frame;
static _Thread_local ov_callback_frame *ov_active_callback_frame;
static inline void ov_callback_fail(ov_callback_frame *frame, int status) {
  if (frame && !frame->status) frame->status = status;
}

static inline int lbov_1d643ee3fbc2aa924d28_v82551d965c182180b0dd_in(const lbov_1d643ee3fbc2aa924d28_t82551d965c182180b0dd *, size_t, int, ov_transaction *, lean_object **);
static inline int lbov_1d643ee3fbc2aa924d28_v82551d965c182180b0dd_out(lbov_1d643ee3fbc2aa924d28_t82551d965c182180b0dd *, lean_object *, size_t, ov_transaction *);
static inline int lbov_1d643ee3fbc2aa924d28_v659ec6a690764999d00d_in(const lbov_1d643ee3fbc2aa924d28_t659ec6a690764999d00d *, size_t, int, ov_transaction *, lean_object **);
static inline int lbov_1d643ee3fbc2aa924d28_v659ec6a690764999d00d_out(lbov_1d643ee3fbc2aa924d28_t659ec6a690764999d00d *, lean_object *, size_t, ov_transaction *);
static inline int lbov_1d643ee3fbc2aa924d28_v817592654f48ba756bd4_in(const lbov_1d643ee3fbc2aa924d28_t817592654f48ba756bd4 *, size_t, int, ov_transaction *, lean_object **);
static inline int lbov_1d643ee3fbc2aa924d28_v817592654f48ba756bd4_out(lbov_1d643ee3fbc2aa924d28_t817592654f48ba756bd4 *, lean_object *, size_t, ov_transaction *);
static inline int lbov_1d643ee3fbc2aa924d28_v6f9a0eb5450512cec111_in(const lbov_1d643ee3fbc2aa924d28_t6f9a0eb5450512cec111 *, size_t, int, ov_transaction *, lean_object **);
static inline int lbov_1d643ee3fbc2aa924d28_v6f9a0eb5450512cec111_out(lbov_1d643ee3fbc2aa924d28_t6f9a0eb5450512cec111 *, lean_object *, size_t, ov_transaction *);
static inline int lbov_1d643ee3fbc2aa924d28_v5faad500583201774348_in(const lbov_1d643ee3fbc2aa924d28_t5faad500583201774348 *, size_t, int, ov_transaction *, lean_object **);
static inline int lbov_1d643ee3fbc2aa924d28_v5faad500583201774348_out(lbov_1d643ee3fbc2aa924d28_t5faad500583201774348 *, lean_object *, size_t, ov_transaction *);
static inline int lbov_1d643ee3fbc2aa924d28_v37c6db88a97448412ed0_in(const lbov_1d643ee3fbc2aa924d28_t37c6db88a97448412ed0 *, size_t, int, ov_transaction *, lean_object **);
static inline int lbov_1d643ee3fbc2aa924d28_v37c6db88a97448412ed0_out(lbov_1d643ee3fbc2aa924d28_t37c6db88a97448412ed0 *, lean_object *, size_t, ov_transaction *);
static inline int lbov_1d643ee3fbc2aa924d28_vf197109068e846c0739c_in(const lbov_1d643ee3fbc2aa924d28_tf197109068e846c0739c *, size_t, int, ov_transaction *, lean_object **);
static inline int lbov_1d643ee3fbc2aa924d28_vf197109068e846c0739c_out(lbov_1d643ee3fbc2aa924d28_tf197109068e846c0739c *, lean_object *, size_t, ov_transaction *);
static inline int lbov_1d643ee3fbc2aa924d28_v550e0acb733e8dd08e4e_in(const lbov_1d643ee3fbc2aa924d28_t550e0acb733e8dd08e4e *, size_t, int, ov_transaction *, lean_object **);
static inline int lbov_1d643ee3fbc2aa924d28_v550e0acb733e8dd08e4e_out(lbov_1d643ee3fbc2aa924d28_t550e0acb733e8dd08e4e *, lean_object *, size_t, ov_transaction *);
static inline int lbov_1d643ee3fbc2aa924d28_v6de8e950bc342c30091c_in(const lbov_1d643ee3fbc2aa924d28_t6de8e950bc342c30091c *, size_t, int, ov_transaction *, lean_object **);
static inline int lbov_1d643ee3fbc2aa924d28_v6de8e950bc342c30091c_out(lbov_1d643ee3fbc2aa924d28_t6de8e950bc342c30091c *, lean_object *, size_t, ov_transaction *);
static inline int lbov_1d643ee3fbc2aa924d28_vf098e5912ebfda269f53_in(const lbov_1d643ee3fbc2aa924d28_tf098e5912ebfda269f53 *, size_t, int, ov_transaction *, lean_object **);
static inline int lbov_1d643ee3fbc2aa924d28_vf098e5912ebfda269f53_out(lbov_1d643ee3fbc2aa924d28_tf098e5912ebfda269f53 *, lean_object *, size_t, ov_transaction *);
static inline int lbov_1d643ee3fbc2aa924d28_v11140334dba7a15b6b99_in(const lbov_1d643ee3fbc2aa924d28_t11140334dba7a15b6b99 *, size_t, int, ov_transaction *, lean_object **);
static inline int lbov_1d643ee3fbc2aa924d28_v11140334dba7a15b6b99_out(lbov_1d643ee3fbc2aa924d28_t11140334dba7a15b6b99 *, lean_object *, size_t, ov_transaction *);
static inline int lbov_1d643ee3fbc2aa924d28_v167081552b6f9c1d1afd_in(const lbov_1d643ee3fbc2aa924d28_t167081552b6f9c1d1afd *, size_t, int, ov_transaction *, lean_object **);
static inline int lbov_1d643ee3fbc2aa924d28_v167081552b6f9c1d1afd_out(lbov_1d643ee3fbc2aa924d28_t167081552b6f9c1d1afd *, lean_object *, size_t, ov_transaction *);
static inline int lbov_1d643ee3fbc2aa924d28_vdc0347e1f7f5c4d928f1_in(const lbov_1d643ee3fbc2aa924d28_tdc0347e1f7f5c4d928f1 *, size_t, int, ov_transaction *, lean_object **);
static inline int lbov_1d643ee3fbc2aa924d28_vdc0347e1f7f5c4d928f1_out(lbov_1d643ee3fbc2aa924d28_tdc0347e1f7f5c4d928f1 *, lean_object *, size_t, ov_transaction *);
static inline int lbov_1d643ee3fbc2aa924d28_v82551d965c182180b0dd_in(const lbov_1d643ee3fbc2aa924d28_t82551d965c182180b0dd *value, size_t depth, int storage, ov_transaction *transaction, lean_object **out) {
  *out = NULL;
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_1d643ee3fbc2aa924d28_t82551d965c182180b0dd))) return LB_OWNED_INVALID;
  int status = ov_enter(&transaction->budget, value, 0, depth);
  if (!status && storage) status = ov_charge(&transaction->budget, 1, sizeof(*value));
  if (status) return status;
  if (value->length > transaction->budget.visits) return LB_OWNED_LIMIT;
  status = ov_span(&transaction->budget, value->data, value->length, sizeof(lbov_1d643ee3fbc2aa924d28_t6de8e950bc342c30091c), _Alignof(lbov_1d643ee3fbc2aa924d28_t6de8e950bc342c30091c));
  if (status) return status;
  lean_object *items = lean_alloc_array(0, value->length);
  for (size_t i = 0; i < value->length; ++i) {
    lean_object *child = NULL;
    status = lbov_1d643ee3fbc2aa924d28_v6de8e950bc342c30091c_in(value->data + i, depth + 1, 0, transaction, &child);
    if (status) { lean_dec(items); return status; }
    items = lean_array_push(items, child);
  }
  return ov_finish(lean_bridge_owned_48d801817da6928541ff452a_t82551d965c182180b0dd_make(items), out);
}
static inline int lbov_1d643ee3fbc2aa924d28_v82551d965c182180b0dd_out(lbov_1d643ee3fbc2aa924d28_t82551d965c182180b0dd *out, lean_object *value, size_t depth, ov_transaction *transaction) {
  int status = ov_visit(&transaction->budget, depth);
  if (status) { if (value) lean_dec(value); return status; }
  if (!ov_carrier(value)) { if (value) lean_dec(value); return OV_RESULT; }
  size_t limit = transaction->budget.bytes / sizeof(lbov_1d643ee3fbc2aa924d28_t6de8e950bc342c30091c);
  if (limit > transaction->budget.visits) limit = transaction->budget.visits;
  if (depth == 128) limit = 0;
  size_t remaining = LB_OWNED_RETAINED_LIMIT - transaction->scope.retained;
  if (limit > remaining) limit = remaining;
  value = lean_bridge_owned_48d801817da6928541ff452a_t82551d965c182180b0dd_itemsBounded(value, lean_box(limit));
  if (!value || lean_is_scalar(value) || !lean_is_array(value)) { if (value) lean_dec(value); return OV_RESULT; }
  size_t count = lean_array_size(value);
  if (count > limit) { lean_dec(value); return LB_OWNED_LIMIT; }
  void *raw = NULL;
  status = ov_allocate(transaction, count, sizeof(lbov_1d643ee3fbc2aa924d28_t6de8e950bc342c30091c), &raw);
  out->data = raw; out->length = count; lbov_1d643ee3fbc2aa924d28_t6de8e950bc342c30091c *data = raw;
  for (size_t i = 0; !status && i < count; ++i) {
    lean_object *child = lean_array_get_core(value, i); lean_inc(child);
    status = lbov_1d643ee3fbc2aa924d28_v6de8e950bc342c30091c_out(data + i, child, depth + 1, transaction);
  }
  lean_dec(value); return status;
}
static inline int lbov_1d643ee3fbc2aa924d28_v659ec6a690764999d00d_in(const lbov_1d643ee3fbc2aa924d28_t659ec6a690764999d00d *value, size_t depth, int storage, ov_transaction *transaction, lean_object **out) {
  *out = NULL;
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_1d643ee3fbc2aa924d28_t659ec6a690764999d00d))) return LB_OWNED_INVALID;
  int status = ov_enter(&transaction->budget, value, 1, depth);
  if (!status && storage) status = ov_charge(&transaction->budget, 1, sizeof(*value));
  if (status) return status;
  if (value->length > transaction->budget.visits) return LB_OWNED_LIMIT;
  status = ov_span(&transaction->budget, value->data, value->length, sizeof(lbov_1d643ee3fbc2aa924d28_t6de8e950bc342c30091c), _Alignof(lbov_1d643ee3fbc2aa924d28_t6de8e950bc342c30091c));
  if (status) return status;
  lean_object *items = lean_alloc_array(0, value->length);
  for (size_t i = 0; i < value->length; ++i) {
    lean_object *child = NULL;
    status = lbov_1d643ee3fbc2aa924d28_v6de8e950bc342c30091c_in(value->data + i, depth + 1, 0, transaction, &child);
    if (status) { lean_dec(items); return status; }
    items = lean_array_push(items, child);
  }
  return ov_finish(lean_bridge_owned_48d801817da6928541ff452a_t659ec6a690764999d00d_make(items), out);
}
static inline int lbov_1d643ee3fbc2aa924d28_v659ec6a690764999d00d_out(lbov_1d643ee3fbc2aa924d28_t659ec6a690764999d00d *out, lean_object *value, size_t depth, ov_transaction *transaction) {
  int status = ov_visit(&transaction->budget, depth);
  if (status) { if (value) lean_dec(value); return status; }
  if (!ov_carrier(value)) { if (value) lean_dec(value); return OV_RESULT; }
  size_t limit = transaction->budget.bytes / sizeof(lbov_1d643ee3fbc2aa924d28_t6de8e950bc342c30091c);
  if (limit > transaction->budget.visits) limit = transaction->budget.visits;
  if (depth == 128) limit = 0;
  size_t remaining = LB_OWNED_RETAINED_LIMIT - transaction->scope.retained;
  if (limit > remaining) limit = remaining;
  value = lean_bridge_owned_48d801817da6928541ff452a_t659ec6a690764999d00d_itemsBounded(value, lean_box(limit));
  if (!value || lean_is_scalar(value) || !lean_is_array(value)) { if (value) lean_dec(value); return OV_RESULT; }
  size_t count = lean_array_size(value);
  if (count > limit) { lean_dec(value); return LB_OWNED_LIMIT; }
  void *raw = NULL;
  status = ov_allocate(transaction, count, sizeof(lbov_1d643ee3fbc2aa924d28_t6de8e950bc342c30091c), &raw);
  out->data = raw; out->length = count; lbov_1d643ee3fbc2aa924d28_t6de8e950bc342c30091c *data = raw;
  for (size_t i = 0; !status && i < count; ++i) {
    lean_object *child = lean_array_get_core(value, i); lean_inc(child);
    status = lbov_1d643ee3fbc2aa924d28_v6de8e950bc342c30091c_out(data + i, child, depth + 1, transaction);
  }
  lean_dec(value); return status;
}
static inline int lbov_1d643ee3fbc2aa924d28_v817592654f48ba756bd4_in(const lbov_1d643ee3fbc2aa924d28_t817592654f48ba756bd4 *value, size_t depth, int storage, ov_transaction *transaction, lean_object **out) {
  *out = NULL;
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_1d643ee3fbc2aa924d28_t817592654f48ba756bd4))) return LB_OWNED_INVALID;
  int status = ov_enter(&transaction->budget, value, 2, depth);
  if (!status && storage) status = ov_charge(&transaction->budget, 1, sizeof(*value));
  if (status) return status;
  if (value->tag > 1) return LB_OWNED_INVALID;
  if (!value->tag) return ov_finish(lean_bridge_owned_48d801817da6928541ff452a_t817592654f48ba756bd4_none(lean_box(0)), out);
  if (value->tag == 1) {
    lean_object *child = NULL;
    status = lbov_1d643ee3fbc2aa924d28_v6de8e950bc342c30091c_in(&value->f0, depth + 1, 0, transaction, &child);
    if (status) return status;
    return ov_finish(lean_bridge_owned_48d801817da6928541ff452a_t817592654f48ba756bd4_make0(child), out);
  }
  return LB_OWNED_INVALID;
}
static inline int lbov_1d643ee3fbc2aa924d28_v817592654f48ba756bd4_out(lbov_1d643ee3fbc2aa924d28_t817592654f48ba756bd4 *out, lean_object *value, size_t depth, ov_transaction *transaction) {
  int status = ov_visit(&transaction->budget, depth);
  if (status) { if (value) lean_dec(value); return status; }
  if (!ov_carrier(value)) { if (value) lean_dec(value); return OV_RESULT; }
  lean_inc(value);
  uint32_t tag = lean_bridge_owned_48d801817da6928541ff452a_t817592654f48ba756bd4_branch(value);
  if (tag > 1) { lean_dec(value); return OV_RESULT; }
  out->tag = (uint8_t)tag;
  if (out->tag == 1) {
  if (!status) {
    if (!status) {
      lean_inc(value);
      status = lbov_1d643ee3fbc2aa924d28_v6de8e950bc342c30091c_out(&out->f0, lean_bridge_owned_48d801817da6928541ff452a_t817592654f48ba756bd4_field0(value), depth + 1, transaction);
    }
  }
  }
  lean_dec(value); return status;
}
static inline int lbov_1d643ee3fbc2aa924d28_v6f9a0eb5450512cec111_in(const lbov_1d643ee3fbc2aa924d28_t6f9a0eb5450512cec111 *value, size_t depth, int storage, ov_transaction *transaction, lean_object **out) {
  *out = NULL;
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_1d643ee3fbc2aa924d28_t6f9a0eb5450512cec111))) return LB_OWNED_INVALID;
  int status = ov_enter(&transaction->budget, value, 3, depth);
  if (!status && storage) status = ov_charge(&transaction->budget, 1, sizeof(*value));
  if (status) return status;
  lean_object *child = NULL;
  status = transaction->input_transfer
  ? lb_owned_scope_transfer_borrow(&transaction->scope, transaction->input_owner, "callable:owned-subtypes@1.0.0:bridge:Callback40c82bf938a942cf2402", value->token, &child)
  : lb_owned_scope_borrow(&transaction->scope, "callable:owned-subtypes@1.0.0:bridge:Callback40c82bf938a942cf2402", value->token, &child);
  if (status) return status;
  lean_inc(child); return ov_finish(ov_carry(child), out);
}
static inline int lbov_1d643ee3fbc2aa924d28_v6f9a0eb5450512cec111_out(lbov_1d643ee3fbc2aa924d28_t6f9a0eb5450512cec111 *out, lean_object *value, size_t depth, ov_transaction *transaction) {
  int status = ov_visit(&transaction->budget, depth);
  if (status) { if (value) lean_dec(value); return status; }
  if (!ov_carrier(value)) { if (value) lean_dec(value); return OV_RESULT; }
  lean_object *child = lean_array_get_core(value, 0);
  if (lean_is_scalar(child)) { lean_dec(value); return OV_RESULT; }
  if (lean_is_scalar(child) || !lean_is_closure(child)) { lean_dec(value); return OV_RESULT; }
  status = lb_owned_scope_acquire(&transaction->scope, "callable:owned-subtypes@1.0.0:bridge:Callback40c82bf938a942cf2402", child, &out->token);
  lean_dec(value); return status;
}
__attribute__((noinline)) static lean_object *lbov_1d643ee3fbc2aa924d28_v5faad500583201774348_make(lean_object *items) {
  lean_object *a0 = lean_array_get_core(items, 0); lean_inc(a0);
  lean_object *a1 = lean_array_get_core(items, 1); lean_inc(a1);
  lean_object *a2 = lean_array_get_core(items, 2); lean_inc(a2);
  lean_object *a3 = lean_array_get_core(items, 3); lean_inc(a3);
  lean_object *a4 = lean_array_get_core(items, 4); lean_inc(a4);
  lean_dec(items);
  return lean_bridge_owned_48d801817da6928541ff452a_t5faad500583201774348_make(a0, a1, a2, a3, a4);
}
static inline int lbov_1d643ee3fbc2aa924d28_v5faad500583201774348_in(const lbov_1d643ee3fbc2aa924d28_t5faad500583201774348 *value, size_t depth, int storage, ov_transaction *transaction, lean_object **out) {
  *out = NULL;
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_1d643ee3fbc2aa924d28_t5faad500583201774348))) return LB_OWNED_INVALID;
  int status = ov_enter(&transaction->budget, value, 4, depth);
  if (!status && storage) status = ov_charge(&transaction->budget, 1, sizeof(*value));
  if (status) return status;
  lean_object *items = lean_alloc_array(0, 5);
  lean_object *child = NULL;
  status = lbov_1d643ee3fbc2aa924d28_v6de8e950bc342c30091c_in(&value->f0, depth + 1, 0, transaction, &child);
  if (status) { lean_dec(items); return status; }
  items = lean_array_push(items, child);
  status = lbov_1d643ee3fbc2aa924d28_v817592654f48ba756bd4_in(value->f1, depth + 1, 1, transaction, &child);
  if (status) { lean_dec(items); return status; }
  items = lean_array_push(items, child);
  status = lbov_1d643ee3fbc2aa924d28_v659ec6a690764999d00d_in(value->f2, depth + 1, 1, transaction, &child);
  if (status) { lean_dec(items); return status; }
  items = lean_array_push(items, child);
  status = lbov_1d643ee3fbc2aa924d28_v82551d965c182180b0dd_in(value->f3, depth + 1, 1, transaction, &child);
  if (status) { lean_dec(items); return status; }
  items = lean_array_push(items, child);
  status = lbov_1d643ee3fbc2aa924d28_v550e0acb733e8dd08e4e_in(value->f4, depth + 1, 1, transaction, &child);
  if (status) { lean_dec(items); return status; }
  items = lean_array_push(items, child);
  return ov_finish(lbov_1d643ee3fbc2aa924d28_v5faad500583201774348_make(items), out);
}
static inline int lbov_1d643ee3fbc2aa924d28_v5faad500583201774348_out(lbov_1d643ee3fbc2aa924d28_t5faad500583201774348 *out, lean_object *value, size_t depth, ov_transaction *transaction) {
  int status = ov_visit(&transaction->budget, depth);
  if (status) { if (value) lean_dec(value); return status; }
  if (!ov_carrier(value)) { if (value) lean_dec(value); return OV_RESULT; }
  if (!status) {
    if (!status) {
      lean_inc(value);
      status = lbov_1d643ee3fbc2aa924d28_v6de8e950bc342c30091c_out(&out->f0, lean_bridge_owned_48d801817da6928541ff452a_t5faad500583201774348_field0(value), depth + 1, transaction);
    }
  }
  if (!status) {
    void *raw = NULL;
    status = ov_allocate(transaction, 1, sizeof(lbov_1d643ee3fbc2aa924d28_t817592654f48ba756bd4), &raw);
    out->f1 = raw;
    if (!status) {
      lean_inc(value);
      status = lbov_1d643ee3fbc2aa924d28_v817592654f48ba756bd4_out(raw, lean_bridge_owned_48d801817da6928541ff452a_t5faad500583201774348_field1(value), depth + 1, transaction);
    }
  }
  if (!status) {
    void *raw = NULL;
    status = ov_allocate(transaction, 1, sizeof(lbov_1d643ee3fbc2aa924d28_t659ec6a690764999d00d), &raw);
    out->f2 = raw;
    if (!status) {
      lean_inc(value);
      status = lbov_1d643ee3fbc2aa924d28_v659ec6a690764999d00d_out(raw, lean_bridge_owned_48d801817da6928541ff452a_t5faad500583201774348_field2(value), depth + 1, transaction);
    }
  }
  if (!status) {
    void *raw = NULL;
    status = ov_allocate(transaction, 1, sizeof(lbov_1d643ee3fbc2aa924d28_t82551d965c182180b0dd), &raw);
    out->f3 = raw;
    if (!status) {
      lean_inc(value);
      status = lbov_1d643ee3fbc2aa924d28_v82551d965c182180b0dd_out(raw, lean_bridge_owned_48d801817da6928541ff452a_t5faad500583201774348_field3(value), depth + 1, transaction);
    }
  }
  if (!status) {
    void *raw = NULL;
    status = ov_allocate(transaction, 1, sizeof(lbov_1d643ee3fbc2aa924d28_t550e0acb733e8dd08e4e), &raw);
    out->f4 = raw;
    if (!status) {
      lean_inc(value);
      status = lbov_1d643ee3fbc2aa924d28_v550e0acb733e8dd08e4e_out(raw, lean_bridge_owned_48d801817da6928541ff452a_t5faad500583201774348_field4(value), depth + 1, transaction);
    }
  }
  lean_dec(value); return status;
}
__attribute__((noinline)) static lean_object *lbov_1d643ee3fbc2aa924d28_v37c6db88a97448412ed0_make(lean_object *items) {
  lean_object *a0 = lean_array_get_core(items, 0); lean_inc(a0);
  lean_object *a1 = lean_array_get_core(items, 1); lean_inc(a1);
  lean_dec(items);
  return lean_bridge_owned_48d801817da6928541ff452a_t37c6db88a97448412ed0_make(a0, a1);
}
static inline int lbov_1d643ee3fbc2aa924d28_v37c6db88a97448412ed0_in(const lbov_1d643ee3fbc2aa924d28_t37c6db88a97448412ed0 *value, size_t depth, int storage, ov_transaction *transaction, lean_object **out) {
  *out = NULL;
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_1d643ee3fbc2aa924d28_t37c6db88a97448412ed0))) return LB_OWNED_INVALID;
  int status = ov_enter(&transaction->budget, value, 5, depth);
  if (!status && storage) status = ov_charge(&transaction->budget, 1, sizeof(*value));
  if (status) return status;
  lean_object *items = lean_alloc_array(0, 2);
  lean_object *child = NULL;
  status = lbov_1d643ee3fbc2aa924d28_v6de8e950bc342c30091c_in(&value->f0, depth + 1, 0, transaction, &child);
  if (status) { lean_dec(items); return status; }
  items = lean_array_push(items, child);
  status = lbov_1d643ee3fbc2aa924d28_vf197109068e846c0739c_in(value->f1, depth + 1, 1, transaction, &child);
  if (status) { lean_dec(items); return status; }
  items = lean_array_push(items, child);
  return ov_finish(lbov_1d643ee3fbc2aa924d28_v37c6db88a97448412ed0_make(items), out);
}
static inline int lbov_1d643ee3fbc2aa924d28_v37c6db88a97448412ed0_out(lbov_1d643ee3fbc2aa924d28_t37c6db88a97448412ed0 *out, lean_object *value, size_t depth, ov_transaction *transaction) {
  int status = ov_visit(&transaction->budget, depth);
  if (status) { if (value) lean_dec(value); return status; }
  if (!ov_carrier(value)) { if (value) lean_dec(value); return OV_RESULT; }
  if (!status) {
    if (!status) {
      lean_inc(value);
      status = lbov_1d643ee3fbc2aa924d28_v6de8e950bc342c30091c_out(&out->f0, lean_bridge_owned_48d801817da6928541ff452a_t37c6db88a97448412ed0_field0(value), depth + 1, transaction);
    }
  }
  if (!status) {
    void *raw = NULL;
    status = ov_allocate(transaction, 1, sizeof(lbov_1d643ee3fbc2aa924d28_tf197109068e846c0739c), &raw);
    out->f1 = raw;
    if (!status) {
      lean_inc(value);
      status = lbov_1d643ee3fbc2aa924d28_vf197109068e846c0739c_out(raw, lean_bridge_owned_48d801817da6928541ff452a_t37c6db88a97448412ed0_field1(value), depth + 1, transaction);
    }
  }
  lean_dec(value); return status;
}
__attribute__((noinline)) static lean_object *lbov_1d643ee3fbc2aa924d28_vf197109068e846c0739c_make(lean_object *items) {
  lean_object *a0 = lean_array_get_core(items, 0); lean_inc(a0);
  lean_object *a1 = lean_array_get_core(items, 1); lean_inc(a1);
  lean_dec(items);
  return lean_bridge_owned_48d801817da6928541ff452a_tf197109068e846c0739c_make(a0, a1);
}
static inline int lbov_1d643ee3fbc2aa924d28_vf197109068e846c0739c_in(const lbov_1d643ee3fbc2aa924d28_tf197109068e846c0739c *value, size_t depth, int storage, ov_transaction *transaction, lean_object **out) {
  *out = NULL;
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_1d643ee3fbc2aa924d28_tf197109068e846c0739c))) return LB_OWNED_INVALID;
  int status = ov_enter(&transaction->budget, value, 6, depth);
  if (!status && storage) status = ov_charge(&transaction->budget, 1, sizeof(*value));
  if (status) return status;
  lean_object *items = lean_alloc_array(0, 2);
  lean_object *child = NULL;
  status = lbov_1d643ee3fbc2aa924d28_v11140334dba7a15b6b99_in(&value->f0, depth + 1, 0, transaction, &child);
  if (status) { lean_dec(items); return status; }
  items = lean_array_push(items, child);
  status = lbov_1d643ee3fbc2aa924d28_vf098e5912ebfda269f53_in(&value->f1, depth + 1, 0, transaction, &child);
  if (status) { lean_dec(items); return status; }
  items = lean_array_push(items, child);
  return ov_finish(lbov_1d643ee3fbc2aa924d28_vf197109068e846c0739c_make(items), out);
}
static inline int lbov_1d643ee3fbc2aa924d28_vf197109068e846c0739c_out(lbov_1d643ee3fbc2aa924d28_tf197109068e846c0739c *out, lean_object *value, size_t depth, ov_transaction *transaction) {
  int status = ov_visit(&transaction->budget, depth);
  if (status) { if (value) lean_dec(value); return status; }
  if (!ov_carrier(value)) { if (value) lean_dec(value); return OV_RESULT; }
  if (!status) {
    if (!status) {
      lean_inc(value);
      status = lbov_1d643ee3fbc2aa924d28_v11140334dba7a15b6b99_out(&out->f0, lean_bridge_owned_48d801817da6928541ff452a_tf197109068e846c0739c_field0(value), depth + 1, transaction);
    }
  }
  if (!status) {
    if (!status) {
      lean_inc(value);
      status = lbov_1d643ee3fbc2aa924d28_vf098e5912ebfda269f53_out(&out->f1, lean_bridge_owned_48d801817da6928541ff452a_tf197109068e846c0739c_field1(value), depth + 1, transaction);
    }
  }
  lean_dec(value); return status;
}
__attribute__((noinline)) static lean_object *lbov_1d643ee3fbc2aa924d28_v550e0acb733e8dd08e4e_make(lean_object *items) {
  lean_object *a0 = lean_array_get_core(items, 0); lean_inc(a0);
  lean_object *a1 = lean_array_get_core(items, 1); lean_inc(a1);
  lean_dec(items);
  return lean_bridge_owned_48d801817da6928541ff452a_t550e0acb733e8dd08e4e_make(a0, a1);
}
static inline int lbov_1d643ee3fbc2aa924d28_v550e0acb733e8dd08e4e_in(const lbov_1d643ee3fbc2aa924d28_t550e0acb733e8dd08e4e *value, size_t depth, int storage, ov_transaction *transaction, lean_object **out) {
  *out = NULL;
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_1d643ee3fbc2aa924d28_t550e0acb733e8dd08e4e))) return LB_OWNED_INVALID;
  int status = ov_enter(&transaction->budget, value, 7, depth);
  if (!status && storage) status = ov_charge(&transaction->budget, 1, sizeof(*value));
  if (status) return status;
  lean_object *items = lean_alloc_array(0, 2);
  lean_object *child = NULL;
  status = lbov_1d643ee3fbc2aa924d28_v11140334dba7a15b6b99_in(&value->f0, depth + 1, 0, transaction, &child);
  if (status) { lean_dec(items); return status; }
  items = lean_array_push(items, child);
  status = lbov_1d643ee3fbc2aa924d28_vf098e5912ebfda269f53_in(&value->f1, depth + 1, 0, transaction, &child);
  if (status) { lean_dec(items); return status; }
  items = lean_array_push(items, child);
  return ov_finish(lbov_1d643ee3fbc2aa924d28_v550e0acb733e8dd08e4e_make(items), out);
}
static inline int lbov_1d643ee3fbc2aa924d28_v550e0acb733e8dd08e4e_out(lbov_1d643ee3fbc2aa924d28_t550e0acb733e8dd08e4e *out, lean_object *value, size_t depth, ov_transaction *transaction) {
  int status = ov_visit(&transaction->budget, depth);
  if (status) { if (value) lean_dec(value); return status; }
  if (!ov_carrier(value)) { if (value) lean_dec(value); return OV_RESULT; }
  if (!status) {
    if (!status) {
      lean_inc(value);
      status = lbov_1d643ee3fbc2aa924d28_v11140334dba7a15b6b99_out(&out->f0, lean_bridge_owned_48d801817da6928541ff452a_t550e0acb733e8dd08e4e_field0(value), depth + 1, transaction);
    }
  }
  if (!status) {
    if (!status) {
      lean_inc(value);
      status = lbov_1d643ee3fbc2aa924d28_vf098e5912ebfda269f53_out(&out->f1, lean_bridge_owned_48d801817da6928541ff452a_t550e0acb733e8dd08e4e_field1(value), depth + 1, transaction);
    }
  }
  lean_dec(value); return status;
}
static inline int lbov_1d643ee3fbc2aa924d28_v6de8e950bc342c30091c_in(const lbov_1d643ee3fbc2aa924d28_t6de8e950bc342c30091c *value, size_t depth, int storage, ov_transaction *transaction, lean_object **out) {
  *out = NULL;
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_1d643ee3fbc2aa924d28_t6de8e950bc342c30091c))) return LB_OWNED_INVALID;
  int status = ov_enter(&transaction->budget, value, 8, depth);
  if (!status && storage) status = ov_charge(&transaction->budget, 1, sizeof(*value));
  if (status) return status;
  lean_object *child = NULL;
  status = transaction->input_transfer
  ? lb_owned_scope_transfer_borrow(&transaction->scope, transaction->input_owner, "resource:Owned.Ticket", value->token, &child)
  : lb_owned_scope_borrow(&transaction->scope, "resource:Owned.Ticket", value->token, &child);
  if (status) return status;
  lean_inc(child); return ov_finish(ov_carry(child), out);
}
static inline int lbov_1d643ee3fbc2aa924d28_v6de8e950bc342c30091c_out(lbov_1d643ee3fbc2aa924d28_t6de8e950bc342c30091c *out, lean_object *value, size_t depth, ov_transaction *transaction) {
  int status = ov_visit(&transaction->budget, depth);
  if (status) { if (value) lean_dec(value); return status; }
  if (!ov_carrier(value)) { if (value) lean_dec(value); return OV_RESULT; }
  lean_object *child = lean_array_get_core(value, 0);
  if (lean_is_scalar(child)) { lean_dec(value); return OV_RESULT; }
  status = lb_owned_scope_acquire(&transaction->scope, "resource:Owned.Ticket", child, &out->token);
  lean_dec(value); return status;
}
static inline int lbov_1d643ee3fbc2aa924d28_vf098e5912ebfda269f53_in(const lbov_1d643ee3fbc2aa924d28_tf098e5912ebfda269f53 *value, size_t depth, int storage, ov_transaction *transaction, lean_object **out) {
  *out = NULL;
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_1d643ee3fbc2aa924d28_tf098e5912ebfda269f53))) return LB_OWNED_INVALID;
  int status = ov_enter(&transaction->budget, value, 9, depth);
  if (!status && storage) status = ov_charge(&transaction->budget, 1, sizeof(*value));
  if (status) return status;
  status = ov_span(&transaction->budget, value->data, value->length, 1, 1);
  if (status) return status;
  lean_object *bytes = lean_alloc_sarray(1, value->length, value->length);
  if (value->length) memcpy(lean_sarray_cptr(bytes), value->data, value->length);
  return ov_finish(ov_carry(bytes), out);
}
static inline int lbov_1d643ee3fbc2aa924d28_vf098e5912ebfda269f53_out(lbov_1d643ee3fbc2aa924d28_tf098e5912ebfda269f53 *out, lean_object *value, size_t depth, ov_transaction *transaction) {
  int status = ov_visit(&transaction->budget, depth);
  if (status) { if (value) lean_dec(value); return status; }
  if (!ov_carrier(value)) { if (value) lean_dec(value); return OV_RESULT; }
  lean_object *child = lean_array_get_core(value, 0); lean_inc(child); lean_dec(value);
  if (lean_is_scalar(child) || !lean_is_sarray(child)) { lean_dec(child); return OV_RESULT; }
  if (lean_sarray_elem_size(child) != 1) { lean_dec(child); return OV_RESULT; }
  size_t length = lean_sarray_size(child);
  void *data = NULL;
  status = ov_allocate(transaction, length, 1, &data);
  if (!status) {
    if (length) memcpy(data, lean_sarray_cptr(child), length);
    out->data = data; out->length = length;
  }
  lean_dec(child); return status;
}
static inline int lbov_1d643ee3fbc2aa924d28_v11140334dba7a15b6b99_in(const lbov_1d643ee3fbc2aa924d28_t11140334dba7a15b6b99 *value, size_t depth, int storage, ov_transaction *transaction, lean_object **out) {
  *out = NULL;
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_1d643ee3fbc2aa924d28_t11140334dba7a15b6b99))) return LB_OWNED_INVALID;
  int status = ov_enter(&transaction->budget, value, 10, depth);
  if (!status && storage) status = ov_charge(&transaction->budget, 1, sizeof(*value));
  if (status) return status;
  status = ov_span(&transaction->budget, value->data, value->length, sizeof(uint32_t), _Alignof(uint32_t));
  if (status) return status;
  if (value->negative > 1) return LB_OWNED_INVALID;
  lean_object *integer = lean_nat_to_int(ov_nat_in(value->data, value->length));
  if (value->negative) { lean_object *negative = lean_int_neg(integer); lean_dec(integer); integer = negative; }
  return ov_finish(ov_carry(integer), out);
}
static inline int lbov_1d643ee3fbc2aa924d28_v11140334dba7a15b6b99_out(lbov_1d643ee3fbc2aa924d28_t11140334dba7a15b6b99 *out, lean_object *value, size_t depth, ov_transaction *transaction) {
  int status = ov_visit(&transaction->budget, depth);
  if (status) { if (value) lean_dec(value); return status; }
  if (!ov_carrier(value)) { if (value) lean_dec(value); return OV_RESULT; }
  lean_object *child = lean_array_get_core(value, 0); lean_inc(child); lean_dec(value);
  if (!lean_is_scalar(child) && !lean_is_mpz(child)) { lean_dec(child); return OV_RESULT; }
  out->negative = lean_int_lt(child, lean_box(0));
  lean_object *magnitude = lean_nat_abs(child); lean_dec(child); child = magnitude;
  status = ov_nat_out(child, transaction, &out->data, &out->length);
  lean_dec(child); return status;
}
static inline int lbov_1d643ee3fbc2aa924d28_v167081552b6f9c1d1afd_in(const lbov_1d643ee3fbc2aa924d28_t167081552b6f9c1d1afd *value, size_t depth, int storage, ov_transaction *transaction, lean_object **out) {
  *out = NULL;
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_1d643ee3fbc2aa924d28_t167081552b6f9c1d1afd))) return LB_OWNED_INVALID;
  int status = ov_enter(&transaction->budget, value, 11, depth);
  if (!status && storage) status = ov_charge(&transaction->budget, 1, sizeof(*value));
  if (status) return status;
  status = ov_span(&transaction->budget, value->data, value->length, sizeof(uint32_t), _Alignof(uint32_t));
  if (status) return status;
  return ov_finish(ov_carry(ov_nat_in(value->data, value->length)), out);
}
static inline int lbov_1d643ee3fbc2aa924d28_v167081552b6f9c1d1afd_out(lbov_1d643ee3fbc2aa924d28_t167081552b6f9c1d1afd *out, lean_object *value, size_t depth, ov_transaction *transaction) {
  int status = ov_visit(&transaction->budget, depth);
  if (status) { if (value) lean_dec(value); return status; }
  if (!ov_carrier(value)) { if (value) lean_dec(value); return OV_RESULT; }
  lean_object *child = lean_array_get_core(value, 0); lean_inc(child); lean_dec(value);
  if (!lean_is_scalar(child) && !lean_is_mpz(child)) { lean_dec(child); return OV_RESULT; }
  status = ov_nat_out(child, transaction, &out->data, &out->length);
  lean_dec(child); return status;
}
static inline int lbov_1d643ee3fbc2aa924d28_vdc0347e1f7f5c4d928f1_in(const lbov_1d643ee3fbc2aa924d28_tdc0347e1f7f5c4d928f1 *value, size_t depth, int storage, ov_transaction *transaction, lean_object **out) {
  *out = NULL;
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_1d643ee3fbc2aa924d28_tdc0347e1f7f5c4d928f1))) return LB_OWNED_INVALID;
  int status = ov_enter(&transaction->budget, value, 12, depth);
  if (!status && storage) status = ov_charge(&transaction->budget, 1, sizeof(*value));
  if (status) return status;
  status = ov_span(&transaction->budget, value->data, value->length, 1, 1);
  if (status) return status;
  if (!ov_utf8((const uint8_t *)value->data, value->length)) return LB_OWNED_INVALID;
  return ov_finish(ov_carry(lean_mk_string_from_bytes(value->length ? value->data : "", value->length)), out);
}
static inline int lbov_1d643ee3fbc2aa924d28_vdc0347e1f7f5c4d928f1_out(lbov_1d643ee3fbc2aa924d28_tdc0347e1f7f5c4d928f1 *out, lean_object *value, size_t depth, ov_transaction *transaction) {
  int status = ov_visit(&transaction->budget, depth);
  if (status) { if (value) lean_dec(value); return status; }
  if (!ov_carrier(value)) { if (value) lean_dec(value); return OV_RESULT; }
  lean_object *child = lean_array_get_core(value, 0); lean_inc(child); lean_dec(value);
  if (lean_is_scalar(child) || !lean_is_string(child)) { lean_dec(child); return OV_RESULT; }
  size_t length = lean_string_size(child) - 1;
  if (!ov_utf8((const uint8_t *)lean_string_cstr(child), length)) { lean_dec(child); return OV_RESULT; }
  void *data = NULL;
  status = ov_allocate(transaction, length, 1, &data);
  if (!status) {
    if (length) memcpy(data, lean_string_cstr(child), length);
    out->data = data; out->length = length;
  }
  lean_dec(child); return status;
}
static inline int lbov_1d643ee3fbc2aa924d28_f0838f7ed39f0edac01d9(lb_owned_context *context, const lbov_1d643ee3fbc2aa924d28_t37c6db88a97448412ed0 *a0, const lbov_1d643ee3fbc2aa924d28_t6f9a0eb5450512cec111 *a1, lbov_1d643ee3fbc2aa924d28_t37c6db88a97448412ed0 *out, ov_result_owner *owner) {
  if (!ov_pointer(out, sizeof(*out), _Alignof(lbov_1d643ee3fbc2aa924d28_t37c6db88a97448412ed0)) || !ov_pointer(owner, sizeof(*owner), _Alignof(ov_result_owner))) return LB_OWNED_INVALID;
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-subtypes@1.0.0");
  if (status) return status;
  status = ov_charge(&transaction.budget, 1, sizeof(*out));
  if (status) return ov_abort(&transaction, status);
  lean_object *arguments = lean_alloc_array(0, 2);
  {
    lean_object *child = NULL;
    status = lbov_1d643ee3fbc2aa924d28_v37c6db88a97448412ed0_in(a0, 0, 1, &transaction, &child);
    if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
    arguments = lean_array_push(arguments, child);
  }
  {
    lean_object *child = NULL;
    status = lbov_1d643ee3fbc2aa924d28_v6f9a0eb5450512cec111_in(a1, 0, 1, &transaction, &child);
    if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
    arguments = lean_array_push(arguments, child);
  }
  lean_object *v0 = lean_array_get_core(arguments, 0); lean_inc(v0);
  lean_object *v1 = lean_array_get_core(arguments, 1); lean_inc(v1);
  lean_dec(arguments);
  ov_callback_frame frame = { .parent = ov_active_callback_frame, .transaction = &transaction };
  if (!frame.parent) { (void)lb_native_callback_take_error(); (void)lean_bridge_owned_callback_failure_1d643ee3fbc2aa924d28(); }
  ov_active_callback_frame = &frame;
  lean_object *returned = lean_bridge_owned_48d801817da6928541ff452a_f0838f7ed39f0edac01d9(v0, v1);
  ov_active_callback_frame = frame.parent; status = frame.status;
  int callback_error = lb_native_callback_take_error();
  int refinement_error = lean_bridge_owned_callback_failure_1d643ee3fbc2aa924d28();
  if (refinement_error && !status) status = LB_OWNED_INVALID;
  else if (callback_error && !status) status = OV_CALLBACK;
  if (!status) status = lb_owned_scope_ready(&transaction.scope);
  if (status) { lean_dec(returned); return ov_abort(&transaction, status); }
  lbov_1d643ee3fbc2aa924d28_t37c6db88a97448412ed0 converted = {0};
  status = lbov_1d643ee3fbc2aa924d28_v37c6db88a97448412ed0_out(&converted, returned, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  status = ov_commit(&transaction, owner);
  if (!status) *out = converted;
  return status;
}
static inline int lbov_1d643ee3fbc2aa924d28_f080cb47999bb83cdc0c1(lb_owned_context *context, const lbov_1d643ee3fbc2aa924d28_t5faad500583201774348 *a0, lbov_1d643ee3fbc2aa924d28_t5faad500583201774348 *out, ov_result_owner *owner) {
  if (!ov_pointer(out, sizeof(*out), _Alignof(lbov_1d643ee3fbc2aa924d28_t5faad500583201774348)) || !ov_pointer(owner, sizeof(*owner), _Alignof(ov_result_owner))) return LB_OWNED_INVALID;
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-subtypes@1.0.0");
  if (status) return status;
  status = ov_charge(&transaction.budget, 1, sizeof(*out));
  if (status) return ov_abort(&transaction, status);
  lean_object *arguments = lean_alloc_array(0, 1);
  {
    lean_object *child = NULL;
    status = lbov_1d643ee3fbc2aa924d28_v5faad500583201774348_in(a0, 0, 1, &transaction, &child);
    if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
    lean_inc(child);
    if (!lean_bridge_owned_refine_14adb93498676f4c30f0(child)) { lean_dec(child); lean_dec(arguments); return ov_abort(&transaction, LB_OWNED_INVALID); }
    arguments = lean_array_push(arguments, child);
  }
  lean_object *v0 = lean_array_get_core(arguments, 0); lean_inc(v0);
  lean_dec(arguments);
  ov_callback_frame frame = { .parent = ov_active_callback_frame, .transaction = &transaction };
  if (!frame.parent) { (void)lb_native_callback_take_error(); (void)lean_bridge_owned_callback_failure_1d643ee3fbc2aa924d28(); }
  ov_active_callback_frame = &frame;
  lean_object *returned = lean_bridge_owned_48d801817da6928541ff452a_f080cb47999bb83cdc0c1(v0);
  ov_active_callback_frame = frame.parent; status = frame.status;
  int callback_error = lb_native_callback_take_error();
  int refinement_error = lean_bridge_owned_callback_failure_1d643ee3fbc2aa924d28();
  if (refinement_error && !status) status = LB_OWNED_INVALID;
  else if (callback_error && !status) status = OV_CALLBACK;
  if (!status) status = lb_owned_scope_ready(&transaction.scope);
  if (status) { lean_dec(returned); return ov_abort(&transaction, status); }
  lbov_1d643ee3fbc2aa924d28_t5faad500583201774348 converted = {0};
  status = lbov_1d643ee3fbc2aa924d28_v5faad500583201774348_out(&converted, returned, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  status = ov_commit(&transaction, owner);
  if (!status) *out = converted;
  return status;
}
static inline int lbov_1d643ee3fbc2aa924d28_f579c430cd49e7c98161f(lb_owned_context *context, const lbov_1d643ee3fbc2aa924d28_t5faad500583201774348 *a0, lbov_1d643ee3fbc2aa924d28_t5faad500583201774348 *out, ov_result_owner *owner) {
  if (!ov_pointer(out, sizeof(*out), _Alignof(lbov_1d643ee3fbc2aa924d28_t5faad500583201774348)) || !ov_pointer(owner, sizeof(*owner), _Alignof(ov_result_owner))) return LB_OWNED_INVALID;
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-subtypes@1.0.0");
  if (status) return status;
  status = ov_charge(&transaction.budget, 1, sizeof(*out));
  if (status) return ov_abort(&transaction, status);
  lean_object *arguments = lean_alloc_array(0, 1);
  {
    lean_object *child = NULL;
    status = lbov_1d643ee3fbc2aa924d28_v5faad500583201774348_in(a0, 0, 1, &transaction, &child);
    if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
    lean_inc(child);
    if (!lean_bridge_owned_refine_a32d032838dcef0ffcc0(child)) { lean_dec(child); lean_dec(arguments); return ov_abort(&transaction, LB_OWNED_INVALID); }
    arguments = lean_array_push(arguments, child);
  }
  lean_object *v0 = lean_array_get_core(arguments, 0); lean_inc(v0);
  lean_dec(arguments);
  ov_callback_frame frame = { .parent = ov_active_callback_frame, .transaction = &transaction };
  if (!frame.parent) { (void)lb_native_callback_take_error(); (void)lean_bridge_owned_callback_failure_1d643ee3fbc2aa924d28(); }
  ov_active_callback_frame = &frame;
  lean_object *returned = lean_bridge_owned_48d801817da6928541ff452a_f579c430cd49e7c98161f(v0);
  ov_active_callback_frame = frame.parent; status = frame.status;
  int callback_error = lb_native_callback_take_error();
  int refinement_error = lean_bridge_owned_callback_failure_1d643ee3fbc2aa924d28();
  if (refinement_error && !status) status = LB_OWNED_INVALID;
  else if (callback_error && !status) status = OV_CALLBACK;
  if (!status) status = lb_owned_scope_ready(&transaction.scope);
  if (status) { lean_dec(returned); return ov_abort(&transaction, status); }
  lbov_1d643ee3fbc2aa924d28_t5faad500583201774348 converted = {0};
  status = lbov_1d643ee3fbc2aa924d28_v5faad500583201774348_out(&converted, returned, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  status = ov_commit(&transaction, owner);
  if (!status) *out = converted;
  return status;
}
static inline int lbov_1d643ee3fbc2aa924d28_f9735b5a0a586b46ce0b8(lb_owned_context *context, const lbov_1d643ee3fbc2aa924d28_t167081552b6f9c1d1afd *a0, const lbov_1d643ee3fbc2aa924d28_tdc0347e1f7f5c4d928f1 *a1, lbov_1d643ee3fbc2aa924d28_t6de8e950bc342c30091c *out, ov_result_owner *owner) {
  if (!ov_pointer(out, sizeof(*out), _Alignof(lbov_1d643ee3fbc2aa924d28_t6de8e950bc342c30091c)) || !ov_pointer(owner, sizeof(*owner), _Alignof(ov_result_owner))) return LB_OWNED_INVALID;
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-subtypes@1.0.0");
  if (status) return status;
  status = ov_charge(&transaction.budget, 1, sizeof(*out));
  if (status) return ov_abort(&transaction, status);
  lean_object *arguments = lean_alloc_array(0, 2);
  {
    lean_object *child = NULL;
    status = lbov_1d643ee3fbc2aa924d28_v167081552b6f9c1d1afd_in(a0, 0, 1, &transaction, &child);
    if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
    arguments = lean_array_push(arguments, child);
  }
  {
    lean_object *child = NULL;
    status = lbov_1d643ee3fbc2aa924d28_vdc0347e1f7f5c4d928f1_in(a1, 0, 1, &transaction, &child);
    if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
    arguments = lean_array_push(arguments, child);
  }
  lean_object *v0 = lean_array_get_core(arguments, 0); lean_inc(v0);
  lean_object *v1 = lean_array_get_core(arguments, 1); lean_inc(v1);
  lean_dec(arguments);
  ov_callback_frame frame = { .parent = ov_active_callback_frame, .transaction = &transaction };
  if (!frame.parent) { (void)lb_native_callback_take_error(); (void)lean_bridge_owned_callback_failure_1d643ee3fbc2aa924d28(); }
  ov_active_callback_frame = &frame;
  lean_object *returned = lean_bridge_owned_48d801817da6928541ff452a_f9735b5a0a586b46ce0b8(v0, v1);
  ov_active_callback_frame = frame.parent; status = frame.status;
  int callback_error = lb_native_callback_take_error();
  int refinement_error = lean_bridge_owned_callback_failure_1d643ee3fbc2aa924d28();
  if (refinement_error && !status) status = LB_OWNED_INVALID;
  else if (callback_error && !status) status = OV_CALLBACK;
  if (!status) status = lb_owned_scope_ready(&transaction.scope);
  if (status) { lean_dec(returned); return ov_abort(&transaction, status); }
  lbov_1d643ee3fbc2aa924d28_t6de8e950bc342c30091c converted = {0};
  status = lbov_1d643ee3fbc2aa924d28_v6de8e950bc342c30091c_out(&converted, returned, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  status = ov_commit(&transaction, owner);
  if (!status) *out = converted;
  return status;
}
static inline int lbov_1d643ee3fbc2aa924d28_f52957d819a8a28259bf1(lb_owned_context *context, const lbov_1d643ee3fbc2aa924d28_t6de8e950bc342c30091c *a0, lbov_1d643ee3fbc2aa924d28_t167081552b6f9c1d1afd *out, ov_result_owner *owner) {
  if (!ov_pointer(out, sizeof(*out), _Alignof(lbov_1d643ee3fbc2aa924d28_t167081552b6f9c1d1afd)) || !ov_pointer(owner, sizeof(*owner), _Alignof(ov_result_owner))) return LB_OWNED_INVALID;
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-subtypes@1.0.0");
  if (status) return status;
  status = ov_charge(&transaction.budget, 1, sizeof(*out));
  if (status) return ov_abort(&transaction, status);
  lean_object *arguments = lean_alloc_array(0, 1);
  {
    lean_object *child = NULL;
    status = lbov_1d643ee3fbc2aa924d28_v6de8e950bc342c30091c_in(a0, 0, 1, &transaction, &child);
    if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
    arguments = lean_array_push(arguments, child);
  }
  lean_object *v0 = lean_array_get_core(arguments, 0); lean_inc(v0);
  lean_dec(arguments);
  ov_callback_frame frame = { .parent = ov_active_callback_frame, .transaction = &transaction };
  if (!frame.parent) { (void)lb_native_callback_take_error(); (void)lean_bridge_owned_callback_failure_1d643ee3fbc2aa924d28(); }
  ov_active_callback_frame = &frame;
  lean_object *returned = lean_bridge_owned_48d801817da6928541ff452a_f52957d819a8a28259bf1(v0);
  ov_active_callback_frame = frame.parent; status = frame.status;
  int callback_error = lb_native_callback_take_error();
  int refinement_error = lean_bridge_owned_callback_failure_1d643ee3fbc2aa924d28();
  if (refinement_error && !status) status = LB_OWNED_INVALID;
  else if (callback_error && !status) status = OV_CALLBACK;
  if (!status) status = lb_owned_scope_ready(&transaction.scope);
  if (status) { lean_dec(returned); return ov_abort(&transaction, status); }
  lbov_1d643ee3fbc2aa924d28_t167081552b6f9c1d1afd converted = {0};
  status = lbov_1d643ee3fbc2aa924d28_v167081552b6f9c1d1afd_out(&converted, returned, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  status = ov_commit(&transaction, owner);
  if (!status) *out = converted;
  return status;
}
static inline int lbov_1d643ee3fbc2aa924d28_f973a6e63b7dad7a3d147(lb_owned_context *context, const lbov_1d643ee3fbc2aa924d28_t5faad500583201774348 *a0, ov_input_transfers *transfer, lbov_1d643ee3fbc2aa924d28_t5faad500583201774348 *out, ov_result_owner *owner) {
  if (!ov_pointer(out, sizeof(*out), _Alignof(lbov_1d643ee3fbc2aa924d28_t5faad500583201774348)) || !ov_pointer(owner, sizeof(*owner), _Alignof(ov_result_owner))) return LB_OWNED_INVALID;
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-subtypes@1.0.0");
  if (status) return status;
  status = ov_charge(&transaction.budget, 1, sizeof(*out));
  if (status) return ov_abort(&transaction, status);
  lb_owned_batch *batches[1] = {0}; size_t batch_count = 0;
  status = ov_transfers_prepare(&transaction, transfer, 1, batches, &batch_count);
  if (status) return ov_abort(&transaction, status);
  lean_object *arguments = lean_alloc_array(0, 1);
  {
    lean_object *child = NULL;
    transaction.input_transfer = 1;
    transaction.input_owner = &transfer->owners[0]->batch;
    status = lbov_1d643ee3fbc2aa924d28_v5faad500583201774348_in(a0, 0, 1, &transaction, &child);
    if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
    lean_inc(child);
    if (!lean_bridge_owned_refine_14adb93498676f4c30f0(child)) { lean_dec(child); lean_dec(arguments); return ov_abort(&transaction, LB_OWNED_INVALID); }
    arguments = lean_array_push(arguments, child);
  }
  transaction.input_transfer = 0; transaction.input_owner = NULL;
  status = lb_owned_scope_transfer_many(&transaction.scope, batches, batch_count);
  if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
  transfer->consumed = 1; transfer->consume(transfer->context);
  lean_object *v0 = lean_array_get_core(arguments, 0); lean_inc(v0);
  lean_dec(arguments);
  ov_callback_frame frame = { .parent = ov_active_callback_frame, .transaction = &transaction };
  if (!frame.parent) { (void)lb_native_callback_take_error(); (void)lean_bridge_owned_callback_failure_1d643ee3fbc2aa924d28(); }
  ov_active_callback_frame = &frame;
  lean_object *returned = lean_bridge_owned_48d801817da6928541ff452a_f973a6e63b7dad7a3d147(v0);
  ov_active_callback_frame = frame.parent; status = frame.status;
  int callback_error = lb_native_callback_take_error();
  int refinement_error = lean_bridge_owned_callback_failure_1d643ee3fbc2aa924d28();
  if (refinement_error && !status) status = LB_OWNED_INVALID;
  else if (callback_error && !status) status = OV_CALLBACK;
  if (!status) status = lb_owned_scope_ready(&transaction.scope);
  if (status) { lean_dec(returned); return ov_abort(&transaction, status); }
  lbov_1d643ee3fbc2aa924d28_t5faad500583201774348 converted = {0};
  status = lbov_1d643ee3fbc2aa924d28_v5faad500583201774348_out(&converted, returned, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  status = ov_commit(&transaction, owner);
  if (!status) *out = converted;
  return status;
}
static inline int lbov_1d643ee3fbc2aa924d28_v6f9a0eb5450512cec111_apply(lb_owned_context *context, const lbov_1d643ee3fbc2aa924d28_t6f9a0eb5450512cec111 *a0, const lbov_1d643ee3fbc2aa924d28_t37c6db88a97448412ed0 *a1, lbov_1d643ee3fbc2aa924d28_t37c6db88a97448412ed0 *out, ov_result_owner *owner) {
  if (!ov_pointer(out, sizeof(*out), _Alignof(lbov_1d643ee3fbc2aa924d28_t37c6db88a97448412ed0)) || !ov_pointer(owner, sizeof(*owner), _Alignof(ov_result_owner))) return LB_OWNED_INVALID;
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-subtypes@1.0.0");
  if (status) return status;
  status = ov_charge(&transaction.budget, 1, sizeof(*out));
  if (status) return ov_abort(&transaction, status);
  lean_object *arguments = lean_alloc_array(0, 2);
  {
    lean_object *child = NULL;
    status = lbov_1d643ee3fbc2aa924d28_v6f9a0eb5450512cec111_in(a0, 0, 1, &transaction, &child);
    if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
    arguments = lean_array_push(arguments, child);
  }
  {
    lean_object *child = NULL;
    status = lbov_1d643ee3fbc2aa924d28_v37c6db88a97448412ed0_in(a1, 0, 1, &transaction, &child);
    if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
    arguments = lean_array_push(arguments, child);
  }
  lean_object *v0 = lean_array_get_core(arguments, 0); lean_inc(v0);
  lean_object *v1 = lean_array_get_core(arguments, 1); lean_inc(v1);
  lean_dec(arguments);
  ov_callback_frame frame = { .parent = ov_active_callback_frame, .transaction = &transaction };
  if (!frame.parent) { (void)lb_native_callback_take_error(); (void)lean_bridge_owned_callback_failure_1d643ee3fbc2aa924d28(); }
  ov_active_callback_frame = &frame;
  lean_object *returned = lean_bridge_owned_48d801817da6928541ff452a_t6f9a0eb5450512cec111_apply(v0, v1);
  ov_active_callback_frame = frame.parent; status = frame.status;
  int callback_error = lb_native_callback_take_error();
  int refinement_error = lean_bridge_owned_callback_failure_1d643ee3fbc2aa924d28();
  if (refinement_error && !status) status = LB_OWNED_INVALID;
  else if (callback_error && !status) status = OV_CALLBACK;
  if (!status) status = lb_owned_scope_ready(&transaction.scope);
  if (status) { lean_dec(returned); return ov_abort(&transaction, status); }
  lbov_1d643ee3fbc2aa924d28_t37c6db88a97448412ed0 converted = {0};
  status = lbov_1d643ee3fbc2aa924d28_v37c6db88a97448412ed0_out(&converted, returned, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  status = ov_commit(&transaction, owner);
  if (!status) *out = converted;
  return status;
}


_Static_assert(sizeof(bool) == 1, "owned C values require one-byte bool storage");
typedef struct oc_block {
  struct oc_block *next;
  int integer_initialized;
  mpz_t integer;
  max_align_t alignment;
  unsigned char data[];
} oc_block;
typedef struct { oc_block *head; ov_budget *budget; } oc_arena;
typedef struct oc_session oc_session;
typedef struct oc_result {
  struct oc_result *next;
  uint64_t key;
  oc_session *session;
  ov_result_owner native;
  oc_block *blocks;
} oc_result;
struct oc_session {
  oc_session *next;
  uint64_t key;
  lb_owned_context native;
  size_t results, calls;
  int closed;
};
static _Thread_local oc_session *oc_sessions;
static _Thread_local oc_result *oc_results;
extern lean_object *initialize_LeanBridgeOwned20815341f7ffc5e1(uint8_t);
static void *oc_initialize(uint8_t builtin) { return initialize_LeanBridgeOwned20815341f7ffc5e1(builtin); }

static inline void oc_release(oc_block *block) {
  while (block) {
    oc_block *next = block->next;
    if (block->integer_initialized) mpz_clear(block->integer);
    LB_OWNED_FREE(block); block = next;
  }
}
static inline int oc_block_new(oc_arena *arena, size_t count, size_t width, oc_block **out) {
  int status = ov_charge(arena->budget, count, width);
  if (!status) status = ov_charge(arena->budget, 1, sizeof(oc_block));
  if (status) return status;
  oc_block *block = LB_OWNED_ALLOC(sizeof(*block) + count * width);
  if (!block) return LB_OWNED_ALLOC_FAILED;
  memset(block, 0, sizeof(*block) + count * width);
  block->next = arena->head; arena->head = block; *out = block;
  return LB_OWNED_OK;
}
static inline int oc_allocate(oc_arena *arena, size_t count, size_t width, void **out) {
  *out = NULL; if (!count) return LB_OWNED_OK;
  oc_block *block; int status = oc_block_new(arena, count, width, &block);
  if (!status) *out = block->data;
  return status;
}
static inline int oc_integer(oc_arena *arena, const uint32_t *limbs, size_t length, int negative, mpz_srcptr *out) {
  int status = ov_span(arena->budget, limbs, length, sizeof(uint32_t), _Alignof(uint32_t));
  if (status) return status;
  size_t bits = length * 32, count = bits / GMP_NUMB_BITS + (bits % GMP_NUMB_BITS != 0);
  status = ov_charge(arena->budget, count, sizeof(mp_limb_t));
  if (status) return status;
  oc_block *block; status = oc_block_new(arena, 0, 1, &block);
  if (status) return status;
  mpz_init(block->integer); block->integer_initialized = 1;
  if (length) mpz_import(block->integer, length, -1, sizeof(uint32_t), 0, 0, limbs);
  if (negative) mpz_neg(block->integer, block->integer);
  *out = block->integer; return LB_OWNED_OK;
}
static inline oc_session *oc_session_find(const owned_subtypes_session *key) {
  for (oc_session *item = oc_sessions; item; item = item->next)
    if (item->key == (uint64_t)(uintptr_t)key) return item;
  return NULL;
}
static inline int oc_session_get(const owned_subtypes_session *key, oc_session **out) {
  if (!lean_bridge_native_process_valid()) return LB_OWNED_PROCESS;
  oc_session *session = oc_session_find(key);
  if (!session) return LB_OWNED_INVALID;
  if (session->closed) return LB_OWNED_CLOSED;
  int status = lb_owned_ready(&session->native);
  if (!status) *out = session;
  return status;
}
static inline void oc_session_collect(oc_session *session) {
  if (!session->closed || session->results || session->calls) return;
  oc_session **slot = &oc_sessions;
  while (*slot != session) slot = &(*slot)->next;
  *slot = session->next;
  (void)lean_bridge_native_identity_release(session->key, "owned-c-session:owned-subtypes@1.0.0", session);
  LB_OWNED_FREE(session);
}
owned_subtypes_status owned_subtypes_session_open(owned_subtypes_session **out) {
  if (!ov_pointer(out, sizeof(*out), _Alignof(owned_subtypes_session *)) || *out) return (owned_subtypes_status)LB_OWNED_INVALID;
  if (!lean_bridge_native_process_valid()) return (owned_subtypes_status)LB_OWNED_PROCESS;
  if (!lean_bridge_native_component_initialize("owned-subtypes@1.0.0", oc_initialize)) return (owned_subtypes_status)LB_OWNED_RUNTIME;
  oc_session *session = LB_OWNED_ALLOC(sizeof(*session));
  if (!session) return (owned_subtypes_status)LB_OWNED_ALLOC_FAILED;
  memset(session, 0, sizeof(*session));
  int status = lb_owned_context_init(&session->native, "owned-subtypes@1.0.0");
  if (status) { LB_OWNED_FREE(session); return (owned_subtypes_status)status; }
  session->key = lean_bridge_native_identity_acquire("owned-c-session:owned-subtypes@1.0.0", session);
  if (!session->key) { lb_owned_context_close(&session->native); LB_OWNED_FREE(session); return (owned_subtypes_status)LB_OWNED_LIMIT; }
  session->next = oc_sessions; oc_sessions = session;
  *out = (owned_subtypes_session *)(uintptr_t)session->key;
  return (owned_subtypes_status)LB_OWNED_OK;
}
owned_subtypes_status owned_subtypes_session_close(owned_subtypes_session **value) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(owned_subtypes_session *))) return (owned_subtypes_status)LB_OWNED_INVALID;
  if (!lean_bridge_native_process_valid()) return (owned_subtypes_status)LB_OWNED_PROCESS;
  if (!*value) return (owned_subtypes_status)LB_OWNED_OK;
  oc_session *session = oc_session_find(*value);
  if (!session) return (owned_subtypes_status)LB_OWNED_INVALID;
  if (session->closed) return (owned_subtypes_status)LB_OWNED_CLOSED;
  int status = lb_owned_context_close(&session->native);
  if (status) return (owned_subtypes_status)status;
  session->closed = 1; *value = NULL;
  oc_session_collect(session); return (owned_subtypes_status)LB_OWNED_OK;
}
owned_subtypes_status owned_subtypes_result_release(owned_subtypes_result **value) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(owned_subtypes_result *))) return (owned_subtypes_status)LB_OWNED_INVALID;
  if (!lean_bridge_native_process_valid()) return (owned_subtypes_status)LB_OWNED_PROCESS;
  if (!*value) return (owned_subtypes_status)LB_OWNED_OK;
  oc_result **slot = &oc_results;
  while (*slot && (*slot)->key != (uint64_t)(uintptr_t)*value) slot = &(*slot)->next;
  if (!*slot) return (owned_subtypes_status)LB_OWNED_INVALID;
  oc_result *result = *slot; oc_session *session = result->session;
  int status = ov_owner_clear(&result->native);
  if (!ov_owner_empty(&result->native)) return (owned_subtypes_status)status;
  *slot = result->next; --session->results;
  if (lean_bridge_native_identity_release(result->key, "owned-c-result:owned-subtypes@1.0.0", result) < 0 && !status) status = LB_OWNED_RUNTIME;
  oc_release(result->blocks); LB_OWNED_FREE(result); *value = NULL;
  oc_session_collect(session); return (owned_subtypes_status)status;
}
static inline int oc_result_begin(oc_session *session, ov_budget *budget, oc_result **out) {
  if (session->calls == LB_OWNED_SCOPE_LIMIT) return LB_OWNED_LIMIT;
  int status = ov_charge(budget, 1, sizeof(oc_result));
  if (status) return status;
  oc_result *result = LB_OWNED_ALLOC(sizeof(*result));
  if (!result) return LB_OWNED_ALLOC_FAILED;
  memset(result, 0, sizeof(*result)); result->session = session;
  ++session->calls; *out = result; return LB_OWNED_OK;
}
static inline int oc_result_finish(oc_result *result, oc_arena *output, int status, owned_subtypes_result **owner) {
  oc_session *session = result->session;
  if (status == OV_RESULT) lean_bridge_native_runtime_retire();
  if (!status) status = lb_owned_ready(&session->native);
  if (!status) {
    result->key = lean_bridge_native_identity_acquire("owned-c-result:owned-subtypes@1.0.0", result);
    if (!result->key) status = LB_OWNED_LIMIT;
  }
  if (!status) {
    result->blocks = output->head; output->head = NULL;
    result->next = oc_results; oc_results = result; ++session->results;
    *owner = (owned_subtypes_result *)(uintptr_t)result->key;
  } else {
    (void)ov_owner_clear(&result->native);
    oc_release(output->head); output->head = NULL; LB_OWNED_FREE(result);
  }
  --session->calls; oc_session_collect(session); return status;
}
static inline ov_budget oc_budget(void) {
  return (ov_budget){ .bytes = 16777216, .visits = 262144 };
}
static inline int oc_outputs(const void *out, size_t bytes, size_t alignment, const void *owner) {
  if (!ov_pointer(out, bytes, alignment) || !ov_pointer(owner, sizeof(void *), _Alignof(void *))) return 0;
  uintptr_t a = (uintptr_t)out, b = (uintptr_t)owner;
  return a < b ? bytes <= b - a : sizeof(void *) <= a - b;
}


typedef struct {
  owned_subtypes_result **slot;
  oc_result *result;
} oc_transfer_input;
typedef struct {
  oc_transfer_input *inputs;
  size_t count;
  int consumed;
} oc_transfer_frame;

static inline int oc_transfer_prepare(oc_session *session, oc_transfer_frame *frame,
    ov_result_owner **owners, void *out, size_t bytes, size_t alignment,
    owned_subtypes_result **output_owner) {
  for (size_t i = 0; i < frame->count; ++i) {
    owned_subtypes_result **slot = frame->inputs[i].slot;
    if (!oc_outputs(out, bytes, alignment, slot) ||
        !oc_outputs(slot, sizeof(*slot), _Alignof(owned_subtypes_result *), output_owner) ||
        !*slot) return LB_OWNED_INVALID;
    oc_result *result = oc_results;
    while (result && result->key != (uint64_t)(uintptr_t)*slot) result = result->next;
    if (!result || result->session != session) return LB_OWNED_INVALID;
    for (size_t j = 0; j < i; ++j)
      if (frame->inputs[j].result == result) return LB_OWNED_INVALID;
    frame->inputs[i].result = result;
    owners[i] = &result->native;
  }
  return LB_OWNED_OK;
}

/* Native conversion has validated every value and moved every input batch.
   This hook cannot allocate, call user code, or fail partway through the set. */
static inline void oc_transfer_consume(void *context) {
  oc_transfer_frame *frame = context;
  for (size_t i = 0; i < frame->count; ++i) {
    oc_result *result = frame->inputs[i].result;
    oc_result **position = &oc_results;
    while (*position != result) position = &(*position)->next;
    *position = result->next;
    --result->session->results;
    *frame->inputs[i].slot = NULL;
  }
  frame->consumed = 1;
}

static inline int oc_transfer_finish(oc_transfer_frame *frame, int status) {
  if (!frame->consumed) return status;
  for (size_t i = 0; i < frame->count; ++i) {
    oc_result *result = frame->inputs[i].result;
    int cleanup = ov_owner_clear(&result->native);
    if (!status) status = cleanup;
    if (lean_bridge_native_identity_release(result->key, "owned-c-result:owned-subtypes@1.0.0", result) < 0 && !status)
      status = LB_OWNED_RUNTIME;
    oc_release(result->blocks); LB_OWNED_FREE(result);
  }
  return status;
}

static inline int oc_v0_to(owned_subtypes_value_82551d965c182180b0dd_t const *, lbov_1d643ee3fbc2aa924d28_t82551d965c182180b0dd *, size_t, oc_arena *);
static inline int oc_v0_from(const lbov_1d643ee3fbc2aa924d28_t82551d965c182180b0dd *, owned_subtypes_value_82551d965c182180b0dd_t *, size_t, oc_arena *);
static inline int oc_v1_to(owned_subtypes_value_659ec6a690764999d00d_t const *, lbov_1d643ee3fbc2aa924d28_t659ec6a690764999d00d *, size_t, oc_arena *);
static inline int oc_v1_from(const lbov_1d643ee3fbc2aa924d28_t659ec6a690764999d00d *, owned_subtypes_value_659ec6a690764999d00d_t *, size_t, oc_arena *);
static inline int oc_v2_to(owned_subtypes_value_817592654f48ba756bd4_t const *, lbov_1d643ee3fbc2aa924d28_t817592654f48ba756bd4 *, size_t, oc_arena *);
static inline int oc_v2_from(const lbov_1d643ee3fbc2aa924d28_t817592654f48ba756bd4 *, owned_subtypes_value_817592654f48ba756bd4_t *, size_t, oc_arena *);
static inline int oc_v3_to(owned_subtypes_callback_record_argument1_t const *, lbov_1d643ee3fbc2aa924d28_t6f9a0eb5450512cec111 *, size_t, oc_arena *);
static inline int oc_v3_from(const lbov_1d643ee3fbc2aa924d28_t6f9a0eb5450512cec111 *, owned_subtypes_callback_record_argument1_t *, size_t, oc_arena *);
static inline int oc_v4_to(owned_subtypes_bundle_t const *, lbov_1d643ee3fbc2aa924d28_t5faad500583201774348 *, size_t, oc_arena *);
static inline int oc_v4_from(const lbov_1d643ee3fbc2aa924d28_t5faad500583201774348 *, owned_subtypes_bundle_t *, size_t, oc_arena *);
static inline int oc_v5_to(owned_subtypes_callback_bundle_t const *, lbov_1d643ee3fbc2aa924d28_t37c6db88a97448412ed0 *, size_t, oc_arena *);
static inline int oc_v5_from(const lbov_1d643ee3fbc2aa924d28_t37c6db88a97448412ed0 *, owned_subtypes_callback_bundle_t *, size_t, oc_arena *);
static inline int oc_v6_to(owned_subtypes_callback_payload_t const *, lbov_1d643ee3fbc2aa924d28_tf197109068e846c0739c *, size_t, oc_arena *);
static inline int oc_v6_from(const lbov_1d643ee3fbc2aa924d28_tf197109068e846c0739c *, owned_subtypes_callback_payload_t *, size_t, oc_arena *);
static inline int oc_v7_to(owned_subtypes_payload_t const *, lbov_1d643ee3fbc2aa924d28_t550e0acb733e8dd08e4e *, size_t, oc_arena *);
static inline int oc_v7_from(const lbov_1d643ee3fbc2aa924d28_t550e0acb733e8dd08e4e *, owned_subtypes_payload_t *, size_t, oc_arena *);
static inline int oc_v8_to(owned_subtypes_ticket_t const *, lbov_1d643ee3fbc2aa924d28_t6de8e950bc342c30091c *, size_t, oc_arena *);
static inline int oc_v8_from(const lbov_1d643ee3fbc2aa924d28_t6de8e950bc342c30091c *, owned_subtypes_ticket_t *, size_t, oc_arena *);
static inline int oc_v9_to(owned_subtypes_scalar_bytes_t const *, lbov_1d643ee3fbc2aa924d28_tf098e5912ebfda269f53 *, size_t, oc_arena *);
static inline int oc_v9_from(const lbov_1d643ee3fbc2aa924d28_tf098e5912ebfda269f53 *, owned_subtypes_scalar_bytes_t *, size_t, oc_arena *);
static inline int oc_v10_to(mpz_srcptr const *, lbov_1d643ee3fbc2aa924d28_t11140334dba7a15b6b99 *, size_t, oc_arena *);
static inline int oc_v10_from(const lbov_1d643ee3fbc2aa924d28_t11140334dba7a15b6b99 *, mpz_srcptr *, size_t, oc_arena *);
static inline int oc_v11_to(mpz_srcptr const *, lbov_1d643ee3fbc2aa924d28_t167081552b6f9c1d1afd *, size_t, oc_arena *);
static inline int oc_v11_from(const lbov_1d643ee3fbc2aa924d28_t167081552b6f9c1d1afd *, mpz_srcptr *, size_t, oc_arena *);
static inline int oc_v12_to(owned_subtypes_scalar_string_t const *, lbov_1d643ee3fbc2aa924d28_tdc0347e1f7f5c4d928f1 *, size_t, oc_arena *);
static inline int oc_v12_from(const lbov_1d643ee3fbc2aa924d28_tdc0347e1f7f5c4d928f1 *, owned_subtypes_scalar_string_t *, size_t, oc_arena *);
static inline int oc_v0_to(owned_subtypes_value_82551d965c182180b0dd_t const *value, lbov_1d643ee3fbc2aa924d28_t82551d965c182180b0dd *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(owned_subtypes_value_82551d965c182180b0dd_t))) return LB_OWNED_INVALID;
  int status = ov_enter(arena->budget, value, 0, depth);
  if (status) return status;
  (void)out;
  if (value->length > arena->budget->visits) return LB_OWNED_LIMIT;
  status = ov_span(arena->budget, value->data, value->length, sizeof(owned_subtypes_ticket_t), _Alignof(owned_subtypes_ticket_t));
  if (status) return status;
  void *data = NULL;
  status = oc_allocate(arena, value->length, sizeof(lbov_1d643ee3fbc2aa924d28_t6de8e950bc342c30091c), &data);
  if (status) return status;
  lbov_1d643ee3fbc2aa924d28_t6de8e950bc342c30091c *items = data; out->data = data; out->length = value->length;
  for (size_t i = 0; i < value->length; ++i) {
    status = oc_v8_to(value->data + i, items + i, depth + 1, arena);
    if (status) return status;
  }
  return LB_OWNED_OK;
}
static inline int oc_v0_from(const lbov_1d643ee3fbc2aa924d28_t82551d965c182180b0dd *value, owned_subtypes_value_82551d965c182180b0dd_t *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_1d643ee3fbc2aa924d28_t82551d965c182180b0dd))) return OV_RESULT;
  int status = ov_enter(arena->budget, value, 0, depth);
  if (status) return status;
  (void)out;
  if (value->length > arena->budget->visits) return LB_OWNED_LIMIT;
  status = ov_span(arena->budget, value->data, value->length, sizeof(lbov_1d643ee3fbc2aa924d28_t6de8e950bc342c30091c), _Alignof(lbov_1d643ee3fbc2aa924d28_t6de8e950bc342c30091c));
  if (status) return status;
  void *data = NULL;
  status = oc_allocate(arena, value->length, sizeof(owned_subtypes_ticket_t), &data);
  if (status) return status;
  owned_subtypes_ticket_t *items = data; out->data = data; out->length = value->length;
  for (size_t i = 0; i < value->length; ++i) {
    status = oc_v8_from(value->data + i, items + i, depth + 1, arena);
    if (status) return status;
  }
  return LB_OWNED_OK;
}
static inline int oc_v1_to(owned_subtypes_value_659ec6a690764999d00d_t const *value, lbov_1d643ee3fbc2aa924d28_t659ec6a690764999d00d *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(owned_subtypes_value_659ec6a690764999d00d_t))) return LB_OWNED_INVALID;
  int status = ov_enter(arena->budget, value, 1, depth);
  if (status) return status;
  (void)out;
  if (value->length > arena->budget->visits) return LB_OWNED_LIMIT;
  status = ov_span(arena->budget, value->data, value->length, sizeof(owned_subtypes_ticket_t), _Alignof(owned_subtypes_ticket_t));
  if (status) return status;
  void *data = NULL;
  status = oc_allocate(arena, value->length, sizeof(lbov_1d643ee3fbc2aa924d28_t6de8e950bc342c30091c), &data);
  if (status) return status;
  lbov_1d643ee3fbc2aa924d28_t6de8e950bc342c30091c *items = data; out->data = data; out->length = value->length;
  for (size_t i = 0; i < value->length; ++i) {
    status = oc_v8_to(value->data + i, items + i, depth + 1, arena);
    if (status) return status;
  }
  return LB_OWNED_OK;
}
static inline int oc_v1_from(const lbov_1d643ee3fbc2aa924d28_t659ec6a690764999d00d *value, owned_subtypes_value_659ec6a690764999d00d_t *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_1d643ee3fbc2aa924d28_t659ec6a690764999d00d))) return OV_RESULT;
  int status = ov_enter(arena->budget, value, 1, depth);
  if (status) return status;
  (void)out;
  if (value->length > arena->budget->visits) return LB_OWNED_LIMIT;
  status = ov_span(arena->budget, value->data, value->length, sizeof(lbov_1d643ee3fbc2aa924d28_t6de8e950bc342c30091c), _Alignof(lbov_1d643ee3fbc2aa924d28_t6de8e950bc342c30091c));
  if (status) return status;
  void *data = NULL;
  status = oc_allocate(arena, value->length, sizeof(owned_subtypes_ticket_t), &data);
  if (status) return status;
  owned_subtypes_ticket_t *items = data; out->data = data; out->length = value->length;
  for (size_t i = 0; i < value->length; ++i) {
    status = oc_v8_from(value->data + i, items + i, depth + 1, arena);
    if (status) return status;
  }
  return LB_OWNED_OK;
}
static inline int oc_v2_to(owned_subtypes_value_817592654f48ba756bd4_t const *value, lbov_1d643ee3fbc2aa924d28_t817592654f48ba756bd4 *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(owned_subtypes_value_817592654f48ba756bd4_t))) return LB_OWNED_INVALID;
  int status = ov_enter(arena->budget, value, 2, depth);
  if (status) return status;
  (void)out;
  uint8_t selected; memcpy(&selected, &value->has_value, 1);
  if (selected > 1) return LB_OWNED_INVALID;
  out->tag = selected;
  if (out->tag == 1) {
  {
    status = oc_v8_to(&value->value, &out->f0, depth + 1, arena);
    if (status) return status;
  }
  }
  return LB_OWNED_OK;
}
static inline int oc_v2_from(const lbov_1d643ee3fbc2aa924d28_t817592654f48ba756bd4 *value, owned_subtypes_value_817592654f48ba756bd4_t *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_1d643ee3fbc2aa924d28_t817592654f48ba756bd4))) return OV_RESULT;
  int status = ov_enter(arena->budget, value, 2, depth);
  if (status) return status;
  (void)out;
  if (value->tag > 1) return OV_RESULT;
  out->has_value = value->tag != 0;
  if (value->tag == 1) {
  {
    status = oc_v8_from(&value->f0, &out->value, depth + 1, arena);
    if (status) return status;
  }
  }
  return LB_OWNED_OK;
}
static inline int oc_v3_to(owned_subtypes_callback_record_argument1_t const *value, lbov_1d643ee3fbc2aa924d28_t6f9a0eb5450512cec111 *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(owned_subtypes_callback_record_argument1_t))) return LB_OWNED_INVALID;
  int status = ov_enter(arena->budget, value, 3, depth);
  if (status) return status;
  (void)out;
  if (!*value) return LB_OWNED_INVALID;
  out->token = (uint64_t)(uintptr_t)*value;
  return LB_OWNED_OK;
}
static inline int oc_v3_from(const lbov_1d643ee3fbc2aa924d28_t6f9a0eb5450512cec111 *value, owned_subtypes_callback_record_argument1_t *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_1d643ee3fbc2aa924d28_t6f9a0eb5450512cec111))) return OV_RESULT;
  int status = ov_enter(arena->budget, value, 3, depth);
  if (status) return status;
  (void)out;
  if (!value->token) return OV_RESULT;
  *out = (owned_subtypes_callback_record_argument1_t)(uintptr_t)value->token;
  return LB_OWNED_OK;
}
static inline int oc_v4_to(owned_subtypes_bundle_t const *value, lbov_1d643ee3fbc2aa924d28_t5faad500583201774348 *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(owned_subtypes_bundle_t))) return LB_OWNED_INVALID;
  int status = ov_enter(arena->budget, value, 4, depth);
  if (status) return status;
  (void)out;
  {
    status = oc_v8_to(&value->primary, &out->f0, depth + 1, arena);
    if (status) return status;
  }
  {
    void *data = NULL;
    status = oc_allocate(arena, 1, sizeof(lbov_1d643ee3fbc2aa924d28_t817592654f48ba756bd4), &data);
    if (status) return status;
    out->f1 = data;
    status = oc_v2_to(value->spare, data, depth + 1, arena);
    if (status) return status;
  }
  {
    void *data = NULL;
    status = oc_allocate(arena, 1, sizeof(lbov_1d643ee3fbc2aa924d28_t659ec6a690764999d00d), &data);
    if (status) return status;
    out->f2 = data;
    status = oc_v1_to(value->peers, data, depth + 1, arena);
    if (status) return status;
  }
  {
    void *data = NULL;
    status = oc_allocate(arena, 1, sizeof(lbov_1d643ee3fbc2aa924d28_t82551d965c182180b0dd), &data);
    if (status) return status;
    out->f3 = data;
    status = oc_v0_to(value->history, data, depth + 1, arena);
    if (status) return status;
  }
  {
    void *data = NULL;
    status = oc_allocate(arena, 1, sizeof(lbov_1d643ee3fbc2aa924d28_t550e0acb733e8dd08e4e), &data);
    if (status) return status;
    out->f4 = data;
    status = oc_v7_to(value->payload, data, depth + 1, arena);
    if (status) return status;
  }
  return LB_OWNED_OK;
}
static inline int oc_v4_from(const lbov_1d643ee3fbc2aa924d28_t5faad500583201774348 *value, owned_subtypes_bundle_t *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_1d643ee3fbc2aa924d28_t5faad500583201774348))) return OV_RESULT;
  int status = ov_enter(arena->budget, value, 4, depth);
  if (status) return status;
  (void)out;
  {
    status = oc_v8_from(&value->f0, &out->primary, depth + 1, arena);
    if (status) return status;
  }
  {
    void *data = NULL;
    status = oc_allocate(arena, 1, sizeof(owned_subtypes_value_817592654f48ba756bd4_t), &data);
    if (status) return status;
    out->spare = data;
    status = oc_v2_from(value->f1, data, depth + 1, arena);
    if (status) return status;
  }
  {
    void *data = NULL;
    status = oc_allocate(arena, 1, sizeof(owned_subtypes_value_659ec6a690764999d00d_t), &data);
    if (status) return status;
    out->peers = data;
    status = oc_v1_from(value->f2, data, depth + 1, arena);
    if (status) return status;
  }
  {
    void *data = NULL;
    status = oc_allocate(arena, 1, sizeof(owned_subtypes_value_82551d965c182180b0dd_t), &data);
    if (status) return status;
    out->history = data;
    status = oc_v0_from(value->f3, data, depth + 1, arena);
    if (status) return status;
  }
  {
    void *data = NULL;
    status = oc_allocate(arena, 1, sizeof(owned_subtypes_payload_t), &data);
    if (status) return status;
    out->payload = data;
    status = oc_v7_from(value->f4, data, depth + 1, arena);
    if (status) return status;
  }
  return LB_OWNED_OK;
}
static inline int oc_v5_to(owned_subtypes_callback_bundle_t const *value, lbov_1d643ee3fbc2aa924d28_t37c6db88a97448412ed0 *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(owned_subtypes_callback_bundle_t))) return LB_OWNED_INVALID;
  int status = ov_enter(arena->budget, value, 5, depth);
  if (status) return status;
  (void)out;
  {
    status = oc_v8_to(&value->primary, &out->f0, depth + 1, arena);
    if (status) return status;
  }
  {
    void *data = NULL;
    status = oc_allocate(arena, 1, sizeof(lbov_1d643ee3fbc2aa924d28_tf197109068e846c0739c), &data);
    if (status) return status;
    out->f1 = data;
    status = oc_v6_to(value->payload, data, depth + 1, arena);
    if (status) return status;
  }
  return LB_OWNED_OK;
}
static inline int oc_v5_from(const lbov_1d643ee3fbc2aa924d28_t37c6db88a97448412ed0 *value, owned_subtypes_callback_bundle_t *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_1d643ee3fbc2aa924d28_t37c6db88a97448412ed0))) return OV_RESULT;
  int status = ov_enter(arena->budget, value, 5, depth);
  if (status) return status;
  (void)out;
  {
    status = oc_v8_from(&value->f0, &out->primary, depth + 1, arena);
    if (status) return status;
  }
  {
    void *data = NULL;
    status = oc_allocate(arena, 1, sizeof(owned_subtypes_callback_payload_t), &data);
    if (status) return status;
    out->payload = data;
    status = oc_v6_from(value->f1, data, depth + 1, arena);
    if (status) return status;
  }
  return LB_OWNED_OK;
}
static inline int oc_v6_to(owned_subtypes_callback_payload_t const *value, lbov_1d643ee3fbc2aa924d28_tf197109068e846c0739c *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(owned_subtypes_callback_payload_t))) return LB_OWNED_INVALID;
  int status = ov_enter(arena->budget, value, 6, depth);
  if (status) return status;
  (void)out;
  {
    status = oc_v10_to(&value->count, &out->f0, depth + 1, arena);
    if (status) return status;
  }
  {
    status = oc_v9_to(&value->bytes, &out->f1, depth + 1, arena);
    if (status) return status;
  }
  return LB_OWNED_OK;
}
static inline int oc_v6_from(const lbov_1d643ee3fbc2aa924d28_tf197109068e846c0739c *value, owned_subtypes_callback_payload_t *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_1d643ee3fbc2aa924d28_tf197109068e846c0739c))) return OV_RESULT;
  int status = ov_enter(arena->budget, value, 6, depth);
  if (status) return status;
  (void)out;
  {
    status = oc_v10_from(&value->f0, &out->count, depth + 1, arena);
    if (status) return status;
  }
  {
    status = oc_v9_from(&value->f1, &out->bytes, depth + 1, arena);
    if (status) return status;
  }
  return LB_OWNED_OK;
}
static inline int oc_v7_to(owned_subtypes_payload_t const *value, lbov_1d643ee3fbc2aa924d28_t550e0acb733e8dd08e4e *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(owned_subtypes_payload_t))) return LB_OWNED_INVALID;
  int status = ov_enter(arena->budget, value, 7, depth);
  if (status) return status;
  (void)out;
  {
    status = oc_v10_to(&value->count, &out->f0, depth + 1, arena);
    if (status) return status;
  }
  {
    status = oc_v9_to(&value->bytes, &out->f1, depth + 1, arena);
    if (status) return status;
  }
  return LB_OWNED_OK;
}
static inline int oc_v7_from(const lbov_1d643ee3fbc2aa924d28_t550e0acb733e8dd08e4e *value, owned_subtypes_payload_t *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_1d643ee3fbc2aa924d28_t550e0acb733e8dd08e4e))) return OV_RESULT;
  int status = ov_enter(arena->budget, value, 7, depth);
  if (status) return status;
  (void)out;
  {
    status = oc_v10_from(&value->f0, &out->count, depth + 1, arena);
    if (status) return status;
  }
  {
    status = oc_v9_from(&value->f1, &out->bytes, depth + 1, arena);
    if (status) return status;
  }
  return LB_OWNED_OK;
}
static inline int oc_v8_to(owned_subtypes_ticket_t const *value, lbov_1d643ee3fbc2aa924d28_t6de8e950bc342c30091c *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(owned_subtypes_ticket_t))) return LB_OWNED_INVALID;
  int status = ov_enter(arena->budget, value, 8, depth);
  if (status) return status;
  (void)out;
  if (!*value) return LB_OWNED_INVALID;
  out->token = (uint64_t)(uintptr_t)*value;
  return LB_OWNED_OK;
}
static inline int oc_v8_from(const lbov_1d643ee3fbc2aa924d28_t6de8e950bc342c30091c *value, owned_subtypes_ticket_t *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_1d643ee3fbc2aa924d28_t6de8e950bc342c30091c))) return OV_RESULT;
  int status = ov_enter(arena->budget, value, 8, depth);
  if (status) return status;
  (void)out;
  if (!value->token) return OV_RESULT;
  *out = (owned_subtypes_ticket_t)(uintptr_t)value->token;
  return LB_OWNED_OK;
}
static inline int oc_v9_to(owned_subtypes_scalar_bytes_t const *value, lbov_1d643ee3fbc2aa924d28_tf098e5912ebfda269f53 *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(owned_subtypes_scalar_bytes_t))) return LB_OWNED_INVALID;
  int status = ov_enter(arena->budget, value, 9, depth);
  if (status) return status;
  (void)out;
  status = ov_span(arena->budget, value->data, value->length, 1, 1);
  if (status) return status;
  out->data = value->data; out->length = value->length;
  return LB_OWNED_OK;
}
static inline int oc_v9_from(const lbov_1d643ee3fbc2aa924d28_tf098e5912ebfda269f53 *value, owned_subtypes_scalar_bytes_t *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_1d643ee3fbc2aa924d28_tf098e5912ebfda269f53))) return OV_RESULT;
  int status = ov_enter(arena->budget, value, 9, depth);
  if (status) return status;
  (void)out;
  status = ov_span(arena->budget, value->data, value->length, 1, 1);
  if (status) return status;
  out->data = value->data; out->length = value->length;
  return LB_OWNED_OK;
}
static inline int oc_v10_to(mpz_srcptr const *value, lbov_1d643ee3fbc2aa924d28_t11140334dba7a15b6b99 *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(mpz_srcptr))) return LB_OWNED_INVALID;
  int status = ov_enter(arena->budget, value, 10, depth);
  if (status) return status;
  (void)out;
  if (!ov_pointer(*value, sizeof(**value), _Alignof(__mpz_struct))) return LB_OWNED_INVALID;
  if (mpz_size(*value) > arena->budget->bytes / sizeof(mp_limb_t) + 1) return LB_OWNED_LIMIT;
  size_t length = mpz_sgn(*value) ? (mpz_sizeinbase(*value, 2) - 1) / 32 + 1 : 0;
  void *data = NULL; status = oc_allocate(arena, length, sizeof(uint32_t), &data);
  if (status) return status;
  if (length) mpz_export(data, &length, -1, sizeof(uint32_t), 0, 0, *value);
  out->data = data; out->length = length;
  out->negative = mpz_sgn(*value) < 0;
  return LB_OWNED_OK;
}
static inline int oc_v10_from(const lbov_1d643ee3fbc2aa924d28_t11140334dba7a15b6b99 *value, mpz_srcptr *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_1d643ee3fbc2aa924d28_t11140334dba7a15b6b99))) return OV_RESULT;
  int status = ov_enter(arena->budget, value, 10, depth);
  if (status) return status;
  (void)out;
  if (value->negative > 1) return OV_RESULT;
  return oc_integer(arena, value->data, value->length, value->negative, out);
  return LB_OWNED_OK;
}
static inline int oc_v11_to(mpz_srcptr const *value, lbov_1d643ee3fbc2aa924d28_t167081552b6f9c1d1afd *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(mpz_srcptr))) return LB_OWNED_INVALID;
  int status = ov_enter(arena->budget, value, 11, depth);
  if (status) return status;
  (void)out;
  if (!ov_pointer(*value, sizeof(**value), _Alignof(__mpz_struct))) return LB_OWNED_INVALID;
  if (mpz_sgn(*value) < 0) return LB_OWNED_INVALID;
  if (mpz_size(*value) > arena->budget->bytes / sizeof(mp_limb_t) + 1) return LB_OWNED_LIMIT;
  size_t length = mpz_sgn(*value) ? (mpz_sizeinbase(*value, 2) - 1) / 32 + 1 : 0;
  void *data = NULL; status = oc_allocate(arena, length, sizeof(uint32_t), &data);
  if (status) return status;
  if (length) mpz_export(data, &length, -1, sizeof(uint32_t), 0, 0, *value);
  out->data = data; out->length = length;
  return LB_OWNED_OK;
}
static inline int oc_v11_from(const lbov_1d643ee3fbc2aa924d28_t167081552b6f9c1d1afd *value, mpz_srcptr *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_1d643ee3fbc2aa924d28_t167081552b6f9c1d1afd))) return OV_RESULT;
  int status = ov_enter(arena->budget, value, 11, depth);
  if (status) return status;
  (void)out;
  return oc_integer(arena, value->data, value->length, 0, out);
  return LB_OWNED_OK;
}
static inline int oc_v12_to(owned_subtypes_scalar_string_t const *value, lbov_1d643ee3fbc2aa924d28_tdc0347e1f7f5c4d928f1 *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(owned_subtypes_scalar_string_t))) return LB_OWNED_INVALID;
  int status = ov_enter(arena->budget, value, 12, depth);
  if (status) return status;
  (void)out;
  status = ov_span(arena->budget, value->data, value->length, 1, 1);
  if (status) return status;
  if (!ov_utf8((const uint8_t *)value->data, value->length)) return LB_OWNED_INVALID;
  out->data = value->data; out->length = value->length;
  return LB_OWNED_OK;
}
static inline int oc_v12_from(const lbov_1d643ee3fbc2aa924d28_tdc0347e1f7f5c4d928f1 *value, owned_subtypes_scalar_string_t *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_1d643ee3fbc2aa924d28_tdc0347e1f7f5c4d928f1))) return OV_RESULT;
  int status = ov_enter(arena->budget, value, 12, depth);
  if (status) return status;
  (void)out;
  status = ov_span(arena->budget, value->data, value->length, 1, 1);
  if (status) return status;
  if (!ov_utf8((const uint8_t *)value->data, value->length)) return OV_RESULT;
  out->data = value->data; out->length = value->length;
  return LB_OWNED_OK;
}
typedef struct oc_host_v3 {
  owned_subtypes_callback_record_argument1_t_host descriptor;
  oc_session *session;
  ov_budget *budget;
  uint64_t token;
  ov_result_owner owner;
} oc_host_v3;
static lean_object *oc_host_v3_invoke(void *context, lean_object *a0) {
  oc_host_v3 *borrow = context; ov_callback_frame *frame = ov_active_callback_frame;
  int status = !frame || frame->transaction->scope.context != &borrow->session->native ? OV_CALLBACK : frame->status;
  ov_transaction arguments = {0}; ov_result_owner argument_owner = {0};
  oc_arena views = { .budget = borrow->budget }, reply_input = { .budget = borrow->budget };
  owned_subtypes_result *reply_owner = NULL; lean_object *returned = NULL;
  lbov_1d643ee3fbc2aa924d28_t37c6db88a97448412ed0 raw0 = {0};
  owned_subtypes_callback_bundle_t view0 = {0};
  owned_subtypes_callback_bundle_t reply = {0}; lbov_1d643ee3fbc2aa924d28_t37c6db88a97448412ed0 raw_reply = {0};
  if (!status) status = ov_begin(&arguments, &borrow->session->native, &argument_owner, "owned-subtypes@1.0.0");
  if (!status) arguments.budget = frame->transaction->budget;
  if (!status) { status = lbov_1d643ee3fbc2aa924d28_v37c6db88a97448412ed0_out(&raw0, a0, 0, &arguments); a0 = NULL; }
  if (arguments.scope.context) frame->transaction->budget = arguments.budget;
  if (!status) status = ov_commit(&arguments, &argument_owner);
  else if (arguments.scope.context) status = ov_abort(&arguments, status);
  if (!status) status = oc_v5_from(&raw0, &view0, 0, &views);
  if (!status) {
    owned_subtypes_status host_status = borrow->descriptor.call(borrow->descriptor.context, (owned_subtypes_session *)(uintptr_t)borrow->session->key, &view0, &reply, &reply_owner);
    if (host_status) status = OV_CALLBACK;
    if (!status) status = lb_owned_scope_ready(&frame->transaction->scope);
  }
  if (!status) status = oc_v5_to(&reply, &raw_reply, 0, &reply_input);
  if (!status) status = lbov_1d643ee3fbc2aa924d28_v37c6db88a97448412ed0_in(&raw_reply, 0, 1, frame->transaction, &returned);
  int cleanup = owned_subtypes_result_release(&reply_owner); if (!status) status = cleanup;
  cleanup = ov_owner_clear(&argument_owner); if (!status) status = cleanup;
  oc_release(reply_input.head); oc_release(views.head);
  if (a0) lean_dec(a0);
  if (status) { ov_callback_fail(frame, status); if (returned) lean_dec(returned); return lean_alloc_array(0, 0); }
  return returned;
}
static inline int oc_host_v3_end(oc_host_v3 *borrow) {
  int status = LB_OWNED_OK;
  if (borrow->token) {
    if (lb_native_callback_wrong_thread(borrow->token)) status = LB_OWNED_THREAD;
    lb_native_callback_release(borrow->token); borrow->token = 0;
  }
  int cleanup = ov_owner_clear(&borrow->owner); return status ? status : cleanup;
}
static inline int oc_host_v3_begin(oc_host_v3 *borrow, const owned_subtypes_callback_record_argument1_t_host *input, oc_session *session, ov_budget *budget, lbov_1d643ee3fbc2aa924d28_t6f9a0eb5450512cec111 *out) {
  if (!ov_pointer(input, sizeof(*input), _Alignof(owned_subtypes_callback_record_argument1_t_host))) return LB_OWNED_INVALID;
  borrow->descriptor = *input; borrow->session = session; borrow->budget = budget;
  if ((!input->call) == (!input->closure)) return LB_OWNED_INVALID;
  if (input->closure) {
    if (input->context || input->recovery) return LB_OWNED_INVALID;
    oc_arena arena = { .budget = budget };
    return oc_v3_to(&input->closure, out, 0, &arena);
  }
  borrow->token = lb_native_callback_register((void (*)(void))oc_host_v3_invoke, borrow);
  if (!borrow->token) return LB_OWNED_LIMIT;
  ov_transaction transaction = {0}; oc_arena arena = { .budget = budget };
  int status = ov_begin(&transaction, &session->native, &borrow->owner, "owned-subtypes@1.0.0");
  lean_object *recovery = NULL;
  if (!status && input->recovery) {
    lbov_1d643ee3fbc2aa924d28_t37c6db88a97448412ed0 raw = {0}; status = oc_v5_to(input->recovery, &raw, 0, &arena);
    if (!status) status = lbov_1d643ee3fbc2aa924d28_v37c6db88a97448412ed0_in(&raw, 0, 1, &transaction, &recovery);
  }
  if (!status) {
    if (!recovery) recovery = lean_alloc_array(0, 0);
    lean_object *closure = lean_bridge_owned_48d801817da6928541ff452a_t6f9a0eb5450512cec111_wrap((size_t)borrow->token, input->recovery ? 1 : 0, recovery);
    if (!ov_carrier(closure)) { lean_dec(closure); status = LB_OWNED_INVALID; }
    else status = lbov_1d643ee3fbc2aa924d28_v6f9a0eb5450512cec111_out(out, closure, 0, &transaction);
  }
  oc_release(arena.head);
  if (!status) status = ov_commit(&transaction, &borrow->owner);
  else if (transaction.scope.context) status = ov_abort(&transaction, status);
  if (status) (void)oc_host_v3_end(borrow);
  return status;
}

static inline int lbov_1d643ee3fbc2aa924d28_v6f9a0eb5450512cec111_retain(lb_owned_context *context, const lbov_1d643ee3fbc2aa924d28_t6f9a0eb5450512cec111 *input, lbov_1d643ee3fbc2aa924d28_t6f9a0eb5450512cec111 *out, ov_result_owner *owner) {
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-subtypes@1.0.0");
  if (status) return status;
  lean_object *value = NULL;
  status = lbov_1d643ee3fbc2aa924d28_v6f9a0eb5450512cec111_in(input, 0, 1, &transaction, &value);
  if (status) return ov_abort(&transaction, status);
  status = lbov_1d643ee3fbc2aa924d28_v6f9a0eb5450512cec111_out(out, value, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  return ov_commit(&transaction, owner);
}
static inline int lbov_1d643ee3fbc2aa924d28_v6de8e950bc342c30091c_retain(lb_owned_context *context, const lbov_1d643ee3fbc2aa924d28_t6de8e950bc342c30091c *input, lbov_1d643ee3fbc2aa924d28_t6de8e950bc342c30091c *out, ov_result_owner *owner) {
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-subtypes@1.0.0");
  if (status) return status;
  lean_object *value = NULL;
  status = lbov_1d643ee3fbc2aa924d28_v6de8e950bc342c30091c_in(input, 0, 1, &transaction, &value);
  if (status) return ov_abort(&transaction, status);
  status = lbov_1d643ee3fbc2aa924d28_v6de8e950bc342c30091c_out(out, value, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  return ov_commit(&transaction, owner);
}
static inline int lbov_1d643ee3fbc2aa924d28_v82551d965c182180b0dd_retain(lb_owned_context *context, const lbov_1d643ee3fbc2aa924d28_t82551d965c182180b0dd *input, lbov_1d643ee3fbc2aa924d28_t82551d965c182180b0dd *out, ov_result_owner *owner) {
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-subtypes@1.0.0");
  if (status) return status;
  lean_object *value = NULL;
  status = lbov_1d643ee3fbc2aa924d28_v82551d965c182180b0dd_in(input, 0, 1, &transaction, &value);
  if (status) return ov_abort(&transaction, status);
  status = lbov_1d643ee3fbc2aa924d28_v82551d965c182180b0dd_out(out, value, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  return ov_commit(&transaction, owner);
}
static inline int lbov_1d643ee3fbc2aa924d28_v659ec6a690764999d00d_retain(lb_owned_context *context, const lbov_1d643ee3fbc2aa924d28_t659ec6a690764999d00d *input, lbov_1d643ee3fbc2aa924d28_t659ec6a690764999d00d *out, ov_result_owner *owner) {
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-subtypes@1.0.0");
  if (status) return status;
  lean_object *value = NULL;
  status = lbov_1d643ee3fbc2aa924d28_v659ec6a690764999d00d_in(input, 0, 1, &transaction, &value);
  if (status) return ov_abort(&transaction, status);
  status = lbov_1d643ee3fbc2aa924d28_v659ec6a690764999d00d_out(out, value, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  return ov_commit(&transaction, owner);
}
static inline int lbov_1d643ee3fbc2aa924d28_v817592654f48ba756bd4_retain(lb_owned_context *context, const lbov_1d643ee3fbc2aa924d28_t817592654f48ba756bd4 *input, lbov_1d643ee3fbc2aa924d28_t817592654f48ba756bd4 *out, ov_result_owner *owner) {
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-subtypes@1.0.0");
  if (status) return status;
  lean_object *value = NULL;
  status = lbov_1d643ee3fbc2aa924d28_v817592654f48ba756bd4_in(input, 0, 1, &transaction, &value);
  if (status) return ov_abort(&transaction, status);
  status = lbov_1d643ee3fbc2aa924d28_v817592654f48ba756bd4_out(out, value, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  return ov_commit(&transaction, owner);
}
static inline int lbov_1d643ee3fbc2aa924d28_v5faad500583201774348_retain(lb_owned_context *context, const lbov_1d643ee3fbc2aa924d28_t5faad500583201774348 *input, lbov_1d643ee3fbc2aa924d28_t5faad500583201774348 *out, ov_result_owner *owner) {
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-subtypes@1.0.0");
  if (status) return status;
  lean_object *value = NULL;
  status = lbov_1d643ee3fbc2aa924d28_v5faad500583201774348_in(input, 0, 1, &transaction, &value);
  if (status) return ov_abort(&transaction, status);
  status = lbov_1d643ee3fbc2aa924d28_v5faad500583201774348_out(out, value, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  return ov_commit(&transaction, owner);
}
static inline int lbov_1d643ee3fbc2aa924d28_v37c6db88a97448412ed0_retain(lb_owned_context *context, const lbov_1d643ee3fbc2aa924d28_t37c6db88a97448412ed0 *input, lbov_1d643ee3fbc2aa924d28_t37c6db88a97448412ed0 *out, ov_result_owner *owner) {
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-subtypes@1.0.0");
  if (status) return status;
  lean_object *value = NULL;
  status = lbov_1d643ee3fbc2aa924d28_v37c6db88a97448412ed0_in(input, 0, 1, &transaction, &value);
  if (status) return ov_abort(&transaction, status);
  status = lbov_1d643ee3fbc2aa924d28_v37c6db88a97448412ed0_out(out, value, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  return ov_commit(&transaction, owner);
}
static inline int lbov_1d643ee3fbc2aa924d28_vf197109068e846c0739c_retain(lb_owned_context *context, const lbov_1d643ee3fbc2aa924d28_tf197109068e846c0739c *input, lbov_1d643ee3fbc2aa924d28_tf197109068e846c0739c *out, ov_result_owner *owner) {
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-subtypes@1.0.0");
  if (status) return status;
  lean_object *value = NULL;
  status = lbov_1d643ee3fbc2aa924d28_vf197109068e846c0739c_in(input, 0, 1, &transaction, &value);
  if (status) return ov_abort(&transaction, status);
  status = lbov_1d643ee3fbc2aa924d28_vf197109068e846c0739c_out(out, value, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  return ov_commit(&transaction, owner);
}
static inline int lbov_1d643ee3fbc2aa924d28_v550e0acb733e8dd08e4e_retain(lb_owned_context *context, const lbov_1d643ee3fbc2aa924d28_t550e0acb733e8dd08e4e *input, lbov_1d643ee3fbc2aa924d28_t550e0acb733e8dd08e4e *out, ov_result_owner *owner) {
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-subtypes@1.0.0");
  if (status) return status;
  lean_object *value = NULL;
  status = lbov_1d643ee3fbc2aa924d28_v550e0acb733e8dd08e4e_in(input, 0, 1, &transaction, &value);
  if (status) return ov_abort(&transaction, status);
  status = lbov_1d643ee3fbc2aa924d28_v550e0acb733e8dd08e4e_out(out, value, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  return ov_commit(&transaction, owner);
}
static inline int lbov_1d643ee3fbc2aa924d28_vf098e5912ebfda269f53_retain(lb_owned_context *context, const lbov_1d643ee3fbc2aa924d28_tf098e5912ebfda269f53 *input, lbov_1d643ee3fbc2aa924d28_tf098e5912ebfda269f53 *out, ov_result_owner *owner) {
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-subtypes@1.0.0");
  if (status) return status;
  lean_object *value = NULL;
  status = lbov_1d643ee3fbc2aa924d28_vf098e5912ebfda269f53_in(input, 0, 1, &transaction, &value);
  if (status) return ov_abort(&transaction, status);
  status = lbov_1d643ee3fbc2aa924d28_vf098e5912ebfda269f53_out(out, value, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  return ov_commit(&transaction, owner);
}
static inline int lbov_1d643ee3fbc2aa924d28_v11140334dba7a15b6b99_retain(lb_owned_context *context, const lbov_1d643ee3fbc2aa924d28_t11140334dba7a15b6b99 *input, lbov_1d643ee3fbc2aa924d28_t11140334dba7a15b6b99 *out, ov_result_owner *owner) {
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-subtypes@1.0.0");
  if (status) return status;
  lean_object *value = NULL;
  status = lbov_1d643ee3fbc2aa924d28_v11140334dba7a15b6b99_in(input, 0, 1, &transaction, &value);
  if (status) return ov_abort(&transaction, status);
  status = lbov_1d643ee3fbc2aa924d28_v11140334dba7a15b6b99_out(out, value, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  return ov_commit(&transaction, owner);
}
static inline int lbov_1d643ee3fbc2aa924d28_v167081552b6f9c1d1afd_retain(lb_owned_context *context, const lbov_1d643ee3fbc2aa924d28_t167081552b6f9c1d1afd *input, lbov_1d643ee3fbc2aa924d28_t167081552b6f9c1d1afd *out, ov_result_owner *owner) {
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-subtypes@1.0.0");
  if (status) return status;
  lean_object *value = NULL;
  status = lbov_1d643ee3fbc2aa924d28_v167081552b6f9c1d1afd_in(input, 0, 1, &transaction, &value);
  if (status) return ov_abort(&transaction, status);
  status = lbov_1d643ee3fbc2aa924d28_v167081552b6f9c1d1afd_out(out, value, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  return ov_commit(&transaction, owner);
}
static inline int lbov_1d643ee3fbc2aa924d28_vdc0347e1f7f5c4d928f1_retain(lb_owned_context *context, const lbov_1d643ee3fbc2aa924d28_tdc0347e1f7f5c4d928f1 *input, lbov_1d643ee3fbc2aa924d28_tdc0347e1f7f5c4d928f1 *out, ov_result_owner *owner) {
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-subtypes@1.0.0");
  if (status) return status;
  lean_object *value = NULL;
  status = lbov_1d643ee3fbc2aa924d28_vdc0347e1f7f5c4d928f1_in(input, 0, 1, &transaction, &value);
  if (status) return ov_abort(&transaction, status);
  status = lbov_1d643ee3fbc2aa924d28_vdc0347e1f7f5c4d928f1_out(out, value, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  return ov_commit(&transaction, owner);
}
owned_subtypes_status owned_subtypes_callback_record(owned_subtypes_session *session, owned_subtypes_callback_bundle_t const * a0, owned_subtypes_callback_record_argument1_t_host const * a1, owned_subtypes_callback_bundle_t *out, owned_subtypes_result **owner) {
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_subtypes_callback_bundle_t), owner) || *owner) return (owned_subtypes_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_subtypes_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_subtypes_status)status;
  lbov_1d643ee3fbc2aa924d28_t37c6db88a97448412ed0 raw0 = {0};
  lbov_1d643ee3fbc2aa924d28_t6f9a0eb5450512cec111 raw1 = {0};
  oc_host_v3 borrow1 = {0};
  lbov_1d643ee3fbc2aa924d28_t37c6db88a97448412ed0 returned = {0};
  owned_subtypes_callback_bundle_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v5_to(a0, &raw0, 0, &input);
  if (!status) status = oc_host_v3_begin(&borrow1, a1, active, &budget, &raw1);
  if (!status) status = lbov_1d643ee3fbc2aa924d28_f0838f7ed39f0edac01d9(&active->native, &raw0, &raw1, &returned, &result_owner->native);
  { int cleanup = oc_host_v3_end(&borrow1); if (!status) status = cleanup; }
  if (!status) {
    status = oc_v5_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_subtypes_status)status;
}
owned_subtypes_status owned_subtypes_echo_record(owned_subtypes_session *session, owned_subtypes_bundle_t const * a0, owned_subtypes_bundle_t *out, owned_subtypes_result **owner) {
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_subtypes_bundle_t), owner) || *owner) return (owned_subtypes_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_subtypes_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_subtypes_status)status;
  lbov_1d643ee3fbc2aa924d28_t5faad500583201774348 raw0 = {0};
  lbov_1d643ee3fbc2aa924d28_t5faad500583201774348 returned = {0};
  owned_subtypes_bundle_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v4_to(a0, &raw0, 0, &input);
  if (!status) status = lbov_1d643ee3fbc2aa924d28_f080cb47999bb83cdc0c1(&active->native, &raw0, &returned, &result_owner->native);
  if (!status) {
    status = oc_v4_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_subtypes_status)status;
}
owned_subtypes_status owned_subtypes_echo_record_alternate(owned_subtypes_session *session, owned_subtypes_bundle_t const * a0, owned_subtypes_bundle_t *out, owned_subtypes_result **owner) {
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_subtypes_bundle_t), owner) || *owner) return (owned_subtypes_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_subtypes_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_subtypes_status)status;
  lbov_1d643ee3fbc2aa924d28_t5faad500583201774348 raw0 = {0};
  lbov_1d643ee3fbc2aa924d28_t5faad500583201774348 returned = {0};
  owned_subtypes_bundle_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v4_to(a0, &raw0, 0, &input);
  if (!status) status = lbov_1d643ee3fbc2aa924d28_f579c430cd49e7c98161f(&active->native, &raw0, &returned, &result_owner->native);
  if (!status) {
    status = oc_v4_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_subtypes_status)status;
}
owned_subtypes_status owned_subtypes_new_ticket(owned_subtypes_session *session, mpz_srcptr a0, owned_subtypes_scalar_string_t a1, owned_subtypes_ticket_t *out, owned_subtypes_result **owner) {
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_subtypes_ticket_t), owner) || *owner) return (owned_subtypes_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_subtypes_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_subtypes_status)status;
  lbov_1d643ee3fbc2aa924d28_t167081552b6f9c1d1afd raw0 = {0};
  lbov_1d643ee3fbc2aa924d28_tdc0347e1f7f5c4d928f1 raw1 = {0};
  lbov_1d643ee3fbc2aa924d28_t6de8e950bc342c30091c returned = {0};
  owned_subtypes_ticket_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v11_to(&a0, &raw0, 0, &input);
  if (!status) status = oc_v12_to(&a1, &raw1, 0, &input);
  if (!status) status = lbov_1d643ee3fbc2aa924d28_f9735b5a0a586b46ce0b8(&active->native, &raw0, &raw1, &returned, &result_owner->native);
  if (!status) {
    status = oc_v8_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_subtypes_status)status;
}
owned_subtypes_status owned_subtypes_serial(owned_subtypes_session *session, owned_subtypes_ticket_t a0, mpz_srcptr *out, owned_subtypes_result **owner) {
  if (!oc_outputs(out, sizeof(*out), _Alignof(mpz_srcptr), owner) || *owner) return (owned_subtypes_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_subtypes_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_subtypes_status)status;
  lbov_1d643ee3fbc2aa924d28_t6de8e950bc342c30091c raw0 = {0};
  lbov_1d643ee3fbc2aa924d28_t167081552b6f9c1d1afd returned = {0};
  mpz_srcptr converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v8_to(&a0, &raw0, 0, &input);
  if (!status) status = lbov_1d643ee3fbc2aa924d28_f52957d819a8a28259bf1(&active->native, &raw0, &returned, &result_owner->native);
  if (!status) {
    status = oc_v11_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_subtypes_status)status;
}
owned_subtypes_status owned_subtypes_transfer_record(owned_subtypes_session *session, owned_subtypes_bundle_t const * a0, owned_subtypes_result **a0_owner, owned_subtypes_bundle_t *out, owned_subtypes_result **owner) {
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_subtypes_bundle_t), owner) || *owner) return (owned_subtypes_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_subtypes_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_subtypes_status)status;
  oc_transfer_input transfer_inputs[1] = { { .slot = a0_owner } };
  ov_result_owner *transfer_owners[1] = {0};
  oc_transfer_frame transfer_frame = { .inputs = transfer_inputs, .count = 1 };
  ov_input_transfers transfer = { .owners = transfer_owners, .count = 1, .consume = oc_transfer_consume, .context = &transfer_frame };
  lbov_1d643ee3fbc2aa924d28_t5faad500583201774348 raw0 = {0};
  lbov_1d643ee3fbc2aa924d28_t5faad500583201774348 returned = {0};
  owned_subtypes_bundle_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_transfer_prepare(active, &transfer_frame, transfer_owners, out, sizeof(*out), _Alignof(owned_subtypes_bundle_t), owner);
  if (!status) status = oc_v4_to(a0, &raw0, 0, &input);
  if (!status) status = lbov_1d643ee3fbc2aa924d28_f973a6e63b7dad7a3d147(&active->native, &raw0, &transfer, &returned, &result_owner->native);
  if (!status) {
    status = oc_v4_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_transfer_finish(&transfer_frame, status);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_subtypes_status)status;
}
owned_subtypes_status owned_subtypes_callback_record_argument1_t_call(owned_subtypes_session *session, owned_subtypes_callback_record_argument1_t a0, owned_subtypes_callback_bundle_t const * a1, owned_subtypes_callback_bundle_t *out, owned_subtypes_result **owner) {
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_subtypes_callback_bundle_t), owner) || *owner) return (owned_subtypes_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_subtypes_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_subtypes_status)status;
  lbov_1d643ee3fbc2aa924d28_t6f9a0eb5450512cec111 raw0 = {0};
  lbov_1d643ee3fbc2aa924d28_t37c6db88a97448412ed0 raw1 = {0};
  lbov_1d643ee3fbc2aa924d28_t37c6db88a97448412ed0 returned = {0};
  owned_subtypes_callback_bundle_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v3_to(&a0, &raw0, 0, &input);
  if (!status) status = oc_v5_to(a1, &raw1, 0, &input);
  if (!status) status = lbov_1d643ee3fbc2aa924d28_v6f9a0eb5450512cec111_apply(&active->native, &raw0, &raw1, &returned, &result_owner->native);
  if (!status) {
    status = oc_v5_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_subtypes_status)status;
}
owned_subtypes_status owned_subtypes_callback_record_argument1_t_retain(owned_subtypes_session *session, owned_subtypes_callback_record_argument1_t a0, owned_subtypes_callback_record_argument1_t *out, owned_subtypes_result **owner) {
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_subtypes_callback_record_argument1_t), owner) || *owner) return (owned_subtypes_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_subtypes_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_subtypes_status)status;
  lbov_1d643ee3fbc2aa924d28_t6f9a0eb5450512cec111 raw0 = {0};
  lbov_1d643ee3fbc2aa924d28_t6f9a0eb5450512cec111 returned = {0};
  owned_subtypes_callback_record_argument1_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v3_to(&a0, &raw0, 0, &input);
  if (!status) status = lbov_1d643ee3fbc2aa924d28_v6f9a0eb5450512cec111_retain(&active->native, &raw0, &returned, &result_owner->native);
  if (!status) {
    status = oc_v3_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_subtypes_status)status;
}
owned_subtypes_status owned_subtypes_ticket_t_retain(owned_subtypes_session *session, owned_subtypes_ticket_t a0, owned_subtypes_ticket_t *out, owned_subtypes_result **owner) {
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_subtypes_ticket_t), owner) || *owner) return (owned_subtypes_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_subtypes_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_subtypes_status)status;
  lbov_1d643ee3fbc2aa924d28_t6de8e950bc342c30091c raw0 = {0};
  lbov_1d643ee3fbc2aa924d28_t6de8e950bc342c30091c returned = {0};
  owned_subtypes_ticket_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v8_to(&a0, &raw0, 0, &input);
  if (!status) status = lbov_1d643ee3fbc2aa924d28_v6de8e950bc342c30091c_retain(&active->native, &raw0, &returned, &result_owner->native);
  if (!status) {
    status = oc_v8_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_subtypes_status)status;
}
owned_subtypes_status owned_subtypes_value_82551d965c182180b0dd_t_copy(owned_subtypes_session *session, owned_subtypes_value_82551d965c182180b0dd_t const * a0, owned_subtypes_value_82551d965c182180b0dd_t *out, owned_subtypes_result **owner) {
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_subtypes_value_82551d965c182180b0dd_t), owner) || *owner) return (owned_subtypes_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_subtypes_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_subtypes_status)status;
  lbov_1d643ee3fbc2aa924d28_t82551d965c182180b0dd raw0 = {0};
  lbov_1d643ee3fbc2aa924d28_t82551d965c182180b0dd returned = {0};
  owned_subtypes_value_82551d965c182180b0dd_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v0_to(a0, &raw0, 0, &input);
  if (!status) status = lbov_1d643ee3fbc2aa924d28_v82551d965c182180b0dd_retain(&active->native, &raw0, &returned, &result_owner->native);
  if (!status) {
    status = oc_v0_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_subtypes_status)status;
}
owned_subtypes_status owned_subtypes_value_659ec6a690764999d00d_t_copy(owned_subtypes_session *session, owned_subtypes_value_659ec6a690764999d00d_t const * a0, owned_subtypes_value_659ec6a690764999d00d_t *out, owned_subtypes_result **owner) {
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_subtypes_value_659ec6a690764999d00d_t), owner) || *owner) return (owned_subtypes_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_subtypes_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_subtypes_status)status;
  lbov_1d643ee3fbc2aa924d28_t659ec6a690764999d00d raw0 = {0};
  lbov_1d643ee3fbc2aa924d28_t659ec6a690764999d00d returned = {0};
  owned_subtypes_value_659ec6a690764999d00d_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v1_to(a0, &raw0, 0, &input);
  if (!status) status = lbov_1d643ee3fbc2aa924d28_v659ec6a690764999d00d_retain(&active->native, &raw0, &returned, &result_owner->native);
  if (!status) {
    status = oc_v1_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_subtypes_status)status;
}
owned_subtypes_status owned_subtypes_value_817592654f48ba756bd4_t_copy(owned_subtypes_session *session, owned_subtypes_value_817592654f48ba756bd4_t const * a0, owned_subtypes_value_817592654f48ba756bd4_t *out, owned_subtypes_result **owner) {
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_subtypes_value_817592654f48ba756bd4_t), owner) || *owner) return (owned_subtypes_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_subtypes_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_subtypes_status)status;
  lbov_1d643ee3fbc2aa924d28_t817592654f48ba756bd4 raw0 = {0};
  lbov_1d643ee3fbc2aa924d28_t817592654f48ba756bd4 returned = {0};
  owned_subtypes_value_817592654f48ba756bd4_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v2_to(a0, &raw0, 0, &input);
  if (!status) status = lbov_1d643ee3fbc2aa924d28_v817592654f48ba756bd4_retain(&active->native, &raw0, &returned, &result_owner->native);
  if (!status) {
    status = oc_v2_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_subtypes_status)status;
}
owned_subtypes_status owned_subtypes_bundle_t_copy(owned_subtypes_session *session, owned_subtypes_bundle_t const * a0, owned_subtypes_bundle_t *out, owned_subtypes_result **owner) {
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_subtypes_bundle_t), owner) || *owner) return (owned_subtypes_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_subtypes_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_subtypes_status)status;
  lbov_1d643ee3fbc2aa924d28_t5faad500583201774348 raw0 = {0};
  lbov_1d643ee3fbc2aa924d28_t5faad500583201774348 returned = {0};
  owned_subtypes_bundle_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v4_to(a0, &raw0, 0, &input);
  if (!status) status = lbov_1d643ee3fbc2aa924d28_v5faad500583201774348_retain(&active->native, &raw0, &returned, &result_owner->native);
  if (!status) {
    status = oc_v4_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_subtypes_status)status;
}
owned_subtypes_status owned_subtypes_callback_bundle_t_copy(owned_subtypes_session *session, owned_subtypes_callback_bundle_t const * a0, owned_subtypes_callback_bundle_t *out, owned_subtypes_result **owner) {
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_subtypes_callback_bundle_t), owner) || *owner) return (owned_subtypes_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_subtypes_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_subtypes_status)status;
  lbov_1d643ee3fbc2aa924d28_t37c6db88a97448412ed0 raw0 = {0};
  lbov_1d643ee3fbc2aa924d28_t37c6db88a97448412ed0 returned = {0};
  owned_subtypes_callback_bundle_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v5_to(a0, &raw0, 0, &input);
  if (!status) status = lbov_1d643ee3fbc2aa924d28_v37c6db88a97448412ed0_retain(&active->native, &raw0, &returned, &result_owner->native);
  if (!status) {
    status = oc_v5_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_subtypes_status)status;
}
owned_subtypes_status owned_subtypes_callback_payload_t_copy(owned_subtypes_session *session, owned_subtypes_callback_payload_t const * a0, owned_subtypes_callback_payload_t *out, owned_subtypes_result **owner) {
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_subtypes_callback_payload_t), owner) || *owner) return (owned_subtypes_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_subtypes_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_subtypes_status)status;
  lbov_1d643ee3fbc2aa924d28_tf197109068e846c0739c raw0 = {0};
  lbov_1d643ee3fbc2aa924d28_tf197109068e846c0739c returned = {0};
  owned_subtypes_callback_payload_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v6_to(a0, &raw0, 0, &input);
  if (!status) status = lbov_1d643ee3fbc2aa924d28_vf197109068e846c0739c_retain(&active->native, &raw0, &returned, &result_owner->native);
  if (!status) {
    status = oc_v6_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_subtypes_status)status;
}
owned_subtypes_status owned_subtypes_payload_t_copy(owned_subtypes_session *session, owned_subtypes_payload_t const * a0, owned_subtypes_payload_t *out, owned_subtypes_result **owner) {
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_subtypes_payload_t), owner) || *owner) return (owned_subtypes_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_subtypes_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_subtypes_status)status;
  lbov_1d643ee3fbc2aa924d28_t550e0acb733e8dd08e4e raw0 = {0};
  lbov_1d643ee3fbc2aa924d28_t550e0acb733e8dd08e4e returned = {0};
  owned_subtypes_payload_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v7_to(a0, &raw0, 0, &input);
  if (!status) status = lbov_1d643ee3fbc2aa924d28_v550e0acb733e8dd08e4e_retain(&active->native, &raw0, &returned, &result_owner->native);
  if (!status) {
    status = oc_v7_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_subtypes_status)status;
}
owned_subtypes_status owned_subtypes_scalar_bytes_copy(owned_subtypes_session *session, owned_subtypes_scalar_bytes_t a0, owned_subtypes_scalar_bytes_t *out, owned_subtypes_result **owner) {
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_subtypes_scalar_bytes_t), owner) || *owner) return (owned_subtypes_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_subtypes_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_subtypes_status)status;
  lbov_1d643ee3fbc2aa924d28_tf098e5912ebfda269f53 raw0 = {0};
  lbov_1d643ee3fbc2aa924d28_tf098e5912ebfda269f53 returned = {0};
  owned_subtypes_scalar_bytes_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v9_to(&a0, &raw0, 0, &input);
  if (!status) status = lbov_1d643ee3fbc2aa924d28_vf098e5912ebfda269f53_retain(&active->native, &raw0, &returned, &result_owner->native);
  if (!status) {
    status = oc_v9_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_subtypes_status)status;
}
owned_subtypes_status owned_subtypes_scalar_int_copy(owned_subtypes_session *session, mpz_srcptr a0, mpz_srcptr *out, owned_subtypes_result **owner) {
  if (!oc_outputs(out, sizeof(*out), _Alignof(mpz_srcptr), owner) || *owner) return (owned_subtypes_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_subtypes_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_subtypes_status)status;
  lbov_1d643ee3fbc2aa924d28_t11140334dba7a15b6b99 raw0 = {0};
  lbov_1d643ee3fbc2aa924d28_t11140334dba7a15b6b99 returned = {0};
  mpz_srcptr converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v10_to(&a0, &raw0, 0, &input);
  if (!status) status = lbov_1d643ee3fbc2aa924d28_v11140334dba7a15b6b99_retain(&active->native, &raw0, &returned, &result_owner->native);
  if (!status) {
    status = oc_v10_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_subtypes_status)status;
}
owned_subtypes_status owned_subtypes_scalar_nat_copy(owned_subtypes_session *session, mpz_srcptr a0, mpz_srcptr *out, owned_subtypes_result **owner) {
  if (!oc_outputs(out, sizeof(*out), _Alignof(mpz_srcptr), owner) || *owner) return (owned_subtypes_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_subtypes_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_subtypes_status)status;
  lbov_1d643ee3fbc2aa924d28_t167081552b6f9c1d1afd raw0 = {0};
  lbov_1d643ee3fbc2aa924d28_t167081552b6f9c1d1afd returned = {0};
  mpz_srcptr converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v11_to(&a0, &raw0, 0, &input);
  if (!status) status = lbov_1d643ee3fbc2aa924d28_v167081552b6f9c1d1afd_retain(&active->native, &raw0, &returned, &result_owner->native);
  if (!status) {
    status = oc_v11_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_subtypes_status)status;
}
owned_subtypes_status owned_subtypes_scalar_string_copy(owned_subtypes_session *session, owned_subtypes_scalar_string_t a0, owned_subtypes_scalar_string_t *out, owned_subtypes_result **owner) {
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_subtypes_scalar_string_t), owner) || *owner) return (owned_subtypes_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_subtypes_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_subtypes_status)status;
  lbov_1d643ee3fbc2aa924d28_tdc0347e1f7f5c4d928f1 raw0 = {0};
  lbov_1d643ee3fbc2aa924d28_tdc0347e1f7f5c4d928f1 returned = {0};
  owned_subtypes_scalar_string_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v12_to(&a0, &raw0, 0, &input);
  if (!status) status = lbov_1d643ee3fbc2aa924d28_vdc0347e1f7f5c4d928f1_retain(&active->native, &raw0, &returned, &result_owner->native);
  if (!status) {
    status = oc_v12_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_subtypes_status)status;
}
