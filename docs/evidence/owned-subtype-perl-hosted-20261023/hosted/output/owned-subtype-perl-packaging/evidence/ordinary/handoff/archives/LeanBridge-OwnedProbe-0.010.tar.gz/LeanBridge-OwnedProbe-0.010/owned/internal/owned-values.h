#pragma once
#include <stdint.h>
#include <stddef.h>
/* Private generated adapter values. Host APIs keep resource tokens opaque. */
typedef struct lbov_1d643ee3fbc2aa924d28_t82551d965c182180b0dd lbov_1d643ee3fbc2aa924d28_t82551d965c182180b0dd;
typedef struct lbov_1d643ee3fbc2aa924d28_t659ec6a690764999d00d lbov_1d643ee3fbc2aa924d28_t659ec6a690764999d00d;
typedef struct lbov_1d643ee3fbc2aa924d28_t817592654f48ba756bd4 lbov_1d643ee3fbc2aa924d28_t817592654f48ba756bd4;
typedef struct lbov_1d643ee3fbc2aa924d28_t6f9a0eb5450512cec111 lbov_1d643ee3fbc2aa924d28_t6f9a0eb5450512cec111;
typedef struct lbov_1d643ee3fbc2aa924d28_t5faad500583201774348 lbov_1d643ee3fbc2aa924d28_t5faad500583201774348;
typedef struct lbov_1d643ee3fbc2aa924d28_t37c6db88a97448412ed0 lbov_1d643ee3fbc2aa924d28_t37c6db88a97448412ed0;
typedef struct lbov_1d643ee3fbc2aa924d28_tf197109068e846c0739c lbov_1d643ee3fbc2aa924d28_tf197109068e846c0739c;
typedef struct lbov_1d643ee3fbc2aa924d28_t550e0acb733e8dd08e4e lbov_1d643ee3fbc2aa924d28_t550e0acb733e8dd08e4e;
typedef struct lbov_1d643ee3fbc2aa924d28_t6de8e950bc342c30091c lbov_1d643ee3fbc2aa924d28_t6de8e950bc342c30091c;
typedef struct lbov_1d643ee3fbc2aa924d28_tf098e5912ebfda269f53 lbov_1d643ee3fbc2aa924d28_tf098e5912ebfda269f53;
typedef struct lbov_1d643ee3fbc2aa924d28_t11140334dba7a15b6b99 lbov_1d643ee3fbc2aa924d28_t11140334dba7a15b6b99;
typedef struct lbov_1d643ee3fbc2aa924d28_t167081552b6f9c1d1afd lbov_1d643ee3fbc2aa924d28_t167081552b6f9c1d1afd;
typedef struct lbov_1d643ee3fbc2aa924d28_tdc0347e1f7f5c4d928f1 lbov_1d643ee3fbc2aa924d28_tdc0347e1f7f5c4d928f1;
struct lbov_1d643ee3fbc2aa924d28_t6f9a0eb5450512cec111 {
  uint64_t token;
};
struct lbov_1d643ee3fbc2aa924d28_t6de8e950bc342c30091c {
  uint64_t token;
};
struct lbov_1d643ee3fbc2aa924d28_tf098e5912ebfda269f53 {
  const uint8_t *data;
  size_t length;
};
struct lbov_1d643ee3fbc2aa924d28_t11140334dba7a15b6b99 {
  const uint32_t *data;
  size_t length;
  uint8_t negative;
};
struct lbov_1d643ee3fbc2aa924d28_t167081552b6f9c1d1afd {
  const uint32_t *data;
  size_t length;
};
struct lbov_1d643ee3fbc2aa924d28_tdc0347e1f7f5c4d928f1 {
  const char *data;
  size_t length;
};
struct lbov_1d643ee3fbc2aa924d28_t82551d965c182180b0dd {
  const lbov_1d643ee3fbc2aa924d28_t6de8e950bc342c30091c *data;
  size_t length;
};
struct lbov_1d643ee3fbc2aa924d28_t659ec6a690764999d00d {
  const lbov_1d643ee3fbc2aa924d28_t6de8e950bc342c30091c *data;
  size_t length;
};
struct lbov_1d643ee3fbc2aa924d28_t817592654f48ba756bd4 {
  uint8_t tag;
  lbov_1d643ee3fbc2aa924d28_t6de8e950bc342c30091c f0;
};
struct lbov_1d643ee3fbc2aa924d28_t5faad500583201774348 {
  lbov_1d643ee3fbc2aa924d28_t6de8e950bc342c30091c f0;
  const lbov_1d643ee3fbc2aa924d28_t817592654f48ba756bd4 *f1;
  const lbov_1d643ee3fbc2aa924d28_t659ec6a690764999d00d *f2;
  const lbov_1d643ee3fbc2aa924d28_t82551d965c182180b0dd *f3;
  const lbov_1d643ee3fbc2aa924d28_t550e0acb733e8dd08e4e *f4;
};
struct lbov_1d643ee3fbc2aa924d28_t37c6db88a97448412ed0 {
  lbov_1d643ee3fbc2aa924d28_t6de8e950bc342c30091c f0;
  const lbov_1d643ee3fbc2aa924d28_tf197109068e846c0739c *f1;
};
struct lbov_1d643ee3fbc2aa924d28_tf197109068e846c0739c {
  lbov_1d643ee3fbc2aa924d28_t11140334dba7a15b6b99 f0;
  lbov_1d643ee3fbc2aa924d28_tf098e5912ebfda269f53 f1;
};
struct lbov_1d643ee3fbc2aa924d28_t550e0acb733e8dd08e4e {
  lbov_1d643ee3fbc2aa924d28_t11140334dba7a15b6b99 f0;
  lbov_1d643ee3fbc2aa924d28_tf098e5912ebfda269f53 f1;
};
