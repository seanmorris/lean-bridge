#include "component.h"
#include "lean_bridge_native_runtime.h"
static _Thread_local int lean_bridge_owned_callback_failure_27b5ca5aeca678a59ac4_state;
int lean_bridge_owned_callback_failure_27b5ca5aeca678a59ac4(void) { int result = lean_bridge_owned_callback_failure_27b5ca5aeca678a59ac4_state; lean_bridge_owned_callback_failure_27b5ca5aeca678a59ac4_state = 0; return result; }
lean_object *lean_bridge_owned_09b5a73d7788c7206a768477_t6f9a0eb5450512cec111_invoke(size_t token, lean_object *a0) {
  lb_native_callback callback = lb_native_callback_lookup(token);
  if (!callback.invoke) {
    lean_dec(a0);
    return lean_alloc_array(0, 0);
  }
  return ((lean_object *(*)(void *, lean_object *))callback.invoke)(callback.context, a0);
}
