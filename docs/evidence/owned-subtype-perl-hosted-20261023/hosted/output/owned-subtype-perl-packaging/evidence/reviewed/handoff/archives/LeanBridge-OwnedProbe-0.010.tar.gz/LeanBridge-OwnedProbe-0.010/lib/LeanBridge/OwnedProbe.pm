package LeanBridge::OwnedProbe;
use strict;
use warnings;
use Math::BigInt;
# Fields are validated and snapshotted at the native call boundary.
# Resource and closure identities are created and checked by the XS adapter.

sub true () { !!1 }
sub false () { !!0 }
package LeanBridge::OwnedProbe::Some;
sub new {
  CORE::die "Some->new expects one payload\n" unless @_ == 2 && CORE::defined($_[0]) && !CORE::ref($_[0]) && $_[0] eq 'LeanBridge::OwnedProbe::Some';
  return CORE::bless {value => $_[1]}, 'LeanBridge::OwnedProbe::Some';
}
sub value { $_[0]->{value} }

package LeanBridge::OwnedProbe::Callback40c82bf938a942cf2402;
sub new { CORE::die "Resources and closures are returned by Lean functions\n" }
sub CLONE_SKIP { 1 }
sub STORABLE_freeze { CORE::die "Lean identities cannot be serialized\n" }
sub STORABLE_thaw { CORE::die "Lean identities cannot be deserialized\n" }

package LeanBridge::OwnedProbe::Bundle;
sub new {
  CORE::die "LeanBridge::OwnedProbe::Bundle->new expects named fields\n" unless @_ % 2 == 1 && CORE::defined($_[0]) && !CORE::ref($_[0]) && $_[0] eq 'LeanBridge::OwnedProbe::Bundle';
  CORE::shift; my %fields;
  while (@_) {
    my ($key, $value) = CORE::splice @_, 0, 2;
    CORE::die "invalid field name\n" if !CORE::defined($key) || CORE::ref($key);
    CORE::die "duplicate constructor field\n" if CORE::exists($fields{$key});
    $fields{$key} = $value;
  }
  my @required = qw(primary spare peers history payload);
  CORE::die "fields do not match the generated schema\n" if CORE::keys(%fields) != @required || CORE::grep { !CORE::exists($fields{$_}) } @required;
  return CORE::bless \%fields, 'LeanBridge::OwnedProbe::Bundle';
}
# primary: Ticket
sub primary { $_[0]->{primary} }
# spare: option<Ticket>
sub spare { $_[0]->{spare} }
# peers: array<Ticket>
sub peers { $_[0]->{peers} }
# history: list<Ticket>
sub history { $_[0]->{history} }
# payload: Payload
sub payload { $_[0]->{payload} }

package LeanBridge::OwnedProbe::CallbackBundle;
sub new {
  CORE::die "LeanBridge::OwnedProbe::CallbackBundle->new expects named fields\n" unless @_ % 2 == 1 && CORE::defined($_[0]) && !CORE::ref($_[0]) && $_[0] eq 'LeanBridge::OwnedProbe::CallbackBundle';
  CORE::shift; my %fields;
  while (@_) {
    my ($key, $value) = CORE::splice @_, 0, 2;
    CORE::die "invalid field name\n" if !CORE::defined($key) || CORE::ref($key);
    CORE::die "duplicate constructor field\n" if CORE::exists($fields{$key});
    $fields{$key} = $value;
  }
  my @required = qw(primary payload);
  CORE::die "fields do not match the generated schema\n" if CORE::keys(%fields) != @required || CORE::grep { !CORE::exists($fields{$_}) } @required;
  return CORE::bless \%fields, 'LeanBridge::OwnedProbe::CallbackBundle';
}
# primary: Ticket
sub primary { $_[0]->{primary} }
# payload: CallbackPayload
sub payload { $_[0]->{payload} }

package LeanBridge::OwnedProbe::CallbackPayload;
sub new {
  CORE::die "LeanBridge::OwnedProbe::CallbackPayload->new expects named fields\n" unless @_ % 2 == 1 && CORE::defined($_[0]) && !CORE::ref($_[0]) && $_[0] eq 'LeanBridge::OwnedProbe::CallbackPayload';
  CORE::shift; my %fields;
  while (@_) {
    my ($key, $value) = CORE::splice @_, 0, 2;
    CORE::die "invalid field name\n" if !CORE::defined($key) || CORE::ref($key);
    CORE::die "duplicate constructor field\n" if CORE::exists($fields{$key});
    $fields{$key} = $value;
  }
  my @required = qw(count bytes);
  CORE::die "fields do not match the generated schema\n" if CORE::keys(%fields) != @required || CORE::grep { !CORE::exists($fields{$_}) } @required;
  return CORE::bless \%fields, 'LeanBridge::OwnedProbe::CallbackPayload';
}
# count: int
sub count { $_[0]->{count} }
# bytes: bytes
sub bytes { $_[0]->{bytes} }

package LeanBridge::OwnedProbe::Payload;
sub new {
  CORE::die "LeanBridge::OwnedProbe::Payload->new expects named fields\n" unless @_ % 2 == 1 && CORE::defined($_[0]) && !CORE::ref($_[0]) && $_[0] eq 'LeanBridge::OwnedProbe::Payload';
  CORE::shift; my %fields;
  while (@_) {
    my ($key, $value) = CORE::splice @_, 0, 2;
    CORE::die "invalid field name\n" if !CORE::defined($key) || CORE::ref($key);
    CORE::die "duplicate constructor field\n" if CORE::exists($fields{$key});
    $fields{$key} = $value;
  }
  my @required = qw(count bytes);
  CORE::die "fields do not match the generated schema\n" if CORE::keys(%fields) != @required || CORE::grep { !CORE::exists($fields{$_}) } @required;
  return CORE::bless \%fields, 'LeanBridge::OwnedProbe::Payload';
}
# count: int
sub count { $_[0]->{count} }
# bytes: bytes
sub bytes { $_[0]->{bytes} }

package LeanBridge::OwnedProbe::Ticket;
sub new { CORE::die "Resources and closures are returned by Lean functions\n" }
sub CLONE_SKIP { 1 }
sub STORABLE_freeze { CORE::die "Lean identities cannot be serialized\n" }
sub STORABLE_thaw { CORE::die "Lean identities cannot be deserialized\n" }

1;

package LeanBridge::OwnedProbe::Runtime::Callback;
sub new {
  CORE::die "LeanBridge::OwnedProbe::Runtime::Callback->new expects code and recovery\n"
    unless @_ == 5 && CORE::defined($_[0]) && !CORE::ref($_[0]) && $_[0] eq 'LeanBridge::OwnedProbe::Runtime::Callback';
  CORE::shift; my %fields = @_;
  CORE::die "expected code and recovery fields\n"
    unless CORE::keys(%fields) == 2 && CORE::exists($fields{code}) && CORE::exists($fields{recovery});
  CORE::die "expected a Perl code reference\n" unless CORE::ref($fields{code}) eq 'CODE';
  return CORE::bless \%fields, 'LeanBridge::OwnedProbe::Runtime::Callback';
}

1;

package LeanBridge::OwnedProbe;
use LeanBridge::Runtime;
die "Incompatible shared Lean runtime package version\n" unless $LeanBridge::Runtime::VERSION eq '0.0020130180835253351074425099676719723942806298898514237203907626409680523998624031';
use LeanBridge::Runtime::OwnedAssets;
use DynaLoader ();
use Cwd ();
use Config ();
use JSON::PP ();
our $VERSION = '0.010';
my $root = Cwd::abs_path(__FILE__); $root =~ s/\.pm\z//;
my $xs_sha256 = '__LEAN_BRIDGE_OWNED_XS_SHA256__';
die "Install this owned Perl package before loading its XS\n" unless $xs_sha256 =~ /\A[0-9a-f]{64}\z/;
LeanBridge::Runtime::_check_component('6f4dbd1e2e112f4678734553d1c9bb8722fad3e6290adbff1ac46d05e5eff7dd', { 'Owned' => 'c0346b3446761904f3d0e1dfe5c057e2f18418929d088feca3d373488fa34042' }, 'owned-subtypes@1.0.0', '7baf7525088e171e39bc6436d128993d9c5b889fc1e6c58bfdd1eef98977f673');
LeanBridge::Runtime::Platform::installed_abi(JSON::PP->new->decode(LeanBridge::Runtime::_read("$root/install-receipt.json")));
my $base = Cwd::abs_path(__FILE__); $base =~ s{\QLeanBridge/OwnedProbe.pm\E\z}{};
my $xs_path;
for my $directory ($base, @INC) {
  next if ref($directory);
  my $candidate = "$directory/auto/LeanBridge/OwnedProbe/OwnedProbe.$Config::Config{dlext}";
  if (-f $candidate) { $xs_path = Cwd::abs_path($candidate); last; }
}
die "Cannot find the installed owned XS image\n" unless defined $xs_path;
my $paths = LeanBridge::Runtime::OwnedAssets::load([
  { path => "$root/native/libgmp-lean-bridge.so.10", soname => 'libgmp-lean-bridge.so.10', sha256 => '9687f8d50f5c413728d4fcc8d96328912239ce8b1269cbb9a1ff793e430a7b27' },
  { path => "$root/native/libcomponent_df500c005a7a829ba06c.so", soname => 'libcomponent_df500c005a7a829ba06c.so', sha256 => '7baf7525088e171e39bc6436d128993d9c5b889fc1e6c58bfdd1eef98977f673' },
  { path => $xs_path, sha256 => $xs_sha256 }
]);
LeanBridge::Runtime::_record_component('6f4dbd1e2e112f4678734553d1c9bb8722fad3e6290adbff1ac46d05e5eff7dd', { 'Owned' => 'c0346b3446761904f3d0e1dfe5c057e2f18418929d088feca3d373488fa34042' }, 'owned-subtypes@1.0.0', '7baf7525088e171e39bc6436d128993d9c5b889fc1e6c58bfdd1eef98977f673');
my $library = DynaLoader::dl_load_file($paths->[-1], 0) or die DynaLoader::dl_error();
my $symbol = DynaLoader::dl_find_symbol($library, 'boot_LeanBridge__OwnedProbe') or die DynaLoader::dl_error();
my $bootstrap = DynaLoader::dl_install_xsub('LeanBridge::OwnedProbe::Runtime::_bootstrap', $symbol, $paths->[-1]);
$bootstrap->(__PACKAGE__, $VERSION);
sub CLONE_SKIP { 1 }
1;

__END__
=head1 NAME

LeanBridge::OwnedProbe - Generated owned Lean values and synchronous callbacks

=head1 API

=head2 callback_record

Calls C<Owned.callbackRecord> in the compiled Lean component.

=head2 echo_record

Calls C<Owned.echoRecord> in the compiled Lean component.

=head2 echo_record_alternate

Calls C<Owned.echoRecordAlternate> in the compiled Lean component.

=head2 new_ticket

Calls C<Owned.newTicket> in the compiled Lean component.

=head2 serial

Calls C<Owned.serial> in the compiled Lean component.

=head2 transfer_record

Calls C<Owned.transferRecord> in the compiled Lean component.

Consumes resource leases in C<arg0> at the Lean call boundary.

=head1 VALUES AND OWNERSHIP

Records and variants use generated named-field classes. Arrays, Lists and
products use array references. None and Unit use undef; Some->new(undef) keeps
optional Unit distinct from None. Ok and Err preserve their result branches.
Nat and Int use Math::BigInt. Text retains Unicode and NUL; ByteArray uses octets.

Resources and Lean closures provide close, closed and retain. Retained results
own independent native references. Close is idempotent; finalization releases
unclosed owners. Closing an input during a call does not invalidate its active
borrow. Callback arguments expire on return unless explicitly retained.

Consuming arguments use ordinary Perl values. Validation and native snapshot
preparation happen before handoff. At the Lean call boundary, shared aliases and
sibling resources using the same result owner close together. Independent
retains survive. Retain callback borrows before transferring them. Two consuming
arguments cannot share a resource lease. Pre-handoff errors preserve ownership;
callback and result-conversion failures after handoff leave inputs consumed.

Pass CODE references for synchronous callbacks. Signatures that require a typed
recovery value accept Runtime::Callback->new(code => ..., recovery => ...).
Perl exceptions retain their identity after native cleanup. Host callbacks
cannot escape their initiating call. Owners cannot be serialized or used by a
different process or interpreter thread.

=head1 INSTALLATION

The runtime dependency is installed with this package. A compatible prebuilt XS
image needs no compiler. Otherwise installation compiles the supplied XS and C
adapter with local Perl headers. Lean, Lake and Node are not required.

=cut
