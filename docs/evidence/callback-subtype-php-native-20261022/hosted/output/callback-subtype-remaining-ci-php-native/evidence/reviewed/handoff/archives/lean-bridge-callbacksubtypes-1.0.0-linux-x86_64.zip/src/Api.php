<?php
declare(strict_types=1);
namespace LeanCallbacksubtypes;

require_once __DIR__ . '/Internal/Values.php';


final class LeanBridgeError extends \RuntimeException {}

final readonly class Bytes implements \Stringable, \Countable
{
    private function __construct(private string $value) {}
    public static function fromString(mixed $value): self {
        if (!\is_string($value)) throw new \TypeError('Bytes requires a string');
        return new self($value);
    }
    public function toString(): string { return $this->value; }
    public function __toString(): string { return $this->value; }
    public function count(): int { return \strlen($this->value); }

    public function equals(mixed $other): bool {
        return $other instanceof self && Internal\Values::equal($this, $other);
    }
    public function hashCode(): string { return Internal\Values::hash($this); }

}


/** @template T */
final readonly class Some
{
    /** @var T */
    public mixed $value;
    /** @param T $value */
    public function __construct(mixed $value) {
        if (\func_num_args() !== 1) throw new \ArgumentCountError('Some requires one payload');
        $this->value = $value;
    }

    public function equals(mixed $other): bool {
        return $other instanceof self && Internal\Values::equal($this, $other);
    }
    public function hashCode(): string { return Internal\Values::hash($this); }

}

/** @template T */
final readonly class Ok
{
    /** @var T */
    public mixed $value;
    /** @param T $value */
    public function __construct(mixed $value) {
        if (\func_num_args() !== 1) throw new \ArgumentCountError('Ok requires one payload');
        $this->value = $value;
    }

    public function equals(mixed $other): bool {
        return $other instanceof self && Internal\Values::equal($this, $other);
    }
    public function hashCode(): string { return Internal\Values::hash($this); }

}

/** @template T */
final readonly class Err
{
    /** @var T */
    public mixed $value;
    /** @param T $value */
    public function __construct(mixed $value) {
        if (\func_num_args() !== 1) throw new \ArgumentCountError('Err requires one payload');
        $this->value = $value;
    }

    public function equals(mixed $other): bool {
        return $other instanceof self && Internal\Values::equal($this, $other);
    }
    public function hashCode(): string { return Internal\Values::hash($this); }

}




final class LeanClosure
{
    private function __construct(private Internal\Lease $lease) {}
    private function __clone() {}
    public function __invoke(mixed ...$arguments): mixed { return $this->lease->invoke($arguments); }
    public function isClosed(): bool { return $this->lease->isClosed(); }
    public function close(): void { $this->lease->close(); }
    public function __serialize(): array { throw new \LogicException('Lean closures cannot be serialized'); }
    public function __unserialize(array $data): void { throw new \LogicException('Lean closures cannot be unserialized'); }
}

final readonly class WithRecovery
{
    public function __construct(public mixed $function, public mixed $recovery) {
        if (\func_num_args() !== 2) throw new \ArgumentCountError('WithRecovery requires a callback and typed value');
        if (!\is_callable($function)) throw new \TypeError('WithRecovery requires a synchronous callable');
    }
}
function with_recovery(mixed $function, mixed $recovery): WithRecovery {
    if (\func_num_args() !== 2) throw new \ArgumentCountError('with_recovery requires a callback and typed value');
    return new WithRecovery($function, $recovery);
}

require_once __DIR__ . '/Internal/Native.php';

/**
 * @param WithRecovery $arg0
 * @return \Brick\Math\BigInteger
 */
function call_host(mixed $arg0): \Brick\Math\BigInteger {
    if (\func_num_args() !== 1) throw new \ArgumentCountError('call_host requires exactly 1 arguments');
    return Internal\Native::call('call_host', [$arg0]);
}

/**
 * @param WithRecovery $arg0
 * @return Ok<Some<\Brick\Math\BigInteger>|null>|Err<string>
 */
function call_host_container(mixed $arg0): Ok|Err {
    if (\func_num_args() !== 1) throw new \ArgumentCountError('call_host_container requires exactly 1 arguments');
    return Internal\Native::call('call_host_container', [$arg0]);
}

/**
 * @param WithRecovery $arg0
 * @return \Brick\Math\BigInteger
 */
function call_host_mixed(mixed $arg0): \Brick\Math\BigInteger {
    if (\func_num_args() !== 1) throw new \ArgumentCountError('call_host_mixed requires exactly 1 arguments');
    return Internal\Native::call('call_host_mixed', [$arg0]);
}

/**
 * @param \Brick\Math\BigInteger $arg0
 * @return LeanClosure&callable(\Brick\Math\BigInteger): \Brick\Math\BigInteger
 */
function make_closure(mixed $arg0): LeanClosure {
    if (\func_num_args() !== 1) throw new \ArgumentCountError('make_closure requires exactly 1 arguments');
    return Internal\Native::call('make_closure', [$arg0]);
}

/**
 * @param \Brick\Math\BigInteger $arg0
 * @return LeanClosure&callable(list<Some<\Brick\Math\BigInteger>|null>): Some<\Brick\Math\BigInteger>|null
 */
function make_container_closure(mixed $arg0): LeanClosure {
    if (\func_num_args() !== 1) throw new \ArgumentCountError('make_container_closure requires exactly 1 arguments');
    return Internal\Native::call('make_container_closure', [$arg0]);
}

/**
 * @param \Brick\Math\BigInteger $arg0
 * @return LeanClosure&callable(\Brick\Math\BigInteger, \Brick\Math\BigInteger): \Brick\Math\BigInteger
 */
function make_mixed_closure(mixed $arg0): LeanClosure {
    if (\func_num_args() !== 1) throw new \ArgumentCountError('make_mixed_closure requires exactly 1 arguments');
    return Internal\Native::call('make_mixed_closure', [$arg0]);
}
