<?php
declare(strict_types=1);
namespace LeanCallbacksubtypes\Internal;

final class GraphTypes
{
    public const NODES = [
        ['kind' => 'option', 'element' => null, 'fields' => [['value', 3]], 'classes' => ['LeanCallbacksubtypes\\Some']],
        ['kind' => 'result', 'element' => null, 'fields' => [['ok', 0], ['error', 4]], 'classes' => ['LeanCallbacksubtypes\\Ok', 'LeanCallbacksubtypes\\Err']],
        ['kind' => 'array', 'element' => 0, 'fields' => [], 'classes' => []],
        ['kind' => 'primitive', 'name' => 'nat', 'host' => 'bigint', 'min' => '0', 'max' => null],
        ['kind' => 'primitive', 'name' => 'string'],
        ['kind' => 'primitive', 'name' => 'unit'],
    ];
    public const CLASSES = [
        'LeanCallbacksubtypes\\Some' => ['fields' => [['value', null]]],
        'LeanCallbacksubtypes\\Ok' => ['fields' => [['value', null]]],
        'LeanCallbacksubtypes\\Err' => ['fields' => [['value', null]]],
    ];
}
