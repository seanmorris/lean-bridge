#ifndef CALLBACKSUBTYPES_COPIED_GRAPH_H
#define CALLBACKSUBTYPES_COPIED_GRAPH_H
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <string.h>

typedef struct callbacksubtypes_graph_743764d1b67e81fcae92_t callbacksubtypes_graph_743764d1b67e81fcae92_t;
typedef struct callbacksubtypes_graph_2c6f4131c8731fa67588_t callbacksubtypes_graph_2c6f4131c8731fa67588_t;
typedef struct callbacksubtypes_graph_6c9c0cf3d3abf9adeb4b_t callbacksubtypes_graph_6c9c0cf3d3abf9adeb4b_t;
typedef struct callbacksubtypes_scalar_nat_t callbacksubtypes_scalar_nat_t;
typedef struct callbacksubtypes_scalar_string_t callbacksubtypes_scalar_string_t;
struct callbacksubtypes_scalar_nat_t {
  void *_bridge_owner;
  void (*_bridge_release)(void *owner);
  const uint32_t *data;
  size_t length;
};
static inline void callbacksubtypes_scalar_nat_t_init(callbacksubtypes_scalar_nat_t *value) {
  if (!value) return;
  memset(value, 0, sizeof(*value));
}
static inline void callbacksubtypes_scalar_nat_t_clear(callbacksubtypes_scalar_nat_t *value) {
  if (!value) return;
  void *owner = value->_bridge_owner;
  void (*release)(void *) = value->_bridge_release;
  callbacksubtypes_scalar_nat_t_init(value);
  if (owner && release) release(owner);
}

struct callbacksubtypes_graph_743764d1b67e81fcae92_t {
  void *_bridge_owner;
  void (*_bridge_release)(void *owner);
  uint8_t has_value;
  callbacksubtypes_scalar_nat_t value;
};
static inline void callbacksubtypes_graph_743764d1b67e81fcae92_t_init(callbacksubtypes_graph_743764d1b67e81fcae92_t *value) {
  if (!value) return;
  memset(value, 0, sizeof(*value));
}
static inline void callbacksubtypes_graph_743764d1b67e81fcae92_t_clear(callbacksubtypes_graph_743764d1b67e81fcae92_t *value) {
  if (!value) return;
  void *owner = value->_bridge_owner;
  void (*release)(void *) = value->_bridge_release;
  callbacksubtypes_graph_743764d1b67e81fcae92_t_init(value);
  if (owner && release) release(owner);
}

struct callbacksubtypes_scalar_string_t {
  void *_bridge_owner;
  void (*_bridge_release)(void *owner);
  const char *data;
  size_t length;
};
static inline void callbacksubtypes_scalar_string_t_init(callbacksubtypes_scalar_string_t *value) {
  if (!value) return;
  memset(value, 0, sizeof(*value));
}
static inline void callbacksubtypes_scalar_string_t_clear(callbacksubtypes_scalar_string_t *value) {
  if (!value) return;
  void *owner = value->_bridge_owner;
  void (*release)(void *) = value->_bridge_release;
  callbacksubtypes_scalar_string_t_init(value);
  if (owner && release) release(owner);
}

struct callbacksubtypes_graph_2c6f4131c8731fa67588_t {
  void *_bridge_owner;
  void (*_bridge_release)(void *owner);
  uint8_t is_ok;
  callbacksubtypes_graph_743764d1b67e81fcae92_t ok;
  callbacksubtypes_scalar_string_t error;
};
static inline void callbacksubtypes_graph_2c6f4131c8731fa67588_t_init(callbacksubtypes_graph_2c6f4131c8731fa67588_t *value) {
  if (!value) return;
  memset(value, 0, sizeof(*value));
}
static inline void callbacksubtypes_graph_2c6f4131c8731fa67588_t_clear(callbacksubtypes_graph_2c6f4131c8731fa67588_t *value) {
  if (!value) return;
  void *owner = value->_bridge_owner;
  void (*release)(void *) = value->_bridge_release;
  callbacksubtypes_graph_2c6f4131c8731fa67588_t_init(value);
  if (owner && release) release(owner);
}

struct callbacksubtypes_graph_6c9c0cf3d3abf9adeb4b_t {
  void *_bridge_owner;
  void (*_bridge_release)(void *owner);
  const callbacksubtypes_graph_743764d1b67e81fcae92_t *data;
  size_t length;
};
static inline void callbacksubtypes_graph_6c9c0cf3d3abf9adeb4b_t_init(callbacksubtypes_graph_6c9c0cf3d3abf9adeb4b_t *value) {
  if (!value) return;
  memset(value, 0, sizeof(*value));
}
static inline void callbacksubtypes_graph_6c9c0cf3d3abf9adeb4b_t_clear(callbacksubtypes_graph_6c9c0cf3d3abf9adeb4b_t *value) {
  if (!value) return;
  void *owner = value->_bridge_owner;
  void (*release)(void *) = value->_bridge_release;
  callbacksubtypes_graph_6c9c0cf3d3abf9adeb4b_t_init(value);
  if (owner && release) release(owner);
}


#endif /* CALLBACKSUBTYPES_COPIED_GRAPH_H */
