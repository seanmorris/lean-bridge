import CallbackSubtypes
set_option maxRecDepth 10000
namespace LeanBridgeNative730462696d8af341
def carrierValue {α : Type} (value : _root_.Array α) : _root_.Option α :=
  if bound : 0 < value.size then
    if value.size == 1 then .some (value[0]'bound) else .none
  else .none

def carrierResult {α : Type} (value : _root_.Option α) : _root_.Array α :=
  match value with | .none => #[] | .some result => #[result]

def carrierCollect {α : Type} (values : _root_.Array (_root_.Array α)) : _root_.Option (_root_.Array α) := Id.run do
  if values.size > 262144 then return .none
  let mut result := #[]
  for value in values do
    match carrierValue value with
    | .none => return .none
    | .some item => result := result.push item
  return .some result

def carrierListItems {α : Type} (values : _root_.List α) : _root_.Array (_root_.Array α) :=
  let rec loop : _root_.Nat → _root_.List α → _root_.Array (_root_.Array α) → _root_.Array (_root_.Array α)
    | 0, _, acc => acc
    | _, [], acc => acc
    | fuel + 1, head :: tail, acc => loop fuel tail (acc.push #[head])
  loop 262145 values #[]

@[export lean_bridge_23220a30761b2d3716c5b4ed_recursive_4fb79b80af1133bbb83d_make]
def make4fb79b80af1133bbb83d (values : _root_.Array (_root_.Array (_root_.Option _root_.Nat))) : (_root_.Array (_root_.Array (_root_.Option _root_.Nat))) :=
  carrierResult (do
    let values ← carrierCollect values
    pure values
  )

@[export lean_bridge_23220a30761b2d3716c5b4ed_recursive_4fb79b80af1133bbb83d_items]
def items4fb79b80af1133bbb83d (value : (_root_.Array (_root_.Array (_root_.Option _root_.Nat)))) : (_root_.Array (_root_.Array (_root_.Option _root_.Nat))) :=
  match carrierValue value with
  | .none => #[]
  | .some values => (values.extract 0 262145).map (fun child => #[child])

@[export lean_bridge_23220a30761b2d3716c5b4ed_recursive_3f262999893350bc4fb4_branch]
def branch3f262999893350bc4fb4 (value : (_root_.Array (_root_.Option _root_.Nat))) : _root_.UInt32 :=
  match carrierValue value with
  | .none => 4294967295
  | .some value =>
    match value with
    | .none => 0
    | .some _ => 1

@[export lean_bridge_23220a30761b2d3716c5b4ed_recursive_3f262999893350bc4fb4_none]
def none3f262999893350bc4fb4 (_bridgeUnit : _root_.Unit) : (_root_.Array (_root_.Option _root_.Nat)) :=
  carrierResult (do
    pure (.none)
  )

@[export lean_bridge_23220a30761b2d3716c5b4ed_recursive_3f262999893350bc4fb4_make0]
def make03f262999893350bc4fb4 (a0 : (_root_.Array _root_.Nat)) : (_root_.Array (_root_.Option _root_.Nat)) :=
  carrierResult (do
    let a0 ← carrierValue a0
    pure (.some a0)
  )

@[export lean_bridge_23220a30761b2d3716c5b4ed_recursive_3f262999893350bc4fb4_field0]
def field03f262999893350bc4fb4 (value : (_root_.Array (_root_.Option _root_.Nat))) : (_root_.Array _root_.Nat) :=
  carrierResult (do
    let value ← carrierValue value
    match value with
    | .some child => pure child
    | _ => .none
  )

@[export lean_bridge_23220a30761b2d3716c5b4ed_recursive_ec3de31d02aa0faa1710_branch]
def branchec3de31d02aa0faa1710 (value : (_root_.Array (_root_.Except _root_.String (_root_.Option _root_.Nat)))) : _root_.UInt32 :=
  match carrierValue value with
  | .none => 4294967295
  | .some value =>
    match value with
    | .ok _ => 0
    | .error _ => 1

@[export lean_bridge_23220a30761b2d3716c5b4ed_recursive_ec3de31d02aa0faa1710_make0]
def make0ec3de31d02aa0faa1710 (a0 : (_root_.Array (_root_.Option _root_.Nat))) : (_root_.Array (_root_.Except _root_.String (_root_.Option _root_.Nat))) :=
  carrierResult (do
    let a0 ← carrierValue a0
    pure (.ok a0)
  )

@[export lean_bridge_23220a30761b2d3716c5b4ed_recursive_ec3de31d02aa0faa1710_field0]
def field0ec3de31d02aa0faa1710 (value : (_root_.Array (_root_.Except _root_.String (_root_.Option _root_.Nat)))) : (_root_.Array (_root_.Option _root_.Nat)) :=
  carrierResult (do
    let value ← carrierValue value
    match value with
    | .ok child => pure child
    | _ => .none
  )

@[export lean_bridge_23220a30761b2d3716c5b4ed_recursive_ec3de31d02aa0faa1710_make1]
def make1ec3de31d02aa0faa1710 (a0 : (_root_.Array _root_.String)) : (_root_.Array (_root_.Except _root_.String (_root_.Option _root_.Nat))) :=
  carrierResult (do
    let a0 ← carrierValue a0
    pure (.error a0)
  )

@[export lean_bridge_23220a30761b2d3716c5b4ed_recursive_ec3de31d02aa0faa1710_field1]
def field1ec3de31d02aa0faa1710 (value : (_root_.Array (_root_.Except _root_.String (_root_.Option _root_.Nat)))) : (_root_.Array _root_.String) :=
  carrierResult (do
    let value ← carrierValue value
    match value with
    | .error child => pure child
    | _ => .none
  )

@[extern "lean_bridge_23220a30761b2d3716c5b4ed_structured_14cd8f1b0d065ede9a36f8590000c62c12d8e99c_invoke"]
opaque invoke_14cd8f1b0d065ede9a36f8590000c62c12d8e99c (token : _root_.USize) (a0 : (_root_.Array (_root_.Option _root_.Nat))) : (_root_.Array (_root_.Except _root_.String (_root_.Option _root_.Nat))) := #[]

@[extern "lean_bridge_23220a30761b2d3716c5b4ed_structured_14cd8f1b0d065ede9a36f8590000c62c12d8e99c_recovery"]
opaque recovery_14cd8f1b0d065ede9a36f8590000c62c12d8e99c (token : _root_.USize) : (_root_.Array (_root_.Except _root_.String (_root_.Option _root_.Nat))) := #[]

@[extern "lean_bridge_23220a30761b2d3716c5b4ed_structured_14cd8f1b0d065ede9a36f8590000c62c12d8e99c_reject"]
opaque reject_14cd8f1b0d065ede9a36f8590000c62c12d8e99c (token : _root_.USize) (recovery : (_root_.Array (_root_.Except _root_.String (_root_.Option _root_.Nat)))) : (_root_.Array (_root_.Except _root_.String (_root_.Option _root_.Nat))) := recovery

@[export lean_bridge_23220a30761b2d3716c5b4ed_structured_14cd8f1b0d065ede9a36f8590000c62c12d8e99c_wrap]
def wrap_14cd8f1b0d065ede9a36f8590000c62c12d8e99c (token : _root_.USize) : (_root_.Array _root_.USize) := #[token]

@[export lean_bridge_23220a30761b2d3716c5b4ed_structured_c27fa7df7f1805196544d398fb121b21c179beb1_apply]
def apply_c27fa7df7f1805196544d398fb121b21c179beb1 (closure : (_root_.Array (_root_.Nat → (_root_.Option _root_.Nat)))) (a0 : (_root_.Array _root_.Nat)) : (_root_.Array _root_.Nat) :=
  carrierResult (do
    let closure ← carrierValue closure
    let a0 ← carrierValue a0
    let result ← closure a0
    pure result
  )

@[export lean_bridge_23220a30761b2d3716c5b4ed_structured_c27fa7df7f1805196544d398fb121b21c179beb1_closure_graph_refinement_0_ba12b83e7ba38842c8fd]
def closure_c27fa7df7f1805196544d398fb121b21c179beb1_graph_refinement_0_ba12b83e7ba38842c8fd (carrier : (_root_.Array _root_.Nat)) : _root_.UInt8 :=
  match carrierValue carrier with
  | .none => 0
  | .some value =>
    match _root_.CallbackSubtypes.checkedPositive value with
    | .some _ => 1
    | .none => 0

@[extern "lean_bridge_23220a30761b2d3716c5b4ed_structured_197d5bf19058d37bc5547c33a8e0bed3bf121ea7_invoke"]
opaque invoke_197d5bf19058d37bc5547c33a8e0bed3bf121ea7 (token : _root_.USize) (a0 : (_root_.Array _root_.Nat)) (a1 : (_root_.Array _root_.Nat)) : (_root_.Array _root_.Nat) := #[]

@[extern "lean_bridge_23220a30761b2d3716c5b4ed_structured_197d5bf19058d37bc5547c33a8e0bed3bf121ea7_recovery"]
opaque recovery_197d5bf19058d37bc5547c33a8e0bed3bf121ea7 (token : _root_.USize) : (_root_.Array _root_.Nat) := #[]

@[extern "lean_bridge_23220a30761b2d3716c5b4ed_structured_197d5bf19058d37bc5547c33a8e0bed3bf121ea7_reject"]
opaque reject_197d5bf19058d37bc5547c33a8e0bed3bf121ea7 (token : _root_.USize) (recovery : (_root_.Array _root_.Nat)) : (_root_.Array _root_.Nat) := recovery

@[export lean_bridge_23220a30761b2d3716c5b4ed_structured_197d5bf19058d37bc5547c33a8e0bed3bf121ea7_wrap]
def wrap_197d5bf19058d37bc5547c33a8e0bed3bf121ea7 (token : _root_.USize) : (_root_.Array _root_.USize) := #[token]

@[export lean_bridge_23220a30761b2d3716c5b4ed_structured_51bfd752726fcfd8a9187a7c3a979ace51f7c1be_apply]
def apply_51bfd752726fcfd8a9187a7c3a979ace51f7c1be (closure : (_root_.Array (_root_.Nat → _root_.Nat → (_root_.Option _root_.Nat)))) (a0 : (_root_.Array _root_.Nat)) (a1 : (_root_.Array _root_.Nat)) : (_root_.Array _root_.Nat) :=
  carrierResult (do
    let closure ← carrierValue closure
    let a0 ← carrierValue a0
    let a1 ← carrierValue a1
    let result ← closure a0 a1
    pure result
  )

@[export lean_bridge_23220a30761b2d3716c5b4ed_structured_51bfd752726fcfd8a9187a7c3a979ace51f7c1be_closure_graph_refinement_1_ba12b83e7ba38842c8fd]
def closure_51bfd752726fcfd8a9187a7c3a979ace51f7c1be_graph_refinement_1_ba12b83e7ba38842c8fd (carrier : (_root_.Array _root_.Nat)) : _root_.UInt8 :=
  match carrierValue carrier with
  | .none => 0
  | .some value =>
    match _root_.CallbackSubtypes.checkedPositive value with
    | .some _ => 1
    | .none => 0

@[export lean_bridge_23220a30761b2d3716c5b4ed_structured_6cdd9c3be7604978d190e4f9d3a70db0539487ba_apply]
def apply_6cdd9c3be7604978d190e4f9d3a70db0539487ba (closure : (_root_.Array ((_root_.Array (_root_.Option _root_.Nat)) → (_root_.Option (_root_.Option _root_.Nat))))) (a0 : (_root_.Array (_root_.Array (_root_.Option _root_.Nat)))) : (_root_.Array (_root_.Option _root_.Nat)) :=
  carrierResult (do
    let closure ← carrierValue closure
    let a0 ← carrierValue a0
    let result ← closure a0
    pure result
  )

@[export lean_bridge_23220a30761b2d3716c5b4ed_structured_6cdd9c3be7604978d190e4f9d3a70db0539487ba_closure_graph_refinement_0_ba12b83e7ba38842c8fd]
def closure_6cdd9c3be7604978d190e4f9d3a70db0539487ba_graph_refinement_0_ba12b83e7ba38842c8fd (carrier : (_root_.Array _root_.Nat)) : _root_.UInt8 :=
  match carrierValue carrier with
  | .none => 0
  | .some value =>
    match _root_.CallbackSubtypes.checkedPositive value with
    | .some _ => 1
    | .none => 0

@[extern "lean_bridge_23220a30761b2d3716c5b4ed_structured_6bc98ee774b20d3238b9e42a92309a51ce9dad0a_invoke"]
opaque invoke_6bc98ee774b20d3238b9e42a92309a51ce9dad0a (token : _root_.USize) (a0 : (_root_.Array _root_.Nat)) : (_root_.Array _root_.Nat) := #[]

@[extern "lean_bridge_23220a30761b2d3716c5b4ed_structured_6bc98ee774b20d3238b9e42a92309a51ce9dad0a_recovery"]
opaque recovery_6bc98ee774b20d3238b9e42a92309a51ce9dad0a (token : _root_.USize) : (_root_.Array _root_.Nat) := #[]

@[extern "lean_bridge_23220a30761b2d3716c5b4ed_structured_6bc98ee774b20d3238b9e42a92309a51ce9dad0a_reject"]
opaque reject_6bc98ee774b20d3238b9e42a92309a51ce9dad0a (token : _root_.USize) (recovery : (_root_.Array _root_.Nat)) : (_root_.Array _root_.Nat) := recovery

@[export lean_bridge_23220a30761b2d3716c5b4ed_structured_6bc98ee774b20d3238b9e42a92309a51ce9dad0a_wrap]
def wrap_6bc98ee774b20d3238b9e42a92309a51ce9dad0a (token : _root_.USize) : (_root_.Array _root_.USize) := #[token]

@[export lean_bridge_23220a30761b2d3716c5b4ed_lean]
def export0 (a0 : (_root_.Array _root_.USize)) : (_root_.Array _root_.Nat) :=
  carrierResult (do
    let a0 ← carrierValue a0
    let _bridgeRecoveryRaw0 ← carrierValue (recovery_6bc98ee774b20d3238b9e42a92309a51ce9dad0a a0)
    let _bridgeRecovery0 ← _root_.CallbackSubtypes.checkedPositive _bridgeRecoveryRaw0
    pure ((_root_.Subtype.val (_root_.CallbackSubtypes.callHost (fun _bridgeCallback0_0 => match (do let _bridgeCallbackResult0 ← carrierValue (invoke_6bc98ee774b20d3238b9e42a92309a51ce9dad0a a0 #[(_root_.Subtype.val (_bridgeCallback0_0))]); _root_.CallbackSubtypes.checkedPositive _bridgeCallbackResult0) with | .some value => value | .none => (match (do let value ← carrierValue (reject_6bc98ee774b20d3238b9e42a92309a51ce9dad0a a0 #[_bridgeRecoveryRaw0]); _root_.CallbackSubtypes.checkedPositive value) with | .some value => value | .none => _bridgeRecovery0)))))
  )

@[export lean_bridge_8ffe188578f9a7b74003cf3c_lean]
def export1 (a0 : (_root_.Array _root_.USize)) : (_root_.Array (_root_.Except _root_.String (_root_.Option _root_.Nat))) :=
  carrierResult (do
    let a0 ← carrierValue a0
    let _bridgeRecoveryRaw0 ← carrierValue (recovery_14cd8f1b0d065ede9a36f8590000c62c12d8e99c a0)
    let _bridgeRecovery0 ← (match (_bridgeRecoveryRaw0) with | _root_.Except.ok _bridgeValue0 => ((match (_bridgeValue0) with | _root_.Option.none => _root_.Option.some _root_.Option.none | _root_.Option.some _bridgeValue1 => (_root_.CallbackSubtypes.checkedPositive _bridgeValue1).map _root_.Option.some)).map _root_.Except.ok | _root_.Except.error _bridgeValue0 => ((_root_.Option.some (_bridgeValue0))).map _root_.Except.error)
    pure ((let _bridgeResult := _root_.CallbackSubtypes.callHostContainer (fun _bridgeCallback0_0 => match (do let _bridgeCallbackResult0 ← carrierValue (invoke_14cd8f1b0d065ede9a36f8590000c62c12d8e99c a0 #[((_bridgeCallback0_0).map (fun _bridgeValue0 => (_root_.Subtype.val (_bridgeValue0))))]); (match (_bridgeCallbackResult0) with | _root_.Except.ok _bridgeValue0 => ((match (_bridgeValue0) with | _root_.Option.none => _root_.Option.some _root_.Option.none | _root_.Option.some _bridgeValue1 => (_root_.CallbackSubtypes.checkedPositive _bridgeValue1).map _root_.Option.some)).map _root_.Except.ok | _root_.Except.error _bridgeValue0 => ((_root_.Option.some (_bridgeValue0))).map _root_.Except.error)) with | .some value => value | .none => (match (do let value ← carrierValue (reject_14cd8f1b0d065ede9a36f8590000c62c12d8e99c a0 #[_bridgeRecoveryRaw0]); (match (value) with | _root_.Except.ok _bridgeValue0 => ((match (_bridgeValue0) with | _root_.Option.none => _root_.Option.some _root_.Option.none | _root_.Option.some _bridgeValue1 => (_root_.CallbackSubtypes.checkedPositive _bridgeValue1).map _root_.Option.some)).map _root_.Except.ok | _root_.Except.error _bridgeValue0 => ((_root_.Option.some (_bridgeValue0))).map _root_.Except.error)) with | .some value => value | .none => _bridgeRecovery0)); (match (_bridgeResult) with | _root_.Except.ok _bridgeValue0 => .ok ((_bridgeValue0).map (fun _bridgeValue1 => (_root_.Subtype.val (_bridgeValue1)))) | _root_.Except.error _bridgeValue0 => .error (_bridgeValue0))))
  )

@[export lean_bridge_4f106adfac5064464a2a8e3f_lean]
def export2 (a0 : (_root_.Array _root_.USize)) : (_root_.Array _root_.Nat) :=
  carrierResult (do
    let a0 ← carrierValue a0
    let _bridgeRecoveryRaw0 ← carrierValue (recovery_197d5bf19058d37bc5547c33a8e0bed3bf121ea7 a0)
    let _bridgeRecovery0 ← _root_.CallbackSubtypes.checkedPositive _bridgeRecoveryRaw0
    pure ((_root_.Subtype.val (_root_.CallbackSubtypes.callHostMixed (fun _bridgeCallback0_0 _bridgeCallback0_1 => match (do let _bridgeCallbackResult0 ← carrierValue (invoke_197d5bf19058d37bc5547c33a8e0bed3bf121ea7 a0 #[_bridgeCallback0_0] #[(_root_.Subtype.val (_bridgeCallback0_1))]); _root_.CallbackSubtypes.checkedPositive _bridgeCallbackResult0) with | .some value => value | .none => (match (do let value ← carrierValue (reject_197d5bf19058d37bc5547c33a8e0bed3bf121ea7 a0 #[_bridgeRecoveryRaw0]); _root_.CallbackSubtypes.checkedPositive value) with | .some value => value | .none => _bridgeRecovery0)))))
  )

@[export lean_bridge_e2d5407c03792441cb368ec1_lean]
def export3 (a0 : (_root_.Array _root_.Nat)) : (_root_.Array (_root_.Nat → (_root_.Option _root_.Nat))) :=
  carrierResult (do
    let a0 ← carrierValue a0
    do let _bridgeClosure := _root_.CallbackSubtypes.makeClosure a0; pure (fun (_bridgeCallbackResult_0 : _root_.Nat) => do let _bridgeCallbackChecked_0 ← _root_.CallbackSubtypes.checkedPositive _bridgeCallbackResult_0; pure ((_root_.Subtype.val (_bridgeClosure _bridgeCallbackChecked_0))))
  )

@[export lean_bridge_07d8425a546c7304b285ddcd_lean]
def export4 (a0 : (_root_.Array _root_.Nat)) : (_root_.Array ((_root_.Array (_root_.Option _root_.Nat)) → (_root_.Option (_root_.Option _root_.Nat)))) :=
  carrierResult (do
    let a0 ← carrierValue a0
    do let _bridgeClosure := _root_.CallbackSubtypes.makeContainerClosure a0; pure (fun (_bridgeCallbackResult_0 : (_root_.Array (_root_.Option _root_.Nat))) => do let _bridgeCallbackChecked_0 ← ((_bridgeCallbackResult_0).mapM (fun _bridgeValue0 => (match (_bridgeValue0) with | _root_.Option.none => _root_.Option.some _root_.Option.none | _root_.Option.some _bridgeValue1 => (_root_.CallbackSubtypes.checkedPositive _bridgeValue1).map _root_.Option.some))); pure (((_bridgeClosure _bridgeCallbackChecked_0).map (fun _bridgeValue0 => (_root_.Subtype.val (_bridgeValue0))))))
  )

@[export lean_bridge_36fd9c74c3921bfb2ead3644_lean]
def export5 (a0 : (_root_.Array _root_.Nat)) : (_root_.Array (_root_.Nat → _root_.Nat → (_root_.Option _root_.Nat))) :=
  carrierResult (do
    let a0 ← carrierValue a0
    do let _bridgeClosure := _root_.CallbackSubtypes.makeMixedClosure a0; pure (fun (_bridgeCallbackResult_0 : _root_.Nat) (_bridgeCallbackResult_1 : _root_.Nat) => do let _bridgeCallbackChecked_1 ← _root_.CallbackSubtypes.checkedPositive _bridgeCallbackResult_1; pure ((_root_.Subtype.val (_bridgeClosure _bridgeCallbackResult_0 _bridgeCallbackChecked_1))))
  )

end LeanBridgeNative730462696d8af341
