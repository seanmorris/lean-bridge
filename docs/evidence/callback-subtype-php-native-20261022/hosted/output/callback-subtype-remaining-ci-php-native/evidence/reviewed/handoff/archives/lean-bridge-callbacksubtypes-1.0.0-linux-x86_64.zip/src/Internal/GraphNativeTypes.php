<?php
declare(strict_types=1);
namespace LeanCallbacksubtypes\Internal;

final class GraphNativeTypes
{
    public const DEFINITIONS = <<<'CDEFS'
typedef uint8_t *lb_php_graph_byte_pointer;
typedef uint8_t **lb_php_graph_byte_slot;
typedef struct callbacksubtypes_graph_743764d1b67e81fcae92_t callbacksubtypes_graph_743764d1b67e81fcae92_t;
typedef struct callbacksubtypes_graph_2c6f4131c8731fa67588_t callbacksubtypes_graph_2c6f4131c8731fa67588_t;
typedef struct callbacksubtypes_graph_6c9c0cf3d3abf9adeb4b_t callbacksubtypes_graph_6c9c0cf3d3abf9adeb4b_t;
typedef struct callbacksubtypes_scalar_nat_t callbacksubtypes_scalar_nat_t;
typedef struct callbacksubtypes_scalar_string_t callbacksubtypes_scalar_string_t;
struct callbacksubtypes_scalar_nat_t {
  void *_bridge_owner;
  void (*_bridge_release)(void *owner);
  const uint32_t *data;
  size_t length;
};

struct callbacksubtypes_graph_743764d1b67e81fcae92_t {
  void *_bridge_owner;
  void (*_bridge_release)(void *owner);
  uint8_t has_value;
  callbacksubtypes_scalar_nat_t value;
};

struct callbacksubtypes_scalar_string_t {
  void *_bridge_owner;
  void (*_bridge_release)(void *owner);
  const char *data;
  size_t length;
};

struct callbacksubtypes_graph_2c6f4131c8731fa67588_t {
  void *_bridge_owner;
  void (*_bridge_release)(void *owner);
  uint8_t is_ok;
  callbacksubtypes_graph_743764d1b67e81fcae92_t ok;
  callbacksubtypes_scalar_string_t error;
};

struct callbacksubtypes_graph_6c9c0cf3d3abf9adeb4b_t {
  void *_bridge_owner;
  void (*_bridge_release)(void *owner);
  const callbacksubtypes_graph_743764d1b67e81fcae92_t *data;
  size_t length;
};
CDEFS;
    public const NODES = [
        ['ctype' => 'callbacksubtypes_graph_743764d1b67e81fcae92_t', 'kind' => 'option', 'scalar' => null, 'aggregate' => true, 'inhabited' => true, 'element' => null, 'branches' => [['class' => null, 'fields' => []], ['class' => 'LeanCallbacksubtypes\\Some', 'fields' => [['type' => 3, 'path' => ['value'], 'pointer' => false, 'key' => 'value']]]]],
        ['ctype' => 'callbacksubtypes_graph_2c6f4131c8731fa67588_t', 'kind' => 'result', 'scalar' => null, 'aggregate' => true, 'inhabited' => true, 'element' => null, 'branches' => [['class' => 'LeanCallbacksubtypes\\Err', 'fields' => [['type' => 4, 'path' => ['error'], 'pointer' => false, 'key' => 'value']]], ['class' => 'LeanCallbacksubtypes\\Ok', 'fields' => [['type' => 0, 'path' => ['ok'], 'pointer' => false, 'key' => 'value']]]]],
        ['ctype' => 'callbacksubtypes_graph_6c9c0cf3d3abf9adeb4b_t', 'kind' => 'array', 'scalar' => null, 'aggregate' => true, 'inhabited' => true, 'element' => 0, 'branches' => [['class' => null, 'fields' => []]]],
        ['ctype' => 'callbacksubtypes_scalar_nat_t', 'kind' => 'primitive', 'scalar' => 'nat', 'aggregate' => true, 'inhabited' => true, 'element' => null, 'branches' => [['class' => null, 'fields' => []]]],
        ['ctype' => 'callbacksubtypes_scalar_string_t', 'kind' => 'primitive', 'scalar' => 'string', 'aggregate' => true, 'inhabited' => true, 'element' => null, 'branches' => [['class' => null, 'fields' => []]]],
        ['ctype' => 'uint8_t', 'kind' => 'primitive', 'scalar' => 'unit', 'aggregate' => false, 'inhabited' => true, 'element' => null, 'branches' => [['class' => null, 'fields' => []]]],
    ];
    public const FUNCTIONS = [['parameters' => [3, 1, 0, 2], 'result' => 5]];
}
