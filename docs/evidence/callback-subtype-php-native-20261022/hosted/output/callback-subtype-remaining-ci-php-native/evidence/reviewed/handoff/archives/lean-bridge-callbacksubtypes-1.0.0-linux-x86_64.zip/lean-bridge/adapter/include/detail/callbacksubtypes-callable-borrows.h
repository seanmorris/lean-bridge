#pragma once
#include "callbacksubtypes-graph-types.h"
typedef struct callbacksubtypes_callback_14cd8f1b0d065ede9a36f8590000c62c12d8e99c {
  uint32_t (*call)(void *, const callbacksubtypes_graph_743764d1b67e81fcae92_t *arg0, callbacksubtypes_graph_2c6f4131c8731fa67588_t *out);
  void *context;
  const callbacksubtypes_graph_2c6f4131c8731fa67588_t *recovery;
} callbacksubtypes_callback_14cd8f1b0d065ede9a36f8590000c62c12d8e99c;
typedef struct callbacksubtypes_callback_c27fa7df7f1805196544d398fb121b21c179beb1 {
  uint32_t (*call)(void *, const callbacksubtypes_scalar_nat_t *arg0, callbacksubtypes_scalar_nat_t *out);
  void *context;
} callbacksubtypes_callback_c27fa7df7f1805196544d398fb121b21c179beb1;
typedef struct callbacksubtypes_callback_197d5bf19058d37bc5547c33a8e0bed3bf121ea7 {
  uint32_t (*call)(void *, const callbacksubtypes_scalar_nat_t *arg0, const callbacksubtypes_scalar_nat_t *arg1, callbacksubtypes_scalar_nat_t *out);
  void *context;
  const callbacksubtypes_scalar_nat_t *recovery;
} callbacksubtypes_callback_197d5bf19058d37bc5547c33a8e0bed3bf121ea7;
typedef struct callbacksubtypes_callback_51bfd752726fcfd8a9187a7c3a979ace51f7c1be {
  uint32_t (*call)(void *, const callbacksubtypes_scalar_nat_t *arg0, const callbacksubtypes_scalar_nat_t *arg1, callbacksubtypes_scalar_nat_t *out);
  void *context;
} callbacksubtypes_callback_51bfd752726fcfd8a9187a7c3a979ace51f7c1be;
typedef struct callbacksubtypes_callback_6cdd9c3be7604978d190e4f9d3a70db0539487ba {
  uint32_t (*call)(void *, const callbacksubtypes_graph_6c9c0cf3d3abf9adeb4b_t *arg0, callbacksubtypes_graph_743764d1b67e81fcae92_t *out);
  void *context;
} callbacksubtypes_callback_6cdd9c3be7604978d190e4f9d3a70db0539487ba;
typedef struct callbacksubtypes_callback_6bc98ee774b20d3238b9e42a92309a51ce9dad0a {
  uint32_t (*call)(void *, const callbacksubtypes_scalar_nat_t *arg0, callbacksubtypes_scalar_nat_t *out);
  void *context;
  const callbacksubtypes_scalar_nat_t *recovery;
} callbacksubtypes_callback_6bc98ee774b20d3238b9e42a92309a51ce9dad0a;
