<?php
declare(strict_types=1);
namespace LeanCallbacksubtypes\Internal;

require_once __DIR__ . '/CallableRuntime.php';
require_once __DIR__ . '/CallableTypes.php';

final class Native
{
    private const DEFINITIONS = <<<'CDEFS'
uint32_t callbacksubtypes_graph_initialize(void);
int callbacksubtypes_graph_ready(void);
void callbacksubtypes_graph_retire(void);
void callbacksubtypes_php_graph_clear(void *);
typedef struct { uint32_t (*call)(void *, void *, void *); void *context; void *recovery; } lb_php_callback_0;
typedef struct { uint32_t (*call)(void *, void *, void *); void *context; } lb_php_callback_1;
uint32_t callbacksubtypes_callback_c27fa7df7f1805196544d398fb121b21c179beb1_lease_call(uint64_t, void *, void *);
void callbacksubtypes_callback_c27fa7df7f1805196544d398fb121b21c179beb1_lease_dispose(uint64_t);
typedef struct { uint32_t (*call)(void *, void *, void *, void *); void *context; void *recovery; } lb_php_callback_2;
typedef struct { uint32_t (*call)(void *, void *, void *, void *); void *context; } lb_php_callback_3;
uint32_t callbacksubtypes_callback_51bfd752726fcfd8a9187a7c3a979ace51f7c1be_lease_call(uint64_t, void *, void *, void *);
void callbacksubtypes_callback_51bfd752726fcfd8a9187a7c3a979ace51f7c1be_lease_dispose(uint64_t);
typedef struct { uint32_t (*call)(void *, void *, void *); void *context; } lb_php_callback_4;
uint32_t callbacksubtypes_callback_6cdd9c3be7604978d190e4f9d3a70db0539487ba_lease_call(uint64_t, void *, void *);
void callbacksubtypes_callback_6cdd9c3be7604978d190e4f9d3a70db0539487ba_lease_dispose(uint64_t);
typedef struct { uint32_t (*call)(void *, void *, void *); void *context; void *recovery; } lb_php_callback_5;
uint32_t lean_bridge_23220a30761b2d3716c5b4ed_graph(void *, void *);
uint32_t lean_bridge_8ffe188578f9a7b74003cf3c_graph(void *, void *);
uint32_t lean_bridge_4f106adfac5064464a2a8e3f_graph(void *, void *);
uint32_t lean_bridge_e2d5407c03792441cb368ec1_graph(void *, void *);
uint32_t lean_bridge_07d8425a546c7304b285ddcd_graph(void *, void *);
uint32_t lean_bridge_36fd9c74c3921bfb2ead3644_graph(void *, void *);
CDEFS;
    private static ?CallableRuntime $runtime = null;
    private static ?\Closure $wrap = null;
    private static function load(): \FFI {
        return \LeanBridge\CopiedNativeV1\Runtime::load(__DIR__ . '/../../native/linux-x64', json_decode(<<<'EVIDENCE'
{
  "componentId": "callbacksubtypes@1.0.0",
  "componentReceiptSha256": "22d7c0caa4fc5c3fe7a564b20a91d9380954491528b4b636ea680f65907455ca",
  "copiedGraph": {
    "layoutSha256": "fecb17552b69763dd41ffa66796f931cff14497a923fdc9cc929186f98530c1c",
    "schemaVersion": 1
  },
  "identity": "9fb20686ef6ca96466b82df422e041c5a74594e529791b0bcf9899cc8070904a",
  "libraries": {
    "libcallbacksubtypes.so": "ef1da55534422072cf9ddca0bc66ff7054c577467a0b1dbd6d9c539c473b4f06",
    "libcomponent_730462696d8af341b48a.so": "839154183007ffb79cbb7071ba40955d9fb28103f2c1d778d7e5744b713275e4",
    "liblean_bridge_native.so": "459fcd2098d4b646ab6ae0f4cdccd1f222908cb162562bfc3940a533cd4e4e21",
    "libleanshared.so": "d7768b88d8162736da4305777cd6f147676038fd885bd8a265c958b0ecea00b4"
  },
  "library": "libcallbacksubtypes.so",
  "loadOrder": [
    "libleanshared.so",
    "liblean_bridge_native.so",
    "libcomponent_730462696d8af341b48a.so",
    "libcallbacksubtypes.so"
  ],
  "runtimeIdentity": "4b5a7fdf0cb11d4bb429181cfd50b330c5622ed8f5f5382a293955a439b595b5"
}
EVIDENCE, true, 512, JSON_THROW_ON_ERROR), self::DEFINITIONS);
    }
    public static function call(string $name, array $arguments): mixed {
        self::$runtime ??= new CallableRuntime(static fn(): \FFI => self::load(), CallableTypes::CATALOG);
        try {
            $value = self::$runtime->call($name, $arguments);
            if (!$value instanceof Lease) return $value;
            self::$wrap ??= \Closure::bind(static fn(Lease $lease) => new \LeanCallbacksubtypes\LeanClosure($lease), null, \LeanCallbacksubtypes\LeanClosure::class);
            return (self::$wrap)($value);
        } catch (GraphInvalidNative $error) {
            throw new \LeanCallbacksubtypes\LeanBridgeError($error->getMessage(), 4, $error);
        }
    }
}
