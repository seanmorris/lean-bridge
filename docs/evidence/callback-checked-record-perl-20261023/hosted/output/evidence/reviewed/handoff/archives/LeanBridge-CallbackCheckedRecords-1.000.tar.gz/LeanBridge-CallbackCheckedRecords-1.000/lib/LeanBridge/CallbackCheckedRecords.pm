package LeanBridge::CallbackCheckedRecords;
use strict;
use warnings;
use Math::BigInt;
# Finite declarations only. Conversion performs payload validation at calls.

sub true () { !!1 }
sub false () { !!0 }
package LeanBridge::CallbackCheckedRecords::Some;
sub new {
  CORE::die "Some->new expects one payload\n" unless @_ == 2 && CORE::defined($_[0]) && !CORE::ref($_[0]) && $_[0] eq 'LeanBridge::CallbackCheckedRecords::Some';
  return CORE::bless {value => $_[1]}, 'LeanBridge::CallbackCheckedRecords::Some';
}
sub value { $_[0]->{value} }

package LeanBridge::CallbackCheckedRecords::Ok;
sub new {
  CORE::die "Ok->new expects one payload\n" unless @_ == 2 && CORE::defined($_[0]) && !CORE::ref($_[0]) && $_[0] eq 'LeanBridge::CallbackCheckedRecords::Ok';
  return CORE::bless {value => $_[1]}, 'LeanBridge::CallbackCheckedRecords::Ok';
}
sub value { $_[0]->{value} }

package LeanBridge::CallbackCheckedRecords::Err;
sub new {
  CORE::die "Err->new expects one payload\n" unless @_ == 2 && CORE::defined($_[0]) && !CORE::ref($_[0]) && $_[0] eq 'LeanBridge::CallbackCheckedRecords::Err';
  return CORE::bless {value => $_[1]}, 'LeanBridge::CallbackCheckedRecords::Err';
}
sub value { $_[0]->{value} }

package LeanBridge::CallbackCheckedRecords::Interval;
sub new {
  CORE::die "LeanBridge::CallbackCheckedRecords::Interval->new expects named fields\n" unless @_ % 2 == 1 && CORE::defined($_[0]) && !CORE::ref($_[0]) && $_[0] eq 'LeanBridge::CallbackCheckedRecords::Interval';
  CORE::shift; my %fields;
  while (@_) {
    my ($key, $value) = CORE::splice @_, 0, 2;
    CORE::die "invalid field name\n" if !CORE::defined($key) || CORE::ref($key);
    $fields{$key} = $value;
  }
  my @required = qw(lo hi);
  CORE::die "fields do not match the generated schema\n" if CORE::keys(%fields) != @required || CORE::grep { !CORE::exists($fields{$_}) } @required;
  return CORE::bless \%fields, 'LeanBridge::CallbackCheckedRecords::Interval';
}
# lo: nat
sub lo { $_[0]->{lo} }
# hi: nat
sub hi { $_[0]->{hi} }

package LeanBridge::CallbackCheckedRecords::Weighted;
sub new {
  CORE::die "LeanBridge::CallbackCheckedRecords::Weighted->new expects named fields\n" unless @_ % 2 == 1 && CORE::defined($_[0]) && !CORE::ref($_[0]) && $_[0] eq 'LeanBridge::CallbackCheckedRecords::Weighted';
  CORE::shift; my %fields;
  while (@_) {
    my ($key, $value) = CORE::splice @_, 0, 2;
    CORE::die "invalid field name\n" if !CORE::defined($key) || CORE::ref($key);
    $fields{$key} = $value;
  }
  my @required = qw(weight limit);
  CORE::die "fields do not match the generated schema\n" if CORE::keys(%fields) != @required || CORE::grep { !CORE::exists($fields{$_}) } @required;
  return CORE::bless \%fields, 'LeanBridge::CallbackCheckedRecords::Weighted';
}
# weight: nat
sub weight { $_[0]->{weight} }
# limit: nat
sub limit { $_[0]->{limit} }

1;

package LeanBridge::CallbackCheckedRecords::Runtime::Callback;
sub new {
  CORE::die "LeanBridge::CallbackCheckedRecords::Runtime::Callback->new expects code and recovery\n"
    unless @_ == 5 && CORE::defined($_[0]) && !CORE::ref($_[0]) && $_[0] eq 'LeanBridge::CallbackCheckedRecords::Runtime::Callback';
  CORE::shift; my %fields = @_;
  CORE::die "expected code and recovery fields\n"
    unless CORE::keys(%fields) == 2 && CORE::exists($fields{code}) && CORE::exists($fields{recovery});
  CORE::die "expected a Perl code reference\n" unless CORE::ref($fields{code}) eq 'CODE';
  return CORE::bless \%fields, 'LeanBridge::CallbackCheckedRecords::Runtime::Callback';
}

package LeanBridge::CallbackCheckedRecords::LeanClosure;
sub new { CORE::die "Use a generated Lean closure factory\n" }
sub CLONE_SKIP { 1 }
sub STORABLE_freeze { CORE::die "Lean closures cannot be serialized\n" }
sub STORABLE_thaw { CORE::die "Lean closures cannot be deserialized\n" }
package LeanBridge::CallbackCheckedRecords::Closuree014092ff0a1ee8527eeeb58a78e2de63bdf09fa;
our @ISA = ('LeanBridge::CallbackCheckedRecords::LeanClosure');
sub CLONE_SKIP { 1 }

package LeanBridge::CallbackCheckedRecords::Closured885a7d82ec894d17b81e7a67a36bc2930adca13;
our @ISA = ('LeanBridge::CallbackCheckedRecords::LeanClosure');
sub CLONE_SKIP { 1 }

package LeanBridge::CallbackCheckedRecords::Closure2e292aebff8c53f6a465ec3d5745e74400590434;
our @ISA = ('LeanBridge::CallbackCheckedRecords::LeanClosure');
sub CLONE_SKIP { 1 }

package LeanBridge::CallbackCheckedRecords::Closure8994592329ecba032f0abfaa9703e59a57f3c6a1;
our @ISA = ('LeanBridge::CallbackCheckedRecords::LeanClosure');
sub CLONE_SKIP { 1 }

1;

package LeanBridge::CallbackCheckedRecords;
use LeanBridge::Runtime;
die "Incompatible shared Lean runtime package version\n" unless $LeanBridge::Runtime::VERSION eq '0.0020130180835253351074425099676719723942806298898514237203907626409680523998624031';
use XSLoader;
our $VERSION = '1.000';
LeanBridge::Runtime::_load_component(__FILE__, 'libcomponent_82670d9206f057180ea5.so', '735b1ed491423e37d316f7714b805425cd4c51246cc99deaf6b8ecdb3ccf5730', '6f4dbd1e2e112f4678734553d1c9bb8722fad3e6290adbff1ac46d05e5eff7dd', { 'CallbackCheckedRecords' => '8e6babb2f13a48d39de6158814b75f54c59173780e1310f2fa521cdd110909b7' }, 'callbackcheckedrecords@1.0.0');
XSLoader::load(__PACKAGE__, $VERSION);
sub CLONE_SKIP { 1 }
1;

__END__
=head1 NAME

LeanBridge::CallbackCheckedRecords - Generated recursive values and synchronous Lean callbacks

=head1 API

=head2 call_host

Calls C<CallbackCheckedRecords.callHost> in the compiled Lean component.

=head2 call_host_container

Calls C<CallbackCheckedRecords.callHostContainer> in the compiled Lean component.

=head2 call_host_mixed

Calls C<CallbackCheckedRecords.callHostMixed> in the compiled Lean component.

=head2 call_host_nested

Calls C<CallbackCheckedRecords.callHostNested> in the compiled Lean component.

=head2 make_closure

Calls C<CallbackCheckedRecords.makeClosure> in the compiled Lean component.

=head2 make_container_closure

Calls C<CallbackCheckedRecords.makeContainerClosure> in the compiled Lean component.

=head2 make_mixed_closure

Calls C<CallbackCheckedRecords.makeMixedClosure> in the compiled Lean component.

=head2 make_nested_closure

Calls C<CallbackCheckedRecords.makeNestedClosure> in the compiled Lean component.

=head1 VALUES

Records and variants use generated named-field classes. Arrays, Lists and
products use plain array references. None and Unit use undef; Some->new(undef)
keeps optional Unit distinct from None. Ok and Err retain result branches.
Nat and Int use Math::BigInt. Strings retain Unicode and NUL; ByteArray uses
octets. Aliases keep their copied target representation.

Calls check exact classes, fields and scalar representations, and reject
cycles, sparse arrays and tied containers. Callback arguments and results,
returned captures and ordinary results own independent copied storage.

=head1 CALLBACKS AND OWNERSHIP

Pass a CODE reference or a matching generated Lean closure as a synchronous
callback. A host callback whose result contains a checked Lean Subtype or checked record must use
C<LeanBridge::CallbackCheckedRecords::Runtime::Callback-E<gt>new(code =E<gt> $callback, recovery =E<gt> $value)>.
The recovery has the callback's declared erased result shape, a generated
record carrying only payload fields for a checked record, and is validated
before Lean or the callback runs. Lean applies the selected constructor to the
callback's actual reply, nested checked fields before their record.
Constructor rejection or a callback exception fails the enclosing call; the
recovery is used only to finish Lean's failure path and is never returned as a
successful result. A returned Lean closure constructs its checked record
arguments the same way before its body runs and projects a checked record
result without proof fields. Returned Lean closures provide call, close and closed. Close each
closure when finished. Close is idempotent and an active call retains its
borrow until native cleanup finishes. Automatic finalization also releases
the native lease. Closures cannot be serialized or used by another interpreter
or process. Host callbacks must not escape their initiating native call.

Perl callback exceptions retain their identity and are rethrown after native
cleanup. Reply buffers remain allocated until Lean copies them. Malformed
native results retire the shared runtime; input, callback and limit failures
leave it usable. Libraries remain loaded until process exit.

=head1 LIMITS

Conversions share a depth limit of 128, 262,144 nodes, a 16 MiB native-copy
budget and a separate 16 MiB conversion-storage budget. Reentry is limited to
64 native calls and the component supports up to 4,096 live closure leases.
These limits do not bound Lean working memory or all Perl allocator overhead.
Resource-containing copied values and asynchronous callbacks remain unsupported.

=cut
