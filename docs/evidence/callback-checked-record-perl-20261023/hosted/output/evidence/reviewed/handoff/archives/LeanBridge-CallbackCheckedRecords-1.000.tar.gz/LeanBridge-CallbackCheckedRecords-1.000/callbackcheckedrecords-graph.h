#pragma once
#include "callbackcheckedrecords-callable-borrows.h"
#ifdef __cplusplus
extern "C" {
#endif
const char *callbackcheckedrecords_callable_graph_error(void);
__attribute__((visibility("hidden"))) uint32_t lean_bridge_697151f2fc3cf6b95ff12b69_graph(const callbackcheckedrecords_callback_00652748bed3eb7036c9091f570efa39888f5490 *a0, callbackcheckedrecords_scalar_nat_t *out);
__attribute__((visibility("hidden"))) uint32_t lean_bridge_413afe4aaf66162bb3ba3d3c_graph(const callbackcheckedrecords_callback_2663a58c7c0e71654db1d87936875f8677e197b2 *a0, callbackcheckedrecords_scalar_nat_t *out);
__attribute__((visibility("hidden"))) uint32_t lean_bridge_184bfb6b98fb39095f0bfec8_graph(const callbackcheckedrecords_callback_526ba4a0f03797057c1f9a17ca435a5a42131510 *a0, callbackcheckedrecords_scalar_nat_t *out);
__attribute__((visibility("hidden"))) uint32_t lean_bridge_f168e18f231fdb7eb1733b0e_graph(const callbackcheckedrecords_callback_cd01d463066ae86d043223e65eab1640e16b22ab *a0, callbackcheckedrecords_scalar_nat_t *out);
__attribute__((visibility("hidden"))) uint32_t lean_bridge_97d7a19c3e5ee22681017ca9_graph(const callbackcheckedrecords_scalar_nat_t *a0, uint64_t *out);
__attribute__((visibility("hidden"))) uint32_t lean_bridge_74ed57fc03e7ed555389a3ab_graph(const callbackcheckedrecords_scalar_nat_t *a0, uint64_t *out);
__attribute__((visibility("hidden"))) uint32_t lean_bridge_bbabc0c3fa2252f4f7a67708_graph(const callbackcheckedrecords_scalar_nat_t *a0, uint64_t *out);
__attribute__((visibility("hidden"))) uint32_t lean_bridge_77496697d09177e0d1ebadfd_graph(const callbackcheckedrecords_scalar_nat_t *a0, uint64_t *out);
__attribute__((visibility("hidden"))) uint32_t callbackcheckedrecords_callback_e014092ff0a1ee8527eeeb58a78e2de63bdf09fa_lease_call(uint64_t self, const callbackcheckedrecords_interval_t *a0, callbackcheckedrecords_scalar_nat_t *out);
__attribute__((visibility("hidden"))) void callbackcheckedrecords_callback_e014092ff0a1ee8527eeeb58a78e2de63bdf09fa_lease_dispose(uint64_t token);
__attribute__((visibility("hidden"))) uint32_t callbackcheckedrecords_callback_d885a7d82ec894d17b81e7a67a36bc2930adca13_lease_call(uint64_t self, const callbackcheckedrecords_weighted_t *a0, callbackcheckedrecords_scalar_nat_t *out);
__attribute__((visibility("hidden"))) void callbackcheckedrecords_callback_d885a7d82ec894d17b81e7a67a36bc2930adca13_lease_dispose(uint64_t token);
__attribute__((visibility("hidden"))) uint32_t callbackcheckedrecords_callback_2e292aebff8c53f6a465ec3d5745e74400590434_lease_call(uint64_t self, const callbackcheckedrecords_scalar_nat_t *a0, const callbackcheckedrecords_interval_t *a1, callbackcheckedrecords_interval_t *out);
__attribute__((visibility("hidden"))) void callbackcheckedrecords_callback_2e292aebff8c53f6a465ec3d5745e74400590434_lease_dispose(uint64_t token);
__attribute__((visibility("hidden"))) uint32_t callbackcheckedrecords_callback_8994592329ecba032f0abfaa9703e59a57f3c6a1_lease_call(uint64_t self, const callbackcheckedrecords_graph_7ee21eb6b8ea120b53f0_t *a0, callbackcheckedrecords_graph_38a8689c2f20ead532ea_t *out);
__attribute__((visibility("hidden"))) void callbackcheckedrecords_callback_8994592329ecba032f0abfaa9703e59a57f3c6a1_lease_dispose(uint64_t token);
#ifdef __cplusplus
}
#endif
