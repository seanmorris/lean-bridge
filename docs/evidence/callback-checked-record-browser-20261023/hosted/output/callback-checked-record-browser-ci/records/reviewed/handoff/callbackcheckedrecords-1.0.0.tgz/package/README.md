# callbackcheckedrecords

Compiler-checked exports for callbackcheckedrecords.

Binding IR SHA-256: `8e79b7d2065d082f926495213e8e660c71462a70d694fde81e2e8c6fe682744b`

## Exports

### callHost

The host receives a proof-backed interval and must construct the one it replies with. 

### callHostContainer

Checked records inside structural containers keep their direction; the export itself
returns a plain value so only the callback carries records. 

### callHostMixed

A plain marker before the checked record in both directions. 

### callHostNested

A refined payload field keeps its own Subtype direction below the record. 

### makeClosure

A leased closure constructs its interval argument before running; its result is plain. 

### makeContainerClosure

Call CallbackCheckedRecords.makeContainerClosure.

### makeMixedClosure

A leased closure with a checked argument and a Lean-produced interval result. 

### makeNestedClosure

Call CallbackCheckedRecords.makeNestedClosure.

## Assurance

