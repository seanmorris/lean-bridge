// Generated from Binding IR SHA-256 8e79b7d2065d082f926495213e8e660c71462a70d694fde81e2e8c6fe682744b.
import { runtime } from "./internal/runtime.mjs";
import * as validate from "./internal/validators.mjs";

/**
 * The host receives a proof-backed interval and must construct the one it replies with. 
 */
export function callHost(arg0) {
  validate.assertCallback96775311ba874014bff2(arg0, "callHost.arg0");
  const result = runtime.call("lean:CallbackCheckedRecords.callHost", [runtime.prepareCallback(arg0, validate.wrapCallback96775311ba874014bff2(arg0, "callHost.arg0"))]);
  validate.assertNat(result, "callHost.result");
  return result;
}

/**
 * Checked records inside structural containers keep their direction; the export itself
returns a plain value so only the callback carries records. 
 */
export function callHostContainer(arg0) {
  validate.assertCallback115f6922f8f3e5b91c8e(arg0, "callHostContainer.arg0");
  const result = runtime.call("lean:CallbackCheckedRecords.callHostContainer", [runtime.prepareCallback(arg0, validate.wrapCallback115f6922f8f3e5b91c8e(arg0, "callHostContainer.arg0"))]);
  validate.assertNat(result, "callHostContainer.result");
  return result;
}

/**
 * A plain marker before the checked record in both directions. 
 */
export function callHostMixed(arg0) {
  validate.assertCallback44d43ec6a49b0f13f8ab(arg0, "callHostMixed.arg0");
  const result = runtime.call("lean:CallbackCheckedRecords.callHostMixed", [runtime.prepareCallback(arg0, validate.wrapCallback44d43ec6a49b0f13f8ab(arg0, "callHostMixed.arg0"))]);
  validate.assertNat(result, "callHostMixed.result");
  return result;
}

/**
 * A refined payload field keeps its own Subtype direction below the record. 
 */
export function callHostNested(arg0) {
  validate.assertCallbackb782f62c1be9d8b0085a(arg0, "callHostNested.arg0");
  const result = runtime.call("lean:CallbackCheckedRecords.callHostNested", [runtime.prepareCallback(arg0, validate.wrapCallbackb782f62c1be9d8b0085a(arg0, "callHostNested.arg0"))]);
  validate.assertNat(result, "callHostNested.result");
  return result;
}

/**
 * A leased closure constructs its interval argument before running; its result is plain. 
 */
export function makeClosure(arg0) {
  validate.assertNat(arg0, "makeClosure.arg0");
  const result = runtime.call("lean:CallbackCheckedRecords.makeClosure", [arg0]);
  validate.assertCallback705cd2e64f6f37b7b3c5(result, "makeClosure.result");
  return validate.wrapCallback705cd2e64f6f37b7b3c5(result, "makeClosure.result");
}

/**
 * Call CallbackCheckedRecords.makeContainerClosure.
 */
export function makeContainerClosure(arg0) {
  validate.assertNat(arg0, "makeContainerClosure.arg0");
  const result = runtime.call("lean:CallbackCheckedRecords.makeContainerClosure", [arg0]);
  validate.assertCallbacke974ad5f8e66387c6d39(result, "makeContainerClosure.result");
  return validate.wrapCallbacke974ad5f8e66387c6d39(result, "makeContainerClosure.result");
}

/**
 * A leased closure with a checked argument and a Lean-produced interval result. 
 */
export function makeMixedClosure(arg0) {
  validate.assertNat(arg0, "makeMixedClosure.arg0");
  const result = runtime.call("lean:CallbackCheckedRecords.makeMixedClosure", [arg0]);
  validate.assertCallbacke7252f0aa280ee0b13ec(result, "makeMixedClosure.result");
  return validate.wrapCallbacke7252f0aa280ee0b13ec(result, "makeMixedClosure.result");
}

/**
 * Call CallbackCheckedRecords.makeNestedClosure.
 */
export function makeNestedClosure(arg0) {
  validate.assertNat(arg0, "makeNestedClosure.arg0");
  const result = runtime.call("lean:CallbackCheckedRecords.makeNestedClosure", [arg0]);
  validate.assertCallback9edd7fa9a1ed11043b7d(result, "makeNestedClosure.result");
  return validate.wrapCallback9edd7fa9a1ed11043b7d(result, "makeNestedClosure.result");
}

export function withRecovery(operation, recovery) { return runtime.withRecovery(operation, recovery); }

export default Object.freeze({ callHost, callHostContainer, callHostMixed, callHostNested, makeClosure, makeContainerClosure, makeMixedClosure, makeNestedClosure, withRecovery });
