// Generated copied-value validators. This file is package-internal.
const invalid = (path, expected) => { throw new TypeError(`${path} must be ${expected}`); };
export const assertUnit = (value, path) => { if (value !== undefined) invalid(path, "undefined"); return value; };
export const assertBool = (value, path) => { if (typeof value !== "boolean") invalid(path, "boolean"); return value; };
export const assertUint8 = (value, path) => { if (!Number.isInteger(value) || value < 0 || value > 0xff) invalid(path, "uint8"); return value; };
export const assertUint16 = (value, path) => { if (!Number.isInteger(value) || value < 0 || value > 0xffff) invalid(path, "uint16"); return value; };
export const assertUint32 = (value, path) => { if (!Number.isInteger(value) || value < 0 || value > 0xffffffff) invalid(path, "uint32"); return value; };
export const assertInt8 = (value, path) => { if (!Number.isInteger(value) || value < -0x80 || value > 0x7f) invalid(path, "int8"); return value; };
export const assertInt16 = (value, path) => { if (!Number.isInteger(value) || value < -0x8000 || value > 0x7fff) invalid(path, "int16"); return value; };
export const assertInt32 = (value, path) => { if (!Number.isInteger(value) || value < -0x80000000 || value > 0x7fffffff) invalid(path, "int32"); return value; };
export const assertUsize = assertUint32;
export const assertIsize = assertInt32;
const assertBigInt = (value, path) => { if (typeof value !== "bigint") invalid(path, "bigint"); return value; };
export const assertUint64 = (value, path) => { assertBigInt(value, path); if (value < 0n || value > 0xffffffffffffffffn) invalid(path, "uint64"); return value; };
export const assertInt64 = (value, path) => { assertBigInt(value, path); if (value < -0x8000000000000000n || value > 0x7fffffffffffffffn) invalid(path, "int64"); return value; };
export const assertInt = assertBigInt;
export const assertNat = (value, path) => { assertBigInt(value, path); if (value < 0n) invalid(path, "non-negative bigint"); return value; };
export const assertFin = (value, bound, path) => { assertNat(value, path); if (value >= BigInt(bound)) invalid(path, `bigint below ${bound}`); return value; };
export const assertNestedFin = (value, refinement, path) => {
  if (refinement === null || refinement.kind === 'subtype') return;
  if (refinement.kind === 'fin') { assertFin(value, refinement.bound, path); return; }
  if (refinement.kind === 'record' || refinement.kind === 'checked-record' || refinement.kind === 'variant') {
    const fields = refinement.kind === 'variant' ? refinement.cases.find(branch => branch.name === value.kind).fields : refinement.fields;
    for (const field of fields) {
      const fieldPath = path + '.' + field.name, fieldRefinement = field.refinement;
      if (fieldRefinement?.kind === 'fin-field') {
        const boundPath = path + '.' + fieldRefinement.field, bound = value[fieldRefinement.field];
        assertNat(bound, boundPath); assertFin(value[field.name], bound, fieldPath);
      } else assertNestedFin(value[field.name], fieldRefinement, fieldPath);
    }
    return;
  }
  const child = (index, value, suffix) => assertNestedFin(value, refinement.arguments[index], path + suffix);
  if (refinement.kind === 'array' || refinement.kind === 'list') { value.forEach((item, index) => child(0, item, '[' + index + ']')); return; }
  if (refinement.kind === 'option') { if (value.tag === 'some') child(0, value.value, '.value'); return; }
  if (refinement.kind === 'tuple') { child(0, value[0], '[0]'); child(1, value[1], '[1]'); return; }
  if (Object.hasOwn(value, 'ok')) child(0, value.ok, '.ok'); else child(1, value.error, '.error');
};
const assertNumber = (value, path) => { if (typeof value !== "number") invalid(path, "number"); return value; };
export const assertFloat32 = assertNumber;
export const assertFloat64 = assertNumber;
export const assertString = (value, path) => { if (typeof value !== "string") invalid(path, "string"); return value; };
export const assertChar = (value, path) => { if (typeof value !== "string" || value.length === 0 || value.length > 2) invalid(path, "one Unicode scalar"); const point = value.codePointAt(0); if ((point >= 0xd800 && point <= 0xdfff) || value.length !== (point > 0xffff ? 2 : 1)) invalid(path, "one Unicode scalar"); return value; };
export const assertBytes = (value, path) => { if (!(value instanceof Uint8Array)) invalid(path, "Uint8Array"); return value; };

const copiedTypes = {"assertInterval":{"kind":"record","fields":[["lo","assertNat"],["hi","assertNat"]]},"assertWeighted":{"kind":"record","fields":[["weight","assertNat"],["limit","assertNat"]]},"assertApplied$14738559a19a523fec87":{"kind":"option","arguments":["assertInterval"]},"assertApplied$1cef3e85133f2c1702bd":{"kind":"result","arguments":["assertApplied$14738559a19a523fec87","assertString"]},"assertArrayOfApplied$14738559a19a523fec87":{"kind":"array","arguments":["assertApplied$14738559a19a523fec87"]}};
const scalarValidators = { assertUnit, assertBool, assertUint8, assertUint16, assertUint32, assertUint64, assertInt8, assertInt16, assertInt32, assertInt64, assertNat, assertInt, assertFloat32, assertFloat64, assertString, assertBytes, assertChar, assertUsize, assertIsize };
const ownData = (value, key, path, expected = "own data fields") => {
  const field = Object.getOwnPropertyDescriptor(value, key);
  if (!field || !Object.hasOwn(field, "value")) invalid(path, expected);
  return field.value;
};
const exactFields = (value, expected, path) => {
  const own = Reflect.ownKeys(value);
  if (own.length !== expected.length || own.some(key => !expected.includes(key)))
    throw new TypeError(path + " does not match the declared copied fields");
};
const copiedValue = (root, input, path) => {
  const active = new Set(), stack = [{ type: root, value: input, path, depth: 0 }];
  let nodes = 0;
  while (stack.length) {
    const frame = stack.at(-1);
    if (frame.children) {
      if (frame.index === frame.count) { active.delete(frame.value); stack.pop(); continue; }
      const index = frame.index++, field = frame.sequence ? [index, frame.element ?? frame.children[index]] : frame.children[index];
      stack.push({ type: field[1], value: ownData(frame.value, field[0], frame.path, frame.sequence ? "dense data array" : "own data fields"), path: frame.path + "." + field[0], depth: frame.depth + 1 });
      continue;
    }
    if (frame.depth > 128) throw new RangeError("Component recursive value depth exceeded");
    if (++nodes > 262144) throw new RangeError("Component recursive value node budget exceeded");
    let type = copiedTypes[frame.type];
    while (type?.kind === "alias") { frame.type = type.target; type = copiedTypes[frame.type]; }
    if (Object.hasOwn(scalarValidators, frame.type)) { scalarValidators[frame.type](frame.value, frame.path); stack.pop(); continue; }
    if (!type) invalid(frame.path, "a declared copied type");
    const value = frame.value, sequence = ["array", "list", "tuple"].includes(type.kind);
    if (!value || typeof value !== "object") invalid(frame.path, "plain " + type.kind);
    if (active.has(value)) throw new TypeError("Cyclic copied value");
    let children, element, count;
    if (sequence) {
      if (!Array.isArray(value) && !(type.kind === "array" && value instanceof Uint32Array)) invalid(frame.path, "array");
      count = value.length; children = type.arguments;
      if (count > 262144 - nodes) throw new RangeError("Component recursive value node budget exceeded (bounded array)");
      if (type.kind === "tuple" && count !== children.length) invalid(frame.path, "exact data tuple");
      if (type.kind !== "tuple") element = children[0];
      if (Array.isArray(value) && Reflect.ownKeys(value).length !== count + 1) invalid(frame.path, "dense data array");
    } else {
      if (![Object.prototype, null].includes(Object.getPrototypeOf(value))) invalid(frame.path, "plain " + type.kind);
      let extra = [];
      if (type.kind === "record") children = type.fields;
      else if (type.kind === "variant") {
        const kind = ownData(value, "kind", frame.path);
        if (typeof kind !== "string" || !Object.hasOwn(type.cases, kind)) invalid(frame.path, "declared variant constructor");
        children = type.cases[kind]; extra = ["kind"];
      } else if (type.kind === "option") {
        const tag = ownData(value, "tag", frame.path);
        if (tag !== "none" && tag !== "some") invalid(frame.path, "Option tag");
        children = tag === "none" ? [] : [["value", type.arguments[0]]]; extra = ["tag"];
      } else {
        const error = Object.hasOwn(value, "error");
        children = [[error ? "error" : "ok", type.arguments[error ? 1 : 0]]];
      }
      exactFields(value, [...extra, ...children.map(field => field[0])], frame.path);
      count = children.length;
    }
    if (count > 262144 - nodes) throw new RangeError("Component recursive value node budget exceeded");
    Object.assign(frame, { children, sequence, element, count, index: 0 }); active.add(value);
  }
  return input;
};
export const assertInterval = (value, path) => copiedValue("assertInterval", value, path);
export const assertWeighted = (value, path) => copiedValue("assertWeighted", value, path);
export const assertApplied$14738559a19a523fec87 = (value, path) => copiedValue("assertApplied$14738559a19a523fec87", value, path);
export const assertApplied$1cef3e85133f2c1702bd = (value, path) => copiedValue("assertApplied$1cef3e85133f2c1702bd", value, path);
export const assertArrayOfApplied$14738559a19a523fec87 = (value, path) => copiedValue("assertArrayOfApplied$14738559a19a523fec87", value, path);
export const assertCallback115f6922f8f3e5b91c8e = (value, path) => { if (typeof value !== "function") invalid(path, "function"); return value; };
export const assertCallback44d43ec6a49b0f13f8ab = (value, path) => { if (typeof value !== "function") invalid(path, "function"); return value; };
export const assertCallback705cd2e64f6f37b7b3c5 = (value, path) => { if (typeof value !== "function") invalid(path, "function"); return value; };
export const assertCallback96775311ba874014bff2 = (value, path) => { if (typeof value !== "function") invalid(path, "function"); return value; };
export const assertCallback9edd7fa9a1ed11043b7d = (value, path) => { if (typeof value !== "function") invalid(path, "function"); return value; };
export const assertCallbackb782f62c1be9d8b0085a = (value, path) => { if (typeof value !== "function") invalid(path, "function"); return value; };
export const assertCallbacke7252f0aa280ee0b13ec = (value, path) => { if (typeof value !== "function") invalid(path, "function"); return value; };
export const assertCallbacke974ad5f8e66387c6d39 = (value, path) => { if (typeof value !== "function") invalid(path, "function"); return value; };
export const wrapCallback115f6922f8f3e5b91c8e = (value, path) => new Proxy(value, {
  apply(target, receiver, args) {
    if (args.length !== 1) throw new TypeError(path + " expects 1 arguments");
    assertApplied$14738559a19a523fec87(args[0], path + ".arg0");
    assertNestedFin(args[0], {"arguments":[{"constructor":null,"fields":[{"name":"lo","refinement":null},{"name":"hi","refinement":null}],"kind":"checked-record","name":"CallbackCheckedRecords.Interval"}],"kind":"option"}, path + ".arg0");
    const result = Reflect.apply(target, receiver, args);
    assertApplied$1cef3e85133f2c1702bd(result, path + ".result");
    assertNestedFin(result, {"arguments":[{"arguments":[{"constructor":"CallbackCheckedRecords.mkInterval","fields":[{"name":"lo","refinement":null},{"name":"hi","refinement":null}],"kind":"checked-record","name":"CallbackCheckedRecords.Interval"}],"kind":"option"},null],"kind":"result"}, path + ".result");
    return result;
  }
});
export const wrapCallback44d43ec6a49b0f13f8ab = (value, path) => new Proxy(value, {
  apply(target, receiver, args) {
    if (args.length !== 2) throw new TypeError(path + " expects 2 arguments");
    assertNat(args[0], path + ".arg0");
    assertInterval(args[1], path + ".arg1");
    assertNestedFin(args[1], {"constructor":null,"fields":[{"name":"lo","refinement":null},{"name":"hi","refinement":null}],"kind":"checked-record","name":"CallbackCheckedRecords.Interval"}, path + ".arg1");
    const result = Reflect.apply(target, receiver, args);
    assertInterval(result, path + ".result");
    assertNestedFin(result, {"constructor":"CallbackCheckedRecords.mkInterval","fields":[{"name":"lo","refinement":null},{"name":"hi","refinement":null}],"kind":"checked-record","name":"CallbackCheckedRecords.Interval"}, path + ".result");
    return result;
  }
});
export const wrapCallback705cd2e64f6f37b7b3c5 = (value, path) => new Proxy(value, {
  apply(target, receiver, args) {
    if (args.length !== 1) throw new TypeError(path + " expects 1 arguments");
    assertInterval(args[0], path + ".arg0");
    assertNestedFin(args[0], {"constructor":"CallbackCheckedRecords.mkInterval","fields":[{"name":"lo","refinement":null},{"name":"hi","refinement":null}],"kind":"checked-record","name":"CallbackCheckedRecords.Interval"}, path + ".arg0");
    const result = Reflect.apply(target, receiver, args);
    assertNat(result, path + ".result");
    return result;
  }
});
export const wrapCallback96775311ba874014bff2 = (value, path) => new Proxy(value, {
  apply(target, receiver, args) {
    if (args.length !== 1) throw new TypeError(path + " expects 1 arguments");
    assertInterval(args[0], path + ".arg0");
    assertNestedFin(args[0], {"constructor":null,"fields":[{"name":"lo","refinement":null},{"name":"hi","refinement":null}],"kind":"checked-record","name":"CallbackCheckedRecords.Interval"}, path + ".arg0");
    const result = Reflect.apply(target, receiver, args);
    assertInterval(result, path + ".result");
    assertNestedFin(result, {"constructor":"CallbackCheckedRecords.mkInterval","fields":[{"name":"lo","refinement":null},{"name":"hi","refinement":null}],"kind":"checked-record","name":"CallbackCheckedRecords.Interval"}, path + ".result");
    return result;
  }
});
export const wrapCallback9edd7fa9a1ed11043b7d = (value, path) => new Proxy(value, {
  apply(target, receiver, args) {
    if (args.length !== 1) throw new TypeError(path + " expects 1 arguments");
    assertWeighted(args[0], path + ".arg0");
    assertNestedFin(args[0], {"constructor":"CallbackCheckedRecords.mkWeighted","fields":[{"name":"weight","refinement":{"constructor":"CallbackCheckedRecords.checkedPositive","kind":"subtype"}},{"name":"limit","refinement":null}],"kind":"checked-record","name":"CallbackCheckedRecords.Weighted"}, path + ".arg0");
    const result = Reflect.apply(target, receiver, args);
    assertNat(result, path + ".result");
    return result;
  }
});
export const wrapCallbackb782f62c1be9d8b0085a = (value, path) => new Proxy(value, {
  apply(target, receiver, args) {
    if (args.length !== 1) throw new TypeError(path + " expects 1 arguments");
    assertWeighted(args[0], path + ".arg0");
    assertNestedFin(args[0], {"constructor":null,"fields":[{"name":"weight","refinement":{"constructor":null,"kind":"subtype"}},{"name":"limit","refinement":null}],"kind":"checked-record","name":"CallbackCheckedRecords.Weighted"}, path + ".arg0");
    const result = Reflect.apply(target, receiver, args);
    assertWeighted(result, path + ".result");
    assertNestedFin(result, {"constructor":"CallbackCheckedRecords.mkWeighted","fields":[{"name":"weight","refinement":{"constructor":"CallbackCheckedRecords.checkedPositive","kind":"subtype"}},{"name":"limit","refinement":null}],"kind":"checked-record","name":"CallbackCheckedRecords.Weighted"}, path + ".result");
    return result;
  }
});
export const wrapCallbacke7252f0aa280ee0b13ec = (value, path) => new Proxy(value, {
  apply(target, receiver, args) {
    if (args.length !== 2) throw new TypeError(path + " expects 2 arguments");
    assertNat(args[0], path + ".arg0");
    assertInterval(args[1], path + ".arg1");
    assertNestedFin(args[1], {"constructor":"CallbackCheckedRecords.mkInterval","fields":[{"name":"lo","refinement":null},{"name":"hi","refinement":null}],"kind":"checked-record","name":"CallbackCheckedRecords.Interval"}, path + ".arg1");
    const result = Reflect.apply(target, receiver, args);
    assertInterval(result, path + ".result");
    assertNestedFin(result, {"constructor":null,"fields":[{"name":"lo","refinement":null},{"name":"hi","refinement":null}],"kind":"checked-record","name":"CallbackCheckedRecords.Interval"}, path + ".result");
    return result;
  }
});
export const wrapCallbacke974ad5f8e66387c6d39 = (value, path) => new Proxy(value, {
  apply(target, receiver, args) {
    if (args.length !== 1) throw new TypeError(path + " expects 1 arguments");
    assertArrayOfApplied$14738559a19a523fec87(args[0], path + ".arg0");
    assertNestedFin(args[0], {"arguments":[{"arguments":[{"constructor":"CallbackCheckedRecords.mkInterval","fields":[{"name":"lo","refinement":null},{"name":"hi","refinement":null}],"kind":"checked-record","name":"CallbackCheckedRecords.Interval"}],"kind":"option"}],"kind":"array"}, path + ".arg0");
    const result = Reflect.apply(target, receiver, args);
    assertApplied$14738559a19a523fec87(result, path + ".result");
    assertNestedFin(result, {"arguments":[{"constructor":null,"fields":[{"name":"lo","refinement":null},{"name":"hi","refinement":null}],"kind":"checked-record","name":"CallbackCheckedRecords.Interval"}],"kind":"option"}, path + ".result");
    return result;
  }
});
