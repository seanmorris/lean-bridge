// Generated from Binding IR SHA-256 2e2ed2326cfa5f0036f5bd5f124aefb5fd804a984fd040bace0a79704568fe58.
/**
 * Checked Lean callback.
 */
export type Callback115f6922f8f3e5b91c8e = (arg0: Readonly<{ tag: "none" }> | Readonly<{ tag: "some"; value: Interval }>) => Readonly<{ ok: Readonly<{ tag: "none" }> | Readonly<{ tag: "some"; value: Interval }> }> | Readonly<{ error: string }>;

/**
 * Checked Lean callback.
 */
export type Callback44d43ec6a49b0f13f8ab = (arg0: bigint, arg1: Interval) => Interval;

/**
 * Checked Lean callback.
 */
export type Callback705cd2e64f6f37b7b3c5 = (arg0: Interval) => bigint;

/**
 * Checked Lean callback.
 */
export type Callback96775311ba874014bff2 = (arg0: Interval) => Interval;

/**
 * Checked Lean callback.
 */
export type Callback9edd7fa9a1ed11043b7d = (arg0: Weighted) => bigint;

/**
 * Checked Lean callback.
 */
export type Callbackb782f62c1be9d8b0085a = (arg0: Weighted) => Weighted;

/**
 * Checked Lean callback.
 */
export type Callbacke7252f0aa280ee0b13ec = (arg0: bigint, arg1: Interval) => Interval;

/**
 * Checked Lean callback.
 */
export type Callbacke974ad5f8e66387c6d39 = (arg0: ReadonlyArray<Readonly<{ tag: "none" }> | Readonly<{ tag: "some"; value: Interval }>>) => Readonly<{ tag: "none" }> | Readonly<{ tag: "some"; value: Interval }>;

/**
 * Checked Lean CallbackCheckedRecords.Interval.
 */
export interface Interval {
  readonly lo: bigint;
  readonly hi: bigint;
}

/**
 * Checked Lean CallbackCheckedRecords.Weighted.
 */
export interface Weighted {
  readonly weight: bigint;
  readonly limit: bigint;
}

export interface LeanOwnedCallable {
  readonly disposed: boolean;
  dispose(): boolean;
  [Symbol.dispose](): void;
}

/**
 * The host receives a proof-backed interval and must construct the one it replies with. 
 */
export declare function callHost(arg0: Callback96775311ba874014bff2): bigint;

/**
 * Checked records inside structural containers keep their direction; the export itself
returns a plain value so only the callback carries records. 
 */
export declare function callHostContainer(arg0: Callback115f6922f8f3e5b91c8e): bigint;

/**
 * A plain marker before the checked record in both directions. 
 */
export declare function callHostMixed(arg0: Callback44d43ec6a49b0f13f8ab): bigint;

/**
 * A refined payload field keeps its own Subtype direction below the record. 
 */
export declare function callHostNested(arg0: Callbackb782f62c1be9d8b0085a): bigint;

/**
 * A leased closure constructs its interval argument before running; its result is plain. 
 */
export declare function makeClosure(arg0: bigint): Callback705cd2e64f6f37b7b3c5 & LeanOwnedCallable;

/**
 * Call CallbackCheckedRecords.makeContainerClosure.
 */
export declare function makeContainerClosure(arg0: bigint): Callbacke974ad5f8e66387c6d39 & LeanOwnedCallable;

/**
 * A leased closure with a checked argument and a Lean-produced interval result. 
 */
export declare function makeMixedClosure(arg0: bigint): Callbacke7252f0aa280ee0b13ec & LeanOwnedCallable;

/**
 * Call CallbackCheckedRecords.makeNestedClosure.
 */
export declare function makeNestedClosure(arg0: bigint): Callback9edd7fa9a1ed11043b7d & LeanOwnedCallable;

export declare function withRecovery<Args extends readonly unknown[], Result>(operation: (...args: Args) => Result, recovery: Result): (...args: Args) => Result;

declare const bindings: Readonly<{
  readonly callHost: typeof callHost;
  readonly callHostContainer: typeof callHostContainer;
  readonly callHostMixed: typeof callHostMixed;
  readonly callHostNested: typeof callHostNested;
  readonly makeClosure: typeof makeClosure;
  readonly makeContainerClosure: typeof makeContainerClosure;
  readonly makeMixedClosure: typeof makeMixedClosure;
  readonly makeNestedClosure: typeof makeNestedClosure;
  readonly withRecovery: typeof withRecovery;
}>;
export default bindings;
