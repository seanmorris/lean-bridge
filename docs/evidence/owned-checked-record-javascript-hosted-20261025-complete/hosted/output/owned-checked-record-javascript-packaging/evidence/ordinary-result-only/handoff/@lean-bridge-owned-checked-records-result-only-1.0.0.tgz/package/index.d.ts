declare const leanResource: unique symbol;

export interface LeanLease {
  readonly disposed: boolean;
  dispose(): boolean;
  retain(): this;
}

/** Checked Lean OwnedCheckedRecords.Claim. */
export interface ClaimInput {
  readonly "holder": Ticket;
  readonly "quota": bigint;
}

export interface Claim {
  readonly "holder": Ticket;
  readonly "quota": bigint;
}

/** Checked Lean OwnedCheckedRecords.Ticket. */
export interface Ticket extends LeanLease {
  readonly [leanResource]: "lean:OwnedCheckedRecords.Ticket";
}

/** Result-only: Lean produces an owned checked record from a resource.  */
export function claimFor(arg0: Ticket): (Readonly<{ tag: "none" }> | Readonly<{ tag: "some"; value: Claim }>);

/** Call OwnedCheckedRecords.newTicket. */
export function newTicket(arg0: bigint, arg1: string): Ticket;

/** Call OwnedCheckedRecords.serial. */
export function serial(arg0: Ticket): bigint;

/** Release this component and invalidate its outstanding leases. */
export function close(): boolean;
/** Supply the typed fallback required by an uninhabited callback result. */
export function withRecovery<Args extends readonly unknown[], Result>(operation: (...args: Args) => Result, recovery: Result): (...args: Args) => Result;

declare const bindings: Readonly<{
  claimFor: typeof claimFor;
  newTicket: typeof newTicket;
  serial: typeof serial;
  close: typeof close;
  withRecovery: typeof withRecovery;
}>;
export default bindings;
