# owned-checked-records

Compiler-checked exports for owned-checked-records.

Call the named exports with JavaScript values. The package loads its shared runtime automatically.
Records use source field names. Variants use kind and named payload fields. Arrays and lists use arrays.
Options use { tag: "none" } or { tag: "some", value }. Results use { ok } or { error }.
Nat, Int, UInt64 and Int64 use bigint. Unit uses undefined; bytes use Uint8Array.

## Resource lifetime

Resource values and returned functions expose dispose(), retain() and disposed. Dispose each distinct lease when finished.
retain() creates an independent lease. Repeated references within a result share one wrapper.
Callback arguments expire when the callback returns. Retain a resource inside the callback to keep it.
close() releases the component and invalidates its outstanding leases. It does not close other packages.
A native trap retires the shared heap; all packages using that heap reject further calls.

## Callbacks and types

Pass ordinary synchronous functions as callbacks. Return a value of the declared result type.
For a callback whose result has no default value, use withRecovery(callback, recoveryValue). The original thrown error reaches the caller.
The TypeScript declarations distinguish host inputs from native results. Input types accept ordinary callbacks; returned functions include explicit lifetime methods.
Conversions reject cycles, invalid fields, invalid tags and out-of-range values. Limits: 128 levels, 262144 visits, 16 MiB and 4096 retained references per call.

## Exports

- claimFor: Result-only: Lean produces an owned checked record from a resource. 
- newTicket: Call OwnedCheckedRecords.newTicket.
- serial: Call OwnedCheckedRecords.serial.
