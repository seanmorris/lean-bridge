#include "component.h"
#include "lean_bridge_native_runtime.h"
static _Thread_local int lean_bridge_owned_callback_failure_9f18c33615370c989e2b_state;
int lean_bridge_owned_callback_failure_9f18c33615370c989e2b(void) { int result = lean_bridge_owned_callback_failure_9f18c33615370c989e2b_state; lean_bridge_owned_callback_failure_9f18c33615370c989e2b_state = 0; return result; }
