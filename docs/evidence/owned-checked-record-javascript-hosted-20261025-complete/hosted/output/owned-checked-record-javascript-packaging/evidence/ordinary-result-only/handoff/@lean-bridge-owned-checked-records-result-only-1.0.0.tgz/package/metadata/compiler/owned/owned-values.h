#pragma once
#include <stdint.h>
#include <stddef.h>
/* Private generated adapter values. Host APIs keep resource tokens opaque. */
typedef struct lbov_9f18c33615370c989e2b_t160ce821a84f6887bbfd lbov_9f18c33615370c989e2b_t160ce821a84f6887bbfd;
typedef struct lbov_9f18c33615370c989e2b_tb2825946e038e653bd2b lbov_9f18c33615370c989e2b_tb2825946e038e653bd2b;
typedef struct lbov_9f18c33615370c989e2b_td79b9bbde250ee1779da lbov_9f18c33615370c989e2b_td79b9bbde250ee1779da;
typedef struct lbov_9f18c33615370c989e2b_t167081552b6f9c1d1afd lbov_9f18c33615370c989e2b_t167081552b6f9c1d1afd;
typedef struct lbov_9f18c33615370c989e2b_tdc0347e1f7f5c4d928f1 lbov_9f18c33615370c989e2b_tdc0347e1f7f5c4d928f1;
struct lbov_9f18c33615370c989e2b_td79b9bbde250ee1779da {
  uint64_t token;
};
struct lbov_9f18c33615370c989e2b_t167081552b6f9c1d1afd {
  const uint32_t *data;
  size_t length;
};
struct lbov_9f18c33615370c989e2b_tdc0347e1f7f5c4d928f1 {
  const char *data;
  size_t length;
};
struct lbov_9f18c33615370c989e2b_t160ce821a84f6887bbfd {
  uint8_t tag;
  const lbov_9f18c33615370c989e2b_tb2825946e038e653bd2b *f0;
};
struct lbov_9f18c33615370c989e2b_tb2825946e038e653bd2b {
  lbov_9f18c33615370c989e2b_td79b9bbde250ee1779da f0;
  lbov_9f18c33615370c989e2b_t167081552b6f9c1d1afd f1;
};
