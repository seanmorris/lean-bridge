#include <lean/lean.h>
#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#ifndef LB_JS_ALLOC_FAIL
#define LB_JS_ALLOC_FAIL() 0
#endif
typedef struct {
  size_t bytes;
  max_align_t alignment;
  unsigned char data[];
} lbjs_component_0faf1e9b49a8ee0850c4_allocation;
static size_t lbjs_component_0faf1e9b49a8ee0850c4_live_allocations;
static void *lbjs_component_0faf1e9b49a8ee0850c4_allocate(size_t bytes) {
  if (bytes > SIZE_MAX - sizeof(lbjs_component_0faf1e9b49a8ee0850c4_allocation) || LB_JS_ALLOC_FAIL()) return NULL;
  lbjs_component_0faf1e9b49a8ee0850c4_allocation *allocation = calloc(1, sizeof(*allocation) + bytes);
  if (!allocation) return NULL;
  allocation->bytes = bytes; ++lbjs_component_0faf1e9b49a8ee0850c4_live_allocations; return allocation->data;
}
static lbjs_component_0faf1e9b49a8ee0850c4_allocation *lbjs_component_0faf1e9b49a8ee0850c4_allocation_of(const void *value) {
  return (lbjs_component_0faf1e9b49a8ee0850c4_allocation *)((unsigned char *)value - offsetof(lbjs_component_0faf1e9b49a8ee0850c4_allocation, data));
}
static void lbjs_component_0faf1e9b49a8ee0850c4_free(void *value) {
  if (!value) return;
  --lbjs_component_0faf1e9b49a8ee0850c4_live_allocations; free(lbjs_component_0faf1e9b49a8ee0850c4_allocation_of(value));
}
#define LB_OWNED_ALLOC lbjs_component_0faf1e9b49a8ee0850c4_allocate
#define LB_OWNED_FREE lbjs_component_0faf1e9b49a8ee0850c4_free
#include "owned-values-codec.h"
#include "owned-js-layout.h"
extern lean_object *initialize_LeanBridgeOwned9017cc99fae375a2(uint8_t);
static lb_owned_context lbjs_component_0faf1e9b49a8ee0850c4_context;
typedef struct { ov_result_owner value; unsigned key; } lbjs_component_0faf1e9b49a8ee0850c4_owner;
static lbjs_component_0faf1e9b49a8ee0850c4_owner lbjs_component_0faf1e9b49a8ee0850c4_owners[4096];
static unsigned lbjs_component_0faf1e9b49a8ee0850c4_next_owner, lbjs_component_0faf1e9b49a8ee0850c4_closed;
static ov_result_owner *lbjs_component_0faf1e9b49a8ee0850c4_find(unsigned key) {
  if (!key) return NULL;
  for (size_t i = 0; i < 4096; ++i)
    if (lbjs_component_0faf1e9b49a8ee0850c4_owners[i].key == key) return &lbjs_component_0faf1e9b49a8ee0850c4_owners[i].value;
  return NULL;
}
unsigned lbjs_component_0faf1e9b49a8ee0850c4_open(void) {
  if (lb_owned_ready(&lbjs_component_0faf1e9b49a8ee0850c4_context) || lbjs_component_0faf1e9b49a8ee0850c4_next_owner == UINT32_MAX) return 0;
  for (size_t i = 0; i < 4096; ++i) if (!lbjs_component_0faf1e9b49a8ee0850c4_owners[i].key) {
    lbjs_component_0faf1e9b49a8ee0850c4_owners[i].key = ++lbjs_component_0faf1e9b49a8ee0850c4_next_owner; return lbjs_component_0faf1e9b49a8ee0850c4_next_owner;
  }
  return 0;
}
int lbjs_component_0faf1e9b49a8ee0850c4_valid(unsigned key) { return lbjs_component_0faf1e9b49a8ee0850c4_find(key) != NULL; }
int lbjs_component_0faf1e9b49a8ee0850c4_release(unsigned key) {
  ov_result_owner *owner = lbjs_component_0faf1e9b49a8ee0850c4_find(key); if (!owner) return LB_OWNED_INVALID;
  int status = ov_owner_clear(owner);
  if (!status) for (size_t i = 0; i < 4096; ++i)
    if (lbjs_component_0faf1e9b49a8ee0850c4_owners[i].key == key) { lbjs_component_0faf1e9b49a8ee0850c4_owners[i].key = 0; break; }
  return status;
}
#include <emscripten.h>
typedef struct { unsigned host, type; uint64_t token; } lbjs_0faf1e9b49a8ee0850c4_host;
static lbjs_0faf1e9b49a8ee0850c4_host lbjs_0faf1e9b49a8ee0850c4_hosts[4096];
typedef struct lbjs_0faf1e9b49a8ee0850c4_frame { struct lbjs_0faf1e9b49a8ee0850c4_frame *parent; unsigned key, host, type, owner; const uintptr_t *args; void *reply; } lbjs_0faf1e9b49a8ee0850c4_frame;
static lbjs_0faf1e9b49a8ee0850c4_frame *lbjs_0faf1e9b49a8ee0850c4_active; static unsigned lbjs_0faf1e9b49a8ee0850c4_next;
EM_JS(int, lbjs_0faf1e9b49a8ee0850c4_dispatch_js, (unsigned key, unsigned host, unsigned type, unsigned owner, const uintptr_t *args, void *reply), {
  return Module["leanBridgeOwnedCallbacks_0faf1e9b49a8ee0850c439e58fbd9b71512bc6c0369f02dca6c46c5ba630909f"].dispatch(key, host, type, owner, args, reply);
});
EM_JS(int, lbjs_0faf1e9b49a8ee0850c4_finish_js, (unsigned key), { return Module["leanBridgeOwnedCallbacks_0faf1e9b49a8ee0850c439e58fbd9b71512bc6c0369f02dca6c46c5ba630909f"].finish(key); });
int lbjs_0faf1e9b49a8ee0850c4_valid(unsigned key, unsigned host, unsigned type, unsigned owner, const uintptr_t *args, void *reply) {
  lbjs_0faf1e9b49a8ee0850c4_frame *frame = lbjs_0faf1e9b49a8ee0850c4_active;
  return frame && frame->key == key && frame->host == host && frame->type == type
    && frame->owner == owner && frame->args == args && frame->reply == reply;
}
int lbjs_0faf1e9b49a8ee0850c4_end(unsigned host) {
  for (size_t i = 0; i < 4096; ++i) if (lbjs_0faf1e9b49a8ee0850c4_hosts[i].host == host && host) {
    lb_native_callback_release(lbjs_0faf1e9b49a8ee0850c4_hosts[i].token); lbjs_0faf1e9b49a8ee0850c4_hosts[i] = (lbjs_0faf1e9b49a8ee0850c4_host){0}; return 0;
  }
  return LB_OWNED_INVALID;
}
unsigned lbjs_0faf1e9b49a8ee0850c4_live(void) { unsigned count = 0; for (unsigned i = 0; i < 4096; ++i) if (lbjs_0faf1e9b49a8ee0850c4_hosts[i].host) ++count; return count; }
int lbjs_0faf1e9b49a8ee0850c4_begin(unsigned type, unsigned id, const void *fallback, void *out, unsigned owner_key) {
  ov_result_owner *owner = lbjs_component_0faf1e9b49a8ee0850c4_find(owner_key); if (!owner || !id) return LB_OWNED_INVALID;
  lbjs_0faf1e9b49a8ee0850c4_host *host = NULL;
  for (size_t i = 0; i < 4096; ++i) { if (lbjs_0faf1e9b49a8ee0850c4_hosts[i].host == id) return LB_OWNED_INVALID; if (!host && !lbjs_0faf1e9b49a8ee0850c4_hosts[i].host) host = &lbjs_0faf1e9b49a8ee0850c4_hosts[i]; }
  if (!host) return LB_OWNED_LIMIT;
  *host = (lbjs_0faf1e9b49a8ee0850c4_host){ .host = id, .type = type };
  int status; switch (type) {
  default: status = LB_OWNED_INVALID;
  }
  if (status) *host = (lbjs_0faf1e9b49a8ee0850c4_host){0};
  return status;
}

int lbjs_component_0faf1e9b49a8ee0850c4_init(void) {
  if (lbjs_component_0faf1e9b49a8ee0850c4_closed) return LB_OWNED_CLOSED;
  if (lbjs_component_0faf1e9b49a8ee0850c4_context.initialized) return lb_owned_ready(&lbjs_component_0faf1e9b49a8ee0850c4_context);
  if (!lean_bridge_native_component_initialize("owned-checked-records@1.0.0",
      (lean_bridge_native_initializer)initialize_LeanBridgeOwned9017cc99fae375a2)) return LB_OWNED_RUNTIME;
  return lb_owned_context_init(&lbjs_component_0faf1e9b49a8ee0850c4_context, "owned-checked-records@1.0.0");
}
int lbjs_component_0faf1e9b49a8ee0850c4_dispatch(unsigned index, const uintptr_t *args, void *out, unsigned key) {
  ov_result_owner *owner = lbjs_component_0faf1e9b49a8ee0850c4_find(key); if (!owner) return LB_OWNED_INVALID;
  switch (index) {
  case 0:
    if (!ov_pointer(out, sizeof(lbov_0faf1e9b49a8ee0850c4_t160ce821a84f6887bbfd), _Alignof(lbov_0faf1e9b49a8ee0850c4_t160ce821a84f6887bbfd)) || !ov_pointer(args, 1 * sizeof(*args), _Alignof(uintptr_t))) return LB_OWNED_INVALID;
    return lbov_0faf1e9b49a8ee0850c4_f483485736ace9af57086(&lbjs_component_0faf1e9b49a8ee0850c4_context, (const lbov_0faf1e9b49a8ee0850c4_td79b9bbde250ee1779da *)args[0], (lbov_0faf1e9b49a8ee0850c4_t160ce821a84f6887bbfd *)out, owner);
  case 1:
    if (!ov_pointer(out, sizeof(lbov_0faf1e9b49a8ee0850c4_td79b9bbde250ee1779da), _Alignof(lbov_0faf1e9b49a8ee0850c4_td79b9bbde250ee1779da)) || !ov_pointer(args, 2 * sizeof(*args), _Alignof(uintptr_t))) return LB_OWNED_INVALID;
    return lbov_0faf1e9b49a8ee0850c4_fa1e5189bd92568e4b939(&lbjs_component_0faf1e9b49a8ee0850c4_context, (const lbov_0faf1e9b49a8ee0850c4_t167081552b6f9c1d1afd *)args[0], (const lbov_0faf1e9b49a8ee0850c4_tdc0347e1f7f5c4d928f1 *)args[1], (lbov_0faf1e9b49a8ee0850c4_td79b9bbde250ee1779da *)out, owner);
  case 2:
    if (!ov_pointer(out, sizeof(lbov_0faf1e9b49a8ee0850c4_t167081552b6f9c1d1afd), _Alignof(lbov_0faf1e9b49a8ee0850c4_t167081552b6f9c1d1afd)) || !ov_pointer(args, 1 * sizeof(*args), _Alignof(uintptr_t))) return LB_OWNED_INVALID;
    return lbov_0faf1e9b49a8ee0850c4_fec926afda994fba3abe2(&lbjs_component_0faf1e9b49a8ee0850c4_context, (const lbov_0faf1e9b49a8ee0850c4_td79b9bbde250ee1779da *)args[0], (lbov_0faf1e9b49a8ee0850c4_t167081552b6f9c1d1afd *)out, owner);
  default: return LB_OWNED_INVALID;
  }
}
int lbjs_component_0faf1e9b49a8ee0850c4_claim(unsigned key, const void *pointer, size_t bytes) {
  ov_result_owner *owner = lbjs_component_0faf1e9b49a8ee0850c4_find(key); if (!owner) return 0;
  for (ov_allocation *allocation = owner->allocations; allocation; allocation = allocation->next) {
    if (allocation->data != pointer) continue;
    size_t actual = lbjs_component_0faf1e9b49a8ee0850c4_allocation_of(allocation)->bytes;
    return actual >= sizeof(*allocation) && actual - sizeof(*allocation) == bytes;
  }
  return 0;
}
int lbjs_component_0faf1e9b49a8ee0850c4_identity(unsigned key, unsigned type, uint64_t token) {
  ov_result_owner *owner = lbjs_component_0faf1e9b49a8ee0850c4_find(key); if (!owner) return 0;
  const char *kind;
  switch (type) {
  case 2: kind = "resource:OwnedCheckedRecords.Ticket"; break;
  default: return 0;
  }
  for (lb_owned_entry *entry = owner->batch.entries; entry; entry = entry->next)
    if (entry->owner->token == token && !strcmp(entry->owner->kind, kind)) return 1;
  return 0;
}
int lbjs_component_0faf1e9b49a8ee0850c4_retain(unsigned type, uint64_t token, void *out, unsigned key) {
  ov_result_owner *owner = lbjs_component_0faf1e9b49a8ee0850c4_find(key); if (!owner) return LB_OWNED_INVALID;
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, &lbjs_component_0faf1e9b49a8ee0850c4_context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  lean_object *value = NULL;
  switch (type) {
  case 2: {
    lbov_0faf1e9b49a8ee0850c4_td79b9bbde250ee1779da input = { .token = token };
    if (!ov_pointer(out, sizeof(input), _Alignof(lbov_0faf1e9b49a8ee0850c4_td79b9bbde250ee1779da))) { status = LB_OWNED_INVALID; break; }
    status = lbov_0faf1e9b49a8ee0850c4_vd79b9bbde250ee1779da_in(&input, 0, 1, &transaction, &value);
    if (!status) status = lbov_0faf1e9b49a8ee0850c4_vd79b9bbde250ee1779da_out(out, value, 0, &transaction);
    break;
  }
  default: status = LB_OWNED_INVALID;
  }
  return status ? ov_abort(&transaction, status) : ov_commit(&transaction, owner);
}
int lbjs_component_0faf1e9b49a8ee0850c4_close(void) {
  if (lbjs_component_0faf1e9b49a8ee0850c4_closed) return LB_OWNED_OK;
  int status = lb_owned_affinity(&lbjs_component_0faf1e9b49a8ee0850c4_context);
  if (status) return status;
  if (lbjs_component_0faf1e9b49a8ee0850c4_context.top || lbjs_0faf1e9b49a8ee0850c4_live()) return LB_OWNED_ORDER;
  for (size_t i = 0; i < 4096; ++i) if (lbjs_component_0faf1e9b49a8ee0850c4_owners[i].key) {
    status = lbjs_component_0faf1e9b49a8ee0850c4_release(lbjs_component_0faf1e9b49a8ee0850c4_owners[i].key); if (status) return status;
  }
  status = lb_owned_context_close(&lbjs_component_0faf1e9b49a8ee0850c4_context);
  if (!status) { lbjs_component_0faf1e9b49a8ee0850c4_closed = 1; lean_bridge_native_component_detach("owned-checked-records@1.0.0"); }
  return status;
}
unsigned lbjs_component_0faf1e9b49a8ee0850c4_live(void) { return lbjs_component_0faf1e9b49a8ee0850c4_live_allocations; }
unsigned lbjs_component_0faf1e9b49a8ee0850c4_results(void) {
  unsigned count = 0;
  for (size_t i = 0; i < 4096; ++i) if (lbjs_component_0faf1e9b49a8ee0850c4_owners[i].key) ++count;
  return count;
}
typedef struct {
  uint32_t version, bytes, status, operation;
  uint32_t arguments[8];
  uint64_t token;
  uint32_t value, reserved;
} lbjs_component_0faf1e9b49a8ee0850c4_control_frame;
_Static_assert(sizeof(lbjs_component_0faf1e9b49a8ee0850c4_control_frame) == 64, "owned JS control size");
_Static_assert(_Alignof(lbjs_component_0faf1e9b49a8ee0850c4_control_frame) == 8, "owned JS control alignment");
_Static_assert(offsetof(lbjs_component_0faf1e9b49a8ee0850c4_control_frame, status) == 8, "owned JS trampoline status");
_Static_assert(offsetof(lbjs_component_0faf1e9b49a8ee0850c4_control_frame, token) == 48, "owned JS control token");
_Static_assert(offsetof(lbjs_component_0faf1e9b49a8ee0850c4_control_frame, value) == 56, "owned JS control result");
static const uint32_t lbjs_component_0faf1e9b49a8ee0850c4_metadata[8] = {
  UINT32_C(0x6d6fb55e), UINT32_C(0xf63be5e0), UINT32_C(0x9879e8fb), UINT32_C(0xbcc03b2a), UINT32_C(0x7a717ca1), UINT32_C(0x77569348), UINT32_C(0x476456c9), UINT32_C(0x924db673)
};
unsigned lbjs_component_0faf1e9b49a8ee0850c4_control(lbjs_component_0faf1e9b49a8ee0850c4_control_frame *frame) {
  if (!ov_pointer(frame, sizeof(*frame), _Alignof(lbjs_component_0faf1e9b49a8ee0850c4_control_frame))) return LB_OWNED_INVALID;
  if (frame->version != 1 || frame->bytes != sizeof(*frame) || frame->status
      || frame->value || frame->reserved) return frame->status = LB_OWNED_INVALID;
  const uint32_t *a = frame->arguments; int status = 0;
  switch (frame->operation) {
  case 0: status = lbjs_component_0faf1e9b49a8ee0850c4_init(); break;
  case 1: frame->value = lbjs_component_0faf1e9b49a8ee0850c4_open(); break;
  case 2: frame->value = lbjs_component_0faf1e9b49a8ee0850c4_valid(a[0]); break;
  case 3: status = lbjs_component_0faf1e9b49a8ee0850c4_release(a[0]); break;
  case 4: frame->value = lbjs_component_0faf1e9b49a8ee0850c4_claim(a[0], (const void *)a[1], a[2]); break;
  case 5: frame->value = lbjs_component_0faf1e9b49a8ee0850c4_identity(a[0], a[1], frame->token); break;
  case 6: status = lbjs_component_0faf1e9b49a8ee0850c4_dispatch(a[0], (const uintptr_t *)a[1], (void *)a[2], a[3]); break;
  case 7: status = lbjs_component_0faf1e9b49a8ee0850c4_retain(a[0], frame->token, (void *)a[1], a[2]); break;
  case 8: status = lbjs_component_0faf1e9b49a8ee0850c4_close(); break;
  case 9: frame->value = lbjs_component_0faf1e9b49a8ee0850c4_live(); break;
  case 10: frame->value = lbjs_component_0faf1e9b49a8ee0850c4_results(); break;
  case 15:
    if (a[0] >= 8) status = LB_OWNED_INVALID;
    else frame->value = lbjs_component_0faf1e9b49a8ee0850c4_metadata[a[0]];
    break;
  case 11: status = lbjs_0faf1e9b49a8ee0850c4_begin(a[0], a[1], (const void *)a[2], (void *)a[3], a[4]); break;
  case 12: status = lbjs_0faf1e9b49a8ee0850c4_end(a[0]); break;
  case 13: frame->value = lbjs_0faf1e9b49a8ee0850c4_valid(a[0], a[1], a[2], a[3], (const uintptr_t *)a[4], (void *)a[5]); break;
  case 14: frame->value = lbjs_0faf1e9b49a8ee0850c4_live(); break;
  default: status = LB_OWNED_INVALID;
  }
  return frame->status = (uint32_t)status;
}
