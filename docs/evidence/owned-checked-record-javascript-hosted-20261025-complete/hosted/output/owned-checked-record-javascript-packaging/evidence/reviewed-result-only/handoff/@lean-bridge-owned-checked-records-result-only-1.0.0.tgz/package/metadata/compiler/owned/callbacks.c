#include "component.h"
#include "lean_bridge_native_runtime.h"
static _Thread_local int lean_bridge_owned_callback_failure_0faf1e9b49a8ee0850c4_state;
int lean_bridge_owned_callback_failure_0faf1e9b49a8ee0850c4(void) { int result = lean_bridge_owned_callback_failure_0faf1e9b49a8ee0850c4_state; lean_bridge_owned_callback_failure_0faf1e9b49a8ee0850c4_state = 0; return result; }
