declare const leanResource: unique symbol;

export interface LeanLease {
  readonly disposed: boolean;
  dispose(): boolean;
  retain(): this;
}

/** Independent owned checked-record contract. */
export interface ClaimInput {
  readonly "holder": Ticket;
  readonly "quota": bigint;
}

export interface Claim {
  readonly "holder": Ticket;
  readonly "quota": bigint;
}

/** Independent owned checked-record contract. */
export interface Ticket extends LeanLease {
  readonly [leanResource]: "lean:OwnedCheckedRecords.Ticket";
}

/** Independent corpus contract. */
export function claimFor(arg0: Ticket): (Readonly<{ tag: "none" }> | Readonly<{ tag: "some"; value: Claim }>);

/** Independent corpus contract. */
export function newTicket(arg0: bigint, arg1: string): Ticket;

/** Independent corpus contract. */
export function serial(arg0: Ticket): bigint;

/** Release this component and invalidate its outstanding leases. */
export function close(): boolean;
/** Supply the typed fallback required by an uninhabited callback result. */
export function withRecovery<Args extends readonly unknown[], Result>(operation: (...args: Args) => Result, recovery: Result): (...args: Args) => Result;

declare const bindings: Readonly<{
  claimFor: typeof claimFor;
  newTicket: typeof newTicket;
  serial: typeof serial;
  close: typeof close;
  withRecovery: typeof withRecovery;
}>;
export default bindings;
