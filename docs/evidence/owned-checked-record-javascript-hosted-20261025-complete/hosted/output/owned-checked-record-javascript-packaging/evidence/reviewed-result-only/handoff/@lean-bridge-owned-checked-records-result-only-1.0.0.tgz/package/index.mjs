// Generated from Binding IR SHA-256 0faf1e9b49a8ee0850c439e58fbd9b71512bc6c0369f02dca6c46c5ba630909f.
import { runtime } from "./internal/runtime.mjs";

/** Independent corpus contract. */
export function claimFor(arg0) {
  return runtime.call("lean:OwnedCheckedRecords.claimFor", Array.from(arguments));
}

/** Independent corpus contract. */
export function newTicket(arg0, arg1) {
  return runtime.call("lean:OwnedCheckedRecords.newTicket", Array.from(arguments));
}

/** Independent corpus contract. */
export function serial(arg0) {
  return runtime.call("lean:OwnedCheckedRecords.serial", Array.from(arguments));
}

export function close() { return runtime.close(); }
export function withRecovery(operation, recovery) { return runtime.withRecovery(operation, recovery); }
export default Object.freeze({ claimFor, newTicket, serial, close, withRecovery });
