declare const leanResource: unique symbol;

export interface LeanLease {
  readonly disposed: boolean;
  dispose(): boolean;
  retain(): this;
}

/** Independent owned checked-record contract. */
export interface Callback26621c40b48fce52ca37 {
  (arg0: Claim): ClaimInput;
}

export interface Callback26621c40b48fce52ca37Lease extends LeanLease {
  (arg0: ClaimInput): Claim;
}

/** Independent owned checked-record contract. */
export interface Callbackb2d3d6fd4e031785f278 {
  (arg0: Claim): ClaimInput;
}

export interface Callbackb2d3d6fd4e031785f278Lease extends LeanLease {
  (arg0: ClaimInput): Claim;
}

/** Independent owned checked-record contract. */
export interface BookingInput {
  readonly "holder": Ticket;
  readonly "window": WindowInput;
}

export interface Booking {
  readonly "holder": Ticket;
  readonly "window": Window;
}

/** Independent owned checked-record contract. */
export interface ClaimInput {
  readonly "holder": Ticket;
  readonly "quota": bigint;
}

export interface Claim {
  readonly "holder": Ticket;
  readonly "quota": bigint;
}

/** Independent owned checked-record contract. */
export interface Ticket extends LeanLease {
  readonly [leanResource]: "lean:OwnedCheckedRecords.Ticket";
}

/** Independent owned checked-record contract. */
export interface WindowInput {
  readonly "lo": bigint;
  readonly "hi": bigint;
}

export interface Window {
  readonly "lo": bigint;
  readonly "hi": bigint;
}

/** Independent corpus contract. */
export function claimClosure(): Callback26621c40b48fce52ca37Lease;

/** Independent corpus contract. */
export function claimFor(arg0: Ticket): (Readonly<{ tag: "none" }> | Readonly<{ tag: "some"; value: Claim }>);

/** Independent corpus contract. */
export function echoBooking(arg0: BookingInput): Booking;

/** Independent corpus contract. */
export function echoClaim(arg0: ClaimInput): Claim;

/** Independent corpus contract. */
export function newTicket(arg0: bigint, arg1: string): Ticket;

/** Independent corpus contract. */
export function pairClaim(arg0: BookingInput, arg1: ClaimInput): Claim;

/** Independent corpus contract. */
export function serial(arg0: Ticket): bigint;

/** Independent corpus contract. */
export function transferClaim(arg0: Claim): Claim;

/** Independent corpus contract. */
export function withClaimCallback(arg0: ClaimInput, arg1: Callbackb2d3d6fd4e031785f278): Claim;

/** Release this component and invalidate its outstanding leases. */
export function close(): boolean;
/** Supply the typed fallback required by an uninhabited callback result. */
export function withRecovery<Args extends readonly unknown[], Result>(operation: (...args: Args) => Result, recovery: Result): (...args: Args) => Result;

declare const bindings: Readonly<{
  claimClosure: typeof claimClosure;
  claimFor: typeof claimFor;
  echoBooking: typeof echoBooking;
  echoClaim: typeof echoClaim;
  newTicket: typeof newTicket;
  pairClaim: typeof pairClaim;
  serial: typeof serial;
  transferClaim: typeof transferClaim;
  withClaimCallback: typeof withClaimCallback;
  close: typeof close;
  withRecovery: typeof withRecovery;
}>;
export default bindings;
