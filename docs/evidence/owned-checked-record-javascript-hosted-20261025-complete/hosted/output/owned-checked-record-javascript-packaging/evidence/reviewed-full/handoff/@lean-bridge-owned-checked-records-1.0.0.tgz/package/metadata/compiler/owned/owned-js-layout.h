#pragma once
#include "owned-values.h"
_Static_assert(sizeof(void *) == 4 && sizeof(size_t) == 4, "Owned JavaScript requires wasm32");
#ifndef __wasm32__
#error "Owned JavaScript requires the wasm32 target"
#endif
_Static_assert(sizeof(lbov_012dff3b5d57224f2883_t160ce821a84f6887bbfd) == 8, "Owned JavaScript size: 0");
_Static_assert(_Alignof(lbov_012dff3b5d57224f2883_t160ce821a84f6887bbfd) == 4, "Owned JavaScript alignment: 0");
_Static_assert(offsetof(lbov_012dff3b5d57224f2883_t160ce821a84f6887bbfd, tag) == 0, "Owned JavaScript field: 0.tag");
_Static_assert(sizeof(((lbov_012dff3b5d57224f2883_t160ce821a84f6887bbfd *)0)->tag) == 1, "Owned JavaScript member size: 0.tag");
_Static_assert(offsetof(lbov_012dff3b5d57224f2883_t160ce821a84f6887bbfd, f0) == 4, "Owned JavaScript field: 0.f0");
_Static_assert(sizeof(((lbov_012dff3b5d57224f2883_t160ce821a84f6887bbfd *)0)->f0) == 4, "Owned JavaScript member size: 0.f0");
_Static_assert(sizeof(lbov_012dff3b5d57224f2883_t648974cffb2d6c1d7951) == 8, "Owned JavaScript size: 1");
_Static_assert(_Alignof(lbov_012dff3b5d57224f2883_t648974cffb2d6c1d7951) == 8, "Owned JavaScript alignment: 1");
_Static_assert(offsetof(lbov_012dff3b5d57224f2883_t648974cffb2d6c1d7951, token) == 0, "Owned JavaScript field: 1.token");
_Static_assert(sizeof(((lbov_012dff3b5d57224f2883_t648974cffb2d6c1d7951 *)0)->token) == 8, "Owned JavaScript member size: 1.token");
_Static_assert(sizeof(lbov_012dff3b5d57224f2883_t5035e6ea0903f12776d9) == 8, "Owned JavaScript size: 2");
_Static_assert(_Alignof(lbov_012dff3b5d57224f2883_t5035e6ea0903f12776d9) == 8, "Owned JavaScript alignment: 2");
_Static_assert(offsetof(lbov_012dff3b5d57224f2883_t5035e6ea0903f12776d9, token) == 0, "Owned JavaScript field: 2.token");
_Static_assert(sizeof(((lbov_012dff3b5d57224f2883_t5035e6ea0903f12776d9 *)0)->token) == 8, "Owned JavaScript member size: 2.token");
_Static_assert(sizeof(lbov_012dff3b5d57224f2883_t23107461f72b24c37654) == 16, "Owned JavaScript size: 3");
_Static_assert(_Alignof(lbov_012dff3b5d57224f2883_t23107461f72b24c37654) == 8, "Owned JavaScript alignment: 3");
_Static_assert(offsetof(lbov_012dff3b5d57224f2883_t23107461f72b24c37654, f0) == 0, "Owned JavaScript field: 3.f0");
_Static_assert(sizeof(((lbov_012dff3b5d57224f2883_t23107461f72b24c37654 *)0)->f0) == 8, "Owned JavaScript member size: 3.f0");
_Static_assert(offsetof(lbov_012dff3b5d57224f2883_t23107461f72b24c37654, f1) == 8, "Owned JavaScript field: 3.f1");
_Static_assert(sizeof(((lbov_012dff3b5d57224f2883_t23107461f72b24c37654 *)0)->f1) == 4, "Owned JavaScript member size: 3.f1");
_Static_assert(sizeof(lbov_012dff3b5d57224f2883_tb2825946e038e653bd2b) == 16, "Owned JavaScript size: 4");
_Static_assert(_Alignof(lbov_012dff3b5d57224f2883_tb2825946e038e653bd2b) == 8, "Owned JavaScript alignment: 4");
_Static_assert(offsetof(lbov_012dff3b5d57224f2883_tb2825946e038e653bd2b, f0) == 0, "Owned JavaScript field: 4.f0");
_Static_assert(sizeof(((lbov_012dff3b5d57224f2883_tb2825946e038e653bd2b *)0)->f0) == 8, "Owned JavaScript member size: 4.f0");
_Static_assert(offsetof(lbov_012dff3b5d57224f2883_tb2825946e038e653bd2b, f1) == 8, "Owned JavaScript field: 4.f1");
_Static_assert(sizeof(((lbov_012dff3b5d57224f2883_tb2825946e038e653bd2b *)0)->f1) == 8, "Owned JavaScript member size: 4.f1");
_Static_assert(sizeof(lbov_012dff3b5d57224f2883_td79b9bbde250ee1779da) == 8, "Owned JavaScript size: 5");
_Static_assert(_Alignof(lbov_012dff3b5d57224f2883_td79b9bbde250ee1779da) == 8, "Owned JavaScript alignment: 5");
_Static_assert(offsetof(lbov_012dff3b5d57224f2883_td79b9bbde250ee1779da, token) == 0, "Owned JavaScript field: 5.token");
_Static_assert(sizeof(((lbov_012dff3b5d57224f2883_td79b9bbde250ee1779da *)0)->token) == 8, "Owned JavaScript member size: 5.token");
_Static_assert(sizeof(lbov_012dff3b5d57224f2883_t2a091437b2d587ce3891) == 16, "Owned JavaScript size: 6");
_Static_assert(_Alignof(lbov_012dff3b5d57224f2883_t2a091437b2d587ce3891) == 4, "Owned JavaScript alignment: 6");
_Static_assert(offsetof(lbov_012dff3b5d57224f2883_t2a091437b2d587ce3891, f0) == 0, "Owned JavaScript field: 6.f0");
_Static_assert(sizeof(((lbov_012dff3b5d57224f2883_t2a091437b2d587ce3891 *)0)->f0) == 8, "Owned JavaScript member size: 6.f0");
_Static_assert(offsetof(lbov_012dff3b5d57224f2883_t2a091437b2d587ce3891, f1) == 8, "Owned JavaScript field: 6.f1");
_Static_assert(sizeof(((lbov_012dff3b5d57224f2883_t2a091437b2d587ce3891 *)0)->f1) == 8, "Owned JavaScript member size: 6.f1");
_Static_assert(sizeof(lbov_012dff3b5d57224f2883_t167081552b6f9c1d1afd) == 8, "Owned JavaScript size: 7");
_Static_assert(_Alignof(lbov_012dff3b5d57224f2883_t167081552b6f9c1d1afd) == 4, "Owned JavaScript alignment: 7");
_Static_assert(offsetof(lbov_012dff3b5d57224f2883_t167081552b6f9c1d1afd, data) == 0, "Owned JavaScript field: 7.data");
_Static_assert(sizeof(((lbov_012dff3b5d57224f2883_t167081552b6f9c1d1afd *)0)->data) == 4, "Owned JavaScript member size: 7.data");
_Static_assert(offsetof(lbov_012dff3b5d57224f2883_t167081552b6f9c1d1afd, length) == 4, "Owned JavaScript field: 7.length");
_Static_assert(sizeof(((lbov_012dff3b5d57224f2883_t167081552b6f9c1d1afd *)0)->length) == 4, "Owned JavaScript member size: 7.length");
_Static_assert(sizeof(lbov_012dff3b5d57224f2883_tdc0347e1f7f5c4d928f1) == 8, "Owned JavaScript size: 8");
_Static_assert(_Alignof(lbov_012dff3b5d57224f2883_tdc0347e1f7f5c4d928f1) == 4, "Owned JavaScript alignment: 8");
_Static_assert(offsetof(lbov_012dff3b5d57224f2883_tdc0347e1f7f5c4d928f1, data) == 0, "Owned JavaScript field: 8.data");
_Static_assert(sizeof(((lbov_012dff3b5d57224f2883_tdc0347e1f7f5c4d928f1 *)0)->data) == 4, "Owned JavaScript member size: 8.data");
_Static_assert(offsetof(lbov_012dff3b5d57224f2883_tdc0347e1f7f5c4d928f1, length) == 4, "Owned JavaScript field: 8.length");
_Static_assert(sizeof(((lbov_012dff3b5d57224f2883_tdc0347e1f7f5c4d928f1 *)0)->length) == 4, "Owned JavaScript member size: 8.length");
