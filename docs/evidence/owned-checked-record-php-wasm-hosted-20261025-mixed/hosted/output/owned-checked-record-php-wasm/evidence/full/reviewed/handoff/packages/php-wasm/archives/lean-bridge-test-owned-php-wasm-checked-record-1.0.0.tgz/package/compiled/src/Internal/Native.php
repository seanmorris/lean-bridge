<?php
declare(strict_types=1);
namespace LeanBridge\CopiedPhpWasmV1 {
if (!class_exists(Loader::class, false)) {
    final class Loader {
        private static ?string $failure = null;
        private static bool $loading = false;
        private static int $callbacks = 0;
        public static function enterCallback(): void { ++self::$callbacks; }
        public static function leaveCallback(): void { --self::$callbacks; }
        public static function load(string $library, string $function): void {
            if (self::$failure !== null) throw new \RuntimeException(self::$failure);
            if (self::$loading) throw new \RuntimeException('Reentrant PHP-Wasm extension loading is not supported');
            // dl may suspend the host to fetch or instantiate a side module.
            // The synchronous Lean stack cannot participate in that unwind.
            if (self::$callbacks !== 0) throw new \RuntimeException('Cannot load a PHP-Wasm extension inside a synchronous Lean callback. Use its startup descriptor or call that package before entering the callback.');
            $registration = '/__lean_bridge/php_wasm_lazy/' . $library . '.txt';
            if (!is_file($registration) || file_get_contents($registration) !== $library) {
                throw new \RuntimeException('Register this package lazy descriptor in dynamicLibs before PHP starts');
            }
            if (!function_exists('dl') || !ini_get('enable_dl')) {
                throw new \RuntimeException('PHP-Wasm lazy loading requires enable_dl=1');
            }
            self::$loading = true;
            try {
                set_error_handler(static function (int $severity, string $message): never {
                    throw new \RuntimeException($message);
                });
                try {
                    if (!dl($library) || !function_exists($function)) {
                        throw new \RuntimeException('The generated Zend transport did not load');
                    }
                } finally { restore_error_handler(); }
            } catch (\Throwable $error) {
                // Emscripten may retain a partially linked DSO after failure.
                // Do not attempt another lazy load in that PHP instance.
                self::$failure = 'PHP-Wasm extension loading failed; create a new PHP instance. ' . $error->getMessage();
                throw new \RuntimeException(self::$failure, 0, $error);
            } finally { self::$loading = false; }
        }
    }
}
}

namespace LeanOwnedCheckedRecords\Internal {
require_once __DIR__ . '/Wire.php';

final class ZendBinding implements ResourceBinding
{
    public function __construct(private int $type, private mixed $resource) { $this->check(); }
    public function check(): void {
        if (!isset($this->type) || !is_resource($this->resource)) throw new \TypeError('Expected an initialized Zend identity');
        Native::identity('check', $this->type, $this->resource);
    }
    public function close(): void { Native::identity('close', $this->type, $this->resource); }
    public function retain(): ResourceBinding {
        $this->check(); return new self($this->type, Native::identity('retain', $this->type, $this->resource));
    }
    public function wire(int $type): mixed {
        if ($type !== $this->type) throw new \TypeError('Wrong nominal Zend identity');
        $this->check(); return $this->resource;
    }
    public function invoke(array $arguments): mixed {
        $this->check();
        return Native::invoke($this->type, ResourceAccess::wrap(GraphTypes::NODES[$this->type]['classes'][0], $this), $arguments);
    }
    // The Zend resource destructor handles implicit release, including in a
    // Fiber. A PHP destructor must not turn that into an explicit native call.
    private function __clone() {}
    public function __serialize(): array { throw new \LogicException('Zend identities cannot be serialized'); }
    public function __unserialize(array $data): void { throw new \LogicException('Zend identities cannot be deserialized'); }
}

final class ZendFrame
{
    public bool $active = true;
    public ?\Throwable $failure = null;
    public readonly GraphBudget $validation;
    public readonly GraphBudget $writing;
    public readonly GraphBudget $reading;
    private static ?\Closure $validate = null;
    public function __construct() {
        $this->validation = new GraphBudget(); $this->writing = new GraphBudget(); $this->reading = new GraphBudget();
    }
    public function check(int $type, mixed $value): void {
        self::$validate ??= \Closure::bind(static function($type, $value, $budget): void {
            foreach (Values::walk($value, $type, $budget) as $_) {}
        }, null, Values::class);
        (self::$validate)($type, $value, $this->validation);
    }
}

final class Native
{
    private const TRANSPORT = 'LeanOwnedCheckedRecords\\Internal\\OwnedZend18a969bc20cf2821667f';
    private const LIBRARY = 'php8.4-lb_owned_18a969bc20cf2821667f.so';
    private const FUNCTIONS = [['entry' => 'call0', 'parameters' => [4], 'host' => [false], 'result' => 9], ['entry' => 'call1', 'parameters' => [], 'host' => [], 'result' => 2], ['entry' => 'call2', 'parameters' => [7], 'host' => [false], 'result' => 1], ['entry' => 'call3', 'parameters' => [5], 'host' => [false], 'result' => 9], ['entry' => 'call4', 'parameters' => [4], 'host' => [false], 'result' => 4], ['entry' => 'call5', 'parameters' => [5], 'host' => [false], 'result' => 5], ['entry' => 'call6', 'parameters' => [0], 'host' => [false], 'result' => 0], ['entry' => 'call7', 'parameters' => [6], 'host' => [false], 'result' => 6], ['entry' => 'call8', 'parameters' => [9, 10], 'host' => [false, false], 'result' => 7], ['entry' => 'call9', 'parameters' => [4, 5], 'host' => [false, false], 'result' => 5], ['entry' => 'call10', 'parameters' => [7], 'host' => [false], 'result' => 9], ['entry' => 'call11', 'parameters' => [5], 'host' => [false], 'result' => 5], ['entry' => 'call12', 'parameters' => [4, 5], 'host' => [false, false], 'result' => 5], ['entry' => 'call13', 'parameters' => [5, 3], 'host' => [false, true], 'result' => 5], ['entry' => 'call14', 'parameters' => [5, 3], 'host' => [false, true], 'result' => 5]];
    private const CALLBACKS = ['2' => ['entry' => 'invoke0', 'parameters' => [2, 5], 'host' => [false, false], 'result' => 5, 'automaticRecovery' => true], '3' => ['entry' => 'invoke1', 'parameters' => [3, 5], 'host' => [false, false], 'result' => 5, 'automaticRecovery' => true]];
    private static int $depth = 0;
    private static function main(): void {
        if (\Fiber::getCurrent() !== null) throw new \LeanOwnedCheckedRecords\LeanBridgeError('Lean calls require the main PHP execution context', 5);
    }
    private static function symbol(string $entry): string {
        $symbol = self::TRANSPORT . '\\' . $entry;
        if (!function_exists($symbol)) {
            try { \LeanBridge\CopiedPhpWasmV1\Loader::load(self::LIBRARY, $symbol); }
            catch (\Throwable $error) { throw new \LeanOwnedCheckedRecords\LeanBridgeError($error->getMessage(), 7, $error); }
        }
        return $symbol;
    }
    public static function identity(string $entry, int $type, mixed $resource): mixed {
        self::main();
        if (!in_array($entry, ['check', 'close', 'retain'], true)) throw new \TypeError('Unknown identity operation');
        $symbol = self::symbol($entry);
        try { return $symbol($type, $resource); }
        catch (\Exception $error) { throw new \LeanOwnedCheckedRecords\LeanBridgeError($error->getMessage(), $error->getCode(), $error); }
    }
    private static function malformed(GraphInvalidWire $error): never {
        $retire = self::symbol('retire'); $retire();
        throw new \LeanOwnedCheckedRecords\LeanBridgeError($error->getMessage(), 9, $error);
    }
    private static function decode(int $type, mixed $value, ZendFrame $frame): mixed {
        try { return GraphWire::transfer($type, $value, true, $frame->reading); }
        catch (GraphInvalidWire $error) { self::malformed($error); }
    }
    private static function callback(mixed $value, int $arity): \Closure {
        if (!is_callable($value)) throw new \TypeError('Expected a synchronous PHP callable or generated Lean closure');
        $callback = \Closure::fromCallable($value); $reflection = new \ReflectionFunction($callback);
        if ($reflection->isGenerator() || $reflection->returnsReference()) throw new \TypeError('Callbacks cannot yield or return references');
        foreach ($reflection->getParameters() as $parameter)
            if ($parameter->isPassedByReference()) throw new \TypeError('Callback arguments cannot be references');
        if ($reflection->getNumberOfRequiredParameters() > $arity
            || (!$reflection->isVariadic() && $reflection->getNumberOfParameters() < $arity))
            throw new \ArgumentCountError('PHP callable does not accept the declared Lean callback arity');
        return $callback;
    }
    private static function prepare(int $type, mixed $value, ZendFrame $frame): array {
        $signature = self::CALLBACKS[$type];
        $explicit = $value instanceof \LeanOwnedCheckedRecords\WithRecovery;
        $fallback = $explicit ? $value->value : null; $value = $explicit ? $value->callback : $value;
        if ($value instanceof Resource) {
            if ($explicit) throw new \TypeError('A returned Lean closure does not accept a PHP recovery wrapper');
            $frame->check($type, $value); return ['closure' => $value];
        }
        if (!$explicit && !$signature['automaticRecovery']) throw new \TypeError('This callback requires with_recovery and a typed result value');
        $callback = self::callback($value, count($signature['parameters']) - 1);
        if ($explicit) $frame->check($signature['result'], $fallback);
        return ['call' => $callback, 'explicit' => $explicit, 'fallback' => $fallback];
    }
    private static function host(int $type, array $prepared, ZendFrame $frame): mixed {
        if (isset($prepared['closure'])) return GraphWire::transfer($type, $prepared['closure'], false, $frame->writing);
        $signature = self::CALLBACKS[$type]; $callback = $prepared['call'];
        $parameters = array_slice($signature['parameters'], 1);
        $invoke = static function(mixed ...$wire) use ($frame, $callback, $signature, $parameters): mixed {
            if (!$frame->active) throw new \LogicException('Lean callback has expired');
            if ($frame->failure !== null) throw $frame->failure;
            \LeanBridge\CopiedPhpWasmV1\Loader::enterCallback();
            try {
                if (count($wire) !== count($parameters)) throw new GraphInvalidWire('Wrong native callback arity');
                $arguments = [];
                foreach ($parameters as $index => $type) $arguments[] = self::decode($type, $wire[$index], $frame);
                $reply = $callback(...$arguments);
                $frame->check($signature['result'], $reply);
                return GraphWire::transfer($signature['result'], $reply, false, $frame->writing);
            } catch (GraphInvalidWire $error) {
                try { self::malformed($error); }
                catch (\Throwable $failure) { $frame->failure ??= $failure; throw $failure; }
            } catch (\Throwable $error) { $frame->failure ??= $error; throw $error; }
            finally { \LeanBridge\CopiedPhpWasmV1\Loader::leaveCallback(); }
        };
        $fallback = $prepared['explicit'] ? GraphWire::transfer($signature['result'], $prepared['fallback'], false, $frame->writing) : null;
        return [$invoke, $prepared['explicit'], $fallback];
    }
    private static function execute(array $fn, array $arguments): mixed {
        self::main();
        if (!array_is_list($arguments) || count($arguments) !== count($fn['parameters'])) throw new \ArgumentCountError('Wrong Lean call arity');
        if (self::$depth >= 64) throw new \OverflowException('Lean calls exceed 64 reentry levels');
        $frame = new ZendFrame(); $prepared = [];
        // Validate every ordinary argument and recovery value before loading
        // the extension or allocating any native identity.
        foreach ($fn['parameters'] as $index => $type) {
            if ($fn['host'][$index]) $prepared[$index] = self::prepare($type, $arguments[$index], $frame);
            else $frame->check($type, $arguments[$index]);
        }
        ++self::$depth;
        try {
            $inputs = [];
            foreach ($fn['parameters'] as $index => $type)
                $inputs[] = $fn['host'][$index] ? self::host($type, $prepared[$index], $frame)
                    : GraphWire::transfer($type, $arguments[$index], false, $frame->writing);
            $symbol = self::symbol($fn['entry']);
            try { $wire = $symbol(...$inputs); }
            catch (\Throwable $error) {
                if ($frame->failure !== null) throw $frame->failure;
                if ($error instanceof \Exception) throw new \LeanOwnedCheckedRecords\LeanBridgeError($error->getMessage(), $error->getCode(), $error);
                throw $error;
            }
            if ($frame->failure !== null) throw $frame->failure;
            return self::decode($fn['result'], $wire, $frame);
        } finally { $frame->active = false; --self::$depth; }
    }
    public static function call(int $index, array $arguments): mixed {
        return self::execute(self::FUNCTIONS[$index] ?? throw new \TypeError('Unknown Lean export'), $arguments);
    }
    public static function invoke(int $type, Resource $closure, array $arguments): mixed {
        if (!array_is_list($arguments)) throw new \ArgumentCountError('Lean closure requires positional arguments');
        return self::execute(self::CALLBACKS[$type] ?? throw new \TypeError('Resource is not a Lean closure'), [$closure, ...$arguments]);
    }
    public static function close(): void {
        self::main();
        if (self::$depth !== 0) throw new \LogicException('Cannot close the runtime during a Lean call');
        $close = self::symbol('shutdown'); $close();
    }
}

}
