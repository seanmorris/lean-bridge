import { createPhpWasmCopiedDescriptor } from './host.mjs';
const runtime = Object.freeze({"identity":"44535fd7b0e510b50f3aae5e2134970012d90e9f6be04048a04dce85bddbd966","loaderIdentity":"4ee1bddd55b230a6e5c8aa2ea4339e146546f332ff9e3760614c8efeba289cd9","library":"liblean_bridge_php_wasm_copied_abe4dea500dab9519b8d.so"});
export const createDescriptor = (component, assets) => createPhpWasmCopiedDescriptor({ ...runtime, url: new URL("./compiled/lib/liblean_bridge_php_wasm_copied_abe4dea500dab9519b8d.so", import.meta.url) }, component, assets);
