import RecursiveSubtypes
set_option maxRecDepth 10000
namespace LeanBridgeNative597c05ce6432c0d3
inductive LbErased.RecursiveSubtypes.Chain where
  | «empty»  : LbErased.RecursiveSubtypes.Chain
  | «node» (a0 : _root_.Nat) (a1 : _root_.Nat) (a2 : LbErased.RecursiveSubtypes.Chain) : LbErased.RecursiveSubtypes.Chain

def LbErased.RecursiveSubtypes.Chain.via_2cb331aa51ddb668a8dff8336edd9916ab7be0f0ecaed898ae8a3eb5d32f1e81 (value : LbErased.RecursiveSubtypes.Chain) : _root_.Option _root_.RecursiveSubtypes.Chain :=
  match value with
  | .«empty»  => do pure (_root_.RecursiveSubtypes.Chain.empty )
  | .«node» a0 a1 a2 => do let b0 ← _root_.RecursiveSubtypes.plusOne a0; let b1 ← (if proof : (a1) < 3 then _root_.Option.some (⟨(a1), proof⟩ : _root_.Fin 3) else _root_.Option.none); let b2 ← (LbErased.RecursiveSubtypes.Chain.via_2cb331aa51ddb668a8dff8336edd9916ab7be0f0ecaed898ae8a3eb5d32f1e81 (a2)); pure (_root_.RecursiveSubtypes.Chain.node b0 b1 b2)

def LbErased.RecursiveSubtypes.Chain.via_b0a9989b03a240ff1df500f95717b8fa3424b6f89cf1f6bdd2410fb902067a89 (value : LbErased.RecursiveSubtypes.Chain) : _root_.Option _root_.RecursiveSubtypes.Chain :=
  match value with
  | .«empty»  => do pure (_root_.RecursiveSubtypes.Chain.empty )
  | .«node» a0 a1 a2 => do let b0 ← _root_.RecursiveSubtypes.plusTwo a0; let b1 ← (if proof : (a1) < 3 then _root_.Option.some (⟨(a1), proof⟩ : _root_.Fin 3) else _root_.Option.none); let b2 ← (LbErased.RecursiveSubtypes.Chain.via_b0a9989b03a240ff1df500f95717b8fa3424b6f89cf1f6bdd2410fb902067a89 (a2)); pure (_root_.RecursiveSubtypes.Chain.node b0 b1 b2)

def LbErased.RecursiveSubtypes.Chain.erase (value : _root_.RecursiveSubtypes.Chain) : LbErased.RecursiveSubtypes.Chain :=
  match value with
  | .«empty»  => LbErased.RecursiveSubtypes.Chain.«empty» 
  | .«node» a0 a1 a2 => LbErased.RecursiveSubtypes.Chain.«node» (a0).val (a1).val (LbErased.RecursiveSubtypes.Chain.erase (a2))

def LbErased.RecursiveSubtypes.Chain.validFin (value : LbErased.RecursiveSubtypes.Chain) : _root_.Bool :=
  match value with
  | .«empty»  => true
  | .«node» _bridgeFinField0 _bridgeFinField1 _bridgeFinField2 => (decide ((_bridgeFinField1) < 3)) && (LbErased.RecursiveSubtypes.Chain.validFin (_bridgeFinField2))

def carrierValue {α : Type} (value : _root_.Array α) : _root_.Option α :=
  if bound : 0 < value.size then
    if value.size == 1 then .some (value[0]'bound) else .none
  else .none

def carrierResult {α : Type} (value : _root_.Option α) : _root_.Array α :=
  match value with | .none => #[] | .some result => #[result]

def carrierCollect {α : Type} (values : _root_.Array (_root_.Array α)) : _root_.Option (_root_.Array α) := Id.run do
  if values.size > 262144 then return .none
  let mut result := #[]
  for value in values do
    match carrierValue value with
    | .none => return .none
    | .some item => result := result.push item
  return .some result

def carrierListItems {α : Type} (values : _root_.List α) : _root_.Array (_root_.Array α) :=
  let rec loop : _root_.Nat → _root_.List α → _root_.Array (_root_.Array α) → _root_.Array (_root_.Array α)
    | 0, _, acc => acc
    | _, [], acc => acc
    | fuel + 1, head :: tail, acc => loop fuel tail (acc.push #[head])
  loop 262145 values #[]

@[export lean_bridge_890e535d855edd42581629d4_recursive_d0f96c6a61c5999d6261_branch]
def branchd0f96c6a61c5999d6261 (value : (_root_.Array LbErased.RecursiveSubtypes.Chain)) : _root_.UInt32 :=
  match carrierValue value with
  | .none => 4294967295
  | .some value =>
    match value with
    | .«empty»  => 0
    | .«node» _ _ _ => 1

@[export lean_bridge_890e535d855edd42581629d4_recursive_d0f96c6a61c5999d6261_make0]
def make0d0f96c6a61c5999d6261 (_bridgeUnit : _root_.Unit) : (_root_.Array LbErased.RecursiveSubtypes.Chain) :=
  carrierResult (do
    pure (.«empty» )
  )

@[export lean_bridge_890e535d855edd42581629d4_recursive_d0f96c6a61c5999d6261_make1]
def make1d0f96c6a61c5999d6261 (a0 : (_root_.Array _root_.Nat)) (a1 : (_root_.Array _root_.Nat)) (a2 : (_root_.Array LbErased.RecursiveSubtypes.Chain)) : (_root_.Array LbErased.RecursiveSubtypes.Chain) :=
  carrierResult (do
    let a0 ← carrierValue a0
    let a1 ← carrierValue a1
    let a2 ← carrierValue a2
    pure (.«node» a0 a1 a2)
  )

@[export lean_bridge_890e535d855edd42581629d4_recursive_d0f96c6a61c5999d6261_case1_field0]
def case1_field0d0f96c6a61c5999d6261 (value : (_root_.Array LbErased.RecursiveSubtypes.Chain)) : (_root_.Array _root_.Nat) :=
  carrierResult (do
    let value ← carrierValue value
    match value with
    | .«node» child _ _ => pure child
    | _ => .none
  )

@[export lean_bridge_890e535d855edd42581629d4_recursive_d0f96c6a61c5999d6261_case1_field1]
def case1_field1d0f96c6a61c5999d6261 (value : (_root_.Array LbErased.RecursiveSubtypes.Chain)) : (_root_.Array _root_.Nat) :=
  carrierResult (do
    let value ← carrierValue value
    match value with
    | .«node» _ child _ => pure child
    | _ => .none
  )

@[export lean_bridge_890e535d855edd42581629d4_recursive_d0f96c6a61c5999d6261_case1_field2]
def case1_field2d0f96c6a61c5999d6261 (value : (_root_.Array LbErased.RecursiveSubtypes.Chain)) : (_root_.Array LbErased.RecursiveSubtypes.Chain) :=
  carrierResult (do
    let value ← carrierValue value
    match value with
    | .«node» _ _ child => pure child
    | _ => .none
  )

@[export lean_bridge_890e535d855edd42581629d4_recursive_7150ee578fdad1fd4810_make]
def make7150ee578fdad1fd4810 (values : _root_.Array (_root_.Array (_root_.Option LbErased.RecursiveSubtypes.Chain))) : (_root_.Array (_root_.Array (_root_.Option LbErased.RecursiveSubtypes.Chain))) :=
  carrierResult (do
    let values ← carrierCollect values
    pure values
  )

@[export lean_bridge_890e535d855edd42581629d4_recursive_7150ee578fdad1fd4810_items]
def items7150ee578fdad1fd4810 (value : (_root_.Array (_root_.Array (_root_.Option LbErased.RecursiveSubtypes.Chain)))) : (_root_.Array (_root_.Array (_root_.Option LbErased.RecursiveSubtypes.Chain))) :=
  match carrierValue value with
  | .none => #[]
  | .some values => (values.extract 0 262145).map (fun child => #[child])

@[export lean_bridge_890e535d855edd42581629d4_recursive_670fab78918c40675bdb_branch]
def branch670fab78918c40675bdb (value : (_root_.Array (_root_.Option LbErased.RecursiveSubtypes.Chain))) : _root_.UInt32 :=
  match carrierValue value with
  | .none => 4294967295
  | .some value =>
    match value with
    | .none => 0
    | .some _ => 1

@[export lean_bridge_890e535d855edd42581629d4_recursive_670fab78918c40675bdb_none]
def none670fab78918c40675bdb (_bridgeUnit : _root_.Unit) : (_root_.Array (_root_.Option LbErased.RecursiveSubtypes.Chain)) :=
  carrierResult (do
    pure (.none)
  )

@[export lean_bridge_890e535d855edd42581629d4_recursive_670fab78918c40675bdb_make0]
def make0670fab78918c40675bdb (a0 : (_root_.Array LbErased.RecursiveSubtypes.Chain)) : (_root_.Array (_root_.Option LbErased.RecursiveSubtypes.Chain)) :=
  carrierResult (do
    let a0 ← carrierValue a0
    pure (.some a0)
  )

@[export lean_bridge_890e535d855edd42581629d4_recursive_670fab78918c40675bdb_field0]
def field0670fab78918c40675bdb (value : (_root_.Array (_root_.Option LbErased.RecursiveSubtypes.Chain))) : (_root_.Array LbErased.RecursiveSubtypes.Chain) :=
  carrierResult (do
    let value ← carrierValue value
    match value with
    | .some child => pure child
    | _ => .none
  )

@[export lean_bridge_890e535d855edd42581629d4_recursive_83c50e7540f0bfb759d4_make]
def make83c50e7540f0bfb759d4 (a0 : (_root_.Array LbErased.RecursiveSubtypes.Chain)) : (_root_.Array LbErased.RecursiveSubtypes.Chain) :=
  carrierResult (do
    let a0 ← carrierValue a0
    pure (a0)
  )

@[export lean_bridge_890e535d855edd42581629d4_recursive_83c50e7540f0bfb759d4_field0]
def field083c50e7540f0bfb759d4 (value : (_root_.Array LbErased.RecursiveSubtypes.Chain)) : (_root_.Array LbErased.RecursiveSubtypes.Chain) :=
  carrierResult (do
    let value ← carrierValue value
    pure value
  )

@[export lean_bridge_890e535d855edd42581629d4_fin_guard_0]
def export0_fin_guard_0 (carrier : _root_.Array LbErased.RecursiveSubtypes.Chain) : _root_.UInt8 :=
  match carrierValue carrier with
  | .none => 0
  | .some _bridgeValue =>
    if (LbErased.RecursiveSubtypes.Chain.validFin (_bridgeValue)) then 1 else 0

@[export lean_bridge_890e535d855edd42581629d4_refinement_0]
def export0_refinement_0 (carrier : _root_.Array LbErased.RecursiveSubtypes.Chain) : _root_.UInt8 :=
  match carrierValue carrier with
  | .none => 0
  | .some value =>
    if (LbErased.RecursiveSubtypes.Chain.validFin (value)) then
      match (LbErased.RecursiveSubtypes.Chain.via_2cb331aa51ddb668a8dff8336edd9916ab7be0f0ecaed898ae8a3eb5d32f1e81 (value)) with
      | .some _ => 1
      | .none => 0
    else 0

@[export lean_bridge_890e535d855edd42581629d4_graph_refinement_0_f47f84e548df9f42ce87]
def export0_graph_refinement_0_f47f84e548df9f42ce87 (carrier : (_root_.Array _root_.Nat)) : _root_.UInt8 :=
  match carrierValue carrier with
  | .none => 0
  | .some value =>
    match _root_.RecursiveSubtypes.plusOne value with
    | .some _ => 1
    | .none => 0

@[export lean_bridge_890e535d855edd42581629d4_lean]
def export0 (a0 : (_root_.Array LbErased.RecursiveSubtypes.Chain)) : (_root_.Array LbErased.RecursiveSubtypes.Chain) :=
  carrierResult (do
    let a0 ← carrierValue a0
    if (LbErased.RecursiveSubtypes.Chain.validFin (a0)) then
      match (LbErased.RecursiveSubtypes.Chain.via_2cb331aa51ddb668a8dff8336edd9916ab7be0f0ecaed898ae8a3eb5d32f1e81 (a0)) with
      | .some _bridgeSubtype0 =>
        pure ((let _bridgeResult := _root_.RecursiveSubtypes.echo _bridgeSubtype0; (LbErased.RecursiveSubtypes.Chain.erase (_bridgeResult))))
      | .none =>
        .none
    else
      .none
  )

@[export lean_bridge_61edaca9ace2104f41ea6e59_fin_guard_0]
def export1_fin_guard_0 (carrier : _root_.Array (_root_.Array (_root_.Option LbErased.RecursiveSubtypes.Chain))) : _root_.UInt8 :=
  match carrierValue carrier with
  | .none => 0
  | .some _bridgeValue =>
    if ((_bridgeValue).all (fun _bridgeFinValue0 => (match (_bridgeFinValue0) with | _root_.Option.none => true | _root_.Option.some _bridgeFinValue1 => (LbErased.RecursiveSubtypes.Chain.validFin (_bridgeFinValue1))))) then 1 else 0

@[export lean_bridge_61edaca9ace2104f41ea6e59_refinement_0]
def export1_refinement_0 (carrier : _root_.Array (_root_.Array (_root_.Option LbErased.RecursiveSubtypes.Chain))) : _root_.UInt8 :=
  match carrierValue carrier with
  | .none => 0
  | .some value =>
    if ((value).all (fun _bridgeFinValue0 => (match (_bridgeFinValue0) with | _root_.Option.none => true | _root_.Option.some _bridgeFinValue1 => (LbErased.RecursiveSubtypes.Chain.validFin (_bridgeFinValue1))))) then
      match ((value).mapM (fun _bridgeValue0 => (match (_bridgeValue0) with | _root_.Option.none => _root_.Option.some _root_.Option.none | _root_.Option.some _bridgeValue1 => ((LbErased.RecursiveSubtypes.Chain.via_2cb331aa51ddb668a8dff8336edd9916ab7be0f0ecaed898ae8a3eb5d32f1e81 (_bridgeValue1))).map _root_.Option.some))) with
      | .some _ => 1
      | .none => 0
    else 0

@[export lean_bridge_61edaca9ace2104f41ea6e59_graph_refinement_0_f47f84e548df9f42ce87]
def export1_graph_refinement_0_f47f84e548df9f42ce87 (carrier : (_root_.Array _root_.Nat)) : _root_.UInt8 :=
  match carrierValue carrier with
  | .none => 0
  | .some value =>
    match _root_.RecursiveSubtypes.plusOne value with
    | .some _ => 1
    | .none => 0

@[export lean_bridge_61edaca9ace2104f41ea6e59_lean]
def export1 (a0 : (_root_.Array (_root_.Array (_root_.Option LbErased.RecursiveSubtypes.Chain)))) : (_root_.Array (_root_.Array (_root_.Option LbErased.RecursiveSubtypes.Chain))) :=
  carrierResult (do
    let a0 ← carrierValue a0
    if ((a0).all (fun _bridgeFinValue0 => (match (_bridgeFinValue0) with | _root_.Option.none => true | _root_.Option.some _bridgeFinValue1 => (LbErased.RecursiveSubtypes.Chain.validFin (_bridgeFinValue1))))) then
      match ((a0).mapM (fun _bridgeValue0 => (match (_bridgeValue0) with | _root_.Option.none => _root_.Option.some _root_.Option.none | _root_.Option.some _bridgeValue1 => ((LbErased.RecursiveSubtypes.Chain.via_2cb331aa51ddb668a8dff8336edd9916ab7be0f0ecaed898ae8a3eb5d32f1e81 (_bridgeValue1))).map _root_.Option.some))) with
      | .some _bridgeSubtype0 =>
        pure ((let _bridgeResult := _root_.RecursiveSubtypes.echoGroups _bridgeSubtype0; ((_bridgeResult).map (fun _bridgeValue0 => (match (_bridgeValue0) with | _root_.Option.none => _root_.Option.none | _root_.Option.some _bridgeValue1 => _root_.Option.some (LbErased.RecursiveSubtypes.Chain.erase (_bridgeValue1)))))))
      | .none =>
        .none
    else
      .none
  )

@[export lean_bridge_a9ae70188abbca81b8f235ce_fin_guard_0]
def export2_fin_guard_0 (carrier : _root_.Array LbErased.RecursiveSubtypes.Chain) : _root_.UInt8 :=
  match carrierValue carrier with
  | .none => 0
  | .some _bridgeValue =>
    if (LbErased.RecursiveSubtypes.Chain.validFin (_bridgeValue)) then 1 else 0

@[export lean_bridge_a9ae70188abbca81b8f235ce_refinement_0]
def export2_refinement_0 (carrier : _root_.Array LbErased.RecursiveSubtypes.Chain) : _root_.UInt8 :=
  match carrierValue carrier with
  | .none => 0
  | .some value =>
    if (LbErased.RecursiveSubtypes.Chain.validFin (value)) then
      match (LbErased.RecursiveSubtypes.Chain.via_2cb331aa51ddb668a8dff8336edd9916ab7be0f0ecaed898ae8a3eb5d32f1e81 (value)) with
      | .some _ => 1
      | .none => 0
    else 0

@[export lean_bridge_a9ae70188abbca81b8f235ce_graph_refinement_0_f47f84e548df9f42ce87]
def export2_graph_refinement_0_f47f84e548df9f42ce87 (carrier : (_root_.Array _root_.Nat)) : _root_.UInt8 :=
  match carrierValue carrier with
  | .none => 0
  | .some value =>
    match _root_.RecursiveSubtypes.plusOne value with
    | .some _ => 1
    | .none => 0

@[export lean_bridge_a9ae70188abbca81b8f235ce_lean]
def export2 (a0 : (_root_.Array LbErased.RecursiveSubtypes.Chain)) : (_root_.Array _root_.Nat) :=
  carrierResult (do
    let a0 ← carrierValue a0
    if (LbErased.RecursiveSubtypes.Chain.validFin (a0)) then
      match (LbErased.RecursiveSubtypes.Chain.via_2cb331aa51ddb668a8dff8336edd9916ab7be0f0ecaed898ae8a3eb5d32f1e81 (a0)) with
      | .some _bridgeSubtype0 =>
        pure (_root_.RecursiveSubtypes.first _bridgeSubtype0)
      | .none =>
        .none
    else
      .none
  )

@[export lean_bridge_5f9ebf1241c61a39ed1bdebf_fin_guard_0]
def export3_fin_guard_0 (carrier : _root_.Array (_root_.Array (_root_.Option LbErased.RecursiveSubtypes.Chain))) : _root_.UInt8 :=
  match carrierValue carrier with
  | .none => 0
  | .some _bridgeValue =>
    if ((_bridgeValue).all (fun _bridgeFinValue0 => (match (_bridgeFinValue0) with | _root_.Option.none => true | _root_.Option.some _bridgeFinValue1 => (LbErased.RecursiveSubtypes.Chain.validFin (_bridgeFinValue1))))) then 1 else 0

@[export lean_bridge_5f9ebf1241c61a39ed1bdebf_refinement_0]
def export3_refinement_0 (carrier : _root_.Array (_root_.Array (_root_.Option LbErased.RecursiveSubtypes.Chain))) : _root_.UInt8 :=
  match carrierValue carrier with
  | .none => 0
  | .some value =>
    if ((value).all (fun _bridgeFinValue0 => (match (_bridgeFinValue0) with | _root_.Option.none => true | _root_.Option.some _bridgeFinValue1 => (LbErased.RecursiveSubtypes.Chain.validFin (_bridgeFinValue1))))) then
      match ((value).mapM (fun _bridgeValue0 => (match (_bridgeValue0) with | _root_.Option.none => _root_.Option.some _root_.Option.none | _root_.Option.some _bridgeValue1 => ((LbErased.RecursiveSubtypes.Chain.via_2cb331aa51ddb668a8dff8336edd9916ab7be0f0ecaed898ae8a3eb5d32f1e81 (_bridgeValue1))).map _root_.Option.some))) with
      | .some _ => 1
      | .none => 0
    else 0

@[export lean_bridge_5f9ebf1241c61a39ed1bdebf_graph_refinement_0_f47f84e548df9f42ce87]
def export3_graph_refinement_0_f47f84e548df9f42ce87 (carrier : (_root_.Array _root_.Nat)) : _root_.UInt8 :=
  match carrierValue carrier with
  | .none => 0
  | .some value =>
    match _root_.RecursiveSubtypes.plusOne value with
    | .some _ => 1
    | .none => 0

@[export lean_bridge_5f9ebf1241c61a39ed1bdebf_lean]
def export3 (a0 : (_root_.Array (_root_.Array (_root_.Option LbErased.RecursiveSubtypes.Chain)))) : (_root_.Array _root_.Nat) :=
  carrierResult (do
    let a0 ← carrierValue a0
    if ((a0).all (fun _bridgeFinValue0 => (match (_bridgeFinValue0) with | _root_.Option.none => true | _root_.Option.some _bridgeFinValue1 => (LbErased.RecursiveSubtypes.Chain.validFin (_bridgeFinValue1))))) then
      match ((a0).mapM (fun _bridgeValue0 => (match (_bridgeValue0) with | _root_.Option.none => _root_.Option.some _root_.Option.none | _root_.Option.some _bridgeValue1 => ((LbErased.RecursiveSubtypes.Chain.via_2cb331aa51ddb668a8dff8336edd9916ab7be0f0ecaed898ae8a3eb5d32f1e81 (_bridgeValue1))).map _root_.Option.some))) with
      | .some _bridgeSubtype0 =>
        pure (_root_.RecursiveSubtypes.groups _bridgeSubtype0)
      | .none =>
        .none
    else
      .none
  )

@[export lean_bridge_cc48993941d89731cae43d8e_fin_guard_0]
def export4_fin_guard_0 (carrier : _root_.Array _root_.Nat) : _root_.UInt8 :=
  match carrierValue carrier with
  | .none => 0
  | .some _bridgeValue =>
    if true then 1 else 0

@[export lean_bridge_cc48993941d89731cae43d8e_lean]
def export4 (a0 : (_root_.Array _root_.Nat)) : (_root_.Array LbErased.RecursiveSubtypes.Chain) :=
  carrierResult (do
    let a0 ← carrierValue a0
    pure ((let _bridgeResult := _root_.RecursiveSubtypes.produce a0; (LbErased.RecursiveSubtypes.Chain.erase (_bridgeResult))))
  )

@[export lean_bridge_9e8d2cbaa99dca92eb622921_fin_guard_0]
def export5_fin_guard_0 (carrier : _root_.Array LbErased.RecursiveSubtypes.Chain) : _root_.UInt8 :=
  match carrierValue carrier with
  | .none => 0
  | .some _bridgeValue =>
    if (LbErased.RecursiveSubtypes.Chain.validFin (_bridgeValue)) then 1 else 0

@[export lean_bridge_9e8d2cbaa99dca92eb622921_refinement_0]
def export5_refinement_0 (carrier : _root_.Array LbErased.RecursiveSubtypes.Chain) : _root_.UInt8 :=
  match carrierValue carrier with
  | .none => 0
  | .some value =>
    if (LbErased.RecursiveSubtypes.Chain.validFin (value)) then
      match (LbErased.RecursiveSubtypes.Chain.via_b0a9989b03a240ff1df500f95717b8fa3424b6f89cf1f6bdd2410fb902067a89 (value)) with
      | .some _ => 1
      | .none => 0
    else 0

@[export lean_bridge_9e8d2cbaa99dca92eb622921_graph_refinement_0_053cd996a2b855a7fe90]
def export5_graph_refinement_0_053cd996a2b855a7fe90 (carrier : (_root_.Array _root_.Nat)) : _root_.UInt8 :=
  match carrierValue carrier with
  | .none => 0
  | .some value =>
    match _root_.RecursiveSubtypes.plusTwo value with
    | .some _ => 1
    | .none => 0

@[export lean_bridge_9e8d2cbaa99dca92eb622921_lean]
def export5 (a0 : (_root_.Array LbErased.RecursiveSubtypes.Chain)) : (_root_.Array _root_.Nat) :=
  carrierResult (do
    let a0 ← carrierValue a0
    if (LbErased.RecursiveSubtypes.Chain.validFin (a0)) then
      match (LbErased.RecursiveSubtypes.Chain.via_b0a9989b03a240ff1df500f95717b8fa3424b6f89cf1f6bdd2410fb902067a89 (a0)) with
      | .some _bridgeSubtype0 =>
        pure (_root_.RecursiveSubtypes.second _bridgeSubtype0)
      | .none =>
        .none
    else
      .none
  )

end LeanBridgeNative597c05ce6432c0d3
