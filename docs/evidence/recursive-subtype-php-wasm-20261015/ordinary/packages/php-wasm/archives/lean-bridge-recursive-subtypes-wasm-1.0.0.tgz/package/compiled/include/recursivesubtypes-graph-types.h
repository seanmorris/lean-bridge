#ifndef RECURSIVESUBTYPES_COPIED_GRAPH_H
#define RECURSIVESUBTYPES_COPIED_GRAPH_H
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <string.h>

typedef struct recursivesubtypes_graph_170e86bf9eebb9860794_t recursivesubtypes_graph_170e86bf9eebb9860794_t;
typedef struct recursivesubtypes_graph_69c0b33a73ddceecbd00_t recursivesubtypes_graph_69c0b33a73ddceecbd00_t;
typedef struct recursivesubtypes_chain_t recursivesubtypes_chain_t;
typedef struct recursivesubtypes_scalar_nat_t recursivesubtypes_scalar_nat_t;
struct recursivesubtypes_scalar_nat_t {
  void *_bridge_owner;
  void (*_bridge_release)(void *owner);
  const uint32_t *data;
  size_t length;
};
static inline void recursivesubtypes_scalar_nat_t_init(recursivesubtypes_scalar_nat_t *value) {
  if (!value) return;
  memset(value, 0, sizeof(*value));
}
static inline void recursivesubtypes_scalar_nat_t_clear(recursivesubtypes_scalar_nat_t *value) {
  if (!value) return;
  void *owner = value->_bridge_owner;
  void (*release)(void *) = value->_bridge_release;
  recursivesubtypes_scalar_nat_t_init(value);
  if (owner && release) release(owner);
}

typedef enum recursivesubtypes_chain_t_tag { RECURSIVESUBTYPES_CHAIN_T_KIND_EMPTY = 0, RECURSIVESUBTYPES_CHAIN_T_KIND_NODE = 1 } recursivesubtypes_chain_t_tag;
struct recursivesubtypes_chain_t {
  void *_bridge_owner;
  void (*_bridge_release)(void *owner);
  uint32_t kind;
  union {
    struct {
      uint8_t empty;
    } empty;
    struct {
      recursivesubtypes_scalar_nat_t value;
      recursivesubtypes_scalar_nat_t digit;
      const recursivesubtypes_chain_t *tail;
    } node;
  } cases;
};
static inline void recursivesubtypes_chain_t_init(recursivesubtypes_chain_t *value) {
  if (!value) return;
  memset(value, 0, sizeof(*value));
  value->kind = UINT32_MAX;
}
static inline void recursivesubtypes_chain_t_clear(recursivesubtypes_chain_t *value) {
  if (!value) return;
  void *owner = value->_bridge_owner;
  void (*release)(void *) = value->_bridge_release;
  recursivesubtypes_chain_t_init(value);
  if (owner && release) release(owner);
}

struct recursivesubtypes_graph_170e86bf9eebb9860794_t {
  void *_bridge_owner;
  void (*_bridge_release)(void *owner);
  uint8_t has_value;
  recursivesubtypes_chain_t value;
};
static inline void recursivesubtypes_graph_170e86bf9eebb9860794_t_init(recursivesubtypes_graph_170e86bf9eebb9860794_t *value) {
  if (!value) return;
  memset(value, 0, sizeof(*value));
}
static inline void recursivesubtypes_graph_170e86bf9eebb9860794_t_clear(recursivesubtypes_graph_170e86bf9eebb9860794_t *value) {
  if (!value) return;
  void *owner = value->_bridge_owner;
  void (*release)(void *) = value->_bridge_release;
  recursivesubtypes_graph_170e86bf9eebb9860794_t_init(value);
  if (owner && release) release(owner);
}

struct recursivesubtypes_graph_69c0b33a73ddceecbd00_t {
  void *_bridge_owner;
  void (*_bridge_release)(void *owner);
  const recursivesubtypes_graph_170e86bf9eebb9860794_t *data;
  size_t length;
};
static inline void recursivesubtypes_graph_69c0b33a73ddceecbd00_t_init(recursivesubtypes_graph_69c0b33a73ddceecbd00_t *value) {
  if (!value) return;
  memset(value, 0, sizeof(*value));
}
static inline void recursivesubtypes_graph_69c0b33a73ddceecbd00_t_clear(recursivesubtypes_graph_69c0b33a73ddceecbd00_t *value) {
  if (!value) return;
  void *owner = value->_bridge_owner;
  void (*release)(void *) = value->_bridge_release;
  recursivesubtypes_graph_69c0b33a73ddceecbd00_t_init(value);
  if (owner && release) release(owner);
}

typedef recursivesubtypes_chain_t recursivesubtypes_chain_alias_t;
static inline void recursivesubtypes_chain_alias_t_init(recursivesubtypes_chain_alias_t *value) { recursivesubtypes_chain_t_init(value); }
static inline void recursivesubtypes_chain_alias_t_clear(recursivesubtypes_chain_alias_t *value) { recursivesubtypes_chain_t_clear(value); }

#endif /* RECURSIVESUBTYPES_COPIED_GRAPH_H */
