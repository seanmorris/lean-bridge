#include "recursivesubtypes-graph-types.h"
uint32_t recursivesubtypes_echo_graph(const recursivesubtypes_chain_t *, recursivesubtypes_chain_t *);
uint32_t recursivesubtypes_echo_groups_graph(const recursivesubtypes_graph_69c0b33a73ddceecbd00_t *, recursivesubtypes_graph_69c0b33a73ddceecbd00_t *);
uint32_t recursivesubtypes_first_graph(const recursivesubtypes_chain_t *, recursivesubtypes_scalar_nat_t *);
uint32_t recursivesubtypes_groups_graph(const recursivesubtypes_graph_69c0b33a73ddceecbd00_t *, recursivesubtypes_scalar_nat_t *);
uint32_t recursivesubtypes_produce_graph(const recursivesubtypes_scalar_nat_t *, recursivesubtypes_chain_t *);
uint32_t recursivesubtypes_second_graph(const recursivesubtypes_chain_t *, recursivesubtypes_scalar_nat_t *);
const char *recursivesubtypes_graph_error(void);
uint32_t recursivesubtypes_graph_initialize(void);
int recursivesubtypes_graph_ready(void);
void recursivesubtypes_graph_retire(void);
