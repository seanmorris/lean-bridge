#include <lean/lean.h>
#include <stdint.h>
LEAN_CASSERT(sizeof(size_t) * 8 == 32);
uint32_t lean_bridge_890e535d855edd42581629d4_recursive_d0f96c6a61c5999d6261_branch(lean_object *);
lean_object * lean_bridge_890e535d855edd42581629d4_recursive_d0f96c6a61c5999d6261_make0(lean_object *);
lean_object * lean_bridge_890e535d855edd42581629d4_recursive_d0f96c6a61c5999d6261_make1(lean_object *, lean_object *, lean_object *);
lean_object * lean_bridge_890e535d855edd42581629d4_recursive_d0f96c6a61c5999d6261_case1_field0(lean_object *);
lean_object * lean_bridge_890e535d855edd42581629d4_recursive_d0f96c6a61c5999d6261_case1_field1(lean_object *);
lean_object * lean_bridge_890e535d855edd42581629d4_recursive_d0f96c6a61c5999d6261_case1_field2(lean_object *);
lean_object * lean_bridge_890e535d855edd42581629d4_recursive_7150ee578fdad1fd4810_make(lean_object *);
lean_object * lean_bridge_890e535d855edd42581629d4_recursive_7150ee578fdad1fd4810_items(lean_object *);
uint32_t lean_bridge_890e535d855edd42581629d4_recursive_670fab78918c40675bdb_branch(lean_object *);
lean_object * lean_bridge_890e535d855edd42581629d4_recursive_670fab78918c40675bdb_none(lean_object *);
lean_object * lean_bridge_890e535d855edd42581629d4_recursive_670fab78918c40675bdb_make0(lean_object *);
lean_object * lean_bridge_890e535d855edd42581629d4_recursive_670fab78918c40675bdb_field0(lean_object *);
lean_object * lean_bridge_890e535d855edd42581629d4_recursive_83c50e7540f0bfb759d4_make(lean_object *);
lean_object * lean_bridge_890e535d855edd42581629d4_recursive_83c50e7540f0bfb759d4_field0(lean_object *);
lean_object * lean_bridge_890e535d855edd42581629d4_lean(lean_object *);
lean_object * lean_bridge_61edaca9ace2104f41ea6e59_lean(lean_object *);
lean_object * lean_bridge_a9ae70188abbca81b8f235ce_lean(lean_object *);
lean_object * lean_bridge_5f9ebf1241c61a39ed1bdebf_lean(lean_object *);
lean_object * lean_bridge_cc48993941d89731cae43d8e_lean(lean_object *);
lean_object * lean_bridge_9e8d2cbaa99dca92eb622921_lean(lean_object *);
