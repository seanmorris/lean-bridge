<?php
declare(strict_types=1);
namespace LeanRecursivesubtypes\Internal;

final class GraphTypes
{
    public const NODES = [
        ['kind' => 'option', 'element' => null, 'fields' => [['value', 2]], 'classes' => ['LeanRecursivesubtypes\\Some']],
        ['kind' => 'array', 'element' => 0, 'fields' => [], 'classes' => []],
        ['kind' => 'variant', 'element' => null, 'fields' => [], 'classes' => ['LeanRecursivesubtypes\\ChainEmpty', 'LeanRecursivesubtypes\\ChainNode']],
        ['kind' => 'primitive', 'name' => 'nat', 'host' => 'bigint', 'min' => '0', 'max' => null],
    ];
    public const CLASSES = [
        'LeanRecursivesubtypes\\ChainEmpty' => ['fields' => []],
        'LeanRecursivesubtypes\\ChainNode' => ['fields' => [['value', 3], ['digit', 3], ['tail', 2]]],
        'LeanRecursivesubtypes\\Some' => ['fields' => [['value', null]]],
        'LeanRecursivesubtypes\\Ok' => ['fields' => [['value', null]]],
        'LeanRecursivesubtypes\\Err' => ['fields' => [['value', null]]],
    ];
}
