package LeanBridge::InheritedCheckedRecords;
use strict;
use warnings;
use Math::BigInt;
use LeanBridge::Runtime;
die "Incompatible shared Lean runtime package version\n" unless $LeanBridge::Runtime::VERSION eq '0.0020130180835253351074425099676719723942806298898514237203907626409680523998624031';
use XSLoader;
our $VERSION = '1.000';
LeanBridge::Runtime::_load_component(__FILE__, 'libcomponent_95491bb762dabafaf0ed.so', '53509628e8748849ffa17fca90c68c15ad1be2ae6340b47f9ab5c1ab751ebbd4', '6f4dbd1e2e112f4678734553d1c9bb8722fad3e6290adbff1ac46d05e5eff7dd', { 'InheritedCheckedRecords' => 'daecdc61827a8ec5eca58522d2f67b69eb1ed81cbc1cedd91132e38d6361f53c' }, 'inheritedcheckedrecords@1.0.0');
XSLoader::load(__PACKAGE__, $VERSION);
sub true () { !!1 }
sub false () { !!0 }
sub CLONE_SKIP { 1 }

package LeanBridge::InheritedCheckedRecords::Span;
sub new {
  die "LeanBridge::InheritedCheckedRecords::Span->new expects named fields\n" unless @_ % 2 == 1 && $_[0] eq 'LeanBridge::InheritedCheckedRecords::Span';
  shift; my %fields;
  while (@_) {
    my ($key, $value) = splice @_, 0, 2;
    die "invalid record field\n" if !defined($key) || ref($key);
    $fields{$key} = $value;
  }
  my @required = qw(lo hi);
  die "record fields do not match the generated schema\n" if keys(%fields) != @required || grep { !exists $fields{$_} } @required;
  return bless \%fields, 'LeanBridge::InheritedCheckedRecords::Span';
}
sub lo { $_[0]->{lo} }
sub hi { $_[0]->{hi} }
package LeanBridge::InheritedCheckedRecords::Ticket;
sub new {
  die "LeanBridge::InheritedCheckedRecords::Ticket->new expects named fields\n" unless @_ % 2 == 1 && $_[0] eq 'LeanBridge::InheritedCheckedRecords::Ticket';
  shift; my %fields;
  while (@_) {
    my ($key, $value) = splice @_, 0, 2;
    die "invalid record field\n" if !defined($key) || ref($key);
    $fields{$key} = $value;
  }
  my @required = qw(toSpan word);
  die "record fields do not match the generated schema\n" if keys(%fields) != @required || grep { !exists $fields{$_} } @required;
  return bless \%fields, 'LeanBridge::InheritedCheckedRecords::Ticket';
}
sub toSpan { $_[0]->{toSpan} }
sub word { $_[0]->{word} }
package LeanBridge::InheritedCheckedRecords::Stamped;
sub new {
  die "LeanBridge::InheritedCheckedRecords::Stamped->new expects named fields\n" unless @_ % 2 == 1 && $_[0] eq 'LeanBridge::InheritedCheckedRecords::Stamped';
  shift; my %fields;
  while (@_) {
    my ($key, $value) = splice @_, 0, 2;
    die "invalid record field\n" if !defined($key) || ref($key);
    $fields{$key} = $value;
  }
  my @required = qw(toTicket mark);
  die "record fields do not match the generated schema\n" if keys(%fields) != @required || grep { !exists $fields{$_} } @required;
  return bless \%fields, 'LeanBridge::InheritedCheckedRecords::Stamped';
}
sub toTicket { $_[0]->{toTicket} }
sub mark { $_[0]->{mark} }
1;

__END__
=head1 NAME

LeanBridge::InheritedCheckedRecords - Generated functions from inheritedcheckedrecords

=head1 API

=head2 aliased

Calls C<InheritedCheckedRecords.aliased> in the compiled Lean component.

Checked Lean refinements: value0 checked by InheritedCheckedRecords.mkTicket; value0.toSpan checked by InheritedCheckedRecords.normalizeSpan; value0.word checked by InheritedCheckedRecords.normalizeWord.

Parameter C<value0>: C<TicketAlias>. Returns C<nat>.

=head2 echo

Calls C<InheritedCheckedRecords.echo> in the compiled Lean component.

Checked Lean refinements: value0 checked by InheritedCheckedRecords.normalizeTicket; value0.toSpan checked by InheritedCheckedRecords.mkSpan; value0.word checked by InheritedCheckedRecords.normalizeWord; result projects proof-backed record payload fields; result.toSpan projects proof-backed record payload fields; result.word projects the Subtype base value.

Parameter C<value0>: C<Ticket>. Returns C<Ticket>.

=head2 first

Calls C<InheritedCheckedRecords.first> in the compiled Lean component.

Checked Lean refinements: value0 checked by InheritedCheckedRecords.mkTicket; value0.toSpan checked by InheritedCheckedRecords.mkSpan; value0.word checked by InheritedCheckedRecords.mkWord.

Parameter C<value0>: C<Ticket>. Returns C<nat>.

=head2 nested

Calls C<InheritedCheckedRecords.nested> in the compiled Lean component.

Checked Lean refinements: value0 checked by InheritedCheckedRecords.mkStamped; value0.toTicket checked by InheritedCheckedRecords.mkTicket; value0.toTicket.toSpan checked by InheritedCheckedRecords.mkSpan; value0.toTicket.word checked by InheritedCheckedRecords.mkWord; value0.mark < 8.

Parameter C<value0>: C<Stamped>. Returns C<nat>.

=head2 normalized

Calls C<InheritedCheckedRecords.normalized> in the compiled Lean component.

Checked Lean refinements: value0 checked by InheritedCheckedRecords.normalizeTicket; value0.toSpan checked by InheritedCheckedRecords.normalizeSpan; value0.word checked by InheritedCheckedRecords.normalizeWord.

Parameter C<value0>: C<Ticket>. Returns C<nat>.

=head2 pair

Calls C<InheritedCheckedRecords.pair> in the compiled Lean component.

Checked Lean refinements: value0 checked by InheritedCheckedRecords.mkTicket; value0.toSpan checked by InheritedCheckedRecords.mkSpan; value0.word checked by InheritedCheckedRecords.mkWord; value1 checked by InheritedCheckedRecords.normalizeTicket; value1.toSpan checked by InheritedCheckedRecords.normalizeSpan; value1.word checked by InheritedCheckedRecords.normalizeWord.

Parameter C<value0>: C<Ticket>. Parameter C<value1>: C<Ticket>. Returns C<nat>.

=head2 produce

Calls C<InheritedCheckedRecords.produce> in the compiled Lean component.

Checked Lean refinements: result projects proof-backed record payload fields; result.toSpan projects proof-backed record payload fields; result.word projects the Subtype base value.

Parameter C<value0>: C<nat>. Returns C<Ticket>.

=head2 produce_stamped

Calls C<InheritedCheckedRecords.produceStamped> in the compiled Lean component.

Checked Lean refinements: result projects proof-backed record payload fields; result.toTicket projects proof-backed record payload fields; result.toTicket.toSpan projects proof-backed record payload fields; result.toTicket.word projects the Subtype base value; result.mark < 8.

Parameter C<value0>: C<nat>. Returns C<Stamped>.

=head1 COPIED ALIASES

Alias names, original targets and chains remain in the binding manifest and this POD. Call with ordinary Perl target values; aliases do not create separate packages or wrapper classes. Nat requires a nonnegative Math::BigInt; Int accepts negative values. Fixed-width and machine-word integers retain their ranges. Char requires one Unicode scalar. Unit uses undef. Copied payloads own independent storage. Existing copy budgets, schema depth and ownership checks apply. Recursive copies, compound callables and identity-bearing alias targets remain unsupported.

=over 4

=item C<TicketAlias>

Contract: C<Ticket>. Perl value: C<LeanBridge::InheritedCheckedRecords::Ticket>.

=back

=head1 RECORD FIELD CONTRACTS

=over 4

=item C<Span.lo>

Contract: C<nat>.

=item C<Span.hi>

Contract: C<nat>.

=item C<Stamped.toTicket>

Contract: C<Ticket>.

=item C<Stamped.mark>

Contract: C<nat>.

=item C<Ticket.toSpan>

Contract: C<Span>.

=item C<Ticket.word>

Contract: C<nat>.

=back

=head1 ARRAYS AND RECORDS

Lean Array values use plain dense array references. Calls reject blessed, tied and sparse arrays. Copied records use generated classes with named fields and accessors. Record keyword arguments keep Perl's last-value-wins hash semantics, including new(%old_fields, field => $replacement). Constructors reject missing, extra or unnamed fields; calls require the exact generated class and reject tied hashes and subclasses. Empty records and one-field records retain their named types.

Array slots and record fields are pinned before conversion can invoke Perl code. Returned arrays, records, octet strings and Math::BigInt payloads own independent copied storage. Reference equality is not deep value equality. Nested copied values share a 16 MiB conversion budget and a 32-level schema limit; these are not limits on all Perl allocations or Lean working memory. Recursive copied types remain unsupported.

=head1 CHECKED VALUES

A Lean C<Subtype> parameter over a primitive base takes the plain base value: L<Math::BigInt> for C<Nat> and C<Int>, an ordinary integer for machine words, a text scalar for C<String> and an octet string for C<ByteArray>. The exported checked constructor named at each function runs on the argument after every Fin bound passed and before the guarded adapter or the exported function; a rejected value dies with a message naming the parameter and the constructor, and the function receives the constructed value. Results are projected to their base value after Lean returns. Each checked site is listed as C<arg0 checked by Module.constructor> at its function.

=head1 CHECKED RECORDS

Checked records use generated classes containing only payload fields. Pass L<Math::BigInt> for C<Nat> fields and plain array references for copied arrays. Checked records may occur directly or through arrays, Lists, options, products, Except branches, plain record fields and active variant fields. Every nested Fin bound and Subtype constructor runs before the record constructor at that exact path. A rejection names the failing path and check. A normalizing constructor changes the record received by Lean without changing the caller's record. Results project payload fields after Lean constructs the proofs. No proof object or input constructor is needed for a result-only export. Ordinary and independently reviewed APIs preserve each site's constructor choices. Recursive and generic checked records, dependent forms beyond the recorded closed fields, callbacks and identity-bearing payloads remain unsupported.

=head1 BOUNDED INTEGERS

Lean C<Fin n> parameters and results are L<Math::BigInt> values below C<n>. Each argument is compared with its exact bound, including bounds wider than 64 bits, before the guarded adapter or the exported function runs. A value that is not a Math::BigInt, or a negative one, is rejected as for Nat; a value at or above its bound dies with a message naming the Lean parameter and bound. C<Fin 0> has no values, so every call to a function taking one dies. Results are Math::BigInt values below their declared bound. Inside arrays, Lists and options every present element is checked the same way before the guarded adapter or the exported function runs, so a C<Fin 0> element is rejected while an empty array or an undefined option is accepted; each checked path is listed as C<arg0[*]? < n> at its function, and a rejection names the failing element's own path and bound, such as C<arg0[2]? is not below its Fin 10 bound>. Fin inside records, variants, callbacks or reviewed Binding IR is not supported in CPAN packages.

=head1 OWNERSHIP

Close resource and closure objects when finished. Host callbacks are synchronous and may not be retained by Lean.

=cut
