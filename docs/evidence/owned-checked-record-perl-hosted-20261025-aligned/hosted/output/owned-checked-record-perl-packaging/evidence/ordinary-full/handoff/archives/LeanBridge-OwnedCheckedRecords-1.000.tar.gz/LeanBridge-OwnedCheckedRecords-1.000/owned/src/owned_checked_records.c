#include "owned_checked_records.h"
#include "owned-values.h"
#include "carriers.h"

#include <stddef.h>
#include <stdint.h>
#include <string.h>
#include "owned-leases.h"
_Static_assert(sizeof(void *) == 8 && sizeof(size_t) == 8, "owned native values require 64-bit Lean");
enum { OV_RESULT = 9 };
typedef struct {
  size_t bytes, visits;
  struct { const void *address; size_t type; } path[129];
} ov_budget;
typedef struct ov_allocation {
  struct ov_allocation *next;
  max_align_t alignment;
  unsigned char data[];
} ov_allocation;
typedef struct {
  lb_owned_scope scope;
  lb_owned_batch *input_owner;
  int input_transfer;
  ov_budget budget;
  ov_allocation *allocations;
} ov_transaction;
typedef struct ov_result_owner {
  struct ov_result_owner *self;
  lb_owned_context *context;
  lb_owned_batch batch;
  ov_allocation *allocations;
} ov_result_owner;

static inline void ov_release(ov_allocation *allocation) {
  while (allocation) {
    ov_allocation *next = allocation->next; LB_OWNED_FREE(allocation); allocation = next;
  }
}
static inline int ov_pointer(const void *value, size_t bytes, size_t alignment) {
  return value && (uintptr_t)value % alignment == 0 && bytes <= UINTPTR_MAX - (uintptr_t)value;
}
static inline int ov_charge(ov_budget *budget, size_t count, size_t width) {
  if (!width || count > budget->bytes / width) return LB_OWNED_LIMIT;
  budget->bytes -= count * width; return LB_OWNED_OK;
}
static inline int ov_visit(ov_budget *budget, size_t depth) {
  if (depth > 128 || !budget->visits) return LB_OWNED_LIMIT;
  --budget->visits; return LB_OWNED_OK;
}
static inline int ov_enter(ov_budget *budget, const void *value, size_t type, size_t depth) {
  int status = ov_visit(budget, depth);
  if (status) return status;
  for (size_t i = 0; i < depth; ++i)
    if (budget->path[i].address == value && budget->path[i].type == type) return LB_OWNED_INVALID;
  budget->path[depth].address = value; budget->path[depth].type = type;
  return LB_OWNED_OK;
}
static inline int ov_span(ov_budget *budget, const void *value, size_t count, size_t width, size_t alignment) {
  int status = ov_charge(budget, count, width);
  if (status) return status;
  return !count || ov_pointer(value, count * width, alignment) ? LB_OWNED_OK : LB_OWNED_INVALID;
}
static inline int ov_allocate(ov_transaction *transaction, size_t count, size_t width, void **out) {
  *out = NULL; if (!count) return LB_OWNED_OK;
  int status = ov_charge(&transaction->budget, count, width);
  if (!status) status = ov_charge(&transaction->budget, 1, sizeof(ov_allocation));
  if (status) return status;
  ov_allocation *allocation = LB_OWNED_ALLOC(sizeof(*allocation) + count * width);
  if (!allocation) return LB_OWNED_ALLOC_FAILED;
  allocation->next = transaction->allocations; transaction->allocations = allocation;
  memset(allocation->data, 0, count * width); *out = allocation->data; return LB_OWNED_OK;
}
static inline int ov_utf8(const uint8_t *data, size_t length) {
  size_t i = 0;
  while (i < length) {
    uint32_t point = data[i++], minimum; size_t extra;
    if (point < 0x80) continue;
    if (point >= 0xc2 && point <= 0xdf) { point &= 0x1f; extra = 1; minimum = 0x80; }
    else if (point >= 0xe0 && point <= 0xef) { point &= 0x0f; extra = 2; minimum = 0x800; }
    else if (point >= 0xf0 && point <= 0xf4) { point &= 7; extra = 3; minimum = 0x10000; }
    else return 0;
    if (extra > length - i) return 0;
    while (extra--) { uint8_t next = data[i++]; if ((next & 0xc0) != 0x80) return 0; point = (point << 6) | (next & 0x3f); }
    if (point < minimum || point > 0x10ffff || (point >= 0xd800 && point <= 0xdfff)) return 0;
  }
  return 1;
}
static inline lean_object *ov_nat_in(const uint32_t *data, size_t length) {
  lean_object *value = lean_box(0);
  while (length) {
    lean_object *shifted = lean_nat_shiftl(value, lean_box(32)); lean_dec(value);
    lean_object *limb = lean_uint32_to_nat(data[--length]);
    value = lean_nat_add(shifted, limb); lean_dec(shifted); lean_dec(limb);
  }
  return value;
}
static inline int ov_nat_out(lean_object *value, ov_transaction *transaction, const uint32_t **data, size_t *length) {
  *data = NULL; *length = 0;
  if (lean_nat_eq(value, lean_box(0))) return LB_OWNED_OK;
  lean_object *bits = lean_nat_log2(value);
  if (!lean_is_scalar(bits)) { lean_dec(bits); return LB_OWNED_LIMIT; }
  size_t count = lean_unbox(bits) / 32 + 1; lean_dec(bits);
  void *raw = NULL; int status = ov_allocate(transaction, count, sizeof(uint32_t), &raw);
  if (status) return status;
  uint32_t *limbs = raw; lean_inc(value);
  for (size_t i = 0; i < count; ++i) {
    limbs[i] = lean_uint32_of_nat(value);
    lean_object *next = lean_nat_shiftr(value, lean_box(32)); lean_dec(value); value = next;
  }
  lean_dec(value); *data = limbs; *length = count; return LB_OWNED_OK;
}
static inline lean_object *ov_carry(lean_object *value) {
  lean_object *carrier = lean_alloc_array(1, 1); lean_array_set_core(carrier, 0, value); return carrier;
}
static inline int ov_carrier(lean_object *value) {
  return value && !lean_is_scalar(value) && lean_is_array(value) && lean_array_size(value) == 1;
}
static inline int ov_finish(lean_object *value, lean_object **out) {
  if (!ov_carrier(value)) { if (value) lean_dec(value); return OV_RESULT; }
  *out = value; return LB_OWNED_OK;
}
static inline int ov_owner_empty(const ov_result_owner *owner) {
  return owner && !owner->self && !owner->context && !owner->allocations
    && !owner->batch.context && !owner->batch.entries && !owner->batch.next;
}
static inline int ov_owner_clear(ov_result_owner *owner) {
  if (!owner) return LB_OWNED_INVALID;
  if (ov_owner_empty(owner)) return LB_OWNED_OK;
  if (owner->self != owner || !owner->context) return LB_OWNED_INVALID;
  lb_owned_context *context = owner->context;
  if (context->self != context) return LB_OWNED_INVALID;
  if (context->process != getpid()) return LB_OWNED_PROCESS;
  if (!pthread_equal(context->thread, pthread_self()) || context->thread_serial != lb_owned_thread_serial)
    return LB_OWNED_THREAD;
  int status = LB_OWNED_OK;
  if (owner->batch.context) status = lb_owned_batch_release(context, &owner->batch);
  /* A broker error can be reported after release has drained the batch. */
  if (owner->batch.context) return status;
  ov_release(owner->allocations); *owner = (ov_result_owner){0}; return status;
}
static inline int ov_begin(ov_transaction *transaction, lb_owned_context *context, ov_result_owner *owner, const char *component) {
  if (!ov_owner_empty(owner)) return LB_OWNED_INVALID;
  int status = lb_owned_ready(context);
  if (status) return status;
  if (strcmp(context->component, component)) return LB_OWNED_INVALID;
  *transaction = (ov_transaction){0};
  transaction->budget.bytes = 16777216; transaction->budget.visits = 262144;
  return lb_owned_scope_begin(context, &transaction->scope);
}
static inline int ov_abort(ov_transaction *transaction, int status) {
  ov_release(transaction->allocations); transaction->allocations = NULL;
  if (transaction->scope.context) {
    if (status == OV_RESULT) lean_bridge_native_runtime_retire();
    int cleanup = lb_owned_scope_abort(&transaction->scope);
    if (!status) status = cleanup;
  }
  return status;
}
static inline int ov_commit(ov_transaction *transaction, ov_result_owner *owner) {
  lb_owned_context *context = transaction->scope.context;
  int status = lb_owned_scope_ready(&transaction->scope);
  if (status) return ov_abort(transaction, status);
  if (!transaction->allocations && !transaction->scope.outputs)
    return ov_abort(transaction, LB_OWNED_OK);
  status = lb_owned_scope_commit(&transaction->scope, &owner->batch);
  if (status) {
    /* Commit may have transferred outputs before dropping a failing input pin. */
    if (owner->batch.context) lb_owned_batch_release(context, &owner->batch);
    return ov_abort(transaction, status);
  }
  owner->self = owner; owner->context = context; owner->allocations = transaction->allocations;
  transaction->allocations = NULL; return LB_OWNED_OK;
}


typedef struct {
  ov_result_owner *const *owners;
  size_t count;
  void (*consume)(void *context);
  void *context;
  int consumed;
} ov_input_transfers;

static inline int ov_transfers_prepare(ov_transaction *transaction,
    ov_input_transfers *transfer, size_t expected, lb_owned_batch **batches,
    size_t *batch_count) {
  int status = lb_owned_scope_ready(&transaction->scope);
  if (status) return status;
  if (!ov_pointer(transfer, sizeof(*transfer), _Alignof(ov_input_transfers)) ||
      transfer->count != expected || transfer->consumed || !transfer->consume)
    return LB_OWNED_INVALID;
  if (expected > LB_OWNED_RETAINED_LIMIT) return LB_OWNED_LIMIT;
  status = ov_span(&transaction->budget, transfer->owners, expected,
      sizeof(ov_result_owner *), _Alignof(ov_result_owner *));
  if (status) return status;
  *batch_count = 0;
  for (size_t i = 0; i < expected; ++i) {
    ov_result_owner *owner = transfer->owners[i];
    if (!ov_pointer(owner, sizeof(*owner), _Alignof(ov_result_owner))) return LB_OWNED_INVALID;
    for (size_t j = 0; j < i; ++j)
      if (owner == transfer->owners[j]) return LB_OWNED_INVALID;
    /* Empty variants can have a public owner but no native allocation or batch.
       Its registration and session are validated by the public adapter. */
    if (ov_owner_empty(owner)) continue;
    if (owner->self != owner || owner->context != transaction->scope.context)
      return LB_OWNED_INVALID;
    lb_owned_batch *batch = transaction->scope.context->batches;
    while (batch && batch != &owner->batch) batch = batch->next;
    if (!batch) return LB_OWNED_INVALID;
    batches[(*batch_count)++] = batch;
  }
  return LB_OWNED_OK;
}


enum { OV_CALLBACK = 10 };
typedef struct ov_callback_frame {
  struct ov_callback_frame *parent;
  ov_transaction *transaction;
  int status;
} ov_callback_frame;
static _Thread_local ov_callback_frame *ov_active_callback_frame;
static inline void ov_callback_fail(ov_callback_frame *frame, int status) {
  if (frame && !frame->status) frame->status = status;
}

static inline int lbov_bf60afc4a65f34b9b6ab_vf790309465bbf573c7b9_in(const lbov_bf60afc4a65f34b9b6ab_tf790309465bbf573c7b9 *, size_t, int, ov_transaction *, lean_object **);
static inline int lbov_bf60afc4a65f34b9b6ab_vf790309465bbf573c7b9_out(lbov_bf60afc4a65f34b9b6ab_tf790309465bbf573c7b9 *, lean_object *, size_t, ov_transaction *);
static inline int lbov_bf60afc4a65f34b9b6ab_v160ce821a84f6887bbfd_in(const lbov_bf60afc4a65f34b9b6ab_t160ce821a84f6887bbfd *, size_t, int, ov_transaction *, lean_object **);
static inline int lbov_bf60afc4a65f34b9b6ab_v160ce821a84f6887bbfd_out(lbov_bf60afc4a65f34b9b6ab_t160ce821a84f6887bbfd *, lean_object *, size_t, ov_transaction *);
static inline int lbov_bf60afc4a65f34b9b6ab_v648974cffb2d6c1d7951_in(const lbov_bf60afc4a65f34b9b6ab_t648974cffb2d6c1d7951 *, size_t, int, ov_transaction *, lean_object **);
static inline int lbov_bf60afc4a65f34b9b6ab_v648974cffb2d6c1d7951_out(lbov_bf60afc4a65f34b9b6ab_t648974cffb2d6c1d7951 *, lean_object *, size_t, ov_transaction *);
static inline int lbov_bf60afc4a65f34b9b6ab_v5035e6ea0903f12776d9_in(const lbov_bf60afc4a65f34b9b6ab_t5035e6ea0903f12776d9 *, size_t, int, ov_transaction *, lean_object **);
static inline int lbov_bf60afc4a65f34b9b6ab_v5035e6ea0903f12776d9_out(lbov_bf60afc4a65f34b9b6ab_t5035e6ea0903f12776d9 *, lean_object *, size_t, ov_transaction *);
static inline int lbov_bf60afc4a65f34b9b6ab_v23107461f72b24c37654_in(const lbov_bf60afc4a65f34b9b6ab_t23107461f72b24c37654 *, size_t, int, ov_transaction *, lean_object **);
static inline int lbov_bf60afc4a65f34b9b6ab_v23107461f72b24c37654_out(lbov_bf60afc4a65f34b9b6ab_t23107461f72b24c37654 *, lean_object *, size_t, ov_transaction *);
static inline int lbov_bf60afc4a65f34b9b6ab_vb2825946e038e653bd2b_in(const lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b *, size_t, int, ov_transaction *, lean_object **);
static inline int lbov_bf60afc4a65f34b9b6ab_vb2825946e038e653bd2b_out(lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b *, lean_object *, size_t, ov_transaction *);
static inline int lbov_bf60afc4a65f34b9b6ab_v4ce841c87ea3b1559bfb_in(const lbov_bf60afc4a65f34b9b6ab_t4ce841c87ea3b1559bfb *, size_t, int, ov_transaction *, lean_object **);
static inline int lbov_bf60afc4a65f34b9b6ab_v4ce841c87ea3b1559bfb_out(lbov_bf60afc4a65f34b9b6ab_t4ce841c87ea3b1559bfb *, lean_object *, size_t, ov_transaction *);
static inline int lbov_bf60afc4a65f34b9b6ab_vd79b9bbde250ee1779da_in(const lbov_bf60afc4a65f34b9b6ab_td79b9bbde250ee1779da *, size_t, int, ov_transaction *, lean_object **);
static inline int lbov_bf60afc4a65f34b9b6ab_vd79b9bbde250ee1779da_out(lbov_bf60afc4a65f34b9b6ab_td79b9bbde250ee1779da *, lean_object *, size_t, ov_transaction *);
static inline int lbov_bf60afc4a65f34b9b6ab_v2a091437b2d587ce3891_in(const lbov_bf60afc4a65f34b9b6ab_t2a091437b2d587ce3891 *, size_t, int, ov_transaction *, lean_object **);
static inline int lbov_bf60afc4a65f34b9b6ab_v2a091437b2d587ce3891_out(lbov_bf60afc4a65f34b9b6ab_t2a091437b2d587ce3891 *, lean_object *, size_t, ov_transaction *);
static inline int lbov_bf60afc4a65f34b9b6ab_v167081552b6f9c1d1afd_in(const lbov_bf60afc4a65f34b9b6ab_t167081552b6f9c1d1afd *, size_t, int, ov_transaction *, lean_object **);
static inline int lbov_bf60afc4a65f34b9b6ab_v167081552b6f9c1d1afd_out(lbov_bf60afc4a65f34b9b6ab_t167081552b6f9c1d1afd *, lean_object *, size_t, ov_transaction *);
static inline int lbov_bf60afc4a65f34b9b6ab_vdc0347e1f7f5c4d928f1_in(const lbov_bf60afc4a65f34b9b6ab_tdc0347e1f7f5c4d928f1 *, size_t, int, ov_transaction *, lean_object **);
static inline int lbov_bf60afc4a65f34b9b6ab_vdc0347e1f7f5c4d928f1_out(lbov_bf60afc4a65f34b9b6ab_tdc0347e1f7f5c4d928f1 *, lean_object *, size_t, ov_transaction *);
static inline int lbov_bf60afc4a65f34b9b6ab_vf790309465bbf573c7b9_in(const lbov_bf60afc4a65f34b9b6ab_tf790309465bbf573c7b9 *value, size_t depth, int storage, ov_transaction *transaction, lean_object **out) {
  *out = NULL;
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_bf60afc4a65f34b9b6ab_tf790309465bbf573c7b9))) return LB_OWNED_INVALID;
  int status = ov_enter(&transaction->budget, value, 0, depth);
  if (!status && storage) status = ov_charge(&transaction->budget, 1, sizeof(*value));
  if (status) return status;
  if (value->length > transaction->budget.visits) return LB_OWNED_LIMIT;
  status = ov_span(&transaction->budget, value->data, value->length, sizeof(lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b), _Alignof(lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b));
  if (status) return status;
  lean_object *items = lean_alloc_array(0, value->length);
  for (size_t i = 0; i < value->length; ++i) {
    lean_object *child = NULL;
    status = lbov_bf60afc4a65f34b9b6ab_vb2825946e038e653bd2b_in(value->data + i, depth + 1, 0, transaction, &child);
    if (status) { lean_dec(items); return status; }
    items = lean_array_push(items, child);
  }
  return ov_finish(lean_bridge_owned_cafbd6a1f8e2dab80c6c01b5_tf790309465bbf573c7b9_make(items), out);
}
static inline int lbov_bf60afc4a65f34b9b6ab_vf790309465bbf573c7b9_out(lbov_bf60afc4a65f34b9b6ab_tf790309465bbf573c7b9 *out, lean_object *value, size_t depth, ov_transaction *transaction) {
  int status = ov_visit(&transaction->budget, depth);
  if (status) { if (value) lean_dec(value); return status; }
  if (!ov_carrier(value)) { if (value) lean_dec(value); return OV_RESULT; }
  size_t limit = transaction->budget.bytes / sizeof(lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b);
  if (limit > transaction->budget.visits) limit = transaction->budget.visits;
  if (depth == 128) limit = 0;
  value = lean_bridge_owned_cafbd6a1f8e2dab80c6c01b5_tf790309465bbf573c7b9_itemsBounded(value, lean_box(limit));
  if (!value || lean_is_scalar(value) || !lean_is_array(value)) { if (value) lean_dec(value); return OV_RESULT; }
  size_t count = lean_array_size(value);
  if (count > limit) { lean_dec(value); return LB_OWNED_LIMIT; }
  void *raw = NULL;
  status = ov_allocate(transaction, count, sizeof(lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b), &raw);
  out->data = raw; out->length = count; lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b *data = raw;
  for (size_t i = 0; !status && i < count; ++i) {
    lean_object *child = lean_array_get_core(value, i); lean_inc(child);
    status = lbov_bf60afc4a65f34b9b6ab_vb2825946e038e653bd2b_out(data + i, child, depth + 1, transaction);
  }
  lean_dec(value); return status;
}
static inline int lbov_bf60afc4a65f34b9b6ab_v160ce821a84f6887bbfd_in(const lbov_bf60afc4a65f34b9b6ab_t160ce821a84f6887bbfd *value, size_t depth, int storage, ov_transaction *transaction, lean_object **out) {
  *out = NULL;
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_bf60afc4a65f34b9b6ab_t160ce821a84f6887bbfd))) return LB_OWNED_INVALID;
  int status = ov_enter(&transaction->budget, value, 1, depth);
  if (!status && storage) status = ov_charge(&transaction->budget, 1, sizeof(*value));
  if (status) return status;
  if (value->tag > 1) return LB_OWNED_INVALID;
  if (!value->tag) return ov_finish(lean_bridge_owned_cafbd6a1f8e2dab80c6c01b5_t160ce821a84f6887bbfd_none(lean_box(0)), out);
  if (value->tag == 1) {
    lean_object *child = NULL;
    status = lbov_bf60afc4a65f34b9b6ab_vb2825946e038e653bd2b_in(value->f0, depth + 1, 1, transaction, &child);
    if (status) return status;
    return ov_finish(lean_bridge_owned_cafbd6a1f8e2dab80c6c01b5_t160ce821a84f6887bbfd_make0(child), out);
  }
  return LB_OWNED_INVALID;
}
static inline int lbov_bf60afc4a65f34b9b6ab_v160ce821a84f6887bbfd_out(lbov_bf60afc4a65f34b9b6ab_t160ce821a84f6887bbfd *out, lean_object *value, size_t depth, ov_transaction *transaction) {
  int status = ov_visit(&transaction->budget, depth);
  if (status) { if (value) lean_dec(value); return status; }
  if (!ov_carrier(value)) { if (value) lean_dec(value); return OV_RESULT; }
  lean_inc(value);
  uint32_t tag = lean_bridge_owned_cafbd6a1f8e2dab80c6c01b5_t160ce821a84f6887bbfd_branch(value);
  if (tag > 1) { lean_dec(value); return OV_RESULT; }
  out->tag = (uint8_t)tag;
  if (out->tag == 1) {
  if (!status) {
    void *raw = NULL;
    status = ov_allocate(transaction, 1, sizeof(lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b), &raw);
    out->f0 = raw;
    if (!status) {
      lean_inc(value);
      status = lbov_bf60afc4a65f34b9b6ab_vb2825946e038e653bd2b_out(raw, lean_bridge_owned_cafbd6a1f8e2dab80c6c01b5_t160ce821a84f6887bbfd_field0(value), depth + 1, transaction);
    }
  }
  }
  lean_dec(value); return status;
}
static inline int lbov_bf60afc4a65f34b9b6ab_v648974cffb2d6c1d7951_in(const lbov_bf60afc4a65f34b9b6ab_t648974cffb2d6c1d7951 *value, size_t depth, int storage, ov_transaction *transaction, lean_object **out) {
  *out = NULL;
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_bf60afc4a65f34b9b6ab_t648974cffb2d6c1d7951))) return LB_OWNED_INVALID;
  int status = ov_enter(&transaction->budget, value, 2, depth);
  if (!status && storage) status = ov_charge(&transaction->budget, 1, sizeof(*value));
  if (status) return status;
  lean_object *child = NULL;
  status = transaction->input_transfer
  ? lb_owned_scope_transfer_borrow(&transaction->scope, transaction->input_owner, "callable:owned-checked-records@1.0.0:bridge:Callback26621c40b48fce52ca37", value->token, &child)
  : lb_owned_scope_borrow(&transaction->scope, "callable:owned-checked-records@1.0.0:bridge:Callback26621c40b48fce52ca37", value->token, &child);
  if (status) return status;
  lean_inc(child); return ov_finish(ov_carry(child), out);
}
static inline int lbov_bf60afc4a65f34b9b6ab_v648974cffb2d6c1d7951_out(lbov_bf60afc4a65f34b9b6ab_t648974cffb2d6c1d7951 *out, lean_object *value, size_t depth, ov_transaction *transaction) {
  int status = ov_visit(&transaction->budget, depth);
  if (status) { if (value) lean_dec(value); return status; }
  if (!ov_carrier(value)) { if (value) lean_dec(value); return OV_RESULT; }
  lean_object *child = lean_array_get_core(value, 0);
  if (lean_is_scalar(child)) { lean_dec(value); return OV_RESULT; }
  if (lean_is_scalar(child) || !lean_is_closure(child)) { lean_dec(value); return OV_RESULT; }
  status = lb_owned_scope_acquire(&transaction->scope, "callable:owned-checked-records@1.0.0:bridge:Callback26621c40b48fce52ca37", child, &out->token);
  lean_dec(value); return status;
}
static inline int lbov_bf60afc4a65f34b9b6ab_v5035e6ea0903f12776d9_in(const lbov_bf60afc4a65f34b9b6ab_t5035e6ea0903f12776d9 *value, size_t depth, int storage, ov_transaction *transaction, lean_object **out) {
  *out = NULL;
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_bf60afc4a65f34b9b6ab_t5035e6ea0903f12776d9))) return LB_OWNED_INVALID;
  int status = ov_enter(&transaction->budget, value, 3, depth);
  if (!status && storage) status = ov_charge(&transaction->budget, 1, sizeof(*value));
  if (status) return status;
  lean_object *child = NULL;
  status = transaction->input_transfer
  ? lb_owned_scope_transfer_borrow(&transaction->scope, transaction->input_owner, "callable:owned-checked-records@1.0.0:bridge:Callbackb2d3d6fd4e031785f278", value->token, &child)
  : lb_owned_scope_borrow(&transaction->scope, "callable:owned-checked-records@1.0.0:bridge:Callbackb2d3d6fd4e031785f278", value->token, &child);
  if (status) return status;
  lean_inc(child); return ov_finish(ov_carry(child), out);
}
static inline int lbov_bf60afc4a65f34b9b6ab_v5035e6ea0903f12776d9_out(lbov_bf60afc4a65f34b9b6ab_t5035e6ea0903f12776d9 *out, lean_object *value, size_t depth, ov_transaction *transaction) {
  int status = ov_visit(&transaction->budget, depth);
  if (status) { if (value) lean_dec(value); return status; }
  if (!ov_carrier(value)) { if (value) lean_dec(value); return OV_RESULT; }
  lean_object *child = lean_array_get_core(value, 0);
  if (lean_is_scalar(child)) { lean_dec(value); return OV_RESULT; }
  if (lean_is_scalar(child) || !lean_is_closure(child)) { lean_dec(value); return OV_RESULT; }
  status = lb_owned_scope_acquire(&transaction->scope, "callable:owned-checked-records@1.0.0:bridge:Callbackb2d3d6fd4e031785f278", child, &out->token);
  lean_dec(value); return status;
}
__attribute__((noinline)) static lean_object *lbov_bf60afc4a65f34b9b6ab_v23107461f72b24c37654_make(lean_object *items) {
  lean_object *a0 = lean_array_get_core(items, 0); lean_inc(a0);
  lean_object *a1 = lean_array_get_core(items, 1); lean_inc(a1);
  lean_dec(items);
  return lean_bridge_owned_cafbd6a1f8e2dab80c6c01b5_t23107461f72b24c37654_make(a0, a1);
}
static inline int lbov_bf60afc4a65f34b9b6ab_v23107461f72b24c37654_in(const lbov_bf60afc4a65f34b9b6ab_t23107461f72b24c37654 *value, size_t depth, int storage, ov_transaction *transaction, lean_object **out) {
  *out = NULL;
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_bf60afc4a65f34b9b6ab_t23107461f72b24c37654))) return LB_OWNED_INVALID;
  int status = ov_enter(&transaction->budget, value, 4, depth);
  if (!status && storage) status = ov_charge(&transaction->budget, 1, sizeof(*value));
  if (status) return status;
  lean_object *items = lean_alloc_array(0, 2);
  lean_object *child = NULL;
  status = lbov_bf60afc4a65f34b9b6ab_vd79b9bbde250ee1779da_in(&value->f0, depth + 1, 0, transaction, &child);
  if (status) { lean_dec(items); return status; }
  items = lean_array_push(items, child);
  status = lbov_bf60afc4a65f34b9b6ab_v2a091437b2d587ce3891_in(value->f1, depth + 1, 1, transaction, &child);
  if (status) { lean_dec(items); return status; }
  items = lean_array_push(items, child);
  return ov_finish(lbov_bf60afc4a65f34b9b6ab_v23107461f72b24c37654_make(items), out);
}
static inline int lbov_bf60afc4a65f34b9b6ab_v23107461f72b24c37654_out(lbov_bf60afc4a65f34b9b6ab_t23107461f72b24c37654 *out, lean_object *value, size_t depth, ov_transaction *transaction) {
  int status = ov_visit(&transaction->budget, depth);
  if (status) { if (value) lean_dec(value); return status; }
  if (!ov_carrier(value)) { if (value) lean_dec(value); return OV_RESULT; }
  if (!status) {
    if (!status) {
      lean_inc(value);
      status = lbov_bf60afc4a65f34b9b6ab_vd79b9bbde250ee1779da_out(&out->f0, lean_bridge_owned_cafbd6a1f8e2dab80c6c01b5_t23107461f72b24c37654_field0(value), depth + 1, transaction);
    }
  }
  if (!status) {
    void *raw = NULL;
    status = ov_allocate(transaction, 1, sizeof(lbov_bf60afc4a65f34b9b6ab_t2a091437b2d587ce3891), &raw);
    out->f1 = raw;
    if (!status) {
      lean_inc(value);
      status = lbov_bf60afc4a65f34b9b6ab_v2a091437b2d587ce3891_out(raw, lean_bridge_owned_cafbd6a1f8e2dab80c6c01b5_t23107461f72b24c37654_field1(value), depth + 1, transaction);
    }
  }
  lean_dec(value); return status;
}
__attribute__((noinline)) static lean_object *lbov_bf60afc4a65f34b9b6ab_vb2825946e038e653bd2b_make(lean_object *items) {
  lean_object *a0 = lean_array_get_core(items, 0); lean_inc(a0);
  lean_object *a1 = lean_array_get_core(items, 1); lean_inc(a1);
  lean_dec(items);
  return lean_bridge_owned_cafbd6a1f8e2dab80c6c01b5_tb2825946e038e653bd2b_make(a0, a1);
}
static inline int lbov_bf60afc4a65f34b9b6ab_vb2825946e038e653bd2b_in(const lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b *value, size_t depth, int storage, ov_transaction *transaction, lean_object **out) {
  *out = NULL;
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b))) return LB_OWNED_INVALID;
  int status = ov_enter(&transaction->budget, value, 5, depth);
  if (!status && storage) status = ov_charge(&transaction->budget, 1, sizeof(*value));
  if (status) return status;
  lean_object *items = lean_alloc_array(0, 2);
  lean_object *child = NULL;
  status = lbov_bf60afc4a65f34b9b6ab_vd79b9bbde250ee1779da_in(&value->f0, depth + 1, 0, transaction, &child);
  if (status) { lean_dec(items); return status; }
  items = lean_array_push(items, child);
  status = lbov_bf60afc4a65f34b9b6ab_v167081552b6f9c1d1afd_in(&value->f1, depth + 1, 0, transaction, &child);
  if (status) { lean_dec(items); return status; }
  items = lean_array_push(items, child);
  return ov_finish(lbov_bf60afc4a65f34b9b6ab_vb2825946e038e653bd2b_make(items), out);
}
static inline int lbov_bf60afc4a65f34b9b6ab_vb2825946e038e653bd2b_out(lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b *out, lean_object *value, size_t depth, ov_transaction *transaction) {
  int status = ov_visit(&transaction->budget, depth);
  if (status) { if (value) lean_dec(value); return status; }
  if (!ov_carrier(value)) { if (value) lean_dec(value); return OV_RESULT; }
  if (!status) {
    if (!status) {
      lean_inc(value);
      status = lbov_bf60afc4a65f34b9b6ab_vd79b9bbde250ee1779da_out(&out->f0, lean_bridge_owned_cafbd6a1f8e2dab80c6c01b5_tb2825946e038e653bd2b_field0(value), depth + 1, transaction);
    }
  }
  if (!status) {
    if (!status) {
      lean_inc(value);
      status = lbov_bf60afc4a65f34b9b6ab_v167081552b6f9c1d1afd_out(&out->f1, lean_bridge_owned_cafbd6a1f8e2dab80c6c01b5_tb2825946e038e653bd2b_field1(value), depth + 1, transaction);
    }
  }
  lean_dec(value); return status;
}
__attribute__((noinline)) static lean_object *lbov_bf60afc4a65f34b9b6ab_v4ce841c87ea3b1559bfb_make(lean_object *items) {
  lean_object *a0 = lean_array_get_core(items, 0); lean_inc(a0);
  lean_object *a1 = lean_array_get_core(items, 1); lean_inc(a1);
  lean_object *a2 = lean_array_get_core(items, 2); lean_inc(a2);
  lean_dec(items);
  return lean_bridge_owned_cafbd6a1f8e2dab80c6c01b5_t4ce841c87ea3b1559bfb_make(a0, a1, a2);
}
static inline int lbov_bf60afc4a65f34b9b6ab_v4ce841c87ea3b1559bfb_in(const lbov_bf60afc4a65f34b9b6ab_t4ce841c87ea3b1559bfb *value, size_t depth, int storage, ov_transaction *transaction, lean_object **out) {
  *out = NULL;
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_bf60afc4a65f34b9b6ab_t4ce841c87ea3b1559bfb))) return LB_OWNED_INVALID;
  int status = ov_enter(&transaction->budget, value, 6, depth);
  if (!status && storage) status = ov_charge(&transaction->budget, 1, sizeof(*value));
  if (status) return status;
  lean_object *items = lean_alloc_array(0, 3);
  lean_object *child = NULL;
  status = lbov_bf60afc4a65f34b9b6ab_vd79b9bbde250ee1779da_in(&value->f0, depth + 1, 0, transaction, &child);
  if (status) { lean_dec(items); return status; }
  items = lean_array_push(items, child);
  status = lbov_bf60afc4a65f34b9b6ab_v167081552b6f9c1d1afd_in(&value->f1, depth + 1, 0, transaction, &child);
  if (status) { lean_dec(items); return status; }
  items = lean_array_push(items, child);
  status = lbov_bf60afc4a65f34b9b6ab_v167081552b6f9c1d1afd_in(&value->f2, depth + 1, 0, transaction, &child);
  if (status) { lean_dec(items); return status; }
  items = lean_array_push(items, child);
  return ov_finish(lbov_bf60afc4a65f34b9b6ab_v4ce841c87ea3b1559bfb_make(items), out);
}
static inline int lbov_bf60afc4a65f34b9b6ab_v4ce841c87ea3b1559bfb_out(lbov_bf60afc4a65f34b9b6ab_t4ce841c87ea3b1559bfb *out, lean_object *value, size_t depth, ov_transaction *transaction) {
  int status = ov_visit(&transaction->budget, depth);
  if (status) { if (value) lean_dec(value); return status; }
  if (!ov_carrier(value)) { if (value) lean_dec(value); return OV_RESULT; }
  if (!status) {
    if (!status) {
      lean_inc(value);
      status = lbov_bf60afc4a65f34b9b6ab_vd79b9bbde250ee1779da_out(&out->f0, lean_bridge_owned_cafbd6a1f8e2dab80c6c01b5_t4ce841c87ea3b1559bfb_field0(value), depth + 1, transaction);
    }
  }
  if (!status) {
    if (!status) {
      lean_inc(value);
      status = lbov_bf60afc4a65f34b9b6ab_v167081552b6f9c1d1afd_out(&out->f1, lean_bridge_owned_cafbd6a1f8e2dab80c6c01b5_t4ce841c87ea3b1559bfb_field1(value), depth + 1, transaction);
    }
  }
  if (!status) {
    if (!status) {
      lean_inc(value);
      status = lbov_bf60afc4a65f34b9b6ab_v167081552b6f9c1d1afd_out(&out->f2, lean_bridge_owned_cafbd6a1f8e2dab80c6c01b5_t4ce841c87ea3b1559bfb_field2(value), depth + 1, transaction);
    }
  }
  lean_dec(value); return status;
}
static inline int lbov_bf60afc4a65f34b9b6ab_vd79b9bbde250ee1779da_in(const lbov_bf60afc4a65f34b9b6ab_td79b9bbde250ee1779da *value, size_t depth, int storage, ov_transaction *transaction, lean_object **out) {
  *out = NULL;
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_bf60afc4a65f34b9b6ab_td79b9bbde250ee1779da))) return LB_OWNED_INVALID;
  int status = ov_enter(&transaction->budget, value, 7, depth);
  if (!status && storage) status = ov_charge(&transaction->budget, 1, sizeof(*value));
  if (status) return status;
  lean_object *child = NULL;
  status = transaction->input_transfer
  ? lb_owned_scope_transfer_borrow(&transaction->scope, transaction->input_owner, "resource:OwnedCheckedRecords.Ticket", value->token, &child)
  : lb_owned_scope_borrow(&transaction->scope, "resource:OwnedCheckedRecords.Ticket", value->token, &child);
  if (status) return status;
  lean_inc(child); return ov_finish(ov_carry(child), out);
}
static inline int lbov_bf60afc4a65f34b9b6ab_vd79b9bbde250ee1779da_out(lbov_bf60afc4a65f34b9b6ab_td79b9bbde250ee1779da *out, lean_object *value, size_t depth, ov_transaction *transaction) {
  int status = ov_visit(&transaction->budget, depth);
  if (status) { if (value) lean_dec(value); return status; }
  if (!ov_carrier(value)) { if (value) lean_dec(value); return OV_RESULT; }
  lean_object *child = lean_array_get_core(value, 0);
  if (lean_is_scalar(child)) { lean_dec(value); return OV_RESULT; }
  status = lb_owned_scope_acquire(&transaction->scope, "resource:OwnedCheckedRecords.Ticket", child, &out->token);
  lean_dec(value); return status;
}
__attribute__((noinline)) static lean_object *lbov_bf60afc4a65f34b9b6ab_v2a091437b2d587ce3891_make(lean_object *items) {
  lean_object *a0 = lean_array_get_core(items, 0); lean_inc(a0);
  lean_object *a1 = lean_array_get_core(items, 1); lean_inc(a1);
  lean_dec(items);
  return lean_bridge_owned_cafbd6a1f8e2dab80c6c01b5_t2a091437b2d587ce3891_make(a0, a1);
}
static inline int lbov_bf60afc4a65f34b9b6ab_v2a091437b2d587ce3891_in(const lbov_bf60afc4a65f34b9b6ab_t2a091437b2d587ce3891 *value, size_t depth, int storage, ov_transaction *transaction, lean_object **out) {
  *out = NULL;
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_bf60afc4a65f34b9b6ab_t2a091437b2d587ce3891))) return LB_OWNED_INVALID;
  int status = ov_enter(&transaction->budget, value, 8, depth);
  if (!status && storage) status = ov_charge(&transaction->budget, 1, sizeof(*value));
  if (status) return status;
  lean_object *items = lean_alloc_array(0, 2);
  lean_object *child = NULL;
  status = lbov_bf60afc4a65f34b9b6ab_v167081552b6f9c1d1afd_in(&value->f0, depth + 1, 0, transaction, &child);
  if (status) { lean_dec(items); return status; }
  items = lean_array_push(items, child);
  status = lbov_bf60afc4a65f34b9b6ab_v167081552b6f9c1d1afd_in(&value->f1, depth + 1, 0, transaction, &child);
  if (status) { lean_dec(items); return status; }
  items = lean_array_push(items, child);
  return ov_finish(lbov_bf60afc4a65f34b9b6ab_v2a091437b2d587ce3891_make(items), out);
}
static inline int lbov_bf60afc4a65f34b9b6ab_v2a091437b2d587ce3891_out(lbov_bf60afc4a65f34b9b6ab_t2a091437b2d587ce3891 *out, lean_object *value, size_t depth, ov_transaction *transaction) {
  int status = ov_visit(&transaction->budget, depth);
  if (status) { if (value) lean_dec(value); return status; }
  if (!ov_carrier(value)) { if (value) lean_dec(value); return OV_RESULT; }
  if (!status) {
    if (!status) {
      lean_inc(value);
      status = lbov_bf60afc4a65f34b9b6ab_v167081552b6f9c1d1afd_out(&out->f0, lean_bridge_owned_cafbd6a1f8e2dab80c6c01b5_t2a091437b2d587ce3891_field0(value), depth + 1, transaction);
    }
  }
  if (!status) {
    if (!status) {
      lean_inc(value);
      status = lbov_bf60afc4a65f34b9b6ab_v167081552b6f9c1d1afd_out(&out->f1, lean_bridge_owned_cafbd6a1f8e2dab80c6c01b5_t2a091437b2d587ce3891_field1(value), depth + 1, transaction);
    }
  }
  lean_dec(value); return status;
}
static inline int lbov_bf60afc4a65f34b9b6ab_v167081552b6f9c1d1afd_in(const lbov_bf60afc4a65f34b9b6ab_t167081552b6f9c1d1afd *value, size_t depth, int storage, ov_transaction *transaction, lean_object **out) {
  *out = NULL;
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_bf60afc4a65f34b9b6ab_t167081552b6f9c1d1afd))) return LB_OWNED_INVALID;
  int status = ov_enter(&transaction->budget, value, 9, depth);
  if (!status && storage) status = ov_charge(&transaction->budget, 1, sizeof(*value));
  if (status) return status;
  status = ov_span(&transaction->budget, value->data, value->length, sizeof(uint32_t), _Alignof(uint32_t));
  if (status) return status;
  return ov_finish(ov_carry(ov_nat_in(value->data, value->length)), out);
}
static inline int lbov_bf60afc4a65f34b9b6ab_v167081552b6f9c1d1afd_out(lbov_bf60afc4a65f34b9b6ab_t167081552b6f9c1d1afd *out, lean_object *value, size_t depth, ov_transaction *transaction) {
  int status = ov_visit(&transaction->budget, depth);
  if (status) { if (value) lean_dec(value); return status; }
  if (!ov_carrier(value)) { if (value) lean_dec(value); return OV_RESULT; }
  lean_object *child = lean_array_get_core(value, 0); lean_inc(child); lean_dec(value);
  if (!lean_is_scalar(child) && !lean_is_mpz(child)) { lean_dec(child); return OV_RESULT; }
  status = ov_nat_out(child, transaction, &out->data, &out->length);
  lean_dec(child); return status;
}
static inline int lbov_bf60afc4a65f34b9b6ab_vdc0347e1f7f5c4d928f1_in(const lbov_bf60afc4a65f34b9b6ab_tdc0347e1f7f5c4d928f1 *value, size_t depth, int storage, ov_transaction *transaction, lean_object **out) {
  *out = NULL;
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_bf60afc4a65f34b9b6ab_tdc0347e1f7f5c4d928f1))) return LB_OWNED_INVALID;
  int status = ov_enter(&transaction->budget, value, 10, depth);
  if (!status && storage) status = ov_charge(&transaction->budget, 1, sizeof(*value));
  if (status) return status;
  status = ov_span(&transaction->budget, value->data, value->length, 1, 1);
  if (status) return status;
  if (!ov_utf8((const uint8_t *)value->data, value->length)) return LB_OWNED_INVALID;
  return ov_finish(ov_carry(lean_mk_string_from_bytes(value->length ? value->data : "", value->length)), out);
}
static inline int lbov_bf60afc4a65f34b9b6ab_vdc0347e1f7f5c4d928f1_out(lbov_bf60afc4a65f34b9b6ab_tdc0347e1f7f5c4d928f1 *out, lean_object *value, size_t depth, ov_transaction *transaction) {
  int status = ov_visit(&transaction->budget, depth);
  if (status) { if (value) lean_dec(value); return status; }
  if (!ov_carrier(value)) { if (value) lean_dec(value); return OV_RESULT; }
  lean_object *child = lean_array_get_core(value, 0); lean_inc(child); lean_dec(value);
  if (lean_is_scalar(child) || !lean_is_string(child)) { lean_dec(child); return OV_RESULT; }
  size_t length = lean_string_size(child) - 1;
  if (!ov_utf8((const uint8_t *)lean_string_cstr(child), length)) { lean_dec(child); return OV_RESULT; }
  void *data = NULL;
  status = ov_allocate(transaction, length, 1, &data);
  if (!status) {
    if (length) memcpy(data, lean_string_cstr(child), length);
    out->data = data; out->length = length;
  }
  lean_dec(child); return status;
}
static inline int lbov_bf60afc4a65f34b9b6ab_f61fa6d001212787ff6aa(lb_owned_context *context, const lbov_bf60afc4a65f34b9b6ab_t23107461f72b24c37654 *a0, lbov_bf60afc4a65f34b9b6ab_t167081552b6f9c1d1afd *out, ov_result_owner *owner) {
  if (!ov_pointer(out, sizeof(*out), _Alignof(lbov_bf60afc4a65f34b9b6ab_t167081552b6f9c1d1afd)) || !ov_pointer(owner, sizeof(*owner), _Alignof(ov_result_owner))) return LB_OWNED_INVALID;
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  status = ov_charge(&transaction.budget, 1, sizeof(*out));
  if (status) return ov_abort(&transaction, status);
  lean_object *arguments = lean_alloc_array(0, 1);
  {
    lean_object *child = NULL;
    status = lbov_bf60afc4a65f34b9b6ab_v23107461f72b24c37654_in(a0, 0, 1, &transaction, &child);
    if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
    lean_inc(child);
    if (!lean_bridge_owned_refine_5ba8ebacbf26c0755e45(child)) { lean_dec(child); lean_dec(arguments); return ov_abort(&transaction, LB_OWNED_INVALID); }
    arguments = lean_array_push(arguments, child);
  }
  lean_object *v0 = lean_array_get_core(arguments, 0); lean_inc(v0);
  lean_dec(arguments);
  ov_callback_frame frame = { .parent = ov_active_callback_frame, .transaction = &transaction };
  if (!frame.parent) { (void)lb_native_callback_take_error(); (void)lean_bridge_owned_callback_failure_bf60afc4a65f34b9b6ab(); }
  ov_active_callback_frame = &frame;
  lean_object *returned = lean_bridge_owned_cafbd6a1f8e2dab80c6c01b5_f61fa6d001212787ff6aa(v0);
  ov_active_callback_frame = frame.parent; status = frame.status;
  int callback_error = lb_native_callback_take_error();
  int refinement_error = lean_bridge_owned_callback_failure_bf60afc4a65f34b9b6ab();
  if (refinement_error && !status) status = LB_OWNED_INVALID;
  else if (callback_error && !status) status = OV_CALLBACK;
  if (!status) status = lb_owned_scope_ready(&transaction.scope);
  if (status) { lean_dec(returned); return ov_abort(&transaction, status); }
  lbov_bf60afc4a65f34b9b6ab_t167081552b6f9c1d1afd converted = {0};
  status = lbov_bf60afc4a65f34b9b6ab_v167081552b6f9c1d1afd_out(&converted, returned, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  status = ov_commit(&transaction, owner);
  if (!status) *out = converted;
  return status;
}
static inline int lbov_bf60afc4a65f34b9b6ab_fa3218a29f42862f9b113(lb_owned_context *context, lbov_bf60afc4a65f34b9b6ab_t648974cffb2d6c1d7951 *out, ov_result_owner *owner) {
  if (!ov_pointer(out, sizeof(*out), _Alignof(lbov_bf60afc4a65f34b9b6ab_t648974cffb2d6c1d7951)) || !ov_pointer(owner, sizeof(*owner), _Alignof(ov_result_owner))) return LB_OWNED_INVALID;
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  status = ov_charge(&transaction.budget, 1, sizeof(*out));
  if (status) return ov_abort(&transaction, status);
  lean_object *arguments = lean_alloc_array(0, 0);
  lean_dec(arguments);
  ov_callback_frame frame = { .parent = ov_active_callback_frame, .transaction = &transaction };
  if (!frame.parent) { (void)lb_native_callback_take_error(); (void)lean_bridge_owned_callback_failure_bf60afc4a65f34b9b6ab(); }
  ov_active_callback_frame = &frame;
  lean_object *returned = lean_bridge_owned_cafbd6a1f8e2dab80c6c01b5_fa3218a29f42862f9b113(lean_box(0));
  ov_active_callback_frame = frame.parent; status = frame.status;
  int callback_error = lb_native_callback_take_error();
  int refinement_error = lean_bridge_owned_callback_failure_bf60afc4a65f34b9b6ab();
  if (refinement_error && !status) status = LB_OWNED_INVALID;
  else if (callback_error && !status) status = OV_CALLBACK;
  if (!status) status = lb_owned_scope_ready(&transaction.scope);
  if (status) { lean_dec(returned); return ov_abort(&transaction, status); }
  lbov_bf60afc4a65f34b9b6ab_t648974cffb2d6c1d7951 converted = {0};
  status = lbov_bf60afc4a65f34b9b6ab_v648974cffb2d6c1d7951_out(&converted, returned, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  status = ov_commit(&transaction, owner);
  if (!status) *out = converted;
  return status;
}
static inline int lbov_bf60afc4a65f34b9b6ab_f483485736ace9af57086(lb_owned_context *context, const lbov_bf60afc4a65f34b9b6ab_td79b9bbde250ee1779da *a0, lbov_bf60afc4a65f34b9b6ab_t160ce821a84f6887bbfd *out, ov_result_owner *owner) {
  if (!ov_pointer(out, sizeof(*out), _Alignof(lbov_bf60afc4a65f34b9b6ab_t160ce821a84f6887bbfd)) || !ov_pointer(owner, sizeof(*owner), _Alignof(ov_result_owner))) return LB_OWNED_INVALID;
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  status = ov_charge(&transaction.budget, 1, sizeof(*out));
  if (status) return ov_abort(&transaction, status);
  lean_object *arguments = lean_alloc_array(0, 1);
  {
    lean_object *child = NULL;
    status = lbov_bf60afc4a65f34b9b6ab_vd79b9bbde250ee1779da_in(a0, 0, 1, &transaction, &child);
    if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
    arguments = lean_array_push(arguments, child);
  }
  lean_object *v0 = lean_array_get_core(arguments, 0); lean_inc(v0);
  lean_dec(arguments);
  ov_callback_frame frame = { .parent = ov_active_callback_frame, .transaction = &transaction };
  if (!frame.parent) { (void)lb_native_callback_take_error(); (void)lean_bridge_owned_callback_failure_bf60afc4a65f34b9b6ab(); }
  ov_active_callback_frame = &frame;
  lean_object *returned = lean_bridge_owned_cafbd6a1f8e2dab80c6c01b5_f483485736ace9af57086(v0);
  ov_active_callback_frame = frame.parent; status = frame.status;
  int callback_error = lb_native_callback_take_error();
  int refinement_error = lean_bridge_owned_callback_failure_bf60afc4a65f34b9b6ab();
  if (refinement_error && !status) status = LB_OWNED_INVALID;
  else if (callback_error && !status) status = OV_CALLBACK;
  if (!status) status = lb_owned_scope_ready(&transaction.scope);
  if (status) { lean_dec(returned); return ov_abort(&transaction, status); }
  lbov_bf60afc4a65f34b9b6ab_t160ce821a84f6887bbfd converted = {0};
  status = lbov_bf60afc4a65f34b9b6ab_v160ce821a84f6887bbfd_out(&converted, returned, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  status = ov_commit(&transaction, owner);
  if (!status) *out = converted;
  return status;
}
static inline int lbov_bf60afc4a65f34b9b6ab_f2f69e4eb3cbfdff310da(lb_owned_context *context, const lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b *a0, lbov_bf60afc4a65f34b9b6ab_t167081552b6f9c1d1afd *out, ov_result_owner *owner) {
  if (!ov_pointer(out, sizeof(*out), _Alignof(lbov_bf60afc4a65f34b9b6ab_t167081552b6f9c1d1afd)) || !ov_pointer(owner, sizeof(*owner), _Alignof(ov_result_owner))) return LB_OWNED_INVALID;
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  status = ov_charge(&transaction.budget, 1, sizeof(*out));
  if (status) return ov_abort(&transaction, status);
  lean_object *arguments = lean_alloc_array(0, 1);
  {
    lean_object *child = NULL;
    status = lbov_bf60afc4a65f34b9b6ab_vb2825946e038e653bd2b_in(a0, 0, 1, &transaction, &child);
    if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
    lean_inc(child);
    if (!lean_bridge_owned_refine_ca177b2570793a278657(child)) { lean_dec(child); lean_dec(arguments); return ov_abort(&transaction, LB_OWNED_INVALID); }
    arguments = lean_array_push(arguments, child);
  }
  lean_object *v0 = lean_array_get_core(arguments, 0); lean_inc(v0);
  lean_dec(arguments);
  ov_callback_frame frame = { .parent = ov_active_callback_frame, .transaction = &transaction };
  if (!frame.parent) { (void)lb_native_callback_take_error(); (void)lean_bridge_owned_callback_failure_bf60afc4a65f34b9b6ab(); }
  ov_active_callback_frame = &frame;
  lean_object *returned = lean_bridge_owned_cafbd6a1f8e2dab80c6c01b5_f2f69e4eb3cbfdff310da(v0);
  ov_active_callback_frame = frame.parent; status = frame.status;
  int callback_error = lb_native_callback_take_error();
  int refinement_error = lean_bridge_owned_callback_failure_bf60afc4a65f34b9b6ab();
  if (refinement_error && !status) status = LB_OWNED_INVALID;
  else if (callback_error && !status) status = OV_CALLBACK;
  if (!status) status = lb_owned_scope_ready(&transaction.scope);
  if (status) { lean_dec(returned); return ov_abort(&transaction, status); }
  lbov_bf60afc4a65f34b9b6ab_t167081552b6f9c1d1afd converted = {0};
  status = lbov_bf60afc4a65f34b9b6ab_v167081552b6f9c1d1afd_out(&converted, returned, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  status = ov_commit(&transaction, owner);
  if (!status) *out = converted;
  return status;
}
static inline int lbov_bf60afc4a65f34b9b6ab_f0711e856cfa97d876c9a(lb_owned_context *context, const lbov_bf60afc4a65f34b9b6ab_t23107461f72b24c37654 *a0, lbov_bf60afc4a65f34b9b6ab_t23107461f72b24c37654 *out, ov_result_owner *owner) {
  if (!ov_pointer(out, sizeof(*out), _Alignof(lbov_bf60afc4a65f34b9b6ab_t23107461f72b24c37654)) || !ov_pointer(owner, sizeof(*owner), _Alignof(ov_result_owner))) return LB_OWNED_INVALID;
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  status = ov_charge(&transaction.budget, 1, sizeof(*out));
  if (status) return ov_abort(&transaction, status);
  lean_object *arguments = lean_alloc_array(0, 1);
  {
    lean_object *child = NULL;
    status = lbov_bf60afc4a65f34b9b6ab_v23107461f72b24c37654_in(a0, 0, 1, &transaction, &child);
    if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
    lean_inc(child);
    if (!lean_bridge_owned_refine_5ba8ebacbf26c0755e45(child)) { lean_dec(child); lean_dec(arguments); return ov_abort(&transaction, LB_OWNED_INVALID); }
    arguments = lean_array_push(arguments, child);
  }
  lean_object *v0 = lean_array_get_core(arguments, 0); lean_inc(v0);
  lean_dec(arguments);
  ov_callback_frame frame = { .parent = ov_active_callback_frame, .transaction = &transaction };
  if (!frame.parent) { (void)lb_native_callback_take_error(); (void)lean_bridge_owned_callback_failure_bf60afc4a65f34b9b6ab(); }
  ov_active_callback_frame = &frame;
  lean_object *returned = lean_bridge_owned_cafbd6a1f8e2dab80c6c01b5_f0711e856cfa97d876c9a(v0);
  ov_active_callback_frame = frame.parent; status = frame.status;
  int callback_error = lb_native_callback_take_error();
  int refinement_error = lean_bridge_owned_callback_failure_bf60afc4a65f34b9b6ab();
  if (refinement_error && !status) status = LB_OWNED_INVALID;
  else if (callback_error && !status) status = OV_CALLBACK;
  if (!status) status = lb_owned_scope_ready(&transaction.scope);
  if (status) { lean_dec(returned); return ov_abort(&transaction, status); }
  lbov_bf60afc4a65f34b9b6ab_t23107461f72b24c37654 converted = {0};
  status = lbov_bf60afc4a65f34b9b6ab_v23107461f72b24c37654_out(&converted, returned, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  status = ov_commit(&transaction, owner);
  if (!status) *out = converted;
  return status;
}
static inline int lbov_bf60afc4a65f34b9b6ab_f535babcfd8d0f67ea0e6(lb_owned_context *context, const lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b *a0, lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b *out, ov_result_owner *owner) {
  if (!ov_pointer(out, sizeof(*out), _Alignof(lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b)) || !ov_pointer(owner, sizeof(*owner), _Alignof(ov_result_owner))) return LB_OWNED_INVALID;
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  status = ov_charge(&transaction.budget, 1, sizeof(*out));
  if (status) return ov_abort(&transaction, status);
  lean_object *arguments = lean_alloc_array(0, 1);
  {
    lean_object *child = NULL;
    status = lbov_bf60afc4a65f34b9b6ab_vb2825946e038e653bd2b_in(a0, 0, 1, &transaction, &child);
    if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
    lean_inc(child);
    if (!lean_bridge_owned_refine_ca177b2570793a278657(child)) { lean_dec(child); lean_dec(arguments); return ov_abort(&transaction, LB_OWNED_INVALID); }
    arguments = lean_array_push(arguments, child);
  }
  lean_object *v0 = lean_array_get_core(arguments, 0); lean_inc(v0);
  lean_dec(arguments);
  ov_callback_frame frame = { .parent = ov_active_callback_frame, .transaction = &transaction };
  if (!frame.parent) { (void)lb_native_callback_take_error(); (void)lean_bridge_owned_callback_failure_bf60afc4a65f34b9b6ab(); }
  ov_active_callback_frame = &frame;
  lean_object *returned = lean_bridge_owned_cafbd6a1f8e2dab80c6c01b5_f535babcfd8d0f67ea0e6(v0);
  ov_active_callback_frame = frame.parent; status = frame.status;
  int callback_error = lb_native_callback_take_error();
  int refinement_error = lean_bridge_owned_callback_failure_bf60afc4a65f34b9b6ab();
  if (refinement_error && !status) status = LB_OWNED_INVALID;
  else if (callback_error && !status) status = OV_CALLBACK;
  if (!status) status = lb_owned_scope_ready(&transaction.scope);
  if (status) { lean_dec(returned); return ov_abort(&transaction, status); }
  lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b converted = {0};
  status = lbov_bf60afc4a65f34b9b6ab_vb2825946e038e653bd2b_out(&converted, returned, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  status = ov_commit(&transaction, owner);
  if (!status) *out = converted;
  return status;
}
static inline int lbov_bf60afc4a65f34b9b6ab_f25326d75f45c4daa9d9d(lb_owned_context *context, const lbov_bf60afc4a65f34b9b6ab_tf790309465bbf573c7b9 *a0, lbov_bf60afc4a65f34b9b6ab_tf790309465bbf573c7b9 *out, ov_result_owner *owner) {
  if (!ov_pointer(out, sizeof(*out), _Alignof(lbov_bf60afc4a65f34b9b6ab_tf790309465bbf573c7b9)) || !ov_pointer(owner, sizeof(*owner), _Alignof(ov_result_owner))) return LB_OWNED_INVALID;
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  status = ov_charge(&transaction.budget, 1, sizeof(*out));
  if (status) return ov_abort(&transaction, status);
  lean_object *arguments = lean_alloc_array(0, 1);
  {
    lean_object *child = NULL;
    status = lbov_bf60afc4a65f34b9b6ab_vf790309465bbf573c7b9_in(a0, 0, 1, &transaction, &child);
    if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
    lean_inc(child);
    if (!lean_bridge_owned_refine_be1666fcf441d2cede51(child)) { lean_dec(child); lean_dec(arguments); return ov_abort(&transaction, LB_OWNED_INVALID); }
    arguments = lean_array_push(arguments, child);
  }
  lean_object *v0 = lean_array_get_core(arguments, 0); lean_inc(v0);
  lean_dec(arguments);
  ov_callback_frame frame = { .parent = ov_active_callback_frame, .transaction = &transaction };
  if (!frame.parent) { (void)lb_native_callback_take_error(); (void)lean_bridge_owned_callback_failure_bf60afc4a65f34b9b6ab(); }
  ov_active_callback_frame = &frame;
  lean_object *returned = lean_bridge_owned_cafbd6a1f8e2dab80c6c01b5_f25326d75f45c4daa9d9d(v0);
  ov_active_callback_frame = frame.parent; status = frame.status;
  int callback_error = lb_native_callback_take_error();
  int refinement_error = lean_bridge_owned_callback_failure_bf60afc4a65f34b9b6ab();
  if (refinement_error && !status) status = LB_OWNED_INVALID;
  else if (callback_error && !status) status = OV_CALLBACK;
  if (!status) status = lb_owned_scope_ready(&transaction.scope);
  if (status) { lean_dec(returned); return ov_abort(&transaction, status); }
  lbov_bf60afc4a65f34b9b6ab_tf790309465bbf573c7b9 converted = {0};
  status = lbov_bf60afc4a65f34b9b6ab_vf790309465bbf573c7b9_out(&converted, returned, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  status = ov_commit(&transaction, owner);
  if (!status) *out = converted;
  return status;
}
static inline int lbov_bf60afc4a65f34b9b6ab_feb082cf837ef02082ea8(lb_owned_context *context, const lbov_bf60afc4a65f34b9b6ab_t4ce841c87ea3b1559bfb *a0, lbov_bf60afc4a65f34b9b6ab_t4ce841c87ea3b1559bfb *out, ov_result_owner *owner) {
  if (!ov_pointer(out, sizeof(*out), _Alignof(lbov_bf60afc4a65f34b9b6ab_t4ce841c87ea3b1559bfb)) || !ov_pointer(owner, sizeof(*owner), _Alignof(ov_result_owner))) return LB_OWNED_INVALID;
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  status = ov_charge(&transaction.budget, 1, sizeof(*out));
  if (status) return ov_abort(&transaction, status);
  lean_object *arguments = lean_alloc_array(0, 1);
  {
    lean_object *child = NULL;
    status = lbov_bf60afc4a65f34b9b6ab_v4ce841c87ea3b1559bfb_in(a0, 0, 1, &transaction, &child);
    if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
    lean_inc(child);
    if (!lean_bridge_owned_refine_5593f0b9830f059702a4(child)) { lean_dec(child); lean_dec(arguments); return ov_abort(&transaction, LB_OWNED_INVALID); }
    arguments = lean_array_push(arguments, child);
  }
  lean_object *v0 = lean_array_get_core(arguments, 0); lean_inc(v0);
  lean_dec(arguments);
  ov_callback_frame frame = { .parent = ov_active_callback_frame, .transaction = &transaction };
  if (!frame.parent) { (void)lb_native_callback_take_error(); (void)lean_bridge_owned_callback_failure_bf60afc4a65f34b9b6ab(); }
  ov_active_callback_frame = &frame;
  lean_object *returned = lean_bridge_owned_cafbd6a1f8e2dab80c6c01b5_feb082cf837ef02082ea8(v0);
  ov_active_callback_frame = frame.parent; status = frame.status;
  int callback_error = lb_native_callback_take_error();
  int refinement_error = lean_bridge_owned_callback_failure_bf60afc4a65f34b9b6ab();
  if (refinement_error && !status) status = LB_OWNED_INVALID;
  else if (callback_error && !status) status = OV_CALLBACK;
  if (!status) status = lb_owned_scope_ready(&transaction.scope);
  if (status) { lean_dec(returned); return ov_abort(&transaction, status); }
  lbov_bf60afc4a65f34b9b6ab_t4ce841c87ea3b1559bfb converted = {0};
  status = lbov_bf60afc4a65f34b9b6ab_v4ce841c87ea3b1559bfb_out(&converted, returned, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  status = ov_commit(&transaction, owner);
  if (!status) *out = converted;
  return status;
}
static inline int lbov_bf60afc4a65f34b9b6ab_fa1e5189bd92568e4b939(lb_owned_context *context, const lbov_bf60afc4a65f34b9b6ab_t167081552b6f9c1d1afd *a0, const lbov_bf60afc4a65f34b9b6ab_tdc0347e1f7f5c4d928f1 *a1, lbov_bf60afc4a65f34b9b6ab_td79b9bbde250ee1779da *out, ov_result_owner *owner) {
  if (!ov_pointer(out, sizeof(*out), _Alignof(lbov_bf60afc4a65f34b9b6ab_td79b9bbde250ee1779da)) || !ov_pointer(owner, sizeof(*owner), _Alignof(ov_result_owner))) return LB_OWNED_INVALID;
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  status = ov_charge(&transaction.budget, 1, sizeof(*out));
  if (status) return ov_abort(&transaction, status);
  lean_object *arguments = lean_alloc_array(0, 2);
  {
    lean_object *child = NULL;
    status = lbov_bf60afc4a65f34b9b6ab_v167081552b6f9c1d1afd_in(a0, 0, 1, &transaction, &child);
    if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
    arguments = lean_array_push(arguments, child);
  }
  {
    lean_object *child = NULL;
    status = lbov_bf60afc4a65f34b9b6ab_vdc0347e1f7f5c4d928f1_in(a1, 0, 1, &transaction, &child);
    if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
    arguments = lean_array_push(arguments, child);
  }
  lean_object *v0 = lean_array_get_core(arguments, 0); lean_inc(v0);
  lean_object *v1 = lean_array_get_core(arguments, 1); lean_inc(v1);
  lean_dec(arguments);
  ov_callback_frame frame = { .parent = ov_active_callback_frame, .transaction = &transaction };
  if (!frame.parent) { (void)lb_native_callback_take_error(); (void)lean_bridge_owned_callback_failure_bf60afc4a65f34b9b6ab(); }
  ov_active_callback_frame = &frame;
  lean_object *returned = lean_bridge_owned_cafbd6a1f8e2dab80c6c01b5_fa1e5189bd92568e4b939(v0, v1);
  ov_active_callback_frame = frame.parent; status = frame.status;
  int callback_error = lb_native_callback_take_error();
  int refinement_error = lean_bridge_owned_callback_failure_bf60afc4a65f34b9b6ab();
  if (refinement_error && !status) status = LB_OWNED_INVALID;
  else if (callback_error && !status) status = OV_CALLBACK;
  if (!status) status = lb_owned_scope_ready(&transaction.scope);
  if (status) { lean_dec(returned); return ov_abort(&transaction, status); }
  lbov_bf60afc4a65f34b9b6ab_td79b9bbde250ee1779da converted = {0};
  status = lbov_bf60afc4a65f34b9b6ab_vd79b9bbde250ee1779da_out(&converted, returned, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  status = ov_commit(&transaction, owner);
  if (!status) *out = converted;
  return status;
}
static inline int lbov_bf60afc4a65f34b9b6ab_feaac3cc8d9197bd7bbca(lb_owned_context *context, const lbov_bf60afc4a65f34b9b6ab_t23107461f72b24c37654 *a0, const lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b *a1, lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b *out, ov_result_owner *owner) {
  if (!ov_pointer(out, sizeof(*out), _Alignof(lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b)) || !ov_pointer(owner, sizeof(*owner), _Alignof(ov_result_owner))) return LB_OWNED_INVALID;
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  status = ov_charge(&transaction.budget, 1, sizeof(*out));
  if (status) return ov_abort(&transaction, status);
  lean_object *arguments = lean_alloc_array(0, 2);
  {
    lean_object *child = NULL;
    status = lbov_bf60afc4a65f34b9b6ab_v23107461f72b24c37654_in(a0, 0, 1, &transaction, &child);
    if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
    lean_inc(child);
    if (!lean_bridge_owned_refine_5ba8ebacbf26c0755e45(child)) { lean_dec(child); lean_dec(arguments); return ov_abort(&transaction, LB_OWNED_INVALID); }
    arguments = lean_array_push(arguments, child);
  }
  {
    lean_object *child = NULL;
    status = lbov_bf60afc4a65f34b9b6ab_vb2825946e038e653bd2b_in(a1, 0, 1, &transaction, &child);
    if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
    lean_inc(child);
    if (!lean_bridge_owned_refine_ca177b2570793a278657(child)) { lean_dec(child); lean_dec(arguments); return ov_abort(&transaction, LB_OWNED_INVALID); }
    arguments = lean_array_push(arguments, child);
  }
  lean_object *v0 = lean_array_get_core(arguments, 0); lean_inc(v0);
  lean_object *v1 = lean_array_get_core(arguments, 1); lean_inc(v1);
  lean_dec(arguments);
  ov_callback_frame frame = { .parent = ov_active_callback_frame, .transaction = &transaction };
  if (!frame.parent) { (void)lb_native_callback_take_error(); (void)lean_bridge_owned_callback_failure_bf60afc4a65f34b9b6ab(); }
  ov_active_callback_frame = &frame;
  lean_object *returned = lean_bridge_owned_cafbd6a1f8e2dab80c6c01b5_feaac3cc8d9197bd7bbca(v0, v1);
  ov_active_callback_frame = frame.parent; status = frame.status;
  int callback_error = lb_native_callback_take_error();
  int refinement_error = lean_bridge_owned_callback_failure_bf60afc4a65f34b9b6ab();
  if (refinement_error && !status) status = LB_OWNED_INVALID;
  else if (callback_error && !status) status = OV_CALLBACK;
  if (!status) status = lb_owned_scope_ready(&transaction.scope);
  if (status) { lean_dec(returned); return ov_abort(&transaction, status); }
  lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b converted = {0};
  status = lbov_bf60afc4a65f34b9b6ab_vb2825946e038e653bd2b_out(&converted, returned, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  status = ov_commit(&transaction, owner);
  if (!status) *out = converted;
  return status;
}
static inline int lbov_bf60afc4a65f34b9b6ab_fec926afda994fba3abe2(lb_owned_context *context, const lbov_bf60afc4a65f34b9b6ab_td79b9bbde250ee1779da *a0, lbov_bf60afc4a65f34b9b6ab_t167081552b6f9c1d1afd *out, ov_result_owner *owner) {
  if (!ov_pointer(out, sizeof(*out), _Alignof(lbov_bf60afc4a65f34b9b6ab_t167081552b6f9c1d1afd)) || !ov_pointer(owner, sizeof(*owner), _Alignof(ov_result_owner))) return LB_OWNED_INVALID;
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  status = ov_charge(&transaction.budget, 1, sizeof(*out));
  if (status) return ov_abort(&transaction, status);
  lean_object *arguments = lean_alloc_array(0, 1);
  {
    lean_object *child = NULL;
    status = lbov_bf60afc4a65f34b9b6ab_vd79b9bbde250ee1779da_in(a0, 0, 1, &transaction, &child);
    if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
    arguments = lean_array_push(arguments, child);
  }
  lean_object *v0 = lean_array_get_core(arguments, 0); lean_inc(v0);
  lean_dec(arguments);
  ov_callback_frame frame = { .parent = ov_active_callback_frame, .transaction = &transaction };
  if (!frame.parent) { (void)lb_native_callback_take_error(); (void)lean_bridge_owned_callback_failure_bf60afc4a65f34b9b6ab(); }
  ov_active_callback_frame = &frame;
  lean_object *returned = lean_bridge_owned_cafbd6a1f8e2dab80c6c01b5_fec926afda994fba3abe2(v0);
  ov_active_callback_frame = frame.parent; status = frame.status;
  int callback_error = lb_native_callback_take_error();
  int refinement_error = lean_bridge_owned_callback_failure_bf60afc4a65f34b9b6ab();
  if (refinement_error && !status) status = LB_OWNED_INVALID;
  else if (callback_error && !status) status = OV_CALLBACK;
  if (!status) status = lb_owned_scope_ready(&transaction.scope);
  if (status) { lean_dec(returned); return ov_abort(&transaction, status); }
  lbov_bf60afc4a65f34b9b6ab_t167081552b6f9c1d1afd converted = {0};
  status = lbov_bf60afc4a65f34b9b6ab_v167081552b6f9c1d1afd_out(&converted, returned, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  status = ov_commit(&transaction, owner);
  if (!status) *out = converted;
  return status;
}
static inline int lbov_bf60afc4a65f34b9b6ab_f040aca3025d850fc12cc(lb_owned_context *context, const lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b *a0, ov_input_transfers *transfer, lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b *out, ov_result_owner *owner) {
  if (!ov_pointer(out, sizeof(*out), _Alignof(lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b)) || !ov_pointer(owner, sizeof(*owner), _Alignof(ov_result_owner))) return LB_OWNED_INVALID;
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  status = ov_charge(&transaction.budget, 1, sizeof(*out));
  if (status) return ov_abort(&transaction, status);
  lb_owned_batch *batches[1] = {0}; size_t batch_count = 0;
  status = ov_transfers_prepare(&transaction, transfer, 1, batches, &batch_count);
  if (status) return ov_abort(&transaction, status);
  lean_object *arguments = lean_alloc_array(0, 1);
  {
    lean_object *child = NULL;
    transaction.input_transfer = 1;
    transaction.input_owner = &transfer->owners[0]->batch;
    status = lbov_bf60afc4a65f34b9b6ab_vb2825946e038e653bd2b_in(a0, 0, 1, &transaction, &child);
    if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
    lean_inc(child);
    if (!lean_bridge_owned_refine_ca177b2570793a278657(child)) { lean_dec(child); lean_dec(arguments); return ov_abort(&transaction, LB_OWNED_INVALID); }
    arguments = lean_array_push(arguments, child);
  }
  transaction.input_transfer = 0; transaction.input_owner = NULL;
  status = lb_owned_scope_transfer_many(&transaction.scope, batches, batch_count);
  if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
  transfer->consumed = 1; transfer->consume(transfer->context);
  lean_object *v0 = lean_array_get_core(arguments, 0); lean_inc(v0);
  lean_dec(arguments);
  ov_callback_frame frame = { .parent = ov_active_callback_frame, .transaction = &transaction };
  if (!frame.parent) { (void)lb_native_callback_take_error(); (void)lean_bridge_owned_callback_failure_bf60afc4a65f34b9b6ab(); }
  ov_active_callback_frame = &frame;
  lean_object *returned = lean_bridge_owned_cafbd6a1f8e2dab80c6c01b5_f040aca3025d850fc12cc(v0);
  ov_active_callback_frame = frame.parent; status = frame.status;
  int callback_error = lb_native_callback_take_error();
  int refinement_error = lean_bridge_owned_callback_failure_bf60afc4a65f34b9b6ab();
  if (refinement_error && !status) status = LB_OWNED_INVALID;
  else if (callback_error && !status) status = OV_CALLBACK;
  if (!status) status = lb_owned_scope_ready(&transaction.scope);
  if (status) { lean_dec(returned); return ov_abort(&transaction, status); }
  lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b converted = {0};
  status = lbov_bf60afc4a65f34b9b6ab_vb2825946e038e653bd2b_out(&converted, returned, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  status = ov_commit(&transaction, owner);
  if (!status) *out = converted;
  return status;
}
static inline int lbov_bf60afc4a65f34b9b6ab_fc4cffe83b4b420b09021(lb_owned_context *context, const lbov_bf60afc4a65f34b9b6ab_t23107461f72b24c37654 *a0, const lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b *a1, ov_input_transfers *transfer, lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b *out, ov_result_owner *owner) {
  if (!ov_pointer(out, sizeof(*out), _Alignof(lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b)) || !ov_pointer(owner, sizeof(*owner), _Alignof(ov_result_owner))) return LB_OWNED_INVALID;
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  status = ov_charge(&transaction.budget, 1, sizeof(*out));
  if (status) return ov_abort(&transaction, status);
  lb_owned_batch *batches[2] = {0}; size_t batch_count = 0;
  status = ov_transfers_prepare(&transaction, transfer, 2, batches, &batch_count);
  if (status) return ov_abort(&transaction, status);
  lean_object *arguments = lean_alloc_array(0, 2);
  {
    lean_object *child = NULL;
    transaction.input_transfer = 1;
    transaction.input_owner = &transfer->owners[0]->batch;
    status = lbov_bf60afc4a65f34b9b6ab_v23107461f72b24c37654_in(a0, 0, 1, &transaction, &child);
    if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
    lean_inc(child);
    if (!lean_bridge_owned_refine_5ba8ebacbf26c0755e45(child)) { lean_dec(child); lean_dec(arguments); return ov_abort(&transaction, LB_OWNED_INVALID); }
    arguments = lean_array_push(arguments, child);
  }
  {
    lean_object *child = NULL;
    transaction.input_transfer = 1;
    transaction.input_owner = &transfer->owners[1]->batch;
    status = lbov_bf60afc4a65f34b9b6ab_vb2825946e038e653bd2b_in(a1, 0, 1, &transaction, &child);
    if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
    lean_inc(child);
    if (!lean_bridge_owned_refine_ca177b2570793a278657(child)) { lean_dec(child); lean_dec(arguments); return ov_abort(&transaction, LB_OWNED_INVALID); }
    arguments = lean_array_push(arguments, child);
  }
  transaction.input_transfer = 0; transaction.input_owner = NULL;
  status = lb_owned_scope_transfer_many(&transaction.scope, batches, batch_count);
  if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
  transfer->consumed = 1; transfer->consume(transfer->context);
  lean_object *v0 = lean_array_get_core(arguments, 0); lean_inc(v0);
  lean_object *v1 = lean_array_get_core(arguments, 1); lean_inc(v1);
  lean_dec(arguments);
  ov_callback_frame frame = { .parent = ov_active_callback_frame, .transaction = &transaction };
  if (!frame.parent) { (void)lb_native_callback_take_error(); (void)lean_bridge_owned_callback_failure_bf60afc4a65f34b9b6ab(); }
  ov_active_callback_frame = &frame;
  lean_object *returned = lean_bridge_owned_cafbd6a1f8e2dab80c6c01b5_fc4cffe83b4b420b09021(v0, v1);
  ov_active_callback_frame = frame.parent; status = frame.status;
  int callback_error = lb_native_callback_take_error();
  int refinement_error = lean_bridge_owned_callback_failure_bf60afc4a65f34b9b6ab();
  if (refinement_error && !status) status = LB_OWNED_INVALID;
  else if (callback_error && !status) status = OV_CALLBACK;
  if (!status) status = lb_owned_scope_ready(&transaction.scope);
  if (status) { lean_dec(returned); return ov_abort(&transaction, status); }
  lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b converted = {0};
  status = lbov_bf60afc4a65f34b9b6ab_vb2825946e038e653bd2b_out(&converted, returned, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  status = ov_commit(&transaction, owner);
  if (!status) *out = converted;
  return status;
}
static inline int lbov_bf60afc4a65f34b9b6ab_f33442f0a4409864e6a4a(lb_owned_context *context, const lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b *a0, const lbov_bf60afc4a65f34b9b6ab_t5035e6ea0903f12776d9 *a1, ov_input_transfers *transfer, lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b *out, ov_result_owner *owner) {
  if (!ov_pointer(out, sizeof(*out), _Alignof(lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b)) || !ov_pointer(owner, sizeof(*owner), _Alignof(ov_result_owner))) return LB_OWNED_INVALID;
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  status = ov_charge(&transaction.budget, 1, sizeof(*out));
  if (status) return ov_abort(&transaction, status);
  lb_owned_batch *batches[1] = {0}; size_t batch_count = 0;
  status = ov_transfers_prepare(&transaction, transfer, 1, batches, &batch_count);
  if (status) return ov_abort(&transaction, status);
  lean_object *arguments = lean_alloc_array(0, 2);
  {
    lean_object *child = NULL;
    transaction.input_transfer = 1;
    transaction.input_owner = &transfer->owners[0]->batch;
    status = lbov_bf60afc4a65f34b9b6ab_vb2825946e038e653bd2b_in(a0, 0, 1, &transaction, &child);
    if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
    lean_inc(child);
    if (!lean_bridge_owned_refine_ca177b2570793a278657(child)) { lean_dec(child); lean_dec(arguments); return ov_abort(&transaction, LB_OWNED_INVALID); }
    arguments = lean_array_push(arguments, child);
  }
  {
    lean_object *child = NULL;
    transaction.input_transfer = 0;
    transaction.input_owner = NULL;
    status = lbov_bf60afc4a65f34b9b6ab_v5035e6ea0903f12776d9_in(a1, 0, 1, &transaction, &child);
    if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
    arguments = lean_array_push(arguments, child);
  }
  transaction.input_transfer = 0; transaction.input_owner = NULL;
  status = lb_owned_scope_transfer_many(&transaction.scope, batches, batch_count);
  if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
  transfer->consumed = 1; transfer->consume(transfer->context);
  lean_object *v0 = lean_array_get_core(arguments, 0); lean_inc(v0);
  lean_object *v1 = lean_array_get_core(arguments, 1); lean_inc(v1);
  lean_dec(arguments);
  ov_callback_frame frame = { .parent = ov_active_callback_frame, .transaction = &transaction };
  if (!frame.parent) { (void)lb_native_callback_take_error(); (void)lean_bridge_owned_callback_failure_bf60afc4a65f34b9b6ab(); }
  ov_active_callback_frame = &frame;
  lean_object *returned = lean_bridge_owned_cafbd6a1f8e2dab80c6c01b5_f33442f0a4409864e6a4a(v0, v1);
  ov_active_callback_frame = frame.parent; status = frame.status;
  int callback_error = lb_native_callback_take_error();
  int refinement_error = lean_bridge_owned_callback_failure_bf60afc4a65f34b9b6ab();
  if (refinement_error && !status) status = LB_OWNED_INVALID;
  else if (callback_error && !status) status = OV_CALLBACK;
  if (!status) status = lb_owned_scope_ready(&transaction.scope);
  if (status) { lean_dec(returned); return ov_abort(&transaction, status); }
  lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b converted = {0};
  status = lbov_bf60afc4a65f34b9b6ab_vb2825946e038e653bd2b_out(&converted, returned, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  status = ov_commit(&transaction, owner);
  if (!status) *out = converted;
  return status;
}
static inline int lbov_bf60afc4a65f34b9b6ab_f7d6c8617a0788c12de15(lb_owned_context *context, const lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b *a0, const lbov_bf60afc4a65f34b9b6ab_t5035e6ea0903f12776d9 *a1, lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b *out, ov_result_owner *owner) {
  if (!ov_pointer(out, sizeof(*out), _Alignof(lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b)) || !ov_pointer(owner, sizeof(*owner), _Alignof(ov_result_owner))) return LB_OWNED_INVALID;
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  status = ov_charge(&transaction.budget, 1, sizeof(*out));
  if (status) return ov_abort(&transaction, status);
  lean_object *arguments = lean_alloc_array(0, 2);
  {
    lean_object *child = NULL;
    status = lbov_bf60afc4a65f34b9b6ab_vb2825946e038e653bd2b_in(a0, 0, 1, &transaction, &child);
    if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
    lean_inc(child);
    if (!lean_bridge_owned_refine_ca177b2570793a278657(child)) { lean_dec(child); lean_dec(arguments); return ov_abort(&transaction, LB_OWNED_INVALID); }
    arguments = lean_array_push(arguments, child);
  }
  {
    lean_object *child = NULL;
    status = lbov_bf60afc4a65f34b9b6ab_v5035e6ea0903f12776d9_in(a1, 0, 1, &transaction, &child);
    if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
    arguments = lean_array_push(arguments, child);
  }
  lean_object *v0 = lean_array_get_core(arguments, 0); lean_inc(v0);
  lean_object *v1 = lean_array_get_core(arguments, 1); lean_inc(v1);
  lean_dec(arguments);
  ov_callback_frame frame = { .parent = ov_active_callback_frame, .transaction = &transaction };
  if (!frame.parent) { (void)lb_native_callback_take_error(); (void)lean_bridge_owned_callback_failure_bf60afc4a65f34b9b6ab(); }
  ov_active_callback_frame = &frame;
  lean_object *returned = lean_bridge_owned_cafbd6a1f8e2dab80c6c01b5_f7d6c8617a0788c12de15(v0, v1);
  ov_active_callback_frame = frame.parent; status = frame.status;
  int callback_error = lb_native_callback_take_error();
  int refinement_error = lean_bridge_owned_callback_failure_bf60afc4a65f34b9b6ab();
  if (refinement_error && !status) status = LB_OWNED_INVALID;
  else if (callback_error && !status) status = OV_CALLBACK;
  if (!status) status = lb_owned_scope_ready(&transaction.scope);
  if (status) { lean_dec(returned); return ov_abort(&transaction, status); }
  lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b converted = {0};
  status = lbov_bf60afc4a65f34b9b6ab_vb2825946e038e653bd2b_out(&converted, returned, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  status = ov_commit(&transaction, owner);
  if (!status) *out = converted;
  return status;
}
static inline int lbov_bf60afc4a65f34b9b6ab_v648974cffb2d6c1d7951_apply(lb_owned_context *context, const lbov_bf60afc4a65f34b9b6ab_t648974cffb2d6c1d7951 *a0, const lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b *a1, lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b *out, ov_result_owner *owner) {
  if (!ov_pointer(out, sizeof(*out), _Alignof(lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b)) || !ov_pointer(owner, sizeof(*owner), _Alignof(ov_result_owner))) return LB_OWNED_INVALID;
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  status = ov_charge(&transaction.budget, 1, sizeof(*out));
  if (status) return ov_abort(&transaction, status);
  lean_object *arguments = lean_alloc_array(0, 2);
  {
    lean_object *child = NULL;
    status = lbov_bf60afc4a65f34b9b6ab_v648974cffb2d6c1d7951_in(a0, 0, 1, &transaction, &child);
    if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
    arguments = lean_array_push(arguments, child);
  }
  {
    lean_object *child = NULL;
    status = lbov_bf60afc4a65f34b9b6ab_vb2825946e038e653bd2b_in(a1, 0, 1, &transaction, &child);
    if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
    lean_inc(child);
    if (!lean_bridge_owned_refine_ca177b2570793a278657(child)) { lean_dec(child); lean_dec(arguments); return ov_abort(&transaction, LB_OWNED_INVALID); }
    arguments = lean_array_push(arguments, child);
  }
  lean_object *v0 = lean_array_get_core(arguments, 0); lean_inc(v0);
  lean_object *v1 = lean_array_get_core(arguments, 1); lean_inc(v1);
  lean_dec(arguments);
  ov_callback_frame frame = { .parent = ov_active_callback_frame, .transaction = &transaction };
  if (!frame.parent) { (void)lb_native_callback_take_error(); (void)lean_bridge_owned_callback_failure_bf60afc4a65f34b9b6ab(); }
  ov_active_callback_frame = &frame;
  lean_object *returned = lean_bridge_owned_cafbd6a1f8e2dab80c6c01b5_t648974cffb2d6c1d7951_apply(v0, v1);
  ov_active_callback_frame = frame.parent; status = frame.status;
  int callback_error = lb_native_callback_take_error();
  int refinement_error = lean_bridge_owned_callback_failure_bf60afc4a65f34b9b6ab();
  if (refinement_error && !status) status = LB_OWNED_INVALID;
  else if (callback_error && !status) status = OV_CALLBACK;
  if (!status) status = lb_owned_scope_ready(&transaction.scope);
  if (status) { lean_dec(returned); return ov_abort(&transaction, status); }
  lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b converted = {0};
  status = lbov_bf60afc4a65f34b9b6ab_vb2825946e038e653bd2b_out(&converted, returned, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  status = ov_commit(&transaction, owner);
  if (!status) *out = converted;
  return status;
}
static inline int lbov_bf60afc4a65f34b9b6ab_v5035e6ea0903f12776d9_apply(lb_owned_context *context, const lbov_bf60afc4a65f34b9b6ab_t5035e6ea0903f12776d9 *a0, const lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b *a1, lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b *out, ov_result_owner *owner) {
  if (!ov_pointer(out, sizeof(*out), _Alignof(lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b)) || !ov_pointer(owner, sizeof(*owner), _Alignof(ov_result_owner))) return LB_OWNED_INVALID;
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  status = ov_charge(&transaction.budget, 1, sizeof(*out));
  if (status) return ov_abort(&transaction, status);
  lean_object *arguments = lean_alloc_array(0, 2);
  {
    lean_object *child = NULL;
    status = lbov_bf60afc4a65f34b9b6ab_v5035e6ea0903f12776d9_in(a0, 0, 1, &transaction, &child);
    if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
    arguments = lean_array_push(arguments, child);
  }
  {
    lean_object *child = NULL;
    status = lbov_bf60afc4a65f34b9b6ab_vb2825946e038e653bd2b_in(a1, 0, 1, &transaction, &child);
    if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
    arguments = lean_array_push(arguments, child);
  }
  lean_object *v0 = lean_array_get_core(arguments, 0); lean_inc(v0);
  lean_object *v1 = lean_array_get_core(arguments, 1); lean_inc(v1);
  lean_dec(arguments);
  ov_callback_frame frame = { .parent = ov_active_callback_frame, .transaction = &transaction };
  if (!frame.parent) { (void)lb_native_callback_take_error(); (void)lean_bridge_owned_callback_failure_bf60afc4a65f34b9b6ab(); }
  ov_active_callback_frame = &frame;
  lean_object *returned = lean_bridge_owned_cafbd6a1f8e2dab80c6c01b5_t5035e6ea0903f12776d9_apply(v0, v1);
  ov_active_callback_frame = frame.parent; status = frame.status;
  int callback_error = lb_native_callback_take_error();
  int refinement_error = lean_bridge_owned_callback_failure_bf60afc4a65f34b9b6ab();
  if (refinement_error && !status) status = LB_OWNED_INVALID;
  else if (callback_error && !status) status = OV_CALLBACK;
  if (!status) status = lb_owned_scope_ready(&transaction.scope);
  if (status) { lean_dec(returned); return ov_abort(&transaction, status); }
  lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b converted = {0};
  status = lbov_bf60afc4a65f34b9b6ab_vb2825946e038e653bd2b_out(&converted, returned, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  status = ov_commit(&transaction, owner);
  if (!status) *out = converted;
  return status;
}


_Static_assert(sizeof(bool) == 1, "owned C values require one-byte bool storage");
typedef struct oc_block {
  struct oc_block *next;
  int integer_initialized;
  mpz_t integer;
  max_align_t alignment;
  unsigned char data[];
} oc_block;
typedef struct { oc_block *head; ov_budget *budget; } oc_arena;
typedef struct oc_session oc_session;
typedef struct oc_result {
  struct oc_result *next;
  uint64_t key;
  oc_session *session;
  ov_result_owner native;
  oc_block *blocks;
} oc_result;
struct oc_session {
  oc_session *next;
  uint64_t key;
  lb_owned_context native;
  size_t results, calls;
  int closed;
};
static _Thread_local oc_session *oc_sessions;
static _Thread_local oc_result *oc_results;
extern lean_object *initialize_LeanBridgeOwnedd4fa73573648ce57(uint8_t);
static void *oc_initialize(uint8_t builtin) { return initialize_LeanBridgeOwnedd4fa73573648ce57(builtin); }

static inline void oc_release(oc_block *block) {
  while (block) {
    oc_block *next = block->next;
    if (block->integer_initialized) mpz_clear(block->integer);
    LB_OWNED_FREE(block); block = next;
  }
}
static inline int oc_block_new(oc_arena *arena, size_t count, size_t width, oc_block **out) {
  int status = ov_charge(arena->budget, count, width);
  if (!status) status = ov_charge(arena->budget, 1, sizeof(oc_block));
  if (status) return status;
  oc_block *block = LB_OWNED_ALLOC(sizeof(*block) + count * width);
  if (!block) return LB_OWNED_ALLOC_FAILED;
  memset(block, 0, sizeof(*block) + count * width);
  block->next = arena->head; arena->head = block; *out = block;
  return LB_OWNED_OK;
}
static inline int oc_allocate(oc_arena *arena, size_t count, size_t width, void **out) {
  *out = NULL; if (!count) return LB_OWNED_OK;
  oc_block *block; int status = oc_block_new(arena, count, width, &block);
  if (!status) *out = block->data;
  return status;
}
static inline int oc_integer(oc_arena *arena, const uint32_t *limbs, size_t length, int negative, mpz_srcptr *out) {
  int status = ov_span(arena->budget, limbs, length, sizeof(uint32_t), _Alignof(uint32_t));
  if (status) return status;
  size_t bits = length * 32, count = bits / GMP_NUMB_BITS + (bits % GMP_NUMB_BITS != 0);
  status = ov_charge(arena->budget, count, sizeof(mp_limb_t));
  if (status) return status;
  oc_block *block; status = oc_block_new(arena, 0, 1, &block);
  if (status) return status;
  mpz_init(block->integer); block->integer_initialized = 1;
  if (length) mpz_import(block->integer, length, -1, sizeof(uint32_t), 0, 0, limbs);
  if (negative) mpz_neg(block->integer, block->integer);
  *out = block->integer; return LB_OWNED_OK;
}
static inline oc_session *oc_session_find(const owned_checked_records_session *key) {
  for (oc_session *item = oc_sessions; item; item = item->next)
    if (item->key == (uint64_t)(uintptr_t)key) return item;
  return NULL;
}
static inline int oc_session_get(const owned_checked_records_session *key, oc_session **out) {
  if (!lean_bridge_native_process_valid()) return LB_OWNED_PROCESS;
  oc_session *session = oc_session_find(key);
  if (!session) return LB_OWNED_INVALID;
  if (session->closed) return LB_OWNED_CLOSED;
  int status = lb_owned_ready(&session->native);
  if (!status) *out = session;
  return status;
}
static inline void oc_session_collect(oc_session *session) {
  if (!session->closed || session->results || session->calls) return;
  oc_session **slot = &oc_sessions;
  while (*slot != session) slot = &(*slot)->next;
  *slot = session->next;
  (void)lean_bridge_native_identity_release(session->key, "owned-c-session:owned-checked-records@1.0.0", session);
  LB_OWNED_FREE(session);
}
owned_checked_records_status owned_checked_records_session_open(owned_checked_records_session **out) {
  if (!ov_pointer(out, sizeof(*out), _Alignof(owned_checked_records_session *)) || *out) return (owned_checked_records_status)LB_OWNED_INVALID;
  if (!lean_bridge_native_process_valid()) return (owned_checked_records_status)LB_OWNED_PROCESS;
  if (!lean_bridge_native_component_initialize("owned-checked-records@1.0.0", oc_initialize)) return (owned_checked_records_status)LB_OWNED_RUNTIME;
  oc_session *session = LB_OWNED_ALLOC(sizeof(*session));
  if (!session) return (owned_checked_records_status)LB_OWNED_ALLOC_FAILED;
  memset(session, 0, sizeof(*session));
  int status = lb_owned_context_init(&session->native, "owned-checked-records@1.0.0");
  if (status) { LB_OWNED_FREE(session); return (owned_checked_records_status)status; }
  session->key = lean_bridge_native_identity_acquire("owned-c-session:owned-checked-records@1.0.0", session);
  if (!session->key) { lb_owned_context_close(&session->native); LB_OWNED_FREE(session); return (owned_checked_records_status)LB_OWNED_LIMIT; }
  session->next = oc_sessions; oc_sessions = session;
  *out = (owned_checked_records_session *)(uintptr_t)session->key;
  return (owned_checked_records_status)LB_OWNED_OK;
}
owned_checked_records_status owned_checked_records_session_close(owned_checked_records_session **value) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(owned_checked_records_session *))) return (owned_checked_records_status)LB_OWNED_INVALID;
  if (!lean_bridge_native_process_valid()) return (owned_checked_records_status)LB_OWNED_PROCESS;
  if (!*value) return (owned_checked_records_status)LB_OWNED_OK;
  oc_session *session = oc_session_find(*value);
  if (!session) return (owned_checked_records_status)LB_OWNED_INVALID;
  if (session->closed) return (owned_checked_records_status)LB_OWNED_CLOSED;
  int status = lb_owned_context_close(&session->native);
  if (status) return (owned_checked_records_status)status;
  session->closed = 1; *value = NULL;
  oc_session_collect(session); return (owned_checked_records_status)LB_OWNED_OK;
}
owned_checked_records_status owned_checked_records_result_release(owned_checked_records_result **value) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(owned_checked_records_result *))) return (owned_checked_records_status)LB_OWNED_INVALID;
  if (!lean_bridge_native_process_valid()) return (owned_checked_records_status)LB_OWNED_PROCESS;
  if (!*value) return (owned_checked_records_status)LB_OWNED_OK;
  oc_result **slot = &oc_results;
  while (*slot && (*slot)->key != (uint64_t)(uintptr_t)*value) slot = &(*slot)->next;
  if (!*slot) return (owned_checked_records_status)LB_OWNED_INVALID;
  oc_result *result = *slot; oc_session *session = result->session;
  int status = ov_owner_clear(&result->native);
  if (!ov_owner_empty(&result->native)) return (owned_checked_records_status)status;
  *slot = result->next; --session->results;
  if (lean_bridge_native_identity_release(result->key, "owned-c-result:owned-checked-records@1.0.0", result) < 0 && !status) status = LB_OWNED_RUNTIME;
  oc_release(result->blocks); LB_OWNED_FREE(result); *value = NULL;
  oc_session_collect(session); return (owned_checked_records_status)status;
}
static inline int oc_result_begin(oc_session *session, ov_budget *budget, oc_result **out) {
  if (session->calls == LB_OWNED_SCOPE_LIMIT) return LB_OWNED_LIMIT;
  int status = ov_charge(budget, 1, sizeof(oc_result));
  if (status) return status;
  oc_result *result = LB_OWNED_ALLOC(sizeof(*result));
  if (!result) return LB_OWNED_ALLOC_FAILED;
  memset(result, 0, sizeof(*result)); result->session = session;
  ++session->calls; *out = result; return LB_OWNED_OK;
}
static inline int oc_result_finish(oc_result *result, oc_arena *output, int status, owned_checked_records_result **owner) {
  oc_session *session = result->session;
  if (status == OV_RESULT) lean_bridge_native_runtime_retire();
  if (!status) status = lb_owned_ready(&session->native);
  if (!status) {
    result->key = lean_bridge_native_identity_acquire("owned-c-result:owned-checked-records@1.0.0", result);
    if (!result->key) status = LB_OWNED_LIMIT;
  }
  if (!status) {
    result->blocks = output->head; output->head = NULL;
    result->next = oc_results; oc_results = result; ++session->results;
    *owner = (owned_checked_records_result *)(uintptr_t)result->key;
  } else {
    (void)ov_owner_clear(&result->native);
    oc_release(output->head); output->head = NULL; LB_OWNED_FREE(result);
  }
  --session->calls; oc_session_collect(session); return status;
}
static inline ov_budget oc_budget(void) {
  return (ov_budget){ .bytes = 16777216, .visits = 262144 };
}
static inline int oc_outputs(const void *out, size_t bytes, size_t alignment, const void *owner) {
  if (!ov_pointer(out, bytes, alignment) || !ov_pointer(owner, sizeof(void *), _Alignof(void *))) return 0;
  uintptr_t a = (uintptr_t)out, b = (uintptr_t)owner;
  return a < b ? bytes <= b - a : sizeof(void *) <= a - b;
}


typedef struct {
  owned_checked_records_result **slot;
  oc_result *result;
} oc_transfer_input;
typedef struct {
  oc_transfer_input *inputs;
  size_t count;
  int consumed;
} oc_transfer_frame;

static inline int oc_transfer_prepare(oc_session *session, oc_transfer_frame *frame,
    ov_result_owner **owners, void *out, size_t bytes, size_t alignment,
    owned_checked_records_result **output_owner) {
  for (size_t i = 0; i < frame->count; ++i) {
    owned_checked_records_result **slot = frame->inputs[i].slot;
    if (!oc_outputs(out, bytes, alignment, slot) ||
        !oc_outputs(slot, sizeof(*slot), _Alignof(owned_checked_records_result *), output_owner) ||
        !*slot) return LB_OWNED_INVALID;
    oc_result *result = oc_results;
    while (result && result->key != (uint64_t)(uintptr_t)*slot) result = result->next;
    if (!result || result->session != session) return LB_OWNED_INVALID;
    for (size_t j = 0; j < i; ++j)
      if (frame->inputs[j].result == result) return LB_OWNED_INVALID;
    frame->inputs[i].result = result;
    owners[i] = &result->native;
  }
  return LB_OWNED_OK;
}

/* Native conversion has validated every value and moved every input batch.
   This hook cannot allocate, call user code, or fail partway through the set. */
static inline void oc_transfer_consume(void *context) {
  oc_transfer_frame *frame = context;
  for (size_t i = 0; i < frame->count; ++i) {
    oc_result *result = frame->inputs[i].result;
    oc_result **position = &oc_results;
    while (*position != result) position = &(*position)->next;
    *position = result->next;
    --result->session->results;
    *frame->inputs[i].slot = NULL;
  }
  frame->consumed = 1;
}

static inline int oc_transfer_finish(oc_transfer_frame *frame, int status) {
  if (!frame->consumed) return status;
  for (size_t i = 0; i < frame->count; ++i) {
    oc_result *result = frame->inputs[i].result;
    int cleanup = ov_owner_clear(&result->native);
    if (!status) status = cleanup;
    if (lean_bridge_native_identity_release(result->key, "owned-c-result:owned-checked-records@1.0.0", result) < 0 && !status)
      status = LB_OWNED_RUNTIME;
    oc_release(result->blocks); LB_OWNED_FREE(result);
  }
  return status;
}

static inline int oc_v0_to(owned_checked_records_value_f790309465bbf573c7b9_t const *, lbov_bf60afc4a65f34b9b6ab_tf790309465bbf573c7b9 *, size_t, oc_arena *);
static inline int oc_v0_from(const lbov_bf60afc4a65f34b9b6ab_tf790309465bbf573c7b9 *, owned_checked_records_value_f790309465bbf573c7b9_t *, size_t, oc_arena *);
static inline int oc_v1_to(owned_checked_records_value_160ce821a84f6887bbfd_t const *, lbov_bf60afc4a65f34b9b6ab_t160ce821a84f6887bbfd *, size_t, oc_arena *);
static inline int oc_v1_from(const lbov_bf60afc4a65f34b9b6ab_t160ce821a84f6887bbfd *, owned_checked_records_value_160ce821a84f6887bbfd_t *, size_t, oc_arena *);
static inline int oc_v2_to(owned_checked_records_claim_closure_result_t const *, lbov_bf60afc4a65f34b9b6ab_t648974cffb2d6c1d7951 *, size_t, oc_arena *);
static inline int oc_v2_from(const lbov_bf60afc4a65f34b9b6ab_t648974cffb2d6c1d7951 *, owned_checked_records_claim_closure_result_t *, size_t, oc_arena *);
static inline int oc_v3_to(owned_checked_records_transfer_with_claim_callback_argument1_t const *, lbov_bf60afc4a65f34b9b6ab_t5035e6ea0903f12776d9 *, size_t, oc_arena *);
static inline int oc_v3_from(const lbov_bf60afc4a65f34b9b6ab_t5035e6ea0903f12776d9 *, owned_checked_records_transfer_with_claim_callback_argument1_t *, size_t, oc_arena *);
static inline int oc_v4_to(owned_checked_records_booking_t const *, lbov_bf60afc4a65f34b9b6ab_t23107461f72b24c37654 *, size_t, oc_arena *);
static inline int oc_v4_from(const lbov_bf60afc4a65f34b9b6ab_t23107461f72b24c37654 *, owned_checked_records_booking_t *, size_t, oc_arena *);
static inline int oc_v5_to(owned_checked_records_claim_t const *, lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b *, size_t, oc_arena *);
static inline int oc_v5_from(const lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b *, owned_checked_records_claim_t *, size_t, oc_arena *);
static inline int oc_v6_to(owned_checked_records_grant_t const *, lbov_bf60afc4a65f34b9b6ab_t4ce841c87ea3b1559bfb *, size_t, oc_arena *);
static inline int oc_v6_from(const lbov_bf60afc4a65f34b9b6ab_t4ce841c87ea3b1559bfb *, owned_checked_records_grant_t *, size_t, oc_arena *);
static inline int oc_v7_to(owned_checked_records_ticket_t const *, lbov_bf60afc4a65f34b9b6ab_td79b9bbde250ee1779da *, size_t, oc_arena *);
static inline int oc_v7_from(const lbov_bf60afc4a65f34b9b6ab_td79b9bbde250ee1779da *, owned_checked_records_ticket_t *, size_t, oc_arena *);
static inline int oc_v8_to(owned_checked_records_window_t const *, lbov_bf60afc4a65f34b9b6ab_t2a091437b2d587ce3891 *, size_t, oc_arena *);
static inline int oc_v8_from(const lbov_bf60afc4a65f34b9b6ab_t2a091437b2d587ce3891 *, owned_checked_records_window_t *, size_t, oc_arena *);
static inline int oc_v9_to(mpz_srcptr const *, lbov_bf60afc4a65f34b9b6ab_t167081552b6f9c1d1afd *, size_t, oc_arena *);
static inline int oc_v9_from(const lbov_bf60afc4a65f34b9b6ab_t167081552b6f9c1d1afd *, mpz_srcptr *, size_t, oc_arena *);
static inline int oc_v10_to(owned_checked_records_scalar_string_t const *, lbov_bf60afc4a65f34b9b6ab_tdc0347e1f7f5c4d928f1 *, size_t, oc_arena *);
static inline int oc_v10_from(const lbov_bf60afc4a65f34b9b6ab_tdc0347e1f7f5c4d928f1 *, owned_checked_records_scalar_string_t *, size_t, oc_arena *);
static inline int oc_v0_to(owned_checked_records_value_f790309465bbf573c7b9_t const *value, lbov_bf60afc4a65f34b9b6ab_tf790309465bbf573c7b9 *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(owned_checked_records_value_f790309465bbf573c7b9_t))) return LB_OWNED_INVALID;
  int status = ov_enter(arena->budget, value, 0, depth);
  if (status) return status;
  (void)out;
  if (value->length > arena->budget->visits) return LB_OWNED_LIMIT;
  status = ov_span(arena->budget, value->data, value->length, sizeof(owned_checked_records_claim_t), _Alignof(owned_checked_records_claim_t));
  if (status) return status;
  void *data = NULL;
  status = oc_allocate(arena, value->length, sizeof(lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b), &data);
  if (status) return status;
  lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b *items = data; out->data = data; out->length = value->length;
  for (size_t i = 0; i < value->length; ++i) {
    status = oc_v5_to(value->data + i, items + i, depth + 1, arena);
    if (status) return status;
  }
  return LB_OWNED_OK;
}
static inline int oc_v0_from(const lbov_bf60afc4a65f34b9b6ab_tf790309465bbf573c7b9 *value, owned_checked_records_value_f790309465bbf573c7b9_t *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_bf60afc4a65f34b9b6ab_tf790309465bbf573c7b9))) return OV_RESULT;
  int status = ov_enter(arena->budget, value, 0, depth);
  if (status) return status;
  (void)out;
  if (value->length > arena->budget->visits) return LB_OWNED_LIMIT;
  status = ov_span(arena->budget, value->data, value->length, sizeof(lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b), _Alignof(lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b));
  if (status) return status;
  void *data = NULL;
  status = oc_allocate(arena, value->length, sizeof(owned_checked_records_claim_t), &data);
  if (status) return status;
  owned_checked_records_claim_t *items = data; out->data = data; out->length = value->length;
  for (size_t i = 0; i < value->length; ++i) {
    status = oc_v5_from(value->data + i, items + i, depth + 1, arena);
    if (status) return status;
  }
  return LB_OWNED_OK;
}
static inline int oc_v1_to(owned_checked_records_value_160ce821a84f6887bbfd_t const *value, lbov_bf60afc4a65f34b9b6ab_t160ce821a84f6887bbfd *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(owned_checked_records_value_160ce821a84f6887bbfd_t))) return LB_OWNED_INVALID;
  int status = ov_enter(arena->budget, value, 1, depth);
  if (status) return status;
  (void)out;
  uint8_t selected; memcpy(&selected, &value->has_value, 1);
  if (selected > 1) return LB_OWNED_INVALID;
  out->tag = selected;
  if (out->tag == 1) {
  {
    void *data = NULL;
    status = oc_allocate(arena, 1, sizeof(lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b), &data);
    if (status) return status;
    out->f0 = data;
    status = oc_v5_to(value->value, data, depth + 1, arena);
    if (status) return status;
  }
  }
  return LB_OWNED_OK;
}
static inline int oc_v1_from(const lbov_bf60afc4a65f34b9b6ab_t160ce821a84f6887bbfd *value, owned_checked_records_value_160ce821a84f6887bbfd_t *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_bf60afc4a65f34b9b6ab_t160ce821a84f6887bbfd))) return OV_RESULT;
  int status = ov_enter(arena->budget, value, 1, depth);
  if (status) return status;
  (void)out;
  if (value->tag > 1) return OV_RESULT;
  out->has_value = value->tag != 0;
  if (value->tag == 1) {
  {
    void *data = NULL;
    status = oc_allocate(arena, 1, sizeof(owned_checked_records_claim_t), &data);
    if (status) return status;
    out->value = data;
    status = oc_v5_from(value->f0, data, depth + 1, arena);
    if (status) return status;
  }
  }
  return LB_OWNED_OK;
}
static inline int oc_v2_to(owned_checked_records_claim_closure_result_t const *value, lbov_bf60afc4a65f34b9b6ab_t648974cffb2d6c1d7951 *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(owned_checked_records_claim_closure_result_t))) return LB_OWNED_INVALID;
  int status = ov_enter(arena->budget, value, 2, depth);
  if (status) return status;
  (void)out;
  if (!*value) return LB_OWNED_INVALID;
  out->token = (uint64_t)(uintptr_t)*value;
  return LB_OWNED_OK;
}
static inline int oc_v2_from(const lbov_bf60afc4a65f34b9b6ab_t648974cffb2d6c1d7951 *value, owned_checked_records_claim_closure_result_t *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_bf60afc4a65f34b9b6ab_t648974cffb2d6c1d7951))) return OV_RESULT;
  int status = ov_enter(arena->budget, value, 2, depth);
  if (status) return status;
  (void)out;
  if (!value->token) return OV_RESULT;
  *out = (owned_checked_records_claim_closure_result_t)(uintptr_t)value->token;
  return LB_OWNED_OK;
}
static inline int oc_v3_to(owned_checked_records_transfer_with_claim_callback_argument1_t const *value, lbov_bf60afc4a65f34b9b6ab_t5035e6ea0903f12776d9 *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(owned_checked_records_transfer_with_claim_callback_argument1_t))) return LB_OWNED_INVALID;
  int status = ov_enter(arena->budget, value, 3, depth);
  if (status) return status;
  (void)out;
  if (!*value) return LB_OWNED_INVALID;
  out->token = (uint64_t)(uintptr_t)*value;
  return LB_OWNED_OK;
}
static inline int oc_v3_from(const lbov_bf60afc4a65f34b9b6ab_t5035e6ea0903f12776d9 *value, owned_checked_records_transfer_with_claim_callback_argument1_t *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_bf60afc4a65f34b9b6ab_t5035e6ea0903f12776d9))) return OV_RESULT;
  int status = ov_enter(arena->budget, value, 3, depth);
  if (status) return status;
  (void)out;
  if (!value->token) return OV_RESULT;
  *out = (owned_checked_records_transfer_with_claim_callback_argument1_t)(uintptr_t)value->token;
  return LB_OWNED_OK;
}
static inline int oc_v4_to(owned_checked_records_booking_t const *value, lbov_bf60afc4a65f34b9b6ab_t23107461f72b24c37654 *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(owned_checked_records_booking_t))) return LB_OWNED_INVALID;
  int status = ov_enter(arena->budget, value, 4, depth);
  if (status) return status;
  (void)out;
  {
    status = oc_v7_to(&value->holder, &out->f0, depth + 1, arena);
    if (status) return status;
  }
  {
    void *data = NULL;
    status = oc_allocate(arena, 1, sizeof(lbov_bf60afc4a65f34b9b6ab_t2a091437b2d587ce3891), &data);
    if (status) return status;
    out->f1 = data;
    status = oc_v8_to(value->window, data, depth + 1, arena);
    if (status) return status;
  }
  return LB_OWNED_OK;
}
static inline int oc_v4_from(const lbov_bf60afc4a65f34b9b6ab_t23107461f72b24c37654 *value, owned_checked_records_booking_t *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_bf60afc4a65f34b9b6ab_t23107461f72b24c37654))) return OV_RESULT;
  int status = ov_enter(arena->budget, value, 4, depth);
  if (status) return status;
  (void)out;
  {
    status = oc_v7_from(&value->f0, &out->holder, depth + 1, arena);
    if (status) return status;
  }
  {
    void *data = NULL;
    status = oc_allocate(arena, 1, sizeof(owned_checked_records_window_t), &data);
    if (status) return status;
    out->window = data;
    status = oc_v8_from(value->f1, data, depth + 1, arena);
    if (status) return status;
  }
  return LB_OWNED_OK;
}
static inline int oc_v5_to(owned_checked_records_claim_t const *value, lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(owned_checked_records_claim_t))) return LB_OWNED_INVALID;
  int status = ov_enter(arena->budget, value, 5, depth);
  if (status) return status;
  (void)out;
  {
    status = oc_v7_to(&value->holder, &out->f0, depth + 1, arena);
    if (status) return status;
  }
  {
    status = oc_v9_to(&value->quota, &out->f1, depth + 1, arena);
    if (status) return status;
  }
  return LB_OWNED_OK;
}
static inline int oc_v5_from(const lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b *value, owned_checked_records_claim_t *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b))) return OV_RESULT;
  int status = ov_enter(arena->budget, value, 5, depth);
  if (status) return status;
  (void)out;
  {
    status = oc_v7_from(&value->f0, &out->holder, depth + 1, arena);
    if (status) return status;
  }
  {
    status = oc_v9_from(&value->f1, &out->quota, depth + 1, arena);
    if (status) return status;
  }
  return LB_OWNED_OK;
}
static inline int oc_v6_to(owned_checked_records_grant_t const *value, lbov_bf60afc4a65f34b9b6ab_t4ce841c87ea3b1559bfb *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(owned_checked_records_grant_t))) return LB_OWNED_INVALID;
  int status = ov_enter(arena->budget, value, 6, depth);
  if (status) return status;
  (void)out;
  {
    status = oc_v7_to(&value->holder, &out->f0, depth + 1, arena);
    if (status) return status;
  }
  {
    status = oc_v9_to(&value->weight, &out->f1, depth + 1, arena);
    if (status) return status;
  }
  {
    status = oc_v9_to(&value->limit, &out->f2, depth + 1, arena);
    if (status) return status;
  }
  return LB_OWNED_OK;
}
static inline int oc_v6_from(const lbov_bf60afc4a65f34b9b6ab_t4ce841c87ea3b1559bfb *value, owned_checked_records_grant_t *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_bf60afc4a65f34b9b6ab_t4ce841c87ea3b1559bfb))) return OV_RESULT;
  int status = ov_enter(arena->budget, value, 6, depth);
  if (status) return status;
  (void)out;
  {
    status = oc_v7_from(&value->f0, &out->holder, depth + 1, arena);
    if (status) return status;
  }
  {
    status = oc_v9_from(&value->f1, &out->weight, depth + 1, arena);
    if (status) return status;
  }
  {
    status = oc_v9_from(&value->f2, &out->limit, depth + 1, arena);
    if (status) return status;
  }
  return LB_OWNED_OK;
}
static inline int oc_v7_to(owned_checked_records_ticket_t const *value, lbov_bf60afc4a65f34b9b6ab_td79b9bbde250ee1779da *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(owned_checked_records_ticket_t))) return LB_OWNED_INVALID;
  int status = ov_enter(arena->budget, value, 7, depth);
  if (status) return status;
  (void)out;
  if (!*value) return LB_OWNED_INVALID;
  out->token = (uint64_t)(uintptr_t)*value;
  return LB_OWNED_OK;
}
static inline int oc_v7_from(const lbov_bf60afc4a65f34b9b6ab_td79b9bbde250ee1779da *value, owned_checked_records_ticket_t *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_bf60afc4a65f34b9b6ab_td79b9bbde250ee1779da))) return OV_RESULT;
  int status = ov_enter(arena->budget, value, 7, depth);
  if (status) return status;
  (void)out;
  if (!value->token) return OV_RESULT;
  *out = (owned_checked_records_ticket_t)(uintptr_t)value->token;
  return LB_OWNED_OK;
}
static inline int oc_v8_to(owned_checked_records_window_t const *value, lbov_bf60afc4a65f34b9b6ab_t2a091437b2d587ce3891 *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(owned_checked_records_window_t))) return LB_OWNED_INVALID;
  int status = ov_enter(arena->budget, value, 8, depth);
  if (status) return status;
  (void)out;
  {
    status = oc_v9_to(&value->lo, &out->f0, depth + 1, arena);
    if (status) return status;
  }
  {
    status = oc_v9_to(&value->hi, &out->f1, depth + 1, arena);
    if (status) return status;
  }
  return LB_OWNED_OK;
}
static inline int oc_v8_from(const lbov_bf60afc4a65f34b9b6ab_t2a091437b2d587ce3891 *value, owned_checked_records_window_t *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_bf60afc4a65f34b9b6ab_t2a091437b2d587ce3891))) return OV_RESULT;
  int status = ov_enter(arena->budget, value, 8, depth);
  if (status) return status;
  (void)out;
  {
    status = oc_v9_from(&value->f0, &out->lo, depth + 1, arena);
    if (status) return status;
  }
  {
    status = oc_v9_from(&value->f1, &out->hi, depth + 1, arena);
    if (status) return status;
  }
  return LB_OWNED_OK;
}
static inline int oc_v9_to(mpz_srcptr const *value, lbov_bf60afc4a65f34b9b6ab_t167081552b6f9c1d1afd *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(mpz_srcptr))) return LB_OWNED_INVALID;
  int status = ov_enter(arena->budget, value, 9, depth);
  if (status) return status;
  (void)out;
  if (!ov_pointer(*value, sizeof(**value), _Alignof(__mpz_struct))) return LB_OWNED_INVALID;
  if (mpz_sgn(*value) < 0) return LB_OWNED_INVALID;
  if (mpz_size(*value) > arena->budget->bytes / sizeof(mp_limb_t) + 1) return LB_OWNED_LIMIT;
  size_t length = mpz_sgn(*value) ? (mpz_sizeinbase(*value, 2) - 1) / 32 + 1 : 0;
  void *data = NULL; status = oc_allocate(arena, length, sizeof(uint32_t), &data);
  if (status) return status;
  if (length) mpz_export(data, &length, -1, sizeof(uint32_t), 0, 0, *value);
  out->data = data; out->length = length;
  return LB_OWNED_OK;
}
static inline int oc_v9_from(const lbov_bf60afc4a65f34b9b6ab_t167081552b6f9c1d1afd *value, mpz_srcptr *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_bf60afc4a65f34b9b6ab_t167081552b6f9c1d1afd))) return OV_RESULT;
  int status = ov_enter(arena->budget, value, 9, depth);
  if (status) return status;
  (void)out;
  return oc_integer(arena, value->data, value->length, 0, out);
  return LB_OWNED_OK;
}
static inline int oc_v10_to(owned_checked_records_scalar_string_t const *value, lbov_bf60afc4a65f34b9b6ab_tdc0347e1f7f5c4d928f1 *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(owned_checked_records_scalar_string_t))) return LB_OWNED_INVALID;
  int status = ov_enter(arena->budget, value, 10, depth);
  if (status) return status;
  (void)out;
  status = ov_span(arena->budget, value->data, value->length, 1, 1);
  if (status) return status;
  if (!ov_utf8((const uint8_t *)value->data, value->length)) return LB_OWNED_INVALID;
  out->data = value->data; out->length = value->length;
  return LB_OWNED_OK;
}
static inline int oc_v10_from(const lbov_bf60afc4a65f34b9b6ab_tdc0347e1f7f5c4d928f1 *value, owned_checked_records_scalar_string_t *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_bf60afc4a65f34b9b6ab_tdc0347e1f7f5c4d928f1))) return OV_RESULT;
  int status = ov_enter(arena->budget, value, 10, depth);
  if (status) return status;
  (void)out;
  status = ov_span(arena->budget, value->data, value->length, 1, 1);
  if (status) return status;
  if (!ov_utf8((const uint8_t *)value->data, value->length)) return OV_RESULT;
  out->data = value->data; out->length = value->length;
  return LB_OWNED_OK;
}
typedef struct oc_host_v2 {
  owned_checked_records_claim_closure_result_t_host descriptor;
  oc_session *session;
  ov_budget *budget;
  uint64_t token;
  ov_result_owner owner;
} oc_host_v2;
static lean_object *oc_host_v2_invoke(void *context, lean_object *a0) {
  oc_host_v2 *borrow = context; ov_callback_frame *frame = ov_active_callback_frame;
  int status = !frame || frame->transaction->scope.context != &borrow->session->native ? OV_CALLBACK : frame->status;
  ov_transaction arguments = {0}; ov_result_owner argument_owner = {0};
  oc_arena views = { .budget = borrow->budget }, reply_input = { .budget = borrow->budget };
  owned_checked_records_result *reply_owner = NULL; lean_object *returned = NULL;
  lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b raw0 = {0};
  owned_checked_records_claim_t view0 = {0};
  owned_checked_records_claim_t reply = {0}; lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b raw_reply = {0};
  if (!status) status = ov_begin(&arguments, &borrow->session->native, &argument_owner, "owned-checked-records@1.0.0");
  if (!status) arguments.budget = frame->transaction->budget;
  if (!status) { status = lbov_bf60afc4a65f34b9b6ab_vb2825946e038e653bd2b_out(&raw0, a0, 0, &arguments); a0 = NULL; }
  if (arguments.scope.context) frame->transaction->budget = arguments.budget;
  if (!status) status = ov_commit(&arguments, &argument_owner);
  else if (arguments.scope.context) status = ov_abort(&arguments, status);
  if (!status) status = oc_v5_from(&raw0, &view0, 0, &views);
  if (!status) {
    owned_checked_records_status host_status = borrow->descriptor.call(borrow->descriptor.context, (owned_checked_records_session *)(uintptr_t)borrow->session->key, &view0, &reply, &reply_owner);
    if (host_status) status = OV_CALLBACK;
    if (!status) status = lb_owned_scope_ready(&frame->transaction->scope);
  }
  if (!status) status = oc_v5_to(&reply, &raw_reply, 0, &reply_input);
  if (!status) status = lbov_bf60afc4a65f34b9b6ab_vb2825946e038e653bd2b_in(&raw_reply, 0, 1, frame->transaction, &returned);
  int cleanup = owned_checked_records_result_release(&reply_owner); if (!status) status = cleanup;
  cleanup = ov_owner_clear(&argument_owner); if (!status) status = cleanup;
  oc_release(reply_input.head); oc_release(views.head);
  if (a0) lean_dec(a0);
  if (status) { ov_callback_fail(frame, status); if (returned) lean_dec(returned); return lean_alloc_array(0, 0); }
  return returned;
}
static inline int oc_host_v2_end(oc_host_v2 *borrow) {
  int status = LB_OWNED_OK;
  if (borrow->token) {
    if (lb_native_callback_wrong_thread(borrow->token)) status = LB_OWNED_THREAD;
    lb_native_callback_release(borrow->token); borrow->token = 0;
  }
  int cleanup = ov_owner_clear(&borrow->owner); return status ? status : cleanup;
}
static inline int oc_host_v2_begin(oc_host_v2 *borrow, const owned_checked_records_claim_closure_result_t_host *input, oc_session *session, ov_budget *budget, lbov_bf60afc4a65f34b9b6ab_t648974cffb2d6c1d7951 *out) {
  if (!ov_pointer(input, sizeof(*input), _Alignof(owned_checked_records_claim_closure_result_t_host))) return LB_OWNED_INVALID;
  borrow->descriptor = *input; borrow->session = session; borrow->budget = budget;
  if ((!input->call) == (!input->closure)) return LB_OWNED_INVALID;
  if (input->closure) {
    if (input->context || input->recovery) return LB_OWNED_INVALID;
    oc_arena arena = { .budget = budget };
    return oc_v2_to(&input->closure, out, 0, &arena);
  }
  borrow->token = lb_native_callback_register((void (*)(void))oc_host_v2_invoke, borrow);
  if (!borrow->token) return LB_OWNED_LIMIT;
  ov_transaction transaction = {0}; oc_arena arena = { .budget = budget };
  int status = ov_begin(&transaction, &session->native, &borrow->owner, "owned-checked-records@1.0.0");
  lean_object *recovery = NULL;
  if (!status && input->recovery) {
    lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b raw = {0}; status = oc_v5_to(input->recovery, &raw, 0, &arena);
    if (!status) status = lbov_bf60afc4a65f34b9b6ab_vb2825946e038e653bd2b_in(&raw, 0, 1, &transaction, &recovery);
  }
  if (!status) {
    if (!recovery) recovery = lean_alloc_array(0, 0);
    lean_object *closure = lean_bridge_owned_cafbd6a1f8e2dab80c6c01b5_t648974cffb2d6c1d7951_wrap((size_t)borrow->token, input->recovery ? 1 : 0, recovery);
    if (!ov_carrier(closure)) { lean_dec(closure); status = LB_OWNED_INVALID; }
    else status = lbov_bf60afc4a65f34b9b6ab_v648974cffb2d6c1d7951_out(out, closure, 0, &transaction);
  }
  oc_release(arena.head);
  if (!status) status = ov_commit(&transaction, &borrow->owner);
  else if (transaction.scope.context) status = ov_abort(&transaction, status);
  if (status) (void)oc_host_v2_end(borrow);
  return status;
}
typedef struct oc_host_v3 {
  owned_checked_records_transfer_with_claim_callback_argument1_t_host descriptor;
  oc_session *session;
  ov_budget *budget;
  uint64_t token;
  ov_result_owner owner;
} oc_host_v3;
static lean_object *oc_host_v3_invoke(void *context, lean_object *a0) {
  oc_host_v3 *borrow = context; ov_callback_frame *frame = ov_active_callback_frame;
  int status = !frame || frame->transaction->scope.context != &borrow->session->native ? OV_CALLBACK : frame->status;
  ov_transaction arguments = {0}; ov_result_owner argument_owner = {0};
  oc_arena views = { .budget = borrow->budget }, reply_input = { .budget = borrow->budget };
  owned_checked_records_result *reply_owner = NULL; lean_object *returned = NULL;
  lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b raw0 = {0};
  owned_checked_records_claim_t view0 = {0};
  owned_checked_records_claim_t reply = {0}; lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b raw_reply = {0};
  if (!status) status = ov_begin(&arguments, &borrow->session->native, &argument_owner, "owned-checked-records@1.0.0");
  if (!status) arguments.budget = frame->transaction->budget;
  if (!status) { status = lbov_bf60afc4a65f34b9b6ab_vb2825946e038e653bd2b_out(&raw0, a0, 0, &arguments); a0 = NULL; }
  if (arguments.scope.context) frame->transaction->budget = arguments.budget;
  if (!status) status = ov_commit(&arguments, &argument_owner);
  else if (arguments.scope.context) status = ov_abort(&arguments, status);
  if (!status) status = oc_v5_from(&raw0, &view0, 0, &views);
  if (!status) {
    owned_checked_records_status host_status = borrow->descriptor.call(borrow->descriptor.context, (owned_checked_records_session *)(uintptr_t)borrow->session->key, &view0, &reply, &reply_owner);
    if (host_status) status = OV_CALLBACK;
    if (!status) status = lb_owned_scope_ready(&frame->transaction->scope);
  }
  if (!status) status = oc_v5_to(&reply, &raw_reply, 0, &reply_input);
  if (!status) status = lbov_bf60afc4a65f34b9b6ab_vb2825946e038e653bd2b_in(&raw_reply, 0, 1, frame->transaction, &returned);
  if (!status) { lean_inc(returned); if (!lean_bridge_owned_refine_ca177b2570793a278657(returned)) { lean_dec(returned); returned = NULL; status = LB_OWNED_INVALID; } }
  int cleanup = owned_checked_records_result_release(&reply_owner); if (!status) status = cleanup;
  cleanup = ov_owner_clear(&argument_owner); if (!status) status = cleanup;
  oc_release(reply_input.head); oc_release(views.head);
  if (a0) lean_dec(a0);
  if (status) { ov_callback_fail(frame, status); if (returned) lean_dec(returned); return lean_alloc_array(0, 0); }
  return returned;
}
static inline int oc_host_v3_end(oc_host_v3 *borrow) {
  int status = LB_OWNED_OK;
  if (borrow->token) {
    if (lb_native_callback_wrong_thread(borrow->token)) status = LB_OWNED_THREAD;
    lb_native_callback_release(borrow->token); borrow->token = 0;
  }
  int cleanup = ov_owner_clear(&borrow->owner); return status ? status : cleanup;
}
static inline int oc_host_v3_begin(oc_host_v3 *borrow, const owned_checked_records_transfer_with_claim_callback_argument1_t_host *input, oc_session *session, ov_budget *budget, lbov_bf60afc4a65f34b9b6ab_t5035e6ea0903f12776d9 *out) {
  if (!ov_pointer(input, sizeof(*input), _Alignof(owned_checked_records_transfer_with_claim_callback_argument1_t_host))) return LB_OWNED_INVALID;
  borrow->descriptor = *input; borrow->session = session; borrow->budget = budget;
  if ((!input->call) == (!input->closure)) return LB_OWNED_INVALID;
  if (input->closure) {
    if (input->context || input->recovery) return LB_OWNED_INVALID;
    oc_arena arena = { .budget = budget };
    return oc_v3_to(&input->closure, out, 0, &arena);
  }
  borrow->token = lb_native_callback_register((void (*)(void))oc_host_v3_invoke, borrow);
  if (!borrow->token) return LB_OWNED_LIMIT;
  ov_transaction transaction = {0}; oc_arena arena = { .budget = budget };
  int status = ov_begin(&transaction, &session->native, &borrow->owner, "owned-checked-records@1.0.0");
  lean_object *recovery = NULL;
  if (!status && input->recovery) {
    lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b raw = {0}; status = oc_v5_to(input->recovery, &raw, 0, &arena);
    if (!status) status = lbov_bf60afc4a65f34b9b6ab_vb2825946e038e653bd2b_in(&raw, 0, 1, &transaction, &recovery);
    if (!status) { lean_inc(recovery); if (!lean_bridge_owned_refine_ca177b2570793a278657(recovery)) { lean_dec(recovery); recovery = NULL; status = LB_OWNED_INVALID; } }
  }
  if (!status) {
    if (!recovery) recovery = lean_alloc_array(0, 0);
    lean_object *closure = lean_bridge_owned_cafbd6a1f8e2dab80c6c01b5_t5035e6ea0903f12776d9_wrap((size_t)borrow->token, input->recovery ? 1 : 0, recovery);
    if (!ov_carrier(closure)) { lean_dec(closure); status = LB_OWNED_INVALID; }
    else status = lbov_bf60afc4a65f34b9b6ab_v5035e6ea0903f12776d9_out(out, closure, 0, &transaction);
  }
  oc_release(arena.head);
  if (!status) status = ov_commit(&transaction, &borrow->owner);
  else if (transaction.scope.context) status = ov_abort(&transaction, status);
  if (status) (void)oc_host_v3_end(borrow);
  return status;
}

static inline int lbov_bf60afc4a65f34b9b6ab_v648974cffb2d6c1d7951_retain(lb_owned_context *context, const lbov_bf60afc4a65f34b9b6ab_t648974cffb2d6c1d7951 *input, lbov_bf60afc4a65f34b9b6ab_t648974cffb2d6c1d7951 *out, ov_result_owner *owner) {
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  lean_object *value = NULL;
  status = lbov_bf60afc4a65f34b9b6ab_v648974cffb2d6c1d7951_in(input, 0, 1, &transaction, &value);
  if (status) return ov_abort(&transaction, status);
  status = lbov_bf60afc4a65f34b9b6ab_v648974cffb2d6c1d7951_out(out, value, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  return ov_commit(&transaction, owner);
}
static inline int lbov_bf60afc4a65f34b9b6ab_v5035e6ea0903f12776d9_retain(lb_owned_context *context, const lbov_bf60afc4a65f34b9b6ab_t5035e6ea0903f12776d9 *input, lbov_bf60afc4a65f34b9b6ab_t5035e6ea0903f12776d9 *out, ov_result_owner *owner) {
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  lean_object *value = NULL;
  status = lbov_bf60afc4a65f34b9b6ab_v5035e6ea0903f12776d9_in(input, 0, 1, &transaction, &value);
  if (status) return ov_abort(&transaction, status);
  status = lbov_bf60afc4a65f34b9b6ab_v5035e6ea0903f12776d9_out(out, value, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  return ov_commit(&transaction, owner);
}
static inline int lbov_bf60afc4a65f34b9b6ab_vd79b9bbde250ee1779da_retain(lb_owned_context *context, const lbov_bf60afc4a65f34b9b6ab_td79b9bbde250ee1779da *input, lbov_bf60afc4a65f34b9b6ab_td79b9bbde250ee1779da *out, ov_result_owner *owner) {
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  lean_object *value = NULL;
  status = lbov_bf60afc4a65f34b9b6ab_vd79b9bbde250ee1779da_in(input, 0, 1, &transaction, &value);
  if (status) return ov_abort(&transaction, status);
  status = lbov_bf60afc4a65f34b9b6ab_vd79b9bbde250ee1779da_out(out, value, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  return ov_commit(&transaction, owner);
}
static inline int lbov_bf60afc4a65f34b9b6ab_vf790309465bbf573c7b9_retain(lb_owned_context *context, const lbov_bf60afc4a65f34b9b6ab_tf790309465bbf573c7b9 *input, lbov_bf60afc4a65f34b9b6ab_tf790309465bbf573c7b9 *out, ov_result_owner *owner) {
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  lean_object *value = NULL;
  status = lbov_bf60afc4a65f34b9b6ab_vf790309465bbf573c7b9_in(input, 0, 1, &transaction, &value);
  if (status) return ov_abort(&transaction, status);
  status = lbov_bf60afc4a65f34b9b6ab_vf790309465bbf573c7b9_out(out, value, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  return ov_commit(&transaction, owner);
}
static inline int lbov_bf60afc4a65f34b9b6ab_v160ce821a84f6887bbfd_retain(lb_owned_context *context, const lbov_bf60afc4a65f34b9b6ab_t160ce821a84f6887bbfd *input, lbov_bf60afc4a65f34b9b6ab_t160ce821a84f6887bbfd *out, ov_result_owner *owner) {
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  lean_object *value = NULL;
  status = lbov_bf60afc4a65f34b9b6ab_v160ce821a84f6887bbfd_in(input, 0, 1, &transaction, &value);
  if (status) return ov_abort(&transaction, status);
  status = lbov_bf60afc4a65f34b9b6ab_v160ce821a84f6887bbfd_out(out, value, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  return ov_commit(&transaction, owner);
}
static inline int lbov_bf60afc4a65f34b9b6ab_v23107461f72b24c37654_retain(lb_owned_context *context, const lbov_bf60afc4a65f34b9b6ab_t23107461f72b24c37654 *input, lbov_bf60afc4a65f34b9b6ab_t23107461f72b24c37654 *out, ov_result_owner *owner) {
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  lean_object *value = NULL;
  status = lbov_bf60afc4a65f34b9b6ab_v23107461f72b24c37654_in(input, 0, 1, &transaction, &value);
  if (status) return ov_abort(&transaction, status);
  status = lbov_bf60afc4a65f34b9b6ab_v23107461f72b24c37654_out(out, value, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  return ov_commit(&transaction, owner);
}
static inline int lbov_bf60afc4a65f34b9b6ab_vb2825946e038e653bd2b_retain(lb_owned_context *context, const lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b *input, lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b *out, ov_result_owner *owner) {
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  lean_object *value = NULL;
  status = lbov_bf60afc4a65f34b9b6ab_vb2825946e038e653bd2b_in(input, 0, 1, &transaction, &value);
  if (status) return ov_abort(&transaction, status);
  status = lbov_bf60afc4a65f34b9b6ab_vb2825946e038e653bd2b_out(out, value, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  return ov_commit(&transaction, owner);
}
static inline int lbov_bf60afc4a65f34b9b6ab_v4ce841c87ea3b1559bfb_retain(lb_owned_context *context, const lbov_bf60afc4a65f34b9b6ab_t4ce841c87ea3b1559bfb *input, lbov_bf60afc4a65f34b9b6ab_t4ce841c87ea3b1559bfb *out, ov_result_owner *owner) {
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  lean_object *value = NULL;
  status = lbov_bf60afc4a65f34b9b6ab_v4ce841c87ea3b1559bfb_in(input, 0, 1, &transaction, &value);
  if (status) return ov_abort(&transaction, status);
  status = lbov_bf60afc4a65f34b9b6ab_v4ce841c87ea3b1559bfb_out(out, value, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  return ov_commit(&transaction, owner);
}
static inline int lbov_bf60afc4a65f34b9b6ab_v2a091437b2d587ce3891_retain(lb_owned_context *context, const lbov_bf60afc4a65f34b9b6ab_t2a091437b2d587ce3891 *input, lbov_bf60afc4a65f34b9b6ab_t2a091437b2d587ce3891 *out, ov_result_owner *owner) {
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  lean_object *value = NULL;
  status = lbov_bf60afc4a65f34b9b6ab_v2a091437b2d587ce3891_in(input, 0, 1, &transaction, &value);
  if (status) return ov_abort(&transaction, status);
  status = lbov_bf60afc4a65f34b9b6ab_v2a091437b2d587ce3891_out(out, value, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  return ov_commit(&transaction, owner);
}
static inline int lbov_bf60afc4a65f34b9b6ab_v167081552b6f9c1d1afd_retain(lb_owned_context *context, const lbov_bf60afc4a65f34b9b6ab_t167081552b6f9c1d1afd *input, lbov_bf60afc4a65f34b9b6ab_t167081552b6f9c1d1afd *out, ov_result_owner *owner) {
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  lean_object *value = NULL;
  status = lbov_bf60afc4a65f34b9b6ab_v167081552b6f9c1d1afd_in(input, 0, 1, &transaction, &value);
  if (status) return ov_abort(&transaction, status);
  status = lbov_bf60afc4a65f34b9b6ab_v167081552b6f9c1d1afd_out(out, value, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  return ov_commit(&transaction, owner);
}
static inline int lbov_bf60afc4a65f34b9b6ab_vdc0347e1f7f5c4d928f1_retain(lb_owned_context *context, const lbov_bf60afc4a65f34b9b6ab_tdc0347e1f7f5c4d928f1 *input, lbov_bf60afc4a65f34b9b6ab_tdc0347e1f7f5c4d928f1 *out, ov_result_owner *owner) {
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  lean_object *value = NULL;
  status = lbov_bf60afc4a65f34b9b6ab_vdc0347e1f7f5c4d928f1_in(input, 0, 1, &transaction, &value);
  if (status) return ov_abort(&transaction, status);
  status = lbov_bf60afc4a65f34b9b6ab_vdc0347e1f7f5c4d928f1_out(out, value, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  return ov_commit(&transaction, owner);
}
owned_checked_records_status owned_checked_records_booking_span(owned_checked_records_session *session, owned_checked_records_booking_t const * a0, mpz_srcptr *out, owned_checked_records_result **owner) {
  if (!oc_outputs(out, sizeof(*out), _Alignof(mpz_srcptr), owner) || *owner) return (owned_checked_records_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_status)status;
  lbov_bf60afc4a65f34b9b6ab_t23107461f72b24c37654 raw0 = {0};
  lbov_bf60afc4a65f34b9b6ab_t167081552b6f9c1d1afd returned = {0};
  mpz_srcptr converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v4_to(a0, &raw0, 0, &input);
  if (!status) status = lbov_bf60afc4a65f34b9b6ab_f61fa6d001212787ff6aa(&active->native, &raw0, &returned, &result_owner->native);
  if (!status) {
    status = oc_v9_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_status)status;
}
owned_checked_records_status owned_checked_records_claim_closure(owned_checked_records_session *session, owned_checked_records_claim_closure_result_t *out, owned_checked_records_result **owner) {
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_checked_records_claim_closure_result_t), owner) || *owner) return (owned_checked_records_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_status)status;
  lbov_bf60afc4a65f34b9b6ab_t648974cffb2d6c1d7951 returned = {0};
  owned_checked_records_claim_closure_result_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = lbov_bf60afc4a65f34b9b6ab_fa3218a29f42862f9b113(&active->native, &returned, &result_owner->native);
  if (!status) {
    status = oc_v2_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_status)status;
}
owned_checked_records_status owned_checked_records_claim_for(owned_checked_records_session *session, owned_checked_records_ticket_t a0, owned_checked_records_value_160ce821a84f6887bbfd_t *out, owned_checked_records_result **owner) {
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_checked_records_value_160ce821a84f6887bbfd_t), owner) || *owner) return (owned_checked_records_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_status)status;
  lbov_bf60afc4a65f34b9b6ab_td79b9bbde250ee1779da raw0 = {0};
  lbov_bf60afc4a65f34b9b6ab_t160ce821a84f6887bbfd returned = {0};
  owned_checked_records_value_160ce821a84f6887bbfd_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v7_to(&a0, &raw0, 0, &input);
  if (!status) status = lbov_bf60afc4a65f34b9b6ab_f483485736ace9af57086(&active->native, &raw0, &returned, &result_owner->native);
  if (!status) {
    status = oc_v1_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_status)status;
}
owned_checked_records_status owned_checked_records_claim_quota(owned_checked_records_session *session, owned_checked_records_claim_t const * a0, mpz_srcptr *out, owned_checked_records_result **owner) {
  if (!oc_outputs(out, sizeof(*out), _Alignof(mpz_srcptr), owner) || *owner) return (owned_checked_records_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_status)status;
  lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b raw0 = {0};
  lbov_bf60afc4a65f34b9b6ab_t167081552b6f9c1d1afd returned = {0};
  mpz_srcptr converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v5_to(a0, &raw0, 0, &input);
  if (!status) status = lbov_bf60afc4a65f34b9b6ab_f2f69e4eb3cbfdff310da(&active->native, &raw0, &returned, &result_owner->native);
  if (!status) {
    status = oc_v9_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_status)status;
}
owned_checked_records_status owned_checked_records_echo_booking(owned_checked_records_session *session, owned_checked_records_booking_t const * a0, owned_checked_records_booking_t *out, owned_checked_records_result **owner) {
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_checked_records_booking_t), owner) || *owner) return (owned_checked_records_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_status)status;
  lbov_bf60afc4a65f34b9b6ab_t23107461f72b24c37654 raw0 = {0};
  lbov_bf60afc4a65f34b9b6ab_t23107461f72b24c37654 returned = {0};
  owned_checked_records_booking_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v4_to(a0, &raw0, 0, &input);
  if (!status) status = lbov_bf60afc4a65f34b9b6ab_f0711e856cfa97d876c9a(&active->native, &raw0, &returned, &result_owner->native);
  if (!status) {
    status = oc_v4_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_status)status;
}
owned_checked_records_status owned_checked_records_echo_claim(owned_checked_records_session *session, owned_checked_records_claim_t const * a0, owned_checked_records_claim_t *out, owned_checked_records_result **owner) {
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_checked_records_claim_t), owner) || *owner) return (owned_checked_records_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_status)status;
  lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b raw0 = {0};
  lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b returned = {0};
  owned_checked_records_claim_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v5_to(a0, &raw0, 0, &input);
  if (!status) status = lbov_bf60afc4a65f34b9b6ab_f535babcfd8d0f67ea0e6(&active->native, &raw0, &returned, &result_owner->native);
  if (!status) {
    status = oc_v5_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_status)status;
}
owned_checked_records_status owned_checked_records_echo_claims(owned_checked_records_session *session, owned_checked_records_value_f790309465bbf573c7b9_t const * a0, owned_checked_records_value_f790309465bbf573c7b9_t *out, owned_checked_records_result **owner) {
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_checked_records_value_f790309465bbf573c7b9_t), owner) || *owner) return (owned_checked_records_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_status)status;
  lbov_bf60afc4a65f34b9b6ab_tf790309465bbf573c7b9 raw0 = {0};
  lbov_bf60afc4a65f34b9b6ab_tf790309465bbf573c7b9 returned = {0};
  owned_checked_records_value_f790309465bbf573c7b9_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v0_to(a0, &raw0, 0, &input);
  if (!status) status = lbov_bf60afc4a65f34b9b6ab_f25326d75f45c4daa9d9d(&active->native, &raw0, &returned, &result_owner->native);
  if (!status) {
    status = oc_v0_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_status)status;
}
owned_checked_records_status owned_checked_records_echo_grant(owned_checked_records_session *session, owned_checked_records_grant_t const * a0, owned_checked_records_grant_t *out, owned_checked_records_result **owner) {
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_checked_records_grant_t), owner) || *owner) return (owned_checked_records_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_status)status;
  lbov_bf60afc4a65f34b9b6ab_t4ce841c87ea3b1559bfb raw0 = {0};
  lbov_bf60afc4a65f34b9b6ab_t4ce841c87ea3b1559bfb returned = {0};
  owned_checked_records_grant_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v6_to(a0, &raw0, 0, &input);
  if (!status) status = lbov_bf60afc4a65f34b9b6ab_feb082cf837ef02082ea8(&active->native, &raw0, &returned, &result_owner->native);
  if (!status) {
    status = oc_v6_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_status)status;
}
owned_checked_records_status owned_checked_records_new_ticket(owned_checked_records_session *session, mpz_srcptr a0, owned_checked_records_scalar_string_t a1, owned_checked_records_ticket_t *out, owned_checked_records_result **owner) {
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_checked_records_ticket_t), owner) || *owner) return (owned_checked_records_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_status)status;
  lbov_bf60afc4a65f34b9b6ab_t167081552b6f9c1d1afd raw0 = {0};
  lbov_bf60afc4a65f34b9b6ab_tdc0347e1f7f5c4d928f1 raw1 = {0};
  lbov_bf60afc4a65f34b9b6ab_td79b9bbde250ee1779da returned = {0};
  owned_checked_records_ticket_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v9_to(&a0, &raw0, 0, &input);
  if (!status) status = oc_v10_to(&a1, &raw1, 0, &input);
  if (!status) status = lbov_bf60afc4a65f34b9b6ab_fa1e5189bd92568e4b939(&active->native, &raw0, &raw1, &returned, &result_owner->native);
  if (!status) {
    status = oc_v7_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_status)status;
}
owned_checked_records_status owned_checked_records_pair_claim(owned_checked_records_session *session, owned_checked_records_booking_t const * a0, owned_checked_records_claim_t const * a1, owned_checked_records_claim_t *out, owned_checked_records_result **owner) {
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_checked_records_claim_t), owner) || *owner) return (owned_checked_records_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_status)status;
  lbov_bf60afc4a65f34b9b6ab_t23107461f72b24c37654 raw0 = {0};
  lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b raw1 = {0};
  lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b returned = {0};
  owned_checked_records_claim_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v4_to(a0, &raw0, 0, &input);
  if (!status) status = oc_v5_to(a1, &raw1, 0, &input);
  if (!status) status = lbov_bf60afc4a65f34b9b6ab_feaac3cc8d9197bd7bbca(&active->native, &raw0, &raw1, &returned, &result_owner->native);
  if (!status) {
    status = oc_v5_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_status)status;
}
owned_checked_records_status owned_checked_records_serial(owned_checked_records_session *session, owned_checked_records_ticket_t a0, mpz_srcptr *out, owned_checked_records_result **owner) {
  if (!oc_outputs(out, sizeof(*out), _Alignof(mpz_srcptr), owner) || *owner) return (owned_checked_records_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_status)status;
  lbov_bf60afc4a65f34b9b6ab_td79b9bbde250ee1779da raw0 = {0};
  lbov_bf60afc4a65f34b9b6ab_t167081552b6f9c1d1afd returned = {0};
  mpz_srcptr converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v7_to(&a0, &raw0, 0, &input);
  if (!status) status = lbov_bf60afc4a65f34b9b6ab_fec926afda994fba3abe2(&active->native, &raw0, &returned, &result_owner->native);
  if (!status) {
    status = oc_v9_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_status)status;
}
owned_checked_records_status owned_checked_records_transfer_claim(owned_checked_records_session *session, owned_checked_records_claim_t const * a0, owned_checked_records_result **a0_owner, owned_checked_records_claim_t *out, owned_checked_records_result **owner) {
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_checked_records_claim_t), owner) || *owner) return (owned_checked_records_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_status)status;
  oc_transfer_input transfer_inputs[1] = { { .slot = a0_owner } };
  ov_result_owner *transfer_owners[1] = {0};
  oc_transfer_frame transfer_frame = { .inputs = transfer_inputs, .count = 1 };
  ov_input_transfers transfer = { .owners = transfer_owners, .count = 1, .consume = oc_transfer_consume, .context = &transfer_frame };
  lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b raw0 = {0};
  lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b returned = {0};
  owned_checked_records_claim_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_transfer_prepare(active, &transfer_frame, transfer_owners, out, sizeof(*out), _Alignof(owned_checked_records_claim_t), owner);
  if (!status) status = oc_v5_to(a0, &raw0, 0, &input);
  if (!status) status = lbov_bf60afc4a65f34b9b6ab_f040aca3025d850fc12cc(&active->native, &raw0, &transfer, &returned, &result_owner->native);
  if (!status) {
    status = oc_v5_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_transfer_finish(&transfer_frame, status);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_status)status;
}
owned_checked_records_status owned_checked_records_transfer_pair_claim(owned_checked_records_session *session, owned_checked_records_booking_t const * a0, owned_checked_records_result **a0_owner, owned_checked_records_claim_t const * a1, owned_checked_records_result **a1_owner, owned_checked_records_claim_t *out, owned_checked_records_result **owner) {
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_checked_records_claim_t), owner) || *owner) return (owned_checked_records_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_status)status;
  oc_transfer_input transfer_inputs[2] = { { .slot = a0_owner }, { .slot = a1_owner } };
  ov_result_owner *transfer_owners[2] = {0};
  oc_transfer_frame transfer_frame = { .inputs = transfer_inputs, .count = 2 };
  ov_input_transfers transfer = { .owners = transfer_owners, .count = 2, .consume = oc_transfer_consume, .context = &transfer_frame };
  lbov_bf60afc4a65f34b9b6ab_t23107461f72b24c37654 raw0 = {0};
  lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b raw1 = {0};
  lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b returned = {0};
  owned_checked_records_claim_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_transfer_prepare(active, &transfer_frame, transfer_owners, out, sizeof(*out), _Alignof(owned_checked_records_claim_t), owner);
  if (!status) status = oc_v4_to(a0, &raw0, 0, &input);
  if (!status) status = oc_v5_to(a1, &raw1, 0, &input);
  if (!status) status = lbov_bf60afc4a65f34b9b6ab_fc4cffe83b4b420b09021(&active->native, &raw0, &raw1, &transfer, &returned, &result_owner->native);
  if (!status) {
    status = oc_v5_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_transfer_finish(&transfer_frame, status);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_status)status;
}
owned_checked_records_status owned_checked_records_transfer_with_claim_callback(owned_checked_records_session *session, owned_checked_records_claim_t const * a0, owned_checked_records_result **a0_owner, owned_checked_records_transfer_with_claim_callback_argument1_t_host const * a1, owned_checked_records_claim_t *out, owned_checked_records_result **owner) {
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_checked_records_claim_t), owner) || *owner) return (owned_checked_records_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_status)status;
  oc_transfer_input transfer_inputs[1] = { { .slot = a0_owner } };
  ov_result_owner *transfer_owners[1] = {0};
  oc_transfer_frame transfer_frame = { .inputs = transfer_inputs, .count = 1 };
  ov_input_transfers transfer = { .owners = transfer_owners, .count = 1, .consume = oc_transfer_consume, .context = &transfer_frame };
  lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b raw0 = {0};
  lbov_bf60afc4a65f34b9b6ab_t5035e6ea0903f12776d9 raw1 = {0};
  oc_host_v3 borrow1 = {0};
  lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b returned = {0};
  owned_checked_records_claim_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_transfer_prepare(active, &transfer_frame, transfer_owners, out, sizeof(*out), _Alignof(owned_checked_records_claim_t), owner);
  if (!status) status = oc_v5_to(a0, &raw0, 0, &input);
  if (!status) status = oc_host_v3_begin(&borrow1, a1, active, &budget, &raw1);
  if (!status) status = lbov_bf60afc4a65f34b9b6ab_f33442f0a4409864e6a4a(&active->native, &raw0, &raw1, &transfer, &returned, &result_owner->native);
  { int cleanup = oc_host_v3_end(&borrow1); if (!status) status = cleanup; }
  if (!status) {
    status = oc_v5_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_transfer_finish(&transfer_frame, status);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_status)status;
}
owned_checked_records_status owned_checked_records_with_claim_callback(owned_checked_records_session *session, owned_checked_records_claim_t const * a0, owned_checked_records_transfer_with_claim_callback_argument1_t_host const * a1, owned_checked_records_claim_t *out, owned_checked_records_result **owner) {
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_checked_records_claim_t), owner) || *owner) return (owned_checked_records_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_status)status;
  lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b raw0 = {0};
  lbov_bf60afc4a65f34b9b6ab_t5035e6ea0903f12776d9 raw1 = {0};
  oc_host_v3 borrow1 = {0};
  lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b returned = {0};
  owned_checked_records_claim_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v5_to(a0, &raw0, 0, &input);
  if (!status) status = oc_host_v3_begin(&borrow1, a1, active, &budget, &raw1);
  if (!status) status = lbov_bf60afc4a65f34b9b6ab_f7d6c8617a0788c12de15(&active->native, &raw0, &raw1, &returned, &result_owner->native);
  { int cleanup = oc_host_v3_end(&borrow1); if (!status) status = cleanup; }
  if (!status) {
    status = oc_v5_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_status)status;
}
owned_checked_records_status owned_checked_records_claim_closure_result_t_call(owned_checked_records_session *session, owned_checked_records_claim_closure_result_t a0, owned_checked_records_claim_t const * a1, owned_checked_records_claim_t *out, owned_checked_records_result **owner) {
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_checked_records_claim_t), owner) || *owner) return (owned_checked_records_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_status)status;
  lbov_bf60afc4a65f34b9b6ab_t648974cffb2d6c1d7951 raw0 = {0};
  lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b raw1 = {0};
  lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b returned = {0};
  owned_checked_records_claim_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v2_to(&a0, &raw0, 0, &input);
  if (!status) status = oc_v5_to(a1, &raw1, 0, &input);
  if (!status) status = lbov_bf60afc4a65f34b9b6ab_v648974cffb2d6c1d7951_apply(&active->native, &raw0, &raw1, &returned, &result_owner->native);
  if (!status) {
    status = oc_v5_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_status)status;
}
owned_checked_records_status owned_checked_records_transfer_with_claim_callback_argument1_t_call(owned_checked_records_session *session, owned_checked_records_transfer_with_claim_callback_argument1_t a0, owned_checked_records_claim_t const * a1, owned_checked_records_claim_t *out, owned_checked_records_result **owner) {
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_checked_records_claim_t), owner) || *owner) return (owned_checked_records_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_status)status;
  lbov_bf60afc4a65f34b9b6ab_t5035e6ea0903f12776d9 raw0 = {0};
  lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b raw1 = {0};
  lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b returned = {0};
  owned_checked_records_claim_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v3_to(&a0, &raw0, 0, &input);
  if (!status) status = oc_v5_to(a1, &raw1, 0, &input);
  if (!status) status = lbov_bf60afc4a65f34b9b6ab_v5035e6ea0903f12776d9_apply(&active->native, &raw0, &raw1, &returned, &result_owner->native);
  if (!status) {
    status = oc_v5_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_status)status;
}
owned_checked_records_status owned_checked_records_claim_closure_result_t_retain(owned_checked_records_session *session, owned_checked_records_claim_closure_result_t a0, owned_checked_records_claim_closure_result_t *out, owned_checked_records_result **owner) {
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_checked_records_claim_closure_result_t), owner) || *owner) return (owned_checked_records_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_status)status;
  lbov_bf60afc4a65f34b9b6ab_t648974cffb2d6c1d7951 raw0 = {0};
  lbov_bf60afc4a65f34b9b6ab_t648974cffb2d6c1d7951 returned = {0};
  owned_checked_records_claim_closure_result_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v2_to(&a0, &raw0, 0, &input);
  if (!status) status = lbov_bf60afc4a65f34b9b6ab_v648974cffb2d6c1d7951_retain(&active->native, &raw0, &returned, &result_owner->native);
  if (!status) {
    status = oc_v2_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_status)status;
}
owned_checked_records_status owned_checked_records_transfer_with_claim_callback_argument1_t_retain(owned_checked_records_session *session, owned_checked_records_transfer_with_claim_callback_argument1_t a0, owned_checked_records_transfer_with_claim_callback_argument1_t *out, owned_checked_records_result **owner) {
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_checked_records_transfer_with_claim_callback_argument1_t), owner) || *owner) return (owned_checked_records_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_status)status;
  lbov_bf60afc4a65f34b9b6ab_t5035e6ea0903f12776d9 raw0 = {0};
  lbov_bf60afc4a65f34b9b6ab_t5035e6ea0903f12776d9 returned = {0};
  owned_checked_records_transfer_with_claim_callback_argument1_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v3_to(&a0, &raw0, 0, &input);
  if (!status) status = lbov_bf60afc4a65f34b9b6ab_v5035e6ea0903f12776d9_retain(&active->native, &raw0, &returned, &result_owner->native);
  if (!status) {
    status = oc_v3_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_status)status;
}
owned_checked_records_status owned_checked_records_ticket_t_retain(owned_checked_records_session *session, owned_checked_records_ticket_t a0, owned_checked_records_ticket_t *out, owned_checked_records_result **owner) {
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_checked_records_ticket_t), owner) || *owner) return (owned_checked_records_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_status)status;
  lbov_bf60afc4a65f34b9b6ab_td79b9bbde250ee1779da raw0 = {0};
  lbov_bf60afc4a65f34b9b6ab_td79b9bbde250ee1779da returned = {0};
  owned_checked_records_ticket_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v7_to(&a0, &raw0, 0, &input);
  if (!status) status = lbov_bf60afc4a65f34b9b6ab_vd79b9bbde250ee1779da_retain(&active->native, &raw0, &returned, &result_owner->native);
  if (!status) {
    status = oc_v7_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_status)status;
}
owned_checked_records_status owned_checked_records_value_f790309465bbf573c7b9_t_copy(owned_checked_records_session *session, owned_checked_records_value_f790309465bbf573c7b9_t const * a0, owned_checked_records_value_f790309465bbf573c7b9_t *out, owned_checked_records_result **owner) {
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_checked_records_value_f790309465bbf573c7b9_t), owner) || *owner) return (owned_checked_records_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_status)status;
  lbov_bf60afc4a65f34b9b6ab_tf790309465bbf573c7b9 raw0 = {0};
  lbov_bf60afc4a65f34b9b6ab_tf790309465bbf573c7b9 returned = {0};
  owned_checked_records_value_f790309465bbf573c7b9_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v0_to(a0, &raw0, 0, &input);
  if (!status) status = lbov_bf60afc4a65f34b9b6ab_vf790309465bbf573c7b9_retain(&active->native, &raw0, &returned, &result_owner->native);
  if (!status) {
    status = oc_v0_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_status)status;
}
owned_checked_records_status owned_checked_records_value_160ce821a84f6887bbfd_t_copy(owned_checked_records_session *session, owned_checked_records_value_160ce821a84f6887bbfd_t const * a0, owned_checked_records_value_160ce821a84f6887bbfd_t *out, owned_checked_records_result **owner) {
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_checked_records_value_160ce821a84f6887bbfd_t), owner) || *owner) return (owned_checked_records_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_status)status;
  lbov_bf60afc4a65f34b9b6ab_t160ce821a84f6887bbfd raw0 = {0};
  lbov_bf60afc4a65f34b9b6ab_t160ce821a84f6887bbfd returned = {0};
  owned_checked_records_value_160ce821a84f6887bbfd_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v1_to(a0, &raw0, 0, &input);
  if (!status) status = lbov_bf60afc4a65f34b9b6ab_v160ce821a84f6887bbfd_retain(&active->native, &raw0, &returned, &result_owner->native);
  if (!status) {
    status = oc_v1_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_status)status;
}
owned_checked_records_status owned_checked_records_booking_t_copy(owned_checked_records_session *session, owned_checked_records_booking_t const * a0, owned_checked_records_booking_t *out, owned_checked_records_result **owner) {
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_checked_records_booking_t), owner) || *owner) return (owned_checked_records_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_status)status;
  lbov_bf60afc4a65f34b9b6ab_t23107461f72b24c37654 raw0 = {0};
  lbov_bf60afc4a65f34b9b6ab_t23107461f72b24c37654 returned = {0};
  owned_checked_records_booking_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v4_to(a0, &raw0, 0, &input);
  if (!status) status = lbov_bf60afc4a65f34b9b6ab_v23107461f72b24c37654_retain(&active->native, &raw0, &returned, &result_owner->native);
  if (!status) {
    status = oc_v4_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_status)status;
}
owned_checked_records_status owned_checked_records_claim_t_copy(owned_checked_records_session *session, owned_checked_records_claim_t const * a0, owned_checked_records_claim_t *out, owned_checked_records_result **owner) {
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_checked_records_claim_t), owner) || *owner) return (owned_checked_records_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_status)status;
  lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b raw0 = {0};
  lbov_bf60afc4a65f34b9b6ab_tb2825946e038e653bd2b returned = {0};
  owned_checked_records_claim_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v5_to(a0, &raw0, 0, &input);
  if (!status) status = lbov_bf60afc4a65f34b9b6ab_vb2825946e038e653bd2b_retain(&active->native, &raw0, &returned, &result_owner->native);
  if (!status) {
    status = oc_v5_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_status)status;
}
owned_checked_records_status owned_checked_records_grant_t_copy(owned_checked_records_session *session, owned_checked_records_grant_t const * a0, owned_checked_records_grant_t *out, owned_checked_records_result **owner) {
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_checked_records_grant_t), owner) || *owner) return (owned_checked_records_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_status)status;
  lbov_bf60afc4a65f34b9b6ab_t4ce841c87ea3b1559bfb raw0 = {0};
  lbov_bf60afc4a65f34b9b6ab_t4ce841c87ea3b1559bfb returned = {0};
  owned_checked_records_grant_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v6_to(a0, &raw0, 0, &input);
  if (!status) status = lbov_bf60afc4a65f34b9b6ab_v4ce841c87ea3b1559bfb_retain(&active->native, &raw0, &returned, &result_owner->native);
  if (!status) {
    status = oc_v6_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_status)status;
}
owned_checked_records_status owned_checked_records_window_t_copy(owned_checked_records_session *session, owned_checked_records_window_t const * a0, owned_checked_records_window_t *out, owned_checked_records_result **owner) {
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_checked_records_window_t), owner) || *owner) return (owned_checked_records_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_status)status;
  lbov_bf60afc4a65f34b9b6ab_t2a091437b2d587ce3891 raw0 = {0};
  lbov_bf60afc4a65f34b9b6ab_t2a091437b2d587ce3891 returned = {0};
  owned_checked_records_window_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v8_to(a0, &raw0, 0, &input);
  if (!status) status = lbov_bf60afc4a65f34b9b6ab_v2a091437b2d587ce3891_retain(&active->native, &raw0, &returned, &result_owner->native);
  if (!status) {
    status = oc_v8_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_status)status;
}
owned_checked_records_status owned_checked_records_scalar_nat_copy(owned_checked_records_session *session, mpz_srcptr a0, mpz_srcptr *out, owned_checked_records_result **owner) {
  if (!oc_outputs(out, sizeof(*out), _Alignof(mpz_srcptr), owner) || *owner) return (owned_checked_records_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_status)status;
  lbov_bf60afc4a65f34b9b6ab_t167081552b6f9c1d1afd raw0 = {0};
  lbov_bf60afc4a65f34b9b6ab_t167081552b6f9c1d1afd returned = {0};
  mpz_srcptr converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v9_to(&a0, &raw0, 0, &input);
  if (!status) status = lbov_bf60afc4a65f34b9b6ab_v167081552b6f9c1d1afd_retain(&active->native, &raw0, &returned, &result_owner->native);
  if (!status) {
    status = oc_v9_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_status)status;
}
owned_checked_records_status owned_checked_records_scalar_string_copy(owned_checked_records_session *session, owned_checked_records_scalar_string_t a0, owned_checked_records_scalar_string_t *out, owned_checked_records_result **owner) {
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_checked_records_scalar_string_t), owner) || *owner) return (owned_checked_records_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_status)status;
  lbov_bf60afc4a65f34b9b6ab_tdc0347e1f7f5c4d928f1 raw0 = {0};
  lbov_bf60afc4a65f34b9b6ab_tdc0347e1f7f5c4d928f1 returned = {0};
  owned_checked_records_scalar_string_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v10_to(&a0, &raw0, 0, &input);
  if (!status) status = lbov_bf60afc4a65f34b9b6ab_vdc0347e1f7f5c4d928f1_retain(&active->native, &raw0, &returned, &result_owner->native);
  if (!status) {
    status = oc_v10_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_status)status;
}
