package LeanBridge::OwnedCheckedRecords;
use strict;
use warnings;
use Math::BigInt;
# Fields are validated and snapshotted at the native call boundary.
# Resource and closure identities are created and checked by the XS adapter.

sub true () { !!1 }
sub false () { !!0 }
package LeanBridge::OwnedCheckedRecords::Some;
sub new {
  CORE::die "Some->new expects one payload\n" unless @_ == 2 && CORE::defined($_[0]) && !CORE::ref($_[0]) && $_[0] eq 'LeanBridge::OwnedCheckedRecords::Some';
  return CORE::bless {value => $_[1]}, 'LeanBridge::OwnedCheckedRecords::Some';
}
sub value { $_[0]->{value} }

package LeanBridge::OwnedCheckedRecords::Claim;
sub new {
  CORE::die "LeanBridge::OwnedCheckedRecords::Claim->new expects named fields\n" unless @_ % 2 == 1 && CORE::defined($_[0]) && !CORE::ref($_[0]) && $_[0] eq 'LeanBridge::OwnedCheckedRecords::Claim';
  CORE::shift; my %fields;
  while (@_) {
    my ($key, $value) = CORE::splice @_, 0, 2;
    CORE::die "invalid field name\n" if !CORE::defined($key) || CORE::ref($key);
    CORE::die "duplicate constructor field\n" if CORE::exists($fields{$key});
    $fields{$key} = $value;
  }
  my @required = qw(holder quota);
  CORE::die "fields do not match the generated schema\n" if CORE::keys(%fields) != @required || CORE::grep { !CORE::exists($fields{$_}) } @required;
  return CORE::bless \%fields, 'LeanBridge::OwnedCheckedRecords::Claim';
}
# holder: Ticket
sub holder { $_[0]->{holder} }
# quota: nat
sub quota { $_[0]->{quota} }

package LeanBridge::OwnedCheckedRecords::Ticket;
sub new { CORE::die "Resources and closures are returned by Lean functions\n" }
sub CLONE_SKIP { 1 }
sub STORABLE_freeze { CORE::die "Lean identities cannot be serialized\n" }
sub STORABLE_thaw { CORE::die "Lean identities cannot be deserialized\n" }

1;


1;

package LeanBridge::OwnedCheckedRecords;
use LeanBridge::Runtime;
die "Incompatible shared Lean runtime package version\n" unless $LeanBridge::Runtime::VERSION eq '0.0020873093885122476990213970161242772861093089627532315710208989625599780543964681';
use LeanBridge::Runtime::OwnedAssets;
use DynaLoader ();
use Cwd ();
use Config ();
use JSON::PP ();
our $VERSION = '1.000';
my $root = Cwd::abs_path(__FILE__); $root =~ s/\.pm\z//;
my $xs_sha256 = '__LEAN_BRIDGE_OWNED_XS_SHA256__';
die "Install this owned Perl package before loading its XS\n" unless $xs_sha256 =~ /\A[0-9a-f]{64}\z/;
LeanBridge::Runtime::_check_component('6f4dbd1e2e112f4678734553d1c9bb8722fad3e6290adbff1ac46d05e5eff7dd', { 'OwnedCheckedRecords' => '65226b9f8cafb1ff9e5c54dd680efc2939158fd9c4be1da2aaf8c069c1e1eb89' }, 'owned-checked-records@1.0.0', 'a61bc7d6e11a7931e8505f23ba6ef618d0d91c75bb17ca8ed246f7acd922b4cc');
LeanBridge::Runtime::Platform::installed_abi(JSON::PP->new->decode(LeanBridge::Runtime::_read("$root/install-receipt.json")));
my $base = Cwd::abs_path(__FILE__); $base =~ s{\QLeanBridge/OwnedCheckedRecords.pm\E\z}{};
my $xs_path;
for my $directory ($base, @INC) {
  next if ref($directory);
  my $candidate = "$directory/auto/LeanBridge/OwnedCheckedRecords/OwnedCheckedRecords.$Config::Config{dlext}";
  if (-f $candidate) { $xs_path = Cwd::abs_path($candidate); last; }
}
die "Cannot find the installed owned XS image\n" unless defined $xs_path;
my $paths = LeanBridge::Runtime::OwnedAssets::load([
  { path => "$root/native/libgmp-lean-bridge.so.10", soname => 'libgmp-lean-bridge.so.10', sha256 => '9687f8d50f5c413728d4fcc8d96328912239ce8b1269cbb9a1ff793e430a7b27' },
  { path => "$root/native/libcomponent_161bdaa35ee11fef40c6.so", soname => 'libcomponent_161bdaa35ee11fef40c6.so', sha256 => 'a61bc7d6e11a7931e8505f23ba6ef618d0d91c75bb17ca8ed246f7acd922b4cc' },
  { path => $xs_path, sha256 => $xs_sha256 }
]);
LeanBridge::Runtime::_record_component('6f4dbd1e2e112f4678734553d1c9bb8722fad3e6290adbff1ac46d05e5eff7dd', { 'OwnedCheckedRecords' => '65226b9f8cafb1ff9e5c54dd680efc2939158fd9c4be1da2aaf8c069c1e1eb89' }, 'owned-checked-records@1.0.0', 'a61bc7d6e11a7931e8505f23ba6ef618d0d91c75bb17ca8ed246f7acd922b4cc');
my $library = DynaLoader::dl_load_file($paths->[-1], 0) or die DynaLoader::dl_error();
my $symbol = DynaLoader::dl_find_symbol($library, 'boot_LeanBridge__OwnedCheckedRecords') or die DynaLoader::dl_error();
my $bootstrap = DynaLoader::dl_install_xsub('LeanBridge::OwnedCheckedRecords::Runtime::_bootstrap', $symbol, $paths->[-1]);
$bootstrap->(__PACKAGE__, $VERSION);
sub CLONE_SKIP { 1 }
1;

__END__
=head1 NAME

LeanBridge::OwnedCheckedRecords - Generated owned Lean values and synchronous callbacks

=head1 API

=head2 claim_for

Calls C<OwnedCheckedRecords.claimFor> in the compiled Lean component.

=head2 new_ticket

Calls C<OwnedCheckedRecords.newTicket> in the compiled Lean component.

=head2 serial

Calls C<OwnedCheckedRecords.serial> in the compiled Lean component.

=head1 VALUES AND OWNERSHIP

Records and variants use generated named-field classes. Arrays, Lists and
products use array references. None and Unit use undef; Some->new(undef) keeps
optional Unit distinct from None. Ok and Err preserve their result branches.
Nat and Int use Math::BigInt. Text retains Unicode and NUL; ByteArray uses octets.

Resources and Lean closures provide close, closed and retain. Retained results
own independent native references. Close is idempotent; finalization releases
unclosed owners. Closing an input during a call does not invalidate its active
borrow. Callback arguments expire on return unless explicitly retained.

Pass CODE references for synchronous callbacks. Signatures that require a typed
recovery value accept Runtime::Callback->new(code => ..., recovery => ...).
Perl exceptions retain their identity after native cleanup. Host callbacks
cannot escape their initiating call. Owners cannot be serialized or used by a
different process or interpreter thread.

=head1 INSTALLATION

The runtime dependency is installed with this package. A compatible prebuilt XS
image needs no compiler. Otherwise installation compiles the supplied XS and C
adapter with local Perl headers. Lean, Lake and Node are not required.

=cut
