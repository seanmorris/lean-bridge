#include "component.h"
#include "lean_bridge_native_runtime.h"
static _Thread_local int lean_bridge_owned_callback_failure_7e4e4299d5b83eeea5ec_state;
int lean_bridge_owned_callback_failure_7e4e4299d5b83eeea5ec(void) { int result = lean_bridge_owned_callback_failure_7e4e4299d5b83eeea5ec_state; lean_bridge_owned_callback_failure_7e4e4299d5b83eeea5ec_state = 0; return result; }
lean_object *lean_bridge_owned_cf3aae0ea57f777cc6a7aa9c_t648974cffb2d6c1d7951_invoke(size_t token, lean_object *a0) {
  lb_native_callback callback = lb_native_callback_lookup(token);
  if (!callback.invoke) {
    lean_dec(a0);
    return lean_alloc_array(0, 0);
  }
  return ((lean_object *(*)(void *, lean_object *))callback.invoke)(callback.context, a0);
}
lean_object *lean_bridge_owned_cf3aae0ea57f777cc6a7aa9c_t5035e6ea0903f12776d9_invoke(size_t token, lean_object *a0) {
  lb_native_callback callback = lb_native_callback_lookup(token);
  if (!callback.invoke) {
    lean_dec(a0);
    return lean_alloc_array(0, 0);
  }
  return ((lean_object *(*)(void *, lean_object *))callback.invoke)(callback.context, a0);
}
lean_object *lean_bridge_owned_cf3aae0ea57f777cc6a7aa9c_t5035e6ea0903f12776d9_reject(size_t token, lean_object *recovery) {
  (void)token;
  lean_bridge_owned_callback_failure_7e4e4299d5b83eeea5ec_state = 1;
  return recovery;
}
