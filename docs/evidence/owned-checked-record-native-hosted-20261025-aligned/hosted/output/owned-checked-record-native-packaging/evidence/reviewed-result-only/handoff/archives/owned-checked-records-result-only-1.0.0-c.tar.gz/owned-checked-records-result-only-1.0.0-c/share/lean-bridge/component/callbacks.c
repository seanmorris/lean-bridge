#include "component.h"
#include "lean_bridge_native_runtime.h"
static _Thread_local int lean_bridge_owned_callback_failure_4e1b1b38cf9e82930a7a_state;
int lean_bridge_owned_callback_failure_4e1b1b38cf9e82930a7a(void) { int result = lean_bridge_owned_callback_failure_4e1b1b38cf9e82930a7a_state; lean_bridge_owned_callback_failure_4e1b1b38cf9e82930a7a_state = 0; return result; }
