# owned-checked-records 1.0.0

Compiled ownership-aware C++20 API from owned-checked-records@1.0.0. Linux x86-64,
glibc 2.38 or newer. Consumers need a C++20 compiler, not Lean.
The archive includes the shared Lean runtime, GMP 6.3.0 with corresponding source
and notices, and pinned Boost 1.90.0 standalone headers and notices.

Include owned_checked_records.hpp. Functions live in lean_bridge::owned_checked_records. Use pkg-config package
owned-checked-records, or find_package(LeanBridgeOwnedCheckedRecordsCpp CONFIG REQUIRED) and link LeanBridge::owned_checked_records_cpp.
Both methods supply the GMP and thread dependencies; bundled libraries load
automatically. Do not link the Lean shared library directly into a C++ executable.

Records and variants have source-named fields and constructors. Arrays and lists
are std::vector, options are std::optional, tuples are std::pair, and Result<T,E>
has distinct Ok<T>/Err<E> alternatives. Recursive inline fields use deep-copy
Box<T>. Nat and Int use exact Boost.Multiprecision integers; negative Nat inputs
reject. Unit inputs use std::monostate and Unit results return void. Strings are
UTF-8 std::string values, including embedded NUL; bytes are std::vector<uint8_t>.

Resource wrappers share checked result leases and nominal identity when copied.
close() releases that wrapper; other owning copies remain usable. retain() makes
an independently owned reference. Calls reject closed, foreign-thread and inherited
post-fork resources. Foreign-thread destruction queues disposal for the creating
thread. Thread exit closes its session and releases registered native owners.

Copied container storage is independent; its resource leaves retain their leases.

Transferred inputs take rvalue references. Pass std::move(value), or a temporary.
The bridge validates every argument before consuming any resource lease. At the
C handoff, all submitted leases and their aliases become closed, before Lean or
a host callback runs. Each source lease can belong to only one transferred
argument; host-assembled values may contain several distinct leases. The entire
lease moves, including siblings omitted from the submitted value. Independent
retain() references survive. Callback borrows cannot be transferred; retain them
first. Failures before handoff preserve the input leases; failures after handoff
leave them consumed. Copied fields remain ordinary C++ values.


Typed lambdas and function objects are call-scoped callbacks. Borrowed callback
resource arguments expire on return, including copies of those wrappers. Call
retain() inside the callback to keep a resource. Reply storage is copied into an
owning C result before callback locals die. Original callback exceptions are
rethrown after C/Lean cleanup; no exception crosses a C trampoline. Later host
invocations in the same failed call are suppressed. Independent calls can recover.
Factories that cannot derive a failure-path value require
with_recovery(callback, typedValue); failures never publish it as successful output.
Returned Lean closures support function-call syntax and retain(). A closure that
captures a borrowed host callback cannot invoke that callback after the borrow ends.


Input, callback and result conversions share per-call depth128,262144-visit and
16MiB native/storage budgets. C/native conversion limits also apply; these do not
cap Lean algorithm working memory or GMP allocator overhead. GMP retains its
default fatal allocation-failure policy. Invalid inputs and partial conversions
release their temporary storage and ownership. Boundaries throw Error with a status;
C++ allocation failures throw std::bad_alloc.

- bookingSpan: lean:OwnedCheckedRecords.bookingSpan
- claimClosure: lean:OwnedCheckedRecords.claimClosure
- claimFor: lean:OwnedCheckedRecords.claimFor
- claimQuota: lean:OwnedCheckedRecords.claimQuota
- echoBooking: lean:OwnedCheckedRecords.echoBooking
- echoClaim: lean:OwnedCheckedRecords.echoClaim
- echoClaims: lean:OwnedCheckedRecords.echoClaims
- echoGrant: lean:OwnedCheckedRecords.echoGrant
- newTicket: lean:OwnedCheckedRecords.newTicket
- pairClaim: lean:OwnedCheckedRecords.pairClaim
- serial: lean:OwnedCheckedRecords.serial
- transferClaim: lean:OwnedCheckedRecords.transferClaim
- transferPairClaim: lean:OwnedCheckedRecords.transferPairClaim
- transferWithClaimCallback: lean:OwnedCheckedRecords.transferWithClaimCallback
- withClaimCallback: lean:OwnedCheckedRecords.withClaimCallback
