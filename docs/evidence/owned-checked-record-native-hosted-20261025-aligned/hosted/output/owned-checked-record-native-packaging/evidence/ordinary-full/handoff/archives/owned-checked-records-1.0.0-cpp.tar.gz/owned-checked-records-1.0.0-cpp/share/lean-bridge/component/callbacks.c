#include "component.h"
#include "lean_bridge_native_runtime.h"
static _Thread_local int lean_bridge_owned_callback_failure_dec495692c7fe4e3ecf9_state;
int lean_bridge_owned_callback_failure_dec495692c7fe4e3ecf9(void) { int result = lean_bridge_owned_callback_failure_dec495692c7fe4e3ecf9_state; lean_bridge_owned_callback_failure_dec495692c7fe4e3ecf9_state = 0; return result; }
lean_object *lean_bridge_owned_58005259d63a1cbb15e3d367_t648974cffb2d6c1d7951_invoke(size_t token, lean_object *a0) {
  lb_native_callback callback = lb_native_callback_lookup(token);
  if (!callback.invoke) {
    lean_dec(a0);
    return lean_alloc_array(0, 0);
  }
  return ((lean_object *(*)(void *, lean_object *))callback.invoke)(callback.context, a0);
}
lean_object *lean_bridge_owned_58005259d63a1cbb15e3d367_t5035e6ea0903f12776d9_invoke(size_t token, lean_object *a0) {
  lb_native_callback callback = lb_native_callback_lookup(token);
  if (!callback.invoke) {
    lean_dec(a0);
    return lean_alloc_array(0, 0);
  }
  return ((lean_object *(*)(void *, lean_object *))callback.invoke)(callback.context, a0);
}
lean_object *lean_bridge_owned_58005259d63a1cbb15e3d367_t5035e6ea0903f12776d9_reject(size_t token, lean_object *recovery) {
  (void)token;
  lean_bridge_owned_callback_failure_dec495692c7fe4e3ecf9_state = 1;
  return recovery;
}
