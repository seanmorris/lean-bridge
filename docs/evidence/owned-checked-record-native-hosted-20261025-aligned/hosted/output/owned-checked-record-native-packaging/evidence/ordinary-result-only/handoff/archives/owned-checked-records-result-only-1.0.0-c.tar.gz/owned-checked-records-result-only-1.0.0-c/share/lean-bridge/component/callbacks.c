#include "component.h"
#include "lean_bridge_native_runtime.h"
static _Thread_local int lean_bridge_owned_callback_failure_e19a75cc2cf6c3dc2550_state;
int lean_bridge_owned_callback_failure_e19a75cc2cf6c3dc2550(void) { int result = lean_bridge_owned_callback_failure_e19a75cc2cf6c3dc2550_state; lean_bridge_owned_callback_failure_e19a75cc2cf6c3dc2550_state = 0; return result; }
