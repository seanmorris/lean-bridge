# nominalsubtypes

Compiler-checked exports for nominalsubtypes.

Binding IR SHA-256: `aab93dfb3005269c791001ee7231660173fa267219cb90dcd6a3f2c9c773dbe1`

## Exports

### aliases

Call NominalSubtypes.aliases.

### arrayValues

Call NominalSubtypes.arrayValues.

### branch

Call NominalSubtypes.branch.

### combine

Call NominalSubtypes.combine.

### echo

Call NominalSubtypes.echo.

### echoEvent

Call NominalSubtypes.echoEvent.

### echoGroups

Call NominalSubtypes.echoGroups.

### echoPair

Call NominalSubtypes.echoPair.

### eventChoices

Call NominalSubtypes.eventChoices.

### eventEmpty

Call NominalSubtypes.eventEmpty.

### eventFirst

Call NominalSubtypes.eventFirst.

### eventSecond

Call NominalSubtypes.eventSecond.

### eventValue

Call NominalSubtypes.eventValue.

### first

Call NominalSubtypes.first.

### groupValues

Call NominalSubtypes.groupValues.

### inspectAliasPair

Call NominalSubtypes.inspectAliasPair.

### listValues

Call NominalSubtypes.listValues.

### nested

Call NominalSubtypes.nested.

### noItems

Call NominalSubtypes.noItems.

### optional

Call NominalSubtypes.optional.

### pairValues

Call NominalSubtypes.pairValues.

### plainFin

Call NominalSubtypes.plainFin.

### produceEnvelope

Call NominalSubtypes.produceEnvelope.

### product

Call NominalSubtypes.product.

### scalar

Call NominalSubtypes.scalar.

### second

Call NominalSubtypes.second.

## Assurance

