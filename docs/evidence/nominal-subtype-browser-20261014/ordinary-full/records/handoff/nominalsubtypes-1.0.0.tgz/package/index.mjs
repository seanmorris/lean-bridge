// Generated from Binding IR SHA-256 aab93dfb3005269c791001ee7231660173fa267219cb90dcd6a3f2c9c773dbe1.
import { runtime } from "./internal/runtime.mjs";
import * as validate from "./internal/validators.mjs";

/**
 * Call NominalSubtypes.aliases.
 */
export function aliases(arg0, arg1) {
  validate.assertArrayOfApplied$fd8c51a7be4376e66987(arg0, "aliases.arg0");
  validate.assertNestedFin(arg0, {"arguments":[{"arguments":[{"fields":[{"name":"payload","refinement":{"constructor":"NominalSubtypes.plusOne","kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}],"kind":"option"}],"kind":"array"}, "aliases.arg0");
  validate.assertArrayOfApplied$fd8c51a7be4376e66987(arg1, "aliases.arg1");
  validate.assertNestedFin(arg1, {"arguments":[{"arguments":[{"fields":[{"name":"payload","refinement":{"constructor":"NominalSubtypes.plusTwo","kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}],"kind":"option"}],"kind":"array"}, "aliases.arg1");
  const result = runtime.call("lean:NominalSubtypes.aliases", [arg0, arg1]);
  validate.assertNat(result, "aliases.result");
  return result;
}

/**
 * Call NominalSubtypes.arrayValues.
 */
export function arrayValues(arg0) {
  validate.assertNat(arg0, "arrayValues.arg0");
  const result = runtime.call("lean:NominalSubtypes.arrayValues", [arg0]);
  validate.assertArrayOfNat(result, "arrayValues.result");
  validate.assertNestedFin(result, {"arguments":[{"constructor":null,"kind":"subtype"}],"kind":"array"}, "arrayValues.result");
  return result;
}

/**
 * Call NominalSubtypes.branch.
 */
export function branch(arg0) {
  validate.assertNat(arg0, "branch.arg0");
  const result = runtime.call("lean:NominalSubtypes.branch", [arg0]);
  validate.assertApplied$6ad544f9f06180f14803(result, "branch.result");
  validate.assertNestedFin(result, {"arguments":[{"constructor":null,"kind":"subtype"},{"constructor":null,"kind":"subtype"}],"kind":"result"}, "branch.result");
  return result;
}

/**
 * Call NominalSubtypes.combine.
 */
export function combine(arg0, arg1) {
  validate.assertEnvelope(arg0, "combine.arg0");
  validate.assertNestedFin(arg0, {"fields":[{"name":"payload","refinement":{"constructor":"NominalSubtypes.plusOne","kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}, "combine.arg0");
  validate.assertEnvelope(arg1, "combine.arg1");
  validate.assertNestedFin(arg1, {"fields":[{"name":"payload","refinement":{"constructor":"NominalSubtypes.plusTwo","kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}, "combine.arg1");
  const result = runtime.call("lean:NominalSubtypes.combine", [arg0, arg1]);
  validate.assertNat(result, "combine.result");
  return result;
}

/**
 * Call NominalSubtypes.echo.
 */
export function echo(arg0) {
  validate.assertEnvelope(arg0, "echo.arg0");
  validate.assertNestedFin(arg0, {"fields":[{"name":"payload","refinement":{"constructor":"NominalSubtypes.plusOne","kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}, "echo.arg0");
  const result = runtime.call("lean:NominalSubtypes.echo", [arg0]);
  validate.assertEnvelope(result, "echo.result");
  validate.assertNestedFin(result, {"fields":[{"name":"payload","refinement":{"constructor":null,"kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}, "echo.result");
  return result;
}

/**
 * Call NominalSubtypes.echoEvent.
 */
export function echoEvent(arg0) {
  validate.assertEvent(arg0, "echoEvent.arg0");
  validate.assertNestedFin(arg0, {"cases":[{"fields":[],"name":"empty"},{"fields":[{"name":"value","refinement":{"fields":[{"name":"payload","refinement":{"constructor":"NominalSubtypes.plusOne","kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}}],"name":"box"},{"fields":[{"name":"values","refinement":{"arguments":[{"arguments":[{"arguments":[{"constructor":"NominalSubtypes.plusOne","kind":"subtype"},{"constructor":"NominalSubtypes.plusTwo","kind":"subtype"}],"kind":"result"}],"kind":"option"}],"kind":"array"}}],"name":"choices"}],"kind":"variant","name":"NominalSubtypes.Event"}, "echoEvent.arg0");
  const result = runtime.call("lean:NominalSubtypes.echoEvent", [arg0]);
  validate.assertEvent(result, "echoEvent.result");
  validate.assertNestedFin(result, {"cases":[{"fields":[],"name":"empty"},{"fields":[{"name":"value","refinement":{"fields":[{"name":"payload","refinement":{"constructor":null,"kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}}],"name":"box"},{"fields":[{"name":"values","refinement":{"arguments":[{"arguments":[{"arguments":[{"constructor":null,"kind":"subtype"},{"constructor":null,"kind":"subtype"}],"kind":"result"}],"kind":"option"}],"kind":"array"}}],"name":"choices"}],"kind":"variant","name":"NominalSubtypes.Event"}, "echoEvent.result");
  return result;
}

/**
 * Call NominalSubtypes.echoGroups.
 */
export function echoGroups(arg0) {
  validate.assertArrayOfApplied$fd8c51a7be4376e66987(arg0, "echoGroups.arg0");
  validate.assertNestedFin(arg0, {"arguments":[{"arguments":[{"fields":[{"name":"payload","refinement":{"constructor":"NominalSubtypes.plusOne","kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}],"kind":"option"}],"kind":"array"}, "echoGroups.arg0");
  const result = runtime.call("lean:NominalSubtypes.echoGroups", [arg0]);
  validate.assertArrayOfApplied$fd8c51a7be4376e66987(result, "echoGroups.result");
  validate.assertNestedFin(result, {"arguments":[{"arguments":[{"fields":[{"name":"payload","refinement":{"constructor":null,"kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}],"kind":"option"}],"kind":"array"}, "echoGroups.result");
  return result;
}

/**
 * Call NominalSubtypes.echoPair.
 */
export function echoPair(arg0) {
  validate.assertAliasPair(arg0, "echoPair.arg0");
  validate.assertNestedFin(arg0, {"fields":[{"name":"left","refinement":{"arguments":[{"arguments":[{"fields":[{"name":"payload","refinement":{"constructor":"NominalSubtypes.plusOne","kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}],"kind":"option"}],"kind":"array"}},{"name":"right","refinement":{"arguments":[{"arguments":[{"fields":[{"name":"payload","refinement":{"constructor":"NominalSubtypes.plusTwo","kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}],"kind":"option"}],"kind":"array"}}],"kind":"record","name":"NominalSubtypes.AliasPair"}, "echoPair.arg0");
  const result = runtime.call("lean:NominalSubtypes.echoPair", [arg0]);
  validate.assertAliasPair(result, "echoPair.result");
  validate.assertNestedFin(result, {"fields":[{"name":"left","refinement":{"arguments":[{"arguments":[{"fields":[{"name":"payload","refinement":{"constructor":null,"kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}],"kind":"option"}],"kind":"array"}},{"name":"right","refinement":{"arguments":[{"arguments":[{"fields":[{"name":"payload","refinement":{"constructor":null,"kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}],"kind":"option"}],"kind":"array"}}],"kind":"record","name":"NominalSubtypes.AliasPair"}, "echoPair.result");
  return result;
}

/**
 * Call NominalSubtypes.eventChoices.
 */
export function eventChoices(arg0) {
  validate.assertNat(arg0, "eventChoices.arg0");
  const result = runtime.call("lean:NominalSubtypes.eventChoices", [arg0]);
  validate.assertEvent(result, "eventChoices.result");
  validate.assertNestedFin(result, {"cases":[{"fields":[],"name":"empty"},{"fields":[{"name":"value","refinement":{"fields":[{"name":"payload","refinement":{"constructor":null,"kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}}],"name":"box"},{"fields":[{"name":"values","refinement":{"arguments":[{"arguments":[{"arguments":[{"constructor":null,"kind":"subtype"},{"constructor":null,"kind":"subtype"}],"kind":"result"}],"kind":"option"}],"kind":"array"}}],"name":"choices"}],"kind":"variant","name":"NominalSubtypes.Event"}, "eventChoices.result");
  return result;
}

/**
 * Call NominalSubtypes.eventEmpty.
 */
export function eventEmpty(arg0) {
  validate.assertNat(arg0, "eventEmpty.arg0");
  const result = runtime.call("lean:NominalSubtypes.eventEmpty", [arg0]);
  validate.assertEvent(result, "eventEmpty.result");
  validate.assertNestedFin(result, {"cases":[{"fields":[],"name":"empty"},{"fields":[{"name":"value","refinement":{"fields":[{"name":"payload","refinement":{"constructor":null,"kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}}],"name":"box"},{"fields":[{"name":"values","refinement":{"arguments":[{"arguments":[{"arguments":[{"constructor":null,"kind":"subtype"},{"constructor":null,"kind":"subtype"}],"kind":"result"}],"kind":"option"}],"kind":"array"}}],"name":"choices"}],"kind":"variant","name":"NominalSubtypes.Event"}, "eventEmpty.result");
  return result;
}

/**
 * Call NominalSubtypes.eventFirst.
 */
export function eventFirst(arg0) {
  validate.assertEvent(arg0, "eventFirst.arg0");
  validate.assertNestedFin(arg0, {"cases":[{"fields":[],"name":"empty"},{"fields":[{"name":"value","refinement":{"fields":[{"name":"payload","refinement":{"constructor":"NominalSubtypes.plusOne","kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}}],"name":"box"},{"fields":[{"name":"values","refinement":{"arguments":[{"arguments":[{"arguments":[{"constructor":"NominalSubtypes.plusOne","kind":"subtype"},{"constructor":"NominalSubtypes.plusTwo","kind":"subtype"}],"kind":"result"}],"kind":"option"}],"kind":"array"}}],"name":"choices"}],"kind":"variant","name":"NominalSubtypes.Event"}, "eventFirst.arg0");
  const result = runtime.call("lean:NominalSubtypes.eventFirst", [arg0]);
  validate.assertNat(result, "eventFirst.result");
  return result;
}

/**
 * Call NominalSubtypes.eventSecond.
 */
export function eventSecond(arg0) {
  validate.assertEvent(arg0, "eventSecond.arg0");
  validate.assertNestedFin(arg0, {"cases":[{"fields":[],"name":"empty"},{"fields":[{"name":"value","refinement":{"fields":[{"name":"payload","refinement":{"constructor":"NominalSubtypes.plusTwo","kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}}],"name":"box"},{"fields":[{"name":"values","refinement":{"arguments":[{"arguments":[{"arguments":[{"constructor":"NominalSubtypes.plusTwo","kind":"subtype"},{"constructor":"NominalSubtypes.plusOne","kind":"subtype"}],"kind":"result"}],"kind":"option"}],"kind":"array"}}],"name":"choices"}],"kind":"variant","name":"NominalSubtypes.Event"}, "eventSecond.arg0");
  const result = runtime.call("lean:NominalSubtypes.eventSecond", [arg0]);
  validate.assertNat(result, "eventSecond.result");
  return result;
}

/**
 * Call NominalSubtypes.eventValue.
 */
export function eventValue(arg0) {
  validate.assertNat(arg0, "eventValue.arg0");
  const result = runtime.call("lean:NominalSubtypes.eventValue", [arg0]);
  validate.assertEvent(result, "eventValue.result");
  validate.assertNestedFin(result, {"cases":[{"fields":[],"name":"empty"},{"fields":[{"name":"value","refinement":{"fields":[{"name":"payload","refinement":{"constructor":null,"kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}}],"name":"box"},{"fields":[{"name":"values","refinement":{"arguments":[{"arguments":[{"arguments":[{"constructor":null,"kind":"subtype"},{"constructor":null,"kind":"subtype"}],"kind":"result"}],"kind":"option"}],"kind":"array"}}],"name":"choices"}],"kind":"variant","name":"NominalSubtypes.Event"}, "eventValue.result");
  return result;
}

/**
 * Call NominalSubtypes.first.
 */
export function first(arg0) {
  validate.assertEnvelope(arg0, "first.arg0");
  validate.assertNestedFin(arg0, {"fields":[{"name":"payload","refinement":{"constructor":"NominalSubtypes.plusOne","kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}, "first.arg0");
  const result = runtime.call("lean:NominalSubtypes.first", [arg0]);
  validate.assertNat(result, "first.result");
  return result;
}

/**
 * Call NominalSubtypes.groupValues.
 */
export function groupValues(arg0) {
  validate.assertNat(arg0, "groupValues.arg0");
  const result = runtime.call("lean:NominalSubtypes.groupValues", [arg0]);
  validate.assertArrayOfApplied$fd8c51a7be4376e66987(result, "groupValues.result");
  validate.assertNestedFin(result, {"arguments":[{"arguments":[{"fields":[{"name":"payload","refinement":{"constructor":null,"kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}],"kind":"option"}],"kind":"array"}, "groupValues.result");
  return result;
}

/**
 * Call NominalSubtypes.inspectAliasPair.
 */
export function inspectAliasPair(arg0) {
  validate.assertAliasPair(arg0, "inspectAliasPair.arg0");
  validate.assertNestedFin(arg0, {"fields":[{"name":"left","refinement":{"arguments":[{"arguments":[{"fields":[{"name":"payload","refinement":{"constructor":"NominalSubtypes.plusOne","kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}],"kind":"option"}],"kind":"array"}},{"name":"right","refinement":{"arguments":[{"arguments":[{"fields":[{"name":"payload","refinement":{"constructor":"NominalSubtypes.plusTwo","kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}],"kind":"option"}],"kind":"array"}}],"kind":"record","name":"NominalSubtypes.AliasPair"}, "inspectAliasPair.arg0");
  const result = runtime.call("lean:NominalSubtypes.inspectAliasPair", [arg0]);
  validate.assertNat(result, "inspectAliasPair.result");
  return result;
}

/**
 * Call NominalSubtypes.listValues.
 */
export function listValues(arg0) {
  validate.assertNat(arg0, "listValues.arg0");
  const result = runtime.call("lean:NominalSubtypes.listValues", [arg0]);
  validate.assertApplied$6a2856fddfdde2691a33(result, "listValues.result");
  validate.assertNestedFin(result, {"arguments":[{"constructor":null,"kind":"subtype"}],"kind":"list"}, "listValues.result");
  return result;
}

/**
 * Call NominalSubtypes.nested.
 */
export function nested(arg0) {
  validate.assertPair(arg0, "nested.arg0");
  validate.assertNestedFin(arg0, {"fields":[{"name":"left","refinement":{"fields":[{"name":"payload","refinement":{"constructor":"NominalSubtypes.plusOne","kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}},{"name":"right","refinement":{"fields":[{"name":"payload","refinement":{"constructor":"NominalSubtypes.plusTwo","kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}}],"kind":"record","name":"NominalSubtypes.Pair"}, "nested.arg0");
  const result = runtime.call("lean:NominalSubtypes.nested", [arg0]);
  validate.assertNat(result, "nested.result");
  return result;
}

/**
 * Call NominalSubtypes.noItems.
 */
export function noItems(arg0) {
  validate.assertNat(arg0, "noItems.arg0");
  const result = runtime.call("lean:NominalSubtypes.noItems", [arg0]);
  validate.assertArrayOfNat(result, "noItems.result");
  validate.assertNestedFin(result, {"arguments":[{"constructor":null,"kind":"subtype"}],"kind":"array"}, "noItems.result");
  return result;
}

/**
 * Call NominalSubtypes.optional.
 */
export function optional(arg0) {
  validate.assertNat(arg0, "optional.arg0");
  const result = runtime.call("lean:NominalSubtypes.optional", [arg0]);
  validate.assertApplied$5e2b3a8b49eb1bdceb39(result, "optional.result");
  validate.assertNestedFin(result, {"arguments":[{"constructor":null,"kind":"subtype"}],"kind":"option"}, "optional.result");
  return result;
}

/**
 * Call NominalSubtypes.pairValues.
 */
export function pairValues(arg0) {
  validate.assertNat(arg0, "pairValues.arg0");
  const result = runtime.call("lean:NominalSubtypes.pairValues", [arg0]);
  validate.assertAliasPair(result, "pairValues.result");
  validate.assertNestedFin(result, {"fields":[{"name":"left","refinement":{"arguments":[{"arguments":[{"fields":[{"name":"payload","refinement":{"constructor":null,"kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}],"kind":"option"}],"kind":"array"}},{"name":"right","refinement":{"arguments":[{"arguments":[{"fields":[{"name":"payload","refinement":{"constructor":null,"kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}],"kind":"option"}],"kind":"array"}}],"kind":"record","name":"NominalSubtypes.AliasPair"}, "pairValues.result");
  return result;
}

/**
 * Call NominalSubtypes.plainFin.
 */
export function plainFin(arg0) {
  validate.assertNat(arg0, "plainFin.arg0");
  validate.assertFin(arg0, "3", "plainFin.arg0");
  const result = runtime.call("lean:NominalSubtypes.plainFin", [arg0]);
  validate.assertNat(result, "plainFin.result");
  return result;
}

/**
 * Call NominalSubtypes.produceEnvelope.
 */
export function produceEnvelope(arg0) {
  validate.assertNat(arg0, "produceEnvelope.arg0");
  const result = runtime.call("lean:NominalSubtypes.produceEnvelope", [arg0]);
  validate.assertEnvelope(result, "produceEnvelope.result");
  validate.assertNestedFin(result, {"fields":[{"name":"payload","refinement":{"constructor":null,"kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}, "produceEnvelope.result");
  return result;
}

/**
 * Call NominalSubtypes.product.
 */
export function product(arg0) {
  validate.assertNat(arg0, "product.arg0");
  const result = runtime.call("lean:NominalSubtypes.product", [arg0]);
  validate.assertApplied$5433d385d845a030e67d(result, "product.result");
  validate.assertNestedFin(result, {"arguments":[{"constructor":null,"kind":"subtype"},{"constructor":null,"kind":"subtype"}],"kind":"tuple"}, "product.result");
  return result;
}

/**
 * Call NominalSubtypes.scalar.
 */
export function scalar(arg0) {
  validate.assertNat(arg0, "scalar.arg0");
  const result = runtime.call("lean:NominalSubtypes.scalar", [arg0]);
  validate.assertNat(result, "scalar.result");
  return result;
}

/**
 * Call NominalSubtypes.second.
 */
export function second(arg0) {
  validate.assertEnvelope(arg0, "second.arg0");
  validate.assertNestedFin(arg0, {"fields":[{"name":"payload","refinement":{"constructor":"NominalSubtypes.plusTwo","kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}, "second.arg0");
  const result = runtime.call("lean:NominalSubtypes.second", [arg0]);
  validate.assertNat(result, "second.result");
  return result;
}

export default Object.freeze({ aliases, arrayValues, branch, combine, echo, echoEvent, echoGroups, echoPair, eventChoices, eventEmpty, eventFirst, eventSecond, eventValue, first, groupValues, inspectAliasPair, listValues, nested, noItems, optional, pairValues, plainFin, produceEnvelope, product, scalar, second });
