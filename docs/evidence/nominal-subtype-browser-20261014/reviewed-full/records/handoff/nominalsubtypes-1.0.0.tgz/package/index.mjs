// Generated from Binding IR SHA-256 1a42b2960f99368a3131fe9ae5c6ec7b1d6556143dbe49a44d8dfd8fc139c9ad.
import { runtime } from "./internal/runtime.mjs";
import * as validate from "./internal/validators.mjs";

/**
 * Independent corpus contract.
 */
export function aliases(value0, value1) {
  validate.assertArrayOfApplied$fd8c51a7be4376e66987(value0, "aliases.value0");
  validate.assertNestedFin(value0, {"arguments":[{"arguments":[{"fields":[{"name":"payload","refinement":{"constructor":"NominalSubtypes.plusOne","kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}],"kind":"option"}],"kind":"array"}, "aliases.value0");
  validate.assertArrayOfApplied$fd8c51a7be4376e66987(value1, "aliases.value1");
  validate.assertNestedFin(value1, {"arguments":[{"arguments":[{"fields":[{"name":"payload","refinement":{"constructor":"NominalSubtypes.plusTwo","kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}],"kind":"option"}],"kind":"array"}, "aliases.value1");
  const result = runtime.call("lean:NominalSubtypes.aliases", [value0, value1]);
  validate.assertNat(result, "aliases.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function arrayValues(value0) {
  validate.assertNat(value0, "arrayValues.value0");
  const result = runtime.call("lean:NominalSubtypes.arrayValues", [value0]);
  validate.assertArrayOfNat(result, "arrayValues.result");
  validate.assertNestedFin(result, {"arguments":[{"constructor":null,"kind":"subtype"}],"kind":"array"}, "arrayValues.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function branch(value0) {
  validate.assertNat(value0, "branch.value0");
  const result = runtime.call("lean:NominalSubtypes.branch", [value0]);
  validate.assertApplied$6ad544f9f06180f14803(result, "branch.result");
  validate.assertNestedFin(result, {"arguments":[{"constructor":null,"kind":"subtype"},{"constructor":null,"kind":"subtype"}],"kind":"result"}, "branch.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function combine(value0, value1) {
  validate.assertEnvelope(value0, "combine.value0");
  validate.assertNestedFin(value0, {"fields":[{"name":"payload","refinement":{"constructor":"NominalSubtypes.plusOne","kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}, "combine.value0");
  validate.assertEnvelope(value1, "combine.value1");
  validate.assertNestedFin(value1, {"fields":[{"name":"payload","refinement":{"constructor":"NominalSubtypes.plusTwo","kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}, "combine.value1");
  const result = runtime.call("lean:NominalSubtypes.combine", [value0, value1]);
  validate.assertNat(result, "combine.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function echo(value0) {
  validate.assertEnvelope(value0, "echo.value0");
  validate.assertNestedFin(value0, {"fields":[{"name":"payload","refinement":{"constructor":"NominalSubtypes.plusOne","kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}, "echo.value0");
  const result = runtime.call("lean:NominalSubtypes.echo", [value0]);
  validate.assertEnvelope(result, "echo.result");
  validate.assertNestedFin(result, {"fields":[{"name":"payload","refinement":{"constructor":null,"kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}, "echo.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function echoEvent(value0) {
  validate.assertEvent(value0, "echoEvent.value0");
  validate.assertNestedFin(value0, {"cases":[{"fields":[],"name":"empty"},{"fields":[{"name":"value","refinement":{"fields":[{"name":"payload","refinement":{"constructor":"NominalSubtypes.plusOne","kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}}],"name":"box"},{"fields":[{"name":"values","refinement":{"arguments":[{"arguments":[{"arguments":[{"constructor":"NominalSubtypes.plusOne","kind":"subtype"},{"constructor":"NominalSubtypes.plusTwo","kind":"subtype"}],"kind":"result"}],"kind":"option"}],"kind":"array"}}],"name":"choices"}],"kind":"variant","name":"NominalSubtypes.Event"}, "echoEvent.value0");
  const result = runtime.call("lean:NominalSubtypes.echoEvent", [value0]);
  validate.assertEvent(result, "echoEvent.result");
  validate.assertNestedFin(result, {"cases":[{"fields":[],"name":"empty"},{"fields":[{"name":"value","refinement":{"fields":[{"name":"payload","refinement":{"constructor":null,"kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}}],"name":"box"},{"fields":[{"name":"values","refinement":{"arguments":[{"arguments":[{"arguments":[{"constructor":null,"kind":"subtype"},{"constructor":null,"kind":"subtype"}],"kind":"result"}],"kind":"option"}],"kind":"array"}}],"name":"choices"}],"kind":"variant","name":"NominalSubtypes.Event"}, "echoEvent.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function echoGroups(value0) {
  validate.assertArrayOfApplied$fd8c51a7be4376e66987(value0, "echoGroups.value0");
  validate.assertNestedFin(value0, {"arguments":[{"arguments":[{"fields":[{"name":"payload","refinement":{"constructor":"NominalSubtypes.plusOne","kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}],"kind":"option"}],"kind":"array"}, "echoGroups.value0");
  const result = runtime.call("lean:NominalSubtypes.echoGroups", [value0]);
  validate.assertArrayOfApplied$fd8c51a7be4376e66987(result, "echoGroups.result");
  validate.assertNestedFin(result, {"arguments":[{"arguments":[{"fields":[{"name":"payload","refinement":{"constructor":null,"kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}],"kind":"option"}],"kind":"array"}, "echoGroups.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function echoPair(value0) {
  validate.assertAliasPair(value0, "echoPair.value0");
  validate.assertNestedFin(value0, {"fields":[{"name":"left","refinement":{"arguments":[{"arguments":[{"fields":[{"name":"payload","refinement":{"constructor":"NominalSubtypes.plusOne","kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}],"kind":"option"}],"kind":"array"}},{"name":"right","refinement":{"arguments":[{"arguments":[{"fields":[{"name":"payload","refinement":{"constructor":"NominalSubtypes.plusTwo","kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}],"kind":"option"}],"kind":"array"}}],"kind":"record","name":"NominalSubtypes.AliasPair"}, "echoPair.value0");
  const result = runtime.call("lean:NominalSubtypes.echoPair", [value0]);
  validate.assertAliasPair(result, "echoPair.result");
  validate.assertNestedFin(result, {"fields":[{"name":"left","refinement":{"arguments":[{"arguments":[{"fields":[{"name":"payload","refinement":{"constructor":null,"kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}],"kind":"option"}],"kind":"array"}},{"name":"right","refinement":{"arguments":[{"arguments":[{"fields":[{"name":"payload","refinement":{"constructor":null,"kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}],"kind":"option"}],"kind":"array"}}],"kind":"record","name":"NominalSubtypes.AliasPair"}, "echoPair.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function eventChoices(value0) {
  validate.assertNat(value0, "eventChoices.value0");
  const result = runtime.call("lean:NominalSubtypes.eventChoices", [value0]);
  validate.assertEvent(result, "eventChoices.result");
  validate.assertNestedFin(result, {"cases":[{"fields":[],"name":"empty"},{"fields":[{"name":"value","refinement":{"fields":[{"name":"payload","refinement":{"constructor":null,"kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}}],"name":"box"},{"fields":[{"name":"values","refinement":{"arguments":[{"arguments":[{"arguments":[{"constructor":null,"kind":"subtype"},{"constructor":null,"kind":"subtype"}],"kind":"result"}],"kind":"option"}],"kind":"array"}}],"name":"choices"}],"kind":"variant","name":"NominalSubtypes.Event"}, "eventChoices.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function eventEmpty(value0) {
  validate.assertNat(value0, "eventEmpty.value0");
  const result = runtime.call("lean:NominalSubtypes.eventEmpty", [value0]);
  validate.assertEvent(result, "eventEmpty.result");
  validate.assertNestedFin(result, {"cases":[{"fields":[],"name":"empty"},{"fields":[{"name":"value","refinement":{"fields":[{"name":"payload","refinement":{"constructor":null,"kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}}],"name":"box"},{"fields":[{"name":"values","refinement":{"arguments":[{"arguments":[{"arguments":[{"constructor":null,"kind":"subtype"},{"constructor":null,"kind":"subtype"}],"kind":"result"}],"kind":"option"}],"kind":"array"}}],"name":"choices"}],"kind":"variant","name":"NominalSubtypes.Event"}, "eventEmpty.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function eventFirst(value0) {
  validate.assertEvent(value0, "eventFirst.value0");
  validate.assertNestedFin(value0, {"cases":[{"fields":[],"name":"empty"},{"fields":[{"name":"value","refinement":{"fields":[{"name":"payload","refinement":{"constructor":"NominalSubtypes.plusOne","kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}}],"name":"box"},{"fields":[{"name":"values","refinement":{"arguments":[{"arguments":[{"arguments":[{"constructor":"NominalSubtypes.plusOne","kind":"subtype"},{"constructor":"NominalSubtypes.plusTwo","kind":"subtype"}],"kind":"result"}],"kind":"option"}],"kind":"array"}}],"name":"choices"}],"kind":"variant","name":"NominalSubtypes.Event"}, "eventFirst.value0");
  const result = runtime.call("lean:NominalSubtypes.eventFirst", [value0]);
  validate.assertNat(result, "eventFirst.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function eventSecond(value0) {
  validate.assertEvent(value0, "eventSecond.value0");
  validate.assertNestedFin(value0, {"cases":[{"fields":[],"name":"empty"},{"fields":[{"name":"value","refinement":{"fields":[{"name":"payload","refinement":{"constructor":"NominalSubtypes.plusTwo","kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}}],"name":"box"},{"fields":[{"name":"values","refinement":{"arguments":[{"arguments":[{"arguments":[{"constructor":"NominalSubtypes.plusTwo","kind":"subtype"},{"constructor":"NominalSubtypes.plusOne","kind":"subtype"}],"kind":"result"}],"kind":"option"}],"kind":"array"}}],"name":"choices"}],"kind":"variant","name":"NominalSubtypes.Event"}, "eventSecond.value0");
  const result = runtime.call("lean:NominalSubtypes.eventSecond", [value0]);
  validate.assertNat(result, "eventSecond.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function eventValue(value0) {
  validate.assertNat(value0, "eventValue.value0");
  const result = runtime.call("lean:NominalSubtypes.eventValue", [value0]);
  validate.assertEvent(result, "eventValue.result");
  validate.assertNestedFin(result, {"cases":[{"fields":[],"name":"empty"},{"fields":[{"name":"value","refinement":{"fields":[{"name":"payload","refinement":{"constructor":null,"kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}}],"name":"box"},{"fields":[{"name":"values","refinement":{"arguments":[{"arguments":[{"arguments":[{"constructor":null,"kind":"subtype"},{"constructor":null,"kind":"subtype"}],"kind":"result"}],"kind":"option"}],"kind":"array"}}],"name":"choices"}],"kind":"variant","name":"NominalSubtypes.Event"}, "eventValue.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function first(value0) {
  validate.assertEnvelope(value0, "first.value0");
  validate.assertNestedFin(value0, {"fields":[{"name":"payload","refinement":{"constructor":"NominalSubtypes.plusOne","kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}, "first.value0");
  const result = runtime.call("lean:NominalSubtypes.first", [value0]);
  validate.assertNat(result, "first.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function groupValues(value0) {
  validate.assertNat(value0, "groupValues.value0");
  const result = runtime.call("lean:NominalSubtypes.groupValues", [value0]);
  validate.assertArrayOfApplied$fd8c51a7be4376e66987(result, "groupValues.result");
  validate.assertNestedFin(result, {"arguments":[{"arguments":[{"fields":[{"name":"payload","refinement":{"constructor":null,"kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}],"kind":"option"}],"kind":"array"}, "groupValues.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function inspectAliasPair(value0) {
  validate.assertAliasPair(value0, "inspectAliasPair.value0");
  validate.assertNestedFin(value0, {"fields":[{"name":"left","refinement":{"arguments":[{"arguments":[{"fields":[{"name":"payload","refinement":{"constructor":"NominalSubtypes.plusOne","kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}],"kind":"option"}],"kind":"array"}},{"name":"right","refinement":{"arguments":[{"arguments":[{"fields":[{"name":"payload","refinement":{"constructor":"NominalSubtypes.plusTwo","kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}],"kind":"option"}],"kind":"array"}}],"kind":"record","name":"NominalSubtypes.AliasPair"}, "inspectAliasPair.value0");
  const result = runtime.call("lean:NominalSubtypes.inspectAliasPair", [value0]);
  validate.assertNat(result, "inspectAliasPair.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function listValues(value0) {
  validate.assertNat(value0, "listValues.value0");
  const result = runtime.call("lean:NominalSubtypes.listValues", [value0]);
  validate.assertApplied$6a2856fddfdde2691a33(result, "listValues.result");
  validate.assertNestedFin(result, {"arguments":[{"constructor":null,"kind":"subtype"}],"kind":"list"}, "listValues.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function nested(value0) {
  validate.assertPair(value0, "nested.value0");
  validate.assertNestedFin(value0, {"fields":[{"name":"left","refinement":{"fields":[{"name":"payload","refinement":{"constructor":"NominalSubtypes.plusOne","kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}},{"name":"right","refinement":{"fields":[{"name":"payload","refinement":{"constructor":"NominalSubtypes.plusTwo","kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}}],"kind":"record","name":"NominalSubtypes.Pair"}, "nested.value0");
  const result = runtime.call("lean:NominalSubtypes.nested", [value0]);
  validate.assertNat(result, "nested.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function noItems(value0) {
  validate.assertNat(value0, "noItems.value0");
  const result = runtime.call("lean:NominalSubtypes.noItems", [value0]);
  validate.assertArrayOfNat(result, "noItems.result");
  validate.assertNestedFin(result, {"arguments":[{"constructor":null,"kind":"subtype"}],"kind":"array"}, "noItems.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function optional(value0) {
  validate.assertNat(value0, "optional.value0");
  const result = runtime.call("lean:NominalSubtypes.optional", [value0]);
  validate.assertApplied$5e2b3a8b49eb1bdceb39(result, "optional.result");
  validate.assertNestedFin(result, {"arguments":[{"constructor":null,"kind":"subtype"}],"kind":"option"}, "optional.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function pairValues(value0) {
  validate.assertNat(value0, "pairValues.value0");
  const result = runtime.call("lean:NominalSubtypes.pairValues", [value0]);
  validate.assertAliasPair(result, "pairValues.result");
  validate.assertNestedFin(result, {"fields":[{"name":"left","refinement":{"arguments":[{"arguments":[{"fields":[{"name":"payload","refinement":{"constructor":null,"kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}],"kind":"option"}],"kind":"array"}},{"name":"right","refinement":{"arguments":[{"arguments":[{"fields":[{"name":"payload","refinement":{"constructor":null,"kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}],"kind":"option"}],"kind":"array"}}],"kind":"record","name":"NominalSubtypes.AliasPair"}, "pairValues.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function plainFin(value0) {
  validate.assertNat(value0, "plainFin.value0");
  validate.assertFin(value0, "3", "plainFin.value0");
  const result = runtime.call("lean:NominalSubtypes.plainFin", [value0]);
  validate.assertNat(result, "plainFin.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function produceEnvelope(value0) {
  validate.assertNat(value0, "produceEnvelope.value0");
  const result = runtime.call("lean:NominalSubtypes.produceEnvelope", [value0]);
  validate.assertEnvelope(result, "produceEnvelope.result");
  validate.assertNestedFin(result, {"fields":[{"name":"payload","refinement":{"constructor":null,"kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}, "produceEnvelope.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function product(value0) {
  validate.assertNat(value0, "product.value0");
  const result = runtime.call("lean:NominalSubtypes.product", [value0]);
  validate.assertApplied$5433d385d845a030e67d(result, "product.result");
  validate.assertNestedFin(result, {"arguments":[{"constructor":null,"kind":"subtype"},{"constructor":null,"kind":"subtype"}],"kind":"tuple"}, "product.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function scalar(value0) {
  validate.assertNat(value0, "scalar.value0");
  const result = runtime.call("lean:NominalSubtypes.scalar", [value0]);
  validate.assertNat(result, "scalar.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function second(value0) {
  validate.assertEnvelope(value0, "second.value0");
  validate.assertNestedFin(value0, {"fields":[{"name":"payload","refinement":{"constructor":"NominalSubtypes.plusTwo","kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}, "second.value0");
  const result = runtime.call("lean:NominalSubtypes.second", [value0]);
  validate.assertNat(result, "second.result");
  return result;
}

export default Object.freeze({ aliases, arrayValues, branch, combine, echo, echoEvent, echoGroups, echoPair, eventChoices, eventEmpty, eventFirst, eventSecond, eventValue, first, groupValues, inspectAliasPair, listValues, nested, noItems, optional, pairValues, plainFin, produceEnvelope, product, scalar, second });
