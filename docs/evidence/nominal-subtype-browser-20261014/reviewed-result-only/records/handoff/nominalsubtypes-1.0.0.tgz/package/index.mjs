// Generated from Binding IR SHA-256 2f38ccd2d87c26c3372cc5b97bb33ae078c10cdcaafd2cb040fb80865cdd4e18.
import { runtime } from "./internal/runtime.mjs";
import * as validate from "./internal/validators.mjs";

/**
 * Independent corpus contract.
 */
export function arrayValues(value0) {
  validate.assertNat(value0, "arrayValues.value0");
  const result = runtime.call("lean:NominalSubtypes.arrayValues", [value0]);
  validate.assertArrayOfNat(result, "arrayValues.result");
  validate.assertNestedFin(result, {"arguments":[{"constructor":null,"kind":"subtype"}],"kind":"array"}, "arrayValues.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function branch(value0) {
  validate.assertNat(value0, "branch.value0");
  const result = runtime.call("lean:NominalSubtypes.branch", [value0]);
  validate.assertApplied$6ad544f9f06180f14803(result, "branch.result");
  validate.assertNestedFin(result, {"arguments":[{"constructor":null,"kind":"subtype"},{"constructor":null,"kind":"subtype"}],"kind":"result"}, "branch.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function eventChoices(value0) {
  validate.assertNat(value0, "eventChoices.value0");
  const result = runtime.call("lean:NominalSubtypes.eventChoices", [value0]);
  validate.assertEvent(result, "eventChoices.result");
  validate.assertNestedFin(result, {"cases":[{"fields":[],"name":"empty"},{"fields":[{"name":"value","refinement":{"fields":[{"name":"payload","refinement":{"constructor":null,"kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}}],"name":"box"},{"fields":[{"name":"values","refinement":{"arguments":[{"arguments":[{"arguments":[{"constructor":null,"kind":"subtype"},{"constructor":null,"kind":"subtype"}],"kind":"result"}],"kind":"option"}],"kind":"array"}}],"name":"choices"}],"kind":"variant","name":"NominalSubtypes.Event"}, "eventChoices.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function eventEmpty(value0) {
  validate.assertNat(value0, "eventEmpty.value0");
  const result = runtime.call("lean:NominalSubtypes.eventEmpty", [value0]);
  validate.assertEvent(result, "eventEmpty.result");
  validate.assertNestedFin(result, {"cases":[{"fields":[],"name":"empty"},{"fields":[{"name":"value","refinement":{"fields":[{"name":"payload","refinement":{"constructor":null,"kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}}],"name":"box"},{"fields":[{"name":"values","refinement":{"arguments":[{"arguments":[{"arguments":[{"constructor":null,"kind":"subtype"},{"constructor":null,"kind":"subtype"}],"kind":"result"}],"kind":"option"}],"kind":"array"}}],"name":"choices"}],"kind":"variant","name":"NominalSubtypes.Event"}, "eventEmpty.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function eventValue(value0) {
  validate.assertNat(value0, "eventValue.value0");
  const result = runtime.call("lean:NominalSubtypes.eventValue", [value0]);
  validate.assertEvent(result, "eventValue.result");
  validate.assertNestedFin(result, {"cases":[{"fields":[],"name":"empty"},{"fields":[{"name":"value","refinement":{"fields":[{"name":"payload","refinement":{"constructor":null,"kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}}],"name":"box"},{"fields":[{"name":"values","refinement":{"arguments":[{"arguments":[{"arguments":[{"constructor":null,"kind":"subtype"},{"constructor":null,"kind":"subtype"}],"kind":"result"}],"kind":"option"}],"kind":"array"}}],"name":"choices"}],"kind":"variant","name":"NominalSubtypes.Event"}, "eventValue.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function groupValues(value0) {
  validate.assertNat(value0, "groupValues.value0");
  const result = runtime.call("lean:NominalSubtypes.groupValues", [value0]);
  validate.assertArrayOfApplied$fd8c51a7be4376e66987(result, "groupValues.result");
  validate.assertNestedFin(result, {"arguments":[{"arguments":[{"fields":[{"name":"payload","refinement":{"constructor":null,"kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}],"kind":"option"}],"kind":"array"}, "groupValues.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function listValues(value0) {
  validate.assertNat(value0, "listValues.value0");
  const result = runtime.call("lean:NominalSubtypes.listValues", [value0]);
  validate.assertApplied$6a2856fddfdde2691a33(result, "listValues.result");
  validate.assertNestedFin(result, {"arguments":[{"constructor":null,"kind":"subtype"}],"kind":"list"}, "listValues.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function noItems(value0) {
  validate.assertNat(value0, "noItems.value0");
  const result = runtime.call("lean:NominalSubtypes.noItems", [value0]);
  validate.assertArrayOfNat(result, "noItems.result");
  validate.assertNestedFin(result, {"arguments":[{"constructor":null,"kind":"subtype"}],"kind":"array"}, "noItems.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function optional(value0) {
  validate.assertNat(value0, "optional.value0");
  const result = runtime.call("lean:NominalSubtypes.optional", [value0]);
  validate.assertApplied$5e2b3a8b49eb1bdceb39(result, "optional.result");
  validate.assertNestedFin(result, {"arguments":[{"constructor":null,"kind":"subtype"}],"kind":"option"}, "optional.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function pairValues(value0) {
  validate.assertNat(value0, "pairValues.value0");
  const result = runtime.call("lean:NominalSubtypes.pairValues", [value0]);
  validate.assertAliasPair(result, "pairValues.result");
  validate.assertNestedFin(result, {"fields":[{"name":"left","refinement":{"arguments":[{"arguments":[{"fields":[{"name":"payload","refinement":{"constructor":null,"kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}],"kind":"option"}],"kind":"array"}},{"name":"right","refinement":{"arguments":[{"arguments":[{"fields":[{"name":"payload","refinement":{"constructor":null,"kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}],"kind":"option"}],"kind":"array"}}],"kind":"record","name":"NominalSubtypes.AliasPair"}, "pairValues.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function produceEnvelope(value0) {
  validate.assertNat(value0, "produceEnvelope.value0");
  const result = runtime.call("lean:NominalSubtypes.produceEnvelope", [value0]);
  validate.assertEnvelope(result, "produceEnvelope.result");
  validate.assertNestedFin(result, {"fields":[{"name":"payload","refinement":{"constructor":null,"kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}, "produceEnvelope.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function product(value0) {
  validate.assertNat(value0, "product.value0");
  const result = runtime.call("lean:NominalSubtypes.product", [value0]);
  validate.assertApplied$5433d385d845a030e67d(result, "product.result");
  validate.assertNestedFin(result, {"arguments":[{"constructor":null,"kind":"subtype"},{"constructor":null,"kind":"subtype"}],"kind":"tuple"}, "product.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function scalar(value0) {
  validate.assertNat(value0, "scalar.value0");
  const result = runtime.call("lean:NominalSubtypes.scalar", [value0]);
  validate.assertNat(result, "scalar.result");
  return result;
}

export default Object.freeze({ arrayValues, branch, eventChoices, eventEmpty, eventValue, groupValues, listValues, noItems, optional, pairValues, produceEnvelope, product, scalar });
