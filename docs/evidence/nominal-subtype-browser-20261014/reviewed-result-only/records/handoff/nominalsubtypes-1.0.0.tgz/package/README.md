# nominalsubtypes

Independent corpus contract.

Binding IR SHA-256: `2f38ccd2d87c26c3372cc5b97bb33ae078c10cdcaafd2cb040fb80865cdd4e18`

## Exports

### arrayValues

Independent corpus contract.

### branch

Independent corpus contract.

### eventChoices

Independent corpus contract.

### eventEmpty

Independent corpus contract.

### eventValue

Independent corpus contract.

### groupValues

Independent corpus contract.

### listValues

Independent corpus contract.

### noItems

Independent corpus contract.

### optional

Independent corpus contract.

### pairValues

Independent corpus contract.

### produceEnvelope

Independent corpus contract.

### product

Independent corpus contract.

### scalar

Independent corpus contract.

## Assurance

