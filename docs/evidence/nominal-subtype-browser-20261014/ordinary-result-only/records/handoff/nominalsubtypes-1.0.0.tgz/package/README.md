# nominalsubtypes

Compiler-checked exports for nominalsubtypes.

Binding IR SHA-256: `876d028329e0f44b957cec223ce5895e94ca5cb3245f3b5c171f7fa81dc80306`

## Exports

### arrayValues

Call NominalSubtypes.arrayValues.

### branch

Call NominalSubtypes.branch.

### eventChoices

Call NominalSubtypes.eventChoices.

### eventEmpty

Call NominalSubtypes.eventEmpty.

### eventValue

Call NominalSubtypes.eventValue.

### groupValues

Call NominalSubtypes.groupValues.

### listValues

Call NominalSubtypes.listValues.

### noItems

Call NominalSubtypes.noItems.

### optional

Call NominalSubtypes.optional.

### pairValues

Call NominalSubtypes.pairValues.

### produceEnvelope

Call NominalSubtypes.produceEnvelope.

### product

Call NominalSubtypes.product.

### scalar

Call NominalSubtypes.scalar.

## Assurance

