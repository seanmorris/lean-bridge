// Generated from Binding IR SHA-256 876d028329e0f44b957cec223ce5895e94ca5cb3245f3b5c171f7fa81dc80306.
import { runtime } from "./internal/runtime.mjs";
import * as validate from "./internal/validators.mjs";

/**
 * Call NominalSubtypes.arrayValues.
 */
export function arrayValues(arg0) {
  validate.assertNat(arg0, "arrayValues.arg0");
  const result = runtime.call("lean:NominalSubtypes.arrayValues", [arg0]);
  validate.assertArrayOfNat(result, "arrayValues.result");
  validate.assertNestedFin(result, {"arguments":[{"constructor":null,"kind":"subtype"}],"kind":"array"}, "arrayValues.result");
  return result;
}

/**
 * Call NominalSubtypes.branch.
 */
export function branch(arg0) {
  validate.assertNat(arg0, "branch.arg0");
  const result = runtime.call("lean:NominalSubtypes.branch", [arg0]);
  validate.assertApplied$6ad544f9f06180f14803(result, "branch.result");
  validate.assertNestedFin(result, {"arguments":[{"constructor":null,"kind":"subtype"},{"constructor":null,"kind":"subtype"}],"kind":"result"}, "branch.result");
  return result;
}

/**
 * Call NominalSubtypes.eventChoices.
 */
export function eventChoices(arg0) {
  validate.assertNat(arg0, "eventChoices.arg0");
  const result = runtime.call("lean:NominalSubtypes.eventChoices", [arg0]);
  validate.assertEvent(result, "eventChoices.result");
  validate.assertNestedFin(result, {"cases":[{"fields":[],"name":"empty"},{"fields":[{"name":"value","refinement":{"fields":[{"name":"payload","refinement":{"constructor":null,"kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}}],"name":"box"},{"fields":[{"name":"values","refinement":{"arguments":[{"arguments":[{"arguments":[{"constructor":null,"kind":"subtype"},{"constructor":null,"kind":"subtype"}],"kind":"result"}],"kind":"option"}],"kind":"array"}}],"name":"choices"}],"kind":"variant","name":"NominalSubtypes.Event"}, "eventChoices.result");
  return result;
}

/**
 * Call NominalSubtypes.eventEmpty.
 */
export function eventEmpty(arg0) {
  validate.assertNat(arg0, "eventEmpty.arg0");
  const result = runtime.call("lean:NominalSubtypes.eventEmpty", [arg0]);
  validate.assertEvent(result, "eventEmpty.result");
  validate.assertNestedFin(result, {"cases":[{"fields":[],"name":"empty"},{"fields":[{"name":"value","refinement":{"fields":[{"name":"payload","refinement":{"constructor":null,"kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}}],"name":"box"},{"fields":[{"name":"values","refinement":{"arguments":[{"arguments":[{"arguments":[{"constructor":null,"kind":"subtype"},{"constructor":null,"kind":"subtype"}],"kind":"result"}],"kind":"option"}],"kind":"array"}}],"name":"choices"}],"kind":"variant","name":"NominalSubtypes.Event"}, "eventEmpty.result");
  return result;
}

/**
 * Call NominalSubtypes.eventValue.
 */
export function eventValue(arg0) {
  validate.assertNat(arg0, "eventValue.arg0");
  const result = runtime.call("lean:NominalSubtypes.eventValue", [arg0]);
  validate.assertEvent(result, "eventValue.result");
  validate.assertNestedFin(result, {"cases":[{"fields":[],"name":"empty"},{"fields":[{"name":"value","refinement":{"fields":[{"name":"payload","refinement":{"constructor":null,"kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}}],"name":"box"},{"fields":[{"name":"values","refinement":{"arguments":[{"arguments":[{"arguments":[{"constructor":null,"kind":"subtype"},{"constructor":null,"kind":"subtype"}],"kind":"result"}],"kind":"option"}],"kind":"array"}}],"name":"choices"}],"kind":"variant","name":"NominalSubtypes.Event"}, "eventValue.result");
  return result;
}

/**
 * Call NominalSubtypes.groupValues.
 */
export function groupValues(arg0) {
  validate.assertNat(arg0, "groupValues.arg0");
  const result = runtime.call("lean:NominalSubtypes.groupValues", [arg0]);
  validate.assertArrayOfApplied$fd8c51a7be4376e66987(result, "groupValues.result");
  validate.assertNestedFin(result, {"arguments":[{"arguments":[{"fields":[{"name":"payload","refinement":{"constructor":null,"kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}],"kind":"option"}],"kind":"array"}, "groupValues.result");
  return result;
}

/**
 * Call NominalSubtypes.listValues.
 */
export function listValues(arg0) {
  validate.assertNat(arg0, "listValues.arg0");
  const result = runtime.call("lean:NominalSubtypes.listValues", [arg0]);
  validate.assertApplied$6a2856fddfdde2691a33(result, "listValues.result");
  validate.assertNestedFin(result, {"arguments":[{"constructor":null,"kind":"subtype"}],"kind":"list"}, "listValues.result");
  return result;
}

/**
 * Call NominalSubtypes.noItems.
 */
export function noItems(arg0) {
  validate.assertNat(arg0, "noItems.arg0");
  const result = runtime.call("lean:NominalSubtypes.noItems", [arg0]);
  validate.assertArrayOfNat(result, "noItems.result");
  validate.assertNestedFin(result, {"arguments":[{"constructor":null,"kind":"subtype"}],"kind":"array"}, "noItems.result");
  return result;
}

/**
 * Call NominalSubtypes.optional.
 */
export function optional(arg0) {
  validate.assertNat(arg0, "optional.arg0");
  const result = runtime.call("lean:NominalSubtypes.optional", [arg0]);
  validate.assertApplied$5e2b3a8b49eb1bdceb39(result, "optional.result");
  validate.assertNestedFin(result, {"arguments":[{"constructor":null,"kind":"subtype"}],"kind":"option"}, "optional.result");
  return result;
}

/**
 * Call NominalSubtypes.pairValues.
 */
export function pairValues(arg0) {
  validate.assertNat(arg0, "pairValues.arg0");
  const result = runtime.call("lean:NominalSubtypes.pairValues", [arg0]);
  validate.assertAliasPair(result, "pairValues.result");
  validate.assertNestedFin(result, {"fields":[{"name":"left","refinement":{"arguments":[{"arguments":[{"fields":[{"name":"payload","refinement":{"constructor":null,"kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}],"kind":"option"}],"kind":"array"}},{"name":"right","refinement":{"arguments":[{"arguments":[{"fields":[{"name":"payload","refinement":{"constructor":null,"kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}],"kind":"option"}],"kind":"array"}}],"kind":"record","name":"NominalSubtypes.AliasPair"}, "pairValues.result");
  return result;
}

/**
 * Call NominalSubtypes.produceEnvelope.
 */
export function produceEnvelope(arg0) {
  validate.assertNat(arg0, "produceEnvelope.arg0");
  const result = runtime.call("lean:NominalSubtypes.produceEnvelope", [arg0]);
  validate.assertEnvelope(result, "produceEnvelope.result");
  validate.assertNestedFin(result, {"fields":[{"name":"payload","refinement":{"constructor":null,"kind":"subtype"}},{"name":"digit","refinement":{"bound":"3","kind":"fin"}}],"kind":"record","name":"NominalSubtypes.Envelope"}, "produceEnvelope.result");
  return result;
}

/**
 * Call NominalSubtypes.product.
 */
export function product(arg0) {
  validate.assertNat(arg0, "product.arg0");
  const result = runtime.call("lean:NominalSubtypes.product", [arg0]);
  validate.assertApplied$5433d385d845a030e67d(result, "product.result");
  validate.assertNestedFin(result, {"arguments":[{"constructor":null,"kind":"subtype"},{"constructor":null,"kind":"subtype"}],"kind":"tuple"}, "product.result");
  return result;
}

/**
 * Call NominalSubtypes.scalar.
 */
export function scalar(arg0) {
  validate.assertNat(arg0, "scalar.arg0");
  const result = runtime.call("lean:NominalSubtypes.scalar", [arg0]);
  validate.assertNat(result, "scalar.result");
  return result;
}

export default Object.freeze({ arrayValues, branch, eventChoices, eventEmpty, eventValue, groupValues, listValues, noItems, optional, pairValues, produceEnvelope, product, scalar });
