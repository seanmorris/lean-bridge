// Generated from Binding IR SHA-256 bf75c1cec8b074f336582b4567d89e48924982edb6217f4cf5a28281438b01db.
import { runtime } from "./internal/runtime.mjs";
import * as validate from "./internal/validators.mjs";

/**
 * Call CheckedRecordValueIndices.produceAb.
 */
export function produceAb() {
  const result = runtime.call("lean:CheckedRecordValueIndices.produceAb", []);
  validate.assertAb(result, "produceAb.result");
  return result;
}

/**
 * Call CheckedRecordValueIndices.produceEmptySized.
 */
export function produceEmptySized() {
  const result = runtime.call("lean:CheckedRecordValueIndices.produceEmptySized", []);
  validate.assertEmptySized(result, "produceEmptySized.result");
  return result;
}

/**
 * Call CheckedRecordValueIndices.produceEmptyString.
 */
export function produceEmptyString(arg0) {
  validate.assertNat(arg0, "produceEmptyString.arg0");
  const result = runtime.call("lean:CheckedRecordValueIndices.produceEmptyString", [arg0]);
  validate.assertEmptyToken(result, "produceEmptyString.result");
  return result;
}

/**
 * Call CheckedRecordValueIndices.produceFalseBool.
 */
export function produceFalseBool() {
  const result = runtime.call("lean:CheckedRecordValueIndices.produceFalseBool", []);
  validate.assertOff(result, "produceFalseBool.result");
  return result;
}

/**
 * Lean-produced records need no host-side checked constructor. 
 */
export function produceTrueBool() {
  const result = runtime.call("lean:CheckedRecordValueIndices.produceTrueBool", []);
  validate.assertOn(result, "produceTrueBool.result");
  return result;
}

/**
 * Call CheckedRecordValueIndices.produceUnicodeString.
 */
export function produceUnicodeString(arg0) {
  validate.assertNat(arg0, "produceUnicodeString.arg0");
  const result = runtime.call("lean:CheckedRecordValueIndices.produceUnicodeString", [arg0]);
  validate.assertUnicodeToken(result, "produceUnicodeString.result");
  return result;
}

/**
 * Call CheckedRecordValueIndices.produceWideNat.
 */
export function produceWideNat(arg0) {
  validate.assertNat(arg0, "produceWideNat.arg0");
  const result = runtime.call("lean:CheckedRecordValueIndices.produceWideNat", [arg0]);
  validate.assertWideToken(result, "produceWideNat.result");
  return result;
}

/**
 * Call CheckedRecordValueIndices.produceZeroNat.
 */
export function produceZeroNat(arg0) {
  validate.assertNat(arg0, "produceZeroNat.arg0");
  const result = runtime.call("lean:CheckedRecordValueIndices.produceZeroNat", [arg0]);
  validate.assertZeroToken(result, "produceZeroNat.result");
  return result;
}

export default Object.freeze({ produceAb, produceEmptySized, produceEmptyString, produceFalseBool, produceTrueBool, produceUnicodeString, produceWideNat, produceZeroNat });
