# checkedrecordvalueindices

Compiler-checked exports for checkedrecordvalueindices.

Binding IR SHA-256: `bf75c1cec8b074f336582b4567d89e48924982edb6217f4cf5a28281438b01db`

## Exports

### produceAb

Call CheckedRecordValueIndices.produceAb.

### produceEmptySized

Call CheckedRecordValueIndices.produceEmptySized.

### produceEmptyString

Call CheckedRecordValueIndices.produceEmptyString.

### produceFalseBool

Call CheckedRecordValueIndices.produceFalseBool.

### produceTrueBool

Lean-produced records need no host-side checked constructor. 

### produceUnicodeString

Call CheckedRecordValueIndices.produceUnicodeString.

### produceWideNat

Call CheckedRecordValueIndices.produceWideNat.

### produceZeroNat

Call CheckedRecordValueIndices.produceZeroNat.

## Assurance

