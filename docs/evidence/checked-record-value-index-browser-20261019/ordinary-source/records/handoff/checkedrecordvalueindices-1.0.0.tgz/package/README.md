# checkedrecordvalueindices

Compiler-checked exports for checkedrecordvalueindices.

Binding IR SHA-256: `05eea5ff9cd617970d13fe47bcfea014b32ba9b5fc69e28d5e291395399581ef`

## Exports

### abStringIndex

Call CheckedRecordValueIndices.abStringIndex.

### emptySizedIndex

Call CheckedRecordValueIndices.emptySizedIndex.

### emptyStringIndex

Call CheckedRecordValueIndices.emptyStringIndex.

### falseBoolIndex

Call CheckedRecordValueIndices.falseBoolIndex.

### produceAb

Call CheckedRecordValueIndices.produceAb.

### produceEmptySized

Call CheckedRecordValueIndices.produceEmptySized.

### produceEmptyString

Call CheckedRecordValueIndices.produceEmptyString.

### produceFalseBool

Call CheckedRecordValueIndices.produceFalseBool.

### produceTrueBool

Lean-produced records need no host-side checked constructor. 

### produceUnicodeString

Call CheckedRecordValueIndices.produceUnicodeString.

### produceWideNat

Call CheckedRecordValueIndices.produceWideNat.

### produceZeroNat

Call CheckedRecordValueIndices.produceZeroNat.

### trueBoolIndex

Call CheckedRecordValueIndices.trueBoolIndex.

### unicodeStringIndex

Call CheckedRecordValueIndices.unicodeStringIndex.

### wideNatIndex

Call CheckedRecordValueIndices.wideNatIndex.

### zeroNatIndex

Call CheckedRecordValueIndices.zeroNatIndex.

## Assurance

