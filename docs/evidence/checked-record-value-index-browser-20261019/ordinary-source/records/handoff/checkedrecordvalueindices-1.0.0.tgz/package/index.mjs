// Generated from Binding IR SHA-256 05eea5ff9cd617970d13fe47bcfea014b32ba9b5fc69e28d5e291395399581ef.
import { runtime } from "./internal/runtime.mjs";
import * as validate from "./internal/validators.mjs";

/**
 * Call CheckedRecordValueIndices.abStringIndex.
 */
export function abStringIndex(arg0) {
  validate.assertAb(arg0, "abStringIndex.arg0");
  const result = runtime.call("lean:CheckedRecordValueIndices.abStringIndex", [arg0]);
  validate.assertNat(result, "abStringIndex.result");
  return result;
}

/**
 * Call CheckedRecordValueIndices.emptySizedIndex.
 */
export function emptySizedIndex(arg0) {
  validate.assertEmptySized(arg0, "emptySizedIndex.arg0");
  const result = runtime.call("lean:CheckedRecordValueIndices.emptySizedIndex", [arg0]);
  validate.assertNat(result, "emptySizedIndex.result");
  return result;
}

/**
 * Call CheckedRecordValueIndices.emptyStringIndex.
 */
export function emptyStringIndex(arg0) {
  validate.assertEmptyToken(arg0, "emptyStringIndex.arg0");
  const result = runtime.call("lean:CheckedRecordValueIndices.emptyStringIndex", [arg0]);
  validate.assertNat(result, "emptyStringIndex.result");
  return result;
}

/**
 * Call CheckedRecordValueIndices.falseBoolIndex.
 */
export function falseBoolIndex(arg0) {
  validate.assertOff(arg0, "falseBoolIndex.arg0");
  const result = runtime.call("lean:CheckedRecordValueIndices.falseBoolIndex", [arg0]);
  validate.assertNat(result, "falseBoolIndex.result");
  return result;
}

/**
 * Call CheckedRecordValueIndices.produceAb.
 */
export function produceAb() {
  const result = runtime.call("lean:CheckedRecordValueIndices.produceAb", []);
  validate.assertAb(result, "produceAb.result");
  return result;
}

/**
 * Call CheckedRecordValueIndices.produceEmptySized.
 */
export function produceEmptySized() {
  const result = runtime.call("lean:CheckedRecordValueIndices.produceEmptySized", []);
  validate.assertEmptySized(result, "produceEmptySized.result");
  return result;
}

/**
 * Call CheckedRecordValueIndices.produceEmptyString.
 */
export function produceEmptyString(arg0) {
  validate.assertNat(arg0, "produceEmptyString.arg0");
  const result = runtime.call("lean:CheckedRecordValueIndices.produceEmptyString", [arg0]);
  validate.assertEmptyToken(result, "produceEmptyString.result");
  return result;
}

/**
 * Call CheckedRecordValueIndices.produceFalseBool.
 */
export function produceFalseBool() {
  const result = runtime.call("lean:CheckedRecordValueIndices.produceFalseBool", []);
  validate.assertOff(result, "produceFalseBool.result");
  return result;
}

/**
 * Lean-produced records need no host-side checked constructor. 
 */
export function produceTrueBool() {
  const result = runtime.call("lean:CheckedRecordValueIndices.produceTrueBool", []);
  validate.assertOn(result, "produceTrueBool.result");
  return result;
}

/**
 * Call CheckedRecordValueIndices.produceUnicodeString.
 */
export function produceUnicodeString(arg0) {
  validate.assertNat(arg0, "produceUnicodeString.arg0");
  const result = runtime.call("lean:CheckedRecordValueIndices.produceUnicodeString", [arg0]);
  validate.assertUnicodeToken(result, "produceUnicodeString.result");
  return result;
}

/**
 * Call CheckedRecordValueIndices.produceWideNat.
 */
export function produceWideNat(arg0) {
  validate.assertNat(arg0, "produceWideNat.arg0");
  const result = runtime.call("lean:CheckedRecordValueIndices.produceWideNat", [arg0]);
  validate.assertWideToken(result, "produceWideNat.result");
  return result;
}

/**
 * Call CheckedRecordValueIndices.produceZeroNat.
 */
export function produceZeroNat(arg0) {
  validate.assertNat(arg0, "produceZeroNat.arg0");
  const result = runtime.call("lean:CheckedRecordValueIndices.produceZeroNat", [arg0]);
  validate.assertZeroToken(result, "produceZeroNat.result");
  return result;
}

/**
 * Call CheckedRecordValueIndices.trueBoolIndex.
 */
export function trueBoolIndex(arg0) {
  validate.assertOn(arg0, "trueBoolIndex.arg0");
  const result = runtime.call("lean:CheckedRecordValueIndices.trueBoolIndex", [arg0]);
  validate.assertNat(result, "trueBoolIndex.result");
  return result;
}

/**
 * Call CheckedRecordValueIndices.unicodeStringIndex.
 */
export function unicodeStringIndex(arg0) {
  validate.assertUnicodeToken(arg0, "unicodeStringIndex.arg0");
  const result = runtime.call("lean:CheckedRecordValueIndices.unicodeStringIndex", [arg0]);
  validate.assertNat(result, "unicodeStringIndex.result");
  return result;
}

/**
 * Call CheckedRecordValueIndices.wideNatIndex.
 */
export function wideNatIndex(arg0) {
  validate.assertWideToken(arg0, "wideNatIndex.arg0");
  const result = runtime.call("lean:CheckedRecordValueIndices.wideNatIndex", [arg0]);
  validate.assertNat(result, "wideNatIndex.result");
  return result;
}

/**
 * Call CheckedRecordValueIndices.zeroNatIndex.
 */
export function zeroNatIndex(arg0) {
  validate.assertZeroToken(arg0, "zeroNatIndex.arg0");
  const result = runtime.call("lean:CheckedRecordValueIndices.zeroNatIndex", [arg0]);
  validate.assertNat(result, "zeroNatIndex.result");
  return result;
}

export default Object.freeze({ abStringIndex, emptySizedIndex, emptyStringIndex, falseBoolIndex, produceAb, produceEmptySized, produceEmptyString, produceFalseBool, produceTrueBool, produceUnicodeString, produceWideNat, produceZeroNat, trueBoolIndex, unicodeStringIndex, wideNatIndex, zeroNatIndex });
