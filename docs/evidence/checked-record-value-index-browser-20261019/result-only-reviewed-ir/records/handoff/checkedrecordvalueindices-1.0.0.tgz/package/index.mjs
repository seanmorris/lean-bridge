// Generated from Binding IR SHA-256 9d1ccb24ddb9c697119890d6cc2fe44d7e98c14853a10f33caec53a84f268492.
import { runtime } from "./internal/runtime.mjs";
import * as validate from "./internal/validators.mjs";

/**
 * Independent corpus contract.
 */
export function produceAb() {
  const result = runtime.call("lean:CheckedRecordValueIndices.produceAb", []);
  validate.assertAb(result, "produceAb.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function produceEmptySized() {
  const result = runtime.call("lean:CheckedRecordValueIndices.produceEmptySized", []);
  validate.assertEmptySized(result, "produceEmptySized.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function produceEmptyString(value0) {
  validate.assertNat(value0, "produceEmptyString.value0");
  const result = runtime.call("lean:CheckedRecordValueIndices.produceEmptyString", [value0]);
  validate.assertEmptyToken(result, "produceEmptyString.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function produceFalseBool() {
  const result = runtime.call("lean:CheckedRecordValueIndices.produceFalseBool", []);
  validate.assertOff(result, "produceFalseBool.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function produceTrueBool() {
  const result = runtime.call("lean:CheckedRecordValueIndices.produceTrueBool", []);
  validate.assertOn(result, "produceTrueBool.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function produceUnicodeString(value0) {
  validate.assertNat(value0, "produceUnicodeString.value0");
  const result = runtime.call("lean:CheckedRecordValueIndices.produceUnicodeString", [value0]);
  validate.assertUnicodeToken(result, "produceUnicodeString.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function produceWideNat(value0) {
  validate.assertNat(value0, "produceWideNat.value0");
  const result = runtime.call("lean:CheckedRecordValueIndices.produceWideNat", [value0]);
  validate.assertWideToken(result, "produceWideNat.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function produceZeroNat(value0) {
  validate.assertNat(value0, "produceZeroNat.value0");
  const result = runtime.call("lean:CheckedRecordValueIndices.produceZeroNat", [value0]);
  validate.assertZeroToken(result, "produceZeroNat.result");
  return result;
}

export default Object.freeze({ produceAb, produceEmptySized, produceEmptyString, produceFalseBool, produceTrueBool, produceUnicodeString, produceWideNat, produceZeroNat });
