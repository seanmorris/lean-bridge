# checkedrecordvalueindices

Independent corpus contract.

Binding IR SHA-256: `e22480b71bdca0b86575bc59232807b1af2e718708bd20dfe752eb1eb66024eb`

## Exports

### abStringIndex

Independent corpus contract.

### emptySizedIndex

Independent corpus contract.

### emptyStringIndex

Independent corpus contract.

### falseBoolIndex

Independent corpus contract.

### produceAb

Independent corpus contract.

### produceEmptySized

Independent corpus contract.

### produceEmptyString

Independent corpus contract.

### produceFalseBool

Independent corpus contract.

### produceTrueBool

Independent corpus contract.

### produceUnicodeString

Independent corpus contract.

### produceWideNat

Independent corpus contract.

### produceZeroNat

Independent corpus contract.

### trueBoolIndex

Independent corpus contract.

### unicodeStringIndex

Independent corpus contract.

### wideNatIndex

Independent corpus contract.

### zeroNatIndex

Independent corpus contract.

## Assurance

