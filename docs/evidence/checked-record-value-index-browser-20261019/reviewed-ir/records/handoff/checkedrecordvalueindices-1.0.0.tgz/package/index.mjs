// Generated from Binding IR SHA-256 e22480b71bdca0b86575bc59232807b1af2e718708bd20dfe752eb1eb66024eb.
import { runtime } from "./internal/runtime.mjs";
import * as validate from "./internal/validators.mjs";

/**
 * Independent corpus contract.
 */
export function abStringIndex(value0) {
  validate.assertAb(value0, "abStringIndex.value0");
  const result = runtime.call("lean:CheckedRecordValueIndices.abStringIndex", [value0]);
  validate.assertNat(result, "abStringIndex.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function emptySizedIndex(value0) {
  validate.assertEmptySized(value0, "emptySizedIndex.value0");
  const result = runtime.call("lean:CheckedRecordValueIndices.emptySizedIndex", [value0]);
  validate.assertNat(result, "emptySizedIndex.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function emptyStringIndex(value0) {
  validate.assertEmptyToken(value0, "emptyStringIndex.value0");
  const result = runtime.call("lean:CheckedRecordValueIndices.emptyStringIndex", [value0]);
  validate.assertNat(result, "emptyStringIndex.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function falseBoolIndex(value0) {
  validate.assertOff(value0, "falseBoolIndex.value0");
  const result = runtime.call("lean:CheckedRecordValueIndices.falseBoolIndex", [value0]);
  validate.assertNat(result, "falseBoolIndex.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function produceAb() {
  const result = runtime.call("lean:CheckedRecordValueIndices.produceAb", []);
  validate.assertAb(result, "produceAb.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function produceEmptySized() {
  const result = runtime.call("lean:CheckedRecordValueIndices.produceEmptySized", []);
  validate.assertEmptySized(result, "produceEmptySized.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function produceEmptyString(value0) {
  validate.assertNat(value0, "produceEmptyString.value0");
  const result = runtime.call("lean:CheckedRecordValueIndices.produceEmptyString", [value0]);
  validate.assertEmptyToken(result, "produceEmptyString.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function produceFalseBool() {
  const result = runtime.call("lean:CheckedRecordValueIndices.produceFalseBool", []);
  validate.assertOff(result, "produceFalseBool.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function produceTrueBool() {
  const result = runtime.call("lean:CheckedRecordValueIndices.produceTrueBool", []);
  validate.assertOn(result, "produceTrueBool.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function produceUnicodeString(value0) {
  validate.assertNat(value0, "produceUnicodeString.value0");
  const result = runtime.call("lean:CheckedRecordValueIndices.produceUnicodeString", [value0]);
  validate.assertUnicodeToken(result, "produceUnicodeString.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function produceWideNat(value0) {
  validate.assertNat(value0, "produceWideNat.value0");
  const result = runtime.call("lean:CheckedRecordValueIndices.produceWideNat", [value0]);
  validate.assertWideToken(result, "produceWideNat.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function produceZeroNat(value0) {
  validate.assertNat(value0, "produceZeroNat.value0");
  const result = runtime.call("lean:CheckedRecordValueIndices.produceZeroNat", [value0]);
  validate.assertZeroToken(result, "produceZeroNat.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function trueBoolIndex(value0) {
  validate.assertOn(value0, "trueBoolIndex.value0");
  const result = runtime.call("lean:CheckedRecordValueIndices.trueBoolIndex", [value0]);
  validate.assertNat(result, "trueBoolIndex.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function unicodeStringIndex(value0) {
  validate.assertUnicodeToken(value0, "unicodeStringIndex.value0");
  const result = runtime.call("lean:CheckedRecordValueIndices.unicodeStringIndex", [value0]);
  validate.assertNat(result, "unicodeStringIndex.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function wideNatIndex(value0) {
  validate.assertWideToken(value0, "wideNatIndex.value0");
  const result = runtime.call("lean:CheckedRecordValueIndices.wideNatIndex", [value0]);
  validate.assertNat(result, "wideNatIndex.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function zeroNatIndex(value0) {
  validate.assertZeroToken(value0, "zeroNatIndex.value0");
  const result = runtime.call("lean:CheckedRecordValueIndices.zeroNatIndex", [value0]);
  validate.assertNat(result, "zeroNatIndex.result");
  return result;
}

export default Object.freeze({ abStringIndex, emptySizedIndex, emptyStringIndex, falseBoolIndex, produceAb, produceEmptySized, produceEmptyString, produceFalseBool, produceTrueBool, produceUnicodeString, produceWideNat, produceZeroNat, trueBoolIndex, unicodeStringIndex, wideNatIndex, zeroNatIndex });
