#include "component.h"
#include "lean_bridge_native_runtime.h"
static _Thread_local int lean_bridge_owned_callback_failure_9fed69d83c4791794e3c_state;
int lean_bridge_owned_callback_failure_9fed69d83c4791794e3c(void) { int result = lean_bridge_owned_callback_failure_9fed69d83c4791794e3c_state; lean_bridge_owned_callback_failure_9fed69d83c4791794e3c_state = 0; return result; }
