declare const leanResource: unique symbol;

export interface LeanLease {
  readonly disposed: boolean;
  dispose(): boolean;
  retain(): this;
}

/** Independent owned aggregate contract. */
export interface BundleInput {
  readonly "primary": Ticket;
  readonly "spare": (Readonly<{ tag: "none" }> | Readonly<{ tag: "some"; value: Ticket }>);
  readonly "peers": ReadonlyArray<Ticket>;
  readonly "history": ReadonlyArray<Ticket>;
  readonly "payload": PayloadInput;
}

export interface Bundle {
  readonly "primary": Ticket;
  readonly "spare": (Readonly<{ tag: "none" }> | Readonly<{ tag: "some"; value: Ticket }>);
  readonly "peers": ReadonlyArray<Ticket>;
  readonly "history": ReadonlyArray<Ticket>;
  readonly "payload": Payload;
}

/** Independent owned aggregate contract. */
export interface PayloadInput {
  readonly "count": bigint;
  readonly "bytes": Uint8Array;
}

export interface Payload {
  readonly "count": bigint;
  readonly "bytes": Uint8Array;
}

/** Independent owned aggregate contract. */
export interface Ticket extends LeanLease {
  readonly [leanResource]: "lean:Owned.Ticket";
}

/** Independent corpus contract. */
export function echoRecord(arg0: BundleInput): Bundle;

/** Independent corpus contract. */
export function echoRecordAlternate(arg0: BundleInput): Bundle;

/** Independent corpus contract. */
export function newTicket(arg0: bigint, arg1: string): Ticket;

/** Independent corpus contract. */
export function serial(arg0: Ticket): bigint;

/** Independent corpus contract. */
export function transferRecord(arg0: Bundle): Bundle;

/** Release this component and invalidate its outstanding leases. */
export function close(): boolean;
/** Supply the typed fallback required by an uninhabited callback result. */
export function withRecovery<Args extends readonly unknown[], Result>(operation: (...args: Args) => Result, recovery: Result): (...args: Args) => Result;

declare const bindings: Readonly<{
  echoRecord: typeof echoRecord;
  echoRecordAlternate: typeof echoRecordAlternate;
  newTicket: typeof newTicket;
  serial: typeof serial;
  transferRecord: typeof transferRecord;
  close: typeof close;
  withRecovery: typeof withRecovery;
}>;
export default bindings;
