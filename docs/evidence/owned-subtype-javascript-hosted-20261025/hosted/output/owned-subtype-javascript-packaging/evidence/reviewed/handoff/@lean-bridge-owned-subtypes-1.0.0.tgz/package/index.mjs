// Generated from Binding IR SHA-256 9fed69d83c4791794e3cca73366ef7ee1937780570c6e2491db9052451d01f32.
import { runtime } from "./internal/runtime.mjs";

/** Independent corpus contract. */
export function echoRecord(arg0) {
  return runtime.call("lean:Owned.echoRecord", Array.from(arguments));
}

/** Independent corpus contract. */
export function echoRecordAlternate(arg0) {
  return runtime.call("lean:Owned.echoRecordAlternate", Array.from(arguments));
}

/** Independent corpus contract. */
export function newTicket(arg0, arg1) {
  return runtime.call("lean:Owned.newTicket", Array.from(arguments));
}

/** Independent corpus contract. */
export function serial(arg0) {
  return runtime.call("lean:Owned.serial", Array.from(arguments));
}

/** Independent corpus contract. */
export function transferRecord(arg0) {
  return runtime.call("lean:Owned.transferRecord", Array.from(arguments));
}

export function close() { return runtime.close(); }
export function withRecovery(operation, recovery) { return runtime.withRecovery(operation, recovery); }
export default Object.freeze({ echoRecord, echoRecordAlternate, newTicket, serial, transferRecord, close, withRecovery });
