// Generated from Binding IR SHA-256 d18d8be33f0e7cbe61f995dccac6512ab176fd961fc1a9c00c23c39d0cc63882.
import { runtime } from "./internal/runtime.mjs";

/** Call Owned.echoRecord. */
export function echoRecord(arg0) {
  return runtime.call("lean:Owned.echoRecord", Array.from(arguments));
}

/** Call Owned.echoRecordAlternate. */
export function echoRecordAlternate(arg0) {
  return runtime.call("lean:Owned.echoRecordAlternate", Array.from(arguments));
}

/** Call Owned.newTicket. */
export function newTicket(arg0, arg1) {
  return runtime.call("lean:Owned.newTicket", Array.from(arguments));
}

/** Call Owned.serial. */
export function serial(arg0) {
  return runtime.call("lean:Owned.serial", Array.from(arguments));
}

/** Call Owned.transferRecord. */
export function transferRecord(arg0) {
  return runtime.call("lean:Owned.transferRecord", Array.from(arguments));
}

export function close() { return runtime.close(); }
export function withRecovery(operation, recovery) { return runtime.withRecovery(operation, recovery); }
export default Object.freeze({ echoRecord, echoRecordAlternate, newTicket, serial, transferRecord, close, withRecovery });
