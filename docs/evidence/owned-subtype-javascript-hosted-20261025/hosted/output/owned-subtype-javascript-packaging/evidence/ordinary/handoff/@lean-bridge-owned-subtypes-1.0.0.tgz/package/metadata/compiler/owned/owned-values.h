#pragma once
#include <stdint.h>
#include <stddef.h>
/* Private generated adapter values. Host APIs keep resource tokens opaque. */
typedef struct lbov_d18d8be33f0e7cbe61f9_t82551d965c182180b0dd lbov_d18d8be33f0e7cbe61f9_t82551d965c182180b0dd;
typedef struct lbov_d18d8be33f0e7cbe61f9_t659ec6a690764999d00d lbov_d18d8be33f0e7cbe61f9_t659ec6a690764999d00d;
typedef struct lbov_d18d8be33f0e7cbe61f9_t817592654f48ba756bd4 lbov_d18d8be33f0e7cbe61f9_t817592654f48ba756bd4;
typedef struct lbov_d18d8be33f0e7cbe61f9_t5faad500583201774348 lbov_d18d8be33f0e7cbe61f9_t5faad500583201774348;
typedef struct lbov_d18d8be33f0e7cbe61f9_t550e0acb733e8dd08e4e lbov_d18d8be33f0e7cbe61f9_t550e0acb733e8dd08e4e;
typedef struct lbov_d18d8be33f0e7cbe61f9_t6de8e950bc342c30091c lbov_d18d8be33f0e7cbe61f9_t6de8e950bc342c30091c;
typedef struct lbov_d18d8be33f0e7cbe61f9_tf098e5912ebfda269f53 lbov_d18d8be33f0e7cbe61f9_tf098e5912ebfda269f53;
typedef struct lbov_d18d8be33f0e7cbe61f9_t11140334dba7a15b6b99 lbov_d18d8be33f0e7cbe61f9_t11140334dba7a15b6b99;
typedef struct lbov_d18d8be33f0e7cbe61f9_t167081552b6f9c1d1afd lbov_d18d8be33f0e7cbe61f9_t167081552b6f9c1d1afd;
typedef struct lbov_d18d8be33f0e7cbe61f9_tdc0347e1f7f5c4d928f1 lbov_d18d8be33f0e7cbe61f9_tdc0347e1f7f5c4d928f1;
struct lbov_d18d8be33f0e7cbe61f9_t6de8e950bc342c30091c {
  uint64_t token;
};
struct lbov_d18d8be33f0e7cbe61f9_tf098e5912ebfda269f53 {
  const uint8_t *data;
  size_t length;
};
struct lbov_d18d8be33f0e7cbe61f9_t11140334dba7a15b6b99 {
  const uint32_t *data;
  size_t length;
  uint8_t negative;
};
struct lbov_d18d8be33f0e7cbe61f9_t167081552b6f9c1d1afd {
  const uint32_t *data;
  size_t length;
};
struct lbov_d18d8be33f0e7cbe61f9_tdc0347e1f7f5c4d928f1 {
  const char *data;
  size_t length;
};
struct lbov_d18d8be33f0e7cbe61f9_t82551d965c182180b0dd {
  const lbov_d18d8be33f0e7cbe61f9_t6de8e950bc342c30091c *data;
  size_t length;
};
struct lbov_d18d8be33f0e7cbe61f9_t659ec6a690764999d00d {
  const lbov_d18d8be33f0e7cbe61f9_t6de8e950bc342c30091c *data;
  size_t length;
};
struct lbov_d18d8be33f0e7cbe61f9_t817592654f48ba756bd4 {
  uint8_t tag;
  lbov_d18d8be33f0e7cbe61f9_t6de8e950bc342c30091c f0;
};
struct lbov_d18d8be33f0e7cbe61f9_t5faad500583201774348 {
  lbov_d18d8be33f0e7cbe61f9_t6de8e950bc342c30091c f0;
  const lbov_d18d8be33f0e7cbe61f9_t817592654f48ba756bd4 *f1;
  const lbov_d18d8be33f0e7cbe61f9_t659ec6a690764999d00d *f2;
  const lbov_d18d8be33f0e7cbe61f9_t82551d965c182180b0dd *f3;
  const lbov_d18d8be33f0e7cbe61f9_t550e0acb733e8dd08e4e *f4;
};
struct lbov_d18d8be33f0e7cbe61f9_t550e0acb733e8dd08e4e {
  lbov_d18d8be33f0e7cbe61f9_t11140334dba7a15b6b99 f0;
  lbov_d18d8be33f0e7cbe61f9_tf098e5912ebfda269f53 f1;
};
