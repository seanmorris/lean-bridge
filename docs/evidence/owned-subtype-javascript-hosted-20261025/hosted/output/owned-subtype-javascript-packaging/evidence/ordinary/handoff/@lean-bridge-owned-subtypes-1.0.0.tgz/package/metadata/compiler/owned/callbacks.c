#include "component.h"
#include "lean_bridge_native_runtime.h"
static _Thread_local int lean_bridge_owned_callback_failure_d18d8be33f0e7cbe61f9_state;
int lean_bridge_owned_callback_failure_d18d8be33f0e7cbe61f9(void) { int result = lean_bridge_owned_callback_failure_d18d8be33f0e7cbe61f9_state; lean_bridge_owned_callback_failure_d18d8be33f0e7cbe61f9_state = 0; return result; }
