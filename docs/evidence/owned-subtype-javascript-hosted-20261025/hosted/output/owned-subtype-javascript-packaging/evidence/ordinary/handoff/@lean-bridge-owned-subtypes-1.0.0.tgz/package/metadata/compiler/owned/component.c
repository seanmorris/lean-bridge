#include <lean/lean.h>
#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#ifndef LB_JS_ALLOC_FAIL
#define LB_JS_ALLOC_FAIL() 0
#endif
typedef struct {
  size_t bytes;
  max_align_t alignment;
  unsigned char data[];
} lbjs_component_d18d8be33f0e7cbe61f9_allocation;
static size_t lbjs_component_d18d8be33f0e7cbe61f9_live_allocations;
static void *lbjs_component_d18d8be33f0e7cbe61f9_allocate(size_t bytes) {
  if (bytes > SIZE_MAX - sizeof(lbjs_component_d18d8be33f0e7cbe61f9_allocation) || LB_JS_ALLOC_FAIL()) return NULL;
  lbjs_component_d18d8be33f0e7cbe61f9_allocation *allocation = calloc(1, sizeof(*allocation) + bytes);
  if (!allocation) return NULL;
  allocation->bytes = bytes; ++lbjs_component_d18d8be33f0e7cbe61f9_live_allocations; return allocation->data;
}
static lbjs_component_d18d8be33f0e7cbe61f9_allocation *lbjs_component_d18d8be33f0e7cbe61f9_allocation_of(const void *value) {
  return (lbjs_component_d18d8be33f0e7cbe61f9_allocation *)((unsigned char *)value - offsetof(lbjs_component_d18d8be33f0e7cbe61f9_allocation, data));
}
static void lbjs_component_d18d8be33f0e7cbe61f9_free(void *value) {
  if (!value) return;
  --lbjs_component_d18d8be33f0e7cbe61f9_live_allocations; free(lbjs_component_d18d8be33f0e7cbe61f9_allocation_of(value));
}
#define LB_OWNED_ALLOC lbjs_component_d18d8be33f0e7cbe61f9_allocate
#define LB_OWNED_FREE lbjs_component_d18d8be33f0e7cbe61f9_free
#include "owned-values-codec.h"
#include "owned-js-layout.h"
extern lean_object *initialize_LeanBridgeOwned6898bc2d25f73481(uint8_t);
static lb_owned_context lbjs_component_d18d8be33f0e7cbe61f9_context;
typedef struct { ov_result_owner value; unsigned key; unsigned published, consumed, moving; } lbjs_component_d18d8be33f0e7cbe61f9_owner;
static lbjs_component_d18d8be33f0e7cbe61f9_owner lbjs_component_d18d8be33f0e7cbe61f9_owners[4096];
static unsigned lbjs_component_d18d8be33f0e7cbe61f9_next_owner, lbjs_component_d18d8be33f0e7cbe61f9_closed;

typedef struct { const uint32_t *owners; uint32_t count; } lbjs_component_d18d8be33f0e7cbe61f9_input_group;
typedef struct {
  uint32_t version, count;
  const lbjs_component_d18d8be33f0e7cbe61f9_input_group *groups;
  uint32_t consumed;
} lbjs_component_d18d8be33f0e7cbe61f9_input_frame;
_Static_assert(sizeof(lbjs_component_d18d8be33f0e7cbe61f9_input_frame) == 16 && offsetof(lbjs_component_d18d8be33f0e7cbe61f9_input_frame, consumed) == 12, "owned JS transfer frame");
_Static_assert(sizeof(lbjs_component_d18d8be33f0e7cbe61f9_input_group) == 8, "owned JS transfer group");
typedef struct lbjs_component_d18d8be33f0e7cbe61f9_reservation {
  struct lbjs_component_d18d8be33f0e7cbe61f9_reservation *next;
  lbjs_component_d18d8be33f0e7cbe61f9_owner *slot;
} lbjs_component_d18d8be33f0e7cbe61f9_reservation;
typedef struct {
  lbjs_component_d18d8be33f0e7cbe61f9_input_frame *frame;
  lbjs_component_d18d8be33f0e7cbe61f9_reservation *reserved;
  ov_result_owner *snapshots;
  ov_result_owner **owners;
  size_t count;
} lbjs_component_d18d8be33f0e7cbe61f9_moves;
static lbjs_component_d18d8be33f0e7cbe61f9_owner *lbjs_component_d18d8be33f0e7cbe61f9_slot(unsigned key) {
  if (!key) return NULL;
  for (size_t i = 0; i < 4096; ++i)
    if (lbjs_component_d18d8be33f0e7cbe61f9_owners[i].key == key) return &lbjs_component_d18d8be33f0e7cbe61f9_owners[i];
  return NULL;
}
static int lbjs_component_d18d8be33f0e7cbe61f9_moves_finish(lbjs_component_d18d8be33f0e7cbe61f9_moves *moves, int status) {
  if (moves->snapshots) for (size_t i = 0; i < moves->count; ++i) {
    int cleanup = ov_owner_clear(&moves->snapshots[i]); if (!status) status = cleanup;
  }
  while (moves->reserved) {
    lbjs_component_d18d8be33f0e7cbe61f9_reservation *entry = moves->reserved; moves->reserved = entry->next;
    entry->slot->moving = 0; LB_OWNED_FREE(entry);
  }
  LB_OWNED_FREE(moves->snapshots); LB_OWNED_FREE(moves->owners);
  *moves = (lbjs_component_d18d8be33f0e7cbe61f9_moves){0}; return status;
}
static int lbjs_component_d18d8be33f0e7cbe61f9_moves_prepare(lbjs_component_d18d8be33f0e7cbe61f9_moves *moves, lbjs_component_d18d8be33f0e7cbe61f9_input_frame *frame,
    size_t count, unsigned output) {
  if (!ov_pointer(frame, sizeof(*frame), _Alignof(lbjs_component_d18d8be33f0e7cbe61f9_input_frame)) ||
      frame->version != 1 || frame->count != count || frame->consumed ||
      !count || count > LB_OWNED_RETAINED_LIMIT ||
      !ov_pointer(frame->groups, count * sizeof(*frame->groups), _Alignof(lbjs_component_d18d8be33f0e7cbe61f9_input_group)))
    return LB_OWNED_INVALID;
  moves->frame = frame; moves->count = count;
  moves->snapshots = LB_OWNED_ALLOC(count * sizeof(*moves->snapshots));
  moves->owners = LB_OWNED_ALLOC(count * sizeof(*moves->owners));
  if (!moves->snapshots || !moves->owners) return LB_OWNED_ALLOC_FAILED;
  memset(moves->snapshots, 0, count * sizeof(*moves->snapshots));
  size_t reserved = 0, retained = 0;
  for (size_t i = 0; i < count; ++i) {
    const lbjs_component_d18d8be33f0e7cbe61f9_input_group *group = &frame->groups[i];
    if (group->count > LB_OWNED_RETAINED_LIMIT - reserved ||
        (group->count && !ov_pointer(group->owners, group->count * sizeof(*group->owners), _Alignof(uint32_t))))
      return LB_OWNED_INVALID;
    reserved += group->count; moves->owners[i] = &moves->snapshots[i];
    ov_transaction snapshot = {0};
    int status = ov_begin(&snapshot, &lbjs_component_d18d8be33f0e7cbe61f9_context, moves->owners[i], "owned-subtypes@1.0.0");
    if (status) return status;
    for (size_t j = 0; j < group->count && !status; ++j) {
      lbjs_component_d18d8be33f0e7cbe61f9_owner *slot = lbjs_component_d18d8be33f0e7cbe61f9_slot(group->owners[j]);
      if (!slot || slot->key == output || !slot->published || slot->consumed || slot->moving) {
        status = LB_OWNED_INVALID; break;
      }
      lbjs_component_d18d8be33f0e7cbe61f9_reservation *entry = LB_OWNED_ALLOC(sizeof(*entry));
      if (!entry) { status = LB_OWNED_ALLOC_FAILED; break; }
      entry->slot = slot; entry->next = moves->reserved; moves->reserved = entry; slot->moving = 1;
      for (lb_owned_entry *item = slot->value.batch.entries; item && !status; item = item->next) {
        if (retained++ == LB_OWNED_RETAINED_LIMIT) { status = LB_OWNED_LIMIT; break; }
        uint64_t token = 0;
        status = lb_owned_scope_acquire(&snapshot.scope, item->owner->kind, item->owner->value, &token);
        if (!status && token != item->owner->token) status = LB_OWNED_INVALID;
      }
    }
    if (status) return ov_abort(&snapshot, status);
    status = ov_commit(&snapshot, moves->owners[i]);
    if (status) return status;
  }
  return LB_OWNED_OK;
}
static void lbjs_component_d18d8be33f0e7cbe61f9_moves_consume(void *context) {
  lbjs_component_d18d8be33f0e7cbe61f9_moves *moves = context;
  for (lbjs_component_d18d8be33f0e7cbe61f9_reservation *entry = moves->reserved; entry; entry = entry->next)
    entry->slot->consumed = 1;
  moves->frame->consumed = 1;
}
static ov_result_owner *lbjs_component_d18d8be33f0e7cbe61f9_find(unsigned key) {
  if (!key) return NULL;
  for (size_t i = 0; i < 4096; ++i)
    if (lbjs_component_d18d8be33f0e7cbe61f9_owners[i].key == key) return &lbjs_component_d18d8be33f0e7cbe61f9_owners[i].value;
  return NULL;
}
unsigned lbjs_component_d18d8be33f0e7cbe61f9_open(void) {
  if (lb_owned_ready(&lbjs_component_d18d8be33f0e7cbe61f9_context) || lbjs_component_d18d8be33f0e7cbe61f9_next_owner == UINT32_MAX) return 0;
  for (size_t i = 0; i < 4096; ++i) if (!lbjs_component_d18d8be33f0e7cbe61f9_owners[i].key) {
    lbjs_component_d18d8be33f0e7cbe61f9_owners[i].key = ++lbjs_component_d18d8be33f0e7cbe61f9_next_owner; return lbjs_component_d18d8be33f0e7cbe61f9_next_owner;
  }
  return 0;
}
int lbjs_component_d18d8be33f0e7cbe61f9_valid(unsigned key) { return lbjs_component_d18d8be33f0e7cbe61f9_find(key) != NULL; }
int lbjs_component_d18d8be33f0e7cbe61f9_release(unsigned key) {
  ov_result_owner *owner = lbjs_component_d18d8be33f0e7cbe61f9_find(key); if (!owner) return LB_OWNED_INVALID;
  if (lbjs_component_d18d8be33f0e7cbe61f9_slot(key)->moving) return LB_OWNED_ORDER;
  int status = ov_owner_clear(owner);
  if (!status) for (size_t i = 0; i < 4096; ++i)
    if (lbjs_component_d18d8be33f0e7cbe61f9_owners[i].key == key) { lbjs_component_d18d8be33f0e7cbe61f9_owners[i] = (lbjs_component_d18d8be33f0e7cbe61f9_owner){0}; break; }
  return status;
}
#include <emscripten.h>
typedef struct { unsigned host, type; uint64_t token; } lbjs_d18d8be33f0e7cbe61f9_host;
static lbjs_d18d8be33f0e7cbe61f9_host lbjs_d18d8be33f0e7cbe61f9_hosts[4096];
typedef struct lbjs_d18d8be33f0e7cbe61f9_frame { struct lbjs_d18d8be33f0e7cbe61f9_frame *parent; unsigned key, host, type, owner; const uintptr_t *args; void *reply; } lbjs_d18d8be33f0e7cbe61f9_frame;
static lbjs_d18d8be33f0e7cbe61f9_frame *lbjs_d18d8be33f0e7cbe61f9_active; static unsigned lbjs_d18d8be33f0e7cbe61f9_next;
EM_JS(int, lbjs_d18d8be33f0e7cbe61f9_dispatch_js, (unsigned key, unsigned host, unsigned type, unsigned owner, const uintptr_t *args, void *reply), {
  return Module["leanBridgeOwnedCallbacks_d18d8be33f0e7cbe61f995dccac6512ab176fd961fc1a9c00c23c39d0cc63882"].dispatch(key, host, type, owner, args, reply);
});
EM_JS(int, lbjs_d18d8be33f0e7cbe61f9_finish_js, (unsigned key), { return Module["leanBridgeOwnedCallbacks_d18d8be33f0e7cbe61f995dccac6512ab176fd961fc1a9c00c23c39d0cc63882"].finish(key); });
int lbjs_d18d8be33f0e7cbe61f9_valid(unsigned key, unsigned host, unsigned type, unsigned owner, const uintptr_t *args, void *reply) {
  lbjs_d18d8be33f0e7cbe61f9_frame *frame = lbjs_d18d8be33f0e7cbe61f9_active;
  return frame && frame->key == key && frame->host == host && frame->type == type
    && frame->owner == owner && frame->args == args && frame->reply == reply;
}
int lbjs_d18d8be33f0e7cbe61f9_end(unsigned host) {
  for (size_t i = 0; i < 4096; ++i) if (lbjs_d18d8be33f0e7cbe61f9_hosts[i].host == host && host) {
    lb_native_callback_release(lbjs_d18d8be33f0e7cbe61f9_hosts[i].token); lbjs_d18d8be33f0e7cbe61f9_hosts[i] = (lbjs_d18d8be33f0e7cbe61f9_host){0}; return 0;
  }
  return LB_OWNED_INVALID;
}
unsigned lbjs_d18d8be33f0e7cbe61f9_live(void) { unsigned count = 0; for (unsigned i = 0; i < 4096; ++i) if (lbjs_d18d8be33f0e7cbe61f9_hosts[i].host) ++count; return count; }
int lbjs_d18d8be33f0e7cbe61f9_begin(unsigned type, unsigned id, const void *fallback, void *out, unsigned owner_key) {
  ov_result_owner *owner = lbjs_component_d18d8be33f0e7cbe61f9_find(owner_key); if (!owner || !id) return LB_OWNED_INVALID;
  lbjs_d18d8be33f0e7cbe61f9_host *host = NULL;
  for (size_t i = 0; i < 4096; ++i) { if (lbjs_d18d8be33f0e7cbe61f9_hosts[i].host == id) return LB_OWNED_INVALID; if (!host && !lbjs_d18d8be33f0e7cbe61f9_hosts[i].host) host = &lbjs_d18d8be33f0e7cbe61f9_hosts[i]; }
  if (!host) return LB_OWNED_LIMIT;
  *host = (lbjs_d18d8be33f0e7cbe61f9_host){ .host = id, .type = type };
  int status; switch (type) {
  default: status = LB_OWNED_INVALID;
  }
  if (status) *host = (lbjs_d18d8be33f0e7cbe61f9_host){0};
  return status;
}

int lbjs_component_d18d8be33f0e7cbe61f9_init(void) {
  if (lbjs_component_d18d8be33f0e7cbe61f9_closed) return LB_OWNED_CLOSED;
  if (lbjs_component_d18d8be33f0e7cbe61f9_context.initialized) return lb_owned_ready(&lbjs_component_d18d8be33f0e7cbe61f9_context);
  if (!lean_bridge_native_component_initialize("owned-subtypes@1.0.0",
      (lean_bridge_native_initializer)initialize_LeanBridgeOwned6898bc2d25f73481)) return LB_OWNED_RUNTIME;
  return lb_owned_context_init(&lbjs_component_d18d8be33f0e7cbe61f9_context, "owned-subtypes@1.0.0");
}
int lbjs_component_d18d8be33f0e7cbe61f9_dispatch(unsigned index, const uintptr_t *args, void *out, unsigned key, lbjs_component_d18d8be33f0e7cbe61f9_input_frame *inputs) {
  ov_result_owner *owner = lbjs_component_d18d8be33f0e7cbe61f9_find(key); if (!owner) return LB_OWNED_INVALID;
  if (lbjs_component_d18d8be33f0e7cbe61f9_slot(key)->published || lbjs_component_d18d8be33f0e7cbe61f9_slot(key)->consumed || lbjs_component_d18d8be33f0e7cbe61f9_slot(key)->moving) return LB_OWNED_INVALID;
  switch (index) {
  case 0: {
    if (!ov_pointer(out, sizeof(lbov_d18d8be33f0e7cbe61f9_t5faad500583201774348), _Alignof(lbov_d18d8be33f0e7cbe61f9_t5faad500583201774348)) || !ov_pointer(args, 1 * sizeof(*args), _Alignof(uintptr_t)) || inputs != NULL) return LB_OWNED_INVALID;
    int status = lbov_d18d8be33f0e7cbe61f9_f080cb47999bb83cdc0c1(&lbjs_component_d18d8be33f0e7cbe61f9_context, (const lbov_d18d8be33f0e7cbe61f9_t5faad500583201774348 *)args[0], (lbov_d18d8be33f0e7cbe61f9_t5faad500583201774348 *)out, owner);
    if (!status) lbjs_component_d18d8be33f0e7cbe61f9_slot(key)->published = 1;
    return status;
  }
  case 1: {
    if (!ov_pointer(out, sizeof(lbov_d18d8be33f0e7cbe61f9_t5faad500583201774348), _Alignof(lbov_d18d8be33f0e7cbe61f9_t5faad500583201774348)) || !ov_pointer(args, 1 * sizeof(*args), _Alignof(uintptr_t)) || inputs != NULL) return LB_OWNED_INVALID;
    int status = lbov_d18d8be33f0e7cbe61f9_f579c430cd49e7c98161f(&lbjs_component_d18d8be33f0e7cbe61f9_context, (const lbov_d18d8be33f0e7cbe61f9_t5faad500583201774348 *)args[0], (lbov_d18d8be33f0e7cbe61f9_t5faad500583201774348 *)out, owner);
    if (!status) lbjs_component_d18d8be33f0e7cbe61f9_slot(key)->published = 1;
    return status;
  }
  case 2: {
    if (!ov_pointer(out, sizeof(lbov_d18d8be33f0e7cbe61f9_t6de8e950bc342c30091c), _Alignof(lbov_d18d8be33f0e7cbe61f9_t6de8e950bc342c30091c)) || !ov_pointer(args, 2 * sizeof(*args), _Alignof(uintptr_t)) || inputs != NULL) return LB_OWNED_INVALID;
    int status = lbov_d18d8be33f0e7cbe61f9_f9735b5a0a586b46ce0b8(&lbjs_component_d18d8be33f0e7cbe61f9_context, (const lbov_d18d8be33f0e7cbe61f9_t167081552b6f9c1d1afd *)args[0], (const lbov_d18d8be33f0e7cbe61f9_tdc0347e1f7f5c4d928f1 *)args[1], (lbov_d18d8be33f0e7cbe61f9_t6de8e950bc342c30091c *)out, owner);
    if (!status) lbjs_component_d18d8be33f0e7cbe61f9_slot(key)->published = 1;
    return status;
  }
  case 3: {
    if (!ov_pointer(out, sizeof(lbov_d18d8be33f0e7cbe61f9_t167081552b6f9c1d1afd), _Alignof(lbov_d18d8be33f0e7cbe61f9_t167081552b6f9c1d1afd)) || !ov_pointer(args, 1 * sizeof(*args), _Alignof(uintptr_t)) || inputs != NULL) return LB_OWNED_INVALID;
    int status = lbov_d18d8be33f0e7cbe61f9_f52957d819a8a28259bf1(&lbjs_component_d18d8be33f0e7cbe61f9_context, (const lbov_d18d8be33f0e7cbe61f9_t6de8e950bc342c30091c *)args[0], (lbov_d18d8be33f0e7cbe61f9_t167081552b6f9c1d1afd *)out, owner);
    if (!status) lbjs_component_d18d8be33f0e7cbe61f9_slot(key)->published = 1;
    return status;
  }
  case 4: {
    if (!ov_pointer(out, sizeof(lbov_d18d8be33f0e7cbe61f9_t5faad500583201774348), _Alignof(lbov_d18d8be33f0e7cbe61f9_t5faad500583201774348)) || !ov_pointer(args, 1 * sizeof(*args), _Alignof(uintptr_t))) return LB_OWNED_INVALID;
    lbjs_component_d18d8be33f0e7cbe61f9_moves moves = {0};
    int status = lbjs_component_d18d8be33f0e7cbe61f9_moves_prepare(&moves, inputs, 1, key);
    ov_input_transfers transfer = { .owners = moves.owners, .count = 1, .consume = lbjs_component_d18d8be33f0e7cbe61f9_moves_consume, .context = &moves };
    if (!status) status = lbov_d18d8be33f0e7cbe61f9_f973a6e63b7dad7a3d147(&lbjs_component_d18d8be33f0e7cbe61f9_context, (const lbov_d18d8be33f0e7cbe61f9_t5faad500583201774348 *)args[0], &transfer, (lbov_d18d8be33f0e7cbe61f9_t5faad500583201774348 *)out, owner);
    status = lbjs_component_d18d8be33f0e7cbe61f9_moves_finish(&moves, status);
    if (!status) lbjs_component_d18d8be33f0e7cbe61f9_slot(key)->published = 1;
    return status;
  }
  default: return LB_OWNED_INVALID;
  }
}
int lbjs_component_d18d8be33f0e7cbe61f9_claim(unsigned key, const void *pointer, size_t bytes) {
  ov_result_owner *owner = lbjs_component_d18d8be33f0e7cbe61f9_find(key); if (!owner) return 0;
  for (ov_allocation *allocation = owner->allocations; allocation; allocation = allocation->next) {
    if (allocation->data != pointer) continue;
    size_t actual = lbjs_component_d18d8be33f0e7cbe61f9_allocation_of(allocation)->bytes;
    return actual >= sizeof(*allocation) && actual - sizeof(*allocation) == bytes;
  }
  return 0;
}
int lbjs_component_d18d8be33f0e7cbe61f9_identity(unsigned key, unsigned type, uint64_t token) {
  ov_result_owner *owner = lbjs_component_d18d8be33f0e7cbe61f9_find(key); if (!owner) return 0;
  const char *kind;
  switch (type) {
  case 5: kind = "resource:Owned.Ticket"; break;
  default: return 0;
  }
  for (lb_owned_entry *entry = owner->batch.entries; entry; entry = entry->next)
    if (entry->owner->token == token && !strcmp(entry->owner->kind, kind)) return 1;
  return 0;
}
int lbjs_component_d18d8be33f0e7cbe61f9_retain(unsigned type, uint64_t token, void *out, unsigned key) {
  ov_result_owner *owner = lbjs_component_d18d8be33f0e7cbe61f9_find(key); if (!owner) return LB_OWNED_INVALID;
  if (lbjs_component_d18d8be33f0e7cbe61f9_slot(key)->published || lbjs_component_d18d8be33f0e7cbe61f9_slot(key)->consumed || lbjs_component_d18d8be33f0e7cbe61f9_slot(key)->moving) return LB_OWNED_INVALID;
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, &lbjs_component_d18d8be33f0e7cbe61f9_context, owner, "owned-subtypes@1.0.0");
  if (status) return status;
  lean_object *value = NULL;
  switch (type) {
  case 5: {
    lbov_d18d8be33f0e7cbe61f9_t6de8e950bc342c30091c input = { .token = token };
    if (!ov_pointer(out, sizeof(input), _Alignof(lbov_d18d8be33f0e7cbe61f9_t6de8e950bc342c30091c))) { status = LB_OWNED_INVALID; break; }
    status = lbov_d18d8be33f0e7cbe61f9_v6de8e950bc342c30091c_in(&input, 0, 1, &transaction, &value);
    if (!status) status = lbov_d18d8be33f0e7cbe61f9_v6de8e950bc342c30091c_out(out, value, 0, &transaction);
    break;
  }
  default: status = LB_OWNED_INVALID;
  }
  status = status ? ov_abort(&transaction, status) : ov_commit(&transaction, owner);
  if (!status) lbjs_component_d18d8be33f0e7cbe61f9_slot(key)->published = 1;
  return status;
}
int lbjs_component_d18d8be33f0e7cbe61f9_close(void) {
  if (lbjs_component_d18d8be33f0e7cbe61f9_closed) return LB_OWNED_OK;
  int status = lb_owned_affinity(&lbjs_component_d18d8be33f0e7cbe61f9_context);
  if (status) return status;
  if (lbjs_component_d18d8be33f0e7cbe61f9_context.top || lbjs_d18d8be33f0e7cbe61f9_live()) return LB_OWNED_ORDER;
  for (size_t i = 0; i < 4096; ++i) if (lbjs_component_d18d8be33f0e7cbe61f9_owners[i].key) {
    status = lbjs_component_d18d8be33f0e7cbe61f9_release(lbjs_component_d18d8be33f0e7cbe61f9_owners[i].key); if (status) return status;
  }
  status = lb_owned_context_close(&lbjs_component_d18d8be33f0e7cbe61f9_context);
  if (!status) { lbjs_component_d18d8be33f0e7cbe61f9_closed = 1; lean_bridge_native_component_detach("owned-subtypes@1.0.0"); }
  return status;
}
unsigned lbjs_component_d18d8be33f0e7cbe61f9_live(void) { return lbjs_component_d18d8be33f0e7cbe61f9_live_allocations; }
unsigned lbjs_component_d18d8be33f0e7cbe61f9_results(void) {
  unsigned count = 0;
  for (size_t i = 0; i < 4096; ++i) if (lbjs_component_d18d8be33f0e7cbe61f9_owners[i].key) ++count;
  return count;
}
typedef struct {
  uint32_t version, bytes, status, operation;
  uint32_t arguments[8];
  uint64_t token;
  uint32_t value, reserved;
} lbjs_component_d18d8be33f0e7cbe61f9_control_frame;
_Static_assert(sizeof(lbjs_component_d18d8be33f0e7cbe61f9_control_frame) == 64, "owned JS control size");
_Static_assert(_Alignof(lbjs_component_d18d8be33f0e7cbe61f9_control_frame) == 8, "owned JS control alignment");
_Static_assert(offsetof(lbjs_component_d18d8be33f0e7cbe61f9_control_frame, status) == 8, "owned JS trampoline status");
_Static_assert(offsetof(lbjs_component_d18d8be33f0e7cbe61f9_control_frame, token) == 48, "owned JS control token");
_Static_assert(offsetof(lbjs_component_d18d8be33f0e7cbe61f9_control_frame, value) == 56, "owned JS control result");
static const uint32_t lbjs_component_d18d8be33f0e7cbe61f9_metadata[8] = {
  UINT32_C(0x420ff75c), UINT32_C(0x36bcca40), UINT32_C(0xf5a4ae01), UINT32_C(0x275ad79a), UINT32_C(0xe1a9b4be), UINT32_C(0xba917e2f), UINT32_C(0x8018c42e), UINT32_C(0xb441e41f)
};
unsigned lbjs_component_d18d8be33f0e7cbe61f9_control(lbjs_component_d18d8be33f0e7cbe61f9_control_frame *frame) {
  if (!ov_pointer(frame, sizeof(*frame), _Alignof(lbjs_component_d18d8be33f0e7cbe61f9_control_frame))) return LB_OWNED_INVALID;
  if (frame->version != 1 || frame->bytes != sizeof(*frame) || frame->status
      || frame->value || frame->reserved) return frame->status = LB_OWNED_INVALID;
  const uint32_t *a = frame->arguments; int status = 0;
  switch (frame->operation) {
  case 0: status = lbjs_component_d18d8be33f0e7cbe61f9_init(); break;
  case 1: frame->value = lbjs_component_d18d8be33f0e7cbe61f9_open(); break;
  case 2: frame->value = lbjs_component_d18d8be33f0e7cbe61f9_valid(a[0]); break;
  case 3: status = lbjs_component_d18d8be33f0e7cbe61f9_release(a[0]); break;
  case 4: frame->value = lbjs_component_d18d8be33f0e7cbe61f9_claim(a[0], (const void *)a[1], a[2]); break;
  case 5: frame->value = lbjs_component_d18d8be33f0e7cbe61f9_identity(a[0], a[1], frame->token); break;
  case 6: status = lbjs_component_d18d8be33f0e7cbe61f9_dispatch(a[0], (const uintptr_t *)a[1], (void *)a[2], a[3], (lbjs_component_d18d8be33f0e7cbe61f9_input_frame *)a[4]); break;
  case 7: status = lbjs_component_d18d8be33f0e7cbe61f9_retain(a[0], frame->token, (void *)a[1], a[2]); break;
  case 8: status = lbjs_component_d18d8be33f0e7cbe61f9_close(); break;
  case 9: frame->value = lbjs_component_d18d8be33f0e7cbe61f9_live(); break;
  case 10: frame->value = lbjs_component_d18d8be33f0e7cbe61f9_results(); break;
  case 15:
    if (a[0] >= 8) status = LB_OWNED_INVALID;
    else frame->value = lbjs_component_d18d8be33f0e7cbe61f9_metadata[a[0]];
    break;
  case 11: status = lbjs_d18d8be33f0e7cbe61f9_begin(a[0], a[1], (const void *)a[2], (void *)a[3], a[4]); break;
  case 12: status = lbjs_d18d8be33f0e7cbe61f9_end(a[0]); break;
  case 13: frame->value = lbjs_d18d8be33f0e7cbe61f9_valid(a[0], a[1], a[2], a[3], (const uintptr_t *)a[4], (void *)a[5]); break;
  case 14: frame->value = lbjs_d18d8be33f0e7cbe61f9_live(); break;
  default: status = LB_OWNED_INVALID;
  }
  return frame->status = (uint32_t)status;
}
