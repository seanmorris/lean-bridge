#include "component.h"
#include "lean_bridge_native_runtime.h"
static _Thread_local int lean_bridge_owned_callback_failure_0c877101f9a861bd3f3f_state;
int lean_bridge_owned_callback_failure_0c877101f9a861bd3f3f(void) { int result = lean_bridge_owned_callback_failure_0c877101f9a861bd3f3f_state; lean_bridge_owned_callback_failure_0c877101f9a861bd3f3f_state = 0; return result; }
