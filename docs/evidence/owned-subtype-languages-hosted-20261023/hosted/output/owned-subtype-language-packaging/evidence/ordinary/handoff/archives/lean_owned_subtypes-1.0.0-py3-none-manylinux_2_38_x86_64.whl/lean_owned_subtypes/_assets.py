import ctypes as _c
import _ctypes
import hashlib as _hashlib
import json as _json
import os as _os
import pathlib as _pathlib
import platform as _platform
import stat as _stat
import sys as _sys
import threading as _threading
import types as _types

_evidence = _json.loads("{\n  \"componentId\": \"owned-subtypes@1.0.0\",\n  \"componentReceiptSha256\": \"7e80bd1a2208fd712552b04deb50f53fa62a93dd7fe9ac097fa3c91eec2358c9\",\n  \"libraries\": {\n    \"libcomponent_df500c005a7a829ba06c.so\": \"38f6cb8f55c11673fe0032d878015ff55736c1fee06c0d4a9de8bcf9bbeb2799\",\n    \"libgmp.so.10\": \"1980c7331f830ab5291a3ec606e03fdc4d00ce7b8a93da6c64da10806ea36cd7\",\n    \"liblean_bridge_native.so\": \"459fcd2098d4b646ab6ae0f4cdccd1f222908cb162562bfc3940a533cd4e4e21\",\n    \"libleanshared.so\": \"d7768b88d8162736da4305777cd6f147676038fd885bd8a265c958b0ecea00b4\",\n    \"libowned_subtypes.so\": \"b0f0671dad46f143128dc090e951d31cfe3166bd82d3cd687d8e736bf46c9d6c\"\n  },\n  \"library\": \"libowned_subtypes.so\",\n  \"ownedValues\": {\n    \"abiHeaderSha256\": \"3ab03afd8eb63c1af50c9b6348a2ae3c62c2d50940ee82166335fc2de87344b8\",\n    \"callbackFailure\": \"raise-after-native-return\",\n    \"callbackLifetime\": \"call\",\n    \"conversionsSha256\": \"346b6c90413add13db2b9fd310f099d8dfa4295a3297ad2efa543ed78ba0b18c\",\n    \"exactIntegers\": \"python-int\",\n    \"explicitRetention\": \"retain\",\n    \"inputTransfers\": {\n      \"aliases\": \"shared-lease\",\n      \"arguments\": \"ordinary-values\",\n      \"borrowedInputs\": \"reject\",\n      \"consumption\": \"before-lean-call\",\n      \"failure\": \"consumed-after-handoff\",\n      \"independentRetains\": \"preserved\",\n      \"schemaVersion\": 1,\n      \"validation\": \"before-consumption\"\n    },\n    \"language\": \"python-3.11\",\n    \"limits\": {\n      \"bytes\": 16777216,\n      \"depth\": 128,\n      \"retained\": 4096,\n      \"visits\": 262144\n    },\n    \"loader\": \"authenticated-bundled-native\",\n    \"loaderSha256\": \"db5e100249b15b5016167eb7cb89da2be64393f0f2d45f7b5ffdd3323569ca60\",\n    \"ownership\": \"checked-result-leases\",\n    \"publicSha256\": \"6966baf913a78077858f99d0cbf657e53c951ce22f48ee3717d9432a8db08a78\",\n    \"runtimeSha256\": \"5eaba4e338392f84a3f91f02e4db5fbe34797c75fb4ac8c568f21f33aa5fd1f1\",\n    \"schemaVersion\": 2,\n    \"stubSha256\": \"5bc0a31385ffd19d0ea1a76dbadc1dbf4b96486d31b7f1c30ead7888d38de0c2\"\n  },\n  \"runtimeIdentity\": \"4b5a7fdf0cb11d4bb429181cfd50b330c5622ed8f5f5382a293955a439b595b5\"\n}\n")
if _evidence is None:
    raise ImportError("Build a compiled PyPI release before importing this API")
if (_sys.version_info < (3, 11) or _sys.platform != "linux"
        or _platform.machine() not in ("x86_64", "AMD64")
        or _c.sizeof(_c.c_void_p) != 8 or _sys.byteorder != "little"):
    raise ImportError("This Lean package requires Python 3.11+ on Linux x86-64")
if hasattr(_sys, "_is_gil_enabled") and not _sys._is_gil_enabled():
    raise ImportError("This Lean package requires a GIL-enabled interpreter")

_PID = _os.getpid()
_root = _pathlib.Path(__file__).resolve().parent / "native" / "linux-x64"
for _directory in (_root.parent, _root):
    if not _stat.S_ISDIR(_directory.lstat().st_mode):
        raise ImportError("Native library directory is not a regular directory")
_libraries = _evidence["libraries"]
for _name, _expected in _libraries.items():
    _path = _root / _name
    if not _stat.S_ISREG(_path.lstat().st_mode):
        raise ImportError("Native library is not a regular file: " + _name)
    with _path.open("rb") as _stream:
        _actual = _hashlib.file_digest(_stream, "sha256").hexdigest()
    if _actual != _expected:
        raise ImportError("Native library differs from compiled evidence: " + _name)

# Reuse the interpreter registry used by copied-value Python packages.
# No shared on-disk module: removing one wheel cannot remove another's loader.
_candidate = _types.ModuleType("_lean_bridge_copied_runtime_v1")
_candidate.lock = _threading.RLock()
_candidate.pid = _PID
_candidate.identity = None
_candidate.failed = False
_candidate.components = {}
_candidate.libraries = {}
_candidate.handles = []
_state = _sys.modules.setdefault(_candidate.__name__, _candidate)
if _state.pid != _PID:
    raise ImportError("Start a fresh Python interpreter after fork to use Lean packages")

def _reject_unverified_loaded(name):
    for candidate in (name, str(_root / name)):
        try:
            probe = _c.CDLL(candidate, mode=_os.RTLD_NOW | _os.RTLD_NOLOAD)
        except OSError:
            continue
        _ctypes.dlclose(probe._handle)
        raise ImportError("Unverified native library is already loaded: " + name)

with _state.lock:
    if _state.failed:
        raise ImportError("Lean native loading failed earlier in this interpreter")
    if _state.identity not in (None, _evidence["runtimeIdentity"]):
        raise ImportError("Incompatible Lean runtime identities")
    for _name, _expected in _libraries.items():
        if _state.libraries.get(_name, _expected) != _expected:
            raise ImportError("Conflicting builds of the same native library: " + _name)
    _previous = _state.components.get(_evidence["componentId"])
    _identity = "8452dba5964b464ecebee97926207c29d1fdeb05ebbf10236b937c4967decf31"
    if _previous is not None and _previous[0] != _identity:
        raise ImportError("Conflicting builds of the same Lean component")
    try:
        if _previous is None:
            # Check every unknown SONAME before loading any new library.
            for _name in _libraries:
                if _name not in _state.libraries:
                    _reject_unverified_loaded(_name)
            _order = ["libleanshared.so", "liblean_bridge_native.so"]
            _order += [name for name in _libraries
                       if name not in (*_order, _evidence["library"])]
            _order.append(_evidence["library"])
            for _name in _order:
                if _name not in _state.libraries:
                    _loaded = _c.CDLL(str(_root / _name), mode=_os.RTLD_NOW | _os.RTLD_GLOBAL)
                    _state.handles.append(_loaded)
                    _state.libraries[_name] = _libraries[_name]
                else:
                    _loaded = next(item for item in _state.handles
                                   if _pathlib.Path(item._name).name == _name)
            _previous = (_identity, _loaded)
            _state.components[_evidence["componentId"]] = _previous
            _state.identity = _evidence["runtimeIdentity"]
        _LIBRARY = _previous[1]
    except BaseException:
        _state.failed = True
        raise

def _ensure_process():
    if _os.getpid() != _PID:
        raise RuntimeError("Start a fresh Python interpreter after fork to use Lean packages")
