#include "component.h"
#include "lean_bridge_native_runtime.h"
static _Thread_local int lean_bridge_owned_callback_failure_9491ed9d31a5b8317640_state;
int lean_bridge_owned_callback_failure_9491ed9d31a5b8317640(void) { int result = lean_bridge_owned_callback_failure_9491ed9d31a5b8317640_state; lean_bridge_owned_callback_failure_9491ed9d31a5b8317640_state = 0; return result; }
