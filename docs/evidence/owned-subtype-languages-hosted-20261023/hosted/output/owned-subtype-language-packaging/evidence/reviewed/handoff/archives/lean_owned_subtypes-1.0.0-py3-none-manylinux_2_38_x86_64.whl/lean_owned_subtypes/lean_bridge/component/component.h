#pragma once
#include <lean/lean.h>
#include <stdint.h>
/* Private typed helpers consume their Array arguments and return an owned Array. */
uint8_t lean_bridge_owned_refine_14adb93498676f4c30f0(lean_object *);
uint8_t lean_bridge_owned_refine_a32d032838dcef0ffcc0(lean_object *);
lean_object * lean_bridge_owned_4b93149f826b8908c8eb1068_t82551d965c182180b0dd_make(lean_object *);
lean_object * lean_bridge_owned_4b93149f826b8908c8eb1068_t82551d965c182180b0dd_items(lean_object *);
lean_object * lean_bridge_owned_4b93149f826b8908c8eb1068_t82551d965c182180b0dd_itemsBounded(lean_object *, lean_object *);
lean_object * lean_bridge_owned_4b93149f826b8908c8eb1068_t659ec6a690764999d00d_make(lean_object *);
lean_object * lean_bridge_owned_4b93149f826b8908c8eb1068_t659ec6a690764999d00d_items(lean_object *);
lean_object * lean_bridge_owned_4b93149f826b8908c8eb1068_t659ec6a690764999d00d_itemsBounded(lean_object *, lean_object *);
uint32_t lean_bridge_owned_4b93149f826b8908c8eb1068_t817592654f48ba756bd4_branch(lean_object *);
lean_object * lean_bridge_owned_4b93149f826b8908c8eb1068_t817592654f48ba756bd4_none(lean_object *);
lean_object * lean_bridge_owned_4b93149f826b8908c8eb1068_t817592654f48ba756bd4_make0(lean_object *);
lean_object * lean_bridge_owned_4b93149f826b8908c8eb1068_t817592654f48ba756bd4_field0(lean_object *);
lean_object * lean_bridge_owned_4b93149f826b8908c8eb1068_t5faad500583201774348_make(lean_object *, lean_object *, lean_object *, lean_object *, lean_object *);
lean_object * lean_bridge_owned_4b93149f826b8908c8eb1068_t5faad500583201774348_field0(lean_object *);
lean_object * lean_bridge_owned_4b93149f826b8908c8eb1068_t5faad500583201774348_field1(lean_object *);
lean_object * lean_bridge_owned_4b93149f826b8908c8eb1068_t5faad500583201774348_field2(lean_object *);
lean_object * lean_bridge_owned_4b93149f826b8908c8eb1068_t5faad500583201774348_field3(lean_object *);
lean_object * lean_bridge_owned_4b93149f826b8908c8eb1068_t5faad500583201774348_field4(lean_object *);
lean_object * lean_bridge_owned_4b93149f826b8908c8eb1068_t550e0acb733e8dd08e4e_make(lean_object *, lean_object *);
lean_object * lean_bridge_owned_4b93149f826b8908c8eb1068_t550e0acb733e8dd08e4e_field0(lean_object *);
lean_object * lean_bridge_owned_4b93149f826b8908c8eb1068_t550e0acb733e8dd08e4e_field1(lean_object *);
lean_object * lean_bridge_owned_4b93149f826b8908c8eb1068_f080cb47999bb83cdc0c1(lean_object *);
lean_object * lean_bridge_owned_4b93149f826b8908c8eb1068_f579c430cd49e7c98161f(lean_object *);
lean_object * lean_bridge_owned_4b93149f826b8908c8eb1068_f9735b5a0a586b46ce0b8(lean_object *, lean_object *);
lean_object * lean_bridge_owned_4b93149f826b8908c8eb1068_f52957d819a8a28259bf1(lean_object *);
lean_object * lean_bridge_owned_4b93149f826b8908c8eb1068_f973a6e63b7dad7a3d147(lean_object *);
int lean_bridge_owned_callback_failure_9491ed9d31a5b8317640(void);
