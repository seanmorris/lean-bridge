from __future__ import annotations
from dataclasses import dataclass as _dataclass
from typing import ClassVar as _ClassVar, Literal as _Literal, TypeAlias as _TypeAlias, Never as _Never

__all__ = ("Some", "Option", "Bundle", "Payload", "Ticket", "LeanBridgeError", "echo_record", "echo_record_alternate", "new_ticket", "serial", "transfer_record",)

from typing import Generic as _Generic, TypeVar as _TypeVar

_T = _TypeVar("_T", covariant=True)
_E = _TypeVar("_E", covariant=True)

@_dataclass(frozen=True)
class Some(_Generic[_T]):
    value: _T

Option = Some[_T] | None


class LeanBridgeError(RuntimeError):
    status: int
    def __init__(self, status: int, message: str | None = None) -> None: ...

@_dataclass(frozen=True, slots=True)
class Bundle:
    primary: Ticket
    spare: _Input2
    peers: _Input1
    history: _Input0
    payload: Payload

@_dataclass(frozen=True, slots=True)
class Payload:
    count: int
    bytes_: bytes

class Ticket:
    __slots__ = ()
    def __init__(self, _forbidden: _Never) -> None: ...
    @property
    def is_closed(self) -> bool: ...
    def close(self) -> None: ...
    def __enter__(self) -> Ticket: ...
    def __exit__(self, *args: object) -> None: ...
    def retain(self) -> Ticket:
        ...

_Value0: _TypeAlias = tuple[Ticket, ...]
_Input0: _TypeAlias = tuple[Ticket, ...] | list[Ticket]
_Value1: _TypeAlias = tuple[Ticket, ...]
_Input1: _TypeAlias = tuple[Ticket, ...] | list[Ticket]
_Value2: _TypeAlias = Option[Ticket]
_Input2: _TypeAlias = Option[Ticket]

def echo_record(arg0: Bundle) -> Bundle:
    ...

def echo_record_alternate(arg0: Bundle) -> Bundle:
    ...

def new_ticket(arg0: int, arg1: str) -> Ticket:
    ...

def serial(arg0: Ticket) -> int:
    ...

def transfer_record(arg0: Bundle) -> Bundle:
    """Consume resource leases in arg0 at the Lean call boundary.

    Shared aliases close at handoff; independently retained owners stay usable.
    Validation and preparation failures preserve ownership. Failures after
    handoff leave inputs consumed. Callback borrows must be retained first.
    """
    ...
