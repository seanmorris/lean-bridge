from __future__ import annotations
from dataclasses import dataclass as _dataclass
from typing import ClassVar as _ClassVar, Literal as _Literal, TypeAlias as _TypeAlias, Never as _Never
from ._owned import _OwnedResource, LeanBridgeError

try:
    from typing import TypeAliasType as _TypeAliasType
except ImportError:
    from typing_extensions import TypeAliasType as _TypeAliasType

__all__ = ("Some", "Option", "Bundle", "Payload", "Ticket", "LeanBridgeError", "echo_record", "echo_record_alternate", "new_ticket", "serial", "transfer_record",)

from typing import Generic as _Generic, TypeVar as _TypeVar

_T = _TypeVar("_T", covariant=True)
_E = _TypeVar("_E", covariant=True)

@_dataclass(frozen=True)
class Some(_Generic[_T]):
    value: _T

Option = Some[_T] | None


@_dataclass(frozen=True, slots=True)
class Bundle:
    primary: Ticket
    spare: _Input2
    peers: _Input1
    history: _Input0
    payload: Payload

@_dataclass(frozen=True, slots=True)
class Payload:
    count: int
    bytes_: bytes

class Ticket(_OwnedResource):
    __slots__ = ()
    def retain(self) -> Ticket:
        from . import _native
        return _native._retain5(self)

_Value0 = _TypeAliasType("_Value0", tuple[Ticket, ...])
_Input0 = _TypeAliasType("_Input0", tuple[Ticket, ...] | list[Ticket])
_Value1 = _TypeAliasType("_Value1", tuple[Ticket, ...])
_Input1 = _TypeAliasType("_Input1", tuple[Ticket, ...] | list[Ticket])
_Value2 = _TypeAliasType("_Value2", Option[Ticket])
_Input2 = _TypeAliasType("_Input2", Option[Ticket])

def echo_record(arg0: Bundle) -> Bundle:
    from . import _native
    return _native._call0(arg0)

def echo_record_alternate(arg0: Bundle) -> Bundle:
    from . import _native
    return _native._call1(arg0)

def new_ticket(arg0: int, arg1: str) -> Ticket:
    from . import _native
    return _native._call2(arg0, arg1)

def serial(arg0: Ticket) -> int:
    from . import _native
    return _native._call3(arg0)

def transfer_record(arg0: Bundle) -> Bundle:
    """Consume resource leases in arg0 at the Lean call boundary.

    Shared aliases close at handoff; independently retained owners stay usable.
    Validation and preparation failures preserve ownership. Failures after
    handoff leave inputs consumed. Callback borrows must be retained first.
    """
    from . import _native
    return _native._call4(arg0)

from . import _native as _OwnedNative
