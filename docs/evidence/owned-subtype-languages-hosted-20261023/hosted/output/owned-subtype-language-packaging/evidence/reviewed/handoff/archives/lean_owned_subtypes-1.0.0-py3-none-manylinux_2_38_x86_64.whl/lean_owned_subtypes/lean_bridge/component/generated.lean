import Owned
set_option maxRecDepth 10000
namespace LeanBridgeOwneddd368cf90fc8c4ad
def carrierValue {α : Type} (value : _root_.Array α) : _root_.Option α :=
  if bound : 0 < value.size then
    if value.size == 1 then .some (value[0]'bound) else .none
  else .none

def carrierResult {α : Type} (value : _root_.Option α) : _root_.Array α :=
  match value with | .none => #[] | .some result => #[result]

def carrierCollect {α : Type} (values : _root_.Array (_root_.Array α)) : _root_.Option (_root_.Array α) := Id.run do
  if values.size > 262144 then return .none
  let mut result := #[]
  for value in values do
    match carrierValue value with
    | .none => return .none
    | .some item => result := result.push item
  return .some result

def carrierListItems {α : Type} (values : _root_.List α) (limit : _root_.Nat) : _root_.Array (_root_.Array α) :=
  let rec loop : _root_.Nat → _root_.List α → _root_.Array (_root_.Array α) → _root_.Array (_root_.Array α)
    | 0, _, acc => acc
    | _, [], acc => acc
    | fuel + 1, head :: tail, acc => loop fuel tail (acc.push #[head])
  loop (min limit 262145) values #[]

structure LbOwnedErased.Owned.Payload where
  «count» : _root_.Int
  «bytes» : _root_.ByteArray

structure LbOwnedErased.Owned.Bundle where
  «primary» : _root_.Owned.Ticket
  «spare» : (_root_.Option _root_.Owned.Ticket)
  «peers» : (_root_.Array _root_.Owned.Ticket)
  «history» : (_root_.List _root_.Owned.Ticket)
  «payload» : LbOwnedErased.Owned.Payload

@[export lean_bridge_owned_refine_14adb93498676f4c30f0]
def lean_bridge_owned_refine_14adb93498676f4c30f0 (carrier : _root_.Array LbOwnedErased.Owned.Bundle) : _root_.UInt8 :=
  match carrierValue carrier with
  | .none => 0
  | .some value =>
    match (do let a0_0 ← (_root_.Option.some ((value).«primary»)); let a0_1 ← (_root_.Option.some ((value).«spare»)); let a0_2 ← (_root_.Option.some ((value).«peers»)); let a0_3 ← (_root_.Option.some ((value).«history»)); let a0_4 ← (do let a1_0 ← _root_.Owned.checkedCount (((value).«payload»).«count»); let a1_1 ← (_root_.Option.some (((value).«payload»).«bytes»)); pure (({ «count» := a1_0, «bytes» := a1_1 } : _root_.Owned.Payload))); pure (({ «primary» := a0_0, «spare» := a0_1, «peers» := a0_2, «history» := a0_3, «payload» := a0_4 } : _root_.Owned.Bundle))) with
    | .some _ => 1
    | .none => 0

@[export lean_bridge_owned_refine_a32d032838dcef0ffcc0]
def lean_bridge_owned_refine_a32d032838dcef0ffcc0 (carrier : _root_.Array LbOwnedErased.Owned.Bundle) : _root_.UInt8 :=
  match carrierValue carrier with
  | .none => 0
  | .some value =>
    match (do let a0_0 ← (_root_.Option.some ((value).«primary»)); let a0_1 ← (_root_.Option.some ((value).«spare»)); let a0_2 ← (_root_.Option.some ((value).«peers»)); let a0_3 ← (_root_.Option.some ((value).«history»)); let a0_4 ← (do let a1_0 ← _root_.Owned.checkedCountAlternate (((value).«payload»).«count»); let a1_1 ← (_root_.Option.some (((value).«payload»).«bytes»)); pure (({ «count» := a1_0, «bytes» := a1_1 } : _root_.Owned.Payload))); pure (({ «primary» := a0_0, «spare» := a0_1, «peers» := a0_2, «history» := a0_3, «payload» := a0_4 } : _root_.Owned.Bundle))) with
    | .some _ => 1
    | .none => 0

@[export lean_bridge_owned_4b93149f826b8908c8eb1068_t82551d965c182180b0dd_make]
def carrier0 (values : _root_.Array (_root_.Array _root_.Owned.Ticket)) : (_root_.Array (_root_.List _root_.Owned.Ticket)) :=
  carrierResult (do
    let values ← carrierCollect values
    pure values.toList
  )

@[export lean_bridge_owned_4b93149f826b8908c8eb1068_t82551d965c182180b0dd_items]
def carrier1 (value : (_root_.Array (_root_.List _root_.Owned.Ticket))) : (_root_.Array (_root_.Array _root_.Owned.Ticket)) :=
  match carrierValue value with
  | .none => #[]
  | .some values => carrierListItems values 262145

@[export lean_bridge_owned_4b93149f826b8908c8eb1068_t82551d965c182180b0dd_itemsBounded]
def carrier2 (value : (_root_.Array (_root_.List _root_.Owned.Ticket))) (limit : _root_.Nat) : (_root_.Array (_root_.Array _root_.Owned.Ticket)) :=
  let bound := min limit 262144 + 1
  match carrierValue value with
  | .none => #[]
  | .some values => carrierListItems values bound

@[export lean_bridge_owned_4b93149f826b8908c8eb1068_t659ec6a690764999d00d_make]
def carrier3 (values : _root_.Array (_root_.Array _root_.Owned.Ticket)) : (_root_.Array (_root_.Array _root_.Owned.Ticket)) :=
  carrierResult (do
    let values ← carrierCollect values
    pure values
  )

@[export lean_bridge_owned_4b93149f826b8908c8eb1068_t659ec6a690764999d00d_items]
def carrier4 (value : (_root_.Array (_root_.Array _root_.Owned.Ticket))) : (_root_.Array (_root_.Array _root_.Owned.Ticket)) :=
  match carrierValue value with
  | .none => #[]
  | .some values => (values.extract 0 262145).map (fun child => #[child])

@[export lean_bridge_owned_4b93149f826b8908c8eb1068_t659ec6a690764999d00d_itemsBounded]
def carrier5 (value : (_root_.Array (_root_.Array _root_.Owned.Ticket))) (limit : _root_.Nat) : (_root_.Array (_root_.Array _root_.Owned.Ticket)) :=
  let bound := min limit 262144 + 1
  match carrierValue value with
  | .none => #[]
  | .some values => (values.extract 0 bound).map (fun child => #[child])

@[export lean_bridge_owned_4b93149f826b8908c8eb1068_t817592654f48ba756bd4_branch]
def carrier6 (value : (_root_.Array (_root_.Option _root_.Owned.Ticket))) : _root_.UInt32 :=
  match carrierValue value with
  | .none => 4294967295
  | .some value =>
    match value with
    | .none => 0
    | .some _ => 1

@[export lean_bridge_owned_4b93149f826b8908c8eb1068_t817592654f48ba756bd4_none]
def carrier7 (_bridgeUnit : _root_.Unit) : (_root_.Array (_root_.Option _root_.Owned.Ticket)) :=
  carrierResult (do
    pure (.none)
  )

@[export lean_bridge_owned_4b93149f826b8908c8eb1068_t817592654f48ba756bd4_make0]
def carrier8 (a0 : (_root_.Array _root_.Owned.Ticket)) : (_root_.Array (_root_.Option _root_.Owned.Ticket)) :=
  carrierResult (do
    let a0 ← carrierValue a0
    pure (.some a0)
  )

@[export lean_bridge_owned_4b93149f826b8908c8eb1068_t817592654f48ba756bd4_field0]
def carrier9 (value : (_root_.Array (_root_.Option _root_.Owned.Ticket))) : (_root_.Array _root_.Owned.Ticket) :=
  carrierResult (do
    let value ← carrierValue value
    match value with
    | .some child => pure child
    | _ => .none
  )

@[export lean_bridge_owned_4b93149f826b8908c8eb1068_t5faad500583201774348_make]
def carrier10 (a0 : (_root_.Array _root_.Owned.Ticket)) (a1 : (_root_.Array (_root_.Option _root_.Owned.Ticket))) (a2 : (_root_.Array (_root_.Array _root_.Owned.Ticket))) (a3 : (_root_.Array (_root_.List _root_.Owned.Ticket))) (a4 : (_root_.Array LbOwnedErased.Owned.Payload)) : (_root_.Array LbOwnedErased.Owned.Bundle) :=
  carrierResult (do
    let a0 ← carrierValue a0
    let a1 ← carrierValue a1
    let a2 ← carrierValue a2
    let a3 ← carrierValue a3
    let a4 ← carrierValue a4
    pure (({ «primary» := a0, «spare» := a1, «peers» := a2, «history» := a3, «payload» := a4 } : LbOwnedErased.Owned.Bundle))
  )

@[export lean_bridge_owned_4b93149f826b8908c8eb1068_t5faad500583201774348_field0]
def carrier11 (value : (_root_.Array LbOwnedErased.Owned.Bundle)) : (_root_.Array _root_.Owned.Ticket) :=
  carrierResult (do
    let value ← carrierValue value
    pure value.«primary»
  )

@[export lean_bridge_owned_4b93149f826b8908c8eb1068_t5faad500583201774348_field1]
def carrier12 (value : (_root_.Array LbOwnedErased.Owned.Bundle)) : (_root_.Array (_root_.Option _root_.Owned.Ticket)) :=
  carrierResult (do
    let value ← carrierValue value
    pure value.«spare»
  )

@[export lean_bridge_owned_4b93149f826b8908c8eb1068_t5faad500583201774348_field2]
def carrier13 (value : (_root_.Array LbOwnedErased.Owned.Bundle)) : (_root_.Array (_root_.Array _root_.Owned.Ticket)) :=
  carrierResult (do
    let value ← carrierValue value
    pure value.«peers»
  )

@[export lean_bridge_owned_4b93149f826b8908c8eb1068_t5faad500583201774348_field3]
def carrier14 (value : (_root_.Array LbOwnedErased.Owned.Bundle)) : (_root_.Array (_root_.List _root_.Owned.Ticket)) :=
  carrierResult (do
    let value ← carrierValue value
    pure value.«history»
  )

@[export lean_bridge_owned_4b93149f826b8908c8eb1068_t5faad500583201774348_field4]
def carrier15 (value : (_root_.Array LbOwnedErased.Owned.Bundle)) : (_root_.Array LbOwnedErased.Owned.Payload) :=
  carrierResult (do
    let value ← carrierValue value
    pure value.«payload»
  )

@[export lean_bridge_owned_4b93149f826b8908c8eb1068_t550e0acb733e8dd08e4e_make]
def carrier16 (a0 : (_root_.Array _root_.Int)) (a1 : (_root_.Array _root_.ByteArray)) : (_root_.Array LbOwnedErased.Owned.Payload) :=
  carrierResult (do
    let a0 ← carrierValue a0
    let a1 ← carrierValue a1
    pure (({ «count» := a0, «bytes» := a1 } : LbOwnedErased.Owned.Payload))
  )

@[export lean_bridge_owned_4b93149f826b8908c8eb1068_t550e0acb733e8dd08e4e_field0]
def carrier17 (value : (_root_.Array LbOwnedErased.Owned.Payload)) : (_root_.Array _root_.Int) :=
  carrierResult (do
    let value ← carrierValue value
    pure value.«count»
  )

@[export lean_bridge_owned_4b93149f826b8908c8eb1068_t550e0acb733e8dd08e4e_field1]
def carrier18 (value : (_root_.Array LbOwnedErased.Owned.Payload)) : (_root_.Array _root_.ByteArray) :=
  carrierResult (do
    let value ← carrierValue value
    pure value.«bytes»
  )

@[export lean_bridge_owned_4b93149f826b8908c8eb1068_f080cb47999bb83cdc0c1]
def carrier19 (a0 : (_root_.Array LbOwnedErased.Owned.Bundle)) : (_root_.Array LbOwnedErased.Owned.Bundle) :=
  carrierResult (do
    let a0 ← carrierValue a0
    let _source0 ← (do let a0_0 ← (_root_.Option.some ((a0).«primary»)); let a0_1 ← (_root_.Option.some ((a0).«spare»)); let a0_2 ← (_root_.Option.some ((a0).«peers»)); let a0_3 ← (_root_.Option.some ((a0).«history»)); let a0_4 ← (do let a1_0 ← _root_.Owned.checkedCount (((a0).«payload»).«count»); let a1_1 ← (_root_.Option.some (((a0).«payload»).«bytes»)); pure (({ «count» := a1_0, «bytes» := a1_1 } : _root_.Owned.Payload))); pure (({ «primary» := a0_0, «spare» := a0_1, «peers» := a0_2, «history» := a0_3, «payload» := a0_4 } : _root_.Owned.Bundle)))
    let _sourceResult := _root_.Owned.echoRecord _source0
    pure ((LbOwnedErased.Owned.Bundle.mk ((_sourceResult).«primary») ((_sourceResult).«spare») ((_sourceResult).«peers») ((_sourceResult).«history») (LbOwnedErased.Owned.Payload.mk (_root_.Subtype.val (((_sourceResult).«payload»).«count»)) (((_sourceResult).«payload»).«bytes»))))
  )

@[export lean_bridge_owned_4b93149f826b8908c8eb1068_f579c430cd49e7c98161f]
def carrier20 (a0 : (_root_.Array LbOwnedErased.Owned.Bundle)) : (_root_.Array LbOwnedErased.Owned.Bundle) :=
  carrierResult (do
    let a0 ← carrierValue a0
    let _source0 ← (do let a0_0 ← (_root_.Option.some ((a0).«primary»)); let a0_1 ← (_root_.Option.some ((a0).«spare»)); let a0_2 ← (_root_.Option.some ((a0).«peers»)); let a0_3 ← (_root_.Option.some ((a0).«history»)); let a0_4 ← (do let a1_0 ← _root_.Owned.checkedCountAlternate (((a0).«payload»).«count»); let a1_1 ← (_root_.Option.some (((a0).«payload»).«bytes»)); pure (({ «count» := a1_0, «bytes» := a1_1 } : _root_.Owned.Payload))); pure (({ «primary» := a0_0, «spare» := a0_1, «peers» := a0_2, «history» := a0_3, «payload» := a0_4 } : _root_.Owned.Bundle)))
    let _sourceResult := _root_.Owned.echoRecordAlternate _source0
    pure ((LbOwnedErased.Owned.Bundle.mk ((_sourceResult).«primary») ((_sourceResult).«spare») ((_sourceResult).«peers») ((_sourceResult).«history») (LbOwnedErased.Owned.Payload.mk (_root_.Subtype.val (((_sourceResult).«payload»).«count»)) (((_sourceResult).«payload»).«bytes»))))
  )

@[export lean_bridge_owned_4b93149f826b8908c8eb1068_f9735b5a0a586b46ce0b8]
def carrier21 (a0 : (_root_.Array _root_.Nat)) (a1 : (_root_.Array _root_.String)) : (_root_.Array _root_.Owned.Ticket) :=
  carrierResult (do
    let a0 ← carrierValue a0
    let a1 ← carrierValue a1
    pure (_root_.Owned.newTicket a0 a1)
  )

@[export lean_bridge_owned_4b93149f826b8908c8eb1068_f52957d819a8a28259bf1]
def carrier22 (a0 : (_root_.Array _root_.Owned.Ticket)) : (_root_.Array _root_.Nat) :=
  carrierResult (do
    let a0 ← carrierValue a0
    pure (_root_.Owned.serial a0)
  )

@[export lean_bridge_owned_4b93149f826b8908c8eb1068_f973a6e63b7dad7a3d147]
def carrier23 (a0 : (_root_.Array LbOwnedErased.Owned.Bundle)) : (_root_.Array LbOwnedErased.Owned.Bundle) :=
  carrierResult (do
    let a0 ← carrierValue a0
    let _source0 ← (do let a0_0 ← (_root_.Option.some ((a0).«primary»)); let a0_1 ← (_root_.Option.some ((a0).«spare»)); let a0_2 ← (_root_.Option.some ((a0).«peers»)); let a0_3 ← (_root_.Option.some ((a0).«history»)); let a0_4 ← (do let a1_0 ← _root_.Owned.checkedCount (((a0).«payload»).«count»); let a1_1 ← (_root_.Option.some (((a0).«payload»).«bytes»)); pure (({ «count» := a1_0, «bytes» := a1_1 } : _root_.Owned.Payload))); pure (({ «primary» := a0_0, «spare» := a0_1, «peers» := a0_2, «history» := a0_3, «payload» := a0_4 } : _root_.Owned.Bundle)))
    let _sourceResult := _root_.Owned.transferRecord _source0
    pure ((LbOwnedErased.Owned.Bundle.mk ((_sourceResult).«primary») ((_sourceResult).«spare») ((_sourceResult).«peers») ((_sourceResult).«history») (LbOwnedErased.Owned.Payload.mk (_root_.Subtype.val (((_sourceResult).«payload»).«count»)) (((_sourceResult).«payload»).«bytes»))))
  )

end LeanBridgeOwneddd368cf90fc8c4ad
