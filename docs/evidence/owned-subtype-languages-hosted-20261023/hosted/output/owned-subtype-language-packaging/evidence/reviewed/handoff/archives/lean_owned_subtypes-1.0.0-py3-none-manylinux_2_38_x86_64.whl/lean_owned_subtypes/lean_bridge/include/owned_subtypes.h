#pragma once
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <gmp.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef enum owned_subtypes_status { OWNED_SUBTYPES_OK = 0, OWNED_SUBTYPES_INVALID_ARGUMENT = 1, OWNED_SUBTYPES_LIMIT = 2, OWNED_SUBTYPES_ALLOCATION_FAILED = 3, OWNED_SUBTYPES_CLOSED = 4, OWNED_SUBTYPES_WRONG_THREAD = 5, OWNED_SUBTYPES_WRONG_PROCESS = 6, OWNED_SUBTYPES_RUNTIME_UNAVAILABLE = 7, OWNED_SUBTYPES_CALL_ORDER = 8, OWNED_SUBTYPES_MALFORMED_RESULT = 9, OWNED_SUBTYPES_CALLBACK_FAILED = 10 } owned_subtypes_status;
typedef struct owned_subtypes_session owned_subtypes_session;
typedef struct owned_subtypes_result owned_subtypes_result;
/* Immutable views: input children borrow caller storage for one call.
   Output children, including GMP integers, remain valid until result_release.
   Never free a child or mutate a returned GMP integer. Retain an identity
   before releasing its last owning result. Sessions are thread/process bound.
   Close invalidates resource use; result_release still frees copied storage.
   Output/result slots must not overlap and *owner must initially be NULL.
   GMP retains its normal fatal out-of-memory policy. */
owned_subtypes_status owned_subtypes_session_open(owned_subtypes_session **out);
owned_subtypes_status owned_subtypes_session_close(owned_subtypes_session **value);
owned_subtypes_status owned_subtypes_result_release(owned_subtypes_result **value);
/* Transferred arguments take an additional input-owner slot. All arguments
   and owners are validated before consumption. Each owner must be distinct
   and belong to this session; owner slots must not overlap output slots.
   Immediately before Lean runs, each entire input owner is consumed and
   its slot becomes NULL. A later failure does not restore consumed owners.
   Old views expire when this call returns. Independently retained owners
   remain valid. Failure before consumption leaves input owners unchanged. */
typedef struct owned_subtypes_value_82551d965c182180b0dd_t owned_subtypes_value_82551d965c182180b0dd_t;
typedef struct owned_subtypes_value_659ec6a690764999d00d_t owned_subtypes_value_659ec6a690764999d00d_t;
typedef struct owned_subtypes_value_817592654f48ba756bd4_t owned_subtypes_value_817592654f48ba756bd4_t;
typedef struct owned_subtypes_bundle_t owned_subtypes_bundle_t;
typedef struct owned_subtypes_payload_t owned_subtypes_payload_t;
typedef struct owned_subtypes_ticket_t_handle *owned_subtypes_ticket_t;
typedef struct owned_subtypes_scalar_bytes_t owned_subtypes_scalar_bytes_t;
typedef struct owned_subtypes_scalar_string_t owned_subtypes_scalar_string_t;
struct owned_subtypes_scalar_bytes_t {
  const uint8_t *data;
  size_t length;
};
struct owned_subtypes_scalar_string_t {
  const char *data;
  size_t length;
};
struct owned_subtypes_value_82551d965c182180b0dd_t {
  owned_subtypes_ticket_t const *data;
  size_t length;
};
struct owned_subtypes_value_659ec6a690764999d00d_t {
  owned_subtypes_ticket_t const *data;
  size_t length;
};
struct owned_subtypes_value_817592654f48ba756bd4_t {
  bool has_value;
  owned_subtypes_ticket_t value;
};
struct owned_subtypes_bundle_t {
  owned_subtypes_ticket_t primary;
  owned_subtypes_value_817592654f48ba756bd4_t const *spare;
  owned_subtypes_value_659ec6a690764999d00d_t const *peers;
  owned_subtypes_value_82551d965c182180b0dd_t const *history;
  owned_subtypes_payload_t const *payload;
};
struct owned_subtypes_payload_t {
  mpz_srcptr count;
  owned_subtypes_scalar_bytes_t bytes;
};
typedef owned_subtypes_value_817592654f48ba756bd4_t owned_subtypes_bundle_spare_t;
typedef owned_subtypes_value_659ec6a690764999d00d_t owned_subtypes_bundle_peers_t;
typedef owned_subtypes_value_82551d965c182180b0dd_t owned_subtypes_bundle_history_t;
/* Host callbacks borrow their context for the enclosing call only.
   Set exactly one of call or closure. recovery is an optional typed value;
   it is required if the signature has no finite recovery from its inputs.
   Failure never publishes recovery as a successful result.
   Callback arguments expire on return. Replies may borrow those arguments
   or context storage, or transfer an owning result (also released on error).
   Use a generated copy function to snapshot callback-local storage.
   Do not let C++ exceptions or longjmp cross a callback boundary. */
owned_subtypes_status owned_subtypes_echo_record(owned_subtypes_session *session, owned_subtypes_bundle_t const * a0, owned_subtypes_bundle_t *out, owned_subtypes_result **owner);
owned_subtypes_status owned_subtypes_echo_record_alternate(owned_subtypes_session *session, owned_subtypes_bundle_t const * a0, owned_subtypes_bundle_t *out, owned_subtypes_result **owner);
owned_subtypes_status owned_subtypes_new_ticket(owned_subtypes_session *session, mpz_srcptr a0, owned_subtypes_scalar_string_t a1, owned_subtypes_ticket_t *out, owned_subtypes_result **owner);
owned_subtypes_status owned_subtypes_serial(owned_subtypes_session *session, owned_subtypes_ticket_t a0, mpz_srcptr *out, owned_subtypes_result **owner);
owned_subtypes_status owned_subtypes_transfer_record(owned_subtypes_session *session, owned_subtypes_bundle_t const * a0, owned_subtypes_result **a0_owner, owned_subtypes_bundle_t *out, owned_subtypes_result **owner);
owned_subtypes_status owned_subtypes_ticket_t_retain(owned_subtypes_session *session, owned_subtypes_ticket_t a0, owned_subtypes_ticket_t *out, owned_subtypes_result **owner);
owned_subtypes_status owned_subtypes_value_82551d965c182180b0dd_t_copy(owned_subtypes_session *session, owned_subtypes_value_82551d965c182180b0dd_t const * a0, owned_subtypes_value_82551d965c182180b0dd_t *out, owned_subtypes_result **owner);
owned_subtypes_status owned_subtypes_value_659ec6a690764999d00d_t_copy(owned_subtypes_session *session, owned_subtypes_value_659ec6a690764999d00d_t const * a0, owned_subtypes_value_659ec6a690764999d00d_t *out, owned_subtypes_result **owner);
owned_subtypes_status owned_subtypes_value_817592654f48ba756bd4_t_copy(owned_subtypes_session *session, owned_subtypes_value_817592654f48ba756bd4_t const * a0, owned_subtypes_value_817592654f48ba756bd4_t *out, owned_subtypes_result **owner);
owned_subtypes_status owned_subtypes_bundle_t_copy(owned_subtypes_session *session, owned_subtypes_bundle_t const * a0, owned_subtypes_bundle_t *out, owned_subtypes_result **owner);
owned_subtypes_status owned_subtypes_payload_t_copy(owned_subtypes_session *session, owned_subtypes_payload_t const * a0, owned_subtypes_payload_t *out, owned_subtypes_result **owner);
owned_subtypes_status owned_subtypes_scalar_bytes_copy(owned_subtypes_session *session, owned_subtypes_scalar_bytes_t a0, owned_subtypes_scalar_bytes_t *out, owned_subtypes_result **owner);
owned_subtypes_status owned_subtypes_scalar_int_copy(owned_subtypes_session *session, mpz_srcptr a0, mpz_srcptr *out, owned_subtypes_result **owner);
owned_subtypes_status owned_subtypes_scalar_nat_copy(owned_subtypes_session *session, mpz_srcptr a0, mpz_srcptr *out, owned_subtypes_result **owner);
owned_subtypes_status owned_subtypes_scalar_string_copy(owned_subtypes_session *session, owned_subtypes_scalar_string_t a0, owned_subtypes_scalar_string_t *out, owned_subtypes_result **owner);
#ifdef __cplusplus
}
#endif
