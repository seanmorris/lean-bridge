<?php
declare(strict_types=1);
namespace LeanOwnedCheckedRecordsPeer;

require_once __DIR__ . '/Internal/Values.php';



final class LeanBridgeError extends \RuntimeException {}

final readonly class Bytes implements \Stringable, \Countable
{
    private function __construct(private string $value) {}
    public static function fromString(mixed $value): self {
        if (!\is_string($value)) throw new \TypeError('Bytes requires a string');
        return new self($value);
    }
    public function toString(): string { return $this->value; }
    public function __toString(): string { return $this->value; }
    public function count(): int { return \strlen($this->value); }

    public function equals(mixed $other): bool {
        return $other instanceof self && Internal\Values::equal($this, $other);
    }
    public function hashCode(): string { return Internal\Values::hash($this); }

}


/** @template T */
final readonly class Some
{
    /** @var T */
    public mixed $value;
    /** @param T $value */
    public function __construct(mixed $value) {
        if (\func_num_args() !== 1) throw new \ArgumentCountError('Some requires one payload');
        $this->value = $value;
    }

    public function equals(mixed $other): bool {
        return $other instanceof self && Internal\Values::equal($this, $other);
    }
    public function hashCode(): string { return Internal\Values::hash($this); }

}

/** @template T */
final readonly class Ok
{
    /** @var T */
    public mixed $value;
    /** @param T $value */
    public function __construct(mixed $value) {
        if (\func_num_args() !== 1) throw new \ArgumentCountError('Ok requires one payload');
        $this->value = $value;
    }

    public function equals(mixed $other): bool {
        return $other instanceof self && Internal\Values::equal($this, $other);
    }
    public function hashCode(): string { return Internal\Values::hash($this); }

}

/** @template T */
final readonly class Err
{
    /** @var T */
    public mixed $value;
    /** @param T $value */
    public function __construct(mixed $value) {
        if (\func_num_args() !== 1) throw new \ArgumentCountError('Err requires one payload');
        $this->value = $value;
    }

    public function equals(mixed $other): bool {
        return $other instanceof self && Internal\Values::equal($this, $other);
    }
    public function hashCode(): string { return Internal\Values::hash($this); }

}

final readonly class Claim
{
    /** @var Ticket */
    public Ticket $holder;
    /** @var \Brick\Math\BigInteger */
    public \Brick\Math\BigInteger $quota;
    public function __construct(mixed $holder, mixed $quota) {
        if (\func_num_args() !== 2) throw new \ArgumentCountError('Claim requires exactly 2 fields');
        Internal\Values::checkFields(self::class, [$holder, $quota]);
        $this->holder = $holder;
        $this->quota = $quota;
    }

    public function equals(mixed $other): bool {
        return $other instanceof self && Internal\Values::equal($this, $other);
    }
    public function hashCode(): string { return Internal\Values::hash($this); }

}
final class Ticket extends Internal\Resource
{
}

require_once __DIR__ . '/Internal/Native.php';
/**
 * @param Ticket $arg0
 * @return Some<Claim>|null
 */
function claim_for(mixed $arg0): Some|null {
    if (\func_num_args() !== 1) throw new \ArgumentCountError('claim_for requires exactly 1 arguments');
    return Internal\Native::call(0, [$arg0]);
}

/**
 * @param \Brick\Math\BigInteger $arg0
 * @param string $arg1
 * @return Ticket
 */
function new_ticket(mixed $arg0, mixed $arg1): Ticket {
    if (\func_num_args() !== 2) throw new \ArgumentCountError('new_ticket requires exactly 2 arguments');
    return Internal\Native::call(1, [$arg0, $arg1]);
}

/**
 * @param Ticket $arg0
 * @return \Brick\Math\BigInteger
 */
function serial(mixed $arg0): \Brick\Math\BigInteger {
    if (\func_num_args() !== 1) throw new \ArgumentCountError('serial requires exactly 1 arguments');
    return Internal\Native::call(2, [$arg0]);
}
