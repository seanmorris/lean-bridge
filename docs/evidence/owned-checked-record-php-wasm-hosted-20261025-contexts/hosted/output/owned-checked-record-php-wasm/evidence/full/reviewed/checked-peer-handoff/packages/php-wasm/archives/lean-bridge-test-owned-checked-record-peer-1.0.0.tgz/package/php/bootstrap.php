<?php
declare(strict_types=1);
require_once __DIR__ . '/dependencies/brick-math/autoload.php';
require_once __DIR__ . '/src/Api.php';
