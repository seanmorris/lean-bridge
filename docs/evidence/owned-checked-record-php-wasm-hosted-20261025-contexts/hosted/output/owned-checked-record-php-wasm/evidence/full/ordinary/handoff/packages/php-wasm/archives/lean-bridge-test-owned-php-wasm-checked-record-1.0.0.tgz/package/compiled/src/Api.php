<?php
declare(strict_types=1);
namespace LeanOwnedCheckedRecords;

require_once __DIR__ . '/Internal/Values.php';



final class LeanBridgeError extends \RuntimeException {}

final readonly class Bytes implements \Stringable, \Countable
{
    private function __construct(private string $value) {}
    public static function fromString(mixed $value): self {
        if (!\is_string($value)) throw new \TypeError('Bytes requires a string');
        return new self($value);
    }
    public function toString(): string { return $this->value; }
    public function __toString(): string { return $this->value; }
    public function count(): int { return \strlen($this->value); }

    public function equals(mixed $other): bool {
        return $other instanceof self && Internal\Values::equal($this, $other);
    }
    public function hashCode(): string { return Internal\Values::hash($this); }

}


/** @template T */
final readonly class Some
{
    /** @var T */
    public mixed $value;
    /** @param T $value */
    public function __construct(mixed $value) {
        if (\func_num_args() !== 1) throw new \ArgumentCountError('Some requires one payload');
        $this->value = $value;
    }

    public function equals(mixed $other): bool {
        return $other instanceof self && Internal\Values::equal($this, $other);
    }
    public function hashCode(): string { return Internal\Values::hash($this); }

}

/** @template T */
final readonly class Ok
{
    /** @var T */
    public mixed $value;
    /** @param T $value */
    public function __construct(mixed $value) {
        if (\func_num_args() !== 1) throw new \ArgumentCountError('Ok requires one payload');
        $this->value = $value;
    }

    public function equals(mixed $other): bool {
        return $other instanceof self && Internal\Values::equal($this, $other);
    }
    public function hashCode(): string { return Internal\Values::hash($this); }

}

/** @template T */
final readonly class Err
{
    /** @var T */
    public mixed $value;
    /** @param T $value */
    public function __construct(mixed $value) {
        if (\func_num_args() !== 1) throw new \ArgumentCountError('Err requires one payload');
        $this->value = $value;
    }

    public function equals(mixed $other): bool {
        return $other instanceof self && Internal\Values::equal($this, $other);
    }
    public function hashCode(): string { return Internal\Values::hash($this); }

}

final readonly class Booking
{
    /** @var Ticket */
    public Ticket $holder;
    /** @var Window */
    public Window $window;
    public function __construct(mixed $holder, mixed $window) {
        if (\func_num_args() !== 2) throw new \ArgumentCountError('Booking requires exactly 2 fields');
        Internal\Values::checkFields(self::class, [$holder, $window]);
        $this->holder = $holder;
        $this->window = $window;
    }

    public function equals(mixed $other): bool {
        return $other instanceof self && Internal\Values::equal($this, $other);
    }
    public function hashCode(): string { return Internal\Values::hash($this); }

}

final readonly class Claim
{
    /** @var Ticket */
    public Ticket $holder;
    /** @var \Brick\Math\BigInteger */
    public \Brick\Math\BigInteger $quota;
    public function __construct(mixed $holder, mixed $quota) {
        if (\func_num_args() !== 2) throw new \ArgumentCountError('Claim requires exactly 2 fields');
        Internal\Values::checkFields(self::class, [$holder, $quota]);
        $this->holder = $holder;
        $this->quota = $quota;
    }

    public function equals(mixed $other): bool {
        return $other instanceof self && Internal\Values::equal($this, $other);
    }
    public function hashCode(): string { return Internal\Values::hash($this); }

}

final readonly class Grant
{
    /** @var Ticket */
    public Ticket $holder;
    /** @var \Brick\Math\BigInteger */
    public \Brick\Math\BigInteger $weight;
    /** @var \Brick\Math\BigInteger */
    public \Brick\Math\BigInteger $limit;
    public function __construct(mixed $holder, mixed $weight, mixed $limit) {
        if (\func_num_args() !== 3) throw new \ArgumentCountError('Grant requires exactly 3 fields');
        Internal\Values::checkFields(self::class, [$holder, $weight, $limit]);
        $this->holder = $holder;
        $this->weight = $weight;
        $this->limit = $limit;
    }

    public function equals(mixed $other): bool {
        return $other instanceof self && Internal\Values::equal($this, $other);
    }
    public function hashCode(): string { return Internal\Values::hash($this); }

}

final readonly class Window
{
    /** @var \Brick\Math\BigInteger */
    public \Brick\Math\BigInteger $lo;
    /** @var \Brick\Math\BigInteger */
    public \Brick\Math\BigInteger $hi;
    public function __construct(mixed $lo, mixed $hi) {
        if (\func_num_args() !== 2) throw new \ArgumentCountError('Window requires exactly 2 fields');
        Internal\Values::checkFields(self::class, [$lo, $hi]);
        $this->lo = $lo;
        $this->hi = $hi;
    }

    public function equals(mixed $other): bool {
        return $other instanceof self && Internal\Values::equal($this, $other);
    }
    public function hashCode(): string { return Internal\Values::hash($this); }

}
final class Callback26621c40b48fce52ca37 extends Internal\Resource
{
    public function __invoke(mixed $argument0): mixed {
        if (\func_num_args() !== 1) throw new \ArgumentCountError('Lean closure requires 1 arguments');
        return Internal\ResourceAccess::invoke($this, [$argument0]);
    }
}

final class Callbackb2d3d6fd4e031785f278 extends Internal\Resource
{
    public function __invoke(mixed $argument0): mixed {
        if (\func_num_args() !== 1) throw new \ArgumentCountError('Lean closure requires 1 arguments');
        return Internal\ResourceAccess::invoke($this, [$argument0]);
    }
}

final class Ticket extends Internal\Resource
{
}

final readonly class WithRecovery
{
    public function __construct(public mixed $callback, public mixed $value) {
        if (\func_num_args() !== 2) throw new \ArgumentCountError('WithRecovery requires a callback and typed value');
    }
}
function with_recovery(mixed $callback, mixed $value): WithRecovery {
    if (\func_num_args() !== 2) throw new \ArgumentCountError('with_recovery requires two arguments');
    return new WithRecovery($callback, $value);
}
require_once __DIR__ . '/Internal/Native.php';
/**
 * @param Booking $arg0
 * @return \Brick\Math\BigInteger
 */
function booking_span(mixed $arg0): \Brick\Math\BigInteger {
    if (\func_num_args() !== 1) throw new \ArgumentCountError('booking_span requires exactly 1 arguments');
    return Internal\Native::call(0, [$arg0]);
}

/**

 * @return Callback26621c40b48fce52ca37
 */
function claim_closure(): Callback26621c40b48fce52ca37 {
    if (\func_num_args() !== 0) throw new \ArgumentCountError('claim_closure requires exactly 0 arguments');
    return Internal\Native::call(1, []);
}

/**
 * @param Ticket $arg0
 * @return Some<Claim>|null
 */
function claim_for(mixed $arg0): Some|null {
    if (\func_num_args() !== 1) throw new \ArgumentCountError('claim_for requires exactly 1 arguments');
    return Internal\Native::call(2, [$arg0]);
}

/**
 * @param Claim $arg0
 * @return \Brick\Math\BigInteger
 */
function claim_quota(mixed $arg0): \Brick\Math\BigInteger {
    if (\func_num_args() !== 1) throw new \ArgumentCountError('claim_quota requires exactly 1 arguments');
    return Internal\Native::call(3, [$arg0]);
}

/**
 * @param Booking $arg0
 * @return Booking
 */
function echo_booking(mixed $arg0): Booking {
    if (\func_num_args() !== 1) throw new \ArgumentCountError('echo_booking requires exactly 1 arguments');
    return Internal\Native::call(4, [$arg0]);
}

/**
 * @param Claim $arg0
 * @return Claim
 */
function echo_claim(mixed $arg0): Claim {
    if (\func_num_args() !== 1) throw new \ArgumentCountError('echo_claim requires exactly 1 arguments');
    return Internal\Native::call(5, [$arg0]);
}

/**
 * @param list<Claim> $arg0
 * @return list<Claim>
 */
function echo_claims(mixed $arg0): array {
    if (\func_num_args() !== 1) throw new \ArgumentCountError('echo_claims requires exactly 1 arguments');
    return Internal\Native::call(6, [$arg0]);
}

/**
 * @param Grant $arg0
 * @return Grant
 */
function echo_grant(mixed $arg0): Grant {
    if (\func_num_args() !== 1) throw new \ArgumentCountError('echo_grant requires exactly 1 arguments');
    return Internal\Native::call(7, [$arg0]);
}

/**
 * @param \Brick\Math\BigInteger $arg0
 * @param string $arg1
 * @return Ticket
 */
function new_ticket(mixed $arg0, mixed $arg1): Ticket {
    if (\func_num_args() !== 2) throw new \ArgumentCountError('new_ticket requires exactly 2 arguments');
    return Internal\Native::call(8, [$arg0, $arg1]);
}

/**
 * @param Booking $arg0
 * @param Claim $arg1
 * @return Claim
 */
function pair_claim(mixed $arg0, mixed $arg1): Claim {
    if (\func_num_args() !== 2) throw new \ArgumentCountError('pair_claim requires exactly 2 arguments');
    return Internal\Native::call(9, [$arg0, $arg1]);
}

/**
 * @param Ticket $arg0
 * @return \Brick\Math\BigInteger
 */
function serial(mixed $arg0): \Brick\Math\BigInteger {
    if (\func_num_args() !== 1) throw new \ArgumentCountError('serial requires exactly 1 arguments');
    return Internal\Native::call(10, [$arg0]);
}

/**
 * @param Claim $arg0
 * Consumes resource leases in $arg0 at the Lean call boundary.
 * @return Claim
 */
function transfer_claim(mixed $arg0): Claim {
    if (\func_num_args() !== 1) throw new \ArgumentCountError('transfer_claim requires exactly 1 arguments');
    return Internal\Native::call(11, [$arg0]);
}

/**
 * @param Booking $arg0
 * @param Claim $arg1
 * Consumes resource leases in $arg0, $arg1 at the Lean call boundary.
 * @return Claim
 */
function transfer_pair_claim(mixed $arg0, mixed $arg1): Claim {
    if (\func_num_args() !== 2) throw new \ArgumentCountError('transfer_pair_claim requires exactly 2 arguments');
    return Internal\Native::call(12, [$arg0, $arg1]);
}

/**
 * @param Claim $arg0
 * @param callable|Callbackb2d3d6fd4e031785f278|WithRecovery $arg1
 * Consumes resource leases in $arg0 at the Lean call boundary.
 * @return Claim
 */
function transfer_with_claim_callback(mixed $arg0, mixed $arg1): Claim {
    if (\func_num_args() !== 2) throw new \ArgumentCountError('transfer_with_claim_callback requires exactly 2 arguments');
    return Internal\Native::call(13, [$arg0, $arg1]);
}

/**
 * @param Claim $arg0
 * @param callable|Callbackb2d3d6fd4e031785f278|WithRecovery $arg1
 * @return Claim
 */
function with_claim_callback(mixed $arg0, mixed $arg1): Claim {
    if (\func_num_args() !== 2) throw new \ArgumentCountError('with_claim_callback requires exactly 2 arguments');
    return Internal\Native::call(14, [$arg0, $arg1]);
}
