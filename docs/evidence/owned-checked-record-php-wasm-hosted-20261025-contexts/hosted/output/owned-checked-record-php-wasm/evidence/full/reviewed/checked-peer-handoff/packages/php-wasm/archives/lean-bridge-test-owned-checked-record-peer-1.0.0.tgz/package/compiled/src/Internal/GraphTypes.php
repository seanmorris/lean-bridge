<?php
declare(strict_types=1);
namespace LeanOwnedCheckedRecordsPeer\Internal;

final class GraphTypes
{
    public const NODES = [['kind' => 'option', 'element' => null, 'fields' => [[0, 1]], 'classes' => ['LeanOwnedCheckedRecordsPeer\\Some']], ['kind' => 'record', 'element' => null, 'fields' => [['holder', 2], ['quota', 3]], 'classes' => ['LeanOwnedCheckedRecordsPeer\\Claim']], ['kind' => 'resource', 'element' => null, 'fields' => [], 'classes' => ['LeanOwnedCheckedRecordsPeer\\Ticket']], ['kind' => 'primitive', 'name' => 'nat', 'host' => 'bigint', 'min' => '0', 'max' => null], ['kind' => 'primitive', 'name' => 'string']];
    public const CLASSES = ['LeanOwnedCheckedRecordsPeer\\Claim' => ['fields' => [['holder', 2], ['quota', 3]]], 'LeanOwnedCheckedRecordsPeer\\Some' => ['fields' => [['value', null]]], 'LeanOwnedCheckedRecordsPeer\\Ok' => ['fields' => [['value', null]]], 'LeanOwnedCheckedRecordsPeer\\Err' => ['fields' => [['value', null]]]];
    public const IDENTITIES = ['LeanOwnedCheckedRecordsPeer\\Ticket' => 2];
}
