#pragma once
#include <lean/lean.h>
#include <stdint.h>
/* Private typed helpers consume their Array arguments and return an owned Array. */
uint32_t lean_bridge_owned_2118e88a898883d1cf45a515_t160ce821a84f6887bbfd_branch(lean_object *);
lean_object * lean_bridge_owned_2118e88a898883d1cf45a515_t160ce821a84f6887bbfd_none(lean_object *);
lean_object * lean_bridge_owned_2118e88a898883d1cf45a515_t160ce821a84f6887bbfd_make0(lean_object *);
lean_object * lean_bridge_owned_2118e88a898883d1cf45a515_t160ce821a84f6887bbfd_field0(lean_object *);
lean_object * lean_bridge_owned_2118e88a898883d1cf45a515_tb2825946e038e653bd2b_make(lean_object *, lean_object *);
lean_object * lean_bridge_owned_2118e88a898883d1cf45a515_tb2825946e038e653bd2b_field0(lean_object *);
lean_object * lean_bridge_owned_2118e88a898883d1cf45a515_tb2825946e038e653bd2b_field1(lean_object *);
lean_object * lean_bridge_owned_2118e88a898883d1cf45a515_f483485736ace9af57086(lean_object *);
lean_object * lean_bridge_owned_2118e88a898883d1cf45a515_fa1e5189bd92568e4b939(lean_object *, lean_object *);
lean_object * lean_bridge_owned_2118e88a898883d1cf45a515_fec926afda994fba3abe2(lean_object *);

LEAN_CASSERT(sizeof(void *) == 4 && sizeof(size_t) == 4);
