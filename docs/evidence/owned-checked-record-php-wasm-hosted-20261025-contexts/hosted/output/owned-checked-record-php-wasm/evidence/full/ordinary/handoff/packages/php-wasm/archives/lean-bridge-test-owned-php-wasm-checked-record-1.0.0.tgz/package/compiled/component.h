#pragma once
#include <lean/lean.h>
#include <stdint.h>
/* Private typed helpers consume their Array arguments and return an owned Array. */
uint8_t lean_bridge_owned_refine_5ba8ebacbf26c0755e45(lean_object *);
uint8_t lean_bridge_owned_refine_ca177b2570793a278657(lean_object *);
uint8_t lean_bridge_owned_refine_be1666fcf441d2cede51(lean_object *);
uint8_t lean_bridge_owned_refine_5593f0b9830f059702a4(lean_object *);
lean_object * lean_bridge_owned_e9dae6f4ae921f12f19dde52_tf790309465bbf573c7b9_make(lean_object *);
lean_object * lean_bridge_owned_e9dae6f4ae921f12f19dde52_tf790309465bbf573c7b9_items(lean_object *);
lean_object * lean_bridge_owned_e9dae6f4ae921f12f19dde52_tf790309465bbf573c7b9_itemsBounded(lean_object *, lean_object *);
uint32_t lean_bridge_owned_e9dae6f4ae921f12f19dde52_t160ce821a84f6887bbfd_branch(lean_object *);
lean_object * lean_bridge_owned_e9dae6f4ae921f12f19dde52_t160ce821a84f6887bbfd_none(lean_object *);
lean_object * lean_bridge_owned_e9dae6f4ae921f12f19dde52_t160ce821a84f6887bbfd_make0(lean_object *);
lean_object * lean_bridge_owned_e9dae6f4ae921f12f19dde52_t160ce821a84f6887bbfd_field0(lean_object *);
lean_object * lean_bridge_owned_e9dae6f4ae921f12f19dde52_t648974cffb2d6c1d7951_apply(lean_object *, lean_object *);
lean_object * lean_bridge_owned_e9dae6f4ae921f12f19dde52_t5035e6ea0903f12776d9_apply(lean_object *, lean_object *);
lean_object * lean_bridge_owned_e9dae6f4ae921f12f19dde52_t23107461f72b24c37654_make(lean_object *, lean_object *);
lean_object * lean_bridge_owned_e9dae6f4ae921f12f19dde52_t23107461f72b24c37654_field0(lean_object *);
lean_object * lean_bridge_owned_e9dae6f4ae921f12f19dde52_t23107461f72b24c37654_field1(lean_object *);
lean_object * lean_bridge_owned_e9dae6f4ae921f12f19dde52_tb2825946e038e653bd2b_make(lean_object *, lean_object *);
lean_object * lean_bridge_owned_e9dae6f4ae921f12f19dde52_tb2825946e038e653bd2b_field0(lean_object *);
lean_object * lean_bridge_owned_e9dae6f4ae921f12f19dde52_tb2825946e038e653bd2b_field1(lean_object *);
lean_object * lean_bridge_owned_e9dae6f4ae921f12f19dde52_t4ce841c87ea3b1559bfb_make(lean_object *, lean_object *, lean_object *);
lean_object * lean_bridge_owned_e9dae6f4ae921f12f19dde52_t4ce841c87ea3b1559bfb_field0(lean_object *);
lean_object * lean_bridge_owned_e9dae6f4ae921f12f19dde52_t4ce841c87ea3b1559bfb_field1(lean_object *);
lean_object * lean_bridge_owned_e9dae6f4ae921f12f19dde52_t4ce841c87ea3b1559bfb_field2(lean_object *);
lean_object * lean_bridge_owned_e9dae6f4ae921f12f19dde52_t2a091437b2d587ce3891_make(lean_object *, lean_object *);
lean_object * lean_bridge_owned_e9dae6f4ae921f12f19dde52_t2a091437b2d587ce3891_field0(lean_object *);
lean_object * lean_bridge_owned_e9dae6f4ae921f12f19dde52_t2a091437b2d587ce3891_field1(lean_object *);
lean_object * lean_bridge_owned_e9dae6f4ae921f12f19dde52_f61fa6d001212787ff6aa(lean_object *);
lean_object * lean_bridge_owned_e9dae6f4ae921f12f19dde52_fa3218a29f42862f9b113(lean_object *);
lean_object * lean_bridge_owned_e9dae6f4ae921f12f19dde52_f483485736ace9af57086(lean_object *);
lean_object * lean_bridge_owned_e9dae6f4ae921f12f19dde52_f2f69e4eb3cbfdff310da(lean_object *);
lean_object * lean_bridge_owned_e9dae6f4ae921f12f19dde52_f0711e856cfa97d876c9a(lean_object *);
lean_object * lean_bridge_owned_e9dae6f4ae921f12f19dde52_f535babcfd8d0f67ea0e6(lean_object *);
lean_object * lean_bridge_owned_e9dae6f4ae921f12f19dde52_f25326d75f45c4daa9d9d(lean_object *);
lean_object * lean_bridge_owned_e9dae6f4ae921f12f19dde52_feb082cf837ef02082ea8(lean_object *);
lean_object * lean_bridge_owned_e9dae6f4ae921f12f19dde52_fa1e5189bd92568e4b939(lean_object *, lean_object *);
lean_object * lean_bridge_owned_e9dae6f4ae921f12f19dde52_feaac3cc8d9197bd7bbca(lean_object *, lean_object *);
lean_object * lean_bridge_owned_e9dae6f4ae921f12f19dde52_fec926afda994fba3abe2(lean_object *);
lean_object * lean_bridge_owned_e9dae6f4ae921f12f19dde52_f040aca3025d850fc12cc(lean_object *);
lean_object * lean_bridge_owned_e9dae6f4ae921f12f19dde52_fc4cffe83b4b420b09021(lean_object *, lean_object *);
lean_object * lean_bridge_owned_e9dae6f4ae921f12f19dde52_f33442f0a4409864e6a4a(lean_object *, lean_object *);
lean_object * lean_bridge_owned_e9dae6f4ae921f12f19dde52_f7d6c8617a0788c12de15(lean_object *, lean_object *);
int lean_bridge_owned_callback_failure_fffd3c0b7fe83a2be231(void);
lean_object *lean_bridge_owned_e9dae6f4ae921f12f19dde52_t648974cffb2d6c1d7951_wrap(size_t, size_t, lean_object *);
lean_object *lean_bridge_owned_e9dae6f4ae921f12f19dde52_t648974cffb2d6c1d7951_invoke(size_t, lean_object *);
lean_object *lean_bridge_owned_e9dae6f4ae921f12f19dde52_t5035e6ea0903f12776d9_wrap(size_t, size_t, lean_object *);
lean_object *lean_bridge_owned_e9dae6f4ae921f12f19dde52_t5035e6ea0903f12776d9_invoke(size_t, lean_object *);
lean_object *lean_bridge_owned_e9dae6f4ae921f12f19dde52_t5035e6ea0903f12776d9_reject(size_t, lean_object *);

LEAN_CASSERT(sizeof(void *) == 4 && sizeof(size_t) == 4);
