<?php
declare(strict_types=1);

// Composer autoloaders take precedence when an application supplies Brick Math.
spl_autoload_register(static function (string $class): void {
    $prefix = 'Brick\\Math\\';
    if (!str_starts_with($class, $prefix)) return;
    $suffix = substr($class, strlen($prefix));
    if (preg_match('/^[A-Za-z_][A-Za-z0-9_]*(?:\\\\[A-Za-z_][A-Za-z0-9_]*)*$/D', $suffix) !== 1) return;
    $path = __DIR__ . '/src/' . str_replace('\\', '/', $suffix) . '.php';
    if (is_file($path)) require $path;
});
