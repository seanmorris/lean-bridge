import { createPhpWasmCopiedDescriptor } from './host.mjs';
const runtime = Object.freeze({"identity":"fbc32dc75641fc5d381ab6bddd05671cb59cad725d631e433cda14469ae1f25a","loaderIdentity":"a01f27ff8abc302e781ded2cad03992af20457e406e5ee58b47e101db107cfeb","library":"liblean_bridge_php_wasm_copied_488de83b725bba40a9b4.so"});
export const createDescriptor = (component, assets) => createPhpWasmCopiedDescriptor({ ...runtime, url: new URL("./compiled/lib/liblean_bridge_php_wasm_copied_488de83b725bba40a9b4.so", import.meta.url) }, component, assets);
