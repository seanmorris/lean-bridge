#include <lean/lean.h>
#include <stdint.h>
LEAN_CASSERT(sizeof(size_t) * 8 == 64);
lean_object * lb_337ad8b506609c627ee6d942(lean_object * a0, lean_object * a1);
lean_object * lb_7d6a59e9b078774c88a366b9(lean_object * a0);
lean_object * lb_3f29217177283a28652ede82(lean_object * a0);
lean_object * lb_958cea34558d0f9a88e5cde7(lean_object * a0);
lean_object * lb_b7af959703ba78059d2cb887(lean_object * a0);
lean_object * lb_c342fc10fdf5bdc8d2f1fad7(lean_object * a0);
lean_object * lb_1ff77873a26f0ee6a603e213(lean_object * a0);
lean_object * lb_t482d86bbb5f392755b83_call(lean_object * closure, lean_object * value0);
lean_object * lb_t482d86bbb5f392755b83_wrap(size_t token);
lean_object * lb_tb5dadeab68a29cbe5033_call(lean_object * closure, lean_object * value0);
lean_object * lb_t07ff56848fc3a3cd3550_call(lean_object * closure, lean_object * value0);
lean_object * lb_t23281a6412f09bc1e5f2_make(lean_object * a0, lean_object * a1);
lean_object * lb_t23281a6412f09bc1e5f2_get0(lean_object * value);
lean_object * lb_t23281a6412f09bc1e5f2_get1(lean_object * value);
lean_object * lb_ta5ff4054fc80e0ed5ecb_call(lean_object * closure, lean_object * value0);
lean_object * lb_ta5ff4054fc80e0ed5ecb_wrap(size_t token);
lean_object * lb_t78cb4d5802be9606854f_from_array(lean_object * value);
lean_object * lb_t78cb4d5802be9606854f_to_array(lean_object * value);
lean_object * lb_ta870c894c6b2db52a3db_call(lean_object * closure, lean_object * value0);
lean_object * lb_native_nat_text(lean_object * value);
lean_object * lb_native_int_text(lean_object * value);
lean_object * lb_native_int_parse(lean_object * value);
