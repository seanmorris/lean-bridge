package LeanBridge::ReviewedCallbacks;
use strict;
use warnings;
use Math::BigInt;
use LeanBridge::Runtime;
die "Incompatible shared Lean runtime package version\n" unless $LeanBridge::Runtime::VERSION eq '0.0020830698749344517611910823833712994369461971843978721904118190786391765830158151';
use XSLoader;
our $VERSION = '1.000';
LeanBridge::Runtime::_load_component(__FILE__, 'libcomponent_99d469b3ee044240ea23.so', '547cc110fd5ae63ca2d6a1885dc7e629e794286703a5a8191851ad419c5855a5', '6f4dbd1e2e112f4678734553d1c9bb8722fad3e6290adbff1ac46d05e5eff7dd', { 'ReviewedCallbacks' => '86bf340d6072fc538e1c020b24194cea0a668f8839c58fe141c4fd722c07a1cd' }, 'reviewedcallbacks@1.0.0');
XSLoader::load(__PACKAGE__, $VERSION);
sub true () { !!1 }
sub false () { !!0 }
sub CLONE_SKIP { 1 }

package LeanBridge::ReviewedCallbacks::Runtime::Callback;
sub new {
  die "LeanBridge::ReviewedCallbacks::Runtime::Callback->new expects code and recovery\n" unless @_ == 5 && defined($_[0]) && !ref($_[0]) && $_[0] eq 'LeanBridge::ReviewedCallbacks::Runtime::Callback';
  shift; my %fields = @_;
  die "expected code and recovery fields\n" unless keys(%fields) == 2 && exists($fields{code}) && exists($fields{recovery});
  die "expected an unblessed CODE reference\n" unless ref($fields{code}) eq "CODE";
  return bless \%fields, 'LeanBridge::ReviewedCallbacks::Runtime::Callback';
}
sub CLONE_SKIP { 1 }

package LeanBridge::ReviewedCallbacks::Closure482d86bbb5f392755b83;
our @ISA = ('LeanBridge::Runtime::Resource');
sub CLONE_SKIP { 1 }
package LeanBridge::ReviewedCallbacks::Closureb5dadeab68a29cbe5033;
our @ISA = ('LeanBridge::Runtime::Resource');
sub CLONE_SKIP { 1 }
package LeanBridge::ReviewedCallbacks::Closure07ff56848fc3a3cd3550;
our @ISA = ('LeanBridge::Runtime::Resource');
sub CLONE_SKIP { 1 }
package LeanBridge::ReviewedCallbacks::Tile;
sub new {
  die "LeanBridge::ReviewedCallbacks::Tile->new expects named fields\n" unless @_ % 2 == 1 && $_[0] eq 'LeanBridge::ReviewedCallbacks::Tile';
  shift; my %fields;
  while (@_) {
    my ($key, $value) = splice @_, 0, 2;
    die "invalid record field\n" if !defined($key) || ref($key);
    $fields{$key} = $value;
  }
  my @required = qw(digit count);
  die "record fields do not match the generated schema\n" if keys(%fields) != @required || grep { !exists $fields{$_} } @required;
  return bless \%fields, 'LeanBridge::ReviewedCallbacks::Tile';
}
sub digit { $_[0]->{digit} }
sub count { $_[0]->{count} }
package LeanBridge::ReviewedCallbacks::Closurea5ff4054fc80e0ed5ecb;
our @ISA = ('LeanBridge::Runtime::Resource');
sub CLONE_SKIP { 1 }
package LeanBridge::ReviewedCallbacks::Closurea870c894c6b2db52a3db;
our @ISA = ('LeanBridge::Runtime::Resource');
sub CLONE_SKIP { 1 }
1;

__END__
=head1 NAME

LeanBridge::ReviewedCallbacks - Generated functions from reviewedcallbacks

=head1 API

=head2 apply

Calls C<ReviewedCallbacks.apply> in the compiled Lean component.

=head2 counter

Calls C<ReviewedCallbacks.counter> in the compiled Lean component.

Checked Lean Fin bounds: result.result < 10.

=head2 digits

Calls C<ReviewedCallbacks.digits> in the compiled Lean component.

Checked Lean Fin bounds: result.arg0[*] < 3.

=head2 scaler

Calls C<ReviewedCallbacks.scaler> in the compiled Lean component.

Checked Lean Fin bounds: result.arg0 < 10.

=head2 tile_maker

Calls C<ReviewedCallbacks.tileMaker> in the compiled Lean component.

Checked Lean Fin bounds: result.result.digit < 5.

=head2 tiles

Calls C<ReviewedCallbacks.tiles> in the compiled Lean component.

Checked Lean Fin bounds: result.arg0[*].digit < 5.

=head2 visit

Calls C<ReviewedCallbacks.visit> in the compiled Lean component.

Checked Lean Fin bounds: arg0.arg0 < 5.

=head1 LISTS

Lean List inputs, results and record fields use copied plain array references. Calls reject blessed, tied and sparse arrays. Empty Lists, order, duplicates and nesting are preserved. Slots are pinned before element conversion can invoke Perl code. Returned arrays and mutable payloads own independent storage. List and Array retain distinct IR/native identities. Typed Lean helpers perform List conversion without inspecting cons-cell layouts. The shared per-call copied-value limit is 16 MiB; List callback arguments and results use independent plain array references.

=head1 ARRAYS AND RECORDS

Lean Array values use plain dense array references. Calls reject blessed, tied and sparse arrays. Copied records use generated classes with named fields and accessors. Record keyword arguments keep Perl's last-value-wins hash semantics, including new(%old_fields, field => $replacement). Constructors reject missing, extra or unnamed fields; calls require the exact generated class and reject tied hashes and subclasses. Empty records and one-field records retain their named types.

Array slots and record fields are pinned before conversion can invoke Perl code. Returned arrays, records, octet strings and Math::BigInt payloads own independent copied storage. Reference equality is not deep value equality. Nested copied values share a 16 MiB conversion budget and a 32-level schema limit; these are not limits on all Perl allocations or Lean working memory. Recursive copied types remain unsupported.

=head1 STRUCTURED CALLBACKS

Synchronous callbacks accept and return acyclic copied arrays, Lists, options, results, products, records, variants and aliases. Use the same generated classes and plain containers as ordinary arguments and results. Callback arguments, results and returned Lean closure captures own independent copied storage.

Pass unrefined host callbacks as CODE references. A checked host callback requires LeanBridge::ReviewedCallbacks::Runtime::Callback->new(code => $callback, recovery => $value); the generated adapter validates and copies the typed recovery before Lean or the callback runs. Lean may not retain them after the exported call returns. Returned Lean closures provide call, close and closed; close each closure when finished. Original Perl exception objects are rethrown after native cleanup. Closing a closure during argument conversion does not invalidate the borrow held by its active call.

Copied-value conversion uses the existing 16 MiB scope budget and 32-level schema bound. Recursive callback payloads, resource-containing aggregates and asynchronous callbacks remain unsupported.

=head1 BOUNDED INTEGERS

Lean C<Fin n> parameters and results are L<Math::BigInt> values below C<n>. Each argument is compared with its exact bound, including bounds wider than 64 bits, before the guarded adapter or the exported function runs. A value that is not a Math::BigInt, or a negative one, is rejected as for Nat; a value at or above its bound dies with a message naming the Lean parameter and bound. C<Fin 0> has no values, so every call to a function taking one dies. Results are Math::BigInt values below their declared bound. Inside arrays, Lists and options every present element is checked the same way before the guarded adapter or the exported function runs, so a C<Fin 0> element is rejected while an empty array or an undefined option is accepted; each checked path is listed as C<arg0[*]? < n> at its function, and a rejection names the failing element's own path and bound, such as C<arg0[2]? is not below its Fin 10 bound>. Generic record instantiations remain unsupported. Synchronous host callbacks and returned Lean closures apply the same checks at their documented argument and result paths.

=head1 OWNERSHIP

Close resource and closure objects when finished. Host callbacks are synchronous and may not be retained by Lean.

=cut
