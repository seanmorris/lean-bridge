import ReviewedCallbacks

namespace LeanBridgeNative99d469b3ee044240

structure LbErased.ReviewedCallbacks.Tile where
  «digit» : _root_.Nat
  «count» : _root_.Nat

def LbErased.ReviewedCallbacks.Tile.check (value : LbErased.ReviewedCallbacks.Tile) : _root_.Option _root_.ReviewedCallbacks.Tile := do
  let a0 ← (if proof : (value.«digit») < 5 then _root_.Option.some (⟨(value.«digit»), proof⟩ : _root_.Fin 5) else _root_.Option.none)
  let a1 ← (_root_.Option.some (value.«count»))
  pure (_root_.ReviewedCallbacks.Tile.mk a0 a1)

def LbErased.ReviewedCallbacks.Tile.erase (value : _root_.ReviewedCallbacks.Tile) : LbErased.ReviewedCallbacks.Tile :=
  LbErased.ReviewedCallbacks.Tile.mk (value.«digit»).val (value.«count»)

structure ClosureCarry482d86bbb5f392755b83 where
  value : (_root_.Nat → _root_.Nat)

structure ClosureCarryb5dadeab68a29cbe5033 where
  value : ((_root_.Array _root_.Nat) → (_root_.Option _root_.Nat))

structure ClosureCarry07ff56848fc3a3cd3550 where
  value : (_root_.Nat → (_root_.Option _root_.Nat))

structure ClosureCarrya5ff4054fc80e0ed5ecb where
  value : (_root_.Nat → LbErased.ReviewedCallbacks.Tile)

structure ClosureCarrya870c894c6b2db52a3db where
  value : ((_root_.List LbErased.ReviewedCallbacks.Tile) → (_root_.Option _root_.Nat))

@[export lb_337ad8b506609c627ee6d942]
def f_lb_337ad8b506609c627ee6d942 (a0 : (_root_.Nat → _root_.Nat)) (a1 : _root_.Nat) : _root_.Nat :=
  _root_.ReviewedCallbacks.apply a0 a1

@[export lb_7d6a59e9b078774c88a366b9]
def f_lb_7d6a59e9b078774c88a366b9 (a0 : _root_.Nat) : ClosureCarry482d86bbb5f392755b83 :=
  ⟨(let _bridgeClosure := _root_.ReviewedCallbacks.counter a0; fun _bridgeArg0 =>
    ((_bridgeClosure) _bridgeArg0).val)⟩

@[export lb_3f29217177283a28652ede82]
def f_lb_3f29217177283a28652ede82 (a0 : _root_.Unit) : ClosureCarryb5dadeab68a29cbe5033 :=
  ⟨(let _bridgeClosure := _root_.ReviewedCallbacks.digits a0; fun _bridgeArg0 =>
    match ((_bridgeArg0).mapM (fun _bridgeValue0 => (if proof : (_bridgeValue0) < 3 then _root_.Option.some (⟨(_bridgeValue0), proof⟩ : _root_.Fin 3) else _root_.Option.none))) with
    | .some _bridgeSubtype0 =>
      _root_.Option.some ((_bridgeClosure) _bridgeSubtype0)
    | .none =>
      _root_.Option.none)⟩

@[export lb_958cea34558d0f9a88e5cde7]
def f_lb_958cea34558d0f9a88e5cde7 (a0 : _root_.Nat) : ClosureCarry07ff56848fc3a3cd3550 :=
  ⟨(let _bridgeClosure := _root_.ReviewedCallbacks.scaler a0; fun _bridgeArg0 =>
    if _bridgeFin0 : (_bridgeArg0) < 10 then
      _root_.Option.some ((_bridgeClosure) ⟨_bridgeArg0, _bridgeFin0⟩)
    else
      _root_.Option.none)⟩

@[export lb_b7af959703ba78059d2cb887]
def f_lb_b7af959703ba78059d2cb887 (a0 : _root_.Nat) : ClosureCarrya5ff4054fc80e0ed5ecb :=
  ⟨(let _bridgeClosure := _root_.ReviewedCallbacks.tileMaker a0; fun _bridgeArg0 =>
    (let _bridgeResult := (_bridgeClosure) _bridgeArg0; (LbErased.ReviewedCallbacks.Tile.erase (_bridgeResult))))⟩

@[export lb_c342fc10fdf5bdc8d2f1fad7]
def f_lb_c342fc10fdf5bdc8d2f1fad7 (a0 : _root_.Unit) : ClosureCarrya870c894c6b2db52a3db :=
  ⟨(let _bridgeClosure := _root_.ReviewedCallbacks.tiles a0; fun _bridgeArg0 =>
    match ((_bridgeArg0).mapM (fun _bridgeValue0 => (LbErased.ReviewedCallbacks.Tile.check (_bridgeValue0)))) with
    | .some _bridgeSubtype0 =>
      _root_.Option.some ((_bridgeClosure) _bridgeSubtype0)
    | .none =>
      _root_.Option.none)⟩

@[export lb_1ff77873a26f0ee6a603e213]
def f_lb_1ff77873a26f0ee6a603e213 (a0 : (_root_.Nat → _root_.Nat)) : _root_.Nat :=
  _root_.ReviewedCallbacks.visit (fun _bridgeArg0 => a0 (_bridgeArg0).val)

@[export lb_t482d86bbb5f392755b83_call]
def f_lb_t482d86bbb5f392755b83_call (closure : (_root_.Nat → _root_.Nat)) (value0 : _root_.Nat) : _root_.Nat :=
  closure value0

@[extern "lb_t482d86bbb5f392755b83_invoke"]
opaque invoke_482d86bbb5f392755b83 (token : _root_.USize) (value0 : _root_.Nat) : _root_.Nat := 0

@[export lb_t482d86bbb5f392755b83_wrap]
def wrap_482d86bbb5f392755b83 (token : _root_.USize) : ClosureCarry482d86bbb5f392755b83 := ⟨fun value0 => invoke_482d86bbb5f392755b83 token value0⟩

@[export lb_tb5dadeab68a29cbe5033_call]
def f_lb_tb5dadeab68a29cbe5033_call (closure : ((_root_.Array _root_.Nat) → (_root_.Option _root_.Nat))) (value0 : (_root_.Array _root_.Nat)) : (_root_.Option _root_.Nat) :=
  closure value0

@[export lb_t07ff56848fc3a3cd3550_call]
def f_lb_t07ff56848fc3a3cd3550_call (closure : (_root_.Nat → (_root_.Option _root_.Nat))) (value0 : _root_.Nat) : (_root_.Option _root_.Nat) :=
  closure value0

@[export lb_t23281a6412f09bc1e5f2_make]
def f_lb_t23281a6412f09bc1e5f2_make (a0 : _root_.Nat) (a1 : _root_.Nat) : LbErased.ReviewedCallbacks.Tile :=
  LbErased.ReviewedCallbacks.Tile.mk a0 a1

@[export lb_t23281a6412f09bc1e5f2_get0]
def f_lb_t23281a6412f09bc1e5f2_get0 (value : LbErased.ReviewedCallbacks.Tile) : _root_.Nat :=
  value.«digit»

@[export lb_t23281a6412f09bc1e5f2_get1]
def f_lb_t23281a6412f09bc1e5f2_get1 (value : LbErased.ReviewedCallbacks.Tile) : _root_.Nat :=
  value.«count»

@[export lb_ta5ff4054fc80e0ed5ecb_call]
def f_lb_ta5ff4054fc80e0ed5ecb_call (closure : (_root_.Nat → LbErased.ReviewedCallbacks.Tile)) (value0 : _root_.Nat) : LbErased.ReviewedCallbacks.Tile :=
  closure value0

@[extern "lb_ta5ff4054fc80e0ed5ecb_invoke"]
opaque invoke_a5ff4054fc80e0ed5ecb (token : _root_.USize) (value0 : _root_.Nat) : LbErased.ReviewedCallbacks.Tile := (LbErased.ReviewedCallbacks.Tile.mk 0 0)

@[export lb_ta5ff4054fc80e0ed5ecb_wrap]
def wrap_a5ff4054fc80e0ed5ecb (token : _root_.USize) : ClosureCarrya5ff4054fc80e0ed5ecb := ⟨fun value0 => invoke_a5ff4054fc80e0ed5ecb token value0⟩

@[export lb_t78cb4d5802be9606854f_from_array]
def f_lb_t78cb4d5802be9606854f_from_array (value : (_root_.Array LbErased.ReviewedCallbacks.Tile)) : (_root_.List LbErased.ReviewedCallbacks.Tile) :=
  value.toList

@[export lb_t78cb4d5802be9606854f_to_array]
def f_lb_t78cb4d5802be9606854f_to_array (value : (_root_.List LbErased.ReviewedCallbacks.Tile)) : (_root_.Array LbErased.ReviewedCallbacks.Tile) :=
  let rec loop : _root_.Nat → (_root_.List LbErased.ReviewedCallbacks.Tile) → (_root_.Array LbErased.ReviewedCallbacks.Tile) → (_root_.Array LbErased.ReviewedCallbacks.Tile)
    | 0, _, acc => acc
    | _, [], acc => acc
    | fuel + 1, head :: tail, acc => loop fuel tail (acc.push head)
  loop 2097153 value #[]

@[export lb_ta870c894c6b2db52a3db_call]
def f_lb_ta870c894c6b2db52a3db_call (closure : ((_root_.List LbErased.ReviewedCallbacks.Tile) → (_root_.Option _root_.Nat))) (value0 : (_root_.List LbErased.ReviewedCallbacks.Tile)) : (_root_.Option _root_.Nat) :=
  closure value0

@[export lb_native_nat_text]
def f_lb_native_nat_text (value : _root_.Nat) : _root_.String :=
  _root_.Nat.repr value

@[export lb_native_int_text]
def f_lb_native_int_text (value : _root_.Int) : _root_.String :=
  _root_.Int.repr value

@[export lb_native_int_parse]
def f_lb_native_int_parse (value : _root_.String) : _root_.Int :=
  _root_.String.toInt! value

end LeanBridgeNative99d469b3ee044240
