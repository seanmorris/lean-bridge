#include "runtime.h"
#include "component.h"
static void lbp_component_ready(pTHX) {
  if (!lean_bridge_native_component_ready("reviewedcallbacks@1.0.0:547cc110fd5ae63ca2d6a1885dc7e629e794286703a5a8191851ad419c5855a5")) croak("Lean runtime is not ready or has been retired");
}

typedef struct { lean_object * argument0; lean_object * result; int returned; } lb_callback_frame_482d86bbb5f392755b83;
static lean_object * lb_callback_482d86bbb5f392755b83(void *context, lean_object * argument0);
typedef struct { lean_object * argument0; lean_object * result; int returned; } lb_callback_frame_b5dadeab68a29cbe5033;
static lean_object * lb_callback_b5dadeab68a29cbe5033(void *context, lean_object * argument0);
typedef struct { lean_object * argument0; lean_object * result; int returned; } lb_callback_frame_07ff56848fc3a3cd3550;
static lean_object * lb_callback_07ff56848fc3a3cd3550(void *context, lean_object * argument0);
typedef struct { lean_object * argument0; lean_object * result; int returned; } lb_callback_frame_a5ff4054fc80e0ed5ecb;
static lean_object * lb_callback_a5ff4054fc80e0ed5ecb(void *context, lean_object * argument0);
typedef struct { lean_object * argument0; lean_object * result; int returned; } lb_callback_frame_a870c894c6b2db52a3db;
static lean_object * lb_callback_a870c894c6b2db52a3db(void *context, lean_object * argument0);
typedef struct lb_callback_recovery_482d86bbb5f392755b83 {
  lbp_callback *callback;
  lean_object * value;
  struct lb_callback_recovery_482d86bbb5f392755b83 *next;
} lb_callback_recovery_482d86bbb5f392755b83;
static _Thread_local lb_callback_recovery_482d86bbb5f392755b83 *lb_callback_recovery_482d86bbb5f392755b83_head;
static void lb_callback_recovery_482d86bbb5f392755b83_drop(pTHX_ void *data) {
  lb_callback_recovery_482d86bbb5f392755b83 *item = data, **cursor = &lb_callback_recovery_482d86bbb5f392755b83_head;
  while (*cursor && *cursor != item) cursor = &(*cursor)->next;
  if (*cursor == item) *cursor = item->next;
  Safefree(item);
}
static void lb_callback_recovery_482d86bbb5f392755b83_install(pTHX_ uint64_t token, lean_object * value) {
  lb_native_callback native = lb_native_callback_lookup(token);
  if (!native.context) croak("registered callback recovery has no native context");
  lb_callback_recovery_482d86bbb5f392755b83 *item; Newxz(item, 1, lb_callback_recovery_482d86bbb5f392755b83);
  item->callback = (lbp_callback *)native.context; item->value = value;
  item->next = lb_callback_recovery_482d86bbb5f392755b83_head; lb_callback_recovery_482d86bbb5f392755b83_head = item;
  SAVEDESTRUCTOR_X(lb_callback_recovery_482d86bbb5f392755b83_drop, item);
}
static lean_object * lb_callback_recovery_482d86bbb5f392755b83_get(lbp_callback *callback) {
  for (lb_callback_recovery_482d86bbb5f392755b83 *item = lb_callback_recovery_482d86bbb5f392755b83_head; item; item = item->next) if (item->callback == callback) {
    lean_inc(item->value);
    return item->value;
  }
  return lean_box(0);
}
static lean_object * lb_read_bcb803bc837008bec599(pTHX_ lbp_scope *scope, SV *value) {

    SV *text = lbp_bigint_text(aTHX_ value, 1);
    STRLEN length; const char *bytes = SvPV(text, length); lbp_budget(scope, length);
    return lbp_keep(scope, lean_cstr_to_nat(bytes));
}
static SV *lb_write_bcb803bc837008bec599(pTHX_ lbp_scope *scope, lean_object * value) {

    lean_inc(value); lean_object *text = lbp_keep(scope, lb_native_nat_text(value));
    size_t length = lean_string_size(text) - 1; lbp_budget(scope, length);
    return lbp_bigint_from_text(aTHX_ lean_string_cstr(text), length);
}

static lean_object * lb_read_482d86bbb5f392755b83(pTHX_ lbp_scope *scope, SV *value) {

	      SvGETMAGIC(value);
	      if (lbp_is_branch(value, "LeanBridge::ReviewedCallbacks::Runtime::Callback")) {
	        HV *descriptor = (HV *)sv_2mortal(SvREFCNT_inc(SvRV(value)));
	        if (HvUSEDKEYS(descriptor) != 2) croak("callback descriptor requires exactly code and recovery fields");
	        /* Pin both fields before recovery conversion can invoke Perl code. */
	        SV *code = lbp_field(aTHX_ descriptor, "code", 4);
	        SV *recovery_value = lbp_field(aTHX_ descriptor, "recovery", 8);
	        if (!SvROK(code) || SvTYPE(SvRV(code)) != SVt_PVCV || SvOBJECT(SvRV(code))) croak("callback descriptor code requires an unblessed CODE reference");
	        lean_object * recovery = lb_read_bcb803bc837008bec599(aTHX_ scope, recovery_value);
	        uint64_t token = lbp_callback_new(aTHX_ scope, code, get_cv("LeanBridge::ReviewedCallbacks::_callback_482d86bbb5f392755b83", 0), (void (*)(void))lb_callback_482d86bbb5f392755b83);
	        lb_callback_recovery_482d86bbb5f392755b83_install(aTHX_ token, recovery);
	        return lbp_keep(scope, lb_t482d86bbb5f392755b83_wrap(token));
	      }
	      if (SvROK(value) && SvTYPE(SvRV(value)) == SVt_PVCV) {
	        uint64_t token = lbp_callback_new(aTHX_ scope, value, get_cv("LeanBridge::ReviewedCallbacks::_callback_482d86bbb5f392755b83", 0), (void (*)(void))lb_callback_482d86bbb5f392755b83);
	        return lbp_keep(scope, lb_t482d86bbb5f392755b83_wrap(token));
	      }
	      return lbp_borrow(aTHX_ scope, value, "callback:482d86bbb5f392755b83");
}
static SV *lb_write_482d86bbb5f392755b83(pTHX_ lbp_scope *scope, lean_object * value) {
return lbp_resource(aTHX_ value, "callback:482d86bbb5f392755b83", "LeanBridge::ReviewedCallbacks::Closure482d86bbb5f392755b83");
}
static lean_object * lb_read_482d86bbb5f392755b83_recovered(pTHX_ lbp_scope *scope, SV *value) {
	  SvGETMAGIC(value);
	  if (!lbp_is_branch(value, "LeanBridge::ReviewedCallbacks::Runtime::Callback"))
	    croak("checked callback requires LeanBridge::ReviewedCallbacks::Runtime::Callback->new(code => ..., recovery => ...)");
	  return lb_read_482d86bbb5f392755b83(aTHX_ scope, value);
	}

static lean_object * lb_read_c6349afd7d22f2e92812(pTHX_ lbp_scope *scope, SV *value) {
lbp_plain(aTHX_ value); if (SvOK(value)) croak("Unit requires undef"); return lean_box(0);
}
static SV *lb_write_c6349afd7d22f2e92812(pTHX_ lbp_scope *scope, lean_object * value) {
return lbp_mortal(newSV(0));
}

static lean_object * lb_read_224517b0527dd01c7a6b(pTHX_ lbp_scope *scope, SV *value) {

      SvGETMAGIC(value);
      if (!SvROK(value) || SvTYPE(SvRV(value)) != SVt_PVAV || SvOBJECT(SvRV(value)) || (SvMAGICAL(SvRV(value)) && mg_find(SvRV(value), PERL_MAGIC_tied))) croak("Array requires a plain array reference");
      AV *array = (AV *)sv_2mortal(SvREFCNT_inc(SvRV(value))); size_t length = av_count(array);
      if (length > 16 * 1024 * 1024 / sizeof(void *)) croak("native copied array exceeds the 16 MiB per-call limit");
      lbp_budget(scope, length * sizeof(void *));
      /* Pin the sequence before an element converter can invoke Perl code. */
      AV *slots = (AV *)sv_2mortal((SV *)newAV());
      if (length) av_extend(slots, length - 1);
      for (size_t i = 0; i < length; ++i) {
        SV **entry = av_fetch(array, i, 0); if (!entry) croak("sparse Perl arrays are unsupported");
        av_push(slots, SvREFCNT_inc(*entry));
      }
      lean_object *result = lean_alloc_array(length, length);
      /* Registration can fail and release result; every slot must already be valid. */
      for (size_t i = 0; i < length; ++i) lean_array_set_core(result, i, lean_box(0));
      lbp_keep(scope, result);
      for (size_t i = 0; i < length; ++i) {
        SV **entry = av_fetch(slots, i, 0); if (!entry) croak("sparse Perl arrays are unsupported");
        lean_object * item = lb_read_bcb803bc837008bec599(aTHX_ scope, sv_2mortal(SvREFCNT_inc(*entry)));
        lean_array_set_core(result, i, (lean_inc(item), item));
      }
      return result;
}
static SV *lb_write_224517b0527dd01c7a6b(pTHX_ lbp_scope *scope, lean_object * value) {

      
      size_t length = lean_array_size(value);
      if (length > 16 * 1024 * 1024 / sizeof(void *)) croak("native copied array exceeds the 16 MiB per-call limit");
      lbp_budget(scope, length * sizeof(void *));
      AV *array = (AV *)sv_2mortal((SV *)newAV());
      for (size_t i = 0; i < length; ++i) {
        SV *item = lb_write_bcb803bc837008bec599(aTHX_ scope, lean_array_get_core(value, i));
        av_push(array, SvREFCNT_inc(item));
      }
      return lbp_mortal(newRV_inc((SV *)array));
}

static lean_object * lb_read_b5dadeab68a29cbe5033(pTHX_ lbp_scope *scope, SV *value) {
return lbp_borrow(aTHX_ scope, value, "callback:b5dadeab68a29cbe5033");
}
static SV *lb_write_b5dadeab68a29cbe5033(pTHX_ lbp_scope *scope, lean_object * value) {
return lbp_resource(aTHX_ value, "callback:b5dadeab68a29cbe5033", "LeanBridge::ReviewedCallbacks::Closureb5dadeab68a29cbe5033");
}

static lean_object * lb_read_07ff56848fc3a3cd3550(pTHX_ lbp_scope *scope, SV *value) {
return lbp_borrow(aTHX_ scope, value, "callback:07ff56848fc3a3cd3550");
}
static SV *lb_write_07ff56848fc3a3cd3550(pTHX_ lbp_scope *scope, lean_object * value) {
return lbp_resource(aTHX_ value, "callback:07ff56848fc3a3cd3550", "LeanBridge::ReviewedCallbacks::Closure07ff56848fc3a3cd3550");
}

static lean_object * lb_read_23281a6412f09bc1e5f2(pTHX_ lbp_scope *scope, SV *value) {

      SvGETMAGIC(value);
      if (!lbp_is_branch(value, "LeanBridge::ReviewedCallbacks::Tile")) croak("expected LeanBridge::ReviewedCallbacks::Tile with an exact class and plain untied hash");
      if (HvUSEDKEYS((HV *)SvRV(value)) != 2) croak("record fields do not match the generated schema");
      HV *input = (HV *)sv_2mortal(SvREFCNT_inc(SvRV(value)));
      lbp_budget(scope, 2 * sizeof(void *));
      /* Pin every field before a child converter can invoke Perl code. */
      SV *slot0 = lbp_field(aTHX_ input, "digit", 5);
      SV *slot1 = lbp_field(aTHX_ input, "count", 5);
      lean_object * a0 = lb_read_bcb803bc837008bec599(aTHX_ scope, slot0);
      lean_object * a1 = lb_read_bcb803bc837008bec599(aTHX_ scope, slot1);
      lean_inc(a0); lean_inc(a1);
      return lbp_keep(scope, lb_t23281a6412f09bc1e5f2_make(a0, a1));
}
static SV *lb_write_23281a6412f09bc1e5f2(pTHX_ lbp_scope *scope, lean_object * value) {

      lbp_budget(scope, 2 * sizeof(void *));
      HV *record = (HV *)sv_2mortal((SV *)newHV());
      lean_inc(value); lean_object * a0 = lb_t23281a6412f09bc1e5f2_get0(value);
      lbp_keep(scope, a0);
      hv_store(record, "digit", 5, SvREFCNT_inc(lb_write_bcb803bc837008bec599(aTHX_ scope, a0)), 0);
      lean_inc(value); lean_object * a1 = lb_t23281a6412f09bc1e5f2_get1(value);
      lbp_keep(scope, a1);
      hv_store(record, "count", 5, SvREFCNT_inc(lb_write_bcb803bc837008bec599(aTHX_ scope, a1)), 0);
      return sv_bless(lbp_mortal(newRV_inc((SV *)record)), gv_stashpv("LeanBridge::ReviewedCallbacks::Tile", GV_ADD));
}

static lean_object * lb_read_a5ff4054fc80e0ed5ecb(pTHX_ lbp_scope *scope, SV *value) {
return lbp_borrow(aTHX_ scope, value, "callback:a5ff4054fc80e0ed5ecb");
}
static SV *lb_write_a5ff4054fc80e0ed5ecb(pTHX_ lbp_scope *scope, lean_object * value) {
return lbp_resource(aTHX_ value, "callback:a5ff4054fc80e0ed5ecb", "LeanBridge::ReviewedCallbacks::Closurea5ff4054fc80e0ed5ecb");
}

static lean_object * lb_read_78cb4d5802be9606854f(pTHX_ lbp_scope *scope, SV *value) {

      SvGETMAGIC(value);
      if (!SvROK(value) || SvTYPE(SvRV(value)) != SVt_PVAV || SvOBJECT(SvRV(value)) || (SvMAGICAL(SvRV(value)) && mg_find(SvRV(value), PERL_MAGIC_tied))) croak("List requires a plain array reference");
      AV *array = (AV *)sv_2mortal(SvREFCNT_inc(SvRV(value))); size_t length = av_count(array);
      if (length > 16 * 1024 * 1024 / sizeof(void *)) croak("native copied array exceeds the 16 MiB per-call limit");
      lbp_budget(scope, length * sizeof(void *));
      /* Pin the sequence before an element converter can invoke Perl code. */
      AV *slots = (AV *)sv_2mortal((SV *)newAV());
      if (length) av_extend(slots, length - 1);
      for (size_t i = 0; i < length; ++i) {
        SV **entry = av_fetch(array, i, 0); if (!entry) croak("sparse Perl Lists are unsupported");
        av_push(slots, SvREFCNT_inc(*entry));
      }
      lean_object *result = lean_alloc_array(length, length);
      /* Registration can fail and release result; every slot must already be valid. */
      for (size_t i = 0; i < length; ++i) lean_array_set_core(result, i, lean_box(0));
      lbp_keep(scope, result);
      for (size_t i = 0; i < length; ++i) {
        SV **entry = av_fetch(slots, i, 0); if (!entry) croak("sparse Perl arrays are unsupported");
        lean_object * item = lb_read_23281a6412f09bc1e5f2(aTHX_ scope, sv_2mortal(SvREFCNT_inc(*entry)));
        lean_array_set_core(result, i, (lean_inc(item), item));
      }
      lean_inc(result); return lbp_keep(scope, lb_t78cb4d5802be9606854f_from_array(result));
}
static SV *lb_write_78cb4d5802be9606854f(pTHX_ lbp_scope *scope, lean_object * value) {

      lean_inc(value); value = lbp_keep(scope, lb_t78cb4d5802be9606854f_to_array(value));
      size_t length = lean_array_size(value);
      if (length > 16 * 1024 * 1024 / sizeof(void *)) croak("native copied array exceeds the 16 MiB per-call limit");
      lbp_budget(scope, length * sizeof(void *));
      AV *array = (AV *)sv_2mortal((SV *)newAV());
      for (size_t i = 0; i < length; ++i) {
        SV *item = lb_write_23281a6412f09bc1e5f2(aTHX_ scope, lean_array_get_core(value, i));
        av_push(array, SvREFCNT_inc(item));
      }
      return lbp_mortal(newRV_inc((SV *)array));
}

static lean_object * lb_read_a870c894c6b2db52a3db(pTHX_ lbp_scope *scope, SV *value) {
return lbp_borrow(aTHX_ scope, value, "callback:a870c894c6b2db52a3db");
}
static SV *lb_write_a870c894c6b2db52a3db(pTHX_ lbp_scope *scope, lean_object * value) {
return lbp_resource(aTHX_ value, "callback:a870c894c6b2db52a3db", "LeanBridge::ReviewedCallbacks::Closurea870c894c6b2db52a3db");
}

static lean_object * lb_callback_482d86bbb5f392755b83(void *context, lean_object * argument0) {
      lb_callback_frame_482d86bbb5f392755b83 frame = { .argument0 = argument0 };
      int ok = lbp_callback_invoke((lbp_callback *)context, &frame);
      lean_dec(argument0);
      if (!ok || !frame.returned) return lb_callback_recovery_482d86bbb5f392755b83_get((lbp_callback *)context);
      return frame.result;
    }
static lean_object * lb_callback_b5dadeab68a29cbe5033(void *context, lean_object * argument0) {
      lb_callback_frame_b5dadeab68a29cbe5033 frame = { .argument0 = argument0 };
      int ok = lbp_callback_invoke((lbp_callback *)context, &frame);
      lean_dec(argument0);
      if (!ok || !frame.returned) return lean_box(0);
      return frame.result;
    }
static lean_object * lb_callback_07ff56848fc3a3cd3550(void *context, lean_object * argument0) {
      lb_callback_frame_07ff56848fc3a3cd3550 frame = { .argument0 = argument0 };
      int ok = lbp_callback_invoke((lbp_callback *)context, &frame);
      lean_dec(argument0);
      if (!ok || !frame.returned) return lean_box(0);
      return frame.result;
    }
static lean_object * lb_callback_a5ff4054fc80e0ed5ecb(void *context, lean_object * argument0) {
      lb_callback_frame_a5ff4054fc80e0ed5ecb frame = { .argument0 = argument0 };
      int ok = lbp_callback_invoke((lbp_callback *)context, &frame);
      lean_dec(argument0);
      if (!ok || !frame.returned) return lb_t23281a6412f09bc1e5f2_make(lean_box(0), lean_box(0));
      return frame.result;
    }
static lean_object * lb_callback_a870c894c6b2db52a3db(void *context, lean_object * argument0) {
      lb_callback_frame_a870c894c6b2db52a3db frame = { .argument0 = argument0 };
      int ok = lbp_callback_invoke((lbp_callback *)context, &frame);
      lean_dec(argument0);
      if (!ok || !frame.returned) return lean_box(0);
      return frame.result;
    }
MODULE = LeanBridge::ReviewedCallbacks    PACKAGE = LeanBridge::ReviewedCallbacks
PROTOTYPES: DISABLE


void
apply(...)
  PPCODE:
    if (items != 2) croak("apply expects 2 arguments");
    lbp_check_interpreter(aTHX);
    lbp_component_ready(aTHX);
    LBP_ENTER();
	    lean_object * a0 = lb_read_482d86bbb5f392755b83(aTHX_ scope, ST(0));
    lean_object * a1 = lb_read_bcb803bc837008bec599(aTHX_ scope, ST(1));
    lean_inc(a0); lean_inc(a1);
    lean_object * result = lb_337ad8b506609c627ee6d942(a0, a1);
    lbp_keep(scope, result);
    lbp_finish(aTHX_ scope);
    lbp_component_ready(aTHX);
    SV *out = lb_write_bcb803bc837008bec599(aTHX_ scope, result);
    lbp_component_ready(aTHX);
    SvREFCNT_inc(out);
    LBP_LEAVE();
    ST(0) = sv_2mortal(out);
    XSRETURN(1);


void
counter(...)
  PPCODE:
    if (items != 1) croak("counter expects 1 arguments");
    lbp_check_interpreter(aTHX);
    lbp_component_ready(aTHX);
    LBP_ENTER();
	    lean_object * a0 = lb_read_bcb803bc837008bec599(aTHX_ scope, ST(0));
    lean_inc(a0);
    lean_object * result = lb_7d6a59e9b078774c88a366b9(a0);
    lbp_keep(scope, result);
    lbp_finish(aTHX_ scope);
    lbp_component_ready(aTHX);
    SV *out = lb_write_482d86bbb5f392755b83(aTHX_ scope, result);
    lbp_component_ready(aTHX);
    SvREFCNT_inc(out);
    LBP_LEAVE();
    ST(0) = sv_2mortal(out);
    XSRETURN(1);


void
digits(...)
  PPCODE:
    if (items != 1) croak("digits expects 1 arguments");
    lbp_check_interpreter(aTHX);
    lbp_component_ready(aTHX);
    LBP_ENTER();
	    lean_object * a0 = lb_read_c6349afd7d22f2e92812(aTHX_ scope, ST(0));
    lean_inc(a0);
    lean_object * result = lb_3f29217177283a28652ede82(a0);
    lbp_keep(scope, result);
    lbp_finish(aTHX_ scope);
    lbp_component_ready(aTHX);
    SV *out = lb_write_b5dadeab68a29cbe5033(aTHX_ scope, result);
    lbp_component_ready(aTHX);
    SvREFCNT_inc(out);
    LBP_LEAVE();
    ST(0) = sv_2mortal(out);
    XSRETURN(1);


void
scaler(...)
  PPCODE:
    if (items != 1) croak("scaler expects 1 arguments");
    lbp_check_interpreter(aTHX);
    lbp_component_ready(aTHX);
    LBP_ENTER();
	    lean_object * a0 = lb_read_bcb803bc837008bec599(aTHX_ scope, ST(0));
    lean_inc(a0);
    lean_object * result = lb_958cea34558d0f9a88e5cde7(a0);
    lbp_keep(scope, result);
    lbp_finish(aTHX_ scope);
    lbp_component_ready(aTHX);
    SV *out = lb_write_07ff56848fc3a3cd3550(aTHX_ scope, result);
    lbp_component_ready(aTHX);
    SvREFCNT_inc(out);
    LBP_LEAVE();
    ST(0) = sv_2mortal(out);
    XSRETURN(1);


void
tile_maker(...)
  PPCODE:
    if (items != 1) croak("tile_maker expects 1 arguments");
    lbp_check_interpreter(aTHX);
    lbp_component_ready(aTHX);
    LBP_ENTER();
	    lean_object * a0 = lb_read_bcb803bc837008bec599(aTHX_ scope, ST(0));
    lean_inc(a0);
    lean_object * result = lb_b7af959703ba78059d2cb887(a0);
    lbp_keep(scope, result);
    lbp_finish(aTHX_ scope);
    lbp_component_ready(aTHX);
    SV *out = lb_write_a5ff4054fc80e0ed5ecb(aTHX_ scope, result);
    lbp_component_ready(aTHX);
    SvREFCNT_inc(out);
    LBP_LEAVE();
    ST(0) = sv_2mortal(out);
    XSRETURN(1);


void
tiles(...)
  PPCODE:
    if (items != 1) croak("tiles expects 1 arguments");
    lbp_check_interpreter(aTHX);
    lbp_component_ready(aTHX);
    LBP_ENTER();
	    lean_object * a0 = lb_read_c6349afd7d22f2e92812(aTHX_ scope, ST(0));
    lean_inc(a0);
    lean_object * result = lb_c342fc10fdf5bdc8d2f1fad7(a0);
    lbp_keep(scope, result);
    lbp_finish(aTHX_ scope);
    lbp_component_ready(aTHX);
    SV *out = lb_write_a870c894c6b2db52a3db(aTHX_ scope, result);
    lbp_component_ready(aTHX);
    SvREFCNT_inc(out);
    LBP_LEAVE();
    ST(0) = sv_2mortal(out);
    XSRETURN(1);


void
visit(...)
  PPCODE:
    if (items != 1) croak("visit expects 1 arguments");
    lbp_check_interpreter(aTHX);
    lbp_component_ready(aTHX);
    LBP_ENTER();
	    lean_object * a0 = lb_read_482d86bbb5f392755b83_recovered(aTHX_ scope, ST(0));
    lean_inc(a0);
    lean_object * result = lb_1ff77873a26f0ee6a603e213(a0);
    lbp_keep(scope, result);
    lbp_finish(aTHX_ scope);
    lbp_component_ready(aTHX);
    SV *out = lb_write_bcb803bc837008bec599(aTHX_ scope, result);
    lbp_component_ready(aTHX);
    SvREFCNT_inc(out);
    LBP_LEAVE();
    ST(0) = sv_2mortal(out);
    XSRETURN(1);


void
_callback_482d86bbb5f392755b83(...)
  PPCODE:
    lbp_invocation *invocation = lbp_callback_current(aTHX);
    lbp_component_ready(aTHX);
    if (invocation->callback->invoker != cv) croak("wrong generated callback converter");
    lb_callback_frame_482d86bbb5f392755b83 *frame = invocation->frame;
    LBP_ENTER();
    SV *argument0 = lb_write_bcb803bc837008bec599(aTHX_ scope, frame->argument0);
    SPAGAIN;
    PUSHMARK(SP); XPUSHs(argument0); PUTBACK;
    int count = call_sv(invocation->callback->code, G_SCALAR);
    SPAGAIN;
    if (count != 1) croak("host callback must return one value");
    SV *returned = POPs;
    lbp_component_ready(aTHX);
    frame->result = lb_read_bcb803bc837008bec599(aTHX_ scope, returned);
    lean_inc(frame->result);
    frame->returned = 1;
    SPAGAIN;
    PUTBACK;
    LBP_LEAVE();
    XSRETURN_EMPTY;


void
_callback_b5dadeab68a29cbe5033(...)
  PPCODE:
    lbp_invocation *invocation = lbp_callback_current(aTHX);
    lbp_component_ready(aTHX);
    if (invocation->callback->invoker != cv) croak("wrong generated callback converter");
    lb_callback_frame_b5dadeab68a29cbe5033 *frame = invocation->frame;
    LBP_ENTER();
    SV *argument0 = lb_write_224517b0527dd01c7a6b(aTHX_ scope, frame->argument0);
    SPAGAIN;
    PUSHMARK(SP); XPUSHs(argument0); PUTBACK;
    int count = call_sv(invocation->callback->code, G_SCALAR);
    SPAGAIN;
    if (count != 1) croak("host callback must return one value");
    SV *returned = POPs;
    lbp_component_ready(aTHX);
    frame->result = lb_read_bcb803bc837008bec599(aTHX_ scope, returned);
    lean_inc(frame->result);
    frame->returned = 1;
    SPAGAIN;
    PUTBACK;
    LBP_LEAVE();
    XSRETURN_EMPTY;


void
_callback_07ff56848fc3a3cd3550(...)
  PPCODE:
    lbp_invocation *invocation = lbp_callback_current(aTHX);
    lbp_component_ready(aTHX);
    if (invocation->callback->invoker != cv) croak("wrong generated callback converter");
    lb_callback_frame_07ff56848fc3a3cd3550 *frame = invocation->frame;
    LBP_ENTER();
    SV *argument0 = lb_write_bcb803bc837008bec599(aTHX_ scope, frame->argument0);
    SPAGAIN;
    PUSHMARK(SP); XPUSHs(argument0); PUTBACK;
    int count = call_sv(invocation->callback->code, G_SCALAR);
    SPAGAIN;
    if (count != 1) croak("host callback must return one value");
    SV *returned = POPs;
    lbp_component_ready(aTHX);
    frame->result = lb_read_bcb803bc837008bec599(aTHX_ scope, returned);
    lean_inc(frame->result);
    frame->returned = 1;
    SPAGAIN;
    PUTBACK;
    LBP_LEAVE();
    XSRETURN_EMPTY;


void
_callback_a5ff4054fc80e0ed5ecb(...)
  PPCODE:
    lbp_invocation *invocation = lbp_callback_current(aTHX);
    lbp_component_ready(aTHX);
    if (invocation->callback->invoker != cv) croak("wrong generated callback converter");
    lb_callback_frame_a5ff4054fc80e0ed5ecb *frame = invocation->frame;
    LBP_ENTER();
    SV *argument0 = lb_write_bcb803bc837008bec599(aTHX_ scope, frame->argument0);
    SPAGAIN;
    PUSHMARK(SP); XPUSHs(argument0); PUTBACK;
    int count = call_sv(invocation->callback->code, G_SCALAR);
    SPAGAIN;
    if (count != 1) croak("host callback must return one value");
    SV *returned = POPs;
    lbp_component_ready(aTHX);
    frame->result = lb_read_23281a6412f09bc1e5f2(aTHX_ scope, returned);
    lean_inc(frame->result);
    frame->returned = 1;
    SPAGAIN;
    PUTBACK;
    LBP_LEAVE();
    XSRETURN_EMPTY;


void
_callback_a870c894c6b2db52a3db(...)
  PPCODE:
    lbp_invocation *invocation = lbp_callback_current(aTHX);
    lbp_component_ready(aTHX);
    if (invocation->callback->invoker != cv) croak("wrong generated callback converter");
    lb_callback_frame_a870c894c6b2db52a3db *frame = invocation->frame;
    LBP_ENTER();
    SV *argument0 = lb_write_78cb4d5802be9606854f(aTHX_ scope, frame->argument0);
    SPAGAIN;
    PUSHMARK(SP); XPUSHs(argument0); PUTBACK;
    int count = call_sv(invocation->callback->code, G_SCALAR);
    SPAGAIN;
    if (count != 1) croak("host callback must return one value");
    SV *returned = POPs;
    lbp_component_ready(aTHX);
    frame->result = lb_read_bcb803bc837008bec599(aTHX_ scope, returned);
    lean_inc(frame->result);
    frame->returned = 1;
    SPAGAIN;
    PUTBACK;
    LBP_LEAVE();
    XSRETURN_EMPTY;

MODULE = LeanBridge::ReviewedCallbacks    PACKAGE = LeanBridge::ReviewedCallbacks::Closure482d86bbb5f392755b83

void
call(...)
  PPCODE:
    if (items != 2) croak("call expects 2 arguments");
    lbp_check_interpreter(aTHX);
    lbp_component_ready(aTHX);
    LBP_ENTER();
	    lean_object * a0 = lb_read_482d86bbb5f392755b83(aTHX_ scope, ST(0));
    lean_object * a1 = lb_read_bcb803bc837008bec599(aTHX_ scope, ST(1));
    lean_inc(a0); lean_inc(a1);
    lean_object * result = lb_t482d86bbb5f392755b83_call(a0, a1);
    lbp_keep(scope, result);
    lbp_finish(aTHX_ scope);
    lbp_component_ready(aTHX);
    SV *out = lb_write_bcb803bc837008bec599(aTHX_ scope, result);
    lbp_component_ready(aTHX);
    SvREFCNT_inc(out);
    LBP_LEAVE();
    ST(0) = sv_2mortal(out);
    XSRETURN(1);

MODULE = LeanBridge::ReviewedCallbacks    PACKAGE = LeanBridge::ReviewedCallbacks::Closureb5dadeab68a29cbe5033

void
call(...)
  PPCODE:
    if (items != 2) croak("call expects 2 arguments");
    lbp_check_interpreter(aTHX);
    lbp_component_ready(aTHX);
    LBP_ENTER();
	    lean_object * a0 = lb_read_b5dadeab68a29cbe5033(aTHX_ scope, ST(0));
    lean_object * a1 = lb_read_224517b0527dd01c7a6b(aTHX_ scope, ST(1));
    { 
      for (size_t k0 = 0; k0 < lean_array_size(a1); ++k0) { lean_object *e0 = lean_array_get_core(a1, k0);
      { lean_object *bound = lean_cstr_to_nat("3"); int below = lean_nat_lt(e0, bound); lean_dec(bound);
      if (!below) croak("%s[%zu] is not below its Fin 3 bound", "arg0", (size_t)k0); } } }
    lean_inc(a0); lean_inc(a1);
    lean_object *checked = lb_tb5dadeab68a29cbe5033_call(a0, a1);
    if (lean_is_scalar(checked)) croak("Lean rejected an argument outside its Fin bound");
    lean_object *boxed = lean_ctor_get(checked, 0);
    lean_inc(boxed);
    lean_object * result = boxed;
    lean_dec(checked);
    lbp_keep(scope, result);
    lbp_finish(aTHX_ scope);
    lbp_component_ready(aTHX);
    SV *out = lb_write_bcb803bc837008bec599(aTHX_ scope, result);
    lbp_component_ready(aTHX);
    SvREFCNT_inc(out);
    LBP_LEAVE();
    ST(0) = sv_2mortal(out);
    XSRETURN(1);

MODULE = LeanBridge::ReviewedCallbacks    PACKAGE = LeanBridge::ReviewedCallbacks::Closure07ff56848fc3a3cd3550

void
call(...)
  PPCODE:
    if (items != 2) croak("call expects 2 arguments");
    lbp_check_interpreter(aTHX);
    lbp_component_ready(aTHX);
    LBP_ENTER();
	    lean_object * a0 = lb_read_07ff56848fc3a3cd3550(aTHX_ scope, ST(0));
    lean_object * a1 = lb_read_bcb803bc837008bec599(aTHX_ scope, ST(1));
    { lean_object *bound = lean_cstr_to_nat("10"); int below = lean_nat_lt(a1, bound); lean_dec(bound);
      if (!below) croak("%s", "arg0 is not below its Fin 10 bound"); }
    lean_inc(a0); lean_inc(a1);
    lean_object *checked = lb_t07ff56848fc3a3cd3550_call(a0, a1);
    if (lean_is_scalar(checked)) croak("Lean rejected an argument outside its Fin bound");
    lean_object *boxed = lean_ctor_get(checked, 0);
    lean_inc(boxed);
    lean_object * result = boxed;
    lean_dec(checked);
    lbp_keep(scope, result);
    lbp_finish(aTHX_ scope);
    lbp_component_ready(aTHX);
    SV *out = lb_write_bcb803bc837008bec599(aTHX_ scope, result);
    lbp_component_ready(aTHX);
    SvREFCNT_inc(out);
    LBP_LEAVE();
    ST(0) = sv_2mortal(out);
    XSRETURN(1);

MODULE = LeanBridge::ReviewedCallbacks    PACKAGE = LeanBridge::ReviewedCallbacks::Closurea5ff4054fc80e0ed5ecb

void
call(...)
  PPCODE:
    if (items != 2) croak("call expects 2 arguments");
    lbp_check_interpreter(aTHX);
    lbp_component_ready(aTHX);
    LBP_ENTER();
	    lean_object * a0 = lb_read_a5ff4054fc80e0ed5ecb(aTHX_ scope, ST(0));
    lean_object * a1 = lb_read_bcb803bc837008bec599(aTHX_ scope, ST(1));
    lean_inc(a0); lean_inc(a1);
    lean_object * result = lb_ta5ff4054fc80e0ed5ecb_call(a0, a1);
    lbp_keep(scope, result);
    lbp_finish(aTHX_ scope);
    lbp_component_ready(aTHX);
    SV *out = lb_write_23281a6412f09bc1e5f2(aTHX_ scope, result);
    lbp_component_ready(aTHX);
    SvREFCNT_inc(out);
    LBP_LEAVE();
    ST(0) = sv_2mortal(out);
    XSRETURN(1);

MODULE = LeanBridge::ReviewedCallbacks    PACKAGE = LeanBridge::ReviewedCallbacks::Closurea870c894c6b2db52a3db

void
call(...)
  PPCODE:
    if (items != 2) croak("call expects 2 arguments");
    lbp_check_interpreter(aTHX);
    lbp_component_ready(aTHX);
    LBP_ENTER();
	    lean_object * a0 = lb_read_a870c894c6b2db52a3db(aTHX_ scope, ST(0));
    lean_object * a1 = lb_read_78cb4d5802be9606854f(aTHX_ scope, ST(1));
    { lean_inc(a1); lean_object *items0 = lbp_keep(scope, lb_t78cb4d5802be9606854f_to_array(a1));
      for (size_t k0 = 0; k0 < lean_array_size(items0); ++k0) { lean_object *e0 = lean_array_get_core(items0, k0);
      { lean_inc(e0); lean_object *v1_0 = lbp_keep(scope, lb_t23281a6412f09bc1e5f2_get0(e0));
      { lean_object *bound = lean_cstr_to_nat("5"); int below = lean_nat_lt(v1_0, bound); lean_dec(bound);
      if (!below) croak("%s[%zu].digit is not below its Fin 5 bound", "arg0", (size_t)k0); } } } }
    lean_inc(a0); lean_inc(a1);
    lean_object *checked = lb_ta870c894c6b2db52a3db_call(a0, a1);
    if (lean_is_scalar(checked)) croak("Lean rejected an argument outside its Fin bound");
    lean_object *boxed = lean_ctor_get(checked, 0);
    lean_inc(boxed);
    lean_object * result = boxed;
    lean_dec(checked);
    lbp_keep(scope, result);
    lbp_finish(aTHX_ scope);
    lbp_component_ready(aTHX);
    SV *out = lb_write_bcb803bc837008bec599(aTHX_ scope, result);
    lbp_component_ready(aTHX);
    SvREFCNT_inc(out);
    LBP_LEAVE();
    ST(0) = sv_2mortal(out);
    XSRETURN(1);

BOOT:
  lbp_check_interpreter(aTHX);
  extern lean_object *initialize_LeanBridgeNative99d469b3ee044240(uint8_t);
  if (!lean_bridge_native_component_initialize("reviewedcallbacks@1.0.0:547cc110fd5ae63ca2d6a1885dc7e629e794286703a5a8191851ad419c5855a5", (lean_bridge_native_initializer)initialize_LeanBridgeNative99d469b3ee044240)) croak("Lean component initialization failed");

