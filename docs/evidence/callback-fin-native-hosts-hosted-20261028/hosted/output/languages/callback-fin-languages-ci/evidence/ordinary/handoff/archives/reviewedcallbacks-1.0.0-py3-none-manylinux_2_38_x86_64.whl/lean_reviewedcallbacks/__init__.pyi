from __future__ import annotations
from dataclasses import dataclass as _dataclass

__all__ = ("LeanBridgeError", "LeanClosure", "Tile", "apply", "counter", "digits", "scaler", "tile_maker", "tiles", "visit",)

class LeanBridgeError(RuntimeError):
    status: int
    def __init__(self, status: int, message: str):
        ...

from typing import Callable as _Callable, Generic as _Generic, ParamSpec as _ParamSpec, TypeVar as _TypeVar
from types import TracebackType as _TracebackType

_P = _ParamSpec("_P")
_R = _TypeVar("_R")

class LeanClosure(_Generic[_P, _R]):
    """A same-thread Lean callable. Use with or close() to release it."""
    __slots__ = ("_lease", "__weakref__")

    def __init__(self) -> None:
        ...

    def __call__(self, *args: _P.args, **kwargs: _P.kwargs) -> _R:
        ...

    @property
    def closed(self) -> bool:
        ...

    def close(self) -> None:
        ...

    def __enter__(self) -> LeanClosure[_P, _R]:
        ...

    def __exit__(self, exc_type: type[BaseException] | None, exc: BaseException | None, traceback: _TracebackType | None) -> None:
        ...

    def __copy__(self):
        ...

    def __deepcopy__(self, memo):
        ...

    def __reduce__(self):
        ...


_Array2 = tuple[int, ...] | list[int]

@_dataclass(frozen=True, slots=True)
class Tile:
    digit: int
    count: int

_Array4 = tuple[Tile, ...] | list[Tile]

def apply(arg0: _Callable[[int], int], arg1: int) -> int:
    ...

def counter(arg0: int) -> LeanClosure[[int], int]:
    ...

def digits(arg0: None) -> LeanClosure[[_Array2], int]:
    ...

def scaler(arg0: int) -> LeanClosure[[int], int]:
    ...

def tile_maker(arg0: int) -> LeanClosure[[int], Tile]:
    ...

def tiles(arg0: None) -> LeanClosure[[_Array4], int]:
    ...

def visit(arg0: _Callable[[int], int]) -> int:
    ...

