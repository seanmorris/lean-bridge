import ctypes as _c
from . import LeanBridgeError, LeanClosure, Tile

import hashlib as _hashlib
import os as _os
import pathlib as _pathlib
import platform as _platform
import stat as _stat
import sys as _sys
import threading as _threading
import types as _types

if (_sys.version_info < (3, 11) or _sys.platform != "linux"
        or _platform.machine() not in ("x86_64", "AMD64")
        or _c.sizeof(_c.c_void_p) != 8 or _sys.byteorder != "little"):
    raise ImportError("This Lean package requires Python 3.11+ on Linux x86-64")
if hasattr(_sys, "_is_gil_enabled") and not _sys._is_gil_enabled():
    raise ImportError("This Lean package requires a GIL-enabled interpreter")

_PID = _os.getpid()
_root = _pathlib.Path(__file__).resolve().parent / "native" / "linux-x64"
_libraries = {"libreviewedcallbacks.so":"119fc624c4a574a56e6bb468cb8062c72a62cc3c0ef9a441f8e89199c8b817b7","libcomponent_99d469b3ee044240ea23.so":"547cc110fd5ae63ca2d6a1885dc7e629e794286703a5a8191851ad419c5855a5","liblean_bridge_native.so":"459fcd2098d4b646ab6ae0f4cdccd1f222908cb162562bfc3940a533cd4e4e21","libleanshared.so":"d7768b88d8162736da4305777cd6f147676038fd885bd8a265c958b0ecea00b4"}
for _name, _expected in _libraries.items():
    _path = _root / _name
    if not _stat.S_ISREG(_path.lstat().st_mode):
        raise ImportError("Native library is not a regular file: " + _name)
    with _path.open("rb") as _stream:
        _actual = _hashlib.file_digest(_stream, "sha256").hexdigest()
    if _actual != _expected:
        raise ImportError("Native library differs from compiled evidence: " + _name)

# No shared on-disk module: uninstalling one wheel must not break another.
_candidate = _types.ModuleType("_lean_bridge_copied_runtime_v1")
_candidate.lock = _threading.RLock()
_candidate.pid = _PID
_candidate.identity = None
_candidate.failed = False
_candidate.components = {}
_candidate.libraries = {}
_candidate.handles = []
_state = _sys.modules.setdefault(_candidate.__name__, _candidate)
if _state.pid != _PID:
    raise ImportError("Start a fresh Python interpreter after fork to use Lean packages")
with _state.lock:
    if _state.failed:
        raise ImportError("Lean native loading failed earlier in this interpreter")
    if _state.identity not in (None, "4b5a7fdf0cb11d4bb429181cfd50b330c5622ed8f5f5382a293955a439b595b5"):
        raise ImportError("Incompatible Lean runtime identities")
    for _name, _expected in _libraries.items():
        if _state.libraries.get(_name, _expected) != _expected:
            raise ImportError("Conflicting builds of the same native library: " + _name)
    _previous = _state.components.get("reviewedcallbacks@1.0.0")
    if _previous is not None and _previous[0] != "aee41b3f25c8d56cfed8a502ac559885043cba64b5460a09a704697b95d89606":
        raise ImportError("Conflicting builds of the same Lean component")
    try:
        if _previous is None:
            for _name in ["libleanshared.so","liblean_bridge_native.so","libcomponent_99d469b3ee044240ea23.so","libreviewedcallbacks.so"]:
                if _name not in _state.libraries:
                    _loaded = _c.CDLL(str(_root / _name), mode=_os.RTLD_NOW | _os.RTLD_GLOBAL)
                    _state.handles.append(_loaded)
                    _state.libraries[_name] = _libraries[_name]
                else:
                    _loaded = next(item for item in _state.handles if _pathlib.Path(item._name).name == _name)
            _previous = ("aee41b3f25c8d56cfed8a502ac559885043cba64b5460a09a704697b95d89606", _loaded)
            _state.components["reviewedcallbacks@1.0.0"] = _previous
            _state.identity = "4b5a7fdf0cb11d4bb429181cfd50b330c5622ed8f5f5382a293955a439b595b5"
        _LIBRARY = _previous[1]
    except BaseException:
        _state.failed = True
        raise

def _ensure_process():
    if _os.getpid() != _PID:
        raise RuntimeError("Start a fresh Python interpreter after fork to use Lean packages")

class _T0(_c.Structure):
    _fields_ = [("data", _c.c_void_p), ("length", _c.c_size_t), ("owner", _c.c_void_p), ("release", _c.c_void_p)]

class _T2(_c.Structure):
    _fields_ = [("data", _c.c_void_p), ("length", _c.c_size_t), ("owner", _c.c_void_p), ("release", _c.c_void_p)]

class _T3(_c.Structure):
    _fields_ = [("digit", _T0), ("count", _T0)]

class _T4(_c.Structure):
    _fields_ = [("data", _c.c_void_p), ("length", _c.c_size_t), ("owner", _c.c_void_p), ("release", _c.c_void_p)]

class _Scope:
    def __init__(self):
        self.remaining = 16 * 1024 * 1024
        self.owners = []
        self.failure = None

    def charge(self, count, width=1):
        if count < 0 or width < 1 or count > self.remaining // width:
            raise ValueError("16 MiB Python conversion limit exceeded")
        self.remaining -= count * width

    def allocate(self, element, count):
        self.charge(count, _c.sizeof(element))
        value = (element * count)()
        self.owners.append(value)
        return value

    def close(self):
        self.owners.clear()
        self.failure = None

def _integer(value, minimum, maximum):
    if type(value) is not int:
        raise TypeError("Expected an int, without Boolean or numeric coercion")
    if (minimum is not None and value < minimum) or (maximum is not None and value > maximum):
        raise ValueError("Integer is outside the declared Lean range")
    return value

def _text_size(value):
    if value.isascii():
        return len(value)
    return sum(1 if ord(c) < 0x80 else 2 if ord(c) < 0x800 else 3 if ord(c) < 0x10000 else 4 for c in value)

def _buffer(data, scope):
    memory = scope.allocate(_c.c_uint8, len(data))
    if data:
        _c.memmove(memory, data, len(data))
    return _c.addressof(memory) if data else None

def _read(data, length, scope, width=1):
    scope.charge(length, width)
    if length and not data:
        raise LeanBridgeError(5, "Native result has a missing buffer")
    return _c.string_at(data, length) if length else b""

class _Error(_c.Structure):
    _fields_ = [("code", _c.c_int), ("message", _c.c_void_p), ("message_length", _c.c_size_t)]

def _check(status, error, scope=None):
    if scope is not None and scope.failure is not None:
        raise scope.failure
    if status:
        message = _c.string_at(error.message, min(error.message_length, 16384)).decode("utf-8", "replace") if error.message else "Native Lean call failed"
        raise LeanBridgeError(status, message)

_F0 = _c.CFUNCTYPE(_c.c_int, _c.c_void_p, _c.POINTER(_T0), _c.POINTER(_T0), _c.POINTER(_Error))
class _B0(_c.Structure):
    _fields_ = [("call", _F0), ("context", _c.c_void_p)]

_owned0 = _LIBRARY["reviewedcallbacks_owned_callbackf2af9db3bda87ab235db_call"]
_owned0.argtypes = [_c.c_void_p, _c.POINTER(_T0), _c.POINTER(_T0), _c.POINTER(_Error)]
_owned0.restype = _c.c_int
_dispose0 = _LIBRARY["reviewedcallbacks_owned_callbackf2af9db3bda87ab235db_dispose"]
_dispose0.argtypes = [_c.POINTER(_c.c_void_p)]
_dispose0.restype = None

_F1 = _c.CFUNCTYPE(_c.c_int, _c.c_void_p, _c.POINTER(_T0), _c.POINTER(_T0), _c.POINTER(_Error))
class _B1(_c.Structure):
    _fields_ = [("call", _F1), ("context", _c.c_void_p)]

_owned1 = _LIBRARY["reviewedcallbacks_owned_callbacka1b5e4d2cfa3d3e80004_call"]
_owned1.argtypes = [_c.c_void_p, _c.POINTER(_T0), _c.POINTER(_T0), _c.POINTER(_Error)]
_owned1.restype = _c.c_int
_dispose1 = _LIBRARY["reviewedcallbacks_owned_callbacka1b5e4d2cfa3d3e80004_dispose"]
_dispose1.argtypes = [_c.POINTER(_c.c_void_p)]
_dispose1.restype = None

_F2 = _c.CFUNCTYPE(_c.c_int, _c.c_void_p, _c.POINTER(_T2), _c.POINTER(_T0), _c.POINTER(_Error))
class _B2(_c.Structure):
    _fields_ = [("call", _F2), ("context", _c.c_void_p)]

_owned2 = _LIBRARY["reviewedcallbacks_owned_callback4ee3669b3c7a96ffd2d0_call"]
_owned2.argtypes = [_c.c_void_p, _c.POINTER(_T2), _c.POINTER(_T0), _c.POINTER(_Error)]
_owned2.restype = _c.c_int
_dispose2 = _LIBRARY["reviewedcallbacks_owned_callback4ee3669b3c7a96ffd2d0_dispose"]
_dispose2.argtypes = [_c.POINTER(_c.c_void_p)]
_dispose2.restype = None

_F3 = _c.CFUNCTYPE(_c.c_int, _c.c_void_p, _c.POINTER(_T0), _c.POINTER(_T0), _c.POINTER(_Error))
class _B3(_c.Structure):
    _fields_ = [("call", _F3), ("context", _c.c_void_p)]

_owned3 = _LIBRARY["reviewedcallbacks_owned_callback1469b3ae2047ff62e64f_call"]
_owned3.argtypes = [_c.c_void_p, _c.POINTER(_T0), _c.POINTER(_T0), _c.POINTER(_Error)]
_owned3.restype = _c.c_int
_dispose3 = _LIBRARY["reviewedcallbacks_owned_callback1469b3ae2047ff62e64f_dispose"]
_dispose3.argtypes = [_c.POINTER(_c.c_void_p)]
_dispose3.restype = None

_F4 = _c.CFUNCTYPE(_c.c_int, _c.c_void_p, _c.POINTER(_T0), _c.POINTER(_T3), _c.POINTER(_Error))
class _B4(_c.Structure):
    _fields_ = [("call", _F4), ("context", _c.c_void_p)]

_owned4 = _LIBRARY["reviewedcallbacks_owned_callbackb2f90de4d8e7b5a028e6_call"]
_owned4.argtypes = [_c.c_void_p, _c.POINTER(_T0), _c.POINTER(_T3), _c.POINTER(_Error)]
_owned4.restype = _c.c_int
_dispose4 = _LIBRARY["reviewedcallbacks_owned_callbackb2f90de4d8e7b5a028e6_dispose"]
_dispose4.argtypes = [_c.POINTER(_c.c_void_p)]
_dispose4.restype = None

_F5 = _c.CFUNCTYPE(_c.c_int, _c.c_void_p, _c.POINTER(_T4), _c.POINTER(_T0), _c.POINTER(_Error))
class _B5(_c.Structure):
    _fields_ = [("call", _F5), ("context", _c.c_void_p)]

_owned5 = _LIBRARY["reviewedcallbacks_owned_callbacka0d2888f62a2884d0fa6_call"]
_owned5.argtypes = [_c.c_void_p, _c.POINTER(_T4), _c.POINTER(_T0), _c.POINTER(_Error)]
_owned5.restype = _c.c_int
_dispose5 = _LIBRARY["reviewedcallbacks_owned_callbacka0d2888f62a2884d0fa6_dispose"]
_dispose5.argtypes = [_c.POINTER(_c.c_void_p)]
_dispose5.restype = None

_F6 = _c.CFUNCTYPE(_c.c_int, _c.c_void_p, _c.POINTER(_T0), _c.POINTER(_T0), _c.POINTER(_Error))
class _B6(_c.Structure):
    _fields_ = [("call", _F6), ("context", _c.c_void_p)]

_owned6 = _LIBRARY["reviewedcallbacks_owned_callback0b35b98375ec45f097a4_call"]
_owned6.argtypes = [_c.c_void_p, _c.POINTER(_T0), _c.POINTER(_T0), _c.POINTER(_Error)]
_owned6.restype = _c.c_int
_dispose6 = _LIBRARY["reviewedcallbacks_owned_callback0b35b98375ec45f097a4_dispose"]
_dispose6.argtypes = [_c.POINTER(_c.c_void_p)]
_dispose6.restype = None

_clear0 = _LIBRARY["reviewedcallbacks_nat_clear"]
_clear0.argtypes = [_c.POINTER(_T0)]
_clear0.restype = None
_clear2 = _LIBRARY["reviewedcallbacks_array_nat_span_clear"]
_clear2.argtypes = [_c.POINTER(_T2)]
_clear2.restype = None
_clear3 = _LIBRARY["reviewedcallbacks_tile_clear"]
_clear3.argtypes = [_c.POINTER(_T3)]
_clear3.restype = None
_clear4 = _LIBRARY["reviewedcallbacks_list_lean_reviewed_callbacks_tile_span_clear"]
_clear4.argtypes = [_c.POINTER(_T4)]
_clear4.restype = None
_fn0 = _LIBRARY["reviewedcallbacks_apply"]
_fn0.argtypes = [_c.POINTER(_B0), _c.POINTER(_T0), _c.POINTER(_T0), _c.POINTER(_Error)]
_fn0.restype = _c.c_int
_fn1 = _LIBRARY["reviewedcallbacks_counter"]
_fn1.argtypes = [_c.POINTER(_T0), _c.POINTER(_c.c_void_p), _c.POINTER(_Error)]
_fn1.restype = _c.c_int
_fn2 = _LIBRARY["reviewedcallbacks_digits"]
_fn2.argtypes = [_c.c_uint8, _c.POINTER(_c.c_void_p), _c.POINTER(_Error)]
_fn2.restype = _c.c_int
_fn3 = _LIBRARY["reviewedcallbacks_scaler"]
_fn3.argtypes = [_c.POINTER(_T0), _c.POINTER(_c.c_void_p), _c.POINTER(_Error)]
_fn3.restype = _c.c_int
_fn4 = _LIBRARY["reviewedcallbacks_tile_maker"]
_fn4.argtypes = [_c.POINTER(_T0), _c.POINTER(_c.c_void_p), _c.POINTER(_Error)]
_fn4.restype = _c.c_int
_fn5 = _LIBRARY["reviewedcallbacks_tiles"]
_fn5.argtypes = [_c.c_uint8, _c.POINTER(_c.c_void_p), _c.POINTER(_Error)]
_fn5.restype = _c.c_int
_fn6 = _LIBRARY["reviewedcallbacks_visit"]
_fn6.argtypes = [_c.POINTER(_B6), _c.POINTER(_T0), _c.POINTER(_Error)]
_fn6.restype = _c.c_int

def _to0(value, scope):
    scope.charge(1, _c.sizeof(_T0))
    _integer(value, 0, None)
    length = (value.bit_length() + 31) // 32
    scope.charge(length, 4)
    data = abs(value).to_bytes(length * 4, "little")
    return _T0(_buffer(data, scope), length, None, None)

def _from0(value, scope):
    scope.charge(1, _c.sizeof(_T0))
    magnitude = int.from_bytes(_read(value.data, value.length * 4, scope, 2), "little")
    return magnitude

def _to1(value, scope):
    scope.charge(1, _c.sizeof(_c.c_uint8))
    if value is not None: raise TypeError("Unit requires None")
    return 0

def _from1(value, scope):
    scope.charge(1, _c.sizeof(_c.c_uint8))
    return None

def _to2(value, scope):
    scope.charge(1, _c.sizeof(_T2))
    if type(value) not in (tuple, list): raise TypeError("Expected a tuple or list")
    scope.charge(len(value), 8)
    value = tuple(value)
    memory = scope.allocate(_T0, len(value))
    for index, item in enumerate(value):
        memory[index] = _to0(item, scope)
    return _T2(_c.addressof(memory) if len(value) else None, len(value), None, None)

def _from2(value, scope):
    scope.charge(1, _c.sizeof(_T2))
    scope.charge(value.length, max(8, _c.sizeof(_T0)))
    if value.length and not value.data: raise LeanBridgeError(5, "Native array has a missing buffer")
    if value.length and value.data % _c.alignment(_T0): raise LeanBridgeError(5, "Native array has a misaligned buffer")
    memory = (_T0 * value.length).from_address(value.data) if value.length else ()
    return tuple(_from0(item, scope) for item in memory)

def _to3(value, scope):
    scope.charge(1, _c.sizeof(_T3))
    if type(value) is not Tile: raise TypeError("Expected Tile")
    return _T3(_to0(value.digit, scope), _to0(value.count, scope))

def _from3(value, scope):
    scope.charge(1, _c.sizeof(_T3))
    return Tile(digit=_from0(value.digit, scope), count=_from0(value.count, scope))

def _to4(value, scope):
    scope.charge(1, _c.sizeof(_T4))
    if type(value) not in (tuple, list): raise TypeError("Expected a tuple or list")
    scope.charge(len(value), 8)
    value = tuple(value)
    memory = scope.allocate(_T3, len(value))
    for index, item in enumerate(value):
        memory[index] = _to3(item, scope)
    return _T4(_c.addressof(memory) if len(value) else None, len(value), None, None)

def _from4(value, scope):
    scope.charge(1, _c.sizeof(_T4))
    scope.charge(value.length, max(8, _c.sizeof(_T3)))
    if value.length and not value.data: raise LeanBridgeError(5, "Native array has a missing buffer")
    if value.length and value.data % _c.alignment(_T3): raise LeanBridgeError(5, "Native array has a misaligned buffer")
    memory = (_T3 * value.length).from_address(value.data) if value.length else ()
    return tuple(_from3(item, scope) for item in memory)

import inspect as _inspect

class _Lease:
    def __init__(self, invoke, dispose):
        self.pointer = _c.c_void_p()
        self.invoke = invoke
        self.dispose = dispose
        self.thread = _threading.current_thread()
        self.lock = _threading.RLock()
        self.active = 0
        self.closed = False

    def ensure_open(self):
        _ensure_process()
        if self.closed:
            raise RuntimeError("Lean closure is closed")
        if _threading.current_thread() is not self.thread:
            raise RuntimeError("Lean closure must be called on its creating thread")

    def __call__(self, *args, **kwargs):
        _ensure_process()
        with self.lock:
            self.ensure_open()
            self.active += 1
            try:
                return self.invoke(self.pointer, *args, **kwargs)
            finally:
                self.active -= 1
                if self.closed and not self.active:
                    self.dispose(_c.byref(self.pointer))

    def close(self):
        _ensure_process()
        with self.lock:
            self.closed = True
            if not self.active:
                self.dispose(_c.byref(self.pointer))

    def __del__(self):
        # Never enter a possibly inherited native lock in a forked child.
        try:
            if _os.getpid() == _PID:
                self.close()
        except BaseException:
            pass

def _require_callback(value):
    if (not callable(value) or _inspect.iscoroutinefunction(value)
            or _inspect.isasyncgenfunction(value)
            or _inspect.iscoroutinefunction(getattr(value, "__call__", None))
            or _inspect.isasyncgenfunction(getattr(value, "__call__", None))):
        raise TypeError("Expected a synchronous callable")

def _synchronous(value):
    if _inspect.isawaitable(value):
        if _inspect.iscoroutine(value):
            value.close()
        raise TypeError("Callbacks must return synchronously")
    return value

def _callback0(value, scope):
    _require_callback(value)
    def invoke(_context, arg0, out, _error):
        try:
            if scope.failure is not None:
                return 4
            result = _synchronous(value(_from0(arg0.contents, scope)))
            out[0] = _to0(result, scope)
            return 0
        except BaseException as failure:
            if scope.failure is None:
                scope.failure = failure
            return 4
    function = _F0(invoke)
    scope.owners.append(function)
    return _B0(function, None)

def _own0(output):
    if not output.value:
        raise LeanBridgeError(5, "Native result has a missing Lean closure")
    result = object.__new__(LeanClosure)
    result._lease = _Lease(_invoke0, _dispose0)
    # Share the pointer box until the caller commits the transfer. If wrapping
    # raises, either cleanup path clears the same box, never a duplicate pointer.
    result._lease.pointer = output
    return result

def _invoke0(_self, _arg0):
    _ensure_process()
    scope = _Scope()
    output = _T0()
    error = _Error()
    try:
        input0 = _to0(_arg0, scope)
        _check(_owned0(_self, _c.byref(input0), _c.byref(output), _c.byref(error)), error, scope)
        return _from0(output, scope)
    finally:
        try:
            _clear0(_c.byref(output))
        finally:
            scope.close()

def _callback1(value, scope):
    _require_callback(value)
    def invoke(_context, arg0, out, _error):
        try:
            if scope.failure is not None:
                return 4
            result = _synchronous(value(_from0(arg0.contents, scope)))
            out[0] = _to0(result, scope)
            return 0
        except BaseException as failure:
            if scope.failure is None:
                scope.failure = failure
            return 4
    function = _F1(invoke)
    scope.owners.append(function)
    return _B1(function, None)

def _own1(output):
    if not output.value:
        raise LeanBridgeError(5, "Native result has a missing Lean closure")
    result = object.__new__(LeanClosure)
    result._lease = _Lease(_invoke1, _dispose1)
    # Share the pointer box until the caller commits the transfer. If wrapping
    # raises, either cleanup path clears the same box, never a duplicate pointer.
    result._lease.pointer = output
    return result

def _invoke1(_self, _arg0):
    _ensure_process()
    scope = _Scope()
    output = _T0()
    error = _Error()
    try:
        input0 = _to0(_arg0, scope)
        _check(_owned1(_self, _c.byref(input0), _c.byref(output), _c.byref(error)), error, scope)
        return _from0(output, scope)
    finally:
        try:
            _clear0(_c.byref(output))
        finally:
            scope.close()

def _callback2(value, scope):
    _require_callback(value)
    def invoke(_context, arg0, out, _error):
        try:
            if scope.failure is not None:
                return 4
            result = _synchronous(value(_from2(arg0.contents, scope)))
            out[0] = _to0(result, scope)
            return 0
        except BaseException as failure:
            if scope.failure is None:
                scope.failure = failure
            return 4
    function = _F2(invoke)
    scope.owners.append(function)
    return _B2(function, None)

def _own2(output):
    if not output.value:
        raise LeanBridgeError(5, "Native result has a missing Lean closure")
    result = object.__new__(LeanClosure)
    result._lease = _Lease(_invoke2, _dispose2)
    # Share the pointer box until the caller commits the transfer. If wrapping
    # raises, either cleanup path clears the same box, never a duplicate pointer.
    result._lease.pointer = output
    return result

def _invoke2(_self, _arg0):
    _ensure_process()
    scope = _Scope()
    output = _T0()
    error = _Error()
    try:
        input0 = _to2(_arg0, scope)
        _check(_owned2(_self, _c.byref(input0), _c.byref(output), _c.byref(error)), error, scope)
        return _from0(output, scope)
    finally:
        try:
            _clear0(_c.byref(output))
        finally:
            scope.close()

def _callback3(value, scope):
    _require_callback(value)
    def invoke(_context, arg0, out, _error):
        try:
            if scope.failure is not None:
                return 4
            result = _synchronous(value(_from0(arg0.contents, scope)))
            out[0] = _to0(result, scope)
            return 0
        except BaseException as failure:
            if scope.failure is None:
                scope.failure = failure
            return 4
    function = _F3(invoke)
    scope.owners.append(function)
    return _B3(function, None)

def _own3(output):
    if not output.value:
        raise LeanBridgeError(5, "Native result has a missing Lean closure")
    result = object.__new__(LeanClosure)
    result._lease = _Lease(_invoke3, _dispose3)
    # Share the pointer box until the caller commits the transfer. If wrapping
    # raises, either cleanup path clears the same box, never a duplicate pointer.
    result._lease.pointer = output
    return result

def _invoke3(_self, _arg0):
    _ensure_process()
    scope = _Scope()
    output = _T0()
    error = _Error()
    try:
        input0 = _to0(_arg0, scope)
        _check(_owned3(_self, _c.byref(input0), _c.byref(output), _c.byref(error)), error, scope)
        return _from0(output, scope)
    finally:
        try:
            _clear0(_c.byref(output))
        finally:
            scope.close()

def _callback4(value, scope):
    _require_callback(value)
    def invoke(_context, arg0, out, _error):
        try:
            if scope.failure is not None:
                return 4
            result = _synchronous(value(_from0(arg0.contents, scope)))
            out[0] = _to3(result, scope)
            return 0
        except BaseException as failure:
            if scope.failure is None:
                scope.failure = failure
            return 4
    function = _F4(invoke)
    scope.owners.append(function)
    return _B4(function, None)

def _own4(output):
    if not output.value:
        raise LeanBridgeError(5, "Native result has a missing Lean closure")
    result = object.__new__(LeanClosure)
    result._lease = _Lease(_invoke4, _dispose4)
    # Share the pointer box until the caller commits the transfer. If wrapping
    # raises, either cleanup path clears the same box, never a duplicate pointer.
    result._lease.pointer = output
    return result

def _invoke4(_self, _arg0):
    _ensure_process()
    scope = _Scope()
    output = _T3()
    error = _Error()
    try:
        input0 = _to0(_arg0, scope)
        _check(_owned4(_self, _c.byref(input0), _c.byref(output), _c.byref(error)), error, scope)
        return _from3(output, scope)
    finally:
        try:
            _clear3(_c.byref(output))
        finally:
            scope.close()

def _callback5(value, scope):
    _require_callback(value)
    def invoke(_context, arg0, out, _error):
        try:
            if scope.failure is not None:
                return 4
            result = _synchronous(value(_from4(arg0.contents, scope)))
            out[0] = _to0(result, scope)
            return 0
        except BaseException as failure:
            if scope.failure is None:
                scope.failure = failure
            return 4
    function = _F5(invoke)
    scope.owners.append(function)
    return _B5(function, None)

def _own5(output):
    if not output.value:
        raise LeanBridgeError(5, "Native result has a missing Lean closure")
    result = object.__new__(LeanClosure)
    result._lease = _Lease(_invoke5, _dispose5)
    # Share the pointer box until the caller commits the transfer. If wrapping
    # raises, either cleanup path clears the same box, never a duplicate pointer.
    result._lease.pointer = output
    return result

def _invoke5(_self, _arg0):
    _ensure_process()
    scope = _Scope()
    output = _T0()
    error = _Error()
    try:
        input0 = _to4(_arg0, scope)
        _check(_owned5(_self, _c.byref(input0), _c.byref(output), _c.byref(error)), error, scope)
        return _from0(output, scope)
    finally:
        try:
            _clear0(_c.byref(output))
        finally:
            scope.close()

def _callback6(value, scope):
    _require_callback(value)
    def invoke(_context, arg0, out, _error):
        try:
            if scope.failure is not None:
                return 4
            result = _synchronous(value(_from0(arg0.contents, scope)))
            out[0] = _to0(result, scope)
            return 0
        except BaseException as failure:
            if scope.failure is None:
                scope.failure = failure
            return 4
    function = _F6(invoke)
    scope.owners.append(function)
    return _B6(function, None)

def _own6(output):
    if not output.value:
        raise LeanBridgeError(5, "Native result has a missing Lean closure")
    result = object.__new__(LeanClosure)
    result._lease = _Lease(_invoke6, _dispose6)
    # Share the pointer box until the caller commits the transfer. If wrapping
    # raises, either cleanup path clears the same box, never a duplicate pointer.
    result._lease.pointer = output
    return result

def _invoke6(_self, _arg0):
    _ensure_process()
    scope = _Scope()
    output = _T0()
    error = _Error()
    try:
        input0 = _to0(_arg0, scope)
        _check(_owned6(_self, _c.byref(input0), _c.byref(output), _c.byref(error)), error, scope)
        return _from0(output, scope)
    finally:
        try:
            _clear0(_c.byref(output))
        finally:
            scope.close()

def _call0(_arg0, _arg1):
    _ensure_process()
    scope = _Scope()
    output = _T0()
    error = _Error()
    try:
        input0 = _callback0(_arg0, scope)
        input1 = _to0(_arg1, scope)
        _check(_fn0(_c.byref(input0), _c.byref(input1), _c.byref(output), _c.byref(error)), error, scope)
        return _from0(output, scope)
    finally:
        try:
            _clear0(_c.byref(output))
        finally:
            scope.close()

def _call1(_arg0):
    _ensure_process()
    scope = _Scope()
    output = _c.c_void_p()
    error = _Error()
    try:
        input0 = _to0(_arg0, scope)
        _check(_fn1(_c.byref(input0), _c.byref(output), _c.byref(error)), error, scope)
        owned = _own1(output)
        output = _c.c_void_p()
        return owned
    finally:
        try:
            _dispose1(_c.byref(output))
        finally:
            scope.close()

def _call2(_arg0):
    _ensure_process()
    scope = _Scope()
    output = _c.c_void_p()
    error = _Error()
    try:
        input0 = _to1(_arg0, scope)
        _check(_fn2(input0, _c.byref(output), _c.byref(error)), error, scope)
        owned = _own2(output)
        output = _c.c_void_p()
        return owned
    finally:
        try:
            _dispose2(_c.byref(output))
        finally:
            scope.close()

def _call3(_arg0):
    _ensure_process()
    scope = _Scope()
    output = _c.c_void_p()
    error = _Error()
    try:
        input0 = _to0(_arg0, scope)
        _check(_fn3(_c.byref(input0), _c.byref(output), _c.byref(error)), error, scope)
        owned = _own3(output)
        output = _c.c_void_p()
        return owned
    finally:
        try:
            _dispose3(_c.byref(output))
        finally:
            scope.close()

def _call4(_arg0):
    _ensure_process()
    scope = _Scope()
    output = _c.c_void_p()
    error = _Error()
    try:
        input0 = _to0(_arg0, scope)
        _check(_fn4(_c.byref(input0), _c.byref(output), _c.byref(error)), error, scope)
        owned = _own4(output)
        output = _c.c_void_p()
        return owned
    finally:
        try:
            _dispose4(_c.byref(output))
        finally:
            scope.close()

def _call5(_arg0):
    _ensure_process()
    scope = _Scope()
    output = _c.c_void_p()
    error = _Error()
    try:
        input0 = _to1(_arg0, scope)
        _check(_fn5(input0, _c.byref(output), _c.byref(error)), error, scope)
        owned = _own5(output)
        output = _c.c_void_p()
        return owned
    finally:
        try:
            _dispose5(_c.byref(output))
        finally:
            scope.close()

def _call6(_arg0):
    _ensure_process()
    scope = _Scope()
    output = _T0()
    error = _Error()
    try:
        input0 = _callback6(_arg0, scope)
        _check(_fn6(_c.byref(input0), _c.byref(output), _c.byref(error)), error, scope)
        return _from0(output, scope)
    finally:
        try:
            _clear0(_c.byref(output))
        finally:
            scope.close()
