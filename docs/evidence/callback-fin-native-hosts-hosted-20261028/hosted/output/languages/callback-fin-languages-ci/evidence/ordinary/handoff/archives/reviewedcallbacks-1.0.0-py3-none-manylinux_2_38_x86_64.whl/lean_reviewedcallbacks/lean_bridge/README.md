# lean_reviewedcallbacks

Install the prepared platform wheel and import lean_reviewedcallbacks. Native Lean libraries and runtime loading are included. No Lean compiler or extension build is needed by consumers. Python 3.11+, Linux x86-64 with glibc matching the wheel tag.

Unit is None in every position. Fixed-width integers are range checked; Nat and Int use exact Python integers. Boolean and numeric coercions are rejected. Float32 rounds a Python float to binary32, preserving NaN classification, infinities and signed zero. String is strict Unicode str, including NUL; ByteArray is bytes. Arrays accept tuples or lists and return tuples. Records are frozen dataclasses; nested copied values remain independent.

Types must be pure, acyclic and at most 32 levels deep. Python conversions and native input/output copies each have a 16 MiB budget. Python array conversions count at least eight bytes per element, and strings account for encoding/decoding. These limits do not bound the Lean algorithm's working memory. Native outputs are cleared in finally even if conversion raises. Calls can run on separate threads with independent scratch; do not mutate an input during its conversion. Compatible packages share a synchronized loader and native runtime. Free-threading and post-fork calls are rejected; subinterpreters and other Python implementations have not been accepted.

- lean_reviewedcallbacks.apply: lean:ReviewedCallbacks.apply
- lean_reviewedcallbacks.counter: lean:ReviewedCallbacks.counter
- lean_reviewedcallbacks.digits: lean:ReviewedCallbacks.digits
- lean_reviewedcallbacks.scaler: lean:ReviewedCallbacks.scaler
- lean_reviewedcallbacks.tile_maker: lean:ReviewedCallbacks.tileMaker
- lean_reviewedcallbacks.tiles: lean:ReviewedCallbacks.tiles
- lean_reviewedcallbacks.visit: lean:ReviewedCallbacks.visit

Option[T] is None or Some(value). Some(None) preserves a present Unit or absent inner Option; nested options retain every layer. Result[T, E] is Ok(value) or Err(value), including when both payload types match. These generated wrappers are frozen dataclasses with a value field. Domain errors return Err, not exceptions. Binary products use exact two-element tuples and retain their nesting. Copies can contain these types, arrays and records; resources and callbacks cannot be hidden in them.

Synchronous primitive and acyclic copied structured callbacks accept typed Python callables. Returned Lean closures are callable LeanClosure values: use a with block or close(), and invoke them on their creating thread. close() is idempotent and defers disposal during active reentry. Garbage collection is a fallback. Callback exceptions return as the original Python exception after native cleanup; later invocations in that call are suppressed. Callback values use the same checked copied-value conversions and share the call's copy budgets. Host callbacks are borrowed only for the exporting call. Async or retained host callbacks, callable containers, resources and other effects are not enabled by this adapter.

Lean List values accept exact Python lists or tuples and return independent tuples, including nested copied values. Order, duplicates and empty Lists are preserved. List and Array retain distinct contract identities. List callback arguments arrive as owned tuples; callback results accept exact lists or tuples.

Callback arguments own independent copied values. Callback results use the same input types as exported functions; arrays and Lists may be exact lists or tuples. Returned closures also accept input containers and return owned tuples. Some(None) preserves nested presence. Ok and Err carry domain results, while callback exceptions propagate after native cleanup. Nested callback result buffers stay alive until native copying finishes. Recursive callback payloads and resource-containing aggregates remain unsupported.
