#ifndef REVIEWEDCALLBACKS_H
#define REVIEWEDCALLBACKS_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define REVIEWEDCALLBACKS_BINDING_ABI_VERSION 1u
#define REVIEWEDCALLBACKS_BINDING_IR_SHA256 "3fea721b302f42d142947873b01e400721ef2eba4d9b1f6a440b40c5254a5b6d"

typedef enum reviewedcallbacks_status {
  REVIEWEDCALLBACKS_STATUS_OK = 0,
  REVIEWEDCALLBACKS_STATUS_INVALID_ARGUMENT = 1,
  REVIEWEDCALLBACKS_STATUS_RUNTIME_UNAVAILABLE = 2,
  REVIEWEDCALLBACKS_STATUS_RUNTIME_REJECTED = 3,
  REVIEWEDCALLBACKS_STATUS_DECLARED_ERROR = 4,
  REVIEWEDCALLBACKS_STATUS_UNEXPECTED_ERROR = 5
} reviewedcallbacks_status;

typedef enum reviewedcallbacks_error_code {
  REVIEWEDCALLBACKS_ERROR_NONE = 0,
  REVIEWEDCALLBACKS_ERROR_INVALID_ARGUMENT = 1,
  REVIEWEDCALLBACKS_ERROR_RUNTIME_UNAVAILABLE = 2,
  REVIEWEDCALLBACKS_ERROR_NATIVE_CALLBACK_FAILURE = 100,
  REVIEWEDCALLBACKS_ERROR_UNEXPECTED = 65535
} reviewedcallbacks_error_code;

typedef struct reviewedcallbacks_error {
  reviewedcallbacks_error_code code;
  const char *message;
  size_t message_length;
} reviewedcallbacks_error;

typedef struct reviewedcallbacks_nat reviewedcallbacks_nat;
typedef struct reviewedcallbacks_array_nat_span reviewedcallbacks_array_nat_span;
typedef struct reviewedcallbacks_list_lean_reviewed_callbacks_tile_span reviewedcallbacks_list_lean_reviewed_callbacks_tile_span;
typedef struct reviewedcallbacks_tile reviewedcallbacks_tile;

typedef struct reviewedcallbacks_nat {
  const uint32_t *data;
  size_t length;
  void *owner;
  void (*release)(void *owner);
} reviewedcallbacks_nat;

void reviewedcallbacks_nat_clear(reviewedcallbacks_nat *value);

typedef struct reviewedcallbacks_array_nat_span {
  const reviewedcallbacks_nat *data;
  size_t length;
  void *owner;
  void (*release)(void *owner);
} reviewedcallbacks_array_nat_span;

void reviewedcallbacks_array_nat_span_clear(reviewedcallbacks_array_nat_span *value);

typedef struct reviewedcallbacks_list_lean_reviewed_callbacks_tile_span {
  const reviewedcallbacks_tile *data;
  size_t length;
  void *owner;
  void (*release)(void *owner);
} reviewedcallbacks_list_lean_reviewed_callbacks_tile_span;

void reviewedcallbacks_list_lean_reviewed_callbacks_tile_span_clear(reviewedcallbacks_list_lean_reviewed_callbacks_tile_span *value);

typedef struct reviewedcallbacks_tile {
  reviewedcallbacks_nat digit;
  reviewedcallbacks_nat count;
} reviewedcallbacks_tile;

void reviewedcallbacks_tile_clear(reviewedcallbacks_tile *value);

typedef reviewedcallbacks_status (*reviewedcallbacks_callback0b35b98375ec45f097a4_fn)(void *context, const reviewedcallbacks_nat *arg0, reviewedcallbacks_nat *out, reviewedcallbacks_error *error);
typedef struct reviewedcallbacks_callback0b35b98375ec45f097a4 {
  reviewedcallbacks_callback0b35b98375ec45f097a4_fn call;
  void *context;
} reviewedcallbacks_callback0b35b98375ec45f097a4;
typedef struct reviewedcallbacks_owned_callback0b35b98375ec45f097a4 reviewedcallbacks_owned_callback0b35b98375ec45f097a4;

reviewedcallbacks_status reviewedcallbacks_owned_callback0b35b98375ec45f097a4_call(const reviewedcallbacks_owned_callback0b35b98375ec45f097a4 *self, const reviewedcallbacks_nat *arg0, reviewedcallbacks_nat *out, reviewedcallbacks_error *error);
void reviewedcallbacks_owned_callback0b35b98375ec45f097a4_dispose(reviewedcallbacks_owned_callback0b35b98375ec45f097a4 **self);

typedef reviewedcallbacks_status (*reviewedcallbacks_callback1469b3ae2047ff62e64f_fn)(void *context, const reviewedcallbacks_nat *arg0, reviewedcallbacks_nat *out, reviewedcallbacks_error *error);
typedef struct reviewedcallbacks_callback1469b3ae2047ff62e64f {
  reviewedcallbacks_callback1469b3ae2047ff62e64f_fn call;
  void *context;
} reviewedcallbacks_callback1469b3ae2047ff62e64f;
typedef struct reviewedcallbacks_owned_callback1469b3ae2047ff62e64f reviewedcallbacks_owned_callback1469b3ae2047ff62e64f;

reviewedcallbacks_status reviewedcallbacks_owned_callback1469b3ae2047ff62e64f_call(const reviewedcallbacks_owned_callback1469b3ae2047ff62e64f *self, const reviewedcallbacks_nat *arg0, reviewedcallbacks_nat *out, reviewedcallbacks_error *error);
void reviewedcallbacks_owned_callback1469b3ae2047ff62e64f_dispose(reviewedcallbacks_owned_callback1469b3ae2047ff62e64f **self);

typedef reviewedcallbacks_status (*reviewedcallbacks_callback4ee3669b3c7a96ffd2d0_fn)(void *context, const reviewedcallbacks_array_nat_span *arg0, reviewedcallbacks_nat *out, reviewedcallbacks_error *error);
typedef struct reviewedcallbacks_callback4ee3669b3c7a96ffd2d0 {
  reviewedcallbacks_callback4ee3669b3c7a96ffd2d0_fn call;
  void *context;
} reviewedcallbacks_callback4ee3669b3c7a96ffd2d0;
typedef struct reviewedcallbacks_owned_callback4ee3669b3c7a96ffd2d0 reviewedcallbacks_owned_callback4ee3669b3c7a96ffd2d0;

reviewedcallbacks_status reviewedcallbacks_owned_callback4ee3669b3c7a96ffd2d0_call(const reviewedcallbacks_owned_callback4ee3669b3c7a96ffd2d0 *self, const reviewedcallbacks_array_nat_span *arg0, reviewedcallbacks_nat *out, reviewedcallbacks_error *error);
void reviewedcallbacks_owned_callback4ee3669b3c7a96ffd2d0_dispose(reviewedcallbacks_owned_callback4ee3669b3c7a96ffd2d0 **self);

typedef reviewedcallbacks_status (*reviewedcallbacks_callbacka0d2888f62a2884d0fa6_fn)(void *context, const reviewedcallbacks_list_lean_reviewed_callbacks_tile_span *arg0, reviewedcallbacks_nat *out, reviewedcallbacks_error *error);
typedef struct reviewedcallbacks_callbacka0d2888f62a2884d0fa6 {
  reviewedcallbacks_callbacka0d2888f62a2884d0fa6_fn call;
  void *context;
} reviewedcallbacks_callbacka0d2888f62a2884d0fa6;
typedef struct reviewedcallbacks_owned_callbacka0d2888f62a2884d0fa6 reviewedcallbacks_owned_callbacka0d2888f62a2884d0fa6;

reviewedcallbacks_status reviewedcallbacks_owned_callbacka0d2888f62a2884d0fa6_call(const reviewedcallbacks_owned_callbacka0d2888f62a2884d0fa6 *self, const reviewedcallbacks_list_lean_reviewed_callbacks_tile_span *arg0, reviewedcallbacks_nat *out, reviewedcallbacks_error *error);
void reviewedcallbacks_owned_callbacka0d2888f62a2884d0fa6_dispose(reviewedcallbacks_owned_callbacka0d2888f62a2884d0fa6 **self);

typedef reviewedcallbacks_status (*reviewedcallbacks_callbacka1b5e4d2cfa3d3e80004_fn)(void *context, const reviewedcallbacks_nat *arg0, reviewedcallbacks_nat *out, reviewedcallbacks_error *error);
typedef struct reviewedcallbacks_callbacka1b5e4d2cfa3d3e80004 {
  reviewedcallbacks_callbacka1b5e4d2cfa3d3e80004_fn call;
  void *context;
} reviewedcallbacks_callbacka1b5e4d2cfa3d3e80004;
typedef struct reviewedcallbacks_owned_callbacka1b5e4d2cfa3d3e80004 reviewedcallbacks_owned_callbacka1b5e4d2cfa3d3e80004;

reviewedcallbacks_status reviewedcallbacks_owned_callbacka1b5e4d2cfa3d3e80004_call(const reviewedcallbacks_owned_callbacka1b5e4d2cfa3d3e80004 *self, const reviewedcallbacks_nat *arg0, reviewedcallbacks_nat *out, reviewedcallbacks_error *error);
void reviewedcallbacks_owned_callbacka1b5e4d2cfa3d3e80004_dispose(reviewedcallbacks_owned_callbacka1b5e4d2cfa3d3e80004 **self);

typedef reviewedcallbacks_status (*reviewedcallbacks_callbackb2f90de4d8e7b5a028e6_fn)(void *context, const reviewedcallbacks_nat *arg0, reviewedcallbacks_tile *out, reviewedcallbacks_error *error);
typedef struct reviewedcallbacks_callbackb2f90de4d8e7b5a028e6 {
  reviewedcallbacks_callbackb2f90de4d8e7b5a028e6_fn call;
  void *context;
} reviewedcallbacks_callbackb2f90de4d8e7b5a028e6;
typedef struct reviewedcallbacks_owned_callbackb2f90de4d8e7b5a028e6 reviewedcallbacks_owned_callbackb2f90de4d8e7b5a028e6;

reviewedcallbacks_status reviewedcallbacks_owned_callbackb2f90de4d8e7b5a028e6_call(const reviewedcallbacks_owned_callbackb2f90de4d8e7b5a028e6 *self, const reviewedcallbacks_nat *arg0, reviewedcallbacks_tile *out, reviewedcallbacks_error *error);
void reviewedcallbacks_owned_callbackb2f90de4d8e7b5a028e6_dispose(reviewedcallbacks_owned_callbackb2f90de4d8e7b5a028e6 **self);

typedef reviewedcallbacks_status (*reviewedcallbacks_callbackf2af9db3bda87ab235db_fn)(void *context, const reviewedcallbacks_nat *arg0, reviewedcallbacks_nat *out, reviewedcallbacks_error *error);
typedef struct reviewedcallbacks_callbackf2af9db3bda87ab235db {
  reviewedcallbacks_callbackf2af9db3bda87ab235db_fn call;
  void *context;
} reviewedcallbacks_callbackf2af9db3bda87ab235db;
typedef struct reviewedcallbacks_owned_callbackf2af9db3bda87ab235db reviewedcallbacks_owned_callbackf2af9db3bda87ab235db;

reviewedcallbacks_status reviewedcallbacks_owned_callbackf2af9db3bda87ab235db_call(const reviewedcallbacks_owned_callbackf2af9db3bda87ab235db *self, const reviewedcallbacks_nat *arg0, reviewedcallbacks_nat *out, reviewedcallbacks_error *error);
void reviewedcallbacks_owned_callbackf2af9db3bda87ab235db_dispose(reviewedcallbacks_owned_callbackf2af9db3bda87ab235db **self);

reviewedcallbacks_status reviewedcallbacks_apply(const reviewedcallbacks_callbackf2af9db3bda87ab235db *arg0, const reviewedcallbacks_nat *arg1, reviewedcallbacks_nat *out, reviewedcallbacks_error *error);
reviewedcallbacks_status reviewedcallbacks_counter(const reviewedcallbacks_nat *arg0, reviewedcallbacks_owned_callbacka1b5e4d2cfa3d3e80004 **out, reviewedcallbacks_error *error);
reviewedcallbacks_status reviewedcallbacks_digits(uint8_t arg0, reviewedcallbacks_owned_callback4ee3669b3c7a96ffd2d0 **out, reviewedcallbacks_error *error);
reviewedcallbacks_status reviewedcallbacks_scaler(const reviewedcallbacks_nat *arg0, reviewedcallbacks_owned_callback1469b3ae2047ff62e64f **out, reviewedcallbacks_error *error);
reviewedcallbacks_status reviewedcallbacks_tile_maker(const reviewedcallbacks_nat *arg0, reviewedcallbacks_owned_callbackb2f90de4d8e7b5a028e6 **out, reviewedcallbacks_error *error);
reviewedcallbacks_status reviewedcallbacks_tiles(uint8_t arg0, reviewedcallbacks_owned_callbacka0d2888f62a2884d0fa6 **out, reviewedcallbacks_error *error);
reviewedcallbacks_status reviewedcallbacks_visit(const reviewedcallbacks_callback0b35b98375ec45f097a4 *arg0, reviewedcallbacks_nat *out, reviewedcallbacks_error *error);

#ifdef __cplusplus
}
#endif

#endif /* REVIEWEDCALLBACKS_H */
