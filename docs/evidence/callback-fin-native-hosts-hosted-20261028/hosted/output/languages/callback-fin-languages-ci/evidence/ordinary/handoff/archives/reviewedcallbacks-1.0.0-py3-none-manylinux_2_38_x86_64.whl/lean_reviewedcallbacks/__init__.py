from __future__ import annotations
from dataclasses import dataclass as _dataclass

__all__ = ("LeanBridgeError", "LeanClosure", "Tile", "apply", "counter", "digits", "scaler", "tile_maker", "tiles", "visit",)

class LeanBridgeError(RuntimeError):
    status: int
    def __init__(self, status: int, message: str):
        super().__init__(message)
        self.status = status

from typing import Callable as _Callable, Generic as _Generic, ParamSpec as _ParamSpec, TypeVar as _TypeVar
from types import TracebackType as _TracebackType

_P = _ParamSpec("_P")
_R = _TypeVar("_R")

class LeanClosure(_Generic[_P, _R]):
    """A same-thread Lean callable. Use with or close() to release it."""
    __slots__ = ("_lease", "__weakref__")

    def __init__(self) -> None:
        raise TypeError("Lean closures are returned by generated functions")

    def __call__(self, *args: _P.args, **kwargs: _P.kwargs) -> _R:
        return self._lease(*args, **kwargs)

    @property
    def closed(self) -> bool:
        return self._lease.closed

    def close(self) -> None:
        self._lease.close()

    def __enter__(self) -> LeanClosure[_P, _R]:
        self._lease.ensure_open()
        return self

    def __exit__(self, exc_type: type[BaseException] | None, exc: BaseException | None, traceback: _TracebackType | None) -> None:
        self.close()

    def __copy__(self):
        raise TypeError("Lean closures cannot be copied")

    def __deepcopy__(self, memo):
        raise TypeError("Lean closures cannot be copied")

    def __reduce__(self):
        raise TypeError("Lean closures cannot be serialized")


_Array2 = tuple[int, ...] | list[int]

@_dataclass(frozen=True, slots=True)
class Tile:
    digit: int
    count: int

_Array4 = tuple[Tile, ...] | list[Tile]

def apply(arg0: _Callable[[int], int], arg1: int) -> int:
    return _native._call0(arg0, arg1)

def counter(arg0: int) -> LeanClosure[[int], int]:
    return _native._call1(arg0)

def digits(arg0: None) -> LeanClosure[[_Array2], int]:
    return _native._call2(arg0)

def scaler(arg0: int) -> LeanClosure[[int], int]:
    return _native._call3(arg0)

def tile_maker(arg0: int) -> LeanClosure[[int], Tile]:
    return _native._call4(arg0)

def tiles(arg0: None) -> LeanClosure[[_Array4], int]:
    return _native._call5(arg0)

def visit(arg0: _Callable[[int], int]) -> int:
    return _native._call6(arg0)

from . import _native
