// Generated from Binding IR SHA-256 8e4519a705cdb507a06f261757861bb93d12911d934fc8ca4c6658fd3bc4abfc.
import { runtime } from "./internal/runtime.mjs";

/** Independent corpus contract. */
export function claimFor(arg0) {
  return runtime.call("lean:OwnedCheckedRecords.claimFor", Array.from(arguments));
}

/** Independent corpus contract. */
export function newTicket(arg0, arg1) {
  return runtime.call("lean:OwnedCheckedRecords.newTicket", Array.from(arguments));
}

/** Independent corpus contract. */
export function serial(arg0) {
  return runtime.call("lean:OwnedCheckedRecords.serial", Array.from(arguments));
}

export function close() { return runtime.close(); }
export function withRecovery(operation, recovery) { return runtime.withRecovery(operation, recovery); }
export default Object.freeze({ claimFor, newTicket, serial, close, withRecovery });
