#include "component.h"
#include "lean_bridge_native_runtime.h"
static _Thread_local int lean_bridge_owned_callback_failure_8e4519a705cdb507a06f_state;
int lean_bridge_owned_callback_failure_8e4519a705cdb507a06f(void) { int result = lean_bridge_owned_callback_failure_8e4519a705cdb507a06f_state; lean_bridge_owned_callback_failure_8e4519a705cdb507a06f_state = 0; return result; }
