# lean_owned_checked_records

Install the prepared platform wheel with pip and import lean_owned_checked_records.
The wheel verifies and loads its bundled Lean runtime and GMP automatically.
Consumers do not need Lean, a C compiler, ctypes setup or shared-library paths.
This native profile requires GIL-enabled Python 3.11+ on Linux x86-64, with
glibc at least as new as the wheel's manylinux tag.

Records and variant constructors are frozen dataclasses. Arrays and Lists
accept lists or tuples and return independent tuples. Option is None or
Some(value), so Some(None) stays distinct. Except uses Ok(value) and Err(value).
Products keep their nested two-element tuples. Concrete aliases retain their
names. Nat and Int use exact Python integers; fixed-width integers check their
ranges and reject Boolean coercion. Strings preserve Unicode scalar text and
embedded NUL; ByteArray is bytes. Float32 rounds to binary32. Unit is None.

Resource fields carry checked ownership leases. Shallow copies share a lease;
closing one wrapper does not invalidate another owning copy. retain() creates
independent native ownership. Use with blocks or close() for explicit release.
Finalization supplies fallback cleanup on the creating thread. Resources reject
use from other threads, after their creating thread exits, or after fork.
Start a fresh interpreter after fork. Deep copying and serialization of resource
identities are rejected.

Pass synchronous Python functions to callback parameters. Callback containers
are independent values, but resource leaves borrow the callback frame and expire
on return. Call retain() inside the callback to keep a resource. Callback-local
replies are snapshotted before their storage disappears. Returned Lean closures
are callable and support retain() and close(); they can also serve as callback
arguments. A Lean closure cannot extend the lifetime of a borrowed host callback.
Signatures that cannot derive a failure-path value from their arguments require
with_recovery(function, typed_value). Recovery never becomes a successful result.

Callback exceptions return to the original Python caller after C has unwound.
Async functions and awaitable replies are rejected. Failed output conversions
revoke partial wrappers even when the caller retains the exception traceback.
Malformed native values retire the runtime; ordinary validation and recoverable
allocation failures leave it usable.

Conversions limit depth to 128, visits to 262,144, native conversion data to
16 MiB and accounted Python conversion storage to another 16 MiB. A call shares
these budgets across its inputs, callbacks and result. These limits do not bound
Lean's algorithm memory or every Python allocator overhead. Recursive type
aliases use typing_extensions >=4.6,<5 on Python 3.11 and the standard library
on Python 3.12+; pip installs the backport when needed.
