import ctypes as _c
import builtins as _b
from . import _owned as _R
from . import __name__ as _package_name
import sys as _sys
_V = _sys.modules[_package_name]

if _c.sizeof(_c.c_void_p) != 8 or _sys.byteorder != "little":
    raise ImportError("Owned Python values require a 64-bit little-endian host")

class _OwnedInvalidNative(_R.LeanBridgeError):
    def __init__(self, message="Malformed native owned value"):
        super().__init__(9, message)

class _OwnedLimit(_R.LeanBridgeError):
    def __init__(self, message="Owned conversion limit exceeded"):
        super().__init__(2, message)

class _OwnedMpz(_c.Structure):
    _fields_ = [("allocated", _c.c_int32), ("size", _c.c_int32), ("data", _c.c_void_p)]

class _OwnedBudget:
    def __init__(self):
        self.nodes = 262144
        self.native = 16777216
        self.storage = 16777216

class _OwnedScope:
    def __init__(self, state, check_only=False, budget=None):
        self.state = state
        self.check_only = check_only
        self.budget = _OwnedBudget() if budget is None else budget
        self.active = set()
        self.owners = []
        self.moves = None
        self.move_group = None

    @property
    def nodes(self):
        return self.budget.nodes

    @property
    def native(self):
        return self.budget.native

    def charge(self, field, count, width=1):
        remaining = getattr(self.budget, field)
        if count < 0 or width < 1 or count > remaining // width:
            raise _OwnedLimit()
        setattr(self.budget, field, remaining - count * width)

    def enter(self, key, depth, raw, output=False):
        if depth > 128 or self.nodes == 0:
            raise _OwnedLimit("Owned value depth or node limit exceeded")
        self.budget.nodes -= 1
        self.charge("native", 1, _c.sizeof(raw))
        if key is not None:
            if key in self.active:
                if output:
                    raise _OwnedInvalidNative("Cyclic native owned value")
                raise ValueError("Cyclic Python owned value")
            self.active.add(key)

    def leave(self, key):
        if key is not None:
            self.active.remove(key)

    def value(self, raw, value=None):
        self.charge("storage", _c.sizeof(raw) + 256)
        if self.check_only:
            return None
        _R._owned_checkpoint()
        result = raw() if value is None else raw(value)
        self.owners.append(result)
        return result

    def allocate(self, raw, count):
        self.charge("storage", count, _c.sizeof(raw))
        self.charge("storage", 256)
        if self.check_only:
            return None
        _R._owned_checkpoint()
        result = (raw * count)()
        self.owners.append(result)
        return result

    def pin(self, value):
        try:
            self.charge("storage", 32)
            if not self.check_only:
                _R._owned_checkpoint()
                self.owners.append(value)
        finally:
            # Retaining a traceback must not retain a private owning lease.
            value = None

    def close(self):
        self.moves = None
        self.owners.clear()
        self.active.clear()

class _OwnedOutput:
    def __init__(self, owner, lease=None):
        self.owner = owner
        self.lease = lease

    def hold(self):
        if self.lease is None:
            if not self.owner.value.value:
                raise _OwnedInvalidNative("Missing native result owner")
            self.lease = self.owner.state.adopt(self.owner)
        self.lease.require()
        return self.lease

def _owned_integer(value, minimum, maximum):
    if type(value) is not int:
        raise TypeError("Expected int without Boolean or numeric coercion")
    if minimum is not None and value < minimum or maximum is not None and value > maximum:
        raise ValueError("Integer is outside the declared Lean range")
    return value

def _owned_text_size(value, limit):
    if len(value) > limit:
        raise _OwnedLimit("UTF-8 text exceeds the conversion limit")
    if value.isascii():
        return len(value)
    size = 0
    for character in value:
        code = ord(character)
        if 0xd800 <= code <= 0xdfff:
            raise ValueError("String requires Unicode scalar values")
        size += 1 if code < 0x80 else 2 if code < 0x800 else 3 if code < 0x10000 else 4
        if size > limit:
            raise _OwnedLimit("UTF-8 text exceeds the conversion limit")
    return size

def _owned_span(pointer, count, raw):
    if not count:
        return 0
    width = _c.sizeof(raw)
    if (not pointer or pointer % _c.alignment(raw)
            or count > ((1 << 63) - 1) // width
            or pointer > (1 << 64) - 1 - count * width):
        raise _OwnedInvalidNative("Missing, misaligned or overflowing native span")
    # Verified native code supplies readable memory. Shape validation alone
    # cannot prove arbitrary foreign pointers belong to live allocations.
    return pointer

def _owned_read(pointer, raw):
    return raw.from_address(_owned_span(pointer, 1, raw))


class _OwnedInputTransfers:
    def __init__(self, state, count, scope):
        self.state = state
        self.finished = False
        self.owners = []
        self.leases = {}
        try:
            scope.charge("storage", count, 512)
            for _ in range(count):
                _R._owned_checkpoint()
                self.owners.append(_R._OwnedNativeOwner(state))
        except BaseException:
            self.close()
            raise

    def ready(self, lease):
        lease.require()
        if lease.state is not self.state or lease.scope is not None:
            raise _R.LeanBridgeError(1, "A transferred input requires an owning lease")
        if lease.input_move is not None:
            raise _R.LeanBridgeError(8, "The input lease already belongs to a handoff")

    def add(self, lease, group, scope):
        previous = None
        try:
            self.ready(lease)
            key = _b.id(lease)
            previous = self.leases.get(key)
            if previous is not None:
                if previous[1] != group:
                    raise _R.LeanBridgeError(1, "Two transferred inputs cannot consume the same lease")
                return
            scope.charge("storage", 256)
            _R._owned_checkpoint()
            self.leases[key] = (lease, group)
        finally:
            # A retained allocation traceback must not keep private owning
            # references after the surrounding transaction closes its ledger.
            lease = previous = None

    def arm(self):
        self.state.require()
        for owner in self.owners:
            if not owner.value.value:
                raise _R.LeanBridgeError(9, "Missing prepared input owner")
        for lease, _ in self.leases.values():
            self.ready(lease)
        # Slots stay alive through the call. C clears them immediately before
        # entering Lean, so a reentrant callback sees every moved alias closed.
        for lease, group in self.leases.values():
            lease.input_move = self.owners[group].slot

    def finish(self):
        if self.finished:
            return
        # Mark all consumed original owners before any release can run user
        # finalizers. A pre-handoff failure leaves every original slot intact.
        for lease, group in self.leases.values():
            signal = self.owners[group].slot
            if lease.input_move is signal and not signal.value.value:
                lease.slot.pending = True
        for lease, group in self.leases.values():
            if lease.input_move is self.owners[group].slot:
                lease.input_move = None
        self.finished = True
        self.state.drain()

    def close(self):
        try:
            self.finish()
        finally:
            for owner in self.owners:
                owner.close()
            self.owners.clear()
            self.leases.clear()

    def __del__(self):
        try:
            self.close()
        except BaseException:
            pass

class _OwnedRaw0(_c.Structure):
    pass

class _OwnedRaw3(_c.Structure):
    pass

class _OwnedRaw4(_c.Structure):
    pass

class _OwnedRaw6(_c.Structure):
    pass

class _OwnedRaw8(_c.Structure):
    pass

_OwnedRaw8._fields_ = [( "data", _c.c_void_p), ("length", _c.c_size_t)]

_OwnedRaw0._fields_ = [( "has_value", _c.c_uint8), ("field0", _c.c_void_p)]

_OwnedRaw3._fields_ = [("field0", _c.c_void_p), ("field1", _c.c_void_p)]

_OwnedRaw4._fields_ = [("field0", _c.c_void_p), ("field1", _c.c_void_p)]

_OwnedRaw6._fields_ = [("field0", _c.c_void_p), ("field1", _c.c_void_p)]

def _owned_input0(value, scope, depth=0):
    key = _b.id(value)
    scope.enter(key, depth, _OwnedRaw0)
    try:
        if value is None: return scope.value(_OwnedRaw0)
        if type(value) is _V.Some:
            out = scope.value(_OwnedRaw0)
            if not scope.check_only: out.has_value = 1
            child = _owned_input4(value.value, scope, depth + 1)
            if not scope.check_only:
                out.field0 = _c.addressof(child)
            return out
        raise TypeError("Expected None or Some(value)")
    finally:
        scope.leave(key)

def _owned_output0(value, scope, output, depth=0):
    key = (0, _c.addressof(value))
    scope.enter(key, depth, _OwnedRaw0, True)
    try:
        if value.has_value == 0: return None
        if value.has_value == 1:
            scope.charge("storage", 272)
            _R._owned_checkpoint()
            return _V.Some(_owned_output4(_owned_read(value.field0, _OwnedRaw4), scope, output, depth + 1))
        raise _OwnedInvalidNative("Invalid native constructor flag")
    finally:
        scope.leave(key)

def _owned_input1(value, scope, depth=0):
    key = None
    scope.enter(key, depth, _c.c_void_p)
    try:
        if type(value) is not _V.Callback26621c40b48fce52ca37: raise TypeError("Expected Callback26621c40b48fce52ca37")
        handle = value._raw(scope.state)
        scope.pin(value._lease)
        if scope.moves is not None and scope.move_group is not None:
            scope.moves.add(value._lease, scope.move_group, scope)
        return handle
    finally:
        scope.leave(key)

def _owned_output1(value, scope, output, depth=0):
    if type(value) is _c.c_void_p: value = value.value
    key = None
    scope.enter(key, depth, _c.c_void_p, True)
    try:
        if not value: raise _OwnedInvalidNative("Missing native resource")
        scope.charge("storage", 256)
        return _V.Callback26621c40b48fce52ca37._from_lease(output.hold(), value)
    finally:
        scope.leave(key)

def _owned_input2(value, scope, depth=0):
    key = None
    scope.enter(key, depth, _c.c_void_p)
    try:
        if type(value) is not _V.Callbackb2d3d6fd4e031785f278: raise TypeError("Expected Callbackb2d3d6fd4e031785f278")
        handle = value._raw(scope.state)
        scope.pin(value._lease)
        if scope.moves is not None and scope.move_group is not None:
            scope.moves.add(value._lease, scope.move_group, scope)
        return handle
    finally:
        scope.leave(key)

def _owned_output2(value, scope, output, depth=0):
    if type(value) is _c.c_void_p: value = value.value
    key = None
    scope.enter(key, depth, _c.c_void_p, True)
    try:
        if not value: raise _OwnedInvalidNative("Missing native resource")
        scope.charge("storage", 256)
        return _V.Callbackb2d3d6fd4e031785f278._from_lease(output.hold(), value)
    finally:
        scope.leave(key)

def _owned_input3(value, scope, depth=0):
    key = _b.id(value)
    scope.enter(key, depth, _OwnedRaw3)
    try:
        if type(value) is not _V.Booking: raise TypeError("Expected Booking")
        out = scope.value(_OwnedRaw3)
        child = _owned_input5(value.holder, scope, depth + 1)
        if not scope.check_only:
            out.field0 = child
        child = _owned_input6(value.window, scope, depth + 1)
        if not scope.check_only:
            out.field1 = _c.addressof(child)
        return out
    finally:
        scope.leave(key)

def _owned_output3(value, scope, output, depth=0):
    key = (3, _c.addressof(value))
    scope.enter(key, depth, _OwnedRaw3, True)
    try:
        scope.charge("storage", 288)
        _R._owned_checkpoint()
        return _V.Booking(_owned_output5(value.field0, scope, output, depth + 1), _owned_output6(_owned_read(value.field1, _OwnedRaw6), scope, output, depth + 1))
    finally:
        scope.leave(key)

def _owned_input4(value, scope, depth=0):
    key = _b.id(value)
    scope.enter(key, depth, _OwnedRaw4)
    try:
        if type(value) is not _V.Claim: raise TypeError("Expected Claim")
        out = scope.value(_OwnedRaw4)
        child = _owned_input5(value.holder, scope, depth + 1)
        if not scope.check_only:
            out.field0 = child
        child = _owned_input7(value.quota, scope, depth + 1)
        if not scope.check_only:
            out.field1 = child
        return out
    finally:
        scope.leave(key)

def _owned_output4(value, scope, output, depth=0):
    key = (4, _c.addressof(value))
    scope.enter(key, depth, _OwnedRaw4, True)
    try:
        scope.charge("storage", 288)
        _R._owned_checkpoint()
        return _V.Claim(_owned_output5(value.field0, scope, output, depth + 1), _owned_output7(value.field1, scope, output, depth + 1))
    finally:
        scope.leave(key)

def _owned_input5(value, scope, depth=0):
    key = None
    scope.enter(key, depth, _c.c_void_p)
    try:
        if type(value) is not _V.Ticket: raise TypeError("Expected Ticket")
        handle = value._raw(scope.state)
        scope.pin(value._lease)
        if scope.moves is not None and scope.move_group is not None:
            scope.moves.add(value._lease, scope.move_group, scope)
        return handle
    finally:
        scope.leave(key)

def _owned_output5(value, scope, output, depth=0):
    if type(value) is _c.c_void_p: value = value.value
    key = None
    scope.enter(key, depth, _c.c_void_p, True)
    try:
        if not value: raise _OwnedInvalidNative("Missing native resource")
        scope.charge("storage", 256)
        return _V.Ticket._from_lease(output.hold(), value)
    finally:
        scope.leave(key)

def _owned_input6(value, scope, depth=0):
    key = _b.id(value)
    scope.enter(key, depth, _OwnedRaw6)
    try:
        if type(value) is not _V.Window: raise TypeError("Expected Window")
        out = scope.value(_OwnedRaw6)
        child = _owned_input7(value.lo, scope, depth + 1)
        if not scope.check_only:
            out.field0 = child
        child = _owned_input7(value.hi, scope, depth + 1)
        if not scope.check_only:
            out.field1 = child
        return out
    finally:
        scope.leave(key)

def _owned_output6(value, scope, output, depth=0):
    key = (6, _c.addressof(value))
    scope.enter(key, depth, _OwnedRaw6, True)
    try:
        scope.charge("storage", 288)
        _R._owned_checkpoint()
        return _V.Window(_owned_output7(value.field0, scope, output, depth + 1), _owned_output7(value.field1, scope, output, depth + 1))
    finally:
        scope.leave(key)

def _owned_input7(value, scope, depth=0):
    key = None
    scope.enter(key, depth, _c.c_void_p)
    try:
        _owned_integer(value, 0, None)
        length = (value.bit_length() + 63) // 64
        scope.charge("native", length, 8)
        scope.charge("storage", length, 16)
        scope.charge("native", _c.sizeof(_OwnedMpz))
        out = scope.value(_OwnedMpz)
        buffer = scope.allocate(_c.c_uint64, length)
        if scope.check_only: return None
        data = abs(value).to_bytes(length * 8, "little")
        if length: _c.memmove(buffer, data, length * 8)
        out.data = _c.addressof(buffer) if length else None
        out.size = -length if value < 0 else length
        return _c.addressof(out)
    finally:
        scope.leave(key)

def _owned_output7(value, scope, output, depth=0):
    if type(value) is _c.c_void_p: value = value.value
    key = None
    scope.enter(key, depth, _c.c_void_p, True)
    try:
        scope.charge("native", _c.sizeof(_OwnedMpz))
        value = _owned_read(value, _OwnedMpz)
        length = abs(value.size)
        if value.size < 0: raise _OwnedInvalidNative("Negative native Nat")
        if value.allocated < 0 or value.allocated != 0 and value.allocated < length: raise _OwnedInvalidNative("Invalid native GMP capacity")
        scope.charge("native", length, 8)
        scope.charge("storage", length, 16)
        pointer = _owned_span(value.data, length, _c.c_uint64)
        _R._owned_checkpoint()
        data = _c.string_at(pointer, length * 8) if length else b""
        if length and int.from_bytes(data[-8:], "little") == 0: raise _OwnedInvalidNative("Noncanonical native GMP integer")
        magnitude = int.from_bytes(data, "little")
        return -magnitude if value.size < 0 else magnitude
    finally:
        scope.leave(key)

def _owned_input8(value, scope, depth=0):
    key = None
    scope.enter(key, depth, _OwnedRaw8)
    try:
        if type(value) is not str: raise TypeError("Expected str")
        length = _owned_text_size(value, scope.native)
        scope.charge("native", length)
        scope.charge("storage", length)
        out = scope.value(_OwnedRaw8)
        buffer = scope.allocate(_c.c_uint8, length)
        if not scope.check_only:
            data = value.encode("utf-8", "strict")
            if length: _c.memmove(buffer, data, length)
            out.data = _c.addressof(buffer) if length else None
            out.length = length
        return out
    finally:
        scope.leave(key)

def _owned_output8(value, scope, output, depth=0):
    key = None
    scope.enter(key, depth, _OwnedRaw8, True)
    try:
        scope.charge("native", value.length)
        scope.charge("storage", value.length, 5)
        pointer = _owned_span(value.data, value.length, _c.c_uint8)
        _R._owned_checkpoint()
        data = _c.string_at(pointer, value.length) if value.length else b""
        try:
            return data.decode("utf-8", "strict")
        except _b.UnicodeDecodeError as error:
            raise _OwnedInvalidNative("Invalid native UTF-8") from error
    finally:
        scope.leave(key)

import inspect as _inspect

class _OwnedCall:
    def __init__(self, state, scope):
        self.state = state
        self.scope = scope
        self.failure = None
        self.alive = True

    def finish(self, status):
        failure, self.failure = self.failure, None
        if failure is not None:
            raise failure
        _R._owned_checked(status)

    def close(self):
        self.alive = False
        self.failure = None

def _owned_require_callback(value):
    if (not callable(value) or _inspect.iscoroutinefunction(value)
            or _inspect.isasyncgenfunction(value)
            or _inspect.iscoroutinefunction(getattr(value, "__call__", None))
            or _inspect.isasyncgenfunction(getattr(value, "__call__", None))):
        raise TypeError("Expected a synchronous callable")

def _owned_synchronous(value):
    if _inspect.isawaitable(value) or _inspect.isasyncgen(value):
        if _inspect.iscoroutine(value):
            value.close()
        raise TypeError("Callbacks must return synchronously")
    return value

_OwnedFunction1 = _c.CFUNCTYPE(_c.c_uint32, _c.c_void_p, _c.c_void_p, _c.POINTER(_OwnedRaw4), _c.POINTER(_OwnedRaw4), _c.POINTER(_c.c_void_p))
class _OwnedHost1(_c.Structure):
    _fields_ = [("call", _OwnedFunction1), ("context", _c.c_void_p), ("closure", _c.c_void_p), ("recovery", _c.POINTER(_OwnedRaw4))]

def _owned_host1(value, scope, frame=None):
    scope.enter(None, 0, _OwnedHost1)
    if type(value) is _V.Callback26621c40b48fce52ca37:
        handle = _owned_input1(value, scope)
        if scope.check_only: return None
        descriptor = scope.value(_OwnedHost1)
        descriptor.closure = handle
        return descriptor
    recovery = None
    wrapped = type(value) is _V.WithRecovery
    if wrapped:
        function, recovery = value.function, value.recovery
    else:
        function = value
    _owned_require_callback(function)
    if wrapped:
        recovery = _owned_input4(recovery, scope)
    if scope.check_only: return None
    descriptor = scope.value(_OwnedHost1)
    if wrapped:
        descriptor.recovery = _c.pointer(recovery)
    def invoke(_context, session, arg0, output, owner):
        incoming = reply_scope = None
        try:
            if not frame.alive or frame.failure is not None: return 10
            state = frame.state
            if state.require().value != session or not output or not owner or owner[0]:
                raise _OwnedInvalidNative("Invalid native callback frame")
            with _R._OwnedBorrowFrame(state) as borrowed:
                incoming = _OwnedScope(state, budget=scope.budget)
                borrowed_output = _OwnedOutput(None, borrowed.lease)
                value0 = _owned_output4(_owned_read(_c.cast(arg0, _c.c_void_p).value, _OwnedRaw4), incoming, borrowed_output)
                reply = _owned_synchronous(function(value0))
                reply_scope = _OwnedScope(state, budget=scope.budget)
                converted = _owned_input4(reply, reply_scope)
                # C owns this reply slot even when Python raises after publication.
                # Snapshot local storage while callback argument borrows are live.
                _R._owned_checked(_fn16(state.require(), _c.byref(converted), output, owner))
                _R._owned_checkpoint()
                return 0
        except BaseException as failure:
            if frame.failure is None: frame.failure = failure
            return 10
        finally:
            if reply_scope is not None: reply_scope.close()
            if incoming is not None: incoming.close()
    _R._owned_checkpoint()
    native = _OwnedFunction1(invoke)
    scope.pin(native)
    descriptor.call = native
    return descriptor

_OwnedFunction2 = _c.CFUNCTYPE(_c.c_uint32, _c.c_void_p, _c.c_void_p, _c.POINTER(_OwnedRaw4), _c.POINTER(_OwnedRaw4), _c.POINTER(_c.c_void_p))
class _OwnedHost2(_c.Structure):
    _fields_ = [("call", _OwnedFunction2), ("context", _c.c_void_p), ("closure", _c.c_void_p), ("recovery", _c.POINTER(_OwnedRaw4))]

def _owned_host2(value, scope, frame=None):
    scope.enter(None, 0, _OwnedHost2)
    if type(value) is _V.Callbackb2d3d6fd4e031785f278:
        handle = _owned_input2(value, scope)
        if scope.check_only: return None
        descriptor = scope.value(_OwnedHost2)
        descriptor.closure = handle
        return descriptor
    recovery = None
    wrapped = type(value) is _V.WithRecovery
    if wrapped:
        function, recovery = value.function, value.recovery
    else:
        function = value
    _owned_require_callback(function)
    if wrapped:
        recovery = _owned_input4(recovery, scope)
    if scope.check_only: return None
    descriptor = scope.value(_OwnedHost2)
    if wrapped:
        descriptor.recovery = _c.pointer(recovery)
    def invoke(_context, session, arg0, output, owner):
        incoming = reply_scope = None
        try:
            if not frame.alive or frame.failure is not None: return 10
            state = frame.state
            if state.require().value != session or not output or not owner or owner[0]:
                raise _OwnedInvalidNative("Invalid native callback frame")
            with _R._OwnedBorrowFrame(state) as borrowed:
                incoming = _OwnedScope(state, budget=scope.budget)
                borrowed_output = _OwnedOutput(None, borrowed.lease)
                value0 = _owned_output4(_owned_read(_c.cast(arg0, _c.c_void_p).value, _OwnedRaw4), incoming, borrowed_output)
                reply = _owned_synchronous(function(value0))
                reply_scope = _OwnedScope(state, budget=scope.budget)
                converted = _owned_input4(reply, reply_scope)
                # C owns this reply slot even when Python raises after publication.
                # Snapshot local storage while callback argument borrows are live.
                _R._owned_checked(_fn16(state.require(), _c.byref(converted), output, owner))
                _R._owned_checkpoint()
                return 0
        except BaseException as failure:
            if frame.failure is None: frame.failure = failure
            return 10
        finally:
            if reply_scope is not None: reply_scope.close()
            if incoming is not None: incoming.close()
    _R._owned_checkpoint()
    native = _OwnedFunction2(invoke)
    scope.pin(native)
    descriptor.call = native
    return descriptor

_runtime = None

def _bind(runtime):
    global _runtime, _fn0, _fn1, _fn2, _fn3, _fn4, _fn5, _fn6, _fn7, _fn8, _fn9, _fn10, _fn11, _fn12, _fn13, _fn14, _fn15, _fn16, _fn17, _fn18, _fn19
    if _runtime is not None: raise RuntimeError('Native adapter is already bound')
    _fn0 = runtime.library["owned_checked_records_claim_closure"]
    _fn0.argtypes = [_c.c_void_p, _c.POINTER(_c.c_void_p), _c.POINTER(_c.c_void_p)]
    _fn0.restype = _c.c_uint32
    _fn1 = runtime.library["owned_checked_records_claim_for"]
    _fn1.argtypes = [_c.c_void_p, _c.c_void_p, _c.POINTER(_OwnedRaw0), _c.POINTER(_c.c_void_p)]
    _fn1.restype = _c.c_uint32
    _fn2 = runtime.library["owned_checked_records_echo_booking"]
    _fn2.argtypes = [_c.c_void_p, _c.POINTER(_OwnedRaw3), _c.POINTER(_OwnedRaw3), _c.POINTER(_c.c_void_p)]
    _fn2.restype = _c.c_uint32
    _fn3 = runtime.library["owned_checked_records_echo_claim"]
    _fn3.argtypes = [_c.c_void_p, _c.POINTER(_OwnedRaw4), _c.POINTER(_OwnedRaw4), _c.POINTER(_c.c_void_p)]
    _fn3.restype = _c.c_uint32
    _fn4 = runtime.library["owned_checked_records_new_ticket"]
    _fn4.argtypes = [_c.c_void_p, _c.c_void_p, _OwnedRaw8, _c.POINTER(_c.c_void_p), _c.POINTER(_c.c_void_p)]
    _fn4.restype = _c.c_uint32
    _fn5 = runtime.library["owned_checked_records_pair_claim"]
    _fn5.argtypes = [_c.c_void_p, _c.POINTER(_OwnedRaw3), _c.POINTER(_OwnedRaw4), _c.POINTER(_OwnedRaw4), _c.POINTER(_c.c_void_p)]
    _fn5.restype = _c.c_uint32
    _fn6 = runtime.library["owned_checked_records_serial"]
    _fn6.argtypes = [_c.c_void_p, _c.c_void_p, _c.POINTER(_c.c_void_p), _c.POINTER(_c.c_void_p)]
    _fn6.restype = _c.c_uint32
    _fn7 = runtime.library["owned_checked_records_transfer_claim"]
    _fn7.argtypes = [_c.c_void_p, _c.POINTER(_OwnedRaw4), _c.POINTER(_c.c_void_p), _c.POINTER(_OwnedRaw4), _c.POINTER(_c.c_void_p)]
    _fn7.restype = _c.c_uint32
    _fn8 = runtime.library["owned_checked_records_with_claim_callback"]
    _fn8.argtypes = [_c.c_void_p, _c.POINTER(_OwnedRaw4), _c.POINTER(_OwnedHost2), _c.POINTER(_OwnedRaw4), _c.POINTER(_c.c_void_p)]
    _fn8.restype = _c.c_uint32
    _fn9 = runtime.library["owned_checked_records_claim_closure_result_t_call"]
    _fn9.argtypes = [_c.c_void_p, _c.c_void_p, _c.POINTER(_OwnedRaw4), _c.POINTER(_OwnedRaw4), _c.POINTER(_c.c_void_p)]
    _fn9.restype = _c.c_uint32
    _fn10 = runtime.library["owned_checked_records_with_claim_callback_argument1_t_call"]
    _fn10.argtypes = [_c.c_void_p, _c.c_void_p, _c.POINTER(_OwnedRaw4), _c.POINTER(_OwnedRaw4), _c.POINTER(_c.c_void_p)]
    _fn10.restype = _c.c_uint32
    _fn11 = runtime.library["owned_checked_records_claim_closure_result_t_retain"]
    _fn11.argtypes = [_c.c_void_p, _c.c_void_p, _c.POINTER(_c.c_void_p), _c.POINTER(_c.c_void_p)]
    _fn11.restype = _c.c_uint32
    _fn12 = runtime.library["owned_checked_records_with_claim_callback_argument1_t_retain"]
    _fn12.argtypes = [_c.c_void_p, _c.c_void_p, _c.POINTER(_c.c_void_p), _c.POINTER(_c.c_void_p)]
    _fn12.restype = _c.c_uint32
    _fn13 = runtime.library["owned_checked_records_ticket_t_retain"]
    _fn13.argtypes = [_c.c_void_p, _c.c_void_p, _c.POINTER(_c.c_void_p), _c.POINTER(_c.c_void_p)]
    _fn13.restype = _c.c_uint32
    _fn14 = runtime.library["owned_checked_records_value_160ce821a84f6887bbfd_t_copy"]
    _fn14.argtypes = [_c.c_void_p, _c.POINTER(_OwnedRaw0), _c.POINTER(_OwnedRaw0), _c.POINTER(_c.c_void_p)]
    _fn14.restype = _c.c_uint32
    _fn15 = runtime.library["owned_checked_records_booking_t_copy"]
    _fn15.argtypes = [_c.c_void_p, _c.POINTER(_OwnedRaw3), _c.POINTER(_OwnedRaw3), _c.POINTER(_c.c_void_p)]
    _fn15.restype = _c.c_uint32
    _fn16 = runtime.library["owned_checked_records_claim_t_copy"]
    _fn16.argtypes = [_c.c_void_p, _c.POINTER(_OwnedRaw4), _c.POINTER(_OwnedRaw4), _c.POINTER(_c.c_void_p)]
    _fn16.restype = _c.c_uint32
    _fn17 = runtime.library["owned_checked_records_window_t_copy"]
    _fn17.argtypes = [_c.c_void_p, _c.POINTER(_OwnedRaw6), _c.POINTER(_OwnedRaw6), _c.POINTER(_c.c_void_p)]
    _fn17.restype = _c.c_uint32
    _fn18 = runtime.library["owned_checked_records_scalar_nat_copy"]
    _fn18.argtypes = [_c.c_void_p, _c.c_void_p, _c.POINTER(_c.c_void_p), _c.POINTER(_c.c_void_p)]
    _fn18.restype = _c.c_uint32
    _fn19 = runtime.library["owned_checked_records_scalar_string_copy"]
    _fn19.argtypes = [_c.c_void_p, _OwnedRaw8, _c.POINTER(_OwnedRaw8), _c.POINTER(_c.c_void_p)]
    _fn19.restype = _c.c_uint32
    _runtime = runtime

def _call0():
    if _runtime is None: raise RuntimeError('Build the native adapter before calling this API')
    state = _runtime.current_state()
    checked = _OwnedScope(state, True)
    try:
        pass
    finally:
        checked.close()
    scope = _OwnedScope(state)
    frame = _OwnedCall(state, scope)
    try:
        raw = scope.value(_c.c_void_p)
        with _R._OwnedNativeOwner(state) as owner:
            status = _fn0(state.require(), _c.byref(raw), _c.byref(owner.value))
            frame.finish(status)
            return _owned_output1(raw, scope, _OwnedOutput(owner))
    except _OwnedInvalidNative:
        _runtime.retire()
        raise
    finally:
        frame.close()
        scope.close()

def _call1(arg0):
    if _runtime is None: raise RuntimeError('Build the native adapter before calling this API')
    state = _runtime.current_state()
    checked = _OwnedScope(state, True)
    try:
        _owned_input5(arg0, checked)
    finally:
        checked.close()
    scope = _OwnedScope(state)
    frame = _OwnedCall(state, scope)
    try:
        input0 = _owned_input5(arg0, scope)
        raw = scope.value(_OwnedRaw0)
        with _R._OwnedNativeOwner(state) as owner:
            status = _fn1(state.require(), input0, _c.byref(raw), _c.byref(owner.value))
            frame.finish(status)
            return _owned_output0(raw, scope, _OwnedOutput(owner))
    except _OwnedInvalidNative:
        _runtime.retire()
        raise
    finally:
        frame.close()
        scope.close()

def _call2(arg0):
    if _runtime is None: raise RuntimeError('Build the native adapter before calling this API')
    state = _runtime.current_state()
    checked = _OwnedScope(state, True)
    try:
        _owned_input3(arg0, checked)
    finally:
        checked.close()
    scope = _OwnedScope(state)
    frame = _OwnedCall(state, scope)
    try:
        input0 = _owned_input3(arg0, scope)
        raw = scope.value(_OwnedRaw3)
        with _R._OwnedNativeOwner(state) as owner:
            status = _fn2(state.require(), _c.byref(input0), _c.byref(raw), _c.byref(owner.value))
            frame.finish(status)
            return _owned_output3(raw, scope, _OwnedOutput(owner))
    except _OwnedInvalidNative:
        _runtime.retire()
        raise
    finally:
        frame.close()
        scope.close()

def _call3(arg0):
    if _runtime is None: raise RuntimeError('Build the native adapter before calling this API')
    state = _runtime.current_state()
    checked = _OwnedScope(state, True)
    try:
        _owned_input4(arg0, checked)
    finally:
        checked.close()
    scope = _OwnedScope(state)
    frame = _OwnedCall(state, scope)
    try:
        input0 = _owned_input4(arg0, scope)
        raw = scope.value(_OwnedRaw4)
        with _R._OwnedNativeOwner(state) as owner:
            status = _fn3(state.require(), _c.byref(input0), _c.byref(raw), _c.byref(owner.value))
            frame.finish(status)
            return _owned_output4(raw, scope, _OwnedOutput(owner))
    except _OwnedInvalidNative:
        _runtime.retire()
        raise
    finally:
        frame.close()
        scope.close()

def _call4(arg0, arg1):
    if _runtime is None: raise RuntimeError('Build the native adapter before calling this API')
    state = _runtime.current_state()
    checked = _OwnedScope(state, True)
    try:
        _owned_input7(arg0, checked)
        _owned_input8(arg1, checked)
    finally:
        checked.close()
    scope = _OwnedScope(state)
    frame = _OwnedCall(state, scope)
    try:
        input0 = _owned_input7(arg0, scope)
        input1 = _owned_input8(arg1, scope)
        raw = scope.value(_c.c_void_p)
        with _R._OwnedNativeOwner(state) as owner:
            status = _fn4(state.require(), input0, input1, _c.byref(raw), _c.byref(owner.value))
            frame.finish(status)
            return _owned_output5(raw, scope, _OwnedOutput(owner))
    except _OwnedInvalidNative:
        _runtime.retire()
        raise
    finally:
        frame.close()
        scope.close()

def _call5(arg0, arg1):
    if _runtime is None: raise RuntimeError('Build the native adapter before calling this API')
    state = _runtime.current_state()
    checked = _OwnedScope(state, True)
    try:
        _owned_input3(arg0, checked)
        _owned_input4(arg1, checked)
    finally:
        checked.close()
    scope = _OwnedScope(state)
    frame = _OwnedCall(state, scope)
    try:
        input0 = _owned_input3(arg0, scope)
        input1 = _owned_input4(arg1, scope)
        raw = scope.value(_OwnedRaw4)
        with _R._OwnedNativeOwner(state) as owner:
            status = _fn5(state.require(), _c.byref(input0), _c.byref(input1), _c.byref(raw), _c.byref(owner.value))
            frame.finish(status)
            return _owned_output4(raw, scope, _OwnedOutput(owner))
    except _OwnedInvalidNative:
        _runtime.retire()
        raise
    finally:
        frame.close()
        scope.close()

def _call6(arg0):
    if _runtime is None: raise RuntimeError('Build the native adapter before calling this API')
    state = _runtime.current_state()
    checked = _OwnedScope(state, True)
    try:
        _owned_input5(arg0, checked)
    finally:
        checked.close()
    scope = _OwnedScope(state)
    frame = _OwnedCall(state, scope)
    try:
        input0 = _owned_input5(arg0, scope)
        raw = scope.value(_c.c_void_p)
        with _R._OwnedNativeOwner(state) as owner:
            status = _fn6(state.require(), input0, _c.byref(raw), _c.byref(owner.value))
            frame.finish(status)
            return _owned_output7(raw, scope, _OwnedOutput(owner))
    except _OwnedInvalidNative:
        _runtime.retire()
        raise
    finally:
        frame.close()
        scope.close()

def _call7(arg0):
    if _runtime is None: raise RuntimeError('Build the native adapter before calling this API')
    state = _runtime.current_state()
    checked = _OwnedScope(state, True)
    try:
        _owned_input4(arg0, checked)
    finally:
        checked.close()
    scope = _OwnedScope(state)
    frame = _OwnedCall(state, scope)
    moves = None
    try:
        moves = _OwnedInputTransfers(state, 1, scope)
        scope.moves = moves
        scope.move_group = 0
        input0 = _owned_input4(arg0, scope)
        scope.move_group = None
        moved0 = scope.value(_OwnedRaw4)
        _R._owned_checked(_fn16(state.require(), _c.byref(input0), _c.byref(moved0), _c.byref(moves.owners[0].value)))
        raw = scope.value(_OwnedRaw4)
        with _R._OwnedNativeOwner(state) as owner:
            session = state.require()
            moves.arm()
            try:
                status = _fn7(session, _c.byref(moved0), _c.byref(moves.owners[0].value), _c.byref(raw), _c.byref(owner.value))
            finally:
                moves.finish()
            frame.finish(status)
            return _owned_output4(raw, scope, _OwnedOutput(owner))
    except _OwnedInvalidNative:
        _runtime.retire()
        raise
    finally:
        if moves is not None: moves.close()
        frame.close()
        scope.close()

def _call8(arg0, arg1):
    if _runtime is None: raise RuntimeError('Build the native adapter before calling this API')
    state = _runtime.current_state()
    checked = _OwnedScope(state, True)
    try:
        _owned_input4(arg0, checked)
        _owned_host2(arg1, checked)
    finally:
        checked.close()
    scope = _OwnedScope(state)
    frame = _OwnedCall(state, scope)
    try:
        input0 = _owned_input4(arg0, scope)
        input1 = _owned_host2(arg1, scope, frame)
        raw = scope.value(_OwnedRaw4)
        with _R._OwnedNativeOwner(state) as owner:
            status = _fn8(state.require(), _c.byref(input0), _c.byref(input1), _c.byref(raw), _c.byref(owner.value))
            frame.finish(status)
            return _owned_output4(raw, scope, _OwnedOutput(owner))
    except _OwnedInvalidNative:
        _runtime.retire()
        raise
    finally:
        frame.close()
        scope.close()

def _invoke1(arg0, arg1):
    if _runtime is None: raise RuntimeError('Build the native adapter before calling this API')
    state = _runtime.current_state()
    checked = _OwnedScope(state, True)
    try:
        _owned_input1(arg0, checked)
        _owned_input4(arg1, checked)
    finally:
        checked.close()
    scope = _OwnedScope(state)
    frame = _OwnedCall(state, scope)
    try:
        input0 = _owned_input1(arg0, scope)
        input1 = _owned_input4(arg1, scope)
        raw = scope.value(_OwnedRaw4)
        with _R._OwnedNativeOwner(state) as owner:
            status = _fn9(state.require(), input0, _c.byref(input1), _c.byref(raw), _c.byref(owner.value))
            frame.finish(status)
            return _owned_output4(raw, scope, _OwnedOutput(owner))
    except _OwnedInvalidNative:
        _runtime.retire()
        raise
    finally:
        frame.close()
        scope.close()

def _invoke2(arg0, arg1):
    if _runtime is None: raise RuntimeError('Build the native adapter before calling this API')
    state = _runtime.current_state()
    checked = _OwnedScope(state, True)
    try:
        _owned_input2(arg0, checked)
        _owned_input4(arg1, checked)
    finally:
        checked.close()
    scope = _OwnedScope(state)
    frame = _OwnedCall(state, scope)
    try:
        input0 = _owned_input2(arg0, scope)
        input1 = _owned_input4(arg1, scope)
        raw = scope.value(_OwnedRaw4)
        with _R._OwnedNativeOwner(state) as owner:
            status = _fn10(state.require(), input0, _c.byref(input1), _c.byref(raw), _c.byref(owner.value))
            frame.finish(status)
            return _owned_output4(raw, scope, _OwnedOutput(owner))
    except _OwnedInvalidNative:
        _runtime.retire()
        raise
    finally:
        frame.close()
        scope.close()

def _retain1(arg0):
    if _runtime is None: raise RuntimeError('Build the native adapter before calling this API')
    state = _runtime.current_state()
    checked = _OwnedScope(state, True)
    try:
        _owned_input1(arg0, checked)
    finally:
        checked.close()
    scope = _OwnedScope(state)
    frame = _OwnedCall(state, scope)
    try:
        input0 = _owned_input1(arg0, scope)
        raw = scope.value(_c.c_void_p)
        with _R._OwnedNativeOwner(state) as owner:
            status = _fn11(state.require(), input0, _c.byref(raw), _c.byref(owner.value))
            frame.finish(status)
            return _owned_output1(raw, scope, _OwnedOutput(owner))
    except _OwnedInvalidNative:
        _runtime.retire()
        raise
    finally:
        frame.close()
        scope.close()

def _retain2(arg0):
    if _runtime is None: raise RuntimeError('Build the native adapter before calling this API')
    state = _runtime.current_state()
    checked = _OwnedScope(state, True)
    try:
        _owned_input2(arg0, checked)
    finally:
        checked.close()
    scope = _OwnedScope(state)
    frame = _OwnedCall(state, scope)
    try:
        input0 = _owned_input2(arg0, scope)
        raw = scope.value(_c.c_void_p)
        with _R._OwnedNativeOwner(state) as owner:
            status = _fn12(state.require(), input0, _c.byref(raw), _c.byref(owner.value))
            frame.finish(status)
            return _owned_output2(raw, scope, _OwnedOutput(owner))
    except _OwnedInvalidNative:
        _runtime.retire()
        raise
    finally:
        frame.close()
        scope.close()

def _retain5(arg0):
    if _runtime is None: raise RuntimeError('Build the native adapter before calling this API')
    state = _runtime.current_state()
    checked = _OwnedScope(state, True)
    try:
        _owned_input5(arg0, checked)
    finally:
        checked.close()
    scope = _OwnedScope(state)
    frame = _OwnedCall(state, scope)
    try:
        input0 = _owned_input5(arg0, scope)
        raw = scope.value(_c.c_void_p)
        with _R._OwnedNativeOwner(state) as owner:
            status = _fn13(state.require(), input0, _c.byref(raw), _c.byref(owner.value))
            frame.finish(status)
            return _owned_output5(raw, scope, _OwnedOutput(owner))
    except _OwnedInvalidNative:
        _runtime.retire()
        raise
    finally:
        frame.close()
        scope.close()

def _copy0(arg0):
    if _runtime is None: raise RuntimeError('Build the native adapter before calling this API')
    state = _runtime.current_state()
    checked = _OwnedScope(state, True)
    try:
        _owned_input0(arg0, checked)
    finally:
        checked.close()
    scope = _OwnedScope(state)
    frame = _OwnedCall(state, scope)
    try:
        input0 = _owned_input0(arg0, scope)
        raw = scope.value(_OwnedRaw0)
        with _R._OwnedNativeOwner(state) as owner:
            status = _fn14(state.require(), _c.byref(input0), _c.byref(raw), _c.byref(owner.value))
            frame.finish(status)
            return _owned_output0(raw, scope, _OwnedOutput(owner))
    except _OwnedInvalidNative:
        _runtime.retire()
        raise
    finally:
        frame.close()
        scope.close()

def _copy3(arg0):
    if _runtime is None: raise RuntimeError('Build the native adapter before calling this API')
    state = _runtime.current_state()
    checked = _OwnedScope(state, True)
    try:
        _owned_input3(arg0, checked)
    finally:
        checked.close()
    scope = _OwnedScope(state)
    frame = _OwnedCall(state, scope)
    try:
        input0 = _owned_input3(arg0, scope)
        raw = scope.value(_OwnedRaw3)
        with _R._OwnedNativeOwner(state) as owner:
            status = _fn15(state.require(), _c.byref(input0), _c.byref(raw), _c.byref(owner.value))
            frame.finish(status)
            return _owned_output3(raw, scope, _OwnedOutput(owner))
    except _OwnedInvalidNative:
        _runtime.retire()
        raise
    finally:
        frame.close()
        scope.close()

def _copy4(arg0):
    if _runtime is None: raise RuntimeError('Build the native adapter before calling this API')
    state = _runtime.current_state()
    checked = _OwnedScope(state, True)
    try:
        _owned_input4(arg0, checked)
    finally:
        checked.close()
    scope = _OwnedScope(state)
    frame = _OwnedCall(state, scope)
    try:
        input0 = _owned_input4(arg0, scope)
        raw = scope.value(_OwnedRaw4)
        with _R._OwnedNativeOwner(state) as owner:
            status = _fn16(state.require(), _c.byref(input0), _c.byref(raw), _c.byref(owner.value))
            frame.finish(status)
            return _owned_output4(raw, scope, _OwnedOutput(owner))
    except _OwnedInvalidNative:
        _runtime.retire()
        raise
    finally:
        frame.close()
        scope.close()

def _copy6(arg0):
    if _runtime is None: raise RuntimeError('Build the native adapter before calling this API')
    state = _runtime.current_state()
    checked = _OwnedScope(state, True)
    try:
        _owned_input6(arg0, checked)
    finally:
        checked.close()
    scope = _OwnedScope(state)
    frame = _OwnedCall(state, scope)
    try:
        input0 = _owned_input6(arg0, scope)
        raw = scope.value(_OwnedRaw6)
        with _R._OwnedNativeOwner(state) as owner:
            status = _fn17(state.require(), _c.byref(input0), _c.byref(raw), _c.byref(owner.value))
            frame.finish(status)
            return _owned_output6(raw, scope, _OwnedOutput(owner))
    except _OwnedInvalidNative:
        _runtime.retire()
        raise
    finally:
        frame.close()
        scope.close()

def _copy7(arg0):
    if _runtime is None: raise RuntimeError('Build the native adapter before calling this API')
    state = _runtime.current_state()
    checked = _OwnedScope(state, True)
    try:
        _owned_input7(arg0, checked)
    finally:
        checked.close()
    scope = _OwnedScope(state)
    frame = _OwnedCall(state, scope)
    try:
        input0 = _owned_input7(arg0, scope)
        raw = scope.value(_c.c_void_p)
        with _R._OwnedNativeOwner(state) as owner:
            status = _fn18(state.require(), input0, _c.byref(raw), _c.byref(owner.value))
            frame.finish(status)
            return _owned_output7(raw, scope, _OwnedOutput(owner))
    except _OwnedInvalidNative:
        _runtime.retire()
        raise
    finally:
        frame.close()
        scope.close()

def _copy8(arg0):
    if _runtime is None: raise RuntimeError('Build the native adapter before calling this API')
    state = _runtime.current_state()
    checked = _OwnedScope(state, True)
    try:
        _owned_input8(arg0, checked)
    finally:
        checked.close()
    scope = _OwnedScope(state)
    frame = _OwnedCall(state, scope)
    try:
        input0 = _owned_input8(arg0, scope)
        raw = scope.value(_OwnedRaw8)
        with _R._OwnedNativeOwner(state) as owner:
            status = _fn19(state.require(), input0, _c.byref(raw), _c.byref(owner.value))
            frame.finish(status)
            return _owned_output8(raw, scope, _OwnedOutput(owner))
    except _OwnedInvalidNative:
        _runtime.retire()
        raise
    finally:
        frame.close()
        scope.close()

from . import _assets as _Assets
_bind(_R._OwnedRuntime(_Assets._LIBRARY, _Assets._ensure_process))
