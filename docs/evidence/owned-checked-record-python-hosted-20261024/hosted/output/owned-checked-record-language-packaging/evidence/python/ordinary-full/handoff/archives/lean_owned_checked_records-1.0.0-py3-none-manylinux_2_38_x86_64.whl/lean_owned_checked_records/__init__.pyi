from __future__ import annotations
from dataclasses import dataclass as _dataclass
from typing import ClassVar as _ClassVar, Literal as _Literal, TypeAlias as _TypeAlias, Never as _Never

__all__ = ("Some", "Option", "Callback26621c40b48fce52ca37", "Callbackb2d3d6fd4e031785f278", "Booking", "Claim", "Ticket", "Window", "LeanBridgeError", "WithRecovery", "with_recovery", "claim_closure", "claim_for", "echo_booking", "echo_claim", "new_ticket", "pair_claim", "serial", "transfer_claim", "with_claim_callback",)

from typing import Generic as _Generic, TypeVar as _TypeVar

_T = _TypeVar("_T", covariant=True)
_E = _TypeVar("_E", covariant=True)

@_dataclass(frozen=True)
class Some(_Generic[_T]):
    value: _T

Option = Some[_T] | None


class LeanBridgeError(RuntimeError):
    status: int
    def __init__(self, status: int, message: str | None = None) -> None: ...

from typing import Callable as _Callable, Generic as _Generic, ParamSpec as _ParamSpec, TypeVar as _TypeVar
_CallbackArgs = _ParamSpec("_CallbackArgs")
_CallbackReturn = _TypeVar("_CallbackReturn")

@_dataclass(frozen=True, slots=True)
class WithRecovery(_Generic[_CallbackArgs, _CallbackReturn]):
    function: _Callable[_CallbackArgs, _CallbackReturn]
    recovery: _CallbackReturn

def with_recovery(function: _Callable[_CallbackArgs, _CallbackReturn], recovery: _CallbackReturn) -> WithRecovery[_CallbackArgs, _CallbackReturn]:
    ...

class Callback26621c40b48fce52ca37:
    __slots__ = ()
    def __init__(self, _forbidden: _Never) -> None: ...
    @property
    def is_closed(self) -> bool: ...
    def close(self) -> None: ...
    def __enter__(self) -> Callback26621c40b48fce52ca37: ...
    def __exit__(self, *args: object) -> None: ...
    def retain(self) -> Callback26621c40b48fce52ca37:
        ...
    def __call__(self, arg0: Claim) -> Claim:
        ...

class Callbackb2d3d6fd4e031785f278:
    __slots__ = ()
    def __init__(self, _forbidden: _Never) -> None: ...
    @property
    def is_closed(self) -> bool: ...
    def close(self) -> None: ...
    def __enter__(self) -> Callbackb2d3d6fd4e031785f278: ...
    def __exit__(self, *args: object) -> None: ...
    def retain(self) -> Callbackb2d3d6fd4e031785f278:
        ...
    def __call__(self, arg0: Claim) -> Claim:
        ...

@_dataclass(frozen=True, slots=True)
class Booking:
    holder: Ticket
    window: Window

@_dataclass(frozen=True, slots=True)
class Claim:
    holder: Ticket
    quota: int

class Ticket:
    __slots__ = ()
    def __init__(self, _forbidden: _Never) -> None: ...
    @property
    def is_closed(self) -> bool: ...
    def close(self) -> None: ...
    def __enter__(self) -> Ticket: ...
    def __exit__(self, *args: object) -> None: ...
    def retain(self) -> Ticket:
        ...

@_dataclass(frozen=True, slots=True)
class Window:
    lo: int
    hi: int

_Value0: _TypeAlias = Option[Claim]
_Input0: _TypeAlias = Option[Claim]
_CallbackInput1: _TypeAlias = Callback26621c40b48fce52ca37 | _Callable[["Claim"], Claim] | WithRecovery[["Claim"], Claim]
_CallbackInput2: _TypeAlias = Callbackb2d3d6fd4e031785f278 | _Callable[["Claim"], Claim] | WithRecovery[["Claim"], Claim]

def claim_closure() -> Callback26621c40b48fce52ca37:
    ...

def claim_for(arg0: Ticket) -> _Value0:
    ...

def echo_booking(arg0: Booking) -> Booking:
    ...

def echo_claim(arg0: Claim) -> Claim:
    ...

def new_ticket(arg0: int, arg1: str) -> Ticket:
    ...

def pair_claim(arg0: Booking, arg1: Claim) -> Claim:
    ...

def serial(arg0: Ticket) -> int:
    ...

def transfer_claim(arg0: Claim) -> Claim:
    """Consume resource leases in arg0 at the Lean call boundary.

    Shared aliases close at handoff; independently retained owners stay usable.
    Validation and preparation failures preserve ownership. Failures after
    handoff leave inputs consumed. Callback borrows must be retained first.
    """
    ...

def with_claim_callback(arg0: Claim, arg1: _CallbackInput2) -> Claim:
    ...
