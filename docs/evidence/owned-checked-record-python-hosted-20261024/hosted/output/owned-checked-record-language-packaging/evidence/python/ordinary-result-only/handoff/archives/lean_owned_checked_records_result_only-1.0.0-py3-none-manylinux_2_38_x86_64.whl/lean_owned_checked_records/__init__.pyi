from __future__ import annotations
from dataclasses import dataclass as _dataclass
from typing import ClassVar as _ClassVar, Literal as _Literal, TypeAlias as _TypeAlias, Never as _Never

__all__ = ("Some", "Option", "Claim", "Ticket", "LeanBridgeError", "claim_for", "new_ticket", "serial",)

from typing import Generic as _Generic, TypeVar as _TypeVar

_T = _TypeVar("_T", covariant=True)
_E = _TypeVar("_E", covariant=True)

@_dataclass(frozen=True)
class Some(_Generic[_T]):
    value: _T

Option = Some[_T] | None


class LeanBridgeError(RuntimeError):
    status: int
    def __init__(self, status: int, message: str | None = None) -> None: ...

@_dataclass(frozen=True, slots=True)
class Claim:
    holder: Ticket
    quota: int

class Ticket:
    __slots__ = ()
    def __init__(self, _forbidden: _Never) -> None: ...
    @property
    def is_closed(self) -> bool: ...
    def close(self) -> None: ...
    def __enter__(self) -> Ticket: ...
    def __exit__(self, *args: object) -> None: ...
    def retain(self) -> Ticket:
        ...

_Value0: _TypeAlias = Option[Claim]
_Input0: _TypeAlias = Option[Claim]

def claim_for(arg0: Ticket) -> _Value0:
    ...

def new_ticket(arg0: int, arg1: str) -> Ticket:
    ...

def serial(arg0: Ticket) -> int:
    ...
