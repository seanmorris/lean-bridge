#pragma once
#include "owned_checked_records.h"
_Static_assert(sizeof(void*) == 8 && sizeof(size_t) == 8 && sizeof(bool) == 1, "Owned Python requires the Linux x86-64 C ABI");
_Static_assert(GMP_NUMB_BITS == 64 && sizeof(mp_limb_t) == 8 && sizeof(int) == 4, "Owned Python requires nail-free 64-bit GMP limbs");
_Static_assert(sizeof(__mpz_struct) == 16 && _Alignof(__mpz_struct) == 8 && offsetof(__mpz_struct, _mp_alloc) == 0 && offsetof(__mpz_struct, _mp_size) == 4 && offsetof(__mpz_struct, _mp_d) == 8, "Owned Python GMP layout");
_Static_assert(sizeof(owned_checked_records_status) == 4, "Owned Python status layout");

