#include "component.h"
#include "lean_bridge_native_runtime.h"
static _Thread_local int lean_bridge_owned_callback_failure_5752f07bf685c55d0351_state;
int lean_bridge_owned_callback_failure_5752f07bf685c55d0351(void) { int result = lean_bridge_owned_callback_failure_5752f07bf685c55d0351_state; lean_bridge_owned_callback_failure_5752f07bf685c55d0351_state = 0; return result; }
