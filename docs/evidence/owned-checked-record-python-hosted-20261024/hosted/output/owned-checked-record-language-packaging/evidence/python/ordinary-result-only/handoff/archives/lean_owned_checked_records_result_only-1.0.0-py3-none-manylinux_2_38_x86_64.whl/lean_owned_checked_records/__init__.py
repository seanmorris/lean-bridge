from __future__ import annotations
from dataclasses import dataclass as _dataclass
from typing import ClassVar as _ClassVar, Literal as _Literal, TypeAlias as _TypeAlias, Never as _Never
from ._owned import _OwnedResource, LeanBridgeError

try:
    from typing import TypeAliasType as _TypeAliasType
except ImportError:
    from typing_extensions import TypeAliasType as _TypeAliasType

__all__ = ("Some", "Option", "Claim", "Ticket", "LeanBridgeError", "claim_for", "new_ticket", "serial",)

from typing import Generic as _Generic, TypeVar as _TypeVar

_T = _TypeVar("_T", covariant=True)
_E = _TypeVar("_E", covariant=True)

@_dataclass(frozen=True)
class Some(_Generic[_T]):
    value: _T

Option = Some[_T] | None


@_dataclass(frozen=True, slots=True)
class Claim:
    holder: Ticket
    quota: int

class Ticket(_OwnedResource):
    __slots__ = ()
    def retain(self) -> Ticket:
        from . import _native
        return _native._retain2(self)

_Value0 = _TypeAliasType("_Value0", Option[Claim])
_Input0 = _TypeAliasType("_Input0", Option[Claim])

def claim_for(arg0: Ticket) -> _Value0:
    from . import _native
    return _native._call0(arg0)

def new_ticket(arg0: int, arg1: str) -> Ticket:
    from . import _native
    return _native._call1(arg0, arg1)

def serial(arg0: Ticket) -> int:
    from . import _native
    return _native._call2(arg0)

from . import _native as _OwnedNative
