#include "component.h"
#include "lean_bridge_native_runtime.h"
static _Thread_local int lean_bridge_owned_callback_failure_093a4742ed19e227a2da_state;
int lean_bridge_owned_callback_failure_093a4742ed19e227a2da(void) { int result = lean_bridge_owned_callback_failure_093a4742ed19e227a2da_state; lean_bridge_owned_callback_failure_093a4742ed19e227a2da_state = 0; return result; }
