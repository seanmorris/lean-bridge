# nestedcheckedrecords

Compiler-checked exports for nestedcheckedrecords.

Binding IR SHA-256: `65fe883f76fbd604d547d00b4fa1a86fbe04a7d3e1a320b7f0a4253bf1ab30f8`

## Exports

### produceArray

Call NestedCheckedRecords.produceArray.

### produceOption

Lean-produced checked records need no input constructor. 

## Assurance

