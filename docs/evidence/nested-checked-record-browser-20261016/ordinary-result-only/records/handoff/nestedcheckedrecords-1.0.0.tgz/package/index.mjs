// Generated from Binding IR SHA-256 65fe883f76fbd604d547d00b4fa1a86fbe04a7d3e1a320b7f0a4253bf1ab30f8.
import { runtime } from "./internal/runtime.mjs";
import * as validate from "./internal/validators.mjs";

/**
 * Call NestedCheckedRecords.produceArray.
 */
export function produceArray(arg0) {
  validate.assertNat(arg0, "produceArray.arg0");
  const result = runtime.call("lean:NestedCheckedRecords.produceArray", [arg0]);
  validate.assertArrayOfPacket(result, "produceArray.result");
  validate.assertNestedFin(result, {"arguments":[{"constructor":null,"fields":[{"name":"digit","refinement":{"bound":"10","kind":"fin"}},{"name":"word","refinement":{"constructor":null,"kind":"subtype"}}],"kind":"checked-record","name":"NestedCheckedRecords.Packet"}],"kind":"array"}, "produceArray.result");
  return result;
}

/**
 * Lean-produced checked records need no input constructor. 
 */
export function produceOption(arg0) {
  validate.assertNat(arg0, "produceOption.arg0");
  const result = runtime.call("lean:NestedCheckedRecords.produceOption", [arg0]);
  validate.assertApplied$89f4af26eabc1bd0097b(result, "produceOption.result");
  validate.assertNestedFin(result, {"arguments":[{"constructor":null,"fields":[{"name":"digit","refinement":{"bound":"10","kind":"fin"}},{"name":"word","refinement":{"constructor":null,"kind":"subtype"}}],"kind":"checked-record","name":"NestedCheckedRecords.Packet"}],"kind":"option"}, "produceOption.result");
  return result;
}

export default Object.freeze({ produceArray, produceOption });
