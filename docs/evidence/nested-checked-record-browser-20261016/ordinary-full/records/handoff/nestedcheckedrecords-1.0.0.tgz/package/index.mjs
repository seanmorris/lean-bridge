// Generated from Binding IR SHA-256 4674b92e2e4e6598389449b2160426cc19400876f4f0aa8aff7ddf2cb3c0b05f.
import { runtime } from "./internal/runtime.mjs";
import * as validate from "./internal/validators.mjs";

/**
 * Call NestedCheckedRecords.echoArray.
 */
export function echoArray(arg0) {
  validate.assertArrayOfPacket(arg0, "echoArray.arg0");
  validate.assertNestedFin(arg0, {"arguments":[{"constructor":"NestedCheckedRecords.mkPacket","fields":[{"name":"digit","refinement":{"bound":"10","kind":"fin"}},{"name":"word","refinement":{"constructor":"NestedCheckedRecords.mkWord","kind":"subtype"}}],"kind":"checked-record","name":"NestedCheckedRecords.Packet"}],"kind":"array"}, "echoArray.arg0");
  const result = runtime.call("lean:NestedCheckedRecords.echoArray", [arg0]);
  validate.assertArrayOfPacket(result, "echoArray.result");
  validate.assertNestedFin(result, {"arguments":[{"constructor":null,"fields":[{"name":"digit","refinement":{"bound":"10","kind":"fin"}},{"name":"word","refinement":{"constructor":null,"kind":"subtype"}}],"kind":"checked-record","name":"NestedCheckedRecords.Packet"}],"kind":"array"}, "echoArray.result");
  return result;
}

/**
 * Call NestedCheckedRecords.first.
 */
export function first(arg0) {
  validate.assertPacket(arg0, "first.arg0");
  const result = runtime.call("lean:NestedCheckedRecords.first", [arg0]);
  validate.assertNat(result, "first.result");
  return result;
}

/**
 * Call NestedCheckedRecords.inArray.
 */
export function inArray(arg0) {
  validate.assertArrayOfPacket(arg0, "inArray.arg0");
  validate.assertNestedFin(arg0, {"arguments":[{"constructor":"NestedCheckedRecords.mkPacket","fields":[{"name":"digit","refinement":{"bound":"10","kind":"fin"}},{"name":"word","refinement":{"constructor":"NestedCheckedRecords.mkWord","kind":"subtype"}}],"kind":"checked-record","name":"NestedCheckedRecords.Packet"}],"kind":"array"}, "inArray.arg0");
  const result = runtime.call("lean:NestedCheckedRecords.inArray", [arg0]);
  validate.assertNat(result, "inArray.result");
  return result;
}

/**
 * Call NestedCheckedRecords.inChoice.
 */
export function inChoice(arg0) {
  validate.assertChoice(arg0, "inChoice.arg0");
  validate.assertNestedFin(arg0, {"cases":[{"fields":[],"name":"empty"},{"fields":[{"name":"value","refinement":{"constructor":"NestedCheckedRecords.mkPacket","fields":[{"name":"digit","refinement":{"bound":"10","kind":"fin"}},{"name":"word","refinement":{"constructor":"NestedCheckedRecords.normalizeWord","kind":"subtype"}}],"kind":"checked-record","name":"NestedCheckedRecords.Packet"}}],"name":"packet"}],"kind":"variant","name":"NestedCheckedRecords.Choice"}, "inChoice.arg0");
  const result = runtime.call("lean:NestedCheckedRecords.inChoice", [arg0]);
  validate.assertNat(result, "inChoice.result");
  return result;
}

/**
 * Call NestedCheckedRecords.inExcept.
 */
export function inExcept(arg0) {
  validate.assertApplied$0e2a29b3f850af87e372(arg0, "inExcept.arg0");
  validate.assertNestedFin(arg0, {"arguments":[{"constructor":"NestedCheckedRecords.normalizePacket","fields":[{"name":"digit","refinement":{"bound":"10","kind":"fin"}},{"name":"word","refinement":{"constructor":"NestedCheckedRecords.mkWord","kind":"subtype"}}],"kind":"checked-record","name":"NestedCheckedRecords.Packet"},{"constructor":"NestedCheckedRecords.mkPacket","fields":[{"name":"digit","refinement":{"bound":"10","kind":"fin"}},{"name":"word","refinement":{"constructor":"NestedCheckedRecords.normalizeWord","kind":"subtype"}}],"kind":"checked-record","name":"NestedCheckedRecords.Packet"}],"kind":"result"}, "inExcept.arg0");
  const result = runtime.call("lean:NestedCheckedRecords.inExcept", [arg0]);
  validate.assertNat(result, "inExcept.result");
  return result;
}

/**
 * Call NestedCheckedRecords.inHolder.
 */
export function inHolder(arg0) {
  validate.assertHolder(arg0, "inHolder.arg0");
  validate.assertNestedFin(arg0, {"fields":[{"name":"packet","refinement":{"constructor":"NestedCheckedRecords.normalizePacket","fields":[{"name":"digit","refinement":{"bound":"10","kind":"fin"}},{"name":"word","refinement":{"constructor":"NestedCheckedRecords.mkWord","kind":"subtype"}}],"kind":"checked-record","name":"NestedCheckedRecords.Packet"}},{"name":"tag","refinement":null}],"kind":"record","name":"NestedCheckedRecords.Holder"}, "inHolder.arg0");
  const result = runtime.call("lean:NestedCheckedRecords.inHolder", [arg0]);
  validate.assertNat(result, "inHolder.result");
  return result;
}

/**
 * Call NestedCheckedRecords.inList.
 */
export function inList(arg0) {
  validate.assertApplied$c7bfdeec07c5a7037c6e(arg0, "inList.arg0");
  validate.assertNestedFin(arg0, {"arguments":[{"constructor":"NestedCheckedRecords.normalizePacket","fields":[{"name":"digit","refinement":{"bound":"10","kind":"fin"}},{"name":"word","refinement":{"constructor":"NestedCheckedRecords.normalizeWord","kind":"subtype"}}],"kind":"checked-record","name":"NestedCheckedRecords.Packet"}],"kind":"list"}, "inList.arg0");
  const result = runtime.call("lean:NestedCheckedRecords.inList", [arg0]);
  validate.assertNat(result, "inList.result");
  return result;
}

/**
 * Call NestedCheckedRecords.inOption.
 */
export function inOption(arg0) {
  validate.assertApplied$89f4af26eabc1bd0097b(arg0, "inOption.arg0");
  validate.assertNestedFin(arg0, {"arguments":[{"constructor":"NestedCheckedRecords.mkPacket","fields":[{"name":"digit","refinement":{"bound":"10","kind":"fin"}},{"name":"word","refinement":{"constructor":"NestedCheckedRecords.normalizeWord","kind":"subtype"}}],"kind":"checked-record","name":"NestedCheckedRecords.Packet"}],"kind":"option"}, "inOption.arg0");
  const result = runtime.call("lean:NestedCheckedRecords.inOption", [arg0]);
  validate.assertNat(result, "inOption.result");
  return result;
}

/**
 * Call NestedCheckedRecords.inProduct.
 */
export function inProduct(arg0) {
  validate.assertApplied$85e8986f8f61f064336a(arg0, "inProduct.arg0");
  validate.assertNestedFin(arg0, {"arguments":[{"constructor":"NestedCheckedRecords.mkPacket","fields":[{"name":"digit","refinement":{"bound":"10","kind":"fin"}},{"name":"word","refinement":{"constructor":"NestedCheckedRecords.mkWord","kind":"subtype"}}],"kind":"checked-record","name":"NestedCheckedRecords.Packet"},{"constructor":"NestedCheckedRecords.normalizePacket","fields":[{"name":"digit","refinement":{"bound":"10","kind":"fin"}},{"name":"word","refinement":{"constructor":"NestedCheckedRecords.normalizeWord","kind":"subtype"}}],"kind":"checked-record","name":"NestedCheckedRecords.Packet"}],"kind":"tuple"}, "inProduct.arg0");
  const result = runtime.call("lean:NestedCheckedRecords.inProduct", [arg0]);
  validate.assertNat(result, "inProduct.result");
  return result;
}

/**
 * Call NestedCheckedRecords.pair.
 */
export function pair(arg0, arg1) {
  validate.assertPacket(arg0, "pair.arg0");
  validate.assertPacket(arg1, "pair.arg1");
  const result = runtime.call("lean:NestedCheckedRecords.pair", [arg0, arg1]);
  validate.assertNat(result, "pair.result");
  return result;
}

/**
 * Call NestedCheckedRecords.produceArray.
 */
export function produceArray(arg0) {
  validate.assertNat(arg0, "produceArray.arg0");
  const result = runtime.call("lean:NestedCheckedRecords.produceArray", [arg0]);
  validate.assertArrayOfPacket(result, "produceArray.result");
  validate.assertNestedFin(result, {"arguments":[{"constructor":null,"fields":[{"name":"digit","refinement":{"bound":"10","kind":"fin"}},{"name":"word","refinement":{"constructor":null,"kind":"subtype"}}],"kind":"checked-record","name":"NestedCheckedRecords.Packet"}],"kind":"array"}, "produceArray.result");
  return result;
}

/**
 * Lean-produced checked records need no input constructor. 
 */
export function produceOption(arg0) {
  validate.assertNat(arg0, "produceOption.arg0");
  const result = runtime.call("lean:NestedCheckedRecords.produceOption", [arg0]);
  validate.assertApplied$89f4af26eabc1bd0097b(result, "produceOption.result");
  validate.assertNestedFin(result, {"arguments":[{"constructor":null,"fields":[{"name":"digit","refinement":{"bound":"10","kind":"fin"}},{"name":"word","refinement":{"constructor":null,"kind":"subtype"}}],"kind":"checked-record","name":"NestedCheckedRecords.Packet"}],"kind":"option"}, "produceOption.result");
  return result;
}

/**
 * Call NestedCheckedRecords.second.
 */
export function second(arg0) {
  validate.assertPacket(arg0, "second.arg0");
  const result = runtime.call("lean:NestedCheckedRecords.second", [arg0]);
  validate.assertNat(result, "second.result");
  return result;
}

export default Object.freeze({ echoArray, first, inArray, inChoice, inExcept, inHolder, inList, inOption, inProduct, pair, produceArray, produceOption, second });
