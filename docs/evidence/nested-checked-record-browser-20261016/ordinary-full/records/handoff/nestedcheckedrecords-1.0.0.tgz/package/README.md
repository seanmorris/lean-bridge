# nestedcheckedrecords

Compiler-checked exports for nestedcheckedrecords.

Binding IR SHA-256: `4674b92e2e4e6598389449b2160426cc19400876f4f0aa8aff7ddf2cb3c0b05f`

## Exports

### echoArray

Call NestedCheckedRecords.echoArray.

### first

Call NestedCheckedRecords.first.

### inArray

Call NestedCheckedRecords.inArray.

### inChoice

Call NestedCheckedRecords.inChoice.

### inExcept

Call NestedCheckedRecords.inExcept.

### inHolder

Call NestedCheckedRecords.inHolder.

### inList

Call NestedCheckedRecords.inList.

### inOption

Call NestedCheckedRecords.inOption.

### inProduct

Call NestedCheckedRecords.inProduct.

### pair

Call NestedCheckedRecords.pair.

### produceArray

Call NestedCheckedRecords.produceArray.

### produceOption

Lean-produced checked records need no input constructor. 

### second

Call NestedCheckedRecords.second.

## Assurance

