// Generated copied-value validators. This file is package-internal.
const invalid = (path, expected) => { throw new TypeError(`${path} must be ${expected}`); };
export const assertUnit = (value, path) => { if (value !== undefined) invalid(path, "undefined"); return value; };
export const assertBool = (value, path) => { if (typeof value !== "boolean") invalid(path, "boolean"); return value; };
export const assertUint8 = (value, path) => { if (!Number.isInteger(value) || value < 0 || value > 0xff) invalid(path, "uint8"); return value; };
export const assertUint16 = (value, path) => { if (!Number.isInteger(value) || value < 0 || value > 0xffff) invalid(path, "uint16"); return value; };
export const assertUint32 = (value, path) => { if (!Number.isInteger(value) || value < 0 || value > 0xffffffff) invalid(path, "uint32"); return value; };
export const assertInt8 = (value, path) => { if (!Number.isInteger(value) || value < -0x80 || value > 0x7f) invalid(path, "int8"); return value; };
export const assertInt16 = (value, path) => { if (!Number.isInteger(value) || value < -0x8000 || value > 0x7fff) invalid(path, "int16"); return value; };
export const assertInt32 = (value, path) => { if (!Number.isInteger(value) || value < -0x80000000 || value > 0x7fffffff) invalid(path, "int32"); return value; };
export const assertUsize = assertUint32;
export const assertIsize = assertInt32;
const assertBigInt = (value, path) => { if (typeof value !== "bigint") invalid(path, "bigint"); return value; };
export const assertUint64 = (value, path) => { assertBigInt(value, path); if (value < 0n || value > 0xffffffffffffffffn) invalid(path, "uint64"); return value; };
export const assertInt64 = (value, path) => { assertBigInt(value, path); if (value < -0x8000000000000000n || value > 0x7fffffffffffffffn) invalid(path, "int64"); return value; };
export const assertInt = assertBigInt;
export const assertNat = (value, path) => { assertBigInt(value, path); if (value < 0n) invalid(path, "non-negative bigint"); return value; };
export const assertFin = (value, bound, path) => { assertNat(value, path); if (value >= BigInt(bound)) invalid(path, `bigint below ${bound}`); return value; };
export const assertNestedFin = (value, refinement, path) => {
  if (refinement === null || refinement.kind === 'subtype') return;
  if (refinement.kind === 'fin') { assertFin(value, refinement.bound, path); return; }
  if (refinement.kind === 'record' || refinement.kind === 'checked-record' || refinement.kind === 'variant') {
    const fields = refinement.kind === 'variant' ? refinement.cases.find(branch => branch.name === value.kind).fields : refinement.fields;
    for (const field of fields) assertNestedFin(value[field.name], field.refinement, path + '.' + field.name);
    return;
  }
  const child = (index, value, suffix) => assertNestedFin(value, refinement.arguments[index], path + suffix);
  if (refinement.kind === 'array' || refinement.kind === 'list') { value.forEach((item, index) => child(0, item, '[' + index + ']')); return; }
  if (refinement.kind === 'option') { if (value.tag === 'some') child(0, value.value, '.value'); return; }
  if (refinement.kind === 'tuple') { child(0, value[0], '[0]'); child(1, value[1], '[1]'); return; }
  if (Object.hasOwn(value, 'ok')) child(0, value.ok, '.ok'); else child(1, value.error, '.error');
};
const assertNumber = (value, path) => { if (typeof value !== "number") invalid(path, "number"); return value; };
export const assertFloat32 = assertNumber;
export const assertFloat64 = assertNumber;
export const assertString = (value, path) => { if (typeof value !== "string") invalid(path, "string"); return value; };
export const assertChar = (value, path) => { if (typeof value !== "string" || value.length === 0 || value.length > 2) invalid(path, "one Unicode scalar"); const point = value.codePointAt(0); if ((point >= 0xd800 && point <= 0xdfff) || value.length !== (point > 0xffff ? 2 : 1)) invalid(path, "one Unicode scalar"); return value; };
export const assertBytes = (value, path) => { if (!(value instanceof Uint8Array)) invalid(path, "Uint8Array"); return value; };

const copiedTypes = {"assertChoice":{"kind":"variant","cases":{"empty":[],"packet":[["value","assertPacket"]]}},"assertHolder":{"kind":"record","fields":[["packet","assertPacket"],["tag","assertNat"]]},"$nominalFin0":{"kind":"alias","target":"assertNat","refinement":{"bound":"10","kind":"fin"}},"assertPacket":{"kind":"record","fields":[["digit","$nominalFin0"],["word","assertNat"]]},"assertArrayOfPacket":{"kind":"array","arguments":["assertPacket"]},"assertApplied$0e2a29b3f850af87e372":{"kind":"result","arguments":["assertPacket","assertPacket"]},"assertApplied$c7bfdeec07c5a7037c6e":{"kind":"list","arguments":["assertPacket"]},"assertApplied$89f4af26eabc1bd0097b":{"kind":"option","arguments":["assertPacket"]},"assertApplied$85e8986f8f61f064336a":{"kind":"tuple","arguments":["assertPacket","assertPacket"]}};
const scalarValidators = { assertUnit, assertBool, assertUint8, assertUint16, assertUint32, assertUint64, assertInt8, assertInt16, assertInt32, assertInt64, assertNat, assertInt, assertFloat32, assertFloat64, assertString, assertBytes, assertChar, assertUsize, assertIsize };
const ownData = (value, key, path, expected = "own data fields") => {
  const field = Object.getOwnPropertyDescriptor(value, key);
  if (!field || !Object.hasOwn(field, "value")) invalid(path, expected);
  return field.value;
};
const exactFields = (value, expected, path) => {
  const own = Reflect.ownKeys(value);
  if (own.length !== expected.length || own.some(key => !expected.includes(key)))
    throw new TypeError(path + " does not match the declared copied fields");
};
const copiedValue = (root, input, path) => {
  const active = new Set(), stack = [{ type: root, value: input, path, depth: 0 }];
  let nodes = 0;
  while (stack.length) {
    const frame = stack.at(-1);
    if (frame.children) {
      if (frame.index === frame.count) { for (const refinement of frame.checks ?? []) assertNestedFin(frame.value, refinement, frame.path); active.delete(frame.value); stack.pop(); continue; }
      const index = frame.index++, field = frame.sequence ? [index, frame.element ?? frame.children[index]] : frame.children[index];
      stack.push({ type: field[1], value: ownData(frame.value, field[0], frame.path, frame.sequence ? "dense data array" : "own data fields"), path: frame.path + "." + field[0], depth: frame.depth + 1 });
      continue;
    }
    if (frame.depth > 128) throw new RangeError("Component recursive value depth exceeded");
    if (++nodes > 262144) throw new RangeError("Component recursive value node budget exceeded");
    let type = copiedTypes[frame.type];
    while (type?.kind === "alias") { if (type.refinement) (frame.checks ??= []).push(type.refinement); frame.type = type.target; type = copiedTypes[frame.type]; }
    if (Object.hasOwn(scalarValidators, frame.type)) { scalarValidators[frame.type](frame.value, frame.path); for (const refinement of frame.checks ?? []) assertNestedFin(frame.value, refinement, frame.path); stack.pop(); continue; }
    if (!type) invalid(frame.path, "a declared copied type");
    const value = frame.value, sequence = ["array", "list", "tuple"].includes(type.kind);
    if (!value || typeof value !== "object") invalid(frame.path, "plain " + type.kind);
    if (active.has(value)) throw new TypeError("Cyclic copied value");
    let children, element, count;
    if (sequence) {
      if (!Array.isArray(value) && !(type.kind === "array" && value instanceof Uint32Array)) invalid(frame.path, "array");
      count = value.length; children = type.arguments;
      if (count > 262144 - nodes) throw new RangeError("Component recursive value node budget exceeded (bounded array)");
      if (type.kind === "tuple" && count !== children.length) invalid(frame.path, "exact data tuple");
      if (type.kind !== "tuple") element = children[0];
      if (Array.isArray(value) && Reflect.ownKeys(value).length !== count + 1) invalid(frame.path, "dense data array");
    } else {
      if (![Object.prototype, null].includes(Object.getPrototypeOf(value))) invalid(frame.path, "plain " + type.kind);
      let extra = [];
      if (type.kind === "record") children = type.fields;
      else if (type.kind === "variant") {
        const kind = ownData(value, "kind", frame.path);
        if (typeof kind !== "string" || !Object.hasOwn(type.cases, kind)) invalid(frame.path, "declared variant constructor");
        children = type.cases[kind]; extra = ["kind"];
      } else if (type.kind === "option") {
        const tag = ownData(value, "tag", frame.path);
        if (tag !== "none" && tag !== "some") invalid(frame.path, "Option tag");
        children = tag === "none" ? [] : [["value", type.arguments[0]]]; extra = ["tag"];
      } else {
        const error = Object.hasOwn(value, "error");
        children = [[error ? "error" : "ok", type.arguments[error ? 1 : 0]]];
      }
      exactFields(value, [...extra, ...children.map(field => field[0])], frame.path);
      count = children.length;
    }
    if (count > 262144 - nodes) throw new RangeError("Component recursive value node budget exceeded");
    Object.assign(frame, { children, sequence, element, count, index: 0 }); active.add(value);
  }
  return input;
};
export const assertChoice = (value, path) => copiedValue("assertChoice", value, path);
export const assertHolder = (value, path) => copiedValue("assertHolder", value, path);
export const $nominalFin0 = (value, path) => copiedValue("$nominalFin0", value, path);
export const assertPacket = (value, path) => copiedValue("assertPacket", value, path);
export const assertArrayOfPacket = (value, path) => copiedValue("assertArrayOfPacket", value, path);
export const assertApplied$0e2a29b3f850af87e372 = (value, path) => copiedValue("assertApplied$0e2a29b3f850af87e372", value, path);
export const assertApplied$c7bfdeec07c5a7037c6e = (value, path) => copiedValue("assertApplied$c7bfdeec07c5a7037c6e", value, path);
export const assertApplied$89f4af26eabc1bd0097b = (value, path) => copiedValue("assertApplied$89f4af26eabc1bd0097b", value, path);
export const assertApplied$85e8986f8f61f064336a = (value, path) => copiedValue("assertApplied$85e8986f8f61f064336a", value, path);

