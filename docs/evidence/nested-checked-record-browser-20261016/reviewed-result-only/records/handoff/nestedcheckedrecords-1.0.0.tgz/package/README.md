# nestedcheckedrecords

Independent corpus contract.

Binding IR SHA-256: `81082c110781d197cd4860b9b39191bc2389afdf0117a1bbf1c250a397912672`

## Exports

### produceArray

Independent corpus contract.

### produceOption

Independent corpus contract.

## Assurance

