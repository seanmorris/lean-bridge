// Generated from Binding IR SHA-256 81082c110781d197cd4860b9b39191bc2389afdf0117a1bbf1c250a397912672.
import { runtime } from "./internal/runtime.mjs";
import * as validate from "./internal/validators.mjs";

/**
 * Independent corpus contract.
 */
export function produceArray(value0) {
  validate.assertNat(value0, "produceArray.value0");
  const result = runtime.call("lean:NestedCheckedRecords.produceArray", [value0]);
  validate.assertArrayOfPacket(result, "produceArray.result");
  validate.assertNestedFin(result, {"arguments":[{"constructor":null,"fields":[{"name":"digit","refinement":{"bound":"10","kind":"fin"}},{"name":"word","refinement":{"constructor":null,"kind":"subtype"}}],"kind":"checked-record","name":"NestedCheckedRecords.Packet"}],"kind":"array"}, "produceArray.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function produceOption(value0) {
  validate.assertNat(value0, "produceOption.value0");
  const result = runtime.call("lean:NestedCheckedRecords.produceOption", [value0]);
  validate.assertApplied$89f4af26eabc1bd0097b(result, "produceOption.result");
  validate.assertNestedFin(result, {"arguments":[{"constructor":null,"fields":[{"name":"digit","refinement":{"bound":"10","kind":"fin"}},{"name":"word","refinement":{"constructor":null,"kind":"subtype"}}],"kind":"checked-record","name":"NestedCheckedRecords.Packet"}],"kind":"option"}, "produceOption.result");
  return result;
}

export default Object.freeze({ produceArray, produceOption });
