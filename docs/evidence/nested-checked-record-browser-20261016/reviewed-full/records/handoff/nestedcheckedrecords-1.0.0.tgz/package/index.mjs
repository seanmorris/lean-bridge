// Generated from Binding IR SHA-256 403aa9c7bfb95f74c6fb6a3043492a30864a18666674b5677701ae1d53a1b985.
import { runtime } from "./internal/runtime.mjs";
import * as validate from "./internal/validators.mjs";

/**
 * Independent corpus contract.
 */
export function echoArray(value0) {
  validate.assertArrayOfPacket(value0, "echoArray.value0");
  validate.assertNestedFin(value0, {"arguments":[{"constructor":"NestedCheckedRecords.mkPacket","fields":[{"name":"digit","refinement":{"bound":"10","kind":"fin"}},{"name":"word","refinement":{"constructor":"NestedCheckedRecords.mkWord","kind":"subtype"}}],"kind":"checked-record","name":"NestedCheckedRecords.Packet"}],"kind":"array"}, "echoArray.value0");
  const result = runtime.call("lean:NestedCheckedRecords.echoArray", [value0]);
  validate.assertArrayOfPacket(result, "echoArray.result");
  validate.assertNestedFin(result, {"arguments":[{"constructor":null,"fields":[{"name":"digit","refinement":{"bound":"10","kind":"fin"}},{"name":"word","refinement":{"constructor":null,"kind":"subtype"}}],"kind":"checked-record","name":"NestedCheckedRecords.Packet"}],"kind":"array"}, "echoArray.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function first(value0) {
  validate.assertPacket(value0, "first.value0");
  const result = runtime.call("lean:NestedCheckedRecords.first", [value0]);
  validate.assertNat(result, "first.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function inArray(value0) {
  validate.assertArrayOfPacket(value0, "inArray.value0");
  validate.assertNestedFin(value0, {"arguments":[{"constructor":"NestedCheckedRecords.mkPacket","fields":[{"name":"digit","refinement":{"bound":"10","kind":"fin"}},{"name":"word","refinement":{"constructor":"NestedCheckedRecords.mkWord","kind":"subtype"}}],"kind":"checked-record","name":"NestedCheckedRecords.Packet"}],"kind":"array"}, "inArray.value0");
  const result = runtime.call("lean:NestedCheckedRecords.inArray", [value0]);
  validate.assertNat(result, "inArray.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function inChoice(value0) {
  validate.assertChoice(value0, "inChoice.value0");
  validate.assertNestedFin(value0, {"cases":[{"fields":[],"name":"empty"},{"fields":[{"name":"value","refinement":{"constructor":"NestedCheckedRecords.mkPacket","fields":[{"name":"digit","refinement":{"bound":"10","kind":"fin"}},{"name":"word","refinement":{"constructor":"NestedCheckedRecords.normalizeWord","kind":"subtype"}}],"kind":"checked-record","name":"NestedCheckedRecords.Packet"}}],"name":"packet"}],"kind":"variant","name":"NestedCheckedRecords.Choice"}, "inChoice.value0");
  const result = runtime.call("lean:NestedCheckedRecords.inChoice", [value0]);
  validate.assertNat(result, "inChoice.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function inExcept(value0) {
  validate.assertApplied$0e2a29b3f850af87e372(value0, "inExcept.value0");
  validate.assertNestedFin(value0, {"arguments":[{"constructor":"NestedCheckedRecords.normalizePacket","fields":[{"name":"digit","refinement":{"bound":"10","kind":"fin"}},{"name":"word","refinement":{"constructor":"NestedCheckedRecords.mkWord","kind":"subtype"}}],"kind":"checked-record","name":"NestedCheckedRecords.Packet"},{"constructor":"NestedCheckedRecords.mkPacket","fields":[{"name":"digit","refinement":{"bound":"10","kind":"fin"}},{"name":"word","refinement":{"constructor":"NestedCheckedRecords.normalizeWord","kind":"subtype"}}],"kind":"checked-record","name":"NestedCheckedRecords.Packet"}],"kind":"result"}, "inExcept.value0");
  const result = runtime.call("lean:NestedCheckedRecords.inExcept", [value0]);
  validate.assertNat(result, "inExcept.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function inHolder(value0) {
  validate.assertHolder(value0, "inHolder.value0");
  validate.assertNestedFin(value0, {"fields":[{"name":"packet","refinement":{"constructor":"NestedCheckedRecords.normalizePacket","fields":[{"name":"digit","refinement":{"bound":"10","kind":"fin"}},{"name":"word","refinement":{"constructor":"NestedCheckedRecords.mkWord","kind":"subtype"}}],"kind":"checked-record","name":"NestedCheckedRecords.Packet"}},{"name":"tag","refinement":null}],"kind":"record","name":"NestedCheckedRecords.Holder"}, "inHolder.value0");
  const result = runtime.call("lean:NestedCheckedRecords.inHolder", [value0]);
  validate.assertNat(result, "inHolder.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function inList(value0) {
  validate.assertApplied$c7bfdeec07c5a7037c6e(value0, "inList.value0");
  validate.assertNestedFin(value0, {"arguments":[{"constructor":"NestedCheckedRecords.normalizePacket","fields":[{"name":"digit","refinement":{"bound":"10","kind":"fin"}},{"name":"word","refinement":{"constructor":"NestedCheckedRecords.normalizeWord","kind":"subtype"}}],"kind":"checked-record","name":"NestedCheckedRecords.Packet"}],"kind":"list"}, "inList.value0");
  const result = runtime.call("lean:NestedCheckedRecords.inList", [value0]);
  validate.assertNat(result, "inList.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function inOption(value0) {
  validate.assertApplied$89f4af26eabc1bd0097b(value0, "inOption.value0");
  validate.assertNestedFin(value0, {"arguments":[{"constructor":"NestedCheckedRecords.mkPacket","fields":[{"name":"digit","refinement":{"bound":"10","kind":"fin"}},{"name":"word","refinement":{"constructor":"NestedCheckedRecords.normalizeWord","kind":"subtype"}}],"kind":"checked-record","name":"NestedCheckedRecords.Packet"}],"kind":"option"}, "inOption.value0");
  const result = runtime.call("lean:NestedCheckedRecords.inOption", [value0]);
  validate.assertNat(result, "inOption.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function inProduct(value0) {
  validate.assertApplied$85e8986f8f61f064336a(value0, "inProduct.value0");
  validate.assertNestedFin(value0, {"arguments":[{"constructor":"NestedCheckedRecords.mkPacket","fields":[{"name":"digit","refinement":{"bound":"10","kind":"fin"}},{"name":"word","refinement":{"constructor":"NestedCheckedRecords.mkWord","kind":"subtype"}}],"kind":"checked-record","name":"NestedCheckedRecords.Packet"},{"constructor":"NestedCheckedRecords.normalizePacket","fields":[{"name":"digit","refinement":{"bound":"10","kind":"fin"}},{"name":"word","refinement":{"constructor":"NestedCheckedRecords.normalizeWord","kind":"subtype"}}],"kind":"checked-record","name":"NestedCheckedRecords.Packet"}],"kind":"tuple"}, "inProduct.value0");
  const result = runtime.call("lean:NestedCheckedRecords.inProduct", [value0]);
  validate.assertNat(result, "inProduct.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function pair(value0, value1) {
  validate.assertPacket(value0, "pair.value0");
  validate.assertPacket(value1, "pair.value1");
  const result = runtime.call("lean:NestedCheckedRecords.pair", [value0, value1]);
  validate.assertNat(result, "pair.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function produceArray(value0) {
  validate.assertNat(value0, "produceArray.value0");
  const result = runtime.call("lean:NestedCheckedRecords.produceArray", [value0]);
  validate.assertArrayOfPacket(result, "produceArray.result");
  validate.assertNestedFin(result, {"arguments":[{"constructor":null,"fields":[{"name":"digit","refinement":{"bound":"10","kind":"fin"}},{"name":"word","refinement":{"constructor":null,"kind":"subtype"}}],"kind":"checked-record","name":"NestedCheckedRecords.Packet"}],"kind":"array"}, "produceArray.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function produceOption(value0) {
  validate.assertNat(value0, "produceOption.value0");
  const result = runtime.call("lean:NestedCheckedRecords.produceOption", [value0]);
  validate.assertApplied$89f4af26eabc1bd0097b(result, "produceOption.result");
  validate.assertNestedFin(result, {"arguments":[{"constructor":null,"fields":[{"name":"digit","refinement":{"bound":"10","kind":"fin"}},{"name":"word","refinement":{"constructor":null,"kind":"subtype"}}],"kind":"checked-record","name":"NestedCheckedRecords.Packet"}],"kind":"option"}, "produceOption.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function second(value0) {
  validate.assertPacket(value0, "second.value0");
  const result = runtime.call("lean:NestedCheckedRecords.second", [value0]);
  validate.assertNat(result, "second.result");
  return result;
}

export default Object.freeze({ echoArray, first, inArray, inChoice, inExcept, inHolder, inList, inOption, inProduct, pair, produceArray, produceOption, second });
