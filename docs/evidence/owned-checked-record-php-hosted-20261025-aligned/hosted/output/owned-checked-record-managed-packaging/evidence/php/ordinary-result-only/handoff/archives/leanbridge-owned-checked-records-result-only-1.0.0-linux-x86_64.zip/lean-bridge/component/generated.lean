import OwnedCheckedRecords
set_option maxRecDepth 10000
namespace LeanBridgeOwned574872ec965d4656
def carrierValue {α : Type} (value : _root_.Array α) : _root_.Option α :=
  if bound : 0 < value.size then
    if value.size == 1 then .some (value[0]'bound) else .none
  else .none

def carrierResult {α : Type} (value : _root_.Option α) : _root_.Array α :=
  match value with | .none => #[] | .some result => #[result]

def carrierCollect {α : Type} (values : _root_.Array (_root_.Array α)) : _root_.Option (_root_.Array α) := Id.run do
  if values.size > 262144 then return .none
  let mut result := #[]
  for value in values do
    match carrierValue value with
    | .none => return .none
    | .some item => result := result.push item
  return .some result

def carrierListItems {α : Type} (values : _root_.List α) (limit : _root_.Nat) : _root_.Array (_root_.Array α) :=
  let rec loop : _root_.Nat → _root_.List α → _root_.Array (_root_.Array α) → _root_.Array (_root_.Array α)
    | 0, _, acc => acc
    | _, [], acc => acc
    | fuel + 1, head :: tail, acc => loop fuel tail (acc.push #[head])
  loop (min limit 262145) values #[]

structure LbOwnedErased.OwnedCheckedRecords.Claim where
  «holder» : _root_.OwnedCheckedRecords.Ticket
  «quota» : _root_.Nat

@[export lean_bridge_owned_b82f2265ee39efaa52174167_t160ce821a84f6887bbfd_branch]
def carrier0 (value : (_root_.Array (_root_.Option LbOwnedErased.OwnedCheckedRecords.Claim))) : _root_.UInt32 :=
  match carrierValue value with
  | .none => 4294967295
  | .some value =>
    match value with
    | .none => 0
    | .some _ => 1

@[export lean_bridge_owned_b82f2265ee39efaa52174167_t160ce821a84f6887bbfd_none]
def carrier1 (_bridgeUnit : _root_.Unit) : (_root_.Array (_root_.Option LbOwnedErased.OwnedCheckedRecords.Claim)) :=
  carrierResult (do
    pure (.none)
  )

@[export lean_bridge_owned_b82f2265ee39efaa52174167_t160ce821a84f6887bbfd_make0]
def carrier2 (a0 : (_root_.Array LbOwnedErased.OwnedCheckedRecords.Claim)) : (_root_.Array (_root_.Option LbOwnedErased.OwnedCheckedRecords.Claim)) :=
  carrierResult (do
    let a0 ← carrierValue a0
    pure (.some a0)
  )

@[export lean_bridge_owned_b82f2265ee39efaa52174167_t160ce821a84f6887bbfd_field0]
def carrier3 (value : (_root_.Array (_root_.Option LbOwnedErased.OwnedCheckedRecords.Claim))) : (_root_.Array LbOwnedErased.OwnedCheckedRecords.Claim) :=
  carrierResult (do
    let value ← carrierValue value
    match value with
    | .some child => pure child
    | _ => .none
  )

@[export lean_bridge_owned_b82f2265ee39efaa52174167_tb2825946e038e653bd2b_make]
def carrier4 (a0 : (_root_.Array _root_.OwnedCheckedRecords.Ticket)) (a1 : (_root_.Array _root_.Nat)) : (_root_.Array LbOwnedErased.OwnedCheckedRecords.Claim) :=
  carrierResult (do
    let a0 ← carrierValue a0
    let a1 ← carrierValue a1
    pure (({ «holder» := a0, «quota» := a1 } : LbOwnedErased.OwnedCheckedRecords.Claim))
  )

@[export lean_bridge_owned_b82f2265ee39efaa52174167_tb2825946e038e653bd2b_field0]
def carrier5 (value : (_root_.Array LbOwnedErased.OwnedCheckedRecords.Claim)) : (_root_.Array _root_.OwnedCheckedRecords.Ticket) :=
  carrierResult (do
    let value ← carrierValue value
    pure value.«holder»
  )

@[export lean_bridge_owned_b82f2265ee39efaa52174167_tb2825946e038e653bd2b_field1]
def carrier6 (value : (_root_.Array LbOwnedErased.OwnedCheckedRecords.Claim)) : (_root_.Array _root_.Nat) :=
  carrierResult (do
    let value ← carrierValue value
    pure value.«quota»
  )

@[export lean_bridge_owned_b82f2265ee39efaa52174167_f483485736ace9af57086]
def carrier7 (a0 : (_root_.Array _root_.OwnedCheckedRecords.Ticket)) : (_root_.Array (_root_.Option LbOwnedErased.OwnedCheckedRecords.Claim)) :=
  carrierResult (do
    let a0 ← carrierValue a0
    let _sourceResult := _root_.OwnedCheckedRecords.claimFor a0
    pure (((_sourceResult).map (fun _ownedValue0 => (LbOwnedErased.OwnedCheckedRecords.Claim.mk ((_ownedValue0).«holder») ((_ownedValue0).«quota»)))))
  )

@[export lean_bridge_owned_b82f2265ee39efaa52174167_fa1e5189bd92568e4b939]
def carrier8 (a0 : (_root_.Array _root_.Nat)) (a1 : (_root_.Array _root_.String)) : (_root_.Array _root_.OwnedCheckedRecords.Ticket) :=
  carrierResult (do
    let a0 ← carrierValue a0
    let a1 ← carrierValue a1
    pure (_root_.OwnedCheckedRecords.newTicket a0 a1)
  )

@[export lean_bridge_owned_b82f2265ee39efaa52174167_fec926afda994fba3abe2]
def carrier9 (a0 : (_root_.Array _root_.OwnedCheckedRecords.Ticket)) : (_root_.Array _root_.Nat) :=
  carrierResult (do
    let a0 ← carrierValue a0
    pure (_root_.OwnedCheckedRecords.serial a0)
  )

end LeanBridgeOwned574872ec965d4656
