<?php
declare(strict_types=1);
namespace LeanOwnedCheckedRecords\Internal;

require_once __DIR__ . '/Runtime.php';
require_once __DIR__ . '/OwnedAssets.php';

final class OwnedAssets
{
    private const DEFINITIONS = OwnedCallTypes::DEFINITIONS;
    public static function load(): \FFI {
        return \LeanBridge\OwnedNativeV1\Runtime::load(__DIR__ . '/../../native/linux-x64', json_decode(<<<'EVIDENCE'
{
  "componentId": "owned-checked-records@1.0.0",
  "componentLibrary": "libcomponent_161bdaa35ee11fef40c6.so",
  "componentReceiptSha256": "6d0fce46543a50a6f0b8867085915da4ad60e28ef74abe35cd10566b04da8cc9",
  "identity": "550eb8ef218a4aae1dfab85bb18d81f935cd84e347edfe2232e50b67658e128f",
  "libraries": {
    "libcomponent_161bdaa35ee11fef40c6.so": "6bf63438c575d01e25e547a4c3dc193f8216eb6f4c26fa7be7044fdc35b15967",
    "libgmp-lean-bridge.so.10": "9687f8d50f5c413728d4fcc8d96328912239ce8b1269cbb9a1ff793e430a7b27",
    "liblean_bridge_native.so": "459fcd2098d4b646ab6ae0f4cdccd1f222908cb162562bfc3940a533cd4e4e21",
    "libleanshared.so": "d7768b88d8162736da4305777cd6f147676038fd885bd8a265c958b0ecea00b4",
    "libowned_checked_records_php.so": "c9ccac1d954e85a7f7c09e224951258567acf0ecc081d5fb4c99b21844c16b59"
  },
  "library": "libowned_checked_records_php.so",
  "ownedValues": {
    "callbackFailure": "raise-after-native-return",
    "callbackLifetime": "call",
    "exactIntegers": "brick-math",
    "explicitRetention": "retain",
    "gmp": "libgmp-lean-bridge.so.10",
    "headerSha256": "0575d397aac7683f34356a85219125c5d26fe000d5ac66e1262f7a6378ceb2b8",
    "inputTransfers": {
      "aliases": "shared-lease",
      "arguments": "ordinary-values",
      "borrowedInputs": "reject",
      "consumption": "before-lean-call",
      "failure": "consumed-after-handoff",
      "independentRetains": "preserved",
      "schemaVersion": 1,
      "validation": "before-consumption"
    },
    "integerDecimalDigits": 16384,
    "language": "php-8.2-nts-cli",
    "limits": {
      "bytes": 16777216,
      "depth": 128,
      "retained": 4096,
      "visits": 262144
    },
    "loaderSha256": "e6974d3de49f085510405fca4a888732e238debd4b9e6a46ebde4ec39b61ca35",
    "loadingPolicy": "linux-x64-deepbind-v1",
    "nativeSha256": "c81759e959be58248ab97afb6a5b36f4ab91e6bb4179e3d13c55aef85495b22f",
    "ownership": "checked-result-leases",
    "schemaVersion": 2,
    "sharedLoaderSha256": "057d6f64a05c18766d6b10663de7aeb70714818ce06f96c74d3f3894644dfc14",
    "sourcesSha256": {
      "src/Api.php": "8ead8345a17836a13cf54110ad63b3db299759dce716807706c6c16c8d7d7d95",
      "src/Internal/GraphTypes.php": "5df138b7a578681fa9a8647e13c33a02815a9ab98b3f6c51c6d49c6d221b6117",
      "src/Internal/OwnedCallTypes.php": "174e5c5b0f8207b2c8105f00de9ef8fd5dc5c894fd393c64e74f870498d0e9e1",
      "src/Internal/OwnedCalls.php": "59bfe68662d9b8e1308e4d9d10ced666aa7793c800390e9be7816e9a64f7dc42",
      "src/Internal/OwnedConversions.php": "9d3a640f68e7c4c6ae700116211bf78e74a5282b45a522d275a324f681721b8b",
      "src/Internal/OwnedNativeTypes.php": "3ec45d7200db1779517da0485a635a3f1558c509562c61fd147fa168a207fa28",
      "src/Internal/OwnedRuntime.php": "0961b10d1d6f2c49267ad61c3a1f9e07af52ef725e14ff7ed78134117610e542",
      "src/Internal/Values.php": "bcd665cf88bba996f1b0dd561a0aa5599acca476c2f297374beff45bfcc85578"
    }
  },
  "runtimeIdentity": "4b5a7fdf0cb11d4bb429181cfd50b330c5622ed8f5f5382a293955a439b595b5"
}
EVIDENCE, true, 512, JSON_THROW_ON_ERROR), self::DEFINITIONS);
    }
}

Native::configure(static fn(): OwnedRuntime => new OwnedRuntime(OwnedAssets::load(),
    \LeanBridge\CopiedNativeV1\Runtime::ensureProcess(...)));
