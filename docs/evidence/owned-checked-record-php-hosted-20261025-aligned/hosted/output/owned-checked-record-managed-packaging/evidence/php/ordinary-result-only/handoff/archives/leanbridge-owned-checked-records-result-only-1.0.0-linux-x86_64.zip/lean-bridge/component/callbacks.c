#include "component.h"
#include "lean_bridge_native_runtime.h"
static _Thread_local int lean_bridge_owned_callback_failure_2f91fd78306b5022a8fd_state;
int lean_bridge_owned_callback_failure_2f91fd78306b5022a8fd(void) { int result = lean_bridge_owned_callback_failure_2f91fd78306b5022a8fd_state; lean_bridge_owned_callback_failure_2f91fd78306b5022a8fd_state = 0; return result; }
