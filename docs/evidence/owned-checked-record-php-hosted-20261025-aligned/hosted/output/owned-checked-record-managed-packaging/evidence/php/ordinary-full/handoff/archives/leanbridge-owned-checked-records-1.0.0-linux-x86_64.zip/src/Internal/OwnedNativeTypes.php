<?php
declare(strict_types=1);
namespace LeanOwnedCheckedRecords\Internal;

final class OwnedNativeTypes
{
    public const DEFINITIONS = <<<'CDEFS'
typedef struct lb_php_integer lb_php_integer;
typedef const lb_php_integer *mpz_srcptr;
typedef uint8_t *lb_php_owned_bytes;
typedef uint8_t **lb_php_owned_slot;
typedef enum owned_checked_records_status { OWNED_CHECKED_RECORDS_OK = 0, OWNED_CHECKED_RECORDS_INVALID_ARGUMENT = 1, OWNED_CHECKED_RECORDS_LIMIT = 2, OWNED_CHECKED_RECORDS_ALLOCATION_FAILED = 3, OWNED_CHECKED_RECORDS_CLOSED = 4, OWNED_CHECKED_RECORDS_WRONG_THREAD = 5, OWNED_CHECKED_RECORDS_WRONG_PROCESS = 6, OWNED_CHECKED_RECORDS_RUNTIME_UNAVAILABLE = 7, OWNED_CHECKED_RECORDS_CALL_ORDER = 8, OWNED_CHECKED_RECORDS_MALFORMED_RESULT = 9, OWNED_CHECKED_RECORDS_CALLBACK_FAILED = 10 } owned_checked_records_status;
typedef struct owned_checked_records_session owned_checked_records_session;
typedef struct owned_checked_records_result owned_checked_records_result;
/* Immutable views: input children borrow caller storage for one call.
   Output children, including GMP integers, remain valid until result_release.
   Never free a child or mutate a returned GMP integer. Retain an identity
   before releasing its last owning result. Sessions are thread/process bound.
   Close invalidates resource use; result_release still frees copied storage.
   Output/result slots must not overlap and *owner must initially be NULL.
   GMP retains its normal fatal out-of-memory policy. */
owned_checked_records_status owned_checked_records_session_open(owned_checked_records_session **out);
owned_checked_records_status owned_checked_records_session_close(owned_checked_records_session **value);
owned_checked_records_status owned_checked_records_result_release(owned_checked_records_result **value);
/* Transferred arguments take an additional input-owner slot. All arguments
   and owners are validated before consumption. Each owner must be distinct
   and belong to this session; owner slots must not overlap output slots.
   Immediately before Lean runs, each entire input owner is consumed and
   its slot becomes NULL. A later failure does not restore consumed owners.
   Old views expire when this call returns. Independently retained owners
   remain valid. Failure before consumption leaves input owners unchanged. */
typedef struct owned_checked_records_value_f790309465bbf573c7b9_t owned_checked_records_value_f790309465bbf573c7b9_t;
typedef struct owned_checked_records_value_160ce821a84f6887bbfd_t owned_checked_records_value_160ce821a84f6887bbfd_t;
typedef struct owned_checked_records_claim_closure_result_t_handle *owned_checked_records_claim_closure_result_t;
typedef struct owned_checked_records_transfer_with_claim_callback_argument1_t_handle *owned_checked_records_transfer_with_claim_callback_argument1_t;
typedef struct owned_checked_records_booking_t owned_checked_records_booking_t;
typedef struct owned_checked_records_claim_t owned_checked_records_claim_t;
typedef struct owned_checked_records_grant_t owned_checked_records_grant_t;
typedef struct owned_checked_records_ticket_t_handle *owned_checked_records_ticket_t;
typedef struct owned_checked_records_window_t owned_checked_records_window_t;
typedef struct owned_checked_records_scalar_string_t owned_checked_records_scalar_string_t;
struct owned_checked_records_scalar_string_t {
  const char *data;
  size_t length;
};
struct owned_checked_records_value_f790309465bbf573c7b9_t {
  owned_checked_records_claim_t const *data;
  size_t length;
};
struct owned_checked_records_value_160ce821a84f6887bbfd_t {
  bool has_value;
  owned_checked_records_claim_t const *value;
};
struct owned_checked_records_booking_t {
  owned_checked_records_ticket_t holder;
  owned_checked_records_window_t const *window;
};
struct owned_checked_records_claim_t {
  owned_checked_records_ticket_t holder;
  mpz_srcptr quota;
};
struct owned_checked_records_grant_t {
  owned_checked_records_ticket_t holder;
  mpz_srcptr weight;
  mpz_srcptr limit;
};
struct owned_checked_records_window_t {
  mpz_srcptr lo;
  mpz_srcptr hi;
};
typedef owned_checked_records_value_160ce821a84f6887bbfd_t owned_checked_records_claim_for_result_t;
typedef owned_checked_records_value_f790309465bbf573c7b9_t owned_checked_records_echo_claims_argument0_t;
typedef owned_checked_records_value_f790309465bbf573c7b9_t owned_checked_records_echo_claims_result_t;
/* Host callbacks borrow their context for the enclosing call only.
   Set exactly one of call or closure. recovery is an optional typed value;
   it is required if the signature has no finite recovery from its inputs.
   Failure never publishes recovery as a successful result.
   Callback arguments expire on return. Replies may borrow those arguments
   or context storage, or transfer an owning result (also released on error).
   Use a generated copy function to snapshot callback-local storage.
   Do not let C++ exceptions or longjmp cross a callback boundary. */
typedef struct owned_checked_records_claim_closure_result_t_host {
  owned_checked_records_status (*call)(void *context, owned_checked_records_session *session, owned_checked_records_claim_t const * a0, owned_checked_records_claim_t *out, owned_checked_records_result **owner);
  void *context;
  owned_checked_records_claim_closure_result_t closure;
  owned_checked_records_claim_t const *recovery;
} owned_checked_records_claim_closure_result_t_host;
typedef struct owned_checked_records_transfer_with_claim_callback_argument1_t_host {
  owned_checked_records_status (*call)(void *context, owned_checked_records_session *session, owned_checked_records_claim_t const * a0, owned_checked_records_claim_t *out, owned_checked_records_result **owner);
  void *context;
  owned_checked_records_transfer_with_claim_callback_argument1_t closure;
  owned_checked_records_claim_t const *recovery;
} owned_checked_records_transfer_with_claim_callback_argument1_t_host;
owned_checked_records_status owned_checked_records_booking_span(owned_checked_records_session *session, owned_checked_records_booking_t const * a0, mpz_srcptr *out, owned_checked_records_result **owner);
owned_checked_records_status owned_checked_records_claim_closure(owned_checked_records_session *session, owned_checked_records_claim_closure_result_t *out, owned_checked_records_result **owner);
owned_checked_records_status owned_checked_records_claim_for(owned_checked_records_session *session, owned_checked_records_ticket_t a0, owned_checked_records_value_160ce821a84f6887bbfd_t *out, owned_checked_records_result **owner);
owned_checked_records_status owned_checked_records_claim_quota(owned_checked_records_session *session, owned_checked_records_claim_t const * a0, mpz_srcptr *out, owned_checked_records_result **owner);
owned_checked_records_status owned_checked_records_echo_booking(owned_checked_records_session *session, owned_checked_records_booking_t const * a0, owned_checked_records_booking_t *out, owned_checked_records_result **owner);
owned_checked_records_status owned_checked_records_echo_claim(owned_checked_records_session *session, owned_checked_records_claim_t const * a0, owned_checked_records_claim_t *out, owned_checked_records_result **owner);
owned_checked_records_status owned_checked_records_echo_claims(owned_checked_records_session *session, owned_checked_records_value_f790309465bbf573c7b9_t const * a0, owned_checked_records_value_f790309465bbf573c7b9_t *out, owned_checked_records_result **owner);
owned_checked_records_status owned_checked_records_echo_grant(owned_checked_records_session *session, owned_checked_records_grant_t const * a0, owned_checked_records_grant_t *out, owned_checked_records_result **owner);
owned_checked_records_status owned_checked_records_new_ticket(owned_checked_records_session *session, mpz_srcptr a0, owned_checked_records_scalar_string_t a1, owned_checked_records_ticket_t *out, owned_checked_records_result **owner);
owned_checked_records_status owned_checked_records_pair_claim(owned_checked_records_session *session, owned_checked_records_booking_t const * a0, owned_checked_records_claim_t const * a1, owned_checked_records_claim_t *out, owned_checked_records_result **owner);
owned_checked_records_status owned_checked_records_serial(owned_checked_records_session *session, owned_checked_records_ticket_t a0, mpz_srcptr *out, owned_checked_records_result **owner);
owned_checked_records_status owned_checked_records_transfer_claim(owned_checked_records_session *session, owned_checked_records_claim_t const * a0, owned_checked_records_result **a0_owner, owned_checked_records_claim_t *out, owned_checked_records_result **owner);
owned_checked_records_status owned_checked_records_transfer_pair_claim(owned_checked_records_session *session, owned_checked_records_booking_t const * a0, owned_checked_records_result **a0_owner, owned_checked_records_claim_t const * a1, owned_checked_records_result **a1_owner, owned_checked_records_claim_t *out, owned_checked_records_result **owner);
owned_checked_records_status owned_checked_records_transfer_with_claim_callback(owned_checked_records_session *session, owned_checked_records_claim_t const * a0, owned_checked_records_result **a0_owner, owned_checked_records_transfer_with_claim_callback_argument1_t_host const * a1, owned_checked_records_claim_t *out, owned_checked_records_result **owner);
owned_checked_records_status owned_checked_records_with_claim_callback(owned_checked_records_session *session, owned_checked_records_claim_t const * a0, owned_checked_records_transfer_with_claim_callback_argument1_t_host const * a1, owned_checked_records_claim_t *out, owned_checked_records_result **owner);
owned_checked_records_status owned_checked_records_claim_closure_result_t_call(owned_checked_records_session *session, owned_checked_records_claim_closure_result_t a0, owned_checked_records_claim_t const * a1, owned_checked_records_claim_t *out, owned_checked_records_result **owner);
owned_checked_records_status owned_checked_records_transfer_with_claim_callback_argument1_t_call(owned_checked_records_session *session, owned_checked_records_transfer_with_claim_callback_argument1_t a0, owned_checked_records_claim_t const * a1, owned_checked_records_claim_t *out, owned_checked_records_result **owner);
owned_checked_records_status owned_checked_records_claim_closure_result_t_retain(owned_checked_records_session *session, owned_checked_records_claim_closure_result_t a0, owned_checked_records_claim_closure_result_t *out, owned_checked_records_result **owner);
owned_checked_records_status owned_checked_records_transfer_with_claim_callback_argument1_t_retain(owned_checked_records_session *session, owned_checked_records_transfer_with_claim_callback_argument1_t a0, owned_checked_records_transfer_with_claim_callback_argument1_t *out, owned_checked_records_result **owner);
owned_checked_records_status owned_checked_records_ticket_t_retain(owned_checked_records_session *session, owned_checked_records_ticket_t a0, owned_checked_records_ticket_t *out, owned_checked_records_result **owner);
owned_checked_records_status owned_checked_records_value_f790309465bbf573c7b9_t_copy(owned_checked_records_session *session, owned_checked_records_value_f790309465bbf573c7b9_t const * a0, owned_checked_records_value_f790309465bbf573c7b9_t *out, owned_checked_records_result **owner);
owned_checked_records_status owned_checked_records_value_160ce821a84f6887bbfd_t_copy(owned_checked_records_session *session, owned_checked_records_value_160ce821a84f6887bbfd_t const * a0, owned_checked_records_value_160ce821a84f6887bbfd_t *out, owned_checked_records_result **owner);
owned_checked_records_status owned_checked_records_booking_t_copy(owned_checked_records_session *session, owned_checked_records_booking_t const * a0, owned_checked_records_booking_t *out, owned_checked_records_result **owner);
owned_checked_records_status owned_checked_records_claim_t_copy(owned_checked_records_session *session, owned_checked_records_claim_t const * a0, owned_checked_records_claim_t *out, owned_checked_records_result **owner);
owned_checked_records_status owned_checked_records_grant_t_copy(owned_checked_records_session *session, owned_checked_records_grant_t const * a0, owned_checked_records_grant_t *out, owned_checked_records_result **owner);
owned_checked_records_status owned_checked_records_window_t_copy(owned_checked_records_session *session, owned_checked_records_window_t const * a0, owned_checked_records_window_t *out, owned_checked_records_result **owner);
owned_checked_records_status owned_checked_records_scalar_nat_copy(owned_checked_records_session *session, mpz_srcptr a0, mpz_srcptr *out, owned_checked_records_result **owner);
owned_checked_records_status owned_checked_records_scalar_string_copy(owned_checked_records_session *session, owned_checked_records_scalar_string_t a0, owned_checked_records_scalar_string_t *out, owned_checked_records_result **owner);

owned_checked_records_status owned_checked_records_php_integer_new(const char *, size_t, mpz_srcptr *);
void owned_checked_records_php_integer_free(mpz_srcptr *);
owned_checked_records_status owned_checked_records_php_integer_text(mpz_srcptr, char *, size_t, size_t *);
CDEFS;
    public const NODES = [['ctype' => 'owned_checked_records_value_f790309465bbf573c7b9_t', 'kind' => 'array', 'scalar' => null, 'identity' => false, 'class' => null, 'leaf' => false, 'inhabited' => true, 'element' => 5, 'flag' => null, 'branches' => [['class' => null, 'fields' => []]]], ['ctype' => 'owned_checked_records_value_160ce821a84f6887bbfd_t', 'kind' => 'option', 'scalar' => null, 'identity' => false, 'class' => null, 'leaf' => false, 'inhabited' => true, 'element' => null, 'flag' => 'has_value', 'branches' => [['class' => null, 'fields' => []], ['class' => 'LeanOwnedCheckedRecords\\Some', 'fields' => [['type' => 5, 'path' => ['value'], 'pointer' => true, 'key' => 'value']]]]], ['ctype' => 'owned_checked_records_claim_closure_result_t', 'kind' => 'callback', 'scalar' => null, 'identity' => true, 'class' => 'LeanOwnedCheckedRecords\\Callback26621c40b48fce52ca37', 'leaf' => true, 'inhabited' => true, 'element' => null, 'flag' => null, 'branches' => [['class' => null, 'fields' => []]]], ['ctype' => 'owned_checked_records_transfer_with_claim_callback_argument1_t', 'kind' => 'callback', 'scalar' => null, 'identity' => true, 'class' => 'LeanOwnedCheckedRecords\\Callbackb2d3d6fd4e031785f278', 'leaf' => true, 'inhabited' => true, 'element' => null, 'flag' => null, 'branches' => [['class' => null, 'fields' => []]]], ['ctype' => 'owned_checked_records_booking_t', 'kind' => 'record', 'scalar' => null, 'identity' => false, 'class' => null, 'leaf' => false, 'inhabited' => true, 'element' => null, 'flag' => null, 'branches' => [['class' => 'LeanOwnedCheckedRecords\\Booking', 'fields' => [['type' => 7, 'path' => ['holder'], 'pointer' => false, 'key' => 'holder'], ['type' => 8, 'path' => ['window'], 'pointer' => true, 'key' => 'window']]]]], ['ctype' => 'owned_checked_records_claim_t', 'kind' => 'record', 'scalar' => null, 'identity' => false, 'class' => null, 'leaf' => false, 'inhabited' => true, 'element' => null, 'flag' => null, 'branches' => [['class' => 'LeanOwnedCheckedRecords\\Claim', 'fields' => [['type' => 7, 'path' => ['holder'], 'pointer' => false, 'key' => 'holder'], ['type' => 9, 'path' => ['quota'], 'pointer' => false, 'key' => 'quota']]]]], ['ctype' => 'owned_checked_records_grant_t', 'kind' => 'record', 'scalar' => null, 'identity' => false, 'class' => null, 'leaf' => false, 'inhabited' => true, 'element' => null, 'flag' => null, 'branches' => [['class' => 'LeanOwnedCheckedRecords\\Grant', 'fields' => [['type' => 7, 'path' => ['holder'], 'pointer' => false, 'key' => 'holder'], ['type' => 9, 'path' => ['weight'], 'pointer' => false, 'key' => 'weight'], ['type' => 9, 'path' => ['limit'], 'pointer' => false, 'key' => 'limit']]]]], ['ctype' => 'owned_checked_records_ticket_t', 'kind' => 'resource', 'scalar' => null, 'identity' => true, 'class' => 'LeanOwnedCheckedRecords\\Ticket', 'leaf' => true, 'inhabited' => true, 'element' => null, 'flag' => null, 'branches' => [['class' => null, 'fields' => []]]], ['ctype' => 'owned_checked_records_window_t', 'kind' => 'record', 'scalar' => null, 'identity' => false, 'class' => null, 'leaf' => false, 'inhabited' => true, 'element' => null, 'flag' => null, 'branches' => [['class' => 'LeanOwnedCheckedRecords\\Window', 'fields' => [['type' => 9, 'path' => ['lo'], 'pointer' => false, 'key' => 'lo'], ['type' => 9, 'path' => ['hi'], 'pointer' => false, 'key' => 'hi']]]]], ['ctype' => 'mpz_srcptr', 'kind' => 'primitive', 'scalar' => 'nat', 'identity' => false, 'class' => null, 'leaf' => true, 'inhabited' => true, 'element' => null, 'flag' => null, 'branches' => [['class' => null, 'fields' => []]]], ['ctype' => 'owned_checked_records_scalar_string_t', 'kind' => 'primitive', 'scalar' => 'string', 'identity' => false, 'class' => null, 'leaf' => true, 'inhabited' => true, 'element' => null, 'flag' => null, 'branches' => [['class' => null, 'fields' => []]]]];
}
