<?php
declare(strict_types=1);
namespace LeanOwnedCheckedRecords\Internal;

require_once __DIR__ . '/Values.php';
require_once __DIR__ . '/OwnedNativeTypes.php';
final class ScalarCodec
{
    public static function point(string $text): int {
        $length = strlen($text);
        $value = ord($text[0]) & [1 => 127, 2 => 31, 3 => 15, 4 => 7][$length];
        for ($i = 1; $i < $length; $i++) $value = ($value << 6) | (ord($text[$i]) & 63);
        return $value;
    }
    public static function text(int $value): string {
        if ($value < 0 || $value > 0x10ffff || ($value >= 0xd800 && $value <= 0xdfff)) throw new \RuntimeException('Invalid native Unicode scalar');
        if ($value < 128) return chr($value);
        if ($value < 0x800) return chr(0xc0 | ($value >> 6)) . chr(0x80 | ($value & 63));
        if ($value < 0x10000) return chr(0xe0 | ($value >> 12)) . chr(0x80 | (($value >> 6) & 63)) . chr(0x80 | ($value & 63));
        return chr(0xf0 | ($value >> 18)) . chr(0x80 | (($value >> 12) & 63)) . chr(0x80 | (($value >> 6) & 63)) . chr(0x80 | ($value & 63));
    }
}

final class IntegerCodec
{
    public static function limbs(string $decimal): array {
        $digits = ltrim($decimal, '-');
        $limbs = [];
        foreach (str_split(str_pad($digits, (int) (ceil(strlen($digits) / 9) * 9), '0', STR_PAD_LEFT), 9) as $part) {
            $carry = (int) $part;
            foreach ($limbs as $i => $word) {
                $value = $word * 1000000000 + $carry;
                $limbs[$i] = $value & 0xffffffff;
                $carry = intdiv($value, 4294967296);
            }
            if ($carry) $limbs[] = $carry;
        }
        return $limbs;
    }
    public static function decimal(array $limbs, bool $negative): string {
        // 1700 limbs fit in 16384 decimal digits; check the exact length below too.
        if (count($limbs) > 1701) throw new \ValueError('BigInteger decimal conversion limit exceeded');
        $chunks = [];
        foreach (array_reverse($limbs) as $word) {
            $carry = $word;
            foreach ($chunks as $i => $part) {
                $value = $part * 4294967296 + $carry;
                $chunks[$i] = $value % 1000000000;
                $carry = intdiv($value, 1000000000);
            }
            while ($carry) { $chunks[] = $carry % 1000000000; $carry = intdiv($carry, 1000000000); }
        }
        $text = $chunks ? (string) array_pop($chunks) : '0';
        foreach (array_reverse($chunks) as $part) $text .= str_pad((string) $part, 9, '0', STR_PAD_LEFT);
        if (strlen($text) > 16384) throw new \ValueError('BigInteger decimal conversion limit exceeded');
        return $negative && $text !== '0' ? '-' . $text : $text;
    }
}


final class OwnedInvalidNative extends \RuntimeException
{
    public function __construct(string $message) { parent::__construct($message, 9); }
}

final class OwnedSchema
{
    public readonly array $nodes;
    public function __construct(public readonly \FFI $ffi) {
        $nodes = OwnedNativeTypes::NODES;
        foreach ($nodes as &$node) {
            $type = $ffi->type($node['ctype']);
            $node['size'] = \FFI::sizeof($type); $node['alignment'] = \FFI::alignof($type);
            $node['pointerType'] = $ffi->type($node['ctype'] . '*');
            if ($node['flag'] !== null) $node['flagOffset'] = $type->getStructFieldOffset($node['flag']);
            if ($node['element'] !== null || in_array($node['scalar'], ['string', 'bytes'], true)) {
                $node['dataOffset'] = $type->getStructFieldOffset('data');
                $node['lengthOffset'] = $type->getStructFieldOffset('length');
            }
            foreach ($node['branches'] as &$branch) {
                foreach ($branch['fields'] as &$field) {
                    $offset = 0; $current = $type;
                    foreach ($field['path'] as $name) {
                        $offset += $current->getStructFieldOffset($name); $current = $current->getStructFieldType($name);
                    }
                    $field['offset'] = $offset;
                }
                unset($field);
            }
            unset($branch);
        }
        unset($node); $this->nodes = $nodes;
    }
    public function node(int $type): array { return $this->nodes[$type] ?? throw new \TypeError('Unknown owned value type'); }
    public function address(\FFI\CData $pointer): int { return $this->ffi->cast('uintptr_t', $pointer)->cdata; }
    public function pointer(?\FFI\CData $pointer, int $count, int $width, int $alignment): ?\FFI\CData {
        if ($count < 0 || $width < 1 || $alignment < 1 || $count > intdiv(16 * 1024 * 1024, $width))
            throw new OwnedInvalidNative('Invalid owned native span');
        if ($count === 0) return null;
        $address = $pointer === null ? 0 : $this->address($pointer);
        if ($address < 4096 || $address % $alignment !== 0 || $address > PHP_INT_MAX - $count * $width)
            throw new OwnedInvalidNative('Missing, misaligned or overflowing owned native pointer');
        return $this->ffi->cast('lb_php_owned_bytes', $pointer);
    }
    public function readPointer(\FFI\CData $at): ?\FFI\CData { return $this->ffi->cast('lb_php_owned_slot', $at)[0]; }
    public function writePointer(\FFI\CData $at, ?\FFI\CData $value): void {
        $this->ffi->cast('lb_php_owned_slot', $at)[0] = $value === null ? null : $this->ffi->cast('lb_php_owned_bytes', $value);
    }
}

final class OwnedConversionScope
{
    private array $memory = [];
    private array $integers = [];
    private array $leases = [];
    private bool $closed = false;
    public readonly GraphBudget $storage;
    public readonly GraphBudget $native;
    public function __construct(public readonly OwnedSchema $schema, public readonly OwnedState $state) {
        $state->requireOpen();
        if ($schema->ffi !== $state->runtime->ffi) throw new \TypeError('Owned conversion schema belongs to another runtime');
        $this->storage = new GraphBudget(); $this->native = new GraphBudget();
    }
    public function checkpoint(): void {
        if ($this->closed) OwnedRuntime::checked(4);
        $this->state->runtime->affinity(); $this->state->runtime->checkpoint();
    }
    public function allocate(int $size): ?\FFI\CData {
        if ($size < 0 || $size > 16 * 1024 * 1024) throw new \ValueError('Owned scratch exceeds 16 MiB');
        $words = intdiv($size + 7, 8); $this->native->charge($words, 8); $this->storage->charge(128);
        $this->checkpoint(); if ($size === 0) return null;
        $owner = $this->schema->ffi->new('uint64_t[' . $words . ']');
        $this->memory[] = $owner;
        return $this->schema->ffi->cast('lb_php_owned_bytes', \FFI::addr($owner[0]));
    }
    public function integer(string $text): \FFI\CData {
        $this->storage->charge(strlen($text), 2); $this->checkpoint();
        $slot = $this->schema->ffi->new('mpz_srcptr');
        $this->integers[] = $slot; $this->checkpoint();
        OwnedRuntime::checked($this->schema->ffi->owned_checked_records_php_integer_new($text, strlen($text), \FFI::addr($slot)));
        return $slot;
    }
    public function pin(NativeBinding $binding): \FFI\CData {
        $this->storage->charge(32); $this->checkpoint();
        $this->leases[] = $binding->pin($this->state);
        return $binding->raw($this->state);
    }
    public function close(): void {
        if ($this->closed) return;
        $this->state->runtime->affinity();
        foreach ($this->integers as $slot) $this->schema->ffi->owned_checked_records_php_integer_free(\FFI::addr($slot));
        $this->integers = []; $this->memory = []; $this->leases = []; $this->closed = true;
    }
    public function __destruct() { try { $this->close(); } catch (\Throwable) {} }
}

final class OwnedScalarNative
{
    public static function write(array $node, mixed $value, \FFI\CData $out, OwnedConversionScope $scope): void {
        $schema = $scope->schema; $ffi = $schema->ffi; $name = $node['scalar'];
        if ($name === 'nat' || $name === 'int') {
            $slot = $scope->integer((string) $value); $schema->writePointer($out, $slot);
        } elseif ($name === 'string' || $name === 'bytes') {
            $bytes = $name === 'bytes' ? $value->toString() : $value; $length = strlen($bytes);
            $scope->storage->charge($length); $data = $scope->allocate($length);
            if ($length) \FFI::memcpy($data, $bytes, $length);
            $schema->writePointer($out + $node['dataOffset'], $data);
            $ffi->cast('size_t*', $out + $node['lengthOffset'])[0] = $length;
        } elseif ($name === 'uint64' || $name === 'usize') {
            $words = IntegerCodec::limbs((string) $value);
            \FFI::memcpy($out, pack('V2', $words[0] ?? 0, $words[1] ?? 0), 8);
        } elseif ($name === 'unit' || $name === 'bool') $out[0] = $value ? 1 : 0;
        elseif ($name === 'char') $ffi->cast('uint32_t*', $out)[0] = ScalarCodec::point($value);
        else $ffi->cast($node['pointerType'], $out)[0] = $value;
    }
    public static function read(array $node, \FFI\CData $at, OwnedConversionScope $scope): mixed {
        $schema = $scope->schema; $ffi = $schema->ffi; $name = $node['scalar']; $scope->checkpoint();
        if ($name === 'nat' || $name === 'int') {
            $raw = $schema->pointer($schema->readPointer($at), 1, 1, 8);
            $number = $ffi->cast('mpz_srcptr', $raw); $size = $ffi->new('size_t');
            OwnedRuntime::checked($ffi->owned_checked_records_php_integer_text($number, null, 0, \FFI::addr($size)));
            $capacity = $size->cdata;
            if ($capacity < 2 || $capacity > 16387) throw new OwnedInvalidNative('Invalid owned integer length');
            $data = $scope->allocate($capacity); $scope->storage->charge($capacity);
            OwnedRuntime::checked($ffi->owned_checked_records_php_integer_text($number, $ffi->cast('char*', $data), $capacity, \FFI::addr($size)));
            if ($size->cdata < 1 || $size->cdata >= $capacity) throw new OwnedInvalidNative('Invalid owned decimal length');
            return \Brick\Math\BigInteger::of(\FFI::string($data, $size->cdata));
        }
        if ($name === 'string' || $name === 'bytes') {
            $length = $ffi->cast('size_t*', $at + $node['lengthOffset'])[0];
            $scope->native->charge($length); $scope->storage->charge($length);
            $data = $schema->pointer($schema->readPointer($at + $node['dataOffset']), $length, 1, 1);
            $text = $length ? \FFI::string($data, $length) : '';
            return $name === 'string' ? $text : \LeanOwnedCheckedRecords\Bytes::fromString($text);
        }
        if ($name === 'unit' || $name === 'bool') {
            if ($at[0] > ($name === 'unit' ? 0 : 1)) throw new OwnedInvalidNative('Invalid owned Unit or Bool');
            return $name === 'unit' ? null : $at[0] === 1;
        }
        if ($name === 'uint64' || $name === 'usize')
            return \Brick\Math\BigInteger::of(IntegerCodec::decimal(array_values(unpack('V2', \FFI::string($at, 8))), false));
        $raw = $ffi->cast($node['pointerType'], $at)[0];
        if ($name === 'char') {
            if ($raw > 0x10ffff || ($raw >= 0xd800 && $raw <= 0xdfff)) throw new OwnedInvalidNative('Invalid owned Unicode scalar');
            return ScalarCodec::text($raw);
        }
        return $raw;
    }
}


final class OwnedReadFrame
{
    public bool $entered = false;
    public int $index = 0;
    public int $count = 0;
    public array $values = [];
    public array $fields = [];
    public ?string $class = null;
    public ?string $identity = null;
    public ?\FFI\CData $data = null;
    public function __construct(public int $type, public \FFI\CData $pointer, public int $depth) {}
}

final class OwnedConversions
{
    private static function branch(array $node, mixed $value): int {
        if ($node['kind'] === 'option') return $value === null ? 0 : 1;
        if ($node['kind'] === 'result') return $value instanceof \LeanOwnedCheckedRecords\Ok ? 1 : 0;
        if ($node['kind'] === 'variant') {
            foreach ($node['branches'] as $index => $branch) if ($value::class === $branch['class']) return $index;
            throw new \TypeError('Unknown owned variant constructor');
        }
        return 0;
    }
    public static function write(int $type, mixed $value, OwnedConversionScope $scope): \FFI\CData {
        $schema = $scope->schema; $root = $schema->node($type);
        Values::check($type, $value); $scope->state->requireOpen();
        $out = $scope->allocate($root['size']); $stack = [[0, $type, $value, $out, 0]];
        while ($stack) {
            $frame = array_pop($stack);
            if ($frame[0] === 1) {
                [, $items, $fields, $element, $index, $count, $data, $depth] = $frame;
                if ($index === $count) continue;
                $frame[4]++; $stack[] = $frame;
                $field = $element === null ? $fields[$index] : null;
                $childType = $element ?? $field['type']; $child = $schema->nodes[$childType];
                $input = $items[$field === null ? $index : $field['key']];
                $at = $data + ($field === null ? $index * $child['size'] : $field['offset']);
                if ($field !== null && $field['pointer']) {
                    $pointer = $scope->allocate($child['size']); $schema->writePointer($at, $pointer); $at = $pointer;
                }
                $stack[] = [0, $childType, $input, $at, $depth + 1]; continue;
            }
            [, $type, $value, $at, $depth] = $frame; $node = $schema->nodes[$type];
            $scope->storage->step($depth);
            if (!$node['inhabited']) throw new \ValueError('The owned type has no finite value');
            if ($node['identity']) {
                $binding = ResourceAccess::binding($value);
                if (!$binding instanceof NativeBinding) throw new \TypeError('Expected a resource from the native PHP transport');
                $schema->writePointer($at, $scope->pin($binding)); continue;
            }
            if ($node['kind'] === 'primitive') { OwnedScalarNative::write($node, $value, $at, $scope); continue; }
            $element = $node['element']; $fields = [];
            if ($element !== null) {
                $items = $value; $count = count($items); $child = $schema->nodes[$element];
                $scope->storage->children($count); $data = $scope->allocate($count * $child['size']);
                $schema->writePointer($at + $node['dataOffset'], $data);
                $schema->ffi->cast('size_t*', $at + $node['lengthOffset'])[0] = $count;
            } else {
                $tag = self::branch($node, $value); $fields = $node['branches'][$tag]['fields'];
                $items = is_object($value) ? get_object_vars($value) : ($value ?? []); $count = count($fields); $data = $at;
                $scope->storage->children($count);
                if ($node['kind'] === 'variant') $schema->ffi->cast('uint32_t*', $at + $node['flagOffset'])[0] = $tag;
                elseif ($node['flag'] !== null) $at[$node['flagOffset']] = $tag;
            }
            $stack[] = [1, $items, $fields, $element, 0, $count, $data, $depth];
        }
        return $out;
    }
    private static function construct(OwnedReadFrame $frame, array $node, OwnedConversionScope $scope): mixed {
        $scope->checkpoint();
        if ($node['kind'] === 'option' && $frame->class === null) return null;
        if ($frame->class === null) return $frame->values;
        // Initialize exact generated final readonly classes once. Revalidating
        // each recursive tail in its constructor would make decoding quadratic.
        $reflection = new \ReflectionClass($frame->class); $result = $reflection->newInstanceWithoutConstructor();
        foreach ($frame->fields as $index => $field) $reflection->getProperty($field['key'])->setValue($result, $frame->values[$index]);
        return $result;
    }
    public static function read(int $type, \FFI\CData $pointer, OwnedConversionScope $scope, \Closure $identity): mixed {
        $schema = $scope->schema; $root = $schema->node($type); $scope->state->requireOpen();
        $scope->native->charge($root['size']); $pointer = $schema->pointer($pointer, 1, $root['size'], $root['alignment']);
        $stack = [new OwnedReadFrame($type, $pointer, 0)]; $active = [];
        while ($stack) {
            $frame = $stack[count($stack) - 1]; $node = $schema->nodes[$frame->type];
            if (!$frame->entered) {
                $scope->storage->step($frame->depth); $scope->storage->charge(128); $frame->entered = true;
                if (!$node['inhabited']) throw new OwnedInvalidNative('Uninhabited native owned value');
                $frame->identity = $frame->type . ':' . $schema->address($frame->pointer);
                if (isset($active[$frame->identity])) throw new OwnedInvalidNative('Cyclic native owned value');
                $active[$frame->identity] = true;
                if ($node['kind'] !== 'primitive' && !$node['identity']) {
                    if ($node['element'] !== null) {
                        $child = $schema->nodes[$node['element']];
                        $frame->count = $schema->ffi->cast('size_t*', $frame->pointer + $node['lengthOffset'])[0];
                        $scope->storage->children($frame->count); $scope->native->charge($frame->count, $child['size']);
                        $frame->data = $schema->pointer($schema->readPointer($frame->pointer + $node['dataOffset']), $frame->count, $child['size'], $child['alignment']);
                    } else {
                        $tag = $node['kind'] === 'variant' ? $schema->ffi->cast('uint32_t*', $frame->pointer + $node['flagOffset'])[0]
                            : ($node['flag'] !== null ? $frame->pointer[$node['flagOffset']] : 0);
                        $branch = $node['branches'][$tag] ?? throw new OwnedInvalidNative('Invalid native owned branch tag');
                        $frame->fields = $branch['fields']; $frame->class = $branch['class']; $frame->count = count($frame->fields);
                        $scope->storage->children($frame->count);
                    }
                }
            }
            if ($node['identity'] || $node['kind'] === 'primitive' || $frame->index === $frame->count) {
                if ($node['identity']) {
                    $scope->checkpoint(); $schema->pointer($schema->readPointer($frame->pointer), 1, 1, 1);
                    // Own the pointer slot itself; never keep a view into scratch.
                    $handle = $schema->ffi->new($node['ctype']);
                    \FFI::memcpy(\FFI::addr($handle), $frame->pointer, $node['size']);
                    $value = $identity($frame->type, $handle);
                    if ($value::class !== $node['class']) throw new \TypeError('Wrong native identity wrapper');
                    ResourceAccess::binding($value);
                } else $value = $node['kind'] === 'primitive' ? OwnedScalarNative::read($node, $frame->pointer, $scope) : self::construct($frame, $node, $scope);
                unset($active[$frame->identity]); array_pop($stack);
                if (!$stack) { Values::check($type, $value); return $value; }
                $stack[count($stack) - 1]->values[] = $value; continue;
            }
            $index = $frame->index++; $field = $node['element'] === null ? $frame->fields[$index] : null;
            $childType = $node['element'] ?? $field['type']; $child = $schema->nodes[$childType];
            $at = $field === null ? $frame->data + $index * $child['size'] : $frame->pointer + $field['offset'];
            if ($field !== null && $field['pointer']) {
                $scope->native->charge($child['size']); $at = $schema->pointer($schema->readPointer($at), 1, $child['size'], $child['alignment']);
            }
            $stack[] = new OwnedReadFrame($childType, $at, $frame->depth + 1);
        }
        throw new OwnedInvalidNative('Missing owned native result');
    }
}
