# LeanOwnedCheckedRecords

Install the prepared Composer release and require vendor/autoload.php. The
generated LeanOwnedCheckedRecords functions load their bundled native libraries on the
first valid call. The loader checks the recorded library hashes. Compatible
packages share one Lean runtime; private adapters and GMP load with local symbol
binding. Consumers need no Lean compiler, C declarations or library paths.

This profile requires PHP 8.2 or newer, below PHP 9, NTS CLI on little-endian
Linux x86-64 with FFI enabled and the release's declared glibc floor. It does not
target PHP-Wasm, ZTS, FPM or Apache. Start a fresh interpreter after fork.

Records and variant constructors are final readonly classes. Arrays and Lists
use consecutive-key arrays; products retain their nested two-element shape.
Option uses null or Some(value), including Some(null). Except uses Ok(value)
and Err(error). Aliases preserve their target representation. Nat, Int, UInt64
and USize use Brick\Math\BigInteger; other fixed-width integers use checked
PHP int. Nat and Int accept at most 16384 decimal digits. Char is one Unicode
scalar, String preserves UTF-8 and NUL, and Bytes preserves arbitrary bytes.
Float32 rounds to binary32. Unit is null. Weak and strict callers receive the
same generated validation without scalar coercion.

Resource and returned Lean closure wrappers support close() and retain(). Close
them in a finally block. Destruction provides fallback cleanup. Calls from
Fibers reject; cleanup deferred by Fiber destruction runs in the main context.
Resource identities cannot be cloned or serialized.

Consuming parameters accept ordinary PHP values. Validation and snapshot
failures before Lean runs preserve their owners. At the native handoff, each
consumed result owner closes all its resource and closure aliases, including
sibling fields. Later callback or result-conversion failures do not restore
ownership. Independent retain() results remain usable. Callback borrows cannot
be consumed; retain them first. Two consuming arguments cannot share one owner.
Generated function documentation names the consuming parameters.

Pass synchronous PHP callables to callback parameters. Borrowed resources in
callback arguments expire on return. Call retain() inside the callback to keep
one. Callback replies are copied before native borrowed storage expires.
Returned Lean closures are invokable but cannot extend a borrowed PHP callback's
lifetime. Use with_recovery(callback, value) when the signature requires a typed
failure-path value. Recovery never becomes a successful result after failure.
PHP receives the original Throwable after native cleanup. Native reply-copy
failures preserve their status. Generator and reference callbacks reject.

Inputs, callbacks and output share bounded conversion budgets: 128 value levels,
262144 visits, 16 MiB accounted PHP storage and 16 MiB native conversion data.
These limits exclude Lean working memory and some PHP allocator overhead.
Malformed native output retires the runtime; validation and recoverable
allocation failures leave it usable. Generated values load with FFI disabled,
and invalid calls reject before loading native code.
