#include "component.h"
#include "lean_bridge_native_runtime.h"
static _Thread_local int lean_bridge_owned_callback_failure_53ebe30b2ab65b874b4e_state;
int lean_bridge_owned_callback_failure_53ebe30b2ab65b874b4e(void) { int result = lean_bridge_owned_callback_failure_53ebe30b2ab65b874b4e_state; lean_bridge_owned_callback_failure_53ebe30b2ab65b874b4e_state = 0; return result; }
