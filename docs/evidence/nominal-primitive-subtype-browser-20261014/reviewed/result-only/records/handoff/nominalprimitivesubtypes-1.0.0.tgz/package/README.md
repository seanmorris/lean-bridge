# nominalprimitivesubtypes

Independent corpus contract.

Binding IR SHA-256: `dd20f303609102347771e25218aeabd01c33114d2189ad6e97246682f194999d`

## Exports

### produce

Independent corpus contract.

### produceChoices

Independent corpus contract.

### produceEvent

Independent corpus contract.

### produceGroup

Independent corpus contract.

### producePair

Independent corpus contract.

### wordBits

Independent corpus contract.

## Assurance

