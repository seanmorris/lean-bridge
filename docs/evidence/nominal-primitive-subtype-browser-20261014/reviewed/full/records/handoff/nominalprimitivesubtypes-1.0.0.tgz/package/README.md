# nominalprimitivesubtypes

Independent corpus contract.

Binding IR SHA-256: `35133987661701050c7c643c8ca8063a4f0a205b9b59c316b3d45d2a294238ae`

## Exports

### aliases

Independent corpus contract.

### combine

Independent corpus contract.

### echoA

Independent corpus contract.

### echoB

Independent corpus contract.

### echoEventA

Independent corpus contract.

### echoEventB

Independent corpus contract.

### echoPair

Independent corpus contract.

### produce

Independent corpus contract.

### produceChoices

Independent corpus contract.

### produceEvent

Independent corpus contract.

### produceGroup

Independent corpus contract.

### producePair

Independent corpus contract.

### refuseUnit

Independent corpus contract.

### wordBits

Independent corpus contract.

## Assurance

