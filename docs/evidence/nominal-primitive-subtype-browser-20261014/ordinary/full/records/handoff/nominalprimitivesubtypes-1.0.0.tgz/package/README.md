# nominalprimitivesubtypes

Compiler-checked exports for nominalprimitivesubtypes.

Binding IR SHA-256: `a7fbef6be0dcbfb7c575f5e198bf6cbbd04f7946592efd6e0b323ebfec795cf9`

## Exports

### aliases

Call NominalPrimitiveSubtypes.aliases.

### combine

Call NominalPrimitiveSubtypes.combine.

### echoA

Call NominalPrimitiveSubtypes.echoA.

### echoB

Call NominalPrimitiveSubtypes.echoB.

### echoEventA

Call NominalPrimitiveSubtypes.echoEventA.

### echoEventB

Call NominalPrimitiveSubtypes.echoEventB.

### echoPair

Call NominalPrimitiveSubtypes.echoPair.

### produce

Call NominalPrimitiveSubtypes.produce.

### produceChoices

Call NominalPrimitiveSubtypes.produceChoices.

### produceEvent

Call NominalPrimitiveSubtypes.produceEvent.

### produceGroup

Call NominalPrimitiveSubtypes.produceGroup.

### producePair

Call NominalPrimitiveSubtypes.producePair.

### refuseUnit

Call NominalPrimitiveSubtypes.refuseUnit.

### wordBits

Call NominalPrimitiveSubtypes.wordBits.

## Assurance

