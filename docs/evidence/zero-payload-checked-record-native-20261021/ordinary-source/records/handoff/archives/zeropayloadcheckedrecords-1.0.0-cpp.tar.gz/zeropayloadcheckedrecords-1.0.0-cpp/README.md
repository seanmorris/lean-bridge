# zeropayloadcheckedrecords 1.0.0

Compiled C++20 and C11 API from zeropayloadcheckedrecords@1.0.0. Linux x86-64, glibc 2.38 or newer. Lean is not required by consumers. The shared native runtime is included in lib/ and loads automatically.

Include zeropayloadcheckedrecords.hpp. Use pkg-config package zeropayloadcheckedrecords, or find_package(LeanBridgeZeropayloadcheckedrecords CONFIG REQUIRED) and link LeanBridge::zeropayloadcheckedrecords. C++ functions live in lean_bridge::zeropayloadcheckedrecords.

C inputs borrow caller buffers for one call. Initialize C result structs to zero and call the matching zeropayloadcheckedrecords_TYPE_clear function after use, before reusing a result slot. Clear is idempotent. C++ results own their memory and release C buffers automatically, including when a C++ allocation throws.

Strings are length-delimited UTF-8, including embedded NUL. Byte arrays are uninterpreted bytes. Nat and Int are Boost.Multiprecision cpp_int values. Negative Nat inputs reject. Packages using these types include Boost 1.90.0 standalone headers, license and source hashes; CMake and pkg-config configure them automatically. Unit parameters are zero in C and std::monostate in C++; Unit results have no output. Fixed-width integers use exact-width host types; floating-point values retain IEEE special values. Input and output copies share a 16 MiB per-call budget. Invalid input leaves the output unchanged and returns a status (C) or throws Error (C++).

Arrays and acyclic records can nest up to 32 types deep. C spans own their nested elements through their release callback; record clear functions clear their fields. Do not shallow-copy an owned result and clear both copies. C++ uses owned vectors and structs, with scoped input views. The 16 MiB conversion budget includes input and output payloads, array slots (at least pointer-sized), output ownership headers and record storage; it does not bound the Lean algorithm's working memory.

Tagged Lean variants use std::variant with one named struct per constructor. Construct and inspect named alternatives with std::get, std::holds_alternative or std::visit; consumers do not supply constructor numbers. Empty constructors remain distinct and Unit fields use std::monostate. Payloads may nest supported copied values. Field names use snake_case; reserved C++ keywords gain a trailing underscore. Generated Lean helpers keep compiler object tags and field offsets private. Only the active case is read, copied or cleared. Variants share the 32-level type limit and the 16 MiB conversion budget. Recursive, callable and identity-bearing payloads are not supported.

- zeropayloadcheckedrecords_absent_count: lean:ZeroPayloadCheckedRecords.absentCount
- zeropayloadcheckedrecords_mark_count: lean:ZeroPayloadCheckedRecords.markCount
- zeropayloadcheckedrecords_marker_count: lean:ZeroPayloadCheckedRecords.markerCount
- zeropayloadcheckedrecords_maybe_witness: lean:ZeroPayloadCheckedRecords.maybeWitness
- zeropayloadcheckedrecords_produce_mark: lean:ZeroPayloadCheckedRecords.produceMark
- zeropayloadcheckedrecords_produce_marker: lean:ZeroPayloadCheckedRecords.produceMarker
- zeropayloadcheckedrecords_produce_token: lean:ZeroPayloadCheckedRecords.produceToken
- zeropayloadcheckedrecords_produce_witness: lean:ZeroPayloadCheckedRecords.produceWitness
- zeropayloadcheckedrecords_token_tag: lean:ZeroPayloadCheckedRecords.tokenTag
- zeropayloadcheckedrecords_witness_count: lean:ZeroPayloadCheckedRecords.witnessCount
- zeropayloadcheckedrecords_witnesses: lean:ZeroPayloadCheckedRecords.witnesses
