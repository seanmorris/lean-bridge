#pragma once
#include "zeropayloadcheckedrecords.h"
#include <stdexcept>
#include <memory>
#include <string>
#include <variant>
#include <optional>
#include <vector>
#include <utility>

#ifndef BOOST_MP_STANDALONE
#define BOOST_MP_STANDALONE
#endif
#include <boost/multiprecision/cpp_int.hpp>

namespace lean_bridge::zeropayloadcheckedrecords {

using Nat = boost::multiprecision::cpp_int;
using Int = boost::multiprecision::cpp_int;
struct Witness {

  friend bool operator==(const Witness&, const Witness&) = default;
};
struct MarkBlank {

  friend bool operator==(const MarkBlank&, const MarkBlank&) = default;
};
struct MarkMarked {
  Witness witness{};
  friend bool operator==(const MarkMarked&, const MarkMarked&) = default;
};
using Mark = std::variant<MarkBlank, MarkMarked>;
struct Marker {

  friend bool operator==(const Marker&, const Marker&) = default;
};
struct Token {
  std::monostate tag{};
  friend bool operator==(const Token&, const Token&) = default;
};
class Error final : public std::runtime_error {
public:
  zeropayloadcheckedrecords_status status;
  zeropayloadcheckedrecords_error_code code;
  Error(zeropayloadcheckedrecords_status value, const zeropayloadcheckedrecords_error& error)
    : std::runtime_error(error.message ? std::string(error.message, error.message_length) : "Lean call failed"), status(value), code(error.code) {}
};
namespace detail {
[[noreturn]] inline void invalid(const char* message) {
  const zeropayloadcheckedrecords_error error{ZEROPAYLOADCHECKEDRECORDS_ERROR_INVALID_ARGUMENT, message, std::char_traits<char>::length(message)};
  throw Error(ZEROPAYLOADCHECKEDRECORDS_STATUS_INVALID_ARGUMENT, error);
}
inline void charge(size_t& budget, size_t count, size_t width) {
  if (count > budget / width) {
    const zeropayloadcheckedrecords_error error{ZEROPAYLOADCHECKEDRECORDS_ERROR_INVALID_ARGUMENT, "16 MiB call limit exceeded", 26};
    throw Error(ZEROPAYLOADCHECKEDRECORDS_STATUS_INVALID_ARGUMENT, error);
  }
  budget -= count * width;
}
inline void check0(const Witness& source, size_t& budget) {
  (void)source; (void)budget;
  charge(budget, 1, sizeof(zeropayloadcheckedrecords_witness));
}
struct View0 {
  zeropayloadcheckedrecords_witness value{};
  explicit View0(const Witness& source) {
    (void)source;
    value = zeropayloadcheckedrecords_witness{};
  }
};
inline Witness from0(const zeropayloadcheckedrecords_witness& source) {
  (void)source;
  return Witness{};
}

inline void check1(const Nat& source, size_t& budget) {
  (void)source; (void)budget;
  if (source < 0) invalid("Nat must be nonnegative");
  charge(budget, source == 0 ? 0 : (boost::multiprecision::msb(source < 0 ? -source : source) / 32 + 1), sizeof(uint32_t));
}
struct View1 {
  std::vector<uint32_t> limbs;
  zeropayloadcheckedrecords_nat value{};
  explicit View1(const Nat& source) {
    (void)source;
    if (source != 0) boost::multiprecision::export_bits(source, std::back_inserter(limbs), 32, false);
    value = zeropayloadcheckedrecords_nat{limbs.data(), limbs.size(), nullptr, nullptr};
  }
};
inline Nat from1(const zeropayloadcheckedrecords_nat& source) {
  (void)source;
  Nat result = 0;
  if (source.length) boost::multiprecision::import_bits(result, source.data, source.data + source.length, 32, false);
  return result;
}

inline void check2(const Mark& source, size_t& budget) {
  (void)source; (void)budget;
  charge(budget, 1, sizeof(zeropayloadcheckedrecords_mark));
  if (source.valueless_by_exception()) invalid("Variant has no active branch");
  switch (source.index()) {
  case 0:
    break;
  case 1:
    check0(std::get<MarkMarked>(source).witness, budget);
    break;
  default: invalid("Variant has no active branch");
  }
}
struct View2 {
  std::unique_ptr<View0> field1_0;
  zeropayloadcheckedrecords_mark value{};
  explicit View2(const Mark& source) {
    (void)source;
    value.kind = static_cast<uint32_t>(source.index());
    switch (source.index()) {
    case 0:
      break;
    case 1:
      field1_0 = std::make_unique<View0>(std::get<MarkMarked>(source).witness); value.cases.marked.witness = field1_0->value;
      break;
    default: invalid("Variant has no active branch");
    }
  }
};
inline Mark from2(const zeropayloadcheckedrecords_mark& source) {
  (void)source;
  switch (source.kind) {
  case 0: return MarkBlank{};
  case 1: return MarkMarked{from0(source.cases.marked.witness)};
  default: invalid("Native variant has an invalid tag");
  }
}

inline void check3(const Marker& source, size_t& budget) {
  (void)source; (void)budget;
  charge(budget, 1, sizeof(zeropayloadcheckedrecords_marker));
}
struct View3 {
  zeropayloadcheckedrecords_marker value{};
  explicit View3(const Marker& source) {
    (void)source;
    value = zeropayloadcheckedrecords_marker{};
  }
};
inline Marker from3(const zeropayloadcheckedrecords_marker& source) {
  (void)source;
  return Marker{};
}

inline void check4(const bool& source, size_t& budget) {
  (void)source; (void)budget;
}
struct View4 {
  bool value{};
  explicit View4(const bool& source) {
    (void)source;
    value = source;
  }
};
inline bool from4(const bool& source) {
  (void)source;
  return source;
}

inline void check5(const std::optional<Witness>& source, size_t& budget) {
  (void)source; (void)budget;
  charge(budget, 1, sizeof(zeropayloadcheckedrecords_option_lean_zero_payload_checked_records_witness_value));
  if (source.has_value()) check0(*source, budget);
}
struct View5 {
  std::unique_ptr<View0> field0;
  zeropayloadcheckedrecords_option_lean_zero_payload_checked_records_witness_value value{};
  explicit View5(const std::optional<Witness>& source) {
    (void)source;
    if (source.has_value()) { field0 = std::make_unique<View0>(*source); value.value = field0->value; }
    value.has_value = source.has_value();
  }
};
inline std::optional<Witness> from5(const zeropayloadcheckedrecords_option_lean_zero_payload_checked_records_witness_value& source) {
  (void)source;
  if (!source.has_value) return std::nullopt;
  return std::optional<Witness>{std::in_place, from0(source.value)};
}

inline void check6(const std::monostate& source, size_t& budget) {
  (void)source; (void)budget;
}
struct View6 {
  uint8_t value{};
  explicit View6(const std::monostate& source) {
    (void)source;
    value = 0;
  }
};
inline std::monostate from6(const uint8_t& source) {
  (void)source;
  return {};
}

inline void check7(const Token& source, size_t& budget) {
  (void)source; (void)budget;
  charge(budget, 1, sizeof(zeropayloadcheckedrecords_token));
  check6(source.tag, budget);
}
struct View7 {
  View6 field0;
  zeropayloadcheckedrecords_token value{};
  explicit View7(const Token& source) : field0(source.tag) {
    (void)source;
    value = zeropayloadcheckedrecords_token{field0.value};
  }
};
inline Token from7(const zeropayloadcheckedrecords_token& source) {
  (void)source;
  return Token{from6(source.tag)};
}

inline void check8(const std::vector<Witness>& source, size_t& budget) {
  (void)source; (void)budget;
  charge(budget, source.size(), sizeof(zeropayloadcheckedrecords_witness) > sizeof(void*) ? sizeof(zeropayloadcheckedrecords_witness) : sizeof(void*));
  for (const auto& item : source) check0(item, budget);
}
struct View8 {
  std::vector<View0> items;
  std::unique_ptr<zeropayloadcheckedrecords_witness[]> values;
  zeropayloadcheckedrecords_array_lean_zero_payload_checked_records_witness_span value{};
  explicit View8(const std::vector<Witness>& source) {
    (void)source;
    items.reserve(source.size()); values = std::make_unique<zeropayloadcheckedrecords_witness[]>(source.size());
    for (const auto& item : source) items.emplace_back(item);
    for (size_t i = 0; i < source.size(); ++i) values[i] = items[i].value;
    value = zeropayloadcheckedrecords_array_lean_zero_payload_checked_records_witness_span{values.get(), source.size(), nullptr, nullptr};
  }
};
inline std::vector<Witness> from8(const zeropayloadcheckedrecords_array_lean_zero_payload_checked_records_witness_span& source) {
  (void)source;
  std::vector<Witness> result; result.reserve(source.length);
  for (size_t i = 0; i < source.length; ++i) result.push_back(from0(source.data[i]));
  return result;
}
inline void check(zeropayloadcheckedrecords_status status, const zeropayloadcheckedrecords_error& error) {
  if (status != ZEROPAYLOADCHECKEDRECORDS_STATUS_OK) throw Error(status, error);
}
template<class T, void (*Clear)(T*)> struct Owned {
  T* value;
  ~Owned() { Clear(value); }
  Owned(const Owned&) = delete;
  Owned& operator=(const Owned&) = delete;
  explicit Owned(T* input) : value(input) {}
};
}


inline Nat absent_count(Witness const& value0) {
  zeropayloadcheckedrecords_error _lb_error{}; size_t _lb_budget = 16u * 1024u * 1024u; (void)_lb_budget;
  detail::check0(value0, _lb_budget);
  detail::View0 _lb_arg0{value0};
  zeropayloadcheckedrecords_nat _lb_result{};
  detail::Owned<zeropayloadcheckedrecords_nat, zeropayloadcheckedrecords_nat_clear> _lb_owner{&_lb_result};
  const auto _lb_status = zeropayloadcheckedrecords_absent_count(&_lb_arg0.value, &_lb_result, &_lb_error);
  detail::check(_lb_status, _lb_error);
  return detail::from1(_lb_result);
}

inline Nat mark_count(Mark const& value0) {
  zeropayloadcheckedrecords_error _lb_error{}; size_t _lb_budget = 16u * 1024u * 1024u; (void)_lb_budget;
  detail::check2(value0, _lb_budget);
  detail::View2 _lb_arg0{value0};
  zeropayloadcheckedrecords_nat _lb_result{};
  detail::Owned<zeropayloadcheckedrecords_nat, zeropayloadcheckedrecords_nat_clear> _lb_owner{&_lb_result};
  const auto _lb_status = zeropayloadcheckedrecords_mark_count(&_lb_arg0.value, &_lb_result, &_lb_error);
  detail::check(_lb_status, _lb_error);
  return detail::from1(_lb_result);
}

inline Nat marker_count(Marker const& value0) {
  zeropayloadcheckedrecords_error _lb_error{}; size_t _lb_budget = 16u * 1024u * 1024u; (void)_lb_budget;
  detail::check3(value0, _lb_budget);
  detail::View3 _lb_arg0{value0};
  zeropayloadcheckedrecords_nat _lb_result{};
  detail::Owned<zeropayloadcheckedrecords_nat, zeropayloadcheckedrecords_nat_clear> _lb_owner{&_lb_result};
  const auto _lb_status = zeropayloadcheckedrecords_marker_count(&_lb_arg0.value, &_lb_result, &_lb_error);
  detail::check(_lb_status, _lb_error);
  return detail::from1(_lb_result);
}

inline std::optional<Witness> maybe_witness(bool value0) {
  zeropayloadcheckedrecords_error _lb_error{}; size_t _lb_budget = 16u * 1024u * 1024u; (void)_lb_budget;
  detail::check4(value0, _lb_budget);
  detail::View4 _lb_arg0{value0};
  zeropayloadcheckedrecords_option_lean_zero_payload_checked_records_witness_value _lb_result{};
  detail::Owned<zeropayloadcheckedrecords_option_lean_zero_payload_checked_records_witness_value, zeropayloadcheckedrecords_option_lean_zero_payload_checked_records_witness_value_clear> _lb_owner{&_lb_result};
  const auto _lb_status = zeropayloadcheckedrecords_maybe_witness(_lb_arg0.value, &_lb_result, &_lb_error);
  detail::check(_lb_status, _lb_error);
  return detail::from5(_lb_result);
}

inline Mark produce_mark(bool value0) {
  zeropayloadcheckedrecords_error _lb_error{}; size_t _lb_budget = 16u * 1024u * 1024u; (void)_lb_budget;
  detail::check4(value0, _lb_budget);
  detail::View4 _lb_arg0{value0};
  zeropayloadcheckedrecords_mark _lb_result{};
  detail::Owned<zeropayloadcheckedrecords_mark, zeropayloadcheckedrecords_mark_clear> _lb_owner{&_lb_result};
  const auto _lb_status = zeropayloadcheckedrecords_produce_mark(_lb_arg0.value, &_lb_result, &_lb_error);
  detail::check(_lb_status, _lb_error);
  return detail::from2(_lb_result);
}

inline Marker produce_marker() {
  zeropayloadcheckedrecords_error _lb_error{}; size_t _lb_budget = 16u * 1024u * 1024u; (void)_lb_budget;
  zeropayloadcheckedrecords_marker _lb_result{};
  detail::Owned<zeropayloadcheckedrecords_marker, zeropayloadcheckedrecords_marker_clear> _lb_owner{&_lb_result};
  const auto _lb_status = zeropayloadcheckedrecords_produce_marker(&_lb_result, &_lb_error);
  detail::check(_lb_status, _lb_error);
  return detail::from3(_lb_result);
}

inline Token produce_token() {
  zeropayloadcheckedrecords_error _lb_error{}; size_t _lb_budget = 16u * 1024u * 1024u; (void)_lb_budget;
  zeropayloadcheckedrecords_token _lb_result{};
  detail::Owned<zeropayloadcheckedrecords_token, zeropayloadcheckedrecords_token_clear> _lb_owner{&_lb_result};
  const auto _lb_status = zeropayloadcheckedrecords_produce_token(&_lb_result, &_lb_error);
  detail::check(_lb_status, _lb_error);
  return detail::from7(_lb_result);
}

inline Witness produce_witness() {
  zeropayloadcheckedrecords_error _lb_error{}; size_t _lb_budget = 16u * 1024u * 1024u; (void)_lb_budget;
  zeropayloadcheckedrecords_witness _lb_result{};
  detail::Owned<zeropayloadcheckedrecords_witness, zeropayloadcheckedrecords_witness_clear> _lb_owner{&_lb_result};
  const auto _lb_status = zeropayloadcheckedrecords_produce_witness(&_lb_result, &_lb_error);
  detail::check(_lb_status, _lb_error);
  return detail::from0(_lb_result);
}

inline void token_tag(Token const& value0) {
  zeropayloadcheckedrecords_error _lb_error{}; size_t _lb_budget = 16u * 1024u * 1024u; (void)_lb_budget;
  detail::check7(value0, _lb_budget);
  detail::View7 _lb_arg0{value0};
  const auto _lb_status = zeropayloadcheckedrecords_token_tag(&_lb_arg0.value, &_lb_error);
  detail::check(_lb_status, _lb_error);
}

inline Nat witness_count(Witness const& value0) {
  zeropayloadcheckedrecords_error _lb_error{}; size_t _lb_budget = 16u * 1024u * 1024u; (void)_lb_budget;
  detail::check0(value0, _lb_budget);
  detail::View0 _lb_arg0{value0};
  zeropayloadcheckedrecords_nat _lb_result{};
  detail::Owned<zeropayloadcheckedrecords_nat, zeropayloadcheckedrecords_nat_clear> _lb_owner{&_lb_result};
  const auto _lb_status = zeropayloadcheckedrecords_witness_count(&_lb_arg0.value, &_lb_result, &_lb_error);
  detail::check(_lb_status, _lb_error);
  return detail::from1(_lb_result);
}

inline std::vector<Witness> witnesses(Nat const& value0) {
  zeropayloadcheckedrecords_error _lb_error{}; size_t _lb_budget = 16u * 1024u * 1024u; (void)_lb_budget;
  detail::check1(value0, _lb_budget);
  detail::View1 _lb_arg0{value0};
  zeropayloadcheckedrecords_array_lean_zero_payload_checked_records_witness_span _lb_result{};
  detail::Owned<zeropayloadcheckedrecords_array_lean_zero_payload_checked_records_witness_span, zeropayloadcheckedrecords_array_lean_zero_payload_checked_records_witness_span_clear> _lb_owner{&_lb_result};
  const auto _lb_status = zeropayloadcheckedrecords_witnesses(&_lb_arg0.value, &_lb_result, &_lb_error);
  detail::check(_lb_status, _lb_error);
  return detail::from8(_lb_result);
}
}
