include(CMakeFindDependencyMacro)
find_dependency(Threads REQUIRED)
get_filename_component(_LB_PREFIX "${CMAKE_CURRENT_LIST_DIR}/../../.." ABSOLUTE)
if(NOT TARGET LeanBridge::owned_subtypes_cpp)
  add_library(LeanBridge::owned_subtypes_cpp SHARED IMPORTED)
  set_target_properties(LeanBridge::owned_subtypes_cpp PROPERTIES
    IMPORTED_LOCATION "${_LB_PREFIX}/lib/libowned_subtypes.so"
    INTERFACE_INCLUDE_DIRECTORIES "${_LB_PREFIX}/include"
    INTERFACE_COMPILE_FEATURES "cxx_std_20"
    INTERFACE_COMPILE_DEFINITIONS "BOOST_MP_STANDALONE"
    INTERFACE_LINK_LIBRARIES "${_LB_PREFIX}/lib/libgmp.so.10;Threads::Threads"
  )
endif()
unset(_LB_PREFIX)
