#pragma once
#include "owned_subtypes-conversions.hpp"
#include <concepts>
#include <exception>
#include <functional>
#include <unordered_map>
namespace lean_bridge::owned_subtypes {
namespace detail {
struct OwnedCall {
  std::shared_ptr<State> state; OwnedBudget budget; std::exception_ptr error;
  explicit OwnedCall(std::shared_ptr<State> value) : state(std::move(value)) {}
  ~OwnedCall() { state->drain(); }
};
template<class F, class R> struct RecoveredCallback { F function; R recovery; };
template<class F> constexpr bool owned_has_recovery = false;
template<class F, class R> constexpr bool owned_has_recovery<RecoveredCallback<F, R>> = true;
template<class F, class Expected> constexpr bool owned_recovery_matches = true;
template<class F, class R, class Expected> constexpr bool owned_recovery_matches<RecoveredCallback<F, R>, Expected> = std::same_as<R, Expected>;
template<class F> inline F& owned_function(F& function) { return function; }
template<class F, class R> inline F& owned_function(RecoveredCallback<F, R>& function) { return function.function; }
template<class F, class R> inline const F& owned_function(const RecoveredCallback<F, R>& function) { return function.function; }
struct OwnedInputTransfers {
  struct Entry { std::shared_ptr<Lease> lease; size_t group; };
  std::shared_ptr<State> state;
  OwnedBudget budget;
  std::vector<std::shared_ptr<InputMoveSignal>> groups;
  std::unordered_map<Lease *, Entry> leases;
  bool finished = false;
  OwnedInputTransfers(std::shared_ptr<State> input, size_t count) : state(std::move(input)) {
    budget.storage(count, sizeof(InputMoveSignal) + sizeof(std::shared_ptr<InputMoveSignal>));
    groups.reserve(count);
    for (size_t i = 0; i < count; ++i) groups.push_back(std::make_shared<InputMoveSignal>());
  }
  OwnedInputTransfers(const OwnedInputTransfers&) = delete;
  OwnedInputTransfers& operator=(const OwnedInputTransfers&) = delete;
  ~OwnedInputTransfers() { finish(); }
  void add(std::shared_ptr<Lease> lease, size_t group) {
    lease->require_transfer();
    if (lease->state() != state || group >= groups.size()) throw Error(OWNED_SUBTYPES_INVALID_ARGUMENT);
    const auto prior = leases.find(lease.get());
    if (prior != leases.end()) {
      if (prior->second.group != group) throw Error(OWNED_SUBTYPES_INVALID_ARGUMENT);
      return;
    }
    budget.storage(1, sizeof(Entry) + 4 * sizeof(void *));
    auto *identity = lease.get(); leases.emplace(identity, Entry{std::move(lease), group});
  }
  owned_subtypes_result **owner(size_t index) { return groups.at(index)->slot(); }
  void arm() {
    for (const auto& group : groups)
      if (!group->owner.value) throw Error(OWNED_SUBTYPES_INVALID_ARGUMENT);
    for (const auto& [identity, entry] : leases) { (void)identity; entry.lease->require_transfer(); }
    for (const auto& [identity, entry] : leases) { (void)identity; entry.lease->begin_transfer(groups[entry.group]); }
    for (const auto& group : groups) group->armed = true;
  }
  void finish() noexcept {
    if (finished) return;
    finished = true;
    for (const auto& group : groups) group->completed.store(group->consumed());
    for (const auto& [identity, entry] : leases) {
      (void)identity; entry.lease->finish_transfer(groups[entry.group]);
    }
  }
};
inline void owned_move_leases0(const Value82551d965c182180b0dd& source, size_t depth, OwnedInputTransfers& moves, size_t group);
inline void owned_move_leases1(const Value659ec6a690764999d00d& source, size_t depth, OwnedInputTransfers& moves, size_t group);
inline void owned_move_leases2(const Value817592654f48ba756bd4& source, size_t depth, OwnedInputTransfers& moves, size_t group);
inline void owned_move_leases3(const Callback40c82bf938a942cf2402& source, size_t depth, OwnedInputTransfers& moves, size_t group);
inline void owned_move_leases4(const Bundle& source, size_t depth, OwnedInputTransfers& moves, size_t group);
inline void owned_move_leases5(const CallbackBundle& source, size_t depth, OwnedInputTransfers& moves, size_t group);
inline void owned_move_leases6(const CallbackPayload& source, size_t depth, OwnedInputTransfers& moves, size_t group);
inline void owned_move_leases7(const Payload& source, size_t depth, OwnedInputTransfers& moves, size_t group);
inline void owned_move_leases8(const Ticket& source, size_t depth, OwnedInputTransfers& moves, size_t group);
inline void owned_move_leases9(const std::vector<uint8_t>& source, size_t depth, OwnedInputTransfers& moves, size_t group);
inline void owned_move_leases10(const Int& source, size_t depth, OwnedInputTransfers& moves, size_t group);
inline void owned_move_leases11(const Nat& source, size_t depth, OwnedInputTransfers& moves, size_t group);
inline void owned_move_leases12(const std::string& source, size_t depth, OwnedInputTransfers& moves, size_t group);
inline void owned_move_leases0(const Value82551d965c182180b0dd& source, size_t depth, OwnedInputTransfers& moves, size_t group) {
  (void)source; (void)depth; (void)moves; (void)group;
  moves.budget.enter(depth);
  for (const auto& item : source) owned_move_leases8(item, depth + 1, moves, group);
}
inline void owned_move_leases1(const Value659ec6a690764999d00d& source, size_t depth, OwnedInputTransfers& moves, size_t group) {
  (void)source; (void)depth; (void)moves; (void)group;
  moves.budget.enter(depth);
  for (const auto& item : source) owned_move_leases8(item, depth + 1, moves, group);
}
inline void owned_move_leases2(const Value817592654f48ba756bd4& source, size_t depth, OwnedInputTransfers& moves, size_t group) {
  (void)source; (void)depth; (void)moves; (void)group;
  moves.budget.enter(depth);
  if (source) {
  owned_move_leases8(*source, depth + 1, moves, group);
  }
}
inline void owned_move_leases3(const Callback40c82bf938a942cf2402& source, size_t depth, OwnedInputTransfers& moves, size_t group) {
  (void)source; (void)depth; (void)moves; (void)group;
  moves.budget.enter(depth);
  moves.add(ResourceAccess::lease(source, moves.state), group);
}
inline void owned_move_leases4(const Bundle& source, size_t depth, OwnedInputTransfers& moves, size_t group) {
  (void)source; (void)depth; (void)moves; (void)group;
  moves.budget.enter(depth);
  owned_move_leases8(source.primary, depth + 1, moves, group);
  owned_move_leases2(source.spare, depth + 1, moves, group);
  owned_move_leases1(source.peers, depth + 1, moves, group);
  owned_move_leases0(source.history, depth + 1, moves, group);
}
inline void owned_move_leases5(const CallbackBundle& source, size_t depth, OwnedInputTransfers& moves, size_t group) {
  (void)source; (void)depth; (void)moves; (void)group;
  moves.budget.enter(depth);
  owned_move_leases8(source.primary, depth + 1, moves, group);
}
inline void owned_move_leases6(const CallbackPayload& source, size_t depth, OwnedInputTransfers& moves, size_t group) {
  (void)source; (void)depth; (void)moves; (void)group;
}
inline void owned_move_leases7(const Payload& source, size_t depth, OwnedInputTransfers& moves, size_t group) {
  (void)source; (void)depth; (void)moves; (void)group;
}
inline void owned_move_leases8(const Ticket& source, size_t depth, OwnedInputTransfers& moves, size_t group) {
  (void)source; (void)depth; (void)moves; (void)group;
  moves.budget.enter(depth);
  moves.add(ResourceAccess::lease(source, moves.state), group);
}
inline void owned_move_leases9(const std::vector<uint8_t>& source, size_t depth, OwnedInputTransfers& moves, size_t group) {
  (void)source; (void)depth; (void)moves; (void)group;
}
inline void owned_move_leases10(const Int& source, size_t depth, OwnedInputTransfers& moves, size_t group) {
  (void)source; (void)depth; (void)moves; (void)group;
}
inline void owned_move_leases11(const Nat& source, size_t depth, OwnedInputTransfers& moves, size_t group) {
  (void)source; (void)depth; (void)moves; (void)group;
}
inline void owned_move_leases12(const std::string& source, size_t depth, OwnedInputTransfers& moves, size_t group) {
  (void)source; (void)depth; (void)moves; (void)group;
}
template<class F> concept OwnedCallback3 = std::same_as<std::remove_cvref_t<F>, Callback40c82bf938a942cf2402> || (
  true
  && owned_recovery_matches<std::remove_cvref_t<F>, CallbackBundle>
  && requires(F& function, const CallbackBundle& a0) {
    { std::invoke(owned_function(function), a0) } -> std::same_as<CallbackBundle>;
  });
template<class F> requires OwnedCallback3<F> struct OwnedCallbackView3 {
  F& function; OwnedCall& call;
  std::unique_ptr<OwnedView5> recovery;
  owned_subtypes_callback_record_argument1_t_host value{};
  static owned_subtypes_status invoke(void *context, owned_subtypes_session *session, owned_subtypes_callback_bundle_t const * a0, owned_subtypes_callback_bundle_t *out, owned_subtypes_result **owner) noexcept {
    auto& self = *static_cast<OwnedCallbackView3 *>(context);
    if (self.call.error) return OWNED_SUBTYPES_CALLBACK_FAILED;
    try {
      if (self.call.state->require() != session || !out || !owner || *owner) throw Error(OWNED_SUBTYPES_INVALID_ARGUMENT);
      BorrowFrame frame(self.call.state); OwnedOutput borrowed(self.call.state, frame.lease);
      auto argument0 = owned_from5(owned_read(a0), 0, self.call.budget, borrowed);
      auto reply = std::invoke(owned_function(self.function), std::as_const(argument0));
      owned_check5(reply, 0, self.call.budget, self.call.state);
      OwnedView5 view(reply, self.call.state);
      owned_subtypes_callback_bundle_t converted{}; NativeOwner retained;
      checked(owned_subtypes_callback_bundle_t_copy(self.call.state->require(), &view.value, &converted, &retained.value));
      *out = converted; *owner = std::exchange(retained.value, nullptr);
      return OWNED_SUBTYPES_OK;
    } catch (...) {
      if (!self.call.error) self.call.error = std::current_exception();
      return OWNED_SUBTYPES_CALLBACK_FAILED;
    }
  }
  OwnedCallbackView3(F& input, OwnedCall& scope) : function(input), call(scope) {
    if constexpr (std::same_as<std::remove_cvref_t<F>, Callback40c82bf938a942cf2402>) {
      value.closure = ResourceAccess::get<owned_subtypes_callback_record_argument1_t>(input, scope.state);
    } else {
      value.call = &invoke; value.context = this;
      if constexpr (owned_has_recovery<std::remove_cvref_t<F>>) {
        recovery = std::make_unique<OwnedView5>(input.recovery, scope.state);
        value.recovery = &recovery->value;
      }
    }
  }
  OwnedCallbackView3(const OwnedCallbackView3&) = delete;
  OwnedCallbackView3& operator=(const OwnedCallbackView3&) = delete;
};
template<class F> requires OwnedCallback3<F> inline void owned_check_callback3(F& input, OwnedCall& call) {
  if constexpr (std::same_as<std::remove_cvref_t<F>, Callback40c82bf938a942cf2402>) owned_check3(input, 0, call.budget, call.state);
  else {
    call.budget.enter(0); call.budget.native(1, sizeof(owned_subtypes_callback_record_argument1_t_host));
    call.budget.storage(1, sizeof(OwnedCallbackView3<F>));
    if constexpr (owned_has_recovery<std::remove_cvref_t<F>>)
      owned_check5(input.recovery, 0, call.budget, call.state);
  }
}
template<class F1>
requires (OwnedCallback3<F1>)
inline CallbackBundle owned_invoke0(const CallbackBundle& a0, F1&& a1) {
  OwnedCall call(current_state());
  owned_check5(a0, 0, call.budget, call.state);
  owned_check_callback3(a1, call);
  OwnedView5 view0(a0, call.state);
  OwnedCallbackView3<std::remove_reference_t<F1>> view1(a1, call);
  owned_subtypes_callback_bundle_t returned{}; OwnedOutput output(call.state);
  const auto status = owned_subtypes_callback_record(call.state->require(), &view0.value, &view1.value, &returned, &output.owner.value);
  if (call.error) std::rethrow_exception(call.error);
  checked(status);
  return owned_from5(returned, 0, call.budget, output);
}
inline Bundle owned_invoke1(const Bundle& a0) {
  OwnedCall call(current_state());
  owned_check4(a0, 0, call.budget, call.state);
  OwnedView4 view0(a0, call.state);
  owned_subtypes_bundle_t returned{}; OwnedOutput output(call.state);
  const auto status = owned_subtypes_echo_record(call.state->require(), &view0.value, &returned, &output.owner.value);
  if (call.error) std::rethrow_exception(call.error);
  checked(status);
  return owned_from4(returned, 0, call.budget, output);
}
inline Bundle owned_invoke2(const Bundle& a0) {
  OwnedCall call(current_state());
  owned_check4(a0, 0, call.budget, call.state);
  OwnedView4 view0(a0, call.state);
  owned_subtypes_bundle_t returned{}; OwnedOutput output(call.state);
  const auto status = owned_subtypes_echo_record_alternate(call.state->require(), &view0.value, &returned, &output.owner.value);
  if (call.error) std::rethrow_exception(call.error);
  checked(status);
  return owned_from4(returned, 0, call.budget, output);
}
inline Ticket owned_invoke3(const Nat& a0, const std::string& a1) {
  OwnedCall call(current_state());
  owned_check11(a0, 0, call.budget, call.state);
  owned_check12(a1, 0, call.budget, call.state);
  OwnedView11 view0(a0, call.state);
  OwnedView12 view1(a1, call.state);
  owned_subtypes_ticket_t returned{}; OwnedOutput output(call.state);
  const auto status = owned_subtypes_new_ticket(call.state->require(), view0.value, view1.value, &returned, &output.owner.value);
  if (call.error) std::rethrow_exception(call.error);
  checked(status);
  return owned_from8(returned, 0, call.budget, output);
}
inline Nat owned_invoke4(const Ticket& a0) {
  OwnedCall call(current_state());
  owned_check8(a0, 0, call.budget, call.state);
  OwnedView8 view0(a0, call.state);
  mpz_srcptr returned{}; OwnedOutput output(call.state);
  const auto status = owned_subtypes_serial(call.state->require(), view0.value, &returned, &output.owner.value);
  if (call.error) std::rethrow_exception(call.error);
  checked(status);
  return owned_from11(returned, 0, call.budget, output);
}
inline Bundle owned_invoke5(Bundle&& a0) {
  OwnedCall call(current_state());
  owned_check4(a0, 0, call.budget, call.state);
  OwnedView4 view0(a0, call.state);
  owned_subtypes_bundle_t returned{}; OwnedOutput output(call.state);
  OwnedInputTransfers moves(call.state, 1);
  owned_move_leases4(a0, 0, moves, 0);
  owned_subtypes_bundle_t moved0{};
  checked(owned_subtypes_bundle_t_copy(call.state->require(), &view0.value, &moved0, moves.owner(0)));
  auto *session = call.state->require();
  moves.arm();
  const auto status = owned_subtypes_transfer_record(session, &moved0, moves.owner(0), &returned, &output.owner.value);
  moves.finish();
  if (call.error) std::rethrow_exception(call.error);
  checked(status);
  return owned_from4(returned, 0, call.budget, output);
}
inline CallbackBundle owned_invoke6(const Callback40c82bf938a942cf2402& a0, const CallbackBundle& a1) {
  OwnedCall call(current_state());
  owned_check3(a0, 0, call.budget, call.state);
  owned_check5(a1, 0, call.budget, call.state);
  OwnedView3 view0(a0, call.state);
  OwnedView5 view1(a1, call.state);
  owned_subtypes_callback_bundle_t returned{}; OwnedOutput output(call.state);
  const auto status = owned_subtypes_callback_record_argument1_t_call(call.state->require(), view0.value, &view1.value, &returned, &output.owner.value);
  if (call.error) std::rethrow_exception(call.error);
  checked(status);
  return owned_from5(returned, 0, call.budget, output);
}
inline Callback40c82bf938a942cf2402 owned_invoke7(const Callback40c82bf938a942cf2402& a0) {
  OwnedCall call(current_state());
  owned_check3(a0, 0, call.budget, call.state);
  OwnedView3 view0(a0, call.state);
  owned_subtypes_callback_record_argument1_t returned{}; OwnedOutput output(call.state);
  const auto status = owned_subtypes_callback_record_argument1_t_retain(call.state->require(), view0.value, &returned, &output.owner.value);
  if (call.error) std::rethrow_exception(call.error);
  checked(status);
  return owned_from3(returned, 0, call.budget, output);
}
inline Ticket owned_invoke8(const Ticket& a0) {
  OwnedCall call(current_state());
  owned_check8(a0, 0, call.budget, call.state);
  OwnedView8 view0(a0, call.state);
  owned_subtypes_ticket_t returned{}; OwnedOutput output(call.state);
  const auto status = owned_subtypes_ticket_t_retain(call.state->require(), view0.value, &returned, &output.owner.value);
  if (call.error) std::rethrow_exception(call.error);
  checked(status);
  return owned_from8(returned, 0, call.budget, output);
}
template<> struct ResourceOps<Identity6f9a0eb5450512cec111> {
  static Callback40c82bf938a942cf2402 retain(const Callback40c82bf938a942cf2402& self) { return owned_invoke7(self); }
  static CallbackBundle call(const Callback40c82bf938a942cf2402& self, const CallbackBundle& a1) {
    return owned_invoke6(self, a1);
  }
};
template<> struct ResourceOps<Identity6de8e950bc342c30091c> {
  static Ticket retain(const Ticket& self) { return owned_invoke8(self); }
};
}
// Recovery supplies a typed failure-path value for Lean cleanup, never a successful host result.
template<class F, class R> inline auto with_recovery(F&& function, R&& recovery) {
  return detail::RecoveredCallback<std::decay_t<F>, std::decay_t<R>>{std::forward<F>(function), std::forward<R>(recovery)};
}
template<class F1>
requires (detail::OwnedCallback3<F1>)
inline CallbackBundle callback_record(const CallbackBundle& a0, F1&& a1) {
  return detail::owned_invoke0(a0, std::forward<F1>(a1));
}
inline Bundle echo_record(const Bundle& a0) {
  return detail::owned_invoke1(a0);
}
inline Bundle echo_record_alternate(const Bundle& a0) {
  return detail::owned_invoke2(a0);
}
inline Ticket new_ticket(const Nat& a0, const std::string& a1) {
  return detail::owned_invoke3(a0, a1);
}
inline Nat serial(const Ticket& a0) {
  return detail::owned_invoke4(a0);
}
inline Bundle transfer_record(Bundle&& a0) {
  return detail::owned_invoke5(std::move(a0));
}
}
