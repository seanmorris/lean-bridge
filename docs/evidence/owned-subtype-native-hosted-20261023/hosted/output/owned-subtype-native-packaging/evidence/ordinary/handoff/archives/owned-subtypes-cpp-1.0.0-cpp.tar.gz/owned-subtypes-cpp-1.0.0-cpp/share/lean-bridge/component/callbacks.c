#include "component.h"
#include "lean_bridge_native_runtime.h"
static _Thread_local int lean_bridge_owned_callback_failure_b14a53e5ed1fffe72e9d_state;
int lean_bridge_owned_callback_failure_b14a53e5ed1fffe72e9d(void) { int result = lean_bridge_owned_callback_failure_b14a53e5ed1fffe72e9d_state; lean_bridge_owned_callback_failure_b14a53e5ed1fffe72e9d_state = 0; return result; }
lean_object *lean_bridge_owned_e89c62145fc2160e00d5df99_t6f9a0eb5450512cec111_invoke(size_t token, lean_object *a0) {
  lb_native_callback callback = lb_native_callback_lookup(token);
  if (!callback.invoke) {
    lean_dec(a0);
    return lean_alloc_array(0, 0);
  }
  return ((lean_object *(*)(void *, lean_object *))callback.invoke)(callback.context, a0);
}
