#pragma once
#include "owned_subtypes-values.hpp"
#include <climits>
#include <cstring>
#include <iterator>
namespace lean_bridge::owned_subtypes::detail {
static_assert(sizeof(void*) == 8 && sizeof(size_t) == 8 && CHAR_BIT == 8 && sizeof(bool) == 1, "Verified native ownership ABI requires 64-bit pointers and 8-bit bytes");
struct OwnedBudget {
  size_t nodes = 262144, native_bytes = 16777216, storage_bytes = 16777216;
  static void charge(size_t& available, size_t count, size_t width) {
    if (width && count > available / width) throw Error(OWNED_SUBTYPES_LIMIT);
    available -= count * width;
  }
  void enter(size_t depth) { if (depth > 128 || !nodes) throw Error(OWNED_SUBTYPES_LIMIT); --nodes; }
  void native(size_t count, size_t width) { charge(native_bytes, count, width); }
  void storage(size_t count, size_t width) { charge(storage_bytes, count, width); }
};
template<class T> inline const T& owned_read(const T *value) {
  const auto address = reinterpret_cast<uintptr_t>(value);
  if (!value || address % alignof(T) || sizeof(T) > UINTPTR_MAX - address) throw Error(OWNED_SUBTYPES_MALFORMED_RESULT);
  return *value;
}
template<class T> inline void owned_span(const T *data, size_t count) {
  if (count) {
    if (count > (UINTPTR_MAX - reinterpret_cast<uintptr_t>(data)) / sizeof(T)) throw Error(OWNED_SUBTYPES_MALFORMED_RESULT);
    (void)owned_read(data);
  }
}
inline bool owned_bool(const bool& source) {
  uint8_t value; std::memcpy(&value, &source, 1);
  if (value > 1) throw Error(OWNED_SUBTYPES_MALFORMED_RESULT);
  return value != 0;
}
inline void owned_utf8(const char *data, size_t length, owned_subtypes_status status) {
  size_t i = 0;
  while (i < length) {
    uint32_t value = static_cast<uint8_t>(data[i++]), minimum; size_t remaining;
    if (value < 0x80) continue;
    if (value >= 0xc2 && value <= 0xdf) { value &= 0x1f; minimum = 0x80; remaining = 1; }
    else if (value >= 0xe0 && value <= 0xef) { value &= 0x0f; minimum = 0x800; remaining = 2; }
    else if (value >= 0xf0 && value <= 0xf4) { value &= 7; minimum = 0x10000; remaining = 3; }
    else throw Error(status);
    if (remaining > length - i) throw Error(status);
    while (remaining--) {
      uint8_t next = static_cast<uint8_t>(data[i++]);
      if ((next & 0xc0) != 0x80) throw Error(status);
      value = (value << 6) | (next & 0x3f);
    }
    if (value < minimum || value > 0x10ffff || (value >= 0xd800 && value <= 0xdfff)) throw Error(status);
  }
}
struct OwnedOutput {
  NativeOwner owner;
  std::shared_ptr<State> state;
  std::shared_ptr<Lease> lease;
  explicit OwnedOutput(std::shared_ptr<State> input, std::shared_ptr<Lease> borrowed = {})
    : state(std::move(input)), lease(std::move(borrowed)) {}
  const std::shared_ptr<Lease>& hold() {
    if (!lease) {
      if (!owner.value) throw Error(OWNED_SUBTYPES_MALFORMED_RESULT);
      lease = state->adopt(owner);
    }
    lease->require(); return lease;
  }
};
inline size_t owned_integer_limbs(const Nat& source) {
  auto high = source.backend().limbs()[source.backend().size() - 1]; size_t bits = 0;
  while (high) { ++bits; high >>= 1; }
  bits += (source.backend().size() - 1) * sizeof(*source.backend().limbs()) * CHAR_BIT;
  return (bits + GMP_NUMB_BITS - 1) / GMP_NUMB_BITS;
}
struct OwnedIntegerView {
  std::vector<mp_limb_t> limbs;
  __mpz_struct value{};
  explicit OwnedIntegerView(const Int& source) {
    limbs.reserve(owned_integer_limbs(source));
    if (source != 0) boost::multiprecision::export_bits(source, std::back_inserter(limbs), GMP_NUMB_BITS, false);
    const auto length = static_cast<mp_size_t>(limbs.size());
    (void)mpz_roinit_n(&value, limbs.data(), source < 0 ? -length : length);
  }
  OwnedIntegerView(const OwnedIntegerView&) = delete;
  OwnedIntegerView& operator=(const OwnedIntegerView&) = delete;
  // mpz_roinit_n borrows the C++ limb vector. Never clear or mutate this GMP view.
};

struct OwnedView0;
inline void owned_check0(const Value82551d965c182180b0dd&, size_t, OwnedBudget&, const std::shared_ptr<State>&);
inline Value82551d965c182180b0dd owned_from0(const owned_subtypes_value_82551d965c182180b0dd_t&, size_t, OwnedBudget&, OwnedOutput&);
struct OwnedView1;
inline void owned_check1(const Value659ec6a690764999d00d&, size_t, OwnedBudget&, const std::shared_ptr<State>&);
inline Value659ec6a690764999d00d owned_from1(const owned_subtypes_value_659ec6a690764999d00d_t&, size_t, OwnedBudget&, OwnedOutput&);
struct OwnedView2;
inline void owned_check2(const Value817592654f48ba756bd4&, size_t, OwnedBudget&, const std::shared_ptr<State>&);
inline Value817592654f48ba756bd4 owned_from2(const owned_subtypes_value_817592654f48ba756bd4_t&, size_t, OwnedBudget&, OwnedOutput&);
struct OwnedView3;
inline void owned_check3(const Callback40c82bf938a942cf2402&, size_t, OwnedBudget&, const std::shared_ptr<State>&);
inline Callback40c82bf938a942cf2402 owned_from3(const owned_subtypes_callback_record_argument1_t&, size_t, OwnedBudget&, OwnedOutput&);
struct OwnedView4;
inline void owned_check4(const Bundle&, size_t, OwnedBudget&, const std::shared_ptr<State>&);
inline Bundle owned_from4(const owned_subtypes_bundle_t&, size_t, OwnedBudget&, OwnedOutput&);
struct OwnedView5;
inline void owned_check5(const CallbackBundle&, size_t, OwnedBudget&, const std::shared_ptr<State>&);
inline CallbackBundle owned_from5(const owned_subtypes_callback_bundle_t&, size_t, OwnedBudget&, OwnedOutput&);
struct OwnedView6;
inline void owned_check6(const CallbackPayload&, size_t, OwnedBudget&, const std::shared_ptr<State>&);
inline CallbackPayload owned_from6(const owned_subtypes_callback_payload_t&, size_t, OwnedBudget&, OwnedOutput&);
struct OwnedView7;
inline void owned_check7(const Payload&, size_t, OwnedBudget&, const std::shared_ptr<State>&);
inline Payload owned_from7(const owned_subtypes_payload_t&, size_t, OwnedBudget&, OwnedOutput&);
struct OwnedView8;
inline void owned_check8(const Ticket&, size_t, OwnedBudget&, const std::shared_ptr<State>&);
inline Ticket owned_from8(const owned_subtypes_ticket_t&, size_t, OwnedBudget&, OwnedOutput&);
struct OwnedView9;
inline void owned_check9(const std::vector<uint8_t>&, size_t, OwnedBudget&, const std::shared_ptr<State>&);
inline std::vector<uint8_t> owned_from9(const owned_subtypes_scalar_bytes_t&, size_t, OwnedBudget&, OwnedOutput&);
struct OwnedView10;
inline void owned_check10(const Int&, size_t, OwnedBudget&, const std::shared_ptr<State>&);
inline Int owned_from10(const mpz_srcptr&, size_t, OwnedBudget&, OwnedOutput&);
struct OwnedView11;
inline void owned_check11(const Nat&, size_t, OwnedBudget&, const std::shared_ptr<State>&);
inline Nat owned_from11(const mpz_srcptr&, size_t, OwnedBudget&, OwnedOutput&);
struct OwnedView12;
inline void owned_check12(const std::string&, size_t, OwnedBudget&, const std::shared_ptr<State>&);
inline std::string owned_from12(const owned_subtypes_scalar_string_t&, size_t, OwnedBudget&, OwnedOutput&);
struct OwnedView0 {
  std::vector<OwnedView8> items;
  std::unique_ptr<owned_subtypes_ticket_t[]> data;
  owned_subtypes_value_82551d965c182180b0dd_t value{};
  OwnedView0(const Value82551d965c182180b0dd&, const std::shared_ptr<State>&);
  ~OwnedView0();
  OwnedView0(OwnedView0&&) noexcept;
  OwnedView0(const OwnedView0&) = delete;
};
struct OwnedView1 {
  std::vector<OwnedView8> items;
  std::unique_ptr<owned_subtypes_ticket_t[]> data;
  owned_subtypes_value_659ec6a690764999d00d_t value{};
  OwnedView1(const Value659ec6a690764999d00d&, const std::shared_ptr<State>&);
  ~OwnedView1();
  OwnedView1(OwnedView1&&) noexcept;
  OwnedView1(const OwnedView1&) = delete;
};
struct OwnedView2 {
  std::unique_ptr<OwnedView8> field0;
  owned_subtypes_value_817592654f48ba756bd4_t value{};
  OwnedView2(const Value817592654f48ba756bd4&, const std::shared_ptr<State>&);
  ~OwnedView2();
  OwnedView2(OwnedView2&&) noexcept;
  OwnedView2(const OwnedView2&) = delete;
};
struct OwnedView3 {
  owned_subtypes_callback_record_argument1_t value{};
  OwnedView3(const Callback40c82bf938a942cf2402&, const std::shared_ptr<State>&);
  ~OwnedView3();
  OwnedView3(OwnedView3&&) noexcept;
  OwnedView3(const OwnedView3&) = delete;
};
struct OwnedView4 {
  std::unique_ptr<OwnedView8> field0;
  std::unique_ptr<OwnedView2> field1;
  std::unique_ptr<OwnedView1> field2;
  std::unique_ptr<OwnedView0> field3;
  std::unique_ptr<OwnedView7> field4;
  owned_subtypes_bundle_t value{};
  OwnedView4(const Bundle&, const std::shared_ptr<State>&);
  ~OwnedView4();
  OwnedView4(OwnedView4&&) noexcept;
  OwnedView4(const OwnedView4&) = delete;
};
struct OwnedView5 {
  std::unique_ptr<OwnedView8> field0;
  std::unique_ptr<OwnedView6> field1;
  owned_subtypes_callback_bundle_t value{};
  OwnedView5(const CallbackBundle&, const std::shared_ptr<State>&);
  ~OwnedView5();
  OwnedView5(OwnedView5&&) noexcept;
  OwnedView5(const OwnedView5&) = delete;
};
struct OwnedView6 {
  std::unique_ptr<OwnedView10> field0;
  std::unique_ptr<OwnedView9> field1;
  owned_subtypes_callback_payload_t value{};
  OwnedView6(const CallbackPayload&, const std::shared_ptr<State>&);
  ~OwnedView6();
  OwnedView6(OwnedView6&&) noexcept;
  OwnedView6(const OwnedView6&) = delete;
};
struct OwnedView7 {
  std::unique_ptr<OwnedView10> field0;
  std::unique_ptr<OwnedView9> field1;
  owned_subtypes_payload_t value{};
  OwnedView7(const Payload&, const std::shared_ptr<State>&);
  ~OwnedView7();
  OwnedView7(OwnedView7&&) noexcept;
  OwnedView7(const OwnedView7&) = delete;
};
struct OwnedView8 {
  owned_subtypes_ticket_t value{};
  OwnedView8(const Ticket&, const std::shared_ptr<State>&);
  ~OwnedView8();
  OwnedView8(OwnedView8&&) noexcept;
  OwnedView8(const OwnedView8&) = delete;
};
struct OwnedView9 {
  owned_subtypes_scalar_bytes_t value{};
  OwnedView9(const std::vector<uint8_t>&, const std::shared_ptr<State>&);
  ~OwnedView9();
  OwnedView9(OwnedView9&&) noexcept;
  OwnedView9(const OwnedView9&) = delete;
};
struct OwnedView10 {
  std::unique_ptr<OwnedIntegerView> integer;
  mpz_srcptr value{};
  OwnedView10(const Int&, const std::shared_ptr<State>&);
  ~OwnedView10();
  OwnedView10(OwnedView10&&) noexcept;
  OwnedView10(const OwnedView10&) = delete;
};
struct OwnedView11 {
  std::unique_ptr<OwnedIntegerView> integer;
  mpz_srcptr value{};
  OwnedView11(const Nat&, const std::shared_ptr<State>&);
  ~OwnedView11();
  OwnedView11(OwnedView11&&) noexcept;
  OwnedView11(const OwnedView11&) = delete;
};
struct OwnedView12 {
  owned_subtypes_scalar_string_t value{};
  OwnedView12(const std::string&, const std::shared_ptr<State>&);
  ~OwnedView12();
  OwnedView12(OwnedView12&&) noexcept;
  OwnedView12(const OwnedView12&) = delete;
};
inline OwnedView0::~OwnedView0() = default;
inline OwnedView0::OwnedView0(OwnedView0&&) noexcept = default;
inline void owned_check0(const Value82551d965c182180b0dd& source, size_t depth, OwnedBudget& budget, const std::shared_ptr<State>& state) {
  (void)source; (void)state; budget.enter(depth);
  budget.native(1, sizeof(owned_subtypes_value_82551d965c182180b0dd_t)); budget.storage(1, sizeof(OwnedView0));
  if (source.size() > budget.nodes) throw Error(OWNED_SUBTYPES_LIMIT);
  budget.native(source.size(), sizeof(owned_subtypes_ticket_t)); budget.storage(source.size(), sizeof(owned_subtypes_ticket_t));
  for (const auto& child : source) owned_check8(child, depth + 1, budget, state);
}
inline OwnedView0::OwnedView0(const Value82551d965c182180b0dd& source, const std::shared_ptr<State>& state) {
  (void)source; (void)state;
  items.reserve(source.size());
  data = source.empty() ? nullptr : std::make_unique<owned_subtypes_ticket_t[]>(source.size());
  for (const auto& child : source) items.emplace_back(child, state);
  for (size_t j = 0; j < source.size(); ++j) data[j] = items[j].value;
  value.data = data.get(); value.length = source.size();
}
inline Value82551d965c182180b0dd owned_from0(const owned_subtypes_value_82551d965c182180b0dd_t& source, size_t depth, OwnedBudget& budget, OwnedOutput& output) {
  (void)source; (void)output; budget.enter(depth);
  budget.native(1, sizeof(owned_subtypes_value_82551d965c182180b0dd_t)); budget.storage(1, sizeof(Value82551d965c182180b0dd));
  if (source.length > budget.nodes) throw Error(OWNED_SUBTYPES_LIMIT);
  budget.native(source.length, sizeof(owned_subtypes_ticket_t)); budget.storage(source.length, sizeof(Ticket));
  owned_span(source.data, source.length);
  Value82551d965c182180b0dd result; result.reserve(source.length);
  for (size_t j = 0; j < source.length; ++j) result.push_back(owned_from8(source.data[j], depth + 1, budget, output));
  return result;
}
inline OwnedView1::~OwnedView1() = default;
inline OwnedView1::OwnedView1(OwnedView1&&) noexcept = default;
inline void owned_check1(const Value659ec6a690764999d00d& source, size_t depth, OwnedBudget& budget, const std::shared_ptr<State>& state) {
  (void)source; (void)state; budget.enter(depth);
  budget.native(1, sizeof(owned_subtypes_value_659ec6a690764999d00d_t)); budget.storage(1, sizeof(OwnedView1));
  if (source.size() > budget.nodes) throw Error(OWNED_SUBTYPES_LIMIT);
  budget.native(source.size(), sizeof(owned_subtypes_ticket_t)); budget.storage(source.size(), sizeof(owned_subtypes_ticket_t));
  for (const auto& child : source) owned_check8(child, depth + 1, budget, state);
}
inline OwnedView1::OwnedView1(const Value659ec6a690764999d00d& source, const std::shared_ptr<State>& state) {
  (void)source; (void)state;
  items.reserve(source.size());
  data = source.empty() ? nullptr : std::make_unique<owned_subtypes_ticket_t[]>(source.size());
  for (const auto& child : source) items.emplace_back(child, state);
  for (size_t j = 0; j < source.size(); ++j) data[j] = items[j].value;
  value.data = data.get(); value.length = source.size();
}
inline Value659ec6a690764999d00d owned_from1(const owned_subtypes_value_659ec6a690764999d00d_t& source, size_t depth, OwnedBudget& budget, OwnedOutput& output) {
  (void)source; (void)output; budget.enter(depth);
  budget.native(1, sizeof(owned_subtypes_value_659ec6a690764999d00d_t)); budget.storage(1, sizeof(Value659ec6a690764999d00d));
  if (source.length > budget.nodes) throw Error(OWNED_SUBTYPES_LIMIT);
  budget.native(source.length, sizeof(owned_subtypes_ticket_t)); budget.storage(source.length, sizeof(Ticket));
  owned_span(source.data, source.length);
  Value659ec6a690764999d00d result; result.reserve(source.length);
  for (size_t j = 0; j < source.length; ++j) result.push_back(owned_from8(source.data[j], depth + 1, budget, output));
  return result;
}
inline OwnedView2::~OwnedView2() = default;
inline OwnedView2::OwnedView2(OwnedView2&&) noexcept = default;
inline void owned_check2(const Value817592654f48ba756bd4& source, size_t depth, OwnedBudget& budget, const std::shared_ptr<State>& state) {
  (void)source; (void)state; budget.enter(depth);
  budget.native(1, sizeof(owned_subtypes_value_817592654f48ba756bd4_t)); budget.storage(1, sizeof(OwnedView2));
  if (source.has_value()) {
  owned_check8(*source, depth + 1, budget, state);
  }
}
inline OwnedView2::OwnedView2(const Value817592654f48ba756bd4& source, const std::shared_ptr<State>& state) {
  (void)source; (void)state;
  value.has_value = source.has_value();
  if (source.has_value()) {
  field0 = std::make_unique<OwnedView8>(*source, state);
  value.value = field0->value;
  }
}
inline Value817592654f48ba756bd4 owned_from2(const owned_subtypes_value_817592654f48ba756bd4_t& source, size_t depth, OwnedBudget& budget, OwnedOutput& output) {
  (void)source; (void)output; budget.enter(depth);
  budget.native(1, sizeof(owned_subtypes_value_817592654f48ba756bd4_t)); budget.storage(1, sizeof(Value817592654f48ba756bd4));
  const bool selected = owned_bool(source.has_value);
  if (selected) return Value817592654f48ba756bd4{std::in_place, owned_from8(source.value, depth + 1, budget, output)};
  return std::nullopt;
}
inline OwnedView3::~OwnedView3() = default;
inline OwnedView3::OwnedView3(OwnedView3&&) noexcept = default;
inline void owned_check3(const Callback40c82bf938a942cf2402& source, size_t depth, OwnedBudget& budget, const std::shared_ptr<State>& state) {
  (void)source; (void)state; budget.enter(depth);
  budget.native(1, sizeof(owned_subtypes_callback_record_argument1_t)); budget.storage(1, sizeof(OwnedView3));
  (void)ResourceAccess::get<owned_subtypes_callback_record_argument1_t>(source, state);
}
inline OwnedView3::OwnedView3(const Callback40c82bf938a942cf2402& source, const std::shared_ptr<State>& state) {
  (void)source; (void)state;
  value = ResourceAccess::get<owned_subtypes_callback_record_argument1_t>(source, state);
}
inline Callback40c82bf938a942cf2402 owned_from3(const owned_subtypes_callback_record_argument1_t& source, size_t depth, OwnedBudget& budget, OwnedOutput& output) {
  (void)source; (void)output; budget.enter(depth);
  budget.native(1, sizeof(owned_subtypes_callback_record_argument1_t)); budget.storage(1, sizeof(Callback40c82bf938a942cf2402));
  if (!source) throw Error(OWNED_SUBTYPES_MALFORMED_RESULT);
  return ResourceAccess::make<Identity6f9a0eb5450512cec111>(output.hold(), source);
}
inline OwnedView4::~OwnedView4() = default;
inline OwnedView4::OwnedView4(OwnedView4&&) noexcept = default;
inline void owned_check4(const Bundle& source, size_t depth, OwnedBudget& budget, const std::shared_ptr<State>& state) {
  (void)source; (void)state; budget.enter(depth);
  budget.native(1, sizeof(owned_subtypes_bundle_t)); budget.storage(1, sizeof(OwnedView4));
  owned_check8(source.primary, depth + 1, budget, state);
  owned_check2(source.spare, depth + 1, budget, state);
  owned_check1(source.peers, depth + 1, budget, state);
  owned_check0(source.history, depth + 1, budget, state);
  owned_check7(source.payload, depth + 1, budget, state);
}
inline OwnedView4::OwnedView4(const Bundle& source, const std::shared_ptr<State>& state) {
  (void)source; (void)state;
  field0 = std::make_unique<OwnedView8>(source.primary, state);
  value.primary = field0->value;
  field1 = std::make_unique<OwnedView2>(source.spare, state);
  value.spare = &field1->value;
  field2 = std::make_unique<OwnedView1>(source.peers, state);
  value.peers = &field2->value;
  field3 = std::make_unique<OwnedView0>(source.history, state);
  value.history = &field3->value;
  field4 = std::make_unique<OwnedView7>(source.payload, state);
  value.payload = &field4->value;
}
inline Bundle owned_from4(const owned_subtypes_bundle_t& source, size_t depth, OwnedBudget& budget, OwnedOutput& output) {
  (void)source; (void)output; budget.enter(depth);
  budget.native(1, sizeof(owned_subtypes_bundle_t)); budget.storage(1, sizeof(Bundle));
  return Bundle{owned_from8(source.primary, depth + 1, budget, output), owned_from2(owned_read(source.spare), depth + 1, budget, output), owned_from1(owned_read(source.peers), depth + 1, budget, output), owned_from0(owned_read(source.history), depth + 1, budget, output), owned_from7(owned_read(source.payload), depth + 1, budget, output)};
}
inline OwnedView5::~OwnedView5() = default;
inline OwnedView5::OwnedView5(OwnedView5&&) noexcept = default;
inline void owned_check5(const CallbackBundle& source, size_t depth, OwnedBudget& budget, const std::shared_ptr<State>& state) {
  (void)source; (void)state; budget.enter(depth);
  budget.native(1, sizeof(owned_subtypes_callback_bundle_t)); budget.storage(1, sizeof(OwnedView5));
  owned_check8(source.primary, depth + 1, budget, state);
  owned_check6(source.payload, depth + 1, budget, state);
}
inline OwnedView5::OwnedView5(const CallbackBundle& source, const std::shared_ptr<State>& state) {
  (void)source; (void)state;
  field0 = std::make_unique<OwnedView8>(source.primary, state);
  value.primary = field0->value;
  field1 = std::make_unique<OwnedView6>(source.payload, state);
  value.payload = &field1->value;
}
inline CallbackBundle owned_from5(const owned_subtypes_callback_bundle_t& source, size_t depth, OwnedBudget& budget, OwnedOutput& output) {
  (void)source; (void)output; budget.enter(depth);
  budget.native(1, sizeof(owned_subtypes_callback_bundle_t)); budget.storage(1, sizeof(CallbackBundle));
  return CallbackBundle{owned_from8(source.primary, depth + 1, budget, output), owned_from6(owned_read(source.payload), depth + 1, budget, output)};
}
inline OwnedView6::~OwnedView6() = default;
inline OwnedView6::OwnedView6(OwnedView6&&) noexcept = default;
inline void owned_check6(const CallbackPayload& source, size_t depth, OwnedBudget& budget, const std::shared_ptr<State>& state) {
  (void)source; (void)state; budget.enter(depth);
  budget.native(1, sizeof(owned_subtypes_callback_payload_t)); budget.storage(1, sizeof(OwnedView6));
  owned_check10(source.count, depth + 1, budget, state);
  owned_check9(source.bytes, depth + 1, budget, state);
}
inline OwnedView6::OwnedView6(const CallbackPayload& source, const std::shared_ptr<State>& state) {
  (void)source; (void)state;
  field0 = std::make_unique<OwnedView10>(source.count, state);
  value.count = field0->value;
  field1 = std::make_unique<OwnedView9>(source.bytes, state);
  value.bytes = field1->value;
}
inline CallbackPayload owned_from6(const owned_subtypes_callback_payload_t& source, size_t depth, OwnedBudget& budget, OwnedOutput& output) {
  (void)source; (void)output; budget.enter(depth);
  budget.native(1, sizeof(owned_subtypes_callback_payload_t)); budget.storage(1, sizeof(CallbackPayload));
  return CallbackPayload{owned_from10(source.count, depth + 1, budget, output), owned_from9(source.bytes, depth + 1, budget, output)};
}
inline OwnedView7::~OwnedView7() = default;
inline OwnedView7::OwnedView7(OwnedView7&&) noexcept = default;
inline void owned_check7(const Payload& source, size_t depth, OwnedBudget& budget, const std::shared_ptr<State>& state) {
  (void)source; (void)state; budget.enter(depth);
  budget.native(1, sizeof(owned_subtypes_payload_t)); budget.storage(1, sizeof(OwnedView7));
  owned_check10(source.count, depth + 1, budget, state);
  owned_check9(source.bytes, depth + 1, budget, state);
}
inline OwnedView7::OwnedView7(const Payload& source, const std::shared_ptr<State>& state) {
  (void)source; (void)state;
  field0 = std::make_unique<OwnedView10>(source.count, state);
  value.count = field0->value;
  field1 = std::make_unique<OwnedView9>(source.bytes, state);
  value.bytes = field1->value;
}
inline Payload owned_from7(const owned_subtypes_payload_t& source, size_t depth, OwnedBudget& budget, OwnedOutput& output) {
  (void)source; (void)output; budget.enter(depth);
  budget.native(1, sizeof(owned_subtypes_payload_t)); budget.storage(1, sizeof(Payload));
  return Payload{owned_from10(source.count, depth + 1, budget, output), owned_from9(source.bytes, depth + 1, budget, output)};
}
inline OwnedView8::~OwnedView8() = default;
inline OwnedView8::OwnedView8(OwnedView8&&) noexcept = default;
inline void owned_check8(const Ticket& source, size_t depth, OwnedBudget& budget, const std::shared_ptr<State>& state) {
  (void)source; (void)state; budget.enter(depth);
  budget.native(1, sizeof(owned_subtypes_ticket_t)); budget.storage(1, sizeof(OwnedView8));
  (void)ResourceAccess::get<owned_subtypes_ticket_t>(source, state);
}
inline OwnedView8::OwnedView8(const Ticket& source, const std::shared_ptr<State>& state) {
  (void)source; (void)state;
  value = ResourceAccess::get<owned_subtypes_ticket_t>(source, state);
}
inline Ticket owned_from8(const owned_subtypes_ticket_t& source, size_t depth, OwnedBudget& budget, OwnedOutput& output) {
  (void)source; (void)output; budget.enter(depth);
  budget.native(1, sizeof(owned_subtypes_ticket_t)); budget.storage(1, sizeof(Ticket));
  if (!source) throw Error(OWNED_SUBTYPES_MALFORMED_RESULT);
  return ResourceAccess::make<Identity6de8e950bc342c30091c>(output.hold(), source);
}
inline OwnedView9::~OwnedView9() = default;
inline OwnedView9::OwnedView9(OwnedView9&&) noexcept = default;
inline void owned_check9(const std::vector<uint8_t>& source, size_t depth, OwnedBudget& budget, const std::shared_ptr<State>& state) {
  (void)source; (void)state; budget.enter(depth);
  budget.native(1, sizeof(owned_subtypes_scalar_bytes_t)); budget.storage(1, sizeof(OwnedView9));
  budget.native(source.size(), 1);
}
inline OwnedView9::OwnedView9(const std::vector<uint8_t>& source, const std::shared_ptr<State>& state) {
  (void)source; (void)state;
  value.data = source.data(); value.length = source.size();
}
inline std::vector<uint8_t> owned_from9(const owned_subtypes_scalar_bytes_t& source, size_t depth, OwnedBudget& budget, OwnedOutput& output) {
  (void)source; (void)output; budget.enter(depth);
  budget.native(1, sizeof(owned_subtypes_scalar_bytes_t)); budget.storage(1, sizeof(std::vector<uint8_t>));
  budget.native(source.length, 1); owned_span(source.data, source.length);
  budget.storage(source.length, 1);
  return source.length ? std::vector<uint8_t>(source.data, source.data + source.length) : std::vector<uint8_t>{};
}
inline OwnedView10::~OwnedView10() = default;
inline OwnedView10::OwnedView10(OwnedView10&&) noexcept = default;
inline void owned_check10(const Int& source, size_t depth, OwnedBudget& budget, const std::shared_ptr<State>& state) {
  (void)source; (void)state; budget.enter(depth);
  budget.native(1, sizeof(mpz_srcptr)); budget.storage(1, sizeof(OwnedView10));
  if (source.backend().size() > budget.native_bytes / sizeof(boost::multiprecision::limb_type) + 1) throw Error(OWNED_SUBTYPES_LIMIT);
  const size_t count = owned_integer_limbs(source);
  budget.native(count, sizeof(mp_limb_t)); budget.storage(count, sizeof(mp_limb_t));
}
inline OwnedView10::OwnedView10(const Int& source, const std::shared_ptr<State>& state) {
  (void)source; (void)state;
  integer = std::make_unique<OwnedIntegerView>(source); value = &integer->value;
}
inline Int owned_from10(const mpz_srcptr& source, size_t depth, OwnedBudget& budget, OwnedOutput& output) {
  (void)source; (void)output; budget.enter(depth);
  budget.native(1, sizeof(mpz_srcptr)); budget.storage(1, sizeof(Int));
  const auto signed_count = owned_read(source)._mp_size;
  const size_t count = signed_count < 0 ? size_t(0) - static_cast<size_t>(signed_count) : static_cast<size_t>(signed_count);
  budget.native(count, sizeof(mp_limb_t)); budget.storage(count, sizeof(mp_limb_t));
  const mp_limb_t *limbs = mpz_limbs_read(source); owned_span(limbs, count);
  Int result = 0;
  if (count) boost::multiprecision::import_bits(result, limbs, limbs + count, GMP_NUMB_BITS, false);
  return mpz_sgn(source) < 0 ? -result : result;
}
inline OwnedView11::~OwnedView11() = default;
inline OwnedView11::OwnedView11(OwnedView11&&) noexcept = default;
inline void owned_check11(const Nat& source, size_t depth, OwnedBudget& budget, const std::shared_ptr<State>& state) {
  (void)source; (void)state; budget.enter(depth);
  budget.native(1, sizeof(mpz_srcptr)); budget.storage(1, sizeof(OwnedView11));
  if (source < 0) throw Error(OWNED_SUBTYPES_INVALID_ARGUMENT);
  if (source.backend().size() > budget.native_bytes / sizeof(boost::multiprecision::limb_type) + 1) throw Error(OWNED_SUBTYPES_LIMIT);
  const size_t count = owned_integer_limbs(source);
  budget.native(count, sizeof(mp_limb_t)); budget.storage(count, sizeof(mp_limb_t));
}
inline OwnedView11::OwnedView11(const Nat& source, const std::shared_ptr<State>& state) {
  (void)source; (void)state;
  integer = std::make_unique<OwnedIntegerView>(source); value = &integer->value;
}
inline Nat owned_from11(const mpz_srcptr& source, size_t depth, OwnedBudget& budget, OwnedOutput& output) {
  (void)source; (void)output; budget.enter(depth);
  budget.native(1, sizeof(mpz_srcptr)); budget.storage(1, sizeof(Nat));
  const auto signed_count = owned_read(source)._mp_size;
  const size_t count = signed_count < 0 ? size_t(0) - static_cast<size_t>(signed_count) : static_cast<size_t>(signed_count);
  budget.native(count, sizeof(mp_limb_t)); budget.storage(count, sizeof(mp_limb_t));
  const mp_limb_t *limbs = mpz_limbs_read(source); owned_span(limbs, count);
  if (mpz_sgn(source) < 0) throw Error(OWNED_SUBTYPES_MALFORMED_RESULT);
  Nat result = 0;
  if (count) boost::multiprecision::import_bits(result, limbs, limbs + count, GMP_NUMB_BITS, false);
  return result;
}
inline OwnedView12::~OwnedView12() = default;
inline OwnedView12::OwnedView12(OwnedView12&&) noexcept = default;
inline void owned_check12(const std::string& source, size_t depth, OwnedBudget& budget, const std::shared_ptr<State>& state) {
  (void)source; (void)state; budget.enter(depth);
  budget.native(1, sizeof(owned_subtypes_scalar_string_t)); budget.storage(1, sizeof(OwnedView12));
  budget.native(source.size(), 1);
  owned_utf8(source.data(), source.size(), OWNED_SUBTYPES_INVALID_ARGUMENT);
}
inline OwnedView12::OwnedView12(const std::string& source, const std::shared_ptr<State>& state) {
  (void)source; (void)state;
  value.data = source.data(); value.length = source.size();
}
inline std::string owned_from12(const owned_subtypes_scalar_string_t& source, size_t depth, OwnedBudget& budget, OwnedOutput& output) {
  (void)source; (void)output; budget.enter(depth);
  budget.native(1, sizeof(owned_subtypes_scalar_string_t)); budget.storage(1, sizeof(std::string));
  budget.native(source.length, 1); owned_span(source.data, source.length);
  budget.storage(source.length + 1, 1);
  owned_utf8(source.data, source.length, OWNED_SUBTYPES_MALFORMED_RESULT);
  return source.length ? std::string(source.data, source.length) : std::string{};
}
}
