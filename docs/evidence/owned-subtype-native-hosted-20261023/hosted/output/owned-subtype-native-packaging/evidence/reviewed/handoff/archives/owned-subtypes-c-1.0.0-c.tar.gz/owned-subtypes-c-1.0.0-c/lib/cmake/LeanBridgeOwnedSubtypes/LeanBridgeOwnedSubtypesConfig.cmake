get_filename_component(_LB_PREFIX "${CMAKE_CURRENT_LIST_DIR}/../../.." ABSOLUTE)
if(NOT TARGET LeanBridge::owned_subtypes)
  add_library(LeanBridge::owned_subtypes SHARED IMPORTED)
  set_target_properties(LeanBridge::owned_subtypes PROPERTIES
    IMPORTED_LOCATION "${_LB_PREFIX}/lib/libowned_subtypes.so"
    INTERFACE_INCLUDE_DIRECTORIES "${_LB_PREFIX}/include"
    INTERFACE_COMPILE_FEATURES "c_std_11"
    INTERFACE_LINK_LIBRARIES "${_LB_PREFIX}/lib/libgmp.so.10"
  )
endif()
unset(_LB_PREFIX)
