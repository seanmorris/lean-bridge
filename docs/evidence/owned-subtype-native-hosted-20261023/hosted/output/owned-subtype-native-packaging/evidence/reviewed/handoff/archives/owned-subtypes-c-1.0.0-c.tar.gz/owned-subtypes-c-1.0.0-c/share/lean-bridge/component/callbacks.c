#include "component.h"
#include "lean_bridge_native_runtime.h"
static _Thread_local int lean_bridge_owned_callback_failure_bbe082d0776c11894fd3_state;
int lean_bridge_owned_callback_failure_bbe082d0776c11894fd3(void) { int result = lean_bridge_owned_callback_failure_bbe082d0776c11894fd3_state; lean_bridge_owned_callback_failure_bbe082d0776c11894fd3_state = 0; return result; }
lean_object *lean_bridge_owned_ba1801b5778ad523eb19c133_t6f9a0eb5450512cec111_invoke(size_t token, lean_object *a0) {
  lb_native_callback callback = lb_native_callback_lookup(token);
  if (!callback.invoke) {
    lean_dec(a0);
    return lean_alloc_array(0, 0);
  }
  return ((lean_object *(*)(void *, lean_object *))callback.invoke)(callback.context, a0);
}
