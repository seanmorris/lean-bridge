#pragma once
#include <stdint.h>
#include <stddef.h>
/* Private generated adapter values. Host APIs keep resource tokens opaque. */
typedef struct lbov_29f2f1a69656aa8c8a56_t160ce821a84f6887bbfd lbov_29f2f1a69656aa8c8a56_t160ce821a84f6887bbfd;
typedef struct lbov_29f2f1a69656aa8c8a56_t648974cffb2d6c1d7951 lbov_29f2f1a69656aa8c8a56_t648974cffb2d6c1d7951;
typedef struct lbov_29f2f1a69656aa8c8a56_t5035e6ea0903f12776d9 lbov_29f2f1a69656aa8c8a56_t5035e6ea0903f12776d9;
typedef struct lbov_29f2f1a69656aa8c8a56_t23107461f72b24c37654 lbov_29f2f1a69656aa8c8a56_t23107461f72b24c37654;
typedef struct lbov_29f2f1a69656aa8c8a56_tb2825946e038e653bd2b lbov_29f2f1a69656aa8c8a56_tb2825946e038e653bd2b;
typedef struct lbov_29f2f1a69656aa8c8a56_td79b9bbde250ee1779da lbov_29f2f1a69656aa8c8a56_td79b9bbde250ee1779da;
typedef struct lbov_29f2f1a69656aa8c8a56_t2a091437b2d587ce3891 lbov_29f2f1a69656aa8c8a56_t2a091437b2d587ce3891;
typedef struct lbov_29f2f1a69656aa8c8a56_t167081552b6f9c1d1afd lbov_29f2f1a69656aa8c8a56_t167081552b6f9c1d1afd;
typedef struct lbov_29f2f1a69656aa8c8a56_tdc0347e1f7f5c4d928f1 lbov_29f2f1a69656aa8c8a56_tdc0347e1f7f5c4d928f1;
struct lbov_29f2f1a69656aa8c8a56_t648974cffb2d6c1d7951 {
  uint64_t token;
};
struct lbov_29f2f1a69656aa8c8a56_t5035e6ea0903f12776d9 {
  uint64_t token;
};
struct lbov_29f2f1a69656aa8c8a56_td79b9bbde250ee1779da {
  uint64_t token;
};
struct lbov_29f2f1a69656aa8c8a56_t167081552b6f9c1d1afd {
  const uint32_t *data;
  size_t length;
};
struct lbov_29f2f1a69656aa8c8a56_tdc0347e1f7f5c4d928f1 {
  const char *data;
  size_t length;
};
struct lbov_29f2f1a69656aa8c8a56_t160ce821a84f6887bbfd {
  uint8_t tag;
  const lbov_29f2f1a69656aa8c8a56_tb2825946e038e653bd2b *f0;
};
struct lbov_29f2f1a69656aa8c8a56_t23107461f72b24c37654 {
  lbov_29f2f1a69656aa8c8a56_td79b9bbde250ee1779da f0;
  const lbov_29f2f1a69656aa8c8a56_t2a091437b2d587ce3891 *f1;
};
struct lbov_29f2f1a69656aa8c8a56_tb2825946e038e653bd2b {
  lbov_29f2f1a69656aa8c8a56_td79b9bbde250ee1779da f0;
  lbov_29f2f1a69656aa8c8a56_t167081552b6f9c1d1afd f1;
};
struct lbov_29f2f1a69656aa8c8a56_t2a091437b2d587ce3891 {
  lbov_29f2f1a69656aa8c8a56_t167081552b6f9c1d1afd f0;
  lbov_29f2f1a69656aa8c8a56_t167081552b6f9c1d1afd f1;
};
