<?php
declare(strict_types=1);
namespace LeanOwnedCheckedRecords\Internal;

final class GraphTypes
{
    public const NODES = [['kind' => 'option', 'element' => null, 'fields' => [[0, 1]], 'classes' => ['LeanOwnedCheckedRecords\\Some']], ['kind' => 'record', 'element' => null, 'fields' => [['holder', 2], ['quota', 3]], 'classes' => ['LeanOwnedCheckedRecords\\Claim']], ['kind' => 'resource', 'element' => null, 'fields' => [], 'classes' => ['LeanOwnedCheckedRecords\\Ticket']], ['kind' => 'primitive', 'name' => 'nat', 'host' => 'bigint', 'min' => '0', 'max' => null], ['kind' => 'primitive', 'name' => 'string']];
    public const CLASSES = ['LeanOwnedCheckedRecords\\Claim' => ['fields' => [['holder', 2], ['quota', 3]]], 'LeanOwnedCheckedRecords\\Some' => ['fields' => [['value', null]]], 'LeanOwnedCheckedRecords\\Ok' => ['fields' => [['value', null]]], 'LeanOwnedCheckedRecords\\Err' => ['fields' => [['value', null]]]];
    public const IDENTITIES = ['LeanOwnedCheckedRecords\\Ticket' => 2];
}
