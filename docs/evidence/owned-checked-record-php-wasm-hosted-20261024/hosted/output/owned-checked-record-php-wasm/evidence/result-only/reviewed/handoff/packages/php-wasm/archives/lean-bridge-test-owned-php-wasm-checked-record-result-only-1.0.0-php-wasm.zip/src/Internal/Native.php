<?php
declare(strict_types=1);
namespace LeanBridge\CopiedPhpWasmV1 {
if (!class_exists(Loader::class, false)) {
    final class Loader {
        private static ?string $failure = null;
        private static bool $loading = false;
        private static int $callbacks = 0;
        public static function enterCallback(): void { ++self::$callbacks; }
        public static function leaveCallback(): void { --self::$callbacks; }
        public static function load(string $library, string $function): void {
            if (self::$failure !== null) throw new \RuntimeException(self::$failure);
            if (self::$loading) throw new \RuntimeException('Reentrant PHP-Wasm extension loading is not supported');
            // dl may suspend the host to fetch or instantiate a side module.
            // The synchronous Lean stack cannot participate in that unwind.
            if (self::$callbacks !== 0) throw new \RuntimeException('Cannot load a PHP-Wasm extension inside a synchronous Lean callback. Use its startup descriptor or call that package before entering the callback.');
            $registration = '/__lean_bridge/php_wasm_lazy/' . $library . '.txt';
            if (!is_file($registration) || file_get_contents($registration) !== $library) {
                throw new \RuntimeException('Register this package lazy descriptor in dynamicLibs before PHP starts');
            }
            if (!function_exists('dl') || !ini_get('enable_dl')) {
                throw new \RuntimeException('PHP-Wasm lazy loading requires enable_dl=1');
            }
            self::$loading = true;
            try {
                set_error_handler(static function (int $severity, string $message): never {
                    throw new \RuntimeException($message);
                });
                try {
                    if (!dl($library) || !function_exists($function)) {
                        throw new \RuntimeException('The generated Zend transport did not load');
                    }
                } finally { restore_error_handler(); }
            } catch (\Throwable $error) {
                // Emscripten may retain a partially linked DSO after failure.
                // Do not attempt another lazy load in that PHP instance.
                self::$failure = 'PHP-Wasm extension loading failed; create a new PHP instance. ' . $error->getMessage();
                throw new \RuntimeException(self::$failure, 0, $error);
            } finally { self::$loading = false; }
        }
    }
}
}

namespace LeanOwnedCheckedRecords\Internal {
require_once __DIR__ . '/Wire.php';

final class ZendBinding implements ResourceBinding
{
    public function __construct(private int $type, private mixed $resource) { $this->check(); }
    public function check(): void {
        if (!isset($this->type) || !is_resource($this->resource)) throw new \TypeError('Expected an initialized Zend identity');
        Native::identity('check', $this->type, $this->resource);
    }
    public function close(): void { Native::identity('close', $this->type, $this->resource); }
    public function retain(): ResourceBinding {
        $this->check(); return new self($this->type, Native::identity('retain', $this->type, $this->resource));
    }
    public function wire(int $type): mixed {
        if ($type !== $this->type) throw new \TypeError('Wrong nominal Zend identity');
        $this->check(); return $this->resource;
    }
    public function invoke(array $arguments): mixed {
        $this->check();
        return Native::invoke($this->type, ResourceAccess::wrap(GraphTypes::NODES[$this->type]['classes'][0], $this), $arguments);
    }
    // The Zend resource destructor handles implicit release, including in a
    // Fiber. A PHP destructor must not turn that into an explicit native call.
    private function __clone() {}
    public function __serialize(): array { throw new \LogicException('Zend identities cannot be serialized'); }
    public function __unserialize(array $data): void { throw new \LogicException('Zend identities cannot be deserialized'); }
}

final class ZendFrame
{
    public bool $active = true;
    public ?\Throwable $failure = null;
    public readonly GraphBudget $validation;
    public readonly GraphBudget $writing;
    public readonly GraphBudget $reading;
    private static ?\Closure $validate = null;
    public function __construct() {
        $this->validation = new GraphBudget(); $this->writing = new GraphBudget(); $this->reading = new GraphBudget();
    }
    public function check(int $type, mixed $value): void {
        self::$validate ??= \Closure::bind(static function($type, $value, $budget): void {
            foreach (Values::walk($value, $type, $budget) as $_) {}
        }, null, Values::class);
        (self::$validate)($type, $value, $this->validation);
    }
}

final class Native
{
    private const TRANSPORT = 'LeanOwnedCheckedRecords\\Internal\\OwnedZenda1bc3cc8d737ba9e0e9a';
    private const LIBRARY = 'php8.4-lb_owned_a1bc3cc8d737ba9e0e9a.so';
    private const FUNCTIONS = [['entry' => 'call0', 'parameters' => [2], 'host' => [false], 'result' => 0], ['entry' => 'call1', 'parameters' => [3, 4], 'host' => [false, false], 'result' => 2], ['entry' => 'call2', 'parameters' => [2], 'host' => [false], 'result' => 3]];
    private const CALLBACKS = [];
    private static int $depth = 0;
    private static function main(): void {
        if (\Fiber::getCurrent() !== null) throw new \LeanOwnedCheckedRecords\LeanBridgeError('Lean calls require the main PHP execution context', 5);
    }
    private static function symbol(string $entry): string {
        $symbol = self::TRANSPORT . '\\' . $entry;
        if (!function_exists($symbol)) {
            try { \LeanBridge\CopiedPhpWasmV1\Loader::load(self::LIBRARY, $symbol); }
            catch (\Throwable $error) { throw new \LeanOwnedCheckedRecords\LeanBridgeError($error->getMessage(), 7, $error); }
        }
        return $symbol;
    }
    public static function identity(string $entry, int $type, mixed $resource): mixed {
        self::main();
        if (!in_array($entry, ['check', 'close', 'retain'], true)) throw new \TypeError('Unknown identity operation');
        $symbol = self::symbol($entry);
        try { return $symbol($type, $resource); }
        catch (\Exception $error) { throw new \LeanOwnedCheckedRecords\LeanBridgeError($error->getMessage(), $error->getCode(), $error); }
    }
    private static function malformed(GraphInvalidWire $error): never {
        $retire = self::symbol('retire'); $retire();
        throw new \LeanOwnedCheckedRecords\LeanBridgeError($error->getMessage(), 9, $error);
    }
    private static function decode(int $type, mixed $value, ZendFrame $frame): mixed {
        try { return GraphWire::transfer($type, $value, true, $frame->reading); }
        catch (GraphInvalidWire $error) { self::malformed($error); }
    }
    private static function execute(array $fn, array $arguments): mixed {
        self::main();
        if (!array_is_list($arguments) || count($arguments) !== count($fn['parameters'])) throw new \ArgumentCountError('Wrong Lean call arity');
        if (self::$depth >= 64) throw new \OverflowException('Lean calls exceed 64 reentry levels');
        $frame = new ZendFrame(); $prepared = [];
        // Validate every ordinary argument and recovery value before loading
        // the extension or allocating any native identity.
        foreach ($fn['parameters'] as $index => $type) {
            if ($fn['host'][$index]) $prepared[$index] = self::prepare($type, $arguments[$index], $frame);
            else $frame->check($type, $arguments[$index]);
        }
        ++self::$depth;
        try {
            $inputs = [];
            foreach ($fn['parameters'] as $index => $type)
                $inputs[] = $fn['host'][$index] ? self::host($type, $prepared[$index], $frame)
                    : GraphWire::transfer($type, $arguments[$index], false, $frame->writing);
            $symbol = self::symbol($fn['entry']);
            try { $wire = $symbol(...$inputs); }
            catch (\Throwable $error) {
                if ($frame->failure !== null) throw $frame->failure;
                if ($error instanceof \Exception) throw new \LeanOwnedCheckedRecords\LeanBridgeError($error->getMessage(), $error->getCode(), $error);
                throw $error;
            }
            if ($frame->failure !== null) throw $frame->failure;
            return self::decode($fn['result'], $wire, $frame);
        } finally { $frame->active = false; --self::$depth; }
    }
    public static function call(int $index, array $arguments): mixed {
        return self::execute(self::FUNCTIONS[$index] ?? throw new \TypeError('Unknown Lean export'), $arguments);
    }
    public static function invoke(int $type, Resource $closure, array $arguments): mixed {
        if (!array_is_list($arguments)) throw new \ArgumentCountError('Lean closure requires positional arguments');
        return self::execute(self::CALLBACKS[$type] ?? throw new \TypeError('Resource is not a Lean closure'), [$closure, ...$arguments]);
    }
    public static function close(): void {
        self::main();
        if (self::$depth !== 0) throw new \LogicException('Cannot close the runtime during a Lean call');
        $close = self::symbol('shutdown'); $close();
    }
}

}
