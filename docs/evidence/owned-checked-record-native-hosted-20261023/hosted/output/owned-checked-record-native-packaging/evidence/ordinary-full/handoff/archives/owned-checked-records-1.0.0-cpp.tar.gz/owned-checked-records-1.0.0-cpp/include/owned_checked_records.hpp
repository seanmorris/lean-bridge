#pragma once
#include "owned_checked_records-conversions.hpp"
#include <concepts>
#include <exception>
#include <functional>
#include <unordered_map>
namespace lean_bridge::owned_checked_records {
namespace detail {
struct OwnedCall {
  std::shared_ptr<State> state; OwnedBudget budget; std::exception_ptr error;
  explicit OwnedCall(std::shared_ptr<State> value) : state(std::move(value)) {}
  ~OwnedCall() { state->drain(); }
};
template<class F, class R> struct RecoveredCallback { F function; R recovery; };
template<class F> constexpr bool owned_has_recovery = false;
template<class F, class R> constexpr bool owned_has_recovery<RecoveredCallback<F, R>> = true;
template<class F, class Expected> constexpr bool owned_recovery_matches = true;
template<class F, class R, class Expected> constexpr bool owned_recovery_matches<RecoveredCallback<F, R>, Expected> = std::same_as<R, Expected>;
template<class F> inline F& owned_function(F& function) { return function; }
template<class F, class R> inline F& owned_function(RecoveredCallback<F, R>& function) { return function.function; }
template<class F, class R> inline const F& owned_function(const RecoveredCallback<F, R>& function) { return function.function; }
struct OwnedInputTransfers {
  struct Entry { std::shared_ptr<Lease> lease; size_t group; };
  std::shared_ptr<State> state;
  OwnedBudget budget;
  std::vector<std::shared_ptr<InputMoveSignal>> groups;
  std::unordered_map<Lease *, Entry> leases;
  bool finished = false;
  OwnedInputTransfers(std::shared_ptr<State> input, size_t count) : state(std::move(input)) {
    budget.storage(count, sizeof(InputMoveSignal) + sizeof(std::shared_ptr<InputMoveSignal>));
    groups.reserve(count);
    for (size_t i = 0; i < count; ++i) groups.push_back(std::make_shared<InputMoveSignal>());
  }
  OwnedInputTransfers(const OwnedInputTransfers&) = delete;
  OwnedInputTransfers& operator=(const OwnedInputTransfers&) = delete;
  ~OwnedInputTransfers() { finish(); }
  void add(std::shared_ptr<Lease> lease, size_t group) {
    lease->require_transfer();
    if (lease->state() != state || group >= groups.size()) throw Error(OWNED_CHECKED_RECORDS_INVALID_ARGUMENT);
    const auto prior = leases.find(lease.get());
    if (prior != leases.end()) {
      if (prior->second.group != group) throw Error(OWNED_CHECKED_RECORDS_INVALID_ARGUMENT);
      return;
    }
    budget.storage(1, sizeof(Entry) + 4 * sizeof(void *));
    auto *identity = lease.get(); leases.emplace(identity, Entry{std::move(lease), group});
  }
  owned_checked_records_result **owner(size_t index) { return groups.at(index)->slot(); }
  void arm() {
    for (const auto& group : groups)
      if (!group->owner.value) throw Error(OWNED_CHECKED_RECORDS_INVALID_ARGUMENT);
    for (const auto& [identity, entry] : leases) { (void)identity; entry.lease->require_transfer(); }
    for (const auto& [identity, entry] : leases) { (void)identity; entry.lease->begin_transfer(groups[entry.group]); }
    for (const auto& group : groups) group->armed = true;
  }
  void finish() noexcept {
    if (finished) return;
    finished = true;
    for (const auto& group : groups) group->completed.store(group->consumed());
    for (const auto& [identity, entry] : leases) {
      (void)identity; entry.lease->finish_transfer(groups[entry.group]);
    }
  }
};
inline void owned_move_leases0(const Value160ce821a84f6887bbfd& source, size_t depth, OwnedInputTransfers& moves, size_t group);
inline void owned_move_leases1(const Callback26621c40b48fce52ca37& source, size_t depth, OwnedInputTransfers& moves, size_t group);
inline void owned_move_leases2(const Callbackb2d3d6fd4e031785f278& source, size_t depth, OwnedInputTransfers& moves, size_t group);
inline void owned_move_leases3(const Booking& source, size_t depth, OwnedInputTransfers& moves, size_t group);
inline void owned_move_leases4(const Claim& source, size_t depth, OwnedInputTransfers& moves, size_t group);
inline void owned_move_leases5(const Ticket& source, size_t depth, OwnedInputTransfers& moves, size_t group);
inline void owned_move_leases6(const Window& source, size_t depth, OwnedInputTransfers& moves, size_t group);
inline void owned_move_leases7(const Nat& source, size_t depth, OwnedInputTransfers& moves, size_t group);
inline void owned_move_leases8(const std::string& source, size_t depth, OwnedInputTransfers& moves, size_t group);
inline void owned_move_leases0(const Value160ce821a84f6887bbfd& source, size_t depth, OwnedInputTransfers& moves, size_t group) {
  (void)source; (void)depth; (void)moves; (void)group;
  moves.budget.enter(depth);
  if (source) {
  owned_move_leases4(*source, depth + 1, moves, group);
  }
}
inline void owned_move_leases1(const Callback26621c40b48fce52ca37& source, size_t depth, OwnedInputTransfers& moves, size_t group) {
  (void)source; (void)depth; (void)moves; (void)group;
  moves.budget.enter(depth);
  moves.add(ResourceAccess::lease(source, moves.state), group);
}
inline void owned_move_leases2(const Callbackb2d3d6fd4e031785f278& source, size_t depth, OwnedInputTransfers& moves, size_t group) {
  (void)source; (void)depth; (void)moves; (void)group;
  moves.budget.enter(depth);
  moves.add(ResourceAccess::lease(source, moves.state), group);
}
inline void owned_move_leases3(const Booking& source, size_t depth, OwnedInputTransfers& moves, size_t group) {
  (void)source; (void)depth; (void)moves; (void)group;
  moves.budget.enter(depth);
  owned_move_leases5(source.holder, depth + 1, moves, group);
}
inline void owned_move_leases4(const Claim& source, size_t depth, OwnedInputTransfers& moves, size_t group) {
  (void)source; (void)depth; (void)moves; (void)group;
  moves.budget.enter(depth);
  owned_move_leases5(source.holder, depth + 1, moves, group);
}
inline void owned_move_leases5(const Ticket& source, size_t depth, OwnedInputTransfers& moves, size_t group) {
  (void)source; (void)depth; (void)moves; (void)group;
  moves.budget.enter(depth);
  moves.add(ResourceAccess::lease(source, moves.state), group);
}
inline void owned_move_leases6(const Window& source, size_t depth, OwnedInputTransfers& moves, size_t group) {
  (void)source; (void)depth; (void)moves; (void)group;
}
inline void owned_move_leases7(const Nat& source, size_t depth, OwnedInputTransfers& moves, size_t group) {
  (void)source; (void)depth; (void)moves; (void)group;
}
inline void owned_move_leases8(const std::string& source, size_t depth, OwnedInputTransfers& moves, size_t group) {
  (void)source; (void)depth; (void)moves; (void)group;
}
template<class F> concept OwnedCallback1 = std::same_as<std::remove_cvref_t<F>, Callback26621c40b48fce52ca37> || (
  true
  && owned_recovery_matches<std::remove_cvref_t<F>, Claim>
  && requires(F& function, const Claim& a0) {
    { std::invoke(owned_function(function), a0) } -> std::same_as<Claim>;
  });
template<class F> requires OwnedCallback1<F> struct OwnedCallbackView1 {
  F& function; OwnedCall& call;
  std::unique_ptr<OwnedView4> recovery;
  owned_checked_records_claim_closure_result_t_host value{};
  static owned_checked_records_status invoke(void *context, owned_checked_records_session *session, owned_checked_records_claim_t const * a0, owned_checked_records_claim_t *out, owned_checked_records_result **owner) noexcept {
    auto& self = *static_cast<OwnedCallbackView1 *>(context);
    if (self.call.error) return OWNED_CHECKED_RECORDS_CALLBACK_FAILED;
    try {
      if (self.call.state->require() != session || !out || !owner || *owner) throw Error(OWNED_CHECKED_RECORDS_INVALID_ARGUMENT);
      BorrowFrame frame(self.call.state); OwnedOutput borrowed(self.call.state, frame.lease);
      auto argument0 = owned_from4(owned_read(a0), 0, self.call.budget, borrowed);
      auto reply = std::invoke(owned_function(self.function), std::as_const(argument0));
      owned_check4(reply, 0, self.call.budget, self.call.state);
      OwnedView4 view(reply, self.call.state);
      owned_checked_records_claim_t converted{}; NativeOwner retained;
      checked(owned_checked_records_claim_t_copy(self.call.state->require(), &view.value, &converted, &retained.value));
      *out = converted; *owner = std::exchange(retained.value, nullptr);
      return OWNED_CHECKED_RECORDS_OK;
    } catch (...) {
      if (!self.call.error) self.call.error = std::current_exception();
      return OWNED_CHECKED_RECORDS_CALLBACK_FAILED;
    }
  }
  OwnedCallbackView1(F& input, OwnedCall& scope) : function(input), call(scope) {
    if constexpr (std::same_as<std::remove_cvref_t<F>, Callback26621c40b48fce52ca37>) {
      value.closure = ResourceAccess::get<owned_checked_records_claim_closure_result_t>(input, scope.state);
    } else {
      value.call = &invoke; value.context = this;
      if constexpr (owned_has_recovery<std::remove_cvref_t<F>>) {
        recovery = std::make_unique<OwnedView4>(input.recovery, scope.state);
        value.recovery = &recovery->value;
      }
    }
  }
  OwnedCallbackView1(const OwnedCallbackView1&) = delete;
  OwnedCallbackView1& operator=(const OwnedCallbackView1&) = delete;
};
template<class F> requires OwnedCallback1<F> inline void owned_check_callback1(F& input, OwnedCall& call) {
  if constexpr (std::same_as<std::remove_cvref_t<F>, Callback26621c40b48fce52ca37>) owned_check1(input, 0, call.budget, call.state);
  else {
    call.budget.enter(0); call.budget.native(1, sizeof(owned_checked_records_claim_closure_result_t_host));
    call.budget.storage(1, sizeof(OwnedCallbackView1<F>));
    if constexpr (owned_has_recovery<std::remove_cvref_t<F>>)
      owned_check4(input.recovery, 0, call.budget, call.state);
  }
}
template<class F> concept OwnedCallback2 = std::same_as<std::remove_cvref_t<F>, Callbackb2d3d6fd4e031785f278> || (
  true
  && owned_recovery_matches<std::remove_cvref_t<F>, Claim>
  && requires(F& function, const Claim& a0) {
    { std::invoke(owned_function(function), a0) } -> std::same_as<Claim>;
  });
template<class F> requires OwnedCallback2<F> struct OwnedCallbackView2 {
  F& function; OwnedCall& call;
  std::unique_ptr<OwnedView4> recovery;
  owned_checked_records_with_claim_callback_argument1_t_host value{};
  static owned_checked_records_status invoke(void *context, owned_checked_records_session *session, owned_checked_records_claim_t const * a0, owned_checked_records_claim_t *out, owned_checked_records_result **owner) noexcept {
    auto& self = *static_cast<OwnedCallbackView2 *>(context);
    if (self.call.error) return OWNED_CHECKED_RECORDS_CALLBACK_FAILED;
    try {
      if (self.call.state->require() != session || !out || !owner || *owner) throw Error(OWNED_CHECKED_RECORDS_INVALID_ARGUMENT);
      BorrowFrame frame(self.call.state); OwnedOutput borrowed(self.call.state, frame.lease);
      auto argument0 = owned_from4(owned_read(a0), 0, self.call.budget, borrowed);
      auto reply = std::invoke(owned_function(self.function), std::as_const(argument0));
      owned_check4(reply, 0, self.call.budget, self.call.state);
      OwnedView4 view(reply, self.call.state);
      owned_checked_records_claim_t converted{}; NativeOwner retained;
      checked(owned_checked_records_claim_t_copy(self.call.state->require(), &view.value, &converted, &retained.value));
      *out = converted; *owner = std::exchange(retained.value, nullptr);
      return OWNED_CHECKED_RECORDS_OK;
    } catch (...) {
      if (!self.call.error) self.call.error = std::current_exception();
      return OWNED_CHECKED_RECORDS_CALLBACK_FAILED;
    }
  }
  OwnedCallbackView2(F& input, OwnedCall& scope) : function(input), call(scope) {
    if constexpr (std::same_as<std::remove_cvref_t<F>, Callbackb2d3d6fd4e031785f278>) {
      value.closure = ResourceAccess::get<owned_checked_records_with_claim_callback_argument1_t>(input, scope.state);
    } else {
      value.call = &invoke; value.context = this;
      if constexpr (owned_has_recovery<std::remove_cvref_t<F>>) {
        recovery = std::make_unique<OwnedView4>(input.recovery, scope.state);
        value.recovery = &recovery->value;
      }
    }
  }
  OwnedCallbackView2(const OwnedCallbackView2&) = delete;
  OwnedCallbackView2& operator=(const OwnedCallbackView2&) = delete;
};
template<class F> requires OwnedCallback2<F> inline void owned_check_callback2(F& input, OwnedCall& call) {
  if constexpr (std::same_as<std::remove_cvref_t<F>, Callbackb2d3d6fd4e031785f278>) owned_check2(input, 0, call.budget, call.state);
  else {
    call.budget.enter(0); call.budget.native(1, sizeof(owned_checked_records_with_claim_callback_argument1_t_host));
    call.budget.storage(1, sizeof(OwnedCallbackView2<F>));
    if constexpr (owned_has_recovery<std::remove_cvref_t<F>>)
      owned_check4(input.recovery, 0, call.budget, call.state);
  }
}
inline Callback26621c40b48fce52ca37 owned_invoke0() {
  OwnedCall call(current_state());
  owned_checked_records_claim_closure_result_t returned{}; OwnedOutput output(call.state);
  const auto status = owned_checked_records_claim_closure(call.state->require(), &returned, &output.owner.value);
  if (call.error) std::rethrow_exception(call.error);
  checked(status);
  return owned_from1(returned, 0, call.budget, output);
}
inline Value160ce821a84f6887bbfd owned_invoke1(const Ticket& a0) {
  OwnedCall call(current_state());
  owned_check5(a0, 0, call.budget, call.state);
  OwnedView5 view0(a0, call.state);
  owned_checked_records_value_160ce821a84f6887bbfd_t returned{}; OwnedOutput output(call.state);
  const auto status = owned_checked_records_claim_for(call.state->require(), view0.value, &returned, &output.owner.value);
  if (call.error) std::rethrow_exception(call.error);
  checked(status);
  return owned_from0(returned, 0, call.budget, output);
}
inline Booking owned_invoke2(const Booking& a0) {
  OwnedCall call(current_state());
  owned_check3(a0, 0, call.budget, call.state);
  OwnedView3 view0(a0, call.state);
  owned_checked_records_booking_t returned{}; OwnedOutput output(call.state);
  const auto status = owned_checked_records_echo_booking(call.state->require(), &view0.value, &returned, &output.owner.value);
  if (call.error) std::rethrow_exception(call.error);
  checked(status);
  return owned_from3(returned, 0, call.budget, output);
}
inline Claim owned_invoke3(const Claim& a0) {
  OwnedCall call(current_state());
  owned_check4(a0, 0, call.budget, call.state);
  OwnedView4 view0(a0, call.state);
  owned_checked_records_claim_t returned{}; OwnedOutput output(call.state);
  const auto status = owned_checked_records_echo_claim(call.state->require(), &view0.value, &returned, &output.owner.value);
  if (call.error) std::rethrow_exception(call.error);
  checked(status);
  return owned_from4(returned, 0, call.budget, output);
}
inline Ticket owned_invoke4(const Nat& a0, const std::string& a1) {
  OwnedCall call(current_state());
  owned_check7(a0, 0, call.budget, call.state);
  owned_check8(a1, 0, call.budget, call.state);
  OwnedView7 view0(a0, call.state);
  OwnedView8 view1(a1, call.state);
  owned_checked_records_ticket_t returned{}; OwnedOutput output(call.state);
  const auto status = owned_checked_records_new_ticket(call.state->require(), view0.value, view1.value, &returned, &output.owner.value);
  if (call.error) std::rethrow_exception(call.error);
  checked(status);
  return owned_from5(returned, 0, call.budget, output);
}
inline Claim owned_invoke5(const Booking& a0, const Claim& a1) {
  OwnedCall call(current_state());
  owned_check3(a0, 0, call.budget, call.state);
  owned_check4(a1, 0, call.budget, call.state);
  OwnedView3 view0(a0, call.state);
  OwnedView4 view1(a1, call.state);
  owned_checked_records_claim_t returned{}; OwnedOutput output(call.state);
  const auto status = owned_checked_records_pair_claim(call.state->require(), &view0.value, &view1.value, &returned, &output.owner.value);
  if (call.error) std::rethrow_exception(call.error);
  checked(status);
  return owned_from4(returned, 0, call.budget, output);
}
inline Nat owned_invoke6(const Ticket& a0) {
  OwnedCall call(current_state());
  owned_check5(a0, 0, call.budget, call.state);
  OwnedView5 view0(a0, call.state);
  mpz_srcptr returned{}; OwnedOutput output(call.state);
  const auto status = owned_checked_records_serial(call.state->require(), view0.value, &returned, &output.owner.value);
  if (call.error) std::rethrow_exception(call.error);
  checked(status);
  return owned_from7(returned, 0, call.budget, output);
}
inline Claim owned_invoke7(Claim&& a0) {
  OwnedCall call(current_state());
  owned_check4(a0, 0, call.budget, call.state);
  OwnedView4 view0(a0, call.state);
  owned_checked_records_claim_t returned{}; OwnedOutput output(call.state);
  OwnedInputTransfers moves(call.state, 1);
  owned_move_leases4(a0, 0, moves, 0);
  owned_checked_records_claim_t moved0{};
  checked(owned_checked_records_claim_t_copy(call.state->require(), &view0.value, &moved0, moves.owner(0)));
  auto *session = call.state->require();
  moves.arm();
  const auto status = owned_checked_records_transfer_claim(session, &moved0, moves.owner(0), &returned, &output.owner.value);
  moves.finish();
  if (call.error) std::rethrow_exception(call.error);
  checked(status);
  return owned_from4(returned, 0, call.budget, output);
}
template<class F1>
requires (OwnedCallback2<F1>)
inline Claim owned_invoke8(const Claim& a0, F1&& a1) {
  OwnedCall call(current_state());
  owned_check4(a0, 0, call.budget, call.state);
  owned_check_callback2(a1, call);
  OwnedView4 view0(a0, call.state);
  OwnedCallbackView2<std::remove_reference_t<F1>> view1(a1, call);
  owned_checked_records_claim_t returned{}; OwnedOutput output(call.state);
  const auto status = owned_checked_records_with_claim_callback(call.state->require(), &view0.value, &view1.value, &returned, &output.owner.value);
  if (call.error) std::rethrow_exception(call.error);
  checked(status);
  return owned_from4(returned, 0, call.budget, output);
}
inline Claim owned_invoke9(const Callback26621c40b48fce52ca37& a0, const Claim& a1) {
  OwnedCall call(current_state());
  owned_check1(a0, 0, call.budget, call.state);
  owned_check4(a1, 0, call.budget, call.state);
  OwnedView1 view0(a0, call.state);
  OwnedView4 view1(a1, call.state);
  owned_checked_records_claim_t returned{}; OwnedOutput output(call.state);
  const auto status = owned_checked_records_claim_closure_result_t_call(call.state->require(), view0.value, &view1.value, &returned, &output.owner.value);
  if (call.error) std::rethrow_exception(call.error);
  checked(status);
  return owned_from4(returned, 0, call.budget, output);
}
inline Claim owned_invoke10(const Callbackb2d3d6fd4e031785f278& a0, const Claim& a1) {
  OwnedCall call(current_state());
  owned_check2(a0, 0, call.budget, call.state);
  owned_check4(a1, 0, call.budget, call.state);
  OwnedView2 view0(a0, call.state);
  OwnedView4 view1(a1, call.state);
  owned_checked_records_claim_t returned{}; OwnedOutput output(call.state);
  const auto status = owned_checked_records_with_claim_callback_argument1_t_call(call.state->require(), view0.value, &view1.value, &returned, &output.owner.value);
  if (call.error) std::rethrow_exception(call.error);
  checked(status);
  return owned_from4(returned, 0, call.budget, output);
}
inline Callback26621c40b48fce52ca37 owned_invoke11(const Callback26621c40b48fce52ca37& a0) {
  OwnedCall call(current_state());
  owned_check1(a0, 0, call.budget, call.state);
  OwnedView1 view0(a0, call.state);
  owned_checked_records_claim_closure_result_t returned{}; OwnedOutput output(call.state);
  const auto status = owned_checked_records_claim_closure_result_t_retain(call.state->require(), view0.value, &returned, &output.owner.value);
  if (call.error) std::rethrow_exception(call.error);
  checked(status);
  return owned_from1(returned, 0, call.budget, output);
}
inline Callbackb2d3d6fd4e031785f278 owned_invoke12(const Callbackb2d3d6fd4e031785f278& a0) {
  OwnedCall call(current_state());
  owned_check2(a0, 0, call.budget, call.state);
  OwnedView2 view0(a0, call.state);
  owned_checked_records_with_claim_callback_argument1_t returned{}; OwnedOutput output(call.state);
  const auto status = owned_checked_records_with_claim_callback_argument1_t_retain(call.state->require(), view0.value, &returned, &output.owner.value);
  if (call.error) std::rethrow_exception(call.error);
  checked(status);
  return owned_from2(returned, 0, call.budget, output);
}
inline Ticket owned_invoke13(const Ticket& a0) {
  OwnedCall call(current_state());
  owned_check5(a0, 0, call.budget, call.state);
  OwnedView5 view0(a0, call.state);
  owned_checked_records_ticket_t returned{}; OwnedOutput output(call.state);
  const auto status = owned_checked_records_ticket_t_retain(call.state->require(), view0.value, &returned, &output.owner.value);
  if (call.error) std::rethrow_exception(call.error);
  checked(status);
  return owned_from5(returned, 0, call.budget, output);
}
template<> struct ResourceOps<Identity648974cffb2d6c1d7951> {
  static Callback26621c40b48fce52ca37 retain(const Callback26621c40b48fce52ca37& self) { return owned_invoke11(self); }
  static Claim call(const Callback26621c40b48fce52ca37& self, const Claim& a1) {
    return owned_invoke9(self, a1);
  }
};
template<> struct ResourceOps<Identity5035e6ea0903f12776d9> {
  static Callbackb2d3d6fd4e031785f278 retain(const Callbackb2d3d6fd4e031785f278& self) { return owned_invoke12(self); }
  static Claim call(const Callbackb2d3d6fd4e031785f278& self, const Claim& a1) {
    return owned_invoke10(self, a1);
  }
};
template<> struct ResourceOps<Identityd79b9bbde250ee1779da> {
  static Ticket retain(const Ticket& self) { return owned_invoke13(self); }
};
}
// Recovery supplies a typed failure-path value for Lean cleanup, never a successful host result.
template<class F, class R> inline auto with_recovery(F&& function, R&& recovery) {
  return detail::RecoveredCallback<std::decay_t<F>, std::decay_t<R>>{std::forward<F>(function), std::forward<R>(recovery)};
}
inline Callback26621c40b48fce52ca37 claim_closure() {
  return detail::owned_invoke0();
}
inline Value160ce821a84f6887bbfd claim_for(const Ticket& a0) {
  return detail::owned_invoke1(a0);
}
inline Booking echo_booking(const Booking& a0) {
  return detail::owned_invoke2(a0);
}
inline Claim echo_claim(const Claim& a0) {
  return detail::owned_invoke3(a0);
}
inline Ticket new_ticket(const Nat& a0, const std::string& a1) {
  return detail::owned_invoke4(a0, a1);
}
inline Claim pair_claim(const Booking& a0, const Claim& a1) {
  return detail::owned_invoke5(a0, a1);
}
inline Nat serial(const Ticket& a0) {
  return detail::owned_invoke6(a0);
}
inline Claim transfer_claim(Claim&& a0) {
  return detail::owned_invoke7(std::move(a0));
}
template<class F1>
requires (detail::OwnedCallback2<F1>)
inline Claim with_claim_callback(const Claim& a0, F1&& a1) {
  return detail::owned_invoke8(a0, std::forward<F1>(a1));
}
}
