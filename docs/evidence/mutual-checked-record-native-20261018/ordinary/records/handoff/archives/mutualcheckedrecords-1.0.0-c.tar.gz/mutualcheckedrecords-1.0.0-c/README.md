# mutualcheckedrecords 1.0.0

Compiled C11 API from mutualcheckedrecords@1.0.0. Linux x86-64, glibc 2.38 or newer. Lean is not required by consumers. The shared native runtime is included in lib/ and loads automatically.

Include mutualcheckedrecords.h. Use pkg-config package mutualcheckedrecords, or find_package(LeanBridgeMutualcheckedrecords CONFIG REQUIRED) and link LeanBridge::mutualcheckedrecords. C++ functions live in lean_bridge::mutualcheckedrecords.

Initialize Nat/Int with mpz_init and aggregate structs with mutualcheckedrecords_TYPE_init before first use. C inputs borrow caller buffers for one call. The recursive C value API includes GMP in every package; CMake and pkg-config link it automatically.

Strings are length-delimited UTF-8, including embedded NUL. Byte arrays are uninterpreted bytes. Nat and Int are GMP mpz_t values. Negative Nat inputs reject. GMP 6.3.0 headers and a replaceable shared library ship in the archive and link automatically through CMake or pkg-config. Its complete corresponding source, build settings and LGPL/GPL notices are under share/lean-bridge/. GMP allocation failures abort by default; the bridge does not replace GMP allocation hooks. Unit parameters are zero in C and std::monostate in C++; Unit results have no output. Fixed-width integers use exact-width host types; floating-point values retain IEEE special values. Input and output copies share a 16 MiB per-call budget. Invalid input leaves the output unchanged and returns a status (C) or throws Error (C++).

Recursive copied records and named variants use a finite type graph. Values must be finite and acyclic, with at most 128 levels and 262,144 visited nodes per call. All inputs and the result share a 16 MiB native-copy budget; host conversion storage has a separate 16 MiB budget. Limits include container slots and ownership bookkeeping, not the Lean algorithm's working memory. Invalid arguments and limit failures report INVALID_ARGUMENT. Bridge allocation failures report UNEXPECTED_ERROR; malformed native results retire the shared runtime and later calls reject. Already owned results can still be released.

C variants use named KIND constants and a union of named cases. Initialize a value with _init, select a constructor with _select, then assign that constructor's fields. _select returns STATUS_OK on success and preserves the value on invalid selections. A freshly initialized or cleared variant has no active constructor until selected. Do not assign kind directly. Caller inputs borrow pointer/span children for one call. Initialize every output before calling; success replaces the previous owned output and failure preserves it. An output root owns its nested data through private bookkeeping. Clear or select only the owning root, never a borrowed child view. Do not shallow-copy owned outputs or alter private ownership fields. An initialized caller-built parent may own an inline returned child; clearing that parent releases the child. Clear is idempotent. GMP integers in active fields are initialized already: assign with mpz_set, not mpz_init. Never overwrite them with a shallow struct copy. Finish standalone integers with mpz_clear.

- mutualcheckedrecords_echo: lean:MutualCheckedRecords.echo
- mutualcheckedrecords_echo_groups: lean:MutualCheckedRecords.echoGroups
- mutualcheckedrecords_first: lean:MutualCheckedRecords.first
- mutualcheckedrecords_groups: lean:MutualCheckedRecords.groups
- mutualcheckedrecords_produce: lean:MutualCheckedRecords.produce
- mutualcheckedrecords_second: lean:MutualCheckedRecords.second
