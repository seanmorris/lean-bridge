#ifndef MUTUALCHECKEDRECORDS_GMP_GRAPH_VALUES_H
#define MUTUALCHECKEDRECORDS_GMP_GRAPH_VALUES_H
#include <gmp.h>
#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>
#include <string.h>

/* Inputs borrow pointer/span children. Owning results must not be
   shallow-copied and cleared twice. The two _bridge fields are private.
   Clear/select the root of an owned result, never a borrowed child.
   Do not overwrite initialized GMP storage or inactive branch fields. */
typedef struct mutualcheckedrecords_gmp_graph_6586a61fcab9df3e21b7_t mutualcheckedrecords_gmp_graph_6586a61fcab9df3e21b7_t;
typedef struct mutualcheckedrecords_gmp_graph_c8c78faf2eecb4e21389_t mutualcheckedrecords_gmp_graph_c8c78faf2eecb4e21389_t;
typedef struct mutualcheckedrecords_gmp_graph_d2fe45ba488df4ece96d_t mutualcheckedrecords_gmp_graph_d2fe45ba488df4ece96d_t;
typedef struct mutualcheckedrecords_gmp_envelope_t mutualcheckedrecords_gmp_envelope_t;
typedef struct mutualcheckedrecords_gmp_step_t mutualcheckedrecords_gmp_step_t;
typedef mpz_t mutualcheckedrecords_gmp_scalar_nat_t;
struct mutualcheckedrecords_gmp_graph_6586a61fcab9df3e21b7_t {
  void *_bridge_owner;
  void (*_bridge_release)(void *owner, void *root);
  const mutualcheckedrecords_gmp_graph_c8c78faf2eecb4e21389_t *data;
  size_t length;
};
static inline void mutualcheckedrecords_gmp_graph_6586a61fcab9df3e21b7_t_init(mutualcheckedrecords_gmp_graph_6586a61fcab9df3e21b7_t *value) {
  if (!value) return;
  memset(value, 0, sizeof(*value));
}
static inline void mutualcheckedrecords_gmp_graph_6586a61fcab9df3e21b7_t_destroy_inline(mutualcheckedrecords_gmp_graph_6586a61fcab9df3e21b7_t *value) {
  (void)value;
}
static inline void mutualcheckedrecords_gmp_graph_6586a61fcab9df3e21b7_t_dispose(mutualcheckedrecords_gmp_graph_6586a61fcab9df3e21b7_t *value) {
  if (!value) return;
  if (value->_bridge_owner && value->_bridge_release) value->_bridge_release(value->_bridge_owner, value);
  else mutualcheckedrecords_gmp_graph_6586a61fcab9df3e21b7_t_destroy_inline(value);
}
static inline void mutualcheckedrecords_gmp_graph_6586a61fcab9df3e21b7_t_clear(mutualcheckedrecords_gmp_graph_6586a61fcab9df3e21b7_t *value) {
  if (!value) return;
  mutualcheckedrecords_gmp_graph_6586a61fcab9df3e21b7_t_dispose(value);
  mutualcheckedrecords_gmp_graph_6586a61fcab9df3e21b7_t_init(value);
}

static inline void mutualcheckedrecords_gmp_scalar_nat_t_init(mpz_ptr value) { if (value) mpz_init(value); }
static inline void mutualcheckedrecords_gmp_scalar_nat_t_clear(mpz_ptr value) { if (value) { mpz_clear(value); mpz_init(value); } }
struct mutualcheckedrecords_gmp_envelope_t {
  void *_bridge_owner;
  void (*_bridge_release)(void *owner, void *root);
  mutualcheckedrecords_gmp_scalar_nat_t value;
  mutualcheckedrecords_gmp_scalar_nat_t mode;
  const mutualcheckedrecords_gmp_graph_d2fe45ba488df4ece96d_t *next;
};
static inline void mutualcheckedrecords_gmp_envelope_t_init(mutualcheckedrecords_gmp_envelope_t *value) {
  if (!value) return;
  memset(value, 0, sizeof(*value));
  mutualcheckedrecords_gmp_scalar_nat_t_init(value->value);
  mutualcheckedrecords_gmp_scalar_nat_t_init(value->mode);
}
static inline void mutualcheckedrecords_gmp_envelope_t_destroy_inline(mutualcheckedrecords_gmp_envelope_t *value) {
  (void)value;
  mpz_clear(value->value);
  mpz_clear(value->mode);
}
static inline void mutualcheckedrecords_gmp_envelope_t_dispose(mutualcheckedrecords_gmp_envelope_t *value) {
  if (!value) return;
  if (value->_bridge_owner && value->_bridge_release) value->_bridge_release(value->_bridge_owner, value);
  else mutualcheckedrecords_gmp_envelope_t_destroy_inline(value);
}
static inline void mutualcheckedrecords_gmp_envelope_t_clear(mutualcheckedrecords_gmp_envelope_t *value) {
  if (!value) return;
  mutualcheckedrecords_gmp_envelope_t_dispose(value);
  mutualcheckedrecords_gmp_envelope_t_init(value);
}

struct mutualcheckedrecords_gmp_graph_c8c78faf2eecb4e21389_t {
  void *_bridge_owner;
  void (*_bridge_release)(void *owner, void *root);
  uint8_t has_value;
  mutualcheckedrecords_gmp_envelope_t value;
};
static inline void mutualcheckedrecords_gmp_graph_c8c78faf2eecb4e21389_t_init(mutualcheckedrecords_gmp_graph_c8c78faf2eecb4e21389_t *value) {
  if (!value) return;
  memset(value, 0, sizeof(*value));
  mutualcheckedrecords_gmp_envelope_t_init(&value->value);
}
static inline void mutualcheckedrecords_gmp_graph_c8c78faf2eecb4e21389_t_destroy_inline(mutualcheckedrecords_gmp_graph_c8c78faf2eecb4e21389_t *value) {
  (void)value;
  mutualcheckedrecords_gmp_envelope_t_dispose(&value->value);
}
static inline void mutualcheckedrecords_gmp_graph_c8c78faf2eecb4e21389_t_dispose(mutualcheckedrecords_gmp_graph_c8c78faf2eecb4e21389_t *value) {
  if (!value) return;
  if (value->_bridge_owner && value->_bridge_release) value->_bridge_release(value->_bridge_owner, value);
  else mutualcheckedrecords_gmp_graph_c8c78faf2eecb4e21389_t_destroy_inline(value);
}
static inline void mutualcheckedrecords_gmp_graph_c8c78faf2eecb4e21389_t_clear(mutualcheckedrecords_gmp_graph_c8c78faf2eecb4e21389_t *value) {
  if (!value) return;
  mutualcheckedrecords_gmp_graph_c8c78faf2eecb4e21389_t_dispose(value);
  mutualcheckedrecords_gmp_graph_c8c78faf2eecb4e21389_t_init(value);
}

struct mutualcheckedrecords_gmp_graph_d2fe45ba488df4ece96d_t {
  void *_bridge_owner;
  void (*_bridge_release)(void *owner, void *root);
  uint8_t has_value;
  const mutualcheckedrecords_gmp_step_t *value;
};
static inline void mutualcheckedrecords_gmp_graph_d2fe45ba488df4ece96d_t_init(mutualcheckedrecords_gmp_graph_d2fe45ba488df4ece96d_t *value) {
  if (!value) return;
  memset(value, 0, sizeof(*value));
}
static inline void mutualcheckedrecords_gmp_graph_d2fe45ba488df4ece96d_t_destroy_inline(mutualcheckedrecords_gmp_graph_d2fe45ba488df4ece96d_t *value) {
  (void)value;
}
static inline void mutualcheckedrecords_gmp_graph_d2fe45ba488df4ece96d_t_dispose(mutualcheckedrecords_gmp_graph_d2fe45ba488df4ece96d_t *value) {
  if (!value) return;
  if (value->_bridge_owner && value->_bridge_release) value->_bridge_release(value->_bridge_owner, value);
  else mutualcheckedrecords_gmp_graph_d2fe45ba488df4ece96d_t_destroy_inline(value);
}
static inline void mutualcheckedrecords_gmp_graph_d2fe45ba488df4ece96d_t_clear(mutualcheckedrecords_gmp_graph_d2fe45ba488df4ece96d_t *value) {
  if (!value) return;
  mutualcheckedrecords_gmp_graph_d2fe45ba488df4ece96d_t_dispose(value);
  mutualcheckedrecords_gmp_graph_d2fe45ba488df4ece96d_t_init(value);
}

typedef enum mutualcheckedrecords_gmp_step_t_tag { MUTUALCHECKEDRECORDS_GMP_STEP_T_KIND_STOP = 0, MUTUALCHECKEDRECORDS_GMP_STEP_T_KIND_MORE = 1 } mutualcheckedrecords_gmp_step_t_tag;
struct mutualcheckedrecords_gmp_step_t {
  void *_bridge_owner;
  void (*_bridge_release)(void *owner, void *root);
  uint32_t kind;
  union {
    struct {
      uint8_t empty;
    } stop;
    struct {
      const mutualcheckedrecords_gmp_envelope_t *packet;
    } more;
  } cases;
};
static inline void mutualcheckedrecords_gmp_step_t_init(mutualcheckedrecords_gmp_step_t *value) {
  if (!value) return;
  memset(value, 0, sizeof(*value));
  value->kind = UINT32_MAX;
}
static inline void mutualcheckedrecords_gmp_step_t_destroy_inline(mutualcheckedrecords_gmp_step_t *value) {
  (void)value;
  switch (value->kind) {
  case 0:
    break;
  case 1:
    break;
  default: break;
  }
}
static inline void mutualcheckedrecords_gmp_step_t_dispose(mutualcheckedrecords_gmp_step_t *value) {
  if (!value) return;
  if (value->_bridge_owner && value->_bridge_release) value->_bridge_release(value->_bridge_owner, value);
  else mutualcheckedrecords_gmp_step_t_destroy_inline(value);
}
static inline void mutualcheckedrecords_gmp_step_t_clear(mutualcheckedrecords_gmp_step_t *value) {
  if (!value) return;
  mutualcheckedrecords_gmp_step_t_dispose(value);
  mutualcheckedrecords_gmp_step_t_init(value);
}
static inline int mutualcheckedrecords_gmp_step_t_select(mutualcheckedrecords_gmp_step_t *value, mutualcheckedrecords_gmp_step_t_tag kind) {
  if (!value || (uint32_t)kind >= 2) return 0;
  mutualcheckedrecords_gmp_step_t_clear(value);
  value->kind = (uint32_t)kind;
  switch (kind) {
  case 0:
    break;
  case 1:
    break;
  default: break;
  }
  return 1;
}

typedef mutualcheckedrecords_gmp_envelope_t mutualcheckedrecords_gmp_envelope_alias_t;
static inline void mutualcheckedrecords_gmp_envelope_alias_t_init(mutualcheckedrecords_gmp_envelope_alias_t *value) { mutualcheckedrecords_gmp_envelope_t_init(value); }
static inline void mutualcheckedrecords_gmp_envelope_alias_t_clear(mutualcheckedrecords_gmp_envelope_alias_t *value) { mutualcheckedrecords_gmp_envelope_t_clear(value); }

#endif /* MUTUALCHECKEDRECORDS_GMP_GRAPH_VALUES_H */
