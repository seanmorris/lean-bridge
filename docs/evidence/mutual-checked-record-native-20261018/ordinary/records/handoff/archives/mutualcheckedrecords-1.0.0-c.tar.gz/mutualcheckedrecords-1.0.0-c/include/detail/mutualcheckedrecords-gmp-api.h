#pragma once
#include "mutualcheckedrecords-status.h"
#include "mutualcheckedrecords-gmp-graph-values.h"
#ifdef __cplusplus
extern "C" {
#endif
mutualcheckedrecords_status mutualcheckedrecords_gmp_initialize(mutualcheckedrecords_error *error);
mutualcheckedrecords_status mutualcheckedrecords_gmp_echo(mutualcheckedrecords_gmp_envelope_t const * a0, mutualcheckedrecords_gmp_envelope_t * out, mutualcheckedrecords_error *error);
mutualcheckedrecords_status mutualcheckedrecords_gmp_echo_groups(mutualcheckedrecords_gmp_graph_6586a61fcab9df3e21b7_t const * a0, mutualcheckedrecords_gmp_graph_6586a61fcab9df3e21b7_t * out, mutualcheckedrecords_error *error);
mutualcheckedrecords_status mutualcheckedrecords_gmp_first(mutualcheckedrecords_gmp_envelope_t const * a0, mpz_ptr out, mutualcheckedrecords_error *error);
mutualcheckedrecords_status mutualcheckedrecords_gmp_groups(mutualcheckedrecords_gmp_graph_6586a61fcab9df3e21b7_t const * a0, mpz_ptr out, mutualcheckedrecords_error *error);
mutualcheckedrecords_status mutualcheckedrecords_gmp_produce(mpz_srcptr a0, mutualcheckedrecords_gmp_envelope_t * out, mutualcheckedrecords_error *error);
mutualcheckedrecords_status mutualcheckedrecords_gmp_second(mutualcheckedrecords_gmp_envelope_t const * a0, mpz_ptr out, mutualcheckedrecords_error *error);
#ifdef __cplusplus
}
#endif
