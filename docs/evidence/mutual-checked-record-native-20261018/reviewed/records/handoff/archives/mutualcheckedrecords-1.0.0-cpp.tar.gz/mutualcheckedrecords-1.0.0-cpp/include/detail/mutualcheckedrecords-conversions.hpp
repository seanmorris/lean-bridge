#pragma once
#include "mutualcheckedrecords-values.hpp"
#include "mutualcheckedrecords-graph-types.h"
#include <climits>
#include <cstring>
#include <iterator>
namespace lean_bridge::mutualcheckedrecords::detail {
static_assert(sizeof(size_t) == 8 && sizeof(void*) == 8 && sizeof(bool) == 1 && CHAR_BIT == 8, "Native graph conversion requires the verified 64-bit byte ABI");
class GraphConversionError : public std::runtime_error {
public:
  uint32_t status;
  bool native_status;
  GraphConversionError(uint32_t code, const char* message, bool native = false)
    : std::runtime_error(message), status(code), native_status(native) {}
};
[[noreturn]] inline void graph_fail(uint32_t status, const char* text, bool native = false) {
  throw GraphConversionError(status, text, native);
}
struct GraphBudget {
  size_t nodes = 262144;
  size_t native_bytes = 16u * 1024u * 1024u;
  size_t storage_bytes = 16u * 1024u * 1024u;
  static void charge(size_t& budget, size_t count, size_t width) {
    if (count > budget / width) graph_fail(2, "Copied graph byte limit exceeded");
    budget -= count * width;
  }
  void enter(size_t depth) {
    if (depth > 128 || !nodes) graph_fail(2, "Copied graph depth or node limit exceeded");
    --nodes;
  }
  void native(size_t count, size_t width) { charge(native_bytes, count, width); }
  void storage(size_t count, size_t width) { charge(storage_bytes, count, width); }
};
template<class T> inline const T& graph_read(const T* pointer) {
  const uintptr_t address = reinterpret_cast<uintptr_t>(pointer);
  if (!pointer || address % alignof(T) || sizeof(T) > UINTPTR_MAX - address) graph_fail(4, "Invalid native graph pointer");
  return *pointer;
}
template<class T> inline void graph_span(const T* pointer, size_t count) {
  if (count) {
    if (count > (UINTPTR_MAX - reinterpret_cast<uintptr_t>(pointer)) / sizeof(T)) graph_fail(4, "Invalid native graph span");
    (void)graph_read(pointer);
  }
}
inline void graph_utf8(const char* data, size_t length, uint32_t status) {
  size_t i = 0;
  while (i < length) {
    uint32_t point = static_cast<uint8_t>(data[i++]), minimum; size_t extra;
    if (point < 0x80) continue;
    if (point >= 0xc2 && point <= 0xdf) { point &= 0x1f; extra = 1; minimum = 0x80; }
    else if (point >= 0xe0 && point <= 0xef) { point &= 0x0f; extra = 2; minimum = 0x800; }
    else if (point >= 0xf0 && point <= 0xf4) { point &= 7; extra = 3; minimum = 0x10000; }
    else graph_fail(status, "Invalid UTF-8 text");
    if (extra > length - i) graph_fail(status, "Incomplete UTF-8 text");
    while (extra--) {
      uint8_t next = static_cast<uint8_t>(data[i++]);
      if ((next & 0xc0) != 0x80) graph_fail(status, "Invalid UTF-8 continuation");
      point = (point << 6) | (next & 0x3f);
    }
    if (point < minimum || point > 0x10ffff || (point >= 0xd800 && point <= 0xdfff)) graph_fail(status, "Invalid UTF-8 scalar");
  }
}
template<class Integer> inline size_t graph_limb_count(const Integer& source) {
  auto high = source.backend().limbs()[source.backend().size() - 1]; size_t high_bits = 0;
  while (high) { ++high_bits; high >>= 1; }
  const size_t bits = (source.backend().size() - 1) * sizeof(*source.backend().limbs()) * CHAR_BIT + high_bits;
  return (bits + 31) / 32;
}
template<class T, void (*Clear)(T*)> struct GraphOwned {
  T* value;
  explicit GraphOwned(T* input) : value(input) {}
  GraphOwned(const GraphOwned&) = delete;
  GraphOwned& operator=(const GraphOwned&) = delete;
  ~GraphOwned() { Clear(value); }
};
struct GraphView0;
inline void graph_check0(const Graph6586a61fcab9df3e21b7&, size_t, bool, GraphBudget&);
inline Graph6586a61fcab9df3e21b7 graph_from0(const mutualcheckedrecords_graph_6586a61fcab9df3e21b7_t&, size_t, bool, bool, GraphBudget&);
struct GraphView1;
inline void graph_check1(const Graphc8c78faf2eecb4e21389&, size_t, bool, GraphBudget&);
inline Graphc8c78faf2eecb4e21389 graph_from1(const mutualcheckedrecords_graph_c8c78faf2eecb4e21389_t&, size_t, bool, bool, GraphBudget&);
struct GraphView2;
inline void graph_check2(const Graphd2fe45ba488df4ece96d&, size_t, bool, GraphBudget&);
inline Graphd2fe45ba488df4ece96d graph_from2(const mutualcheckedrecords_graph_d2fe45ba488df4ece96d_t&, size_t, bool, bool, GraphBudget&);
struct GraphView3;
inline void graph_check3(const Envelope&, size_t, bool, GraphBudget&);
inline Envelope graph_from3(const mutualcheckedrecords_envelope_t&, size_t, bool, bool, GraphBudget&);
struct GraphView4;
inline void graph_check4(const Step&, size_t, bool, GraphBudget&);
inline Step graph_from4(const mutualcheckedrecords_step_t&, size_t, bool, bool, GraphBudget&);
struct GraphView5;
inline void graph_check5(const Nat&, size_t, bool, GraphBudget&);
inline Nat graph_from5(const mutualcheckedrecords_scalar_nat_t&, size_t, bool, bool, GraphBudget&);
struct GraphView0 {
  std::vector<GraphView1> items;
  std::unique_ptr<mutualcheckedrecords_graph_c8c78faf2eecb4e21389_t[]> data;
  mutualcheckedrecords_graph_6586a61fcab9df3e21b7_t value{};
  explicit GraphView0(const Graph6586a61fcab9df3e21b7&);
  ~GraphView0();
  GraphView0(GraphView0&&) noexcept;
  GraphView0(const GraphView0&) = delete;
};
struct GraphView1 {
  std::unique_ptr<GraphView3> field0;
  mutualcheckedrecords_graph_c8c78faf2eecb4e21389_t value{};
  explicit GraphView1(const Graphc8c78faf2eecb4e21389&);
  ~GraphView1();
  GraphView1(GraphView1&&) noexcept;
  GraphView1(const GraphView1&) = delete;
};
struct GraphView2 {
  std::unique_ptr<GraphView4> field0;
  mutualcheckedrecords_graph_d2fe45ba488df4ece96d_t value{};
  explicit GraphView2(const Graphd2fe45ba488df4ece96d&);
  ~GraphView2();
  GraphView2(GraphView2&&) noexcept;
  GraphView2(const GraphView2&) = delete;
};
struct GraphView3 {
  std::unique_ptr<GraphView5> field0;
  std::unique_ptr<GraphView5> field1;
  std::unique_ptr<GraphView2> field2;
  mutualcheckedrecords_envelope_t value{};
  explicit GraphView3(const Envelope&);
  ~GraphView3();
  GraphView3(GraphView3&&) noexcept;
  GraphView3(const GraphView3&) = delete;
};
struct GraphView4 {
  std::unique_ptr<GraphView3> field1_0;
  mutualcheckedrecords_step_t value{};
  explicit GraphView4(const Step&);
  ~GraphView4();
  GraphView4(GraphView4&&) noexcept;
  GraphView4(const GraphView4&) = delete;
};
struct GraphView5 {
  std::vector<uint32_t> limbs;
  mutualcheckedrecords_scalar_nat_t value{};
  explicit GraphView5(const Nat&);
  ~GraphView5();
  GraphView5(GraphView5&&) noexcept;
  GraphView5(const GraphView5&) = delete;
};
inline GraphView0::~GraphView0() = default;
inline GraphView0::GraphView0(GraphView0&&) noexcept = default;
inline void graph_check0(const Graph6586a61fcab9df3e21b7& source, size_t depth, bool storage, GraphBudget& budget) {
  (void)source; budget.enter(depth);
  if (storage) budget.native(1, sizeof(mutualcheckedrecords_graph_6586a61fcab9df3e21b7_t));
  budget.storage(1, sizeof(GraphView0));
  if (source.size() > budget.nodes) graph_fail(2, "Copied sequence node limit exceeded");
  budget.native(source.size(), sizeof(mutualcheckedrecords_graph_c8c78faf2eecb4e21389_t)); budget.storage(source.size(), sizeof(mutualcheckedrecords_graph_c8c78faf2eecb4e21389_t));
  for (const auto& child : source) graph_check1(child, depth + 1, false, budget);
}
inline GraphView0::GraphView0(const Graph6586a61fcab9df3e21b7& source) {
  (void)source;
  items.reserve(source.size());
  data = source.empty() ? nullptr : std::make_unique<mutualcheckedrecords_graph_c8c78faf2eecb4e21389_t[]>(source.size());
  for (const auto& child : source) items.emplace_back(child);
  for (size_t j = 0; j < source.size(); ++j) data[j] = items[j].value;
  value.data = data.get(); value.length = source.size();
}
inline Graph6586a61fcab9df3e21b7 graph_from0(const mutualcheckedrecords_graph_6586a61fcab9df3e21b7_t& source, size_t depth, bool native_storage, bool host_storage, GraphBudget& budget) {
  (void)source; budget.enter(depth);
  if (native_storage) budget.native(1, sizeof(mutualcheckedrecords_graph_6586a61fcab9df3e21b7_t));
  if (host_storage) budget.storage(1, sizeof(Graph6586a61fcab9df3e21b7));
  if (source.length > budget.nodes) graph_fail(2, "Copied sequence node limit exceeded");
  budget.native(source.length, sizeof(mutualcheckedrecords_graph_c8c78faf2eecb4e21389_t)); budget.storage(source.length, sizeof(Graphc8c78faf2eecb4e21389));
  graph_span(source.data, source.length);
  Graph6586a61fcab9df3e21b7 result; result.reserve(source.length);
  for (size_t j = 0; j < source.length; ++j) result.push_back(graph_from1(source.data[j], depth + 1, false, false, budget));
  return result;
}
inline GraphView1::~GraphView1() = default;
inline GraphView1::GraphView1(GraphView1&&) noexcept = default;
inline void graph_check1(const Graphc8c78faf2eecb4e21389& source, size_t depth, bool storage, GraphBudget& budget) {
  (void)source; budget.enter(depth);
  if (storage) budget.native(1, sizeof(mutualcheckedrecords_graph_c8c78faf2eecb4e21389_t));
  budget.storage(1, sizeof(GraphView1));
  if (source.has_value()) {
  graph_check3(*source, depth + 1, false, budget);
  }
}
inline GraphView1::GraphView1(const Graphc8c78faf2eecb4e21389& source) {
  (void)source;
  value.has_value = source.has_value();
  if (source.has_value()) {
  field0 = std::make_unique<GraphView3>(*source);
  value.value = field0->value;
  }
}
inline Graphc8c78faf2eecb4e21389 graph_from1(const mutualcheckedrecords_graph_c8c78faf2eecb4e21389_t& source, size_t depth, bool native_storage, bool host_storage, GraphBudget& budget) {
  (void)source; budget.enter(depth);
  if (native_storage) budget.native(1, sizeof(mutualcheckedrecords_graph_c8c78faf2eecb4e21389_t));
  if (host_storage) budget.storage(1, sizeof(Graphc8c78faf2eecb4e21389));
  if (source.has_value > 1) graph_fail(4, "Invalid native optional/result tag");
  if (source.has_value) return Graphc8c78faf2eecb4e21389{std::in_place, graph_from3(source.value, depth + 1, false, false, budget)};
  return std::nullopt;
}
inline GraphView2::~GraphView2() = default;
inline GraphView2::GraphView2(GraphView2&&) noexcept = default;
inline void graph_check2(const Graphd2fe45ba488df4ece96d& source, size_t depth, bool storage, GraphBudget& budget) {
  (void)source; budget.enter(depth);
  if (storage) budget.native(1, sizeof(mutualcheckedrecords_graph_d2fe45ba488df4ece96d_t));
  budget.storage(1, sizeof(GraphView2));
  if (source.has_value()) {
  if (!(*source)) graph_fail(1, "Empty recursive value box");
  graph_check4(*(*source), depth + 1, true, budget);
  }
}
inline GraphView2::GraphView2(const Graphd2fe45ba488df4ece96d& source) {
  (void)source;
  value.has_value = source.has_value();
  if (source.has_value()) {
  field0 = std::make_unique<GraphView4>(*(*source));
  value.value = &field0->value;
  }
}
inline Graphd2fe45ba488df4ece96d graph_from2(const mutualcheckedrecords_graph_d2fe45ba488df4ece96d_t& source, size_t depth, bool native_storage, bool host_storage, GraphBudget& budget) {
  (void)source; budget.enter(depth);
  if (native_storage) budget.native(1, sizeof(mutualcheckedrecords_graph_d2fe45ba488df4ece96d_t));
  if (host_storage) budget.storage(1, sizeof(Graphd2fe45ba488df4ece96d));
  if (source.has_value > 1) graph_fail(4, "Invalid native optional/result tag");
  if (source.has_value) return Graphd2fe45ba488df4ece96d{std::in_place, graph_from4(graph_read(source.value), depth + 1, true, true, budget)};
  return std::nullopt;
}
inline GraphView3::~GraphView3() = default;
inline GraphView3::GraphView3(GraphView3&&) noexcept = default;
inline void graph_check3(const Envelope& source, size_t depth, bool storage, GraphBudget& budget) {
  (void)source; budget.enter(depth);
  if (storage) budget.native(1, sizeof(mutualcheckedrecords_envelope_t));
  budget.storage(1, sizeof(GraphView3));
  graph_check5(source.value, depth + 1, false, budget);
  graph_check5(source.mode, depth + 1, false, budget);
  graph_check2(source.next, depth + 1, true, budget);
}
inline GraphView3::GraphView3(const Envelope& source) {
  (void)source;
  field0 = std::make_unique<GraphView5>(source.value);
  value.value = field0->value;
  field1 = std::make_unique<GraphView5>(source.mode);
  value.mode = field1->value;
  field2 = std::make_unique<GraphView2>(source.next);
  value.next = &field2->value;
}
inline Envelope graph_from3(const mutualcheckedrecords_envelope_t& source, size_t depth, bool native_storage, bool host_storage, GraphBudget& budget) {
  (void)source; budget.enter(depth);
  if (native_storage) budget.native(1, sizeof(mutualcheckedrecords_envelope_t));
  if (host_storage) budget.storage(1, sizeof(Envelope));
  return Envelope{graph_from5(source.value, depth + 1, false, false, budget), graph_from5(source.mode, depth + 1, false, false, budget), graph_from2(graph_read(source.next), depth + 1, true, false, budget)};
}
inline GraphView4::~GraphView4() = default;
inline GraphView4::GraphView4(GraphView4&&) noexcept = default;
inline void graph_check4(const Step& source, size_t depth, bool storage, GraphBudget& budget) {
  (void)source; budget.enter(depth);
  if (storage) budget.native(1, sizeof(mutualcheckedrecords_step_t));
  budget.storage(1, sizeof(GraphView4));
  if (source.value.valueless_by_exception()) graph_fail(1, "Variant has no active constructor");
  switch (source.value.index()) {
  case 0:
  break;
  case 1:
  if (!(std::get<StepMore>(source.value).packet)) graph_fail(1, "Empty recursive value box");
  graph_check3(*(std::get<StepMore>(source.value).packet), depth + 1, true, budget);
  break;
  default: graph_fail(1, "Invalid variant constructor");
  }
}
inline GraphView4::GraphView4(const Step& source) {
  (void)source;
  value.kind = static_cast<uint32_t>(source.value.index());
  switch (source.value.index()) {
  case 0:
  break;
  case 1:
  field1_0 = std::make_unique<GraphView3>(*(std::get<StepMore>(source.value).packet));
  value.cases.more.packet = &field1_0->value;
  break;
  default: graph_fail(1, "Invalid variant constructor");
  }
}
inline Step graph_from4(const mutualcheckedrecords_step_t& source, size_t depth, bool native_storage, bool host_storage, GraphBudget& budget) {
  (void)source; budget.enter(depth);
  if (native_storage) budget.native(1, sizeof(mutualcheckedrecords_step_t));
  if (host_storage) budget.storage(1, sizeof(Step));
  switch (source.kind) {
  case 0: return StepStop{};
  case 1: return StepMore{graph_from3(graph_read(source.cases.more.packet), depth + 1, true, true, budget)};
  default: graph_fail(4, "Invalid native variant constructor");
  }
}
inline GraphView5::~GraphView5() = default;
inline GraphView5::GraphView5(GraphView5&&) noexcept = default;
inline void graph_check5(const Nat& source, size_t depth, bool storage, GraphBudget& budget) {
  (void)source; budget.enter(depth);
  if (storage) budget.native(1, sizeof(mutualcheckedrecords_scalar_nat_t));
  budget.storage(1, sizeof(GraphView5));
  if (source < 0) graph_fail(1, "Nat must be nonnegative");
  if (source.backend().size() > budget.native_bytes / sizeof(boost::multiprecision::limb_type) + 1) graph_fail(2, "Copied integer limit exceeded");
  const size_t limbs = graph_limb_count(source);
  budget.native(limbs, sizeof(uint32_t)); budget.storage(limbs, sizeof(uint32_t));
}
inline GraphView5::GraphView5(const Nat& source) {
  (void)source;
  limbs.reserve(graph_limb_count(source));
  if (source != 0) boost::multiprecision::export_bits(source, std::back_inserter(limbs), 32, false);
  value.data = limbs.data(); value.length = limbs.size();
}
inline Nat graph_from5(const mutualcheckedrecords_scalar_nat_t& source, size_t depth, bool native_storage, bool host_storage, GraphBudget& budget) {
  (void)source; budget.enter(depth);
  if (native_storage) budget.native(1, sizeof(mutualcheckedrecords_scalar_nat_t));
  if (host_storage) budget.storage(1, sizeof(Nat));
  budget.native(source.length, sizeof(uint32_t)); budget.storage(source.length, sizeof(uint32_t));
  graph_span(source.data, source.length);
  Nat result = 0;
  if (source.length) boost::multiprecision::import_bits(result, source.data, source.data + source.length, 32, false);
  return result;
}
template<class Invoke> inline Envelope graph_call_echo(Invoke&& invoke, const Envelope& arg0) {
  GraphBudget budget;
  graph_check3(arg0, 0, true, budget);
  GraphView3 view0(arg0);
  mutualcheckedrecords_envelope_t result{};
  GraphOwned<mutualcheckedrecords_envelope_t, mutualcheckedrecords_envelope_t_clear> owner(&result);
  const uint32_t status = std::forward<Invoke>(invoke)(&view0.value, &result);
  if (status) graph_fail(status, "Native copied graph call failed", true);
  return graph_from3(result, 0, true, true, budget);
}
template<class Invoke> inline Graph6586a61fcab9df3e21b7 graph_call_echo_groups(Invoke&& invoke, const Graph6586a61fcab9df3e21b7& arg0) {
  GraphBudget budget;
  graph_check0(arg0, 0, true, budget);
  GraphView0 view0(arg0);
  mutualcheckedrecords_graph_6586a61fcab9df3e21b7_t result{};
  GraphOwned<mutualcheckedrecords_graph_6586a61fcab9df3e21b7_t, mutualcheckedrecords_graph_6586a61fcab9df3e21b7_t_clear> owner(&result);
  const uint32_t status = std::forward<Invoke>(invoke)(&view0.value, &result);
  if (status) graph_fail(status, "Native copied graph call failed", true);
  return graph_from0(result, 0, true, true, budget);
}
template<class Invoke> inline Nat graph_call_first(Invoke&& invoke, const Envelope& arg0) {
  GraphBudget budget;
  graph_check3(arg0, 0, true, budget);
  GraphView3 view0(arg0);
  mutualcheckedrecords_scalar_nat_t result{};
  GraphOwned<mutualcheckedrecords_scalar_nat_t, mutualcheckedrecords_scalar_nat_t_clear> owner(&result);
  const uint32_t status = std::forward<Invoke>(invoke)(&view0.value, &result);
  if (status) graph_fail(status, "Native copied graph call failed", true);
  return graph_from5(result, 0, true, true, budget);
}
template<class Invoke> inline Nat graph_call_groups(Invoke&& invoke, const Graph6586a61fcab9df3e21b7& arg0) {
  GraphBudget budget;
  graph_check0(arg0, 0, true, budget);
  GraphView0 view0(arg0);
  mutualcheckedrecords_scalar_nat_t result{};
  GraphOwned<mutualcheckedrecords_scalar_nat_t, mutualcheckedrecords_scalar_nat_t_clear> owner(&result);
  const uint32_t status = std::forward<Invoke>(invoke)(&view0.value, &result);
  if (status) graph_fail(status, "Native copied graph call failed", true);
  return graph_from5(result, 0, true, true, budget);
}
template<class Invoke> inline Envelope graph_call_produce(Invoke&& invoke, const Nat& arg0) {
  GraphBudget budget;
  graph_check5(arg0, 0, true, budget);
  GraphView5 view0(arg0);
  mutualcheckedrecords_envelope_t result{};
  GraphOwned<mutualcheckedrecords_envelope_t, mutualcheckedrecords_envelope_t_clear> owner(&result);
  const uint32_t status = std::forward<Invoke>(invoke)(&view0.value, &result);
  if (status) graph_fail(status, "Native copied graph call failed", true);
  return graph_from3(result, 0, true, true, budget);
}
template<class Invoke> inline Nat graph_call_second(Invoke&& invoke, const Envelope& arg0) {
  GraphBudget budget;
  graph_check3(arg0, 0, true, budget);
  GraphView3 view0(arg0);
  mutualcheckedrecords_scalar_nat_t result{};
  GraphOwned<mutualcheckedrecords_scalar_nat_t, mutualcheckedrecords_scalar_nat_t_clear> owner(&result);
  const uint32_t status = std::forward<Invoke>(invoke)(&view0.value, &result);
  if (status) graph_fail(status, "Native copied graph call failed", true);
  return graph_from5(result, 0, true, true, budget);
}
}
