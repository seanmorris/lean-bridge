#ifndef MUTUALCHECKEDRECORDS_COPIED_GRAPH_STATUS_H
#define MUTUALCHECKEDRECORDS_COPIED_GRAPH_STATUS_H
#include <stddef.h>
#include <stdint.h>
typedef enum mutualcheckedrecords_status {
  MUTUALCHECKEDRECORDS_STATUS_OK = 0, MUTUALCHECKEDRECORDS_STATUS_INVALID_ARGUMENT = 1,
  MUTUALCHECKEDRECORDS_STATUS_RUNTIME_UNAVAILABLE = 2, MUTUALCHECKEDRECORDS_STATUS_RUNTIME_REJECTED = 3,
  MUTUALCHECKEDRECORDS_STATUS_DECLARED_ERROR = 4, MUTUALCHECKEDRECORDS_STATUS_UNEXPECTED_ERROR = 5
} mutualcheckedrecords_status;
typedef enum mutualcheckedrecords_error_code {
  MUTUALCHECKEDRECORDS_ERROR_NONE = 0, MUTUALCHECKEDRECORDS_ERROR_INVALID_ARGUMENT = 1,
  MUTUALCHECKEDRECORDS_ERROR_RUNTIME_UNAVAILABLE = 2, MUTUALCHECKEDRECORDS_ERROR_UNEXPECTED = 65535
} mutualcheckedrecords_error_code;
typedef struct mutualcheckedrecords_error { mutualcheckedrecords_error_code code; const char *message; size_t message_length; } mutualcheckedrecords_error;
static inline mutualcheckedrecords_status mutualcheckedrecords_graph_finish_with_message(uint32_t status, mutualcheckedrecords_error *error, const char *specific) {
  static const char *const messages[] = {"", "Invalid copied value", "Copied value limit exceeded", "Copied value allocation failed", "Malformed native result", "Lean runtime initialization failed or runtime retired"};
  const char *message = messages[status <= 5 ? status : 4];
  if (status == 1 && specific) message = specific;
  size_t length = 0; while (message[length]) ++length;
  mutualcheckedrecords_status result = status == 0 ? MUTUALCHECKEDRECORDS_STATUS_OK
    : status <= 2 ? MUTUALCHECKEDRECORDS_STATUS_INVALID_ARGUMENT : MUTUALCHECKEDRECORDS_STATUS_UNEXPECTED_ERROR;
  if (error) { error->code = status == 0 ? MUTUALCHECKEDRECORDS_ERROR_NONE
    : status <= 2 ? MUTUALCHECKEDRECORDS_ERROR_INVALID_ARGUMENT : MUTUALCHECKEDRECORDS_ERROR_UNEXPECTED;
    error->message = message; error->message_length = length; }
  return result;
}
static inline mutualcheckedrecords_status mutualcheckedrecords_graph_finish(uint32_t status, mutualcheckedrecords_error *error) {
  return mutualcheckedrecords_graph_finish_with_message(status, error, NULL);
}
#endif
