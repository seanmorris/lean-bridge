# mutualcheckedrecords 1.0.0

Compiled C++20 API from mutualcheckedrecords@1.0.0. Linux x86-64, glibc 2.38 or newer. Lean is not required by consumers. The shared native runtime is included in lib/ and loads automatically.

Include mutualcheckedrecords.hpp. Use pkg-config package mutualcheckedrecords, or find_package(LeanBridgeMutualcheckedrecords CONFIG REQUIRED) and link LeanBridge::mutualcheckedrecords. C++ functions live in lean_bridge::mutualcheckedrecords.

C++ results own their memory and release native buffers automatically, including when a C++ allocation throws.

Strings are length-delimited UTF-8, including embedded NUL. Byte arrays are uninterpreted bytes. Nat and Int are Boost.Multiprecision cpp_int values. Negative Nat inputs reject. Packages using these types include Boost 1.90.0 standalone headers, license and source hashes; CMake and pkg-config configure them automatically. Unit parameters are zero in C and std::monostate in C++; Unit results have no output. Fixed-width integers use exact-width host types; floating-point values retain IEEE special values. Input and output copies share a 16 MiB per-call budget. Invalid input leaves the output unchanged and returns a status (C) or throws Error (C++).

Recursive copied records and named variants use a finite type graph. Values must be finite and acyclic, with at most 128 levels and 262,144 visited nodes per call. All inputs and the result share a 16 MiB native-copy budget; host conversion storage has a separate 16 MiB budget. Limits include container slots and ownership bookkeeping, not the Lean algorithm's working memory. Invalid arguments and limit failures report INVALID_ARGUMENT. Bridge allocation failures report UNEXPECTED_ERROR; malformed native results retire the shared runtime and later calls reject. Already owned results can still be released.

C++ uses owned strings, vectors, optional values, pairs and named structs. Variants have a named struct for each constructor; inspect value with std::get, std::holds_alternative or std::visit. Recursive fields that require indirection use Box<T>; copying a box makes an independent deep copy. Empty required boxes reject. None, Some(None), Unit and empty constructors remain distinct. Calls return owned values, throw Error with status/code on bridge failures, or propagate std::bad_alloc for C++ allocation failures. Input and native output views are released during exception unwinding. Do not mutate input values concurrently with a call.

- mutualcheckedrecords_echo: lean:MutualCheckedRecords.echo
- mutualcheckedrecords_echo_groups: lean:MutualCheckedRecords.echoGroups
- mutualcheckedrecords_first: lean:MutualCheckedRecords.first
- mutualcheckedrecords_groups: lean:MutualCheckedRecords.groups
- mutualcheckedrecords_produce: lean:MutualCheckedRecords.produce
- mutualcheckedrecords_second: lean:MutualCheckedRecords.second
