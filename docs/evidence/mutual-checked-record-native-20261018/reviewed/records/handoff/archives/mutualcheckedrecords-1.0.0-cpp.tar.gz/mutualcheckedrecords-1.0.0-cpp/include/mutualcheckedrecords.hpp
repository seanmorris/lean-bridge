#pragma once
#include "detail/mutualcheckedrecords-status.h"
#include <stdbool.h>
#include <string.h>
namespace lean_bridge::mutualcheckedrecords::detail {
struct mutualcheckedrecords_graph_6586a61fcab9df3e21b7_t;
struct mutualcheckedrecords_graph_c8c78faf2eecb4e21389_t;
struct mutualcheckedrecords_graph_d2fe45ba488df4ece96d_t;
struct mutualcheckedrecords_envelope_t;
struct mutualcheckedrecords_step_t;
struct mutualcheckedrecords_scalar_nat_t;
#include "detail/mutualcheckedrecords-graph.h"
}
#include "detail/mutualcheckedrecords-conversions.hpp"
namespace lean_bridge::mutualcheckedrecords {
class Error final : public std::runtime_error {
public:
  mutualcheckedrecords_status status; mutualcheckedrecords_error_code code;
  Error(mutualcheckedrecords_status status, const mutualcheckedrecords_error& error) : std::runtime_error(error.message ? std::string(error.message, error.message_length) : "Lean call failed"), status(status), code(error.code) {}
};
inline Envelope echo(const Envelope& a0) {
  try {
    auto result = detail::graph_call_echo(detail::mutualcheckedrecords_echo_graph, a0);
    if (!detail::mutualcheckedrecords_graph_ready()) detail::graph_fail(5, "Lean runtime retired during output conversion");
    return result;
  } catch (const detail::GraphConversionError& failure) {
    if (failure.status == 4) detail::mutualcheckedrecords_graph_retire();
    const char *specific = failure.native_status && failure.status == 1 ? detail::mutualcheckedrecords_graph_error() : nullptr;
    mutualcheckedrecords_error error{}; auto status = mutualcheckedrecords_graph_finish_with_message(failure.status, &error, specific);
    throw Error(status, error);
  }
}
inline Graph6586a61fcab9df3e21b7 echo_groups(const Graph6586a61fcab9df3e21b7& a0) {
  try {
    auto result = detail::graph_call_echo_groups(detail::mutualcheckedrecords_echo_groups_graph, a0);
    if (!detail::mutualcheckedrecords_graph_ready()) detail::graph_fail(5, "Lean runtime retired during output conversion");
    return result;
  } catch (const detail::GraphConversionError& failure) {
    if (failure.status == 4) detail::mutualcheckedrecords_graph_retire();
    const char *specific = failure.native_status && failure.status == 1 ? detail::mutualcheckedrecords_graph_error() : nullptr;
    mutualcheckedrecords_error error{}; auto status = mutualcheckedrecords_graph_finish_with_message(failure.status, &error, specific);
    throw Error(status, error);
  }
}
inline Nat first(const Envelope& a0) {
  try {
    auto result = detail::graph_call_first(detail::mutualcheckedrecords_first_graph, a0);
    if (!detail::mutualcheckedrecords_graph_ready()) detail::graph_fail(5, "Lean runtime retired during output conversion");
    return result;
  } catch (const detail::GraphConversionError& failure) {
    if (failure.status == 4) detail::mutualcheckedrecords_graph_retire();
    const char *specific = failure.native_status && failure.status == 1 ? detail::mutualcheckedrecords_graph_error() : nullptr;
    mutualcheckedrecords_error error{}; auto status = mutualcheckedrecords_graph_finish_with_message(failure.status, &error, specific);
    throw Error(status, error);
  }
}
inline Nat groups(const Graph6586a61fcab9df3e21b7& a0) {
  try {
    auto result = detail::graph_call_groups(detail::mutualcheckedrecords_groups_graph, a0);
    if (!detail::mutualcheckedrecords_graph_ready()) detail::graph_fail(5, "Lean runtime retired during output conversion");
    return result;
  } catch (const detail::GraphConversionError& failure) {
    if (failure.status == 4) detail::mutualcheckedrecords_graph_retire();
    const char *specific = failure.native_status && failure.status == 1 ? detail::mutualcheckedrecords_graph_error() : nullptr;
    mutualcheckedrecords_error error{}; auto status = mutualcheckedrecords_graph_finish_with_message(failure.status, &error, specific);
    throw Error(status, error);
  }
}
inline Envelope produce(const Nat& a0) {
  try {
    auto result = detail::graph_call_produce(detail::mutualcheckedrecords_produce_graph, a0);
    if (!detail::mutualcheckedrecords_graph_ready()) detail::graph_fail(5, "Lean runtime retired during output conversion");
    return result;
  } catch (const detail::GraphConversionError& failure) {
    if (failure.status == 4) detail::mutualcheckedrecords_graph_retire();
    const char *specific = failure.native_status && failure.status == 1 ? detail::mutualcheckedrecords_graph_error() : nullptr;
    mutualcheckedrecords_error error{}; auto status = mutualcheckedrecords_graph_finish_with_message(failure.status, &error, specific);
    throw Error(status, error);
  }
}
inline Nat second(const Envelope& a0) {
  try {
    auto result = detail::graph_call_second(detail::mutualcheckedrecords_second_graph, a0);
    if (!detail::mutualcheckedrecords_graph_ready()) detail::graph_fail(5, "Lean runtime retired during output conversion");
    return result;
  } catch (const detail::GraphConversionError& failure) {
    if (failure.status == 4) detail::mutualcheckedrecords_graph_retire();
    const char *specific = failure.native_status && failure.status == 1 ? detail::mutualcheckedrecords_graph_error() : nullptr;
    mutualcheckedrecords_error error{}; auto status = mutualcheckedrecords_graph_finish_with_message(failure.status, &error, specific);
    throw Error(status, error);
  }
}
}
