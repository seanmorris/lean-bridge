package LeanBridge::ZeroPayloadCheckedRecords;
use strict;
use warnings;
use Math::BigInt;
use LeanBridge::Runtime;
die "Incompatible shared Lean runtime package version\n" unless $LeanBridge::Runtime::VERSION eq '0.0020130180835253351074425099676719723942806298898514237203907626409680523998624031';
use XSLoader;
our $VERSION = '1.000';
LeanBridge::Runtime::_load_component(__FILE__, 'libcomponent_d43d7c5a9f170f3ce127.so', '99757ffd528089839276986cecbacc46ff50f89c9c9d51ddfaa77e680091384a', '6f4dbd1e2e112f4678734553d1c9bb8722fad3e6290adbff1ac46d05e5eff7dd', { 'ZeroPayloadCheckedRecords' => 'ec380a8846fdb502045f3a17e7593b95554a54a1045fa83a165af9dd4f7de1d8' }, 'zeropayloadcheckedrecords@1.0.0');
XSLoader::load(__PACKAGE__, $VERSION);
sub true () { !!1 }
sub false () { !!0 }
sub CLONE_SKIP { 1 }

package LeanBridge::ZeroPayloadCheckedRecords::Some;
sub new {
  die "LeanBridge::ZeroPayloadCheckedRecords::Some->new expects one payload\n" unless @_ == 2 && $_[0] eq 'LeanBridge::ZeroPayloadCheckedRecords::Some';
  return bless { value => $_[1] }, 'LeanBridge::ZeroPayloadCheckedRecords::Some';
}
sub value { $_[0]->{value} }

package LeanBridge::ZeroPayloadCheckedRecords::Witness;
sub new {
  die "LeanBridge::ZeroPayloadCheckedRecords::Witness->new expects named fields\n" unless @_ % 2 == 1 && $_[0] eq 'LeanBridge::ZeroPayloadCheckedRecords::Witness';
  shift; my %fields;
  while (@_) {
    my ($key, $value) = splice @_, 0, 2;
    die "invalid record field\n" if !defined($key) || ref($key);
    $fields{$key} = $value;
  }
  my @required = qw();
  die "record fields do not match the generated schema\n" if keys(%fields) != @required || grep { !exists $fields{$_} } @required;
  return bless \%fields, 'LeanBridge::ZeroPayloadCheckedRecords::Witness';
}
package LeanBridge::ZeroPayloadCheckedRecords::Marker;
sub new {
  die "LeanBridge::ZeroPayloadCheckedRecords::Marker->new expects named fields\n" unless @_ % 2 == 1 && $_[0] eq 'LeanBridge::ZeroPayloadCheckedRecords::Marker';
  shift; my %fields;
  while (@_) {
    my ($key, $value) = splice @_, 0, 2;
    die "invalid record field\n" if !defined($key) || ref($key);
    $fields{$key} = $value;
  }
  my @required = qw();
  die "record fields do not match the generated schema\n" if keys(%fields) != @required || grep { !exists $fields{$_} } @required;
  return bless \%fields, 'LeanBridge::ZeroPayloadCheckedRecords::Marker';
}
package LeanBridge::ZeroPayloadCheckedRecords::Token;
sub new {
  die "LeanBridge::ZeroPayloadCheckedRecords::Token->new expects named fields\n" unless @_ % 2 == 1 && $_[0] eq 'LeanBridge::ZeroPayloadCheckedRecords::Token';
  shift; my %fields;
  while (@_) {
    my ($key, $value) = splice @_, 0, 2;
    die "invalid record field\n" if !defined($key) || ref($key);
    $fields{$key} = $value;
  }
  my @required = qw(tag);
  die "record fields do not match the generated schema\n" if keys(%fields) != @required || grep { !exists $fields{$_} } @required;
  return bless \%fields, 'LeanBridge::ZeroPayloadCheckedRecords::Token';
}
sub tag { $_[0]->{tag} }
package LeanBridge::ZeroPayloadCheckedRecords::Mark;
sub new { die "select a named variant constructor\n" }

package LeanBridge::ZeroPayloadCheckedRecords::Mark::Blank;
our @ISA = ('LeanBridge::ZeroPayloadCheckedRecords::Mark');
sub new {
  die "LeanBridge::ZeroPayloadCheckedRecords::Mark::Blank->new expects named fields\n" unless @_ % 2 == 1 && $_[0] eq 'LeanBridge::ZeroPayloadCheckedRecords::Mark::Blank';
  shift; my %fields;
  while (@_) {
    my ($key, $value) = splice @_, 0, 2;
    die "invalid constructor field\n" if !defined($key) || ref($key);
    die "duplicate constructor field\n" if exists $fields{$key};
    $fields{$key} = $value;
  }
  my @required = qw();
  die "constructor fields do not match the generated schema\n" if keys(%fields) != @required || grep { !exists $fields{$_} } @required;
  return bless \%fields, 'LeanBridge::ZeroPayloadCheckedRecords::Mark::Blank';
}

package LeanBridge::ZeroPayloadCheckedRecords::Mark::Marked;
our @ISA = ('LeanBridge::ZeroPayloadCheckedRecords::Mark');
sub new {
  die "LeanBridge::ZeroPayloadCheckedRecords::Mark::Marked->new expects named fields\n" unless @_ % 2 == 1 && $_[0] eq 'LeanBridge::ZeroPayloadCheckedRecords::Mark::Marked';
  shift; my %fields;
  while (@_) {
    my ($key, $value) = splice @_, 0, 2;
    die "invalid constructor field\n" if !defined($key) || ref($key);
    die "duplicate constructor field\n" if exists $fields{$key};
    $fields{$key} = $value;
  }
  my @required = qw(witness);
  die "constructor fields do not match the generated schema\n" if keys(%fields) != @required || grep { !exists $fields{$_} } @required;
  return bless \%fields, 'LeanBridge::ZeroPayloadCheckedRecords::Mark::Marked';
}
sub witness { $_[0]->{witness} }

1;

__END__
=head1 NAME

LeanBridge::ZeroPayloadCheckedRecords - Generated functions from zeropayloadcheckedrecords

=head1 API

=head2 absent_count

Calls C<ZeroPayloadCheckedRecords.absentCount> in the compiled Lean component.

Checked Lean refinements: value0 checked by ZeroPayloadCheckedRecords.mkAbsent.

=head2 mark_count

Calls C<ZeroPayloadCheckedRecords.markCount> in the compiled Lean component.

Checked Lean refinements: value0.marked.witness checked by ZeroPayloadCheckedRecords.mkWitness.

=head2 marker_count

Calls C<ZeroPayloadCheckedRecords.markerCount> in the compiled Lean component.

=head2 maybe_witness

Calls C<ZeroPayloadCheckedRecords.maybeWitness> in the compiled Lean component.

Checked Lean refinements: result? projects proof-backed record payload fields.

=head2 produce_mark

Calls C<ZeroPayloadCheckedRecords.produceMark> in the compiled Lean component.

Checked Lean refinements: result.marked.witness projects proof-backed record payload fields.

=head2 produce_marker

Calls C<ZeroPayloadCheckedRecords.produceMarker> in the compiled Lean component.

=head2 produce_token

Calls C<ZeroPayloadCheckedRecords.produceToken> in the compiled Lean component.

Checked Lean refinements: result projects proof-backed record payload fields.

=head2 produce_witness

Calls C<ZeroPayloadCheckedRecords.produceWitness> in the compiled Lean component.

Checked Lean refinements: result projects proof-backed record payload fields.

=head2 token_tag

Calls C<ZeroPayloadCheckedRecords.tokenTag> in the compiled Lean component.

Checked Lean refinements: value0 checked by ZeroPayloadCheckedRecords.mkToken.

=head2 witness_count

Calls C<ZeroPayloadCheckedRecords.witnessCount> in the compiled Lean component.

Checked Lean refinements: value0 checked by ZeroPayloadCheckedRecords.mkWitness.

=head2 witnesses

Calls C<ZeroPayloadCheckedRecords.witnesses> in the compiled Lean component.

Checked Lean refinements: result[*] projects proof-backed record payload fields.

=head1 TAGGED VARIANTS

Concrete copied Lean variants use named constructor classes with keyword fields. Construct a case with C<< Signal::Data->new(count => 42, label => 'ready') >> under this component's namespace. The family itself cannot be constructed. Payload accessors keep the original field names. Calls require the exact generated class and field set, reject tied or magical hashes and unknown subclasses, and copy only the active payload. Empty cases and cases carrying undef for Unit stay distinct.

Fields and contained arrays remain mutable. Returned payloads own independent storage. Perl reference equality is not deep value equality, and Perl does not check match exhaustiveness. Input field slots are pinned before conversion can invoke Perl. Scoped cleanup releases partial conversions. The shared per-call copied-value limit is 16 MiB and schema nesting is limited to 32 levels. Generic, indexed, recursive, proof-bearing, callable and identity-bearing payloads remain unsupported.

=over 4

=item C<LeanBridge::ZeroPayloadCheckedRecords::Mark::Blank>

No payload fields.

=item C<LeanBridge::ZeroPayloadCheckedRecords::Mark::Marked>

Required fields: C<witness>.

=back

=head1 COPIED VALUES

Option uses undef for None and Some->new($value) for Some, including Some->new(undef). Unit uses undef. Except uses distinct Ok->new($value) and Err->new($value) objects; ->value returns the payload. Branch classes live under this component's namespace. Prod uses a plain two-element array reference; nested pairs stay nested.

Branches are mutable one-field hashes. Calls check the exact class and field set, reject tied branches and products, and copy their contents. Returned arrays, records and payloads are independent of input values. Perl reference equality is not deep value equality. The shared per-call copied-value limit is 16 MiB; schema nesting is limited to 32 levels. Compound callbacks and resources inside copied values are unsupported.

=head1 ARRAYS AND RECORDS

Lean Array values use plain dense array references. Calls reject blessed, tied and sparse arrays. Copied records use generated classes with named fields and accessors. Record keyword arguments keep Perl's last-value-wins hash semantics, including new(%old_fields, field => $replacement). Constructors reject missing, extra or unnamed fields; calls require the exact generated class and reject tied hashes and subclasses. Empty records and one-field records retain their named types.

Array slots and record fields are pinned before conversion can invoke Perl code. Returned arrays, records, octet strings and Math::BigInt payloads own independent copied storage. Reference equality is not deep value equality. Nested copied values share a 16 MiB conversion budget and a 32-level schema limit; these are not limits on all Perl allocations or Lean working memory. Recursive copied types remain unsupported.

=head1 CHECKED RECORDS

Checked records use generated classes containing only payload fields. Pass L<Math::BigInt> for C<Nat> fields and plain array references for copied arrays. Checked records may occur directly or through arrays, Lists, options, products, Except branches, plain record fields and active variant fields. Every nested Fin bound and Subtype constructor runs before the record constructor at that exact path. A rejection names the failing path and check. A normalizing constructor changes the record received by Lean without changing the caller's record. Results project payload fields after Lean constructs the proofs. No proof object or input constructor is needed for a result-only export. Ordinary and independently reviewed APIs preserve each site's constructor choices. Recursive and generic checked records, dependent forms beyond the recorded closed fields, callbacks and identity-bearing payloads remain unsupported.

=head1 OWNERSHIP

Close resource and closure objects when finished. Host callbacks are synchronous and may not be retained by Lean.

=cut
