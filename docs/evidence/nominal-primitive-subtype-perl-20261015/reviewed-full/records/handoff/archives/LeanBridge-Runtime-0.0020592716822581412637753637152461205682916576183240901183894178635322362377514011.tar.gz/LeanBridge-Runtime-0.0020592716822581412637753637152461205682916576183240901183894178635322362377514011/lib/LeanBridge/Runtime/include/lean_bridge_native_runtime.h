#ifndef LEAN_BRIDGE_NATIVE_RUNTIME_H
#define LEAN_BRIDGE_NATIVE_RUNTIME_H

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define LEAN_BRIDGE_NATIVE_RUNTIME_ABI_VERSION 1u
#define LEAN_BRIDGE_NATIVE_RUNTIME_RETIREMENT_VERSION 1u
#define LEAN_BRIDGE_NATIVE_RUNTIME_PROCESS_GUARD_VERSION 1u

#if defined(_WIN32)
#define LEAN_BRIDGE_NATIVE_API __declspec(dllexport)
#else
#define LEAN_BRIDGE_NATIVE_API __attribute__((visibility("default")))
#endif

typedef void *(*lean_bridge_native_initializer)(uint8_t builtin);

typedef struct lean_bridge_native_snapshot {
  uint32_t abi_version;
  uint32_t runtime_state;
  uint32_t runtime_init_runs;
  uint32_t component_init_runs;
  uint32_t attached_components;
  uint32_t live_identities;
  uint64_t runtime_instance_id;
  uint64_t identity_domain_id;
} lean_bridge_native_snapshot;

LEAN_BRIDGE_NATIVE_API int lean_bridge_native_component_initialize(
    const char *component_id,
    lean_bridge_native_initializer initializer
);
LEAN_BRIDGE_NATIVE_API void lean_bridge_native_component_detach(const char *component_id);
/* Lock-free: reject an inherited runtime before entering a post-fork mutex. */
LEAN_BRIDGE_NATIVE_API int lean_bridge_native_process_valid(void);
/* Retirement is permanent. Existing owners may still release their values. */
LEAN_BRIDGE_NATIVE_API int lean_bridge_native_component_ready(const char *component_id);
LEAN_BRIDGE_NATIVE_API void lean_bridge_native_runtime_retire(void);
LEAN_BRIDGE_NATIVE_API uint64_t lean_bridge_native_identity_acquire(const char *kind, const void *pointer);
LEAN_BRIDGE_NATIVE_API int lean_bridge_native_identity_release(uint64_t token, const char *kind, const void *pointer);
LEAN_BRIDGE_NATIVE_API int lean_bridge_native_identity_release_pointer(const char *kind, const void *pointer);
LEAN_BRIDGE_NATIVE_API void lean_bridge_native_snapshot_read(lean_bridge_native_snapshot *out);


typedef struct lb_native_callback { void (*invoke)(void); void *context; } lb_native_callback;
uint64_t lb_native_callback_register(void (*invoke)(void), void *context);
void lb_native_callback_release(uint64_t token);
lb_native_callback lb_native_callback_lookup(uint64_t token);
int lb_native_callback_wrong_thread(uint64_t token);
int lb_native_callback_take_error(void);

#ifdef __cplusplus
}
#endif

#endif
