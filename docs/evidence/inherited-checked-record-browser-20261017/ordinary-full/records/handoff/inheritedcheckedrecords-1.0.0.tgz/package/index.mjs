// Generated from Binding IR SHA-256 00c89fd429ee5484eed64fb0bdcae3a44bda860d704e48e45f04fe7b0ba0f80f.
import { runtime } from "./internal/runtime.mjs";
import * as validate from "./internal/validators.mjs";

/**
 * Call InheritedCheckedRecords.aliased.
 */
export function aliased(arg0) {
  validate.assertTicketAlias(arg0, "aliased.arg0");
  const result = runtime.call("lean:InheritedCheckedRecords.aliased", [arg0]);
  validate.assertNat(result, "aliased.result");
  return result;
}

/**
 * Call InheritedCheckedRecords.echo.
 */
export function echo(arg0) {
  validate.assertTicket(arg0, "echo.arg0");
  const result = runtime.call("lean:InheritedCheckedRecords.echo", [arg0]);
  validate.assertTicket(result, "echo.result");
  return result;
}

/**
 * Call InheritedCheckedRecords.first.
 */
export function first(arg0) {
  validate.assertTicket(arg0, "first.arg0");
  const result = runtime.call("lean:InheritedCheckedRecords.first", [arg0]);
  validate.assertNat(result, "first.result");
  return result;
}

/**
 * Call InheritedCheckedRecords.nested.
 */
export function nested(arg0) {
  validate.assertStamped(arg0, "nested.arg0");
  const result = runtime.call("lean:InheritedCheckedRecords.nested", [arg0]);
  validate.assertNat(result, "nested.result");
  return result;
}

/**
 * Call InheritedCheckedRecords.normalized.
 */
export function normalized(arg0) {
  validate.assertTicket(arg0, "normalized.arg0");
  const result = runtime.call("lean:InheritedCheckedRecords.normalized", [arg0]);
  validate.assertNat(result, "normalized.result");
  return result;
}

/**
 * Call InheritedCheckedRecords.pair.
 */
export function pair(arg0, arg1) {
  validate.assertTicket(arg0, "pair.arg0");
  validate.assertTicket(arg1, "pair.arg1");
  const result = runtime.call("lean:InheritedCheckedRecords.pair", [arg0, arg1]);
  validate.assertNat(result, "pair.result");
  return result;
}

/**
 * Lean produces every erased proof on results; no host constructor is selected. 
 */
export function produce(arg0) {
  validate.assertNat(arg0, "produce.arg0");
  const result = runtime.call("lean:InheritedCheckedRecords.produce", [arg0]);
  validate.assertTicket(result, "produce.result");
  return result;
}

/**
 * Call InheritedCheckedRecords.produceStamped.
 */
export function produceStamped(arg0) {
  validate.assertNat(arg0, "produceStamped.arg0");
  const result = runtime.call("lean:InheritedCheckedRecords.produceStamped", [arg0]);
  validate.assertStamped(result, "produceStamped.result");
  return result;
}

export default Object.freeze({ aliased, echo, first, nested, normalized, pair, produce, produceStamped });
