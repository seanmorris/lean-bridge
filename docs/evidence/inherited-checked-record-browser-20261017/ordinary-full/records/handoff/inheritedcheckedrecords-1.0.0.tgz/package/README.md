# inheritedcheckedrecords

Compiler-checked exports for inheritedcheckedrecords.

Binding IR SHA-256: `00c89fd429ee5484eed64fb0bdcae3a44bda860d704e48e45f04fe7b0ba0f80f`

## Exports

### aliased

Call InheritedCheckedRecords.aliased.

### echo

Call InheritedCheckedRecords.echo.

### first

Call InheritedCheckedRecords.first.

### nested

Call InheritedCheckedRecords.nested.

### normalized

Call InheritedCheckedRecords.normalized.

### pair

Call InheritedCheckedRecords.pair.

### produce

Lean produces every erased proof on results; no host constructor is selected. 

### produceStamped

Call InheritedCheckedRecords.produceStamped.

## Assurance

