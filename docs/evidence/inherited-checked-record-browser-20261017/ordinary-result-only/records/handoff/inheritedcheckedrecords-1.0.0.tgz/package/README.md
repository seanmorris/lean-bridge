# inheritedcheckedrecords

Compiler-checked exports for inheritedcheckedrecords.

Binding IR SHA-256: `115ba99993b15783e14c3828e3c244ca3eb6a435d1e26d34afde36131d9de2f2`

## Exports

### produce

Lean produces every erased proof on results; no host constructor is selected. 

### produceStamped

Call InheritedCheckedRecords.produceStamped.

## Assurance

