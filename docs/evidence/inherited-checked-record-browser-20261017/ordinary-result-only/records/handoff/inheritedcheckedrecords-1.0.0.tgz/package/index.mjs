// Generated from Binding IR SHA-256 115ba99993b15783e14c3828e3c244ca3eb6a435d1e26d34afde36131d9de2f2.
import { runtime } from "./internal/runtime.mjs";
import * as validate from "./internal/validators.mjs";

/**
 * Lean produces every erased proof on results; no host constructor is selected. 
 */
export function produce(arg0) {
  validate.assertNat(arg0, "produce.arg0");
  const result = runtime.call("lean:InheritedCheckedRecords.produce", [arg0]);
  validate.assertTicket(result, "produce.result");
  return result;
}

/**
 * Call InheritedCheckedRecords.produceStamped.
 */
export function produceStamped(arg0) {
  validate.assertNat(arg0, "produceStamped.arg0");
  const result = runtime.call("lean:InheritedCheckedRecords.produceStamped", [arg0]);
  validate.assertStamped(result, "produceStamped.result");
  return result;
}

export default Object.freeze({ produce, produceStamped });
