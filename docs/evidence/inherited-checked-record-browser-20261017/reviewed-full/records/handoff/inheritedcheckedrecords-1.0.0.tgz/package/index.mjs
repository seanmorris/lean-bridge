// Generated from Binding IR SHA-256 6fec0815177f3351ec950aa7a9da15e4084b7f8d417401440c1b2823086484c9.
import { runtime } from "./internal/runtime.mjs";
import * as validate from "./internal/validators.mjs";

/**
 * Independent corpus contract.
 */
export function aliased(value0) {
  validate.assertTicketAlias(value0, "aliased.value0");
  const result = runtime.call("lean:InheritedCheckedRecords.aliased", [value0]);
  validate.assertNat(result, "aliased.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function echo(value0) {
  validate.assertTicket(value0, "echo.value0");
  const result = runtime.call("lean:InheritedCheckedRecords.echo", [value0]);
  validate.assertTicket(result, "echo.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function first(value0) {
  validate.assertTicket(value0, "first.value0");
  const result = runtime.call("lean:InheritedCheckedRecords.first", [value0]);
  validate.assertNat(result, "first.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function nested(value0) {
  validate.assertStamped(value0, "nested.value0");
  const result = runtime.call("lean:InheritedCheckedRecords.nested", [value0]);
  validate.assertNat(result, "nested.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function normalized(value0) {
  validate.assertTicket(value0, "normalized.value0");
  const result = runtime.call("lean:InheritedCheckedRecords.normalized", [value0]);
  validate.assertNat(result, "normalized.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function pair(value0, value1) {
  validate.assertTicket(value0, "pair.value0");
  validate.assertTicket(value1, "pair.value1");
  const result = runtime.call("lean:InheritedCheckedRecords.pair", [value0, value1]);
  validate.assertNat(result, "pair.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function produce(value0) {
  validate.assertNat(value0, "produce.value0");
  const result = runtime.call("lean:InheritedCheckedRecords.produce", [value0]);
  validate.assertTicket(result, "produce.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function produceStamped(value0) {
  validate.assertNat(value0, "produceStamped.value0");
  const result = runtime.call("lean:InheritedCheckedRecords.produceStamped", [value0]);
  validate.assertStamped(result, "produceStamped.result");
  return result;
}

export default Object.freeze({ aliased, echo, first, nested, normalized, pair, produce, produceStamped });
