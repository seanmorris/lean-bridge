# inheritedcheckedrecords

Independent corpus contract.

Binding IR SHA-256: `6fec0815177f3351ec950aa7a9da15e4084b7f8d417401440c1b2823086484c9`

## Exports

### aliased

Independent corpus contract.

### echo

Independent corpus contract.

### first

Independent corpus contract.

### nested

Independent corpus contract.

### normalized

Independent corpus contract.

### pair

Independent corpus contract.

### produce

Independent corpus contract.

### produceStamped

Independent corpus contract.

## Assurance

