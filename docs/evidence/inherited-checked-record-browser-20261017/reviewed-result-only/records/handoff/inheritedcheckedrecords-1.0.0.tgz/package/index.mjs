// Generated from Binding IR SHA-256 d0c701ec7684c8405b57675f53612017d7cf2633cca08eb3b776704ebda1a659.
import { runtime } from "./internal/runtime.mjs";
import * as validate from "./internal/validators.mjs";

/**
 * Independent corpus contract.
 */
export function produce(value0) {
  validate.assertNat(value0, "produce.value0");
  const result = runtime.call("lean:InheritedCheckedRecords.produce", [value0]);
  validate.assertTicket(result, "produce.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function produceStamped(value0) {
  validate.assertNat(value0, "produceStamped.value0");
  const result = runtime.call("lean:InheritedCheckedRecords.produceStamped", [value0]);
  validate.assertStamped(result, "produceStamped.result");
  return result;
}

export default Object.freeze({ produce, produceStamped });
