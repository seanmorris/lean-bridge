# zeropayloadcheckedrecords for PHP-Wasm

Import this package's default descriptor and include it in PHP-Wasm's `sharedLibs` array. npm installs the matching Lean runtime dependency. The descriptor registers that runtime once per PHP host and mounts the generated PHP files.

```js
import { PhpNode } from 'php-wasm/PhpNode';
import api from 'lean-bridge-zeropayloadcheckedrecords-wasm';

const php = new PhpNode({ version: '8.4', sharedLibs: [api] });
await php.run(`<?php require '${api.autoload}';`);
```

Call the generated functions in the `LeanZeropayloadcheckedrecords` PHP namespace. The `compiled/src/Api.php` file contains their typed declarations. Other descriptors can share the same `sharedLibs` list. Conflicting runtime, component and PHP namespace identities are rejected before startup.

For a Composer application, install the companion `lean-bridge-zeropayloadcheckedrecords/wasm:1.0.0` ZIP, mount your application's `vendor` directory into PHP-Wasm, and use the named `extensions` export in `sharedLibs` instead of the default descriptor. Require your normal `vendor/autoload.php`. This export registers the native libraries without preloading a second copy of the PHP files.

For first-call loading, import `{ lazy as api }` from this package and pass `dynamicLibs: [api]` instead. With Composer, use `api.extensions` in `dynamicLibs`. The host loads PHP declarations at startup but fetches the Lean runtime and this component only on its first valid API call. An unused component stays unloaded. Different components may choose different modes; registering the same component in both modes is rejected.

This package uses PHP-Wasm 0.1.0, PHP 8.4.1 and the default host variant in Node or Chromium. Register descriptors before constructing the host. Lazy loading requires `enable_dl=1`; await each host request before starting another. After an extension-loading failure, create a new PHP instance. No compiler, FFI extension or install script is required. The handoff receipt verifies package bytes; the descriptor checks compatibility identities, not downloaded byte integrity.

Compound exports use null or Some for Option, Ok or Err for Except, and exact two-element lists for Prod. Some(null) retains a present Unit or an outer Some containing None, according to the declared type. Generated branch classes are final readonly and expose one value property. Calls validate payload types without weak-mode coercion and return independent copies, including nested arrays and records. PHP object identity is not Lean value equality. On wasm32, UInt32, UInt64, Int64, Nat, Int and USize use Brick\Math\BigInteger; ISize uses a 32-bit PHP int. These mappings apply inside compound payloads. Type nesting stops at 32. Validation, Zend conversion and native copying each have a 16 MiB accounting limit, not a bound on Lean working memory. Compound callables, generic or indexed variants and recursive copied types remain unsupported.

Lean List inputs, results and record fields use consecutive-key PHP arrays with `list<T>` PHPDoc. Empty Lists, order, duplicates and nesting are preserved. List and Array retain distinct IR and native identities. Returned mutable values are independent copies. Weak and strict callers receive the same validation and copy-budget checks. List callback payloads remain unsupported.


## Tagged variants

Concrete copied variants use abstract readonly family classes and final readonly constructor classes, such as SignalData extends Signal. Constructors take named or positional payload arguments with the original Lean field names. All payload checks apply in weak and strict PHP callers. Empty constructors and null Unit payloads stay distinct. Calls accept only exact generated constructor classes with their initialized fields; unknown family subclasses and uninitialized reflection-created objects reject. The native tag and union layout are private. Returned tags are checked before reading the active payload.

Accepted payloads include all nineteen primitives, copied arrays, Lists, records, options, results, products and other admitted variants. Returned payloads have independent copied storage. Readonly properties cannot be reassigned; arrays and objects still follow PHP's value and object semantics. PHP === compares object identity, while == compares properties under PHP rules. PHP does not check branch exhaustiveness. The 32-level schema limit and separate 16 MiB validation, PHP conversion and native-copy budgets remain in effect. Generic, indexed, proof-bearing, recursive, callable and identity-bearing payloads remain unsupported.

## Value comparison

Generated records, variant cases, Some/Ok/Err and Bytes expose equals($other) and hashCode(). equals compares nested copied contents without numeric-string or other weak coercion and keeps class/constructor identity distinct. NaNs compare equal and signed zeros differ. hashCode returns a matching 64-character hexadecimal value hash; hashes are not a proof of equality or a versioned serialization format. PHP == and === keep their built-in meanings. Comparisons and hashing have a 32-level nesting bound and a 16 MiB traversal budget. Cycles exceed that depth bound; uninitialized values, foreign objects, resources and non-list arrays reject. Do not mutate referenced payloads while using their hash as a lookup key.

## Bounded integers

Checked records cross as generated record values containing only their payload fields. The bundled native library validates each input through the constructor selected for that exact occurrence before calling the export. Nested arrays, Lists, options, products, Except values, plain records and active variant cases retain their own checked-record constructors. Fin and Subtype payload fields run their checks before the outer record constructor. A rejection names the argument, nested path and failing constructor or bound. A normalizing constructor changes the copied value received by Lean without changing the caller's record. Results recursively project the payload fields and refined base values of records whose proofs Lean has already constructed. No proof object or input constructor is needed for a result-only export. Ordinary and reviewed APIs retain every per-occurrence constructor choice. Recursive, generic, owned and callback checked-record positions remain unsupported.

- LeanZeropayloadcheckedrecords\absent_count: $value0 checked by ZeroPayloadCheckedRecords.mkAbsent
- LeanZeropayloadcheckedrecords\mark_count: $value0.marked.witness checked by ZeroPayloadCheckedRecords.mkWitness
- LeanZeropayloadcheckedrecords\maybe_witness: result? projects proof-backed record payload fields
- LeanZeropayloadcheckedrecords\produce_mark: result.marked.witness projects proof-backed record payload fields
- LeanZeropayloadcheckedrecords\produce_token: result projects proof-backed record payload fields
- LeanZeropayloadcheckedrecords\produce_witness: result projects proof-backed record payload fields
- LeanZeropayloadcheckedrecords\token_tag: $value0 checked by ZeroPayloadCheckedRecords.mkToken
- LeanZeropayloadcheckedrecords\witness_count: $value0 checked by ZeroPayloadCheckedRecords.mkWitness
- LeanZeropayloadcheckedrecords\witnesses: result[*] projects proof-backed record payload fields
