// Generated from Binding IR SHA-256 a9e9d79548c24350f615c35af8261d44a4cde8bc545964eb4cd4f16a08c55b00.
import { runtime } from "./internal/runtime.mjs";

/** Result-only: Lean produces an owned checked record from a resource.  */
export function claimFor(arg0) {
  return runtime.call("lean:OwnedCheckedRecords.claimFor", Array.from(arguments));
}

/** Call OwnedCheckedRecords.newTicket. */
export function newTicket(arg0, arg1) {
  return runtime.call("lean:OwnedCheckedRecords.newTicket", Array.from(arguments));
}

/** Call OwnedCheckedRecords.serial. */
export function serial(arg0) {
  return runtime.call("lean:OwnedCheckedRecords.serial", Array.from(arguments));
}

export function close() { return runtime.close(); }
export function withRecovery(operation, recovery) { return runtime.withRecovery(operation, recovery); }
export default Object.freeze({ claimFor, newTicket, serial, close, withRecovery });
