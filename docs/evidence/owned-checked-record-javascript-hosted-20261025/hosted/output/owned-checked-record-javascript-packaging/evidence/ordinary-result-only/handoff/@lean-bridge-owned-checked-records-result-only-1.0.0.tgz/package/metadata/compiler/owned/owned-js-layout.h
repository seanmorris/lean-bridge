#pragma once
#include "owned-values.h"
_Static_assert(sizeof(void *) == 4 && sizeof(size_t) == 4, "Owned JavaScript requires wasm32");
#ifndef __wasm32__
#error "Owned JavaScript requires the wasm32 target"
#endif
_Static_assert(sizeof(lbov_a9e9d79548c24350f615_t160ce821a84f6887bbfd) == 8, "Owned JavaScript size: 0");
_Static_assert(_Alignof(lbov_a9e9d79548c24350f615_t160ce821a84f6887bbfd) == 4, "Owned JavaScript alignment: 0");
_Static_assert(offsetof(lbov_a9e9d79548c24350f615_t160ce821a84f6887bbfd, tag) == 0, "Owned JavaScript field: 0.tag");
_Static_assert(sizeof(((lbov_a9e9d79548c24350f615_t160ce821a84f6887bbfd *)0)->tag) == 1, "Owned JavaScript member size: 0.tag");
_Static_assert(offsetof(lbov_a9e9d79548c24350f615_t160ce821a84f6887bbfd, f0) == 4, "Owned JavaScript field: 0.f0");
_Static_assert(sizeof(((lbov_a9e9d79548c24350f615_t160ce821a84f6887bbfd *)0)->f0) == 4, "Owned JavaScript member size: 0.f0");
_Static_assert(sizeof(lbov_a9e9d79548c24350f615_tb2825946e038e653bd2b) == 16, "Owned JavaScript size: 1");
_Static_assert(_Alignof(lbov_a9e9d79548c24350f615_tb2825946e038e653bd2b) == 8, "Owned JavaScript alignment: 1");
_Static_assert(offsetof(lbov_a9e9d79548c24350f615_tb2825946e038e653bd2b, f0) == 0, "Owned JavaScript field: 1.f0");
_Static_assert(sizeof(((lbov_a9e9d79548c24350f615_tb2825946e038e653bd2b *)0)->f0) == 8, "Owned JavaScript member size: 1.f0");
_Static_assert(offsetof(lbov_a9e9d79548c24350f615_tb2825946e038e653bd2b, f1) == 8, "Owned JavaScript field: 1.f1");
_Static_assert(sizeof(((lbov_a9e9d79548c24350f615_tb2825946e038e653bd2b *)0)->f1) == 8, "Owned JavaScript member size: 1.f1");
_Static_assert(sizeof(lbov_a9e9d79548c24350f615_td79b9bbde250ee1779da) == 8, "Owned JavaScript size: 2");
_Static_assert(_Alignof(lbov_a9e9d79548c24350f615_td79b9bbde250ee1779da) == 8, "Owned JavaScript alignment: 2");
_Static_assert(offsetof(lbov_a9e9d79548c24350f615_td79b9bbde250ee1779da, token) == 0, "Owned JavaScript field: 2.token");
_Static_assert(sizeof(((lbov_a9e9d79548c24350f615_td79b9bbde250ee1779da *)0)->token) == 8, "Owned JavaScript member size: 2.token");
_Static_assert(sizeof(lbov_a9e9d79548c24350f615_t167081552b6f9c1d1afd) == 8, "Owned JavaScript size: 3");
_Static_assert(_Alignof(lbov_a9e9d79548c24350f615_t167081552b6f9c1d1afd) == 4, "Owned JavaScript alignment: 3");
_Static_assert(offsetof(lbov_a9e9d79548c24350f615_t167081552b6f9c1d1afd, data) == 0, "Owned JavaScript field: 3.data");
_Static_assert(sizeof(((lbov_a9e9d79548c24350f615_t167081552b6f9c1d1afd *)0)->data) == 4, "Owned JavaScript member size: 3.data");
_Static_assert(offsetof(lbov_a9e9d79548c24350f615_t167081552b6f9c1d1afd, length) == 4, "Owned JavaScript field: 3.length");
_Static_assert(sizeof(((lbov_a9e9d79548c24350f615_t167081552b6f9c1d1afd *)0)->length) == 4, "Owned JavaScript member size: 3.length");
_Static_assert(sizeof(lbov_a9e9d79548c24350f615_tdc0347e1f7f5c4d928f1) == 8, "Owned JavaScript size: 4");
_Static_assert(_Alignof(lbov_a9e9d79548c24350f615_tdc0347e1f7f5c4d928f1) == 4, "Owned JavaScript alignment: 4");
_Static_assert(offsetof(lbov_a9e9d79548c24350f615_tdc0347e1f7f5c4d928f1, data) == 0, "Owned JavaScript field: 4.data");
_Static_assert(sizeof(((lbov_a9e9d79548c24350f615_tdc0347e1f7f5c4d928f1 *)0)->data) == 4, "Owned JavaScript member size: 4.data");
_Static_assert(offsetof(lbov_a9e9d79548c24350f615_tdc0347e1f7f5c4d928f1, length) == 4, "Owned JavaScript field: 4.length");
_Static_assert(sizeof(((lbov_a9e9d79548c24350f615_tdc0347e1f7f5c4d928f1 *)0)->length) == 4, "Owned JavaScript member size: 4.length");
