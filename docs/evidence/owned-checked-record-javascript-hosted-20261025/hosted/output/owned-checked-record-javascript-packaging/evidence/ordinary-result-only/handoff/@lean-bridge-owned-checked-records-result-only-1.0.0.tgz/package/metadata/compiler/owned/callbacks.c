#include "component.h"
#include "lean_bridge_native_runtime.h"
static _Thread_local int lean_bridge_owned_callback_failure_a9e9d79548c24350f615_state;
int lean_bridge_owned_callback_failure_a9e9d79548c24350f615(void) { int result = lean_bridge_owned_callback_failure_a9e9d79548c24350f615_state; lean_bridge_owned_callback_failure_a9e9d79548c24350f615_state = 0; return result; }
