#pragma once
#include <lean/lean.h>
#include <stdint.h>
/* Private typed helpers consume their Array arguments and return an owned Array. */
uint8_t lean_bridge_owned_refine_5ba8ebacbf26c0755e45(lean_object *);
uint8_t lean_bridge_owned_refine_ca177b2570793a278657(lean_object *);
uint32_t lean_bridge_owned_c6e809d222fddb027dfda13e_t160ce821a84f6887bbfd_branch(lean_object *);
lean_object * lean_bridge_owned_c6e809d222fddb027dfda13e_t160ce821a84f6887bbfd_none(lean_object *);
lean_object * lean_bridge_owned_c6e809d222fddb027dfda13e_t160ce821a84f6887bbfd_make0(lean_object *);
lean_object * lean_bridge_owned_c6e809d222fddb027dfda13e_t160ce821a84f6887bbfd_field0(lean_object *);
lean_object * lean_bridge_owned_c6e809d222fddb027dfda13e_t648974cffb2d6c1d7951_apply(lean_object *, lean_object *);
lean_object * lean_bridge_owned_c6e809d222fddb027dfda13e_t5035e6ea0903f12776d9_apply(lean_object *, lean_object *);
lean_object * lean_bridge_owned_c6e809d222fddb027dfda13e_t23107461f72b24c37654_make(lean_object *, lean_object *);
lean_object * lean_bridge_owned_c6e809d222fddb027dfda13e_t23107461f72b24c37654_field0(lean_object *);
lean_object * lean_bridge_owned_c6e809d222fddb027dfda13e_t23107461f72b24c37654_field1(lean_object *);
lean_object * lean_bridge_owned_c6e809d222fddb027dfda13e_tb2825946e038e653bd2b_make(lean_object *, lean_object *);
lean_object * lean_bridge_owned_c6e809d222fddb027dfda13e_tb2825946e038e653bd2b_field0(lean_object *);
lean_object * lean_bridge_owned_c6e809d222fddb027dfda13e_tb2825946e038e653bd2b_field1(lean_object *);
lean_object * lean_bridge_owned_c6e809d222fddb027dfda13e_t2a091437b2d587ce3891_make(lean_object *, lean_object *);
lean_object * lean_bridge_owned_c6e809d222fddb027dfda13e_t2a091437b2d587ce3891_field0(lean_object *);
lean_object * lean_bridge_owned_c6e809d222fddb027dfda13e_t2a091437b2d587ce3891_field1(lean_object *);
lean_object * lean_bridge_owned_c6e809d222fddb027dfda13e_fa3218a29f42862f9b113(lean_object *);
lean_object * lean_bridge_owned_c6e809d222fddb027dfda13e_f483485736ace9af57086(lean_object *);
lean_object * lean_bridge_owned_c6e809d222fddb027dfda13e_f0711e856cfa97d876c9a(lean_object *);
lean_object * lean_bridge_owned_c6e809d222fddb027dfda13e_f535babcfd8d0f67ea0e6(lean_object *);
lean_object * lean_bridge_owned_c6e809d222fddb027dfda13e_fa1e5189bd92568e4b939(lean_object *, lean_object *);
lean_object * lean_bridge_owned_c6e809d222fddb027dfda13e_feaac3cc8d9197bd7bbca(lean_object *, lean_object *);
lean_object * lean_bridge_owned_c6e809d222fddb027dfda13e_fec926afda994fba3abe2(lean_object *);
lean_object * lean_bridge_owned_c6e809d222fddb027dfda13e_f040aca3025d850fc12cc(lean_object *);
lean_object * lean_bridge_owned_c6e809d222fddb027dfda13e_f7d6c8617a0788c12de15(lean_object *, lean_object *);
int lean_bridge_owned_callback_failure_a70b07b980c43460ffc6(void);
lean_object *lean_bridge_owned_c6e809d222fddb027dfda13e_t648974cffb2d6c1d7951_wrap(size_t, size_t, lean_object *);
lean_object *lean_bridge_owned_c6e809d222fddb027dfda13e_t648974cffb2d6c1d7951_invoke(size_t, lean_object *);
lean_object *lean_bridge_owned_c6e809d222fddb027dfda13e_t5035e6ea0903f12776d9_wrap(size_t, size_t, lean_object *);
lean_object *lean_bridge_owned_c6e809d222fddb027dfda13e_t5035e6ea0903f12776d9_invoke(size_t, lean_object *);
lean_object *lean_bridge_owned_c6e809d222fddb027dfda13e_t5035e6ea0903f12776d9_reject(size_t, lean_object *);

LEAN_CASSERT(sizeof(void *) == 4 && sizeof(size_t) == 4);
