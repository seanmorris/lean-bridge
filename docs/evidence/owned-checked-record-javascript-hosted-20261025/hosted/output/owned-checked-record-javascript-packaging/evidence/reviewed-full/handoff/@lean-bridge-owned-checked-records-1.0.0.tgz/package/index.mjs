// Generated from Binding IR SHA-256 a70b07b980c43460ffc6ff59adf7db667f460e554b8e7d7263269b3d9808fcbf.
import { runtime } from "./internal/runtime.mjs";

/** Independent corpus contract. */
export function claimClosure() {
  return runtime.call("lean:OwnedCheckedRecords.claimClosure", Array.from(arguments));
}

/** Independent corpus contract. */
export function claimFor(arg0) {
  return runtime.call("lean:OwnedCheckedRecords.claimFor", Array.from(arguments));
}

/** Independent corpus contract. */
export function echoBooking(arg0) {
  return runtime.call("lean:OwnedCheckedRecords.echoBooking", Array.from(arguments));
}

/** Independent corpus contract. */
export function echoClaim(arg0) {
  return runtime.call("lean:OwnedCheckedRecords.echoClaim", Array.from(arguments));
}

/** Independent corpus contract. */
export function newTicket(arg0, arg1) {
  return runtime.call("lean:OwnedCheckedRecords.newTicket", Array.from(arguments));
}

/** Independent corpus contract. */
export function pairClaim(arg0, arg1) {
  return runtime.call("lean:OwnedCheckedRecords.pairClaim", Array.from(arguments));
}

/** Independent corpus contract. */
export function serial(arg0) {
  return runtime.call("lean:OwnedCheckedRecords.serial", Array.from(arguments));
}

/** Independent corpus contract. */
export function transferClaim(arg0) {
  return runtime.call("lean:OwnedCheckedRecords.transferClaim", Array.from(arguments));
}

/** Independent corpus contract. */
export function withClaimCallback(arg0, arg1) {
  return runtime.call("lean:OwnedCheckedRecords.withClaimCallback", Array.from(arguments));
}

export function close() { return runtime.close(); }
export function withRecovery(operation, recovery) { return runtime.withRecovery(operation, recovery); }
export default Object.freeze({ claimClosure, claimFor, echoBooking, echoClaim, newTicket, pairClaim, serial, transferClaim, withClaimCallback, close, withRecovery });
