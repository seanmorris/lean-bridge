# owned-checked-records

Compiler-checked exports for owned-checked-records.

Call the named exports with JavaScript values. The package loads its shared runtime automatically.
Records use source field names. Variants use kind and named payload fields. Arrays and lists use arrays.
Options use { tag: "none" } or { tag: "some", value }. Results use { ok } or { error }.
Nat, Int, UInt64 and Int64 use bigint. Unit uses undefined; bytes use Uint8Array.

## Resource lifetime

Resource values and returned functions expose dispose(), retain() and disposed. Dispose each distinct lease when finished.
retain() creates an independent lease. Repeated references within a result share one wrapper.
Callback arguments expire when the callback returns. Retain a resource inside the callback to keep it.
close() releases the component and invalidates its outstanding leases. It does not close other packages.
A native trap retires the shared heap; all packages using that heap reject further calls.

## Consuming arguments

Arguments declared transfer consume the whole shared result owner, including aliases and sibling handles.
Validation failures leave inputs usable. Handoff invalidates inputs before Lean runs; they stay consumed if the call or a callback later fails.
Call retain() first to keep an independent lease. Borrowed callback arguments must be retained before transfer.
A result owner may appear repeatedly in one consuming argument, but cannot supply two consuming arguments or concurrent reentrant transfers.
Consuming function arguments require returned Lean function leases, not ordinary JavaScript callbacks.
- transferClaim: consumes arg0.

## Callbacks and types

Pass ordinary synchronous functions for borrowed callback arguments. Return a value of the declared result type.
For a callback whose result has no default value, use withRecovery(callback, recoveryValue). The original thrown error reaches the caller.
The TypeScript declarations distinguish host inputs from native results. Input types accept ordinary callbacks; returned functions include explicit lifetime methods.
Conversions reject cycles, invalid fields, invalid tags and out-of-range values. Limits: 128 levels, 262144 visits, 16 MiB and 4096 retained references per call.

## Exports

- claimClosure: A leased Lean closure consumes host claims and returns proved claims. 
- claimFor: Result-only: Lean produces an owned checked record from a resource. 
- echoBooking: Shape A both ways: the input window runs mkWindow, the result projects it. 
- echoClaim: Shape B both ways: the input claim runs mkClaim after the ticket is borrowed. 
- newTicket: Call OwnedCheckedRecords.newTicket.
- pairClaim: The second constructor can reject after the first owned argument converted. 
- serial: Call OwnedCheckedRecords.serial.
- transferClaim: Transfer: the claim moves into Lean and comes back as a new lease. 
- withClaimCallback: A host callback receives a proved claim and must return another proved claim. 
