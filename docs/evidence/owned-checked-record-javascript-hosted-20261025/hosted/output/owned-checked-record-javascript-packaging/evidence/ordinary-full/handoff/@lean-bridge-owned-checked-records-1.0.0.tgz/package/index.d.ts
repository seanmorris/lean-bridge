declare const leanResource: unique symbol;

export interface LeanLease {
  readonly disposed: boolean;
  dispose(): boolean;
  retain(): this;
}

/** Checked Lean callback. */
export interface Callback26621c40b48fce52ca37 {
  (arg0: Claim): ClaimInput;
}

export interface Callback26621c40b48fce52ca37Lease extends LeanLease {
  (arg0: ClaimInput): Claim;
}

/** Checked Lean callback. */
export interface Callbackb2d3d6fd4e031785f278 {
  (arg0: Claim): ClaimInput;
}

export interface Callbackb2d3d6fd4e031785f278Lease extends LeanLease {
  (arg0: ClaimInput): Claim;
}

/** Checked Lean OwnedCheckedRecords.Booking. */
export interface BookingInput {
  readonly "holder": Ticket;
  readonly "window": WindowInput;
}

export interface Booking {
  readonly "holder": Ticket;
  readonly "window": Window;
}

/** Checked Lean OwnedCheckedRecords.Claim. */
export interface ClaimInput {
  readonly "holder": Ticket;
  readonly "quota": bigint;
}

export interface Claim {
  readonly "holder": Ticket;
  readonly "quota": bigint;
}

/** Checked Lean OwnedCheckedRecords.Ticket. */
export interface Ticket extends LeanLease {
  readonly [leanResource]: "lean:OwnedCheckedRecords.Ticket";
}

/** Checked Lean OwnedCheckedRecords.Window. */
export interface WindowInput {
  readonly "lo": bigint;
  readonly "hi": bigint;
}

export interface Window {
  readonly "lo": bigint;
  readonly "hi": bigint;
}

/** A leased Lean closure consumes host claims and returns proved claims.  */
export function claimClosure(): Callback26621c40b48fce52ca37Lease;

/** Result-only: Lean produces an owned checked record from a resource.  */
export function claimFor(arg0: Ticket): (Readonly<{ tag: "none" }> | Readonly<{ tag: "some"; value: Claim }>);

/** Shape A both ways: the input window runs mkWindow, the result projects it.  */
export function echoBooking(arg0: BookingInput): Booking;

/** Shape B both ways: the input claim runs mkClaim after the ticket is borrowed.  */
export function echoClaim(arg0: ClaimInput): Claim;

/** Call OwnedCheckedRecords.newTicket. */
export function newTicket(arg0: bigint, arg1: string): Ticket;

/** The second constructor can reject after the first owned argument converted.  */
export function pairClaim(arg0: BookingInput, arg1: ClaimInput): Claim;

/** Call OwnedCheckedRecords.serial. */
export function serial(arg0: Ticket): bigint;

/** Transfer: the claim moves into Lean and comes back as a new lease.  */
export function transferClaim(arg0: Claim): Claim;

/** A host callback receives a proved claim and must return another proved claim.  */
export function withClaimCallback(arg0: ClaimInput, arg1: Callbackb2d3d6fd4e031785f278): Claim;

/** Release this component and invalidate its outstanding leases. */
export function close(): boolean;
/** Supply the typed fallback required by an uninhabited callback result. */
export function withRecovery<Args extends readonly unknown[], Result>(operation: (...args: Args) => Result, recovery: Result): (...args: Args) => Result;

declare const bindings: Readonly<{
  claimClosure: typeof claimClosure;
  claimFor: typeof claimFor;
  echoBooking: typeof echoBooking;
  echoClaim: typeof echoClaim;
  newTicket: typeof newTicket;
  pairClaim: typeof pairClaim;
  serial: typeof serial;
  transferClaim: typeof transferClaim;
  withClaimCallback: typeof withClaimCallback;
  close: typeof close;
  withRecovery: typeof withRecovery;
}>;
export default bindings;
