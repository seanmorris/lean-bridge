#include <lean/lean.h>
#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#ifndef LB_JS_ALLOC_FAIL
#define LB_JS_ALLOC_FAIL() 0
#endif
typedef struct {
  size_t bytes;
  max_align_t alignment;
  unsigned char data[];
} lbjs_component_8a490d0254d8eb2a9c52_allocation;
static size_t lbjs_component_8a490d0254d8eb2a9c52_live_allocations;
static void *lbjs_component_8a490d0254d8eb2a9c52_allocate(size_t bytes) {
  if (bytes > SIZE_MAX - sizeof(lbjs_component_8a490d0254d8eb2a9c52_allocation) || LB_JS_ALLOC_FAIL()) return NULL;
  lbjs_component_8a490d0254d8eb2a9c52_allocation *allocation = calloc(1, sizeof(*allocation) + bytes);
  if (!allocation) return NULL;
  allocation->bytes = bytes; ++lbjs_component_8a490d0254d8eb2a9c52_live_allocations; return allocation->data;
}
static lbjs_component_8a490d0254d8eb2a9c52_allocation *lbjs_component_8a490d0254d8eb2a9c52_allocation_of(const void *value) {
  return (lbjs_component_8a490d0254d8eb2a9c52_allocation *)((unsigned char *)value - offsetof(lbjs_component_8a490d0254d8eb2a9c52_allocation, data));
}
static void lbjs_component_8a490d0254d8eb2a9c52_free(void *value) {
  if (!value) return;
  --lbjs_component_8a490d0254d8eb2a9c52_live_allocations; free(lbjs_component_8a490d0254d8eb2a9c52_allocation_of(value));
}
#define LB_OWNED_ALLOC lbjs_component_8a490d0254d8eb2a9c52_allocate
#define LB_OWNED_FREE lbjs_component_8a490d0254d8eb2a9c52_free
#include "owned-values-codec.h"
#include "owned-js-layout.h"
extern lean_object *initialize_LeanBridgeOwned9c644b84e83d8727(uint8_t);
static lb_owned_context lbjs_component_8a490d0254d8eb2a9c52_context;
typedef struct { ov_result_owner value; unsigned key; unsigned published, consumed, moving; } lbjs_component_8a490d0254d8eb2a9c52_owner;
static lbjs_component_8a490d0254d8eb2a9c52_owner lbjs_component_8a490d0254d8eb2a9c52_owners[4096];
static unsigned lbjs_component_8a490d0254d8eb2a9c52_next_owner, lbjs_component_8a490d0254d8eb2a9c52_closed;

typedef struct { const uint32_t *owners; uint32_t count; } lbjs_component_8a490d0254d8eb2a9c52_input_group;
typedef struct {
  uint32_t version, count;
  const lbjs_component_8a490d0254d8eb2a9c52_input_group *groups;
  uint32_t consumed;
} lbjs_component_8a490d0254d8eb2a9c52_input_frame;
_Static_assert(sizeof(lbjs_component_8a490d0254d8eb2a9c52_input_frame) == 16 && offsetof(lbjs_component_8a490d0254d8eb2a9c52_input_frame, consumed) == 12, "owned JS transfer frame");
_Static_assert(sizeof(lbjs_component_8a490d0254d8eb2a9c52_input_group) == 8, "owned JS transfer group");
typedef struct lbjs_component_8a490d0254d8eb2a9c52_reservation {
  struct lbjs_component_8a490d0254d8eb2a9c52_reservation *next;
  lbjs_component_8a490d0254d8eb2a9c52_owner *slot;
} lbjs_component_8a490d0254d8eb2a9c52_reservation;
typedef struct {
  lbjs_component_8a490d0254d8eb2a9c52_input_frame *frame;
  lbjs_component_8a490d0254d8eb2a9c52_reservation *reserved;
  ov_result_owner *snapshots;
  ov_result_owner **owners;
  size_t count;
} lbjs_component_8a490d0254d8eb2a9c52_moves;
static lbjs_component_8a490d0254d8eb2a9c52_owner *lbjs_component_8a490d0254d8eb2a9c52_slot(unsigned key) {
  if (!key) return NULL;
  for (size_t i = 0; i < 4096; ++i)
    if (lbjs_component_8a490d0254d8eb2a9c52_owners[i].key == key) return &lbjs_component_8a490d0254d8eb2a9c52_owners[i];
  return NULL;
}
static int lbjs_component_8a490d0254d8eb2a9c52_moves_finish(lbjs_component_8a490d0254d8eb2a9c52_moves *moves, int status) {
  if (moves->snapshots) for (size_t i = 0; i < moves->count; ++i) {
    int cleanup = ov_owner_clear(&moves->snapshots[i]); if (!status) status = cleanup;
  }
  while (moves->reserved) {
    lbjs_component_8a490d0254d8eb2a9c52_reservation *entry = moves->reserved; moves->reserved = entry->next;
    entry->slot->moving = 0; LB_OWNED_FREE(entry);
  }
  LB_OWNED_FREE(moves->snapshots); LB_OWNED_FREE(moves->owners);
  *moves = (lbjs_component_8a490d0254d8eb2a9c52_moves){0}; return status;
}
static int lbjs_component_8a490d0254d8eb2a9c52_moves_prepare(lbjs_component_8a490d0254d8eb2a9c52_moves *moves, lbjs_component_8a490d0254d8eb2a9c52_input_frame *frame,
    size_t count, unsigned output) {
  if (!ov_pointer(frame, sizeof(*frame), _Alignof(lbjs_component_8a490d0254d8eb2a9c52_input_frame)) ||
      frame->version != 1 || frame->count != count || frame->consumed ||
      !count || count > LB_OWNED_RETAINED_LIMIT ||
      !ov_pointer(frame->groups, count * sizeof(*frame->groups), _Alignof(lbjs_component_8a490d0254d8eb2a9c52_input_group)))
    return LB_OWNED_INVALID;
  moves->frame = frame; moves->count = count;
  moves->snapshots = LB_OWNED_ALLOC(count * sizeof(*moves->snapshots));
  moves->owners = LB_OWNED_ALLOC(count * sizeof(*moves->owners));
  if (!moves->snapshots || !moves->owners) return LB_OWNED_ALLOC_FAILED;
  memset(moves->snapshots, 0, count * sizeof(*moves->snapshots));
  size_t reserved = 0, retained = 0;
  for (size_t i = 0; i < count; ++i) {
    const lbjs_component_8a490d0254d8eb2a9c52_input_group *group = &frame->groups[i];
    if (group->count > LB_OWNED_RETAINED_LIMIT - reserved ||
        (group->count && !ov_pointer(group->owners, group->count * sizeof(*group->owners), _Alignof(uint32_t))))
      return LB_OWNED_INVALID;
    reserved += group->count; moves->owners[i] = &moves->snapshots[i];
    ov_transaction snapshot = {0};
    int status = ov_begin(&snapshot, &lbjs_component_8a490d0254d8eb2a9c52_context, moves->owners[i], "owned-checked-records@1.0.0");
    if (status) return status;
    for (size_t j = 0; j < group->count && !status; ++j) {
      lbjs_component_8a490d0254d8eb2a9c52_owner *slot = lbjs_component_8a490d0254d8eb2a9c52_slot(group->owners[j]);
      if (!slot || slot->key == output || !slot->published || slot->consumed || slot->moving) {
        status = LB_OWNED_INVALID; break;
      }
      lbjs_component_8a490d0254d8eb2a9c52_reservation *entry = LB_OWNED_ALLOC(sizeof(*entry));
      if (!entry) { status = LB_OWNED_ALLOC_FAILED; break; }
      entry->slot = slot; entry->next = moves->reserved; moves->reserved = entry; slot->moving = 1;
      for (lb_owned_entry *item = slot->value.batch.entries; item && !status; item = item->next) {
        if (retained++ == LB_OWNED_RETAINED_LIMIT) { status = LB_OWNED_LIMIT; break; }
        uint64_t token = 0;
        status = lb_owned_scope_acquire(&snapshot.scope, item->owner->kind, item->owner->value, &token);
        if (!status && token != item->owner->token) status = LB_OWNED_INVALID;
      }
    }
    if (status) return ov_abort(&snapshot, status);
    status = ov_commit(&snapshot, moves->owners[i]);
    if (status) return status;
  }
  return LB_OWNED_OK;
}
static void lbjs_component_8a490d0254d8eb2a9c52_moves_consume(void *context) {
  lbjs_component_8a490d0254d8eb2a9c52_moves *moves = context;
  for (lbjs_component_8a490d0254d8eb2a9c52_reservation *entry = moves->reserved; entry; entry = entry->next)
    entry->slot->consumed = 1;
  moves->frame->consumed = 1;
}
static ov_result_owner *lbjs_component_8a490d0254d8eb2a9c52_find(unsigned key) {
  if (!key) return NULL;
  for (size_t i = 0; i < 4096; ++i)
    if (lbjs_component_8a490d0254d8eb2a9c52_owners[i].key == key) return &lbjs_component_8a490d0254d8eb2a9c52_owners[i].value;
  return NULL;
}
unsigned lbjs_component_8a490d0254d8eb2a9c52_open(void) {
  if (lb_owned_ready(&lbjs_component_8a490d0254d8eb2a9c52_context) || lbjs_component_8a490d0254d8eb2a9c52_next_owner == UINT32_MAX) return 0;
  for (size_t i = 0; i < 4096; ++i) if (!lbjs_component_8a490d0254d8eb2a9c52_owners[i].key) {
    lbjs_component_8a490d0254d8eb2a9c52_owners[i].key = ++lbjs_component_8a490d0254d8eb2a9c52_next_owner; return lbjs_component_8a490d0254d8eb2a9c52_next_owner;
  }
  return 0;
}
int lbjs_component_8a490d0254d8eb2a9c52_valid(unsigned key) { return lbjs_component_8a490d0254d8eb2a9c52_find(key) != NULL; }
int lbjs_component_8a490d0254d8eb2a9c52_release(unsigned key) {
  ov_result_owner *owner = lbjs_component_8a490d0254d8eb2a9c52_find(key); if (!owner) return LB_OWNED_INVALID;
  if (lbjs_component_8a490d0254d8eb2a9c52_slot(key)->moving) return LB_OWNED_ORDER;
  int status = ov_owner_clear(owner);
  if (!status) for (size_t i = 0; i < 4096; ++i)
    if (lbjs_component_8a490d0254d8eb2a9c52_owners[i].key == key) { lbjs_component_8a490d0254d8eb2a9c52_owners[i] = (lbjs_component_8a490d0254d8eb2a9c52_owner){0}; break; }
  return status;
}
#include <emscripten.h>
typedef struct { unsigned host, type; uint64_t token; } lbjs_8a490d0254d8eb2a9c52_host;
static lbjs_8a490d0254d8eb2a9c52_host lbjs_8a490d0254d8eb2a9c52_hosts[4096];
typedef struct lbjs_8a490d0254d8eb2a9c52_frame { struct lbjs_8a490d0254d8eb2a9c52_frame *parent; unsigned key, host, type, owner; const uintptr_t *args; void *reply; } lbjs_8a490d0254d8eb2a9c52_frame;
static lbjs_8a490d0254d8eb2a9c52_frame *lbjs_8a490d0254d8eb2a9c52_active; static unsigned lbjs_8a490d0254d8eb2a9c52_next;
EM_JS(int, lbjs_8a490d0254d8eb2a9c52_dispatch_js, (unsigned key, unsigned host, unsigned type, unsigned owner, const uintptr_t *args, void *reply), {
  return Module["leanBridgeOwnedCallbacks_8a490d0254d8eb2a9c5207c6c42b7e3923f3cc2754c5845ea56999462196d118"].dispatch(key, host, type, owner, args, reply);
});
EM_JS(int, lbjs_8a490d0254d8eb2a9c52_finish_js, (unsigned key), { return Module["leanBridgeOwnedCallbacks_8a490d0254d8eb2a9c5207c6c42b7e3923f3cc2754c5845ea56999462196d118"].finish(key); });
int lbjs_8a490d0254d8eb2a9c52_valid(unsigned key, unsigned host, unsigned type, unsigned owner, const uintptr_t *args, void *reply) {
  lbjs_8a490d0254d8eb2a9c52_frame *frame = lbjs_8a490d0254d8eb2a9c52_active;
  return frame && frame->key == key && frame->host == host && frame->type == type
    && frame->owner == owner && frame->args == args && frame->reply == reply;
}
int lbjs_8a490d0254d8eb2a9c52_end(unsigned host) {
  for (size_t i = 0; i < 4096; ++i) if (lbjs_8a490d0254d8eb2a9c52_hosts[i].host == host && host) {
    lb_native_callback_release(lbjs_8a490d0254d8eb2a9c52_hosts[i].token); lbjs_8a490d0254d8eb2a9c52_hosts[i] = (lbjs_8a490d0254d8eb2a9c52_host){0}; return 0;
  }
  return LB_OWNED_INVALID;
}
unsigned lbjs_8a490d0254d8eb2a9c52_live(void) { unsigned count = 0; for (unsigned i = 0; i < 4096; ++i) if (lbjs_8a490d0254d8eb2a9c52_hosts[i].host) ++count; return count; }
static lean_object *lbjs_8a490d0254d8eb2a9c52_v1_invoke(void *opaque, lean_object *a0) {
  lbjs_8a490d0254d8eb2a9c52_host *host = opaque; ov_callback_frame *parent = ov_active_callback_frame;
  int status = !parent || parent->transaction->scope.context != &lbjs_component_8a490d0254d8eb2a9c52_context ? OV_CALLBACK : parent->status;
  ov_transaction arguments = {0}; lean_object *returned = NULL; unsigned owner_key = 0;
  lbov_8a490d0254d8eb2a9c52_tb2825946e038e653bd2b reply = {0};
  lbov_8a490d0254d8eb2a9c52_tb2825946e038e653bd2b value0 = {0};
  uintptr_t pointers[1] = {(uintptr_t)&value0};
  if (!status) { owner_key = lbjs_component_8a490d0254d8eb2a9c52_open(); if (!owner_key) status = LB_OWNED_LIMIT; }
  if (!status) status = ov_begin(&arguments, &lbjs_component_8a490d0254d8eb2a9c52_context, lbjs_component_8a490d0254d8eb2a9c52_find(owner_key), "owned-checked-records@1.0.0");
  if (!status) arguments.budget = parent->transaction->budget;
  if (!status) { status = lbov_8a490d0254d8eb2a9c52_vb2825946e038e653bd2b_out(&value0, a0, 0, &arguments); a0 = NULL; }
  if (arguments.scope.context) parent->transaction->budget = arguments.budget;
  if (!status) status = ov_commit(&arguments, lbjs_component_8a490d0254d8eb2a9c52_find(owner_key));
  else if (arguments.scope.context) status = ov_abort(&arguments, status);
  if (!status && lbjs_8a490d0254d8eb2a9c52_next == UINT32_MAX) status = LB_OWNED_LIMIT;
  if (!status) {
    lbjs_8a490d0254d8eb2a9c52_frame frame = { .parent = lbjs_8a490d0254d8eb2a9c52_active, .key = ++lbjs_8a490d0254d8eb2a9c52_next, .host = host->host, .type = host->type, .owner = owner_key, .args = pointers, .reply = &reply };
    lbjs_8a490d0254d8eb2a9c52_active = &frame;
    if (lbjs_8a490d0254d8eb2a9c52_dispatch_js(frame.key, host->host, host->type, owner_key, pointers, &reply)) status = OV_CALLBACK;
    if (!status) status = lb_owned_scope_ready(&parent->transaction->scope);
    if (!status) status = lbov_8a490d0254d8eb2a9c52_vb2825946e038e653bd2b_in(&reply, 0, 1, parent->transaction, &returned);
    int finished = lbjs_8a490d0254d8eb2a9c52_finish_js(frame.key); if (!status && finished) status = OV_CALLBACK;
    lbjs_8a490d0254d8eb2a9c52_active = frame.parent;
  }
  if (owner_key) { int cleanup = lbjs_component_8a490d0254d8eb2a9c52_release(owner_key); if (!status) status = cleanup; }
  if (a0) lean_dec(a0);
  if (status) { ov_callback_fail(parent, status); if (returned) lean_dec(returned); return lean_alloc_array(0, 0); }
  return returned;
}
static int lbjs_8a490d0254d8eb2a9c52_v1_begin(lbjs_8a490d0254d8eb2a9c52_host *host, const void *fallback, void *out, ov_result_owner *owner) {
  if (!ov_pointer(out, sizeof(lbov_8a490d0254d8eb2a9c52_t648974cffb2d6c1d7951), _Alignof(lbov_8a490d0254d8eb2a9c52_t648974cffb2d6c1d7951))) return LB_OWNED_INVALID;
  if (!fallback) return LB_OWNED_INVALID;
  host->token = lb_native_callback_register((void (*)(void))lbjs_8a490d0254d8eb2a9c52_v1_invoke, host);
  if (!host->token) return LB_OWNED_LIMIT;
  if (host->token > UINTPTR_MAX) { lb_native_callback_release(host->token); host->token = 0; return LB_OWNED_LIMIT; }
  ov_transaction transaction = {0}; lean_object *recovery = NULL;
  int status = ov_begin(&transaction, &lbjs_component_8a490d0254d8eb2a9c52_context, owner, "owned-checked-records@1.0.0");
  if (!status && fallback) status = lbov_8a490d0254d8eb2a9c52_vb2825946e038e653bd2b_in(fallback, 0, 1, &transaction, &recovery);
  if (!status) {
    if (!recovery) recovery = lean_alloc_array(0, 0);
    lean_object *closure = lean_bridge_owned_25595653b57f19bce095c0d8_t648974cffb2d6c1d7951_wrap((size_t)host->token, fallback ? 1 : 0, recovery);
    if (!ov_carrier(closure)) { lean_dec(closure); status = LB_OWNED_INVALID; }
    else status = lbov_8a490d0254d8eb2a9c52_v648974cffb2d6c1d7951_out(out, closure, 0, &transaction);
  }
  if (!status) status = ov_commit(&transaction, owner);
  else if (transaction.scope.context) status = ov_abort(&transaction, status);
  if (status) { lb_native_callback_release(host->token); host->token = 0; }
  return status;
}
static lean_object *lbjs_8a490d0254d8eb2a9c52_v2_invoke(void *opaque, lean_object *a0) {
  lbjs_8a490d0254d8eb2a9c52_host *host = opaque; ov_callback_frame *parent = ov_active_callback_frame;
  int status = !parent || parent->transaction->scope.context != &lbjs_component_8a490d0254d8eb2a9c52_context ? OV_CALLBACK : parent->status;
  ov_transaction arguments = {0}; lean_object *returned = NULL; unsigned owner_key = 0;
  lbov_8a490d0254d8eb2a9c52_tb2825946e038e653bd2b reply = {0};
  lbov_8a490d0254d8eb2a9c52_tb2825946e038e653bd2b value0 = {0};
  uintptr_t pointers[1] = {(uintptr_t)&value0};
  if (!status) { owner_key = lbjs_component_8a490d0254d8eb2a9c52_open(); if (!owner_key) status = LB_OWNED_LIMIT; }
  if (!status) status = ov_begin(&arguments, &lbjs_component_8a490d0254d8eb2a9c52_context, lbjs_component_8a490d0254d8eb2a9c52_find(owner_key), "owned-checked-records@1.0.0");
  if (!status) arguments.budget = parent->transaction->budget;
  if (!status) { status = lbov_8a490d0254d8eb2a9c52_vb2825946e038e653bd2b_out(&value0, a0, 0, &arguments); a0 = NULL; }
  if (arguments.scope.context) parent->transaction->budget = arguments.budget;
  if (!status) status = ov_commit(&arguments, lbjs_component_8a490d0254d8eb2a9c52_find(owner_key));
  else if (arguments.scope.context) status = ov_abort(&arguments, status);
  if (!status && lbjs_8a490d0254d8eb2a9c52_next == UINT32_MAX) status = LB_OWNED_LIMIT;
  if (!status) {
    lbjs_8a490d0254d8eb2a9c52_frame frame = { .parent = lbjs_8a490d0254d8eb2a9c52_active, .key = ++lbjs_8a490d0254d8eb2a9c52_next, .host = host->host, .type = host->type, .owner = owner_key, .args = pointers, .reply = &reply };
    lbjs_8a490d0254d8eb2a9c52_active = &frame;
    if (lbjs_8a490d0254d8eb2a9c52_dispatch_js(frame.key, host->host, host->type, owner_key, pointers, &reply)) status = OV_CALLBACK;
    if (!status) status = lb_owned_scope_ready(&parent->transaction->scope);
    if (!status) status = lbov_8a490d0254d8eb2a9c52_vb2825946e038e653bd2b_in(&reply, 0, 1, parent->transaction, &returned);
    int finished = lbjs_8a490d0254d8eb2a9c52_finish_js(frame.key); if (!status && finished) status = OV_CALLBACK;
    lbjs_8a490d0254d8eb2a9c52_active = frame.parent;
  }
  if (owner_key) { int cleanup = lbjs_component_8a490d0254d8eb2a9c52_release(owner_key); if (!status) status = cleanup; }
  if (a0) lean_dec(a0);
  if (status) { ov_callback_fail(parent, status); if (returned) lean_dec(returned); return lean_alloc_array(0, 0); }
  return returned;
}
static int lbjs_8a490d0254d8eb2a9c52_v2_begin(lbjs_8a490d0254d8eb2a9c52_host *host, const void *fallback, void *out, ov_result_owner *owner) {
  if (!ov_pointer(out, sizeof(lbov_8a490d0254d8eb2a9c52_t5035e6ea0903f12776d9), _Alignof(lbov_8a490d0254d8eb2a9c52_t5035e6ea0903f12776d9))) return LB_OWNED_INVALID;
  host->token = lb_native_callback_register((void (*)(void))lbjs_8a490d0254d8eb2a9c52_v2_invoke, host);
  if (!host->token) return LB_OWNED_LIMIT;
  if (host->token > UINTPTR_MAX) { lb_native_callback_release(host->token); host->token = 0; return LB_OWNED_LIMIT; }
  ov_transaction transaction = {0}; lean_object *recovery = NULL;
  int status = ov_begin(&transaction, &lbjs_component_8a490d0254d8eb2a9c52_context, owner, "owned-checked-records@1.0.0");
  if (!status && fallback) status = lbov_8a490d0254d8eb2a9c52_vb2825946e038e653bd2b_in(fallback, 0, 1, &transaction, &recovery);
  if (!status) {
    if (!recovery) recovery = lean_alloc_array(0, 0);
    lean_object *closure = lean_bridge_owned_25595653b57f19bce095c0d8_t5035e6ea0903f12776d9_wrap((size_t)host->token, fallback ? 1 : 0, recovery);
    if (!ov_carrier(closure)) { lean_dec(closure); status = LB_OWNED_INVALID; }
    else status = lbov_8a490d0254d8eb2a9c52_v5035e6ea0903f12776d9_out(out, closure, 0, &transaction);
  }
  if (!status) status = ov_commit(&transaction, owner);
  else if (transaction.scope.context) status = ov_abort(&transaction, status);
  if (status) { lb_native_callback_release(host->token); host->token = 0; }
  return status;
}
int lbjs_8a490d0254d8eb2a9c52_begin(unsigned type, unsigned id, const void *fallback, void *out, unsigned owner_key) {
  ov_result_owner *owner = lbjs_component_8a490d0254d8eb2a9c52_find(owner_key); if (!owner || !id) return LB_OWNED_INVALID;
  lbjs_8a490d0254d8eb2a9c52_host *host = NULL;
  for (size_t i = 0; i < 4096; ++i) { if (lbjs_8a490d0254d8eb2a9c52_hosts[i].host == id) return LB_OWNED_INVALID; if (!host && !lbjs_8a490d0254d8eb2a9c52_hosts[i].host) host = &lbjs_8a490d0254d8eb2a9c52_hosts[i]; }
  if (!host) return LB_OWNED_LIMIT;
  *host = (lbjs_8a490d0254d8eb2a9c52_host){ .host = id, .type = type };
  int status; switch (type) {
  case 1: status = lbjs_8a490d0254d8eb2a9c52_v1_begin(host, fallback, out, owner); break;
  case 2: status = lbjs_8a490d0254d8eb2a9c52_v2_begin(host, fallback, out, owner); break;
  default: status = LB_OWNED_INVALID;
  }
  if (status) *host = (lbjs_8a490d0254d8eb2a9c52_host){0};
  return status;
}

int lbjs_component_8a490d0254d8eb2a9c52_init(void) {
  if (lbjs_component_8a490d0254d8eb2a9c52_closed) return LB_OWNED_CLOSED;
  if (lbjs_component_8a490d0254d8eb2a9c52_context.initialized) return lb_owned_ready(&lbjs_component_8a490d0254d8eb2a9c52_context);
  if (!lean_bridge_native_component_initialize("owned-checked-records@1.0.0",
      (lean_bridge_native_initializer)initialize_LeanBridgeOwned9c644b84e83d8727)) return LB_OWNED_RUNTIME;
  return lb_owned_context_init(&lbjs_component_8a490d0254d8eb2a9c52_context, "owned-checked-records@1.0.0");
}
int lbjs_component_8a490d0254d8eb2a9c52_dispatch(unsigned index, const uintptr_t *args, void *out, unsigned key, lbjs_component_8a490d0254d8eb2a9c52_input_frame *inputs) {
  ov_result_owner *owner = lbjs_component_8a490d0254d8eb2a9c52_find(key); if (!owner) return LB_OWNED_INVALID;
  if (lbjs_component_8a490d0254d8eb2a9c52_slot(key)->published || lbjs_component_8a490d0254d8eb2a9c52_slot(key)->consumed || lbjs_component_8a490d0254d8eb2a9c52_slot(key)->moving) return LB_OWNED_INVALID;
  switch (index) {
  case 0: {
    if (!ov_pointer(out, sizeof(lbov_8a490d0254d8eb2a9c52_t648974cffb2d6c1d7951), _Alignof(lbov_8a490d0254d8eb2a9c52_t648974cffb2d6c1d7951)) || inputs != NULL) return LB_OWNED_INVALID;
    int status = lbov_8a490d0254d8eb2a9c52_fa3218a29f42862f9b113(&lbjs_component_8a490d0254d8eb2a9c52_context, (lbov_8a490d0254d8eb2a9c52_t648974cffb2d6c1d7951 *)out, owner);
    if (!status) lbjs_component_8a490d0254d8eb2a9c52_slot(key)->published = 1;
    return status;
  }
  case 1: {
    if (!ov_pointer(out, sizeof(lbov_8a490d0254d8eb2a9c52_t160ce821a84f6887bbfd), _Alignof(lbov_8a490d0254d8eb2a9c52_t160ce821a84f6887bbfd)) || !ov_pointer(args, 1 * sizeof(*args), _Alignof(uintptr_t)) || inputs != NULL) return LB_OWNED_INVALID;
    int status = lbov_8a490d0254d8eb2a9c52_f483485736ace9af57086(&lbjs_component_8a490d0254d8eb2a9c52_context, (const lbov_8a490d0254d8eb2a9c52_td79b9bbde250ee1779da *)args[0], (lbov_8a490d0254d8eb2a9c52_t160ce821a84f6887bbfd *)out, owner);
    if (!status) lbjs_component_8a490d0254d8eb2a9c52_slot(key)->published = 1;
    return status;
  }
  case 2: {
    if (!ov_pointer(out, sizeof(lbov_8a490d0254d8eb2a9c52_t23107461f72b24c37654), _Alignof(lbov_8a490d0254d8eb2a9c52_t23107461f72b24c37654)) || !ov_pointer(args, 1 * sizeof(*args), _Alignof(uintptr_t)) || inputs != NULL) return LB_OWNED_INVALID;
    int status = lbov_8a490d0254d8eb2a9c52_f0711e856cfa97d876c9a(&lbjs_component_8a490d0254d8eb2a9c52_context, (const lbov_8a490d0254d8eb2a9c52_t23107461f72b24c37654 *)args[0], (lbov_8a490d0254d8eb2a9c52_t23107461f72b24c37654 *)out, owner);
    if (!status) lbjs_component_8a490d0254d8eb2a9c52_slot(key)->published = 1;
    return status;
  }
  case 3: {
    if (!ov_pointer(out, sizeof(lbov_8a490d0254d8eb2a9c52_tb2825946e038e653bd2b), _Alignof(lbov_8a490d0254d8eb2a9c52_tb2825946e038e653bd2b)) || !ov_pointer(args, 1 * sizeof(*args), _Alignof(uintptr_t)) || inputs != NULL) return LB_OWNED_INVALID;
    int status = lbov_8a490d0254d8eb2a9c52_f535babcfd8d0f67ea0e6(&lbjs_component_8a490d0254d8eb2a9c52_context, (const lbov_8a490d0254d8eb2a9c52_tb2825946e038e653bd2b *)args[0], (lbov_8a490d0254d8eb2a9c52_tb2825946e038e653bd2b *)out, owner);
    if (!status) lbjs_component_8a490d0254d8eb2a9c52_slot(key)->published = 1;
    return status;
  }
  case 4: {
    if (!ov_pointer(out, sizeof(lbov_8a490d0254d8eb2a9c52_td79b9bbde250ee1779da), _Alignof(lbov_8a490d0254d8eb2a9c52_td79b9bbde250ee1779da)) || !ov_pointer(args, 2 * sizeof(*args), _Alignof(uintptr_t)) || inputs != NULL) return LB_OWNED_INVALID;
    int status = lbov_8a490d0254d8eb2a9c52_fa1e5189bd92568e4b939(&lbjs_component_8a490d0254d8eb2a9c52_context, (const lbov_8a490d0254d8eb2a9c52_t167081552b6f9c1d1afd *)args[0], (const lbov_8a490d0254d8eb2a9c52_tdc0347e1f7f5c4d928f1 *)args[1], (lbov_8a490d0254d8eb2a9c52_td79b9bbde250ee1779da *)out, owner);
    if (!status) lbjs_component_8a490d0254d8eb2a9c52_slot(key)->published = 1;
    return status;
  }
  case 5: {
    if (!ov_pointer(out, sizeof(lbov_8a490d0254d8eb2a9c52_tb2825946e038e653bd2b), _Alignof(lbov_8a490d0254d8eb2a9c52_tb2825946e038e653bd2b)) || !ov_pointer(args, 2 * sizeof(*args), _Alignof(uintptr_t)) || inputs != NULL) return LB_OWNED_INVALID;
    int status = lbov_8a490d0254d8eb2a9c52_feaac3cc8d9197bd7bbca(&lbjs_component_8a490d0254d8eb2a9c52_context, (const lbov_8a490d0254d8eb2a9c52_t23107461f72b24c37654 *)args[0], (const lbov_8a490d0254d8eb2a9c52_tb2825946e038e653bd2b *)args[1], (lbov_8a490d0254d8eb2a9c52_tb2825946e038e653bd2b *)out, owner);
    if (!status) lbjs_component_8a490d0254d8eb2a9c52_slot(key)->published = 1;
    return status;
  }
  case 6: {
    if (!ov_pointer(out, sizeof(lbov_8a490d0254d8eb2a9c52_t167081552b6f9c1d1afd), _Alignof(lbov_8a490d0254d8eb2a9c52_t167081552b6f9c1d1afd)) || !ov_pointer(args, 1 * sizeof(*args), _Alignof(uintptr_t)) || inputs != NULL) return LB_OWNED_INVALID;
    int status = lbov_8a490d0254d8eb2a9c52_fec926afda994fba3abe2(&lbjs_component_8a490d0254d8eb2a9c52_context, (const lbov_8a490d0254d8eb2a9c52_td79b9bbde250ee1779da *)args[0], (lbov_8a490d0254d8eb2a9c52_t167081552b6f9c1d1afd *)out, owner);
    if (!status) lbjs_component_8a490d0254d8eb2a9c52_slot(key)->published = 1;
    return status;
  }
  case 7: {
    if (!ov_pointer(out, sizeof(lbov_8a490d0254d8eb2a9c52_tb2825946e038e653bd2b), _Alignof(lbov_8a490d0254d8eb2a9c52_tb2825946e038e653bd2b)) || !ov_pointer(args, 1 * sizeof(*args), _Alignof(uintptr_t))) return LB_OWNED_INVALID;
    lbjs_component_8a490d0254d8eb2a9c52_moves moves = {0};
    int status = lbjs_component_8a490d0254d8eb2a9c52_moves_prepare(&moves, inputs, 1, key);
    ov_input_transfers transfer = { .owners = moves.owners, .count = 1, .consume = lbjs_component_8a490d0254d8eb2a9c52_moves_consume, .context = &moves };
    if (!status) status = lbov_8a490d0254d8eb2a9c52_f040aca3025d850fc12cc(&lbjs_component_8a490d0254d8eb2a9c52_context, (const lbov_8a490d0254d8eb2a9c52_tb2825946e038e653bd2b *)args[0], &transfer, (lbov_8a490d0254d8eb2a9c52_tb2825946e038e653bd2b *)out, owner);
    status = lbjs_component_8a490d0254d8eb2a9c52_moves_finish(&moves, status);
    if (!status) lbjs_component_8a490d0254d8eb2a9c52_slot(key)->published = 1;
    return status;
  }
  case 8: {
    if (!ov_pointer(out, sizeof(lbov_8a490d0254d8eb2a9c52_tb2825946e038e653bd2b), _Alignof(lbov_8a490d0254d8eb2a9c52_tb2825946e038e653bd2b)) || !ov_pointer(args, 2 * sizeof(*args), _Alignof(uintptr_t)) || inputs != NULL) return LB_OWNED_INVALID;
    int status = lbov_8a490d0254d8eb2a9c52_f7d6c8617a0788c12de15(&lbjs_component_8a490d0254d8eb2a9c52_context, (const lbov_8a490d0254d8eb2a9c52_tb2825946e038e653bd2b *)args[0], (const lbov_8a490d0254d8eb2a9c52_t5035e6ea0903f12776d9 *)args[1], (lbov_8a490d0254d8eb2a9c52_tb2825946e038e653bd2b *)out, owner);
    if (!status) lbjs_component_8a490d0254d8eb2a9c52_slot(key)->published = 1;
    return status;
  }
  case 9: {
    if (!ov_pointer(out, sizeof(lbov_8a490d0254d8eb2a9c52_tb2825946e038e653bd2b), _Alignof(lbov_8a490d0254d8eb2a9c52_tb2825946e038e653bd2b)) || !ov_pointer(args, 2 * sizeof(*args), _Alignof(uintptr_t)) || inputs != NULL) return LB_OWNED_INVALID;
    int status = lbov_8a490d0254d8eb2a9c52_v648974cffb2d6c1d7951_apply(&lbjs_component_8a490d0254d8eb2a9c52_context, (const lbov_8a490d0254d8eb2a9c52_t648974cffb2d6c1d7951 *)args[0], (const lbov_8a490d0254d8eb2a9c52_tb2825946e038e653bd2b *)args[1], (lbov_8a490d0254d8eb2a9c52_tb2825946e038e653bd2b *)out, owner);
    if (!status) lbjs_component_8a490d0254d8eb2a9c52_slot(key)->published = 1;
    return status;
  }
  case 10: {
    if (!ov_pointer(out, sizeof(lbov_8a490d0254d8eb2a9c52_tb2825946e038e653bd2b), _Alignof(lbov_8a490d0254d8eb2a9c52_tb2825946e038e653bd2b)) || !ov_pointer(args, 2 * sizeof(*args), _Alignof(uintptr_t)) || inputs != NULL) return LB_OWNED_INVALID;
    int status = lbov_8a490d0254d8eb2a9c52_v5035e6ea0903f12776d9_apply(&lbjs_component_8a490d0254d8eb2a9c52_context, (const lbov_8a490d0254d8eb2a9c52_t5035e6ea0903f12776d9 *)args[0], (const lbov_8a490d0254d8eb2a9c52_tb2825946e038e653bd2b *)args[1], (lbov_8a490d0254d8eb2a9c52_tb2825946e038e653bd2b *)out, owner);
    if (!status) lbjs_component_8a490d0254d8eb2a9c52_slot(key)->published = 1;
    return status;
  }
  default: return LB_OWNED_INVALID;
  }
}
int lbjs_component_8a490d0254d8eb2a9c52_claim(unsigned key, const void *pointer, size_t bytes) {
  ov_result_owner *owner = lbjs_component_8a490d0254d8eb2a9c52_find(key); if (!owner) return 0;
  for (ov_allocation *allocation = owner->allocations; allocation; allocation = allocation->next) {
    if (allocation->data != pointer) continue;
    size_t actual = lbjs_component_8a490d0254d8eb2a9c52_allocation_of(allocation)->bytes;
    return actual >= sizeof(*allocation) && actual - sizeof(*allocation) == bytes;
  }
  return 0;
}
int lbjs_component_8a490d0254d8eb2a9c52_identity(unsigned key, unsigned type, uint64_t token) {
  ov_result_owner *owner = lbjs_component_8a490d0254d8eb2a9c52_find(key); if (!owner) return 0;
  const char *kind;
  switch (type) {
  case 1: kind = "callable:owned-checked-records@1.0.0:bridge:Callback26621c40b48fce52ca37"; break;
  case 2: kind = "callable:owned-checked-records@1.0.0:bridge:Callbackb2d3d6fd4e031785f278"; break;
  case 5: kind = "resource:OwnedCheckedRecords.Ticket"; break;
  default: return 0;
  }
  for (lb_owned_entry *entry = owner->batch.entries; entry; entry = entry->next)
    if (entry->owner->token == token && !strcmp(entry->owner->kind, kind)) return 1;
  return 0;
}
int lbjs_component_8a490d0254d8eb2a9c52_retain(unsigned type, uint64_t token, void *out, unsigned key) {
  ov_result_owner *owner = lbjs_component_8a490d0254d8eb2a9c52_find(key); if (!owner) return LB_OWNED_INVALID;
  if (lbjs_component_8a490d0254d8eb2a9c52_slot(key)->published || lbjs_component_8a490d0254d8eb2a9c52_slot(key)->consumed || lbjs_component_8a490d0254d8eb2a9c52_slot(key)->moving) return LB_OWNED_INVALID;
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, &lbjs_component_8a490d0254d8eb2a9c52_context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  lean_object *value = NULL;
  switch (type) {
  case 1: {
    lbov_8a490d0254d8eb2a9c52_t648974cffb2d6c1d7951 input = { .token = token };
    if (!ov_pointer(out, sizeof(input), _Alignof(lbov_8a490d0254d8eb2a9c52_t648974cffb2d6c1d7951))) { status = LB_OWNED_INVALID; break; }
    status = lbov_8a490d0254d8eb2a9c52_v648974cffb2d6c1d7951_in(&input, 0, 1, &transaction, &value);
    if (!status) status = lbov_8a490d0254d8eb2a9c52_v648974cffb2d6c1d7951_out(out, value, 0, &transaction);
    break;
  }
  case 2: {
    lbov_8a490d0254d8eb2a9c52_t5035e6ea0903f12776d9 input = { .token = token };
    if (!ov_pointer(out, sizeof(input), _Alignof(lbov_8a490d0254d8eb2a9c52_t5035e6ea0903f12776d9))) { status = LB_OWNED_INVALID; break; }
    status = lbov_8a490d0254d8eb2a9c52_v5035e6ea0903f12776d9_in(&input, 0, 1, &transaction, &value);
    if (!status) status = lbov_8a490d0254d8eb2a9c52_v5035e6ea0903f12776d9_out(out, value, 0, &transaction);
    break;
  }
  case 5: {
    lbov_8a490d0254d8eb2a9c52_td79b9bbde250ee1779da input = { .token = token };
    if (!ov_pointer(out, sizeof(input), _Alignof(lbov_8a490d0254d8eb2a9c52_td79b9bbde250ee1779da))) { status = LB_OWNED_INVALID; break; }
    status = lbov_8a490d0254d8eb2a9c52_vd79b9bbde250ee1779da_in(&input, 0, 1, &transaction, &value);
    if (!status) status = lbov_8a490d0254d8eb2a9c52_vd79b9bbde250ee1779da_out(out, value, 0, &transaction);
    break;
  }
  default: status = LB_OWNED_INVALID;
  }
  status = status ? ov_abort(&transaction, status) : ov_commit(&transaction, owner);
  if (!status) lbjs_component_8a490d0254d8eb2a9c52_slot(key)->published = 1;
  return status;
}
int lbjs_component_8a490d0254d8eb2a9c52_close(void) {
  if (lbjs_component_8a490d0254d8eb2a9c52_closed) return LB_OWNED_OK;
  int status = lb_owned_affinity(&lbjs_component_8a490d0254d8eb2a9c52_context);
  if (status) return status;
  if (lbjs_component_8a490d0254d8eb2a9c52_context.top || lbjs_8a490d0254d8eb2a9c52_live()) return LB_OWNED_ORDER;
  for (size_t i = 0; i < 4096; ++i) if (lbjs_component_8a490d0254d8eb2a9c52_owners[i].key) {
    status = lbjs_component_8a490d0254d8eb2a9c52_release(lbjs_component_8a490d0254d8eb2a9c52_owners[i].key); if (status) return status;
  }
  status = lb_owned_context_close(&lbjs_component_8a490d0254d8eb2a9c52_context);
  if (!status) { lbjs_component_8a490d0254d8eb2a9c52_closed = 1; lean_bridge_native_component_detach("owned-checked-records@1.0.0"); }
  return status;
}
unsigned lbjs_component_8a490d0254d8eb2a9c52_live(void) { return lbjs_component_8a490d0254d8eb2a9c52_live_allocations; }
unsigned lbjs_component_8a490d0254d8eb2a9c52_results(void) {
  unsigned count = 0;
  for (size_t i = 0; i < 4096; ++i) if (lbjs_component_8a490d0254d8eb2a9c52_owners[i].key) ++count;
  return count;
}
typedef struct {
  uint32_t version, bytes, status, operation;
  uint32_t arguments[8];
  uint64_t token;
  uint32_t value, reserved;
} lbjs_component_8a490d0254d8eb2a9c52_control_frame;
_Static_assert(sizeof(lbjs_component_8a490d0254d8eb2a9c52_control_frame) == 64, "owned JS control size");
_Static_assert(_Alignof(lbjs_component_8a490d0254d8eb2a9c52_control_frame) == 8, "owned JS control alignment");
_Static_assert(offsetof(lbjs_component_8a490d0254d8eb2a9c52_control_frame, status) == 8, "owned JS trampoline status");
_Static_assert(offsetof(lbjs_component_8a490d0254d8eb2a9c52_control_frame, token) == 48, "owned JS control token");
_Static_assert(offsetof(lbjs_component_8a490d0254d8eb2a9c52_control_frame, value) == 56, "owned JS control result");
static const uint32_t lbjs_component_8a490d0254d8eb2a9c52_metadata[8] = {
  UINT32_C(0x1c481a96), UINT32_C(0x1c0abd32), UINT32_C(0xce250933), UINT32_C(0x788d7b0d), UINT32_C(0x20b310c3), UINT32_C(0x934fcc56), UINT32_C(0x112b7b70), UINT32_C(0xba2bd17d)
};
unsigned lbjs_component_8a490d0254d8eb2a9c52_control(lbjs_component_8a490d0254d8eb2a9c52_control_frame *frame) {
  if (!ov_pointer(frame, sizeof(*frame), _Alignof(lbjs_component_8a490d0254d8eb2a9c52_control_frame))) return LB_OWNED_INVALID;
  if (frame->version != 1 || frame->bytes != sizeof(*frame) || frame->status
      || frame->value || frame->reserved) return frame->status = LB_OWNED_INVALID;
  const uint32_t *a = frame->arguments; int status = 0;
  switch (frame->operation) {
  case 0: status = lbjs_component_8a490d0254d8eb2a9c52_init(); break;
  case 1: frame->value = lbjs_component_8a490d0254d8eb2a9c52_open(); break;
  case 2: frame->value = lbjs_component_8a490d0254d8eb2a9c52_valid(a[0]); break;
  case 3: status = lbjs_component_8a490d0254d8eb2a9c52_release(a[0]); break;
  case 4: frame->value = lbjs_component_8a490d0254d8eb2a9c52_claim(a[0], (const void *)a[1], a[2]); break;
  case 5: frame->value = lbjs_component_8a490d0254d8eb2a9c52_identity(a[0], a[1], frame->token); break;
  case 6: status = lbjs_component_8a490d0254d8eb2a9c52_dispatch(a[0], (const uintptr_t *)a[1], (void *)a[2], a[3], (lbjs_component_8a490d0254d8eb2a9c52_input_frame *)a[4]); break;
  case 7: status = lbjs_component_8a490d0254d8eb2a9c52_retain(a[0], frame->token, (void *)a[1], a[2]); break;
  case 8: status = lbjs_component_8a490d0254d8eb2a9c52_close(); break;
  case 9: frame->value = lbjs_component_8a490d0254d8eb2a9c52_live(); break;
  case 10: frame->value = lbjs_component_8a490d0254d8eb2a9c52_results(); break;
  case 15:
    if (a[0] >= 8) status = LB_OWNED_INVALID;
    else frame->value = lbjs_component_8a490d0254d8eb2a9c52_metadata[a[0]];
    break;
  case 11: status = lbjs_8a490d0254d8eb2a9c52_begin(a[0], a[1], (const void *)a[2], (void *)a[3], a[4]); break;
  case 12: status = lbjs_8a490d0254d8eb2a9c52_end(a[0]); break;
  case 13: frame->value = lbjs_8a490d0254d8eb2a9c52_valid(a[0], a[1], a[2], a[3], (const uintptr_t *)a[4], (void *)a[5]); break;
  case 14: frame->value = lbjs_8a490d0254d8eb2a9c52_live(); break;
  default: status = LB_OWNED_INVALID;
  }
  return frame->status = (uint32_t)status;
}
