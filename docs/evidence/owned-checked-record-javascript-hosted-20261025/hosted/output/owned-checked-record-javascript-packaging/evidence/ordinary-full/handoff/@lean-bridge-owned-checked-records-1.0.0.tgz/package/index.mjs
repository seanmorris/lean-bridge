// Generated from Binding IR SHA-256 8a490d0254d8eb2a9c5207c6c42b7e3923f3cc2754c5845ea56999462196d118.
import { runtime } from "./internal/runtime.mjs";

/** A leased Lean closure consumes host claims and returns proved claims.  */
export function claimClosure() {
  return runtime.call("lean:OwnedCheckedRecords.claimClosure", Array.from(arguments));
}

/** Result-only: Lean produces an owned checked record from a resource.  */
export function claimFor(arg0) {
  return runtime.call("lean:OwnedCheckedRecords.claimFor", Array.from(arguments));
}

/** Shape A both ways: the input window runs mkWindow, the result projects it.  */
export function echoBooking(arg0) {
  return runtime.call("lean:OwnedCheckedRecords.echoBooking", Array.from(arguments));
}

/** Shape B both ways: the input claim runs mkClaim after the ticket is borrowed.  */
export function echoClaim(arg0) {
  return runtime.call("lean:OwnedCheckedRecords.echoClaim", Array.from(arguments));
}

/** Call OwnedCheckedRecords.newTicket. */
export function newTicket(arg0, arg1) {
  return runtime.call("lean:OwnedCheckedRecords.newTicket", Array.from(arguments));
}

/** The second constructor can reject after the first owned argument converted.  */
export function pairClaim(arg0, arg1) {
  return runtime.call("lean:OwnedCheckedRecords.pairClaim", Array.from(arguments));
}

/** Call OwnedCheckedRecords.serial. */
export function serial(arg0) {
  return runtime.call("lean:OwnedCheckedRecords.serial", Array.from(arguments));
}

/** Transfer: the claim moves into Lean and comes back as a new lease.  */
export function transferClaim(arg0) {
  return runtime.call("lean:OwnedCheckedRecords.transferClaim", Array.from(arguments));
}

/** A host callback receives a proved claim and must return another proved claim.  */
export function withClaimCallback(arg0, arg1) {
  return runtime.call("lean:OwnedCheckedRecords.withClaimCallback", Array.from(arguments));
}

export function close() { return runtime.close(); }
export function withRecovery(operation, recovery) { return runtime.withRecovery(operation, recovery); }
export default Object.freeze({ claimClosure, claimFor, echoBooking, echoClaim, newTicket, pairClaim, serial, transferClaim, withClaimCallback, close, withRecovery });
