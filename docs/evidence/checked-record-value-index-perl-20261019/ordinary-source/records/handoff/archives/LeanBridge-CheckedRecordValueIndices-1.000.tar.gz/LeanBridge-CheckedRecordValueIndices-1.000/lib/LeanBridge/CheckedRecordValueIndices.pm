package LeanBridge::CheckedRecordValueIndices;
use strict;
use warnings;
use Math::BigInt;
use LeanBridge::Runtime;
die "Incompatible shared Lean runtime package version\n" unless $LeanBridge::Runtime::VERSION eq '0.0020130180835253351074425099676719723942806298898514237203907626409680523998624031';
use XSLoader;
our $VERSION = '1.000';
LeanBridge::Runtime::_load_component(__FILE__, 'libcomponent_767c615eabad08d77709.so', '39941bbf2ec5f61793b17581a6f4e1e79725ec63f2fd2a6d5a5cbfa7274ae1e6', '6f4dbd1e2e112f4678734553d1c9bb8722fad3e6290adbff1ac46d05e5eff7dd', { 'CheckedRecordValueIndices' => 'ccc330676f03ae5e101315010ed6fad4f4902b8f4d3c10228d5223006273a054' }, 'checkedrecordvalueindices@1.0.0');
XSLoader::load(__PACKAGE__, $VERSION);
sub true () { !!1 }
sub false () { !!0 }
sub CLONE_SKIP { 1 }

package LeanBridge::CheckedRecordValueIndices::Ab;
sub new {
  die "LeanBridge::CheckedRecordValueIndices::Ab->new expects named fields\n" unless @_ % 2 == 1 && $_[0] eq 'LeanBridge::CheckedRecordValueIndices::Ab';
  shift; my %fields;
  while (@_) {
    my ($key, $value) = splice @_, 0, 2;
    die "invalid record field\n" if !defined($key) || ref($key);
    $fields{$key} = $value;
  }
  my @required = qw(size);
  die "record fields do not match the generated schema\n" if keys(%fields) != @required || grep { !exists $fields{$_} } @required;
  return bless \%fields, 'LeanBridge::CheckedRecordValueIndices::Ab';
}
sub size { $_[0]->{size} }
package LeanBridge::CheckedRecordValueIndices::EmptySized;
sub new {
  die "LeanBridge::CheckedRecordValueIndices::EmptySized->new expects named fields\n" unless @_ % 2 == 1 && $_[0] eq 'LeanBridge::CheckedRecordValueIndices::EmptySized';
  shift; my %fields;
  while (@_) {
    my ($key, $value) = splice @_, 0, 2;
    die "invalid record field\n" if !defined($key) || ref($key);
    $fields{$key} = $value;
  }
  my @required = qw(data);
  die "record fields do not match the generated schema\n" if keys(%fields) != @required || grep { !exists $fields{$_} } @required;
  return bless \%fields, 'LeanBridge::CheckedRecordValueIndices::EmptySized';
}
sub data { $_[0]->{data} }
package LeanBridge::CheckedRecordValueIndices::EmptyToken;
sub new {
  die "LeanBridge::CheckedRecordValueIndices::EmptyToken->new expects named fields\n" unless @_ % 2 == 1 && $_[0] eq 'LeanBridge::CheckedRecordValueIndices::EmptyToken';
  shift; my %fields;
  while (@_) {
    my ($key, $value) = splice @_, 0, 2;
    die "invalid record field\n" if !defined($key) || ref($key);
    $fields{$key} = $value;
  }
  my @required = qw(count);
  die "record fields do not match the generated schema\n" if keys(%fields) != @required || grep { !exists $fields{$_} } @required;
  return bless \%fields, 'LeanBridge::CheckedRecordValueIndices::EmptyToken';
}
sub count { $_[0]->{count} }
package LeanBridge::CheckedRecordValueIndices::Off;
sub new {
  die "LeanBridge::CheckedRecordValueIndices::Off->new expects named fields\n" unless @_ % 2 == 1 && $_[0] eq 'LeanBridge::CheckedRecordValueIndices::Off';
  shift; my %fields;
  while (@_) {
    my ($key, $value) = splice @_, 0, 2;
    die "invalid record field\n" if !defined($key) || ref($key);
    $fields{$key} = $value;
  }
  my @required = qw(count);
  die "record fields do not match the generated schema\n" if keys(%fields) != @required || grep { !exists $fields{$_} } @required;
  return bless \%fields, 'LeanBridge::CheckedRecordValueIndices::Off';
}
sub count { $_[0]->{count} }
package LeanBridge::CheckedRecordValueIndices::On;
sub new {
  die "LeanBridge::CheckedRecordValueIndices::On->new expects named fields\n" unless @_ % 2 == 1 && $_[0] eq 'LeanBridge::CheckedRecordValueIndices::On';
  shift; my %fields;
  while (@_) {
    my ($key, $value) = splice @_, 0, 2;
    die "invalid record field\n" if !defined($key) || ref($key);
    $fields{$key} = $value;
  }
  my @required = qw(count);
  die "record fields do not match the generated schema\n" if keys(%fields) != @required || grep { !exists $fields{$_} } @required;
  return bless \%fields, 'LeanBridge::CheckedRecordValueIndices::On';
}
sub count { $_[0]->{count} }
package LeanBridge::CheckedRecordValueIndices::UnicodeToken;
sub new {
  die "LeanBridge::CheckedRecordValueIndices::UnicodeToken->new expects named fields\n" unless @_ % 2 == 1 && $_[0] eq 'LeanBridge::CheckedRecordValueIndices::UnicodeToken';
  shift; my %fields;
  while (@_) {
    my ($key, $value) = splice @_, 0, 2;
    die "invalid record field\n" if !defined($key) || ref($key);
    $fields{$key} = $value;
  }
  my @required = qw(count);
  die "record fields do not match the generated schema\n" if keys(%fields) != @required || grep { !exists $fields{$_} } @required;
  return bless \%fields, 'LeanBridge::CheckedRecordValueIndices::UnicodeToken';
}
sub count { $_[0]->{count} }
package LeanBridge::CheckedRecordValueIndices::WideToken;
sub new {
  die "LeanBridge::CheckedRecordValueIndices::WideToken->new expects named fields\n" unless @_ % 2 == 1 && $_[0] eq 'LeanBridge::CheckedRecordValueIndices::WideToken';
  shift; my %fields;
  while (@_) {
    my ($key, $value) = splice @_, 0, 2;
    die "invalid record field\n" if !defined($key) || ref($key);
    $fields{$key} = $value;
  }
  my @required = qw(count);
  die "record fields do not match the generated schema\n" if keys(%fields) != @required || grep { !exists $fields{$_} } @required;
  return bless \%fields, 'LeanBridge::CheckedRecordValueIndices::WideToken';
}
sub count { $_[0]->{count} }
package LeanBridge::CheckedRecordValueIndices::ZeroToken;
sub new {
  die "LeanBridge::CheckedRecordValueIndices::ZeroToken->new expects named fields\n" unless @_ % 2 == 1 && $_[0] eq 'LeanBridge::CheckedRecordValueIndices::ZeroToken';
  shift; my %fields;
  while (@_) {
    my ($key, $value) = splice @_, 0, 2;
    die "invalid record field\n" if !defined($key) || ref($key);
    $fields{$key} = $value;
  }
  my @required = qw(count);
  die "record fields do not match the generated schema\n" if keys(%fields) != @required || grep { !exists $fields{$_} } @required;
  return bless \%fields, 'LeanBridge::CheckedRecordValueIndices::ZeroToken';
}
sub count { $_[0]->{count} }
1;

__END__
=head1 NAME

LeanBridge::CheckedRecordValueIndices - Generated functions from checkedrecordvalueindices

=head1 API

=head2 ab_string_index

Calls C<CheckedRecordValueIndices.abStringIndex> in the compiled Lean component.

Checked Lean refinements: arg0 checked by CheckedRecordValueIndices.mkAb.

=head2 empty_sized_index

Calls C<CheckedRecordValueIndices.emptySizedIndex> in the compiled Lean component.

Checked Lean refinements: arg0 checked by CheckedRecordValueIndices.mkEmptySized.

=head2 empty_string_index

Calls C<CheckedRecordValueIndices.emptyStringIndex> in the compiled Lean component.

Checked Lean refinements: arg0 checked by CheckedRecordValueIndices.mkEmptyToken.

=head2 false_bool_index

Calls C<CheckedRecordValueIndices.falseBoolIndex> in the compiled Lean component.

Checked Lean refinements: arg0 checked by CheckedRecordValueIndices.mkOff.

=head2 produce_ab

Calls C<CheckedRecordValueIndices.produceAb> in the compiled Lean component.

Checked Lean refinements: result projects proof-backed record payload fields.

=head2 produce_empty_sized

Calls C<CheckedRecordValueIndices.produceEmptySized> in the compiled Lean component.

Checked Lean refinements: result projects proof-backed record payload fields.

=head2 produce_empty_string

Calls C<CheckedRecordValueIndices.produceEmptyString> in the compiled Lean component.

Checked Lean refinements: result projects proof-backed record payload fields.

=head2 produce_false_bool

Calls C<CheckedRecordValueIndices.produceFalseBool> in the compiled Lean component.

Checked Lean refinements: result projects proof-backed record payload fields.

=head2 produce_true_bool

Calls C<CheckedRecordValueIndices.produceTrueBool> in the compiled Lean component.

Checked Lean refinements: result projects proof-backed record payload fields.

=head2 produce_unicode_string

Calls C<CheckedRecordValueIndices.produceUnicodeString> in the compiled Lean component.

Checked Lean refinements: result projects proof-backed record payload fields.

=head2 produce_wide_nat

Calls C<CheckedRecordValueIndices.produceWideNat> in the compiled Lean component.

Checked Lean refinements: result projects proof-backed record payload fields.

=head2 produce_zero_nat

Calls C<CheckedRecordValueIndices.produceZeroNat> in the compiled Lean component.

Checked Lean refinements: result projects proof-backed record payload fields.

=head2 true_bool_index

Calls C<CheckedRecordValueIndices.trueBoolIndex> in the compiled Lean component.

Checked Lean refinements: arg0 checked by CheckedRecordValueIndices.mkOn.

=head2 unicode_string_index

Calls C<CheckedRecordValueIndices.unicodeStringIndex> in the compiled Lean component.

Checked Lean refinements: arg0 checked by CheckedRecordValueIndices.mkUnicodeToken.

=head2 wide_nat_index

Calls C<CheckedRecordValueIndices.wideNatIndex> in the compiled Lean component.

Checked Lean refinements: arg0 checked by CheckedRecordValueIndices.mkWideToken.

=head2 zero_nat_index

Calls C<CheckedRecordValueIndices.zeroNatIndex> in the compiled Lean component.

Checked Lean refinements: arg0 checked by CheckedRecordValueIndices.mkZeroToken.

=head1 ARRAYS AND RECORDS

Lean Array values use plain dense array references. Calls reject blessed, tied and sparse arrays. Copied records use generated classes with named fields and accessors. Record keyword arguments keep Perl's last-value-wins hash semantics, including new(%old_fields, field => $replacement). Constructors reject missing, extra or unnamed fields; calls require the exact generated class and reject tied hashes and subclasses. Empty records and one-field records retain their named types.

Array slots and record fields are pinned before conversion can invoke Perl code. Returned arrays, records, octet strings and Math::BigInt payloads own independent copied storage. Reference equality is not deep value equality. Nested copied values share a 16 MiB conversion budget and a 32-level schema limit; these are not limits on all Perl allocations or Lean working memory. Recursive copied types remain unsupported.

=head1 CHECKED RECORDS

Checked records use generated classes containing only payload fields. Pass L<Math::BigInt> for C<Nat> fields and plain array references for copied arrays. Checked records may occur directly or through arrays, Lists, options, products, Except branches, plain record fields and active variant fields. Every nested Fin bound and Subtype constructor runs before the record constructor at that exact path. A rejection names the failing path and check. A normalizing constructor changes the record received by Lean without changing the caller's record. Results project payload fields after Lean constructs the proofs. No proof object or input constructor is needed for a result-only export. Ordinary and independently reviewed APIs preserve each site's constructor choices. Recursive and generic checked records, dependent forms beyond the recorded closed fields, callbacks and identity-bearing payloads remain unsupported.

=head1 OWNERSHIP

Close resource and closure objects when finished. Host callbacks are synchronous and may not be retained by Lean.

=cut
