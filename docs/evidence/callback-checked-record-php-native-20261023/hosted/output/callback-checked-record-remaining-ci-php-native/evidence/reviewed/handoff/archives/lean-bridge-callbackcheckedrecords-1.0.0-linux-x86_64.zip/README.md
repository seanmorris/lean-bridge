# LeanCallbackcheckedrecords

Install this package with Composer and load vendor/autoload.php. The package
loads its bundled native libraries automatically. Native execution requires
PHP 8.2+ NTS CLI on Linux x86-64 with FFI enabled.

Synchronous callbacks accept finite copied values, including recursive records
and variants. A host callback whose result contains a checked Lean Subtype or checked record must be wrapped with with_recovery(function, value); the typed recovery value is validated before native libraries load and is used only if Lean rejects the callback reply. Returned LeanClosure objects are invokable; close them in a
finally block. Destruction provides cleanup for abandoned closures. Callback
exceptions retain their Throwable identity.

Copied conversion is bounded to 128 levels, 262144 visited values and separate
16 MiB host/native budgets per call. Lean working memory is not included.
Callback reply buffers remain alive through native copying. Malformed native
output retires the shared runtime. Calls must use the main PHP execution
context in the originating process; start a fresh PHP process after fork.
