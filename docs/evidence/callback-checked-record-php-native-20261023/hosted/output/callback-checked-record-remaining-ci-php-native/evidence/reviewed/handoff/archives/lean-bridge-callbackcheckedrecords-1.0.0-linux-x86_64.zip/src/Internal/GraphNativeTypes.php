<?php
declare(strict_types=1);
namespace LeanCallbackcheckedrecords\Internal;

final class GraphNativeTypes
{
    public const DEFINITIONS = <<<'CDEFS'
typedef uint8_t *lb_php_graph_byte_pointer;
typedef uint8_t **lb_php_graph_byte_slot;
typedef struct callbackcheckedrecords_graph_38a8689c2f20ead532ea_t callbackcheckedrecords_graph_38a8689c2f20ead532ea_t;
typedef struct callbackcheckedrecords_graph_7ee21eb6b8ea120b53f0_t callbackcheckedrecords_graph_7ee21eb6b8ea120b53f0_t;
typedef struct callbackcheckedrecords_graph_29468227bdfd05da1480_t callbackcheckedrecords_graph_29468227bdfd05da1480_t;
typedef struct callbackcheckedrecords_interval_t callbackcheckedrecords_interval_t;
typedef struct callbackcheckedrecords_weighted_t callbackcheckedrecords_weighted_t;
typedef struct callbackcheckedrecords_scalar_nat_t callbackcheckedrecords_scalar_nat_t;
typedef struct callbackcheckedrecords_scalar_string_t callbackcheckedrecords_scalar_string_t;
struct callbackcheckedrecords_scalar_nat_t {
  void *_bridge_owner;
  void (*_bridge_release)(void *owner);
  const uint32_t *data;
  size_t length;
};

struct callbackcheckedrecords_interval_t {
  void *_bridge_owner;
  void (*_bridge_release)(void *owner);
  callbackcheckedrecords_scalar_nat_t lo;
  callbackcheckedrecords_scalar_nat_t hi;
};

struct callbackcheckedrecords_graph_38a8689c2f20ead532ea_t {
  void *_bridge_owner;
  void (*_bridge_release)(void *owner);
  uint8_t has_value;
  callbackcheckedrecords_interval_t value;
};

struct callbackcheckedrecords_graph_7ee21eb6b8ea120b53f0_t {
  void *_bridge_owner;
  void (*_bridge_release)(void *owner);
  const callbackcheckedrecords_graph_38a8689c2f20ead532ea_t *data;
  size_t length;
};

struct callbackcheckedrecords_scalar_string_t {
  void *_bridge_owner;
  void (*_bridge_release)(void *owner);
  const char *data;
  size_t length;
};

struct callbackcheckedrecords_graph_29468227bdfd05da1480_t {
  void *_bridge_owner;
  void (*_bridge_release)(void *owner);
  uint8_t is_ok;
  callbackcheckedrecords_graph_38a8689c2f20ead532ea_t ok;
  callbackcheckedrecords_scalar_string_t error;
};

struct callbackcheckedrecords_weighted_t {
  void *_bridge_owner;
  void (*_bridge_release)(void *owner);
  callbackcheckedrecords_scalar_nat_t weight;
  callbackcheckedrecords_scalar_nat_t limit;
};
CDEFS;
    public const NODES = [
        ['ctype' => 'callbackcheckedrecords_graph_38a8689c2f20ead532ea_t', 'kind' => 'option', 'scalar' => null, 'aggregate' => true, 'inhabited' => true, 'element' => null, 'branches' => [['class' => null, 'fields' => []], ['class' => 'LeanCallbackcheckedrecords\\Some', 'fields' => [['type' => 3, 'path' => ['value'], 'pointer' => false, 'key' => 'value']]]]],
        ['ctype' => 'callbackcheckedrecords_graph_7ee21eb6b8ea120b53f0_t', 'kind' => 'array', 'scalar' => null, 'aggregate' => true, 'inhabited' => true, 'element' => 0, 'branches' => [['class' => null, 'fields' => []]]],
        ['ctype' => 'callbackcheckedrecords_graph_29468227bdfd05da1480_t', 'kind' => 'result', 'scalar' => null, 'aggregate' => true, 'inhabited' => true, 'element' => null, 'branches' => [['class' => 'LeanCallbackcheckedrecords\\Err', 'fields' => [['type' => 6, 'path' => ['error'], 'pointer' => false, 'key' => 'value']]], ['class' => 'LeanCallbackcheckedrecords\\Ok', 'fields' => [['type' => 0, 'path' => ['ok'], 'pointer' => false, 'key' => 'value']]]]],
        ['ctype' => 'callbackcheckedrecords_interval_t', 'kind' => 'record', 'scalar' => null, 'aggregate' => true, 'inhabited' => true, 'element' => null, 'branches' => [['class' => 'LeanCallbackcheckedrecords\\Interval', 'fields' => [['type' => 5, 'path' => ['lo'], 'pointer' => false, 'key' => 'lo'], ['type' => 5, 'path' => ['hi'], 'pointer' => false, 'key' => 'hi']]]]],
        ['ctype' => 'callbackcheckedrecords_weighted_t', 'kind' => 'record', 'scalar' => null, 'aggregate' => true, 'inhabited' => true, 'element' => null, 'branches' => [['class' => 'LeanCallbackcheckedrecords\\Weighted', 'fields' => [['type' => 5, 'path' => ['weight'], 'pointer' => false, 'key' => 'weight'], ['type' => 5, 'path' => ['limit'], 'pointer' => false, 'key' => 'limit']]]]],
        ['ctype' => 'callbackcheckedrecords_scalar_nat_t', 'kind' => 'primitive', 'scalar' => 'nat', 'aggregate' => true, 'inhabited' => true, 'element' => null, 'branches' => [['class' => null, 'fields' => []]]],
        ['ctype' => 'callbackcheckedrecords_scalar_string_t', 'kind' => 'primitive', 'scalar' => 'string', 'aggregate' => true, 'inhabited' => true, 'element' => null, 'branches' => [['class' => null, 'fields' => []]]],
        ['ctype' => 'uint8_t', 'kind' => 'primitive', 'scalar' => 'unit', 'aggregate' => false, 'inhabited' => true, 'element' => null, 'branches' => [['class' => null, 'fields' => []]]],
    ];
    public const FUNCTIONS = [['parameters' => [5, 0, 2, 3, 4, 1], 'result' => 7]];
}
