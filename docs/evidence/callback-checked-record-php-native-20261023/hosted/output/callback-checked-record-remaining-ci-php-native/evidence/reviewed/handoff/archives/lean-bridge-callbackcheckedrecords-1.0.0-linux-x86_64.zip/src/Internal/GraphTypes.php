<?php
declare(strict_types=1);
namespace LeanCallbackcheckedrecords\Internal;

final class GraphTypes
{
    public const NODES = [
        ['kind' => 'option', 'element' => null, 'fields' => [['value', 3]], 'classes' => ['LeanCallbackcheckedrecords\\Some']],
        ['kind' => 'array', 'element' => 0, 'fields' => [], 'classes' => []],
        ['kind' => 'result', 'element' => null, 'fields' => [['ok', 0], ['error', 6]], 'classes' => ['LeanCallbackcheckedrecords\\Ok', 'LeanCallbackcheckedrecords\\Err']],
        ['kind' => 'record', 'element' => null, 'fields' => [['lo', 5], ['hi', 5]], 'classes' => ['LeanCallbackcheckedrecords\\Interval']],
        ['kind' => 'record', 'element' => null, 'fields' => [['weight', 5], ['limit', 5]], 'classes' => ['LeanCallbackcheckedrecords\\Weighted']],
        ['kind' => 'primitive', 'name' => 'nat', 'host' => 'bigint', 'min' => '0', 'max' => null],
        ['kind' => 'primitive', 'name' => 'string'],
        ['kind' => 'primitive', 'name' => 'unit'],
    ];
    public const CLASSES = [
        'LeanCallbackcheckedrecords\\Interval' => ['fields' => [['lo', 5], ['hi', 5]]],
        'LeanCallbackcheckedrecords\\Weighted' => ['fields' => [['weight', 5], ['limit', 5]]],
        'LeanCallbackcheckedrecords\\Some' => ['fields' => [['value', null]]],
        'LeanCallbackcheckedrecords\\Ok' => ['fields' => [['value', null]]],
        'LeanCallbackcheckedrecords\\Err' => ['fields' => [['value', null]]],
    ];
}
