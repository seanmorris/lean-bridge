<?php
declare(strict_types=1);
namespace LeanCallbackcheckedrecords\Internal;

require_once __DIR__ . '/CallableRuntime.php';
require_once __DIR__ . '/CallableTypes.php';

final class Native
{
    private const DEFINITIONS = <<<'CDEFS'
uint32_t callbackcheckedrecords_graph_initialize(void);
int callbackcheckedrecords_graph_ready(void);
void callbackcheckedrecords_graph_retire(void);
void callbackcheckedrecords_php_graph_clear(void *);
typedef struct { uint32_t (*call)(void *, void *, void *); void *context; void *recovery; } lb_php_callback_0;
typedef struct { uint32_t (*call)(void *, void *, void *, void *); void *context; void *recovery; } lb_php_callback_1;
typedef struct { uint32_t (*call)(void *, void *, void *); void *context; } lb_php_callback_2;
uint32_t callbackcheckedrecords_callback_e014092ff0a1ee8527eeeb58a78e2de63bdf09fa_lease_call(uint64_t, void *, void *);
void callbackcheckedrecords_callback_e014092ff0a1ee8527eeeb58a78e2de63bdf09fa_lease_dispose(uint64_t);
typedef struct { uint32_t (*call)(void *, void *, void *); void *context; void *recovery; } lb_php_callback_3;
typedef struct { uint32_t (*call)(void *, void *, void *); void *context; } lb_php_callback_4;
uint32_t callbackcheckedrecords_callback_d885a7d82ec894d17b81e7a67a36bc2930adca13_lease_call(uint64_t, void *, void *);
void callbackcheckedrecords_callback_d885a7d82ec894d17b81e7a67a36bc2930adca13_lease_dispose(uint64_t);
typedef struct { uint32_t (*call)(void *, void *, void *); void *context; void *recovery; } lb_php_callback_5;
typedef struct { uint32_t (*call)(void *, void *, void *, void *); void *context; } lb_php_callback_6;
uint32_t callbackcheckedrecords_callback_2e292aebff8c53f6a465ec3d5745e74400590434_lease_call(uint64_t, void *, void *, void *);
void callbackcheckedrecords_callback_2e292aebff8c53f6a465ec3d5745e74400590434_lease_dispose(uint64_t);
typedef struct { uint32_t (*call)(void *, void *, void *); void *context; } lb_php_callback_7;
uint32_t callbackcheckedrecords_callback_8994592329ecba032f0abfaa9703e59a57f3c6a1_lease_call(uint64_t, void *, void *);
void callbackcheckedrecords_callback_8994592329ecba032f0abfaa9703e59a57f3c6a1_lease_dispose(uint64_t);
uint32_t lean_bridge_697151f2fc3cf6b95ff12b69_graph(void *, void *);
uint32_t lean_bridge_413afe4aaf66162bb3ba3d3c_graph(void *, void *);
uint32_t lean_bridge_184bfb6b98fb39095f0bfec8_graph(void *, void *);
uint32_t lean_bridge_f168e18f231fdb7eb1733b0e_graph(void *, void *);
uint32_t lean_bridge_97d7a19c3e5ee22681017ca9_graph(void *, void *);
uint32_t lean_bridge_74ed57fc03e7ed555389a3ab_graph(void *, void *);
uint32_t lean_bridge_bbabc0c3fa2252f4f7a67708_graph(void *, void *);
uint32_t lean_bridge_77496697d09177e0d1ebadfd_graph(void *, void *);
CDEFS;
    private static ?CallableRuntime $runtime = null;
    private static ?\Closure $wrap = null;
    private static function load(): \FFI {
        return \LeanBridge\CopiedNativeV1\Runtime::load(__DIR__ . '/../../native/linux-x64', json_decode(<<<'EVIDENCE'
{
  "componentId": "callbackcheckedrecords@1.0.0",
  "componentReceiptSha256": "ad090749c8057b85fe8198e187a3a58ae7e9278f1963da3ba95c0ca01110f71d",
  "copiedGraph": {
    "layoutSha256": "3b810bc98e54fc20451172720fbb9b577a4e849dd4e0ff7d6669cf6e5fde6f72",
    "schemaVersion": 1
  },
  "identity": "801ef34264eadd13547f47b62a63f23a796833661f43d1879f1016a565a33db9",
  "libraries": {
    "libcallbackcheckedrecords.so": "6facfdbcb9c0c963e99ed382cee7653dcab86e1e0061ca4b33aa418f9689fdf4",
    "libcomponent_82670d9206f057180ea5.so": "735b1ed491423e37d316f7714b805425cd4c51246cc99deaf6b8ecdb3ccf5730",
    "liblean_bridge_native.so": "459fcd2098d4b646ab6ae0f4cdccd1f222908cb162562bfc3940a533cd4e4e21",
    "libleanshared.so": "d7768b88d8162736da4305777cd6f147676038fd885bd8a265c958b0ecea00b4"
  },
  "library": "libcallbackcheckedrecords.so",
  "loadOrder": [
    "libleanshared.so",
    "liblean_bridge_native.so",
    "libcomponent_82670d9206f057180ea5.so",
    "libcallbackcheckedrecords.so"
  ],
  "runtimeIdentity": "4b5a7fdf0cb11d4bb429181cfd50b330c5622ed8f5f5382a293955a439b595b5"
}
EVIDENCE, true, 512, JSON_THROW_ON_ERROR), self::DEFINITIONS);
    }
    public static function call(string $name, array $arguments): mixed {
        self::$runtime ??= new CallableRuntime(static fn(): \FFI => self::load(), CallableTypes::CATALOG);
        try {
            $value = self::$runtime->call($name, $arguments);
            if (!$value instanceof Lease) return $value;
            self::$wrap ??= \Closure::bind(static fn(Lease $lease) => new \LeanCallbackcheckedrecords\LeanClosure($lease), null, \LeanCallbackcheckedrecords\LeanClosure::class);
            return (self::$wrap)($value);
        } catch (GraphInvalidNative $error) {
            throw new \LeanCallbackcheckedrecords\LeanBridgeError($error->getMessage(), 4, $error);
        }
    }
}
