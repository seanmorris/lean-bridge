# nominalprimitivesubtypes

Compiler-checked exports for nominalprimitivesubtypes.

Binding IR SHA-256: `33636b4cd7eecec1fd9f2531fab598f860f4b225362a156d692bfe57f6cfdaa4`

## Exports

### produce

Call NominalPrimitiveSubtypes.produce.

### produceChoices

Call NominalPrimitiveSubtypes.produceChoices.

### produceEvent

Call NominalPrimitiveSubtypes.produceEvent.

### produceGroup

Call NominalPrimitiveSubtypes.produceGroup.

### producePair

Call NominalPrimitiveSubtypes.producePair.

### wordBits

Call NominalPrimitiveSubtypes.wordBits.

## Assurance

