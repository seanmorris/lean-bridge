# nominalprimitivesubtypes 1.0.0

Compiled C11 API from nominalprimitivesubtypes@1.0.0. Linux x86-64, glibc 2.36 or newer. Lean is not required by consumers. The shared native runtime is included in lib/ and loads automatically.

Include nominalprimitivesubtypes.h. Use pkg-config package nominalprimitivesubtypes, or find_package(LeanBridgeNominalprimitivesubtypes CONFIG REQUIRED) and link LeanBridge::nominalprimitivesubtypes. C++ functions live in lean_bridge::nominalprimitivesubtypes.

C inputs borrow caller buffers for one call. Initialize Nat/Int with mpz_init and aggregate structs with nominalprimitivesubtypes_TYPE_init before first use. Never initialize an mpz_t with a shallow struct copy. Nat/Int inputs are borrowed mpz_srcptr values; outputs are initialized mpz_ptr values. Successful calls replace initialized copied outputs; failures leave them unchanged. Clear structs with nominalprimitivesubtypes_TYPE_clear. Clear resets their fields to initialized empty values and is idempotent. Finish standalone integers with mpz_clear. GMP callback inputs are borrowed read-only values; callback output integers are already initialized, so assign with mpz_set, not mpz_init. Do not clear callback integer arguments or outputs. C++ results own their memory and release C buffers automatically, including when a C++ allocation throws.

Strings are length-delimited UTF-8, including embedded NUL. Byte arrays are uninterpreted bytes. Nat and Int are GMP mpz_t values. Negative Nat inputs reject. GMP 6.3.0 headers and a replaceable shared library ship in the archive and link automatically through CMake or pkg-config. Its complete corresponding source, build settings and LGPL/GPL notices are under share/lean-bridge/. GMP allocation failures abort by default; the bridge does not replace GMP allocation hooks. Unit parameters are zero in C and std::monostate in C++; Unit results have no output. Fixed-width integers use exact-width host types; floating-point values retain IEEE special values. Input and output copies share a 16 MiB per-call budget. Invalid input leaves the output unchanged and returns a status (C) or throws Error (C++).

Arrays and acyclic records can nest up to 32 types deep. C spans own their nested elements through their release callback; record clear functions clear their fields. Do not shallow-copy an owned result and clear both copies. C++ uses owned vectors and structs, with scoped input views. The 16 MiB conversion budget includes input and output payloads, array slots (at least pointer-sized), output ownership headers and record storage; it does not bound the Lean algorithm's working memory.

Tagged Lean variants use named KIND constructor constants and a union of named case fields. Initialize with the generated _init function, then call _select with a named constructor tag before filling its fields. Selection releases the previous active payload and initializes the new one, including mpz_t fields. Read kind to choose the active case; do not assign it directly or shallow-copy an owned result. Invalid selections leave the value unchanged. _clear releases the active payload and restores the initialized first constructor; repeated clear is safe. Initialize output slots before calls, and clear an earlier owned result before reusing its slot. Failed calls leave the supplied output slot unchanged. Empty constructors and Unit fields remain distinct. Generated Lean helpers keep compiler object tags and field offsets private. Variants share the 32-level type limit and 16 MiB conversion budget. Recursive, callable and identity-bearing payloads remain unsupported.

- nominalprimitivesubtypes_aliases: lean:NominalPrimitiveSubtypes.aliases
- nominalprimitivesubtypes_combine: lean:NominalPrimitiveSubtypes.combine
- nominalprimitivesubtypes_echo_a: lean:NominalPrimitiveSubtypes.echoA
- nominalprimitivesubtypes_echo_b: lean:NominalPrimitiveSubtypes.echoB
- nominalprimitivesubtypes_echo_event_a: lean:NominalPrimitiveSubtypes.echoEventA
- nominalprimitivesubtypes_echo_event_b: lean:NominalPrimitiveSubtypes.echoEventB
- nominalprimitivesubtypes_echo_pair: lean:NominalPrimitiveSubtypes.echoPair
- nominalprimitivesubtypes_produce: lean:NominalPrimitiveSubtypes.produce
- nominalprimitivesubtypes_produce_choices: lean:NominalPrimitiveSubtypes.produceChoices
- nominalprimitivesubtypes_produce_event: lean:NominalPrimitiveSubtypes.produceEvent
- nominalprimitivesubtypes_produce_group: lean:NominalPrimitiveSubtypes.produceGroup
- nominalprimitivesubtypes_produce_pair: lean:NominalPrimitiveSubtypes.producePair
- nominalprimitivesubtypes_refuse_unit: lean:NominalPrimitiveSubtypes.refuseUnit
- nominalprimitivesubtypes_word_bits: lean:NominalPrimitiveSubtypes.wordBits
