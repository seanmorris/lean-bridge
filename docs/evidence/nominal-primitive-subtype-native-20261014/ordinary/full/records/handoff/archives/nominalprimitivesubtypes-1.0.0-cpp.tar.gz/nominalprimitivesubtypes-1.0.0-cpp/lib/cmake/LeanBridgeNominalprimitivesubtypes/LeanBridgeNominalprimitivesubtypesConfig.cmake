get_filename_component(_LB_PREFIX "${CMAKE_CURRENT_LIST_DIR}/../../.." ABSOLUTE)
if(NOT TARGET LeanBridge::nominalprimitivesubtypes)
  add_library(LeanBridge::nominalprimitivesubtypes SHARED IMPORTED)
  set_target_properties(LeanBridge::nominalprimitivesubtypes PROPERTIES
    IMPORTED_LOCATION "${_LB_PREFIX}/lib/libnominalprimitivesubtypes.so"
    INTERFACE_INCLUDE_DIRECTORIES "${_LB_PREFIX}/include"
    INTERFACE_COMPILE_FEATURES "cxx_std_20"
    INTERFACE_COMPILE_DEFINITIONS "BOOST_MP_STANDALONE"
  )
endif()
unset(_LB_PREFIX)
