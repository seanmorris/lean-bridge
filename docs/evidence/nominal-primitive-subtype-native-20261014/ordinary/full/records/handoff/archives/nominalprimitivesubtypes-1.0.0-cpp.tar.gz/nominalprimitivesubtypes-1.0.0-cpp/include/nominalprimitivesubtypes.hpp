#pragma once
#include "nominalprimitivesubtypes.h"
#include <stdexcept>
#include <memory>
#include <string>
#include <variant>
#include <optional>
#include <vector>
#include <utility>

#ifndef BOOST_MP_STANDALONE
#define BOOST_MP_STANDALONE
#endif
#include <boost/multiprecision/cpp_int.hpp>

namespace lean_bridge::nominalprimitivesubtypes {
template<class T> struct Ok { T value; friend bool operator==(const Ok&, const Ok&) = default; };
template<class E> struct Err { E value; friend bool operator==(const Err&, const Err&) = default; };
template<class T, class E> using Result = std::variant<Ok<T>, Err<E>>;
using Nat = boost::multiprecision::cpp_int;
using Int = boost::multiprecision::cpp_int;
struct Packet {
  std::monostate unit_value{};
  bool bool_value{};
  uint8_t uint8_value{};
  uint16_t uint16_value{};
  uint32_t uint32_value{};
  uint64_t uint64_value{};
  int8_t int8_value{};
  int16_t int16_value{};
  int32_t int32_value{};
  int64_t int64_value{};
  Nat nat_value{};
  Int int_value{};
  float float32_value{};
  double float64_value{};
  std::string text_value{};
  std::vector<uint8_t> bytes_value{};
  char32_t char_value{};
  uint64_t usize_value{};
  int64_t isize_value{};
  Nat digit{};
  friend bool operator==(const Packet&, const Packet&) = default;
};
struct EventEmpty {

  friend bool operator==(const EventEmpty&, const EventEmpty&) = default;
};
struct EventBox {
  Packet value{};
  friend bool operator==(const EventBox&, const EventBox&) = default;
};
struct EventChoices {
  std::vector<std::optional<Result<Packet, Packet>>> values{};
  friend bool operator==(const EventChoices&, const EventChoices&) = default;
};
using Event = std::variant<EventEmpty, EventBox, EventChoices>;
struct Pair {
  std::vector<std::optional<Packet>> left{};
  std::vector<std::optional<Packet>> right{};
  friend bool operator==(const Pair&, const Pair&) = default;
};
struct RawPacket {
  std::monostate unit_value{};
  bool bool_value{};
  uint8_t uint8_value{};
  uint16_t uint16_value{};
  uint32_t uint32_value{};
  uint64_t uint64_value{};
  int8_t int8_value{};
  int16_t int16_value{};
  int32_t int32_value{};
  int64_t int64_value{};
  Nat nat_value{};
  Int int_value{};
  float float32_value{};
  double float64_value{};
  std::string text_value{};
  std::vector<uint8_t> bytes_value{};
  char32_t char_value{};
  uint64_t usize_value{};
  int64_t isize_value{};
  Nat digit{};
  friend bool operator==(const RawPacket&, const RawPacket&) = default;
};
using PacketAlias = Packet;
class Error final : public std::runtime_error {
public:
  nominalprimitivesubtypes_status status;
  nominalprimitivesubtypes_error_code code;
  Error(nominalprimitivesubtypes_status value, const nominalprimitivesubtypes_error& error)
    : std::runtime_error(error.message ? std::string(error.message, error.message_length) : "Lean call failed"), status(value), code(error.code) {}
};
namespace detail {
[[noreturn]] inline void invalid(const char* message) {
  const nominalprimitivesubtypes_error error{NOMINALPRIMITIVESUBTYPES_ERROR_INVALID_ARGUMENT, message, std::char_traits<char>::length(message)};
  throw Error(NOMINALPRIMITIVESUBTYPES_STATUS_INVALID_ARGUMENT, error);
}
inline void charge(size_t& budget, size_t count, size_t width) {
  if (count > budget / width) {
    const nominalprimitivesubtypes_error error{NOMINALPRIMITIVESUBTYPES_ERROR_INVALID_ARGUMENT, "16 MiB call limit exceeded", 26};
    throw Error(NOMINALPRIMITIVESUBTYPES_STATUS_INVALID_ARGUMENT, error);
  }
  budget -= count * width;
}
inline void check0(const std::monostate& source, size_t& budget) {
  (void)source; (void)budget;
}
struct View0 {
  uint8_t value{};
  explicit View0(const std::monostate& source) {
    (void)source;
    value = 0;
  }
};
inline std::monostate from0(const uint8_t& source) {
  (void)source;
  return {};
}

inline void check1(const bool& source, size_t& budget) {
  (void)source; (void)budget;
}
struct View1 {
  bool value{};
  explicit View1(const bool& source) {
    (void)source;
    value = source;
  }
};
inline bool from1(const bool& source) {
  (void)source;
  return source;
}

inline void check2(const uint8_t& source, size_t& budget) {
  (void)source; (void)budget;
}
struct View2 {
  uint8_t value{};
  explicit View2(const uint8_t& source) {
    (void)source;
    value = source;
  }
};
inline uint8_t from2(const uint8_t& source) {
  (void)source;
  return source;
}

inline void check3(const uint16_t& source, size_t& budget) {
  (void)source; (void)budget;
}
struct View3 {
  uint16_t value{};
  explicit View3(const uint16_t& source) {
    (void)source;
    value = source;
  }
};
inline uint16_t from3(const uint16_t& source) {
  (void)source;
  return source;
}

inline void check4(const uint32_t& source, size_t& budget) {
  (void)source; (void)budget;
}
struct View4 {
  uint32_t value{};
  explicit View4(const uint32_t& source) {
    (void)source;
    value = source;
  }
};
inline uint32_t from4(const uint32_t& source) {
  (void)source;
  return source;
}

inline void check5(const uint64_t& source, size_t& budget) {
  (void)source; (void)budget;
}
struct View5 {
  uint64_t value{};
  explicit View5(const uint64_t& source) {
    (void)source;
    value = source;
  }
};
inline uint64_t from5(const uint64_t& source) {
  (void)source;
  return source;
}

inline void check6(const int8_t& source, size_t& budget) {
  (void)source; (void)budget;
}
struct View6 {
  int8_t value{};
  explicit View6(const int8_t& source) {
    (void)source;
    value = source;
  }
};
inline int8_t from6(const int8_t& source) {
  (void)source;
  return source;
}

inline void check7(const int16_t& source, size_t& budget) {
  (void)source; (void)budget;
}
struct View7 {
  int16_t value{};
  explicit View7(const int16_t& source) {
    (void)source;
    value = source;
  }
};
inline int16_t from7(const int16_t& source) {
  (void)source;
  return source;
}

inline void check8(const int32_t& source, size_t& budget) {
  (void)source; (void)budget;
}
struct View8 {
  int32_t value{};
  explicit View8(const int32_t& source) {
    (void)source;
    value = source;
  }
};
inline int32_t from8(const int32_t& source) {
  (void)source;
  return source;
}

inline void check9(const int64_t& source, size_t& budget) {
  (void)source; (void)budget;
}
struct View9 {
  int64_t value{};
  explicit View9(const int64_t& source) {
    (void)source;
    value = source;
  }
};
inline int64_t from9(const int64_t& source) {
  (void)source;
  return source;
}

inline void check10(const Nat& source, size_t& budget) {
  (void)source; (void)budget;
  if (source < 0) invalid("Nat must be nonnegative");
  charge(budget, source == 0 ? 0 : (boost::multiprecision::msb(source < 0 ? -source : source) / 32 + 1), sizeof(uint32_t));
}
struct View10 {
  std::vector<uint32_t> limbs;
  nominalprimitivesubtypes_nat value{};
  explicit View10(const Nat& source) {
    (void)source;
    if (source != 0) boost::multiprecision::export_bits(source, std::back_inserter(limbs), 32, false);
    value = nominalprimitivesubtypes_nat{limbs.data(), limbs.size(), nullptr, nullptr};
  }
};
inline Nat from10(const nominalprimitivesubtypes_nat& source) {
  (void)source;
  Nat result = 0;
  if (source.length) boost::multiprecision::import_bits(result, source.data, source.data + source.length, 32, false);
  return result;
}

inline void check11(const Int& source, size_t& budget) {
  (void)source; (void)budget;
  charge(budget, source == 0 ? 0 : (boost::multiprecision::msb(source < 0 ? -source : source) / 32 + 1), sizeof(uint32_t));
}
struct View11 {
  std::vector<uint32_t> limbs;
  nominalprimitivesubtypes_int value{};
  explicit View11(const Int& source) {
    (void)source;
    if (source != 0) boost::multiprecision::export_bits(source, std::back_inserter(limbs), 32, false);
    value = nominalprimitivesubtypes_int{limbs.data(), limbs.size(), nullptr, nullptr, source < 0};
  }
};
inline Int from11(const nominalprimitivesubtypes_int& source) {
  (void)source;
  Int result = 0;
  if (source.length) boost::multiprecision::import_bits(result, source.data, source.data + source.length, 32, false);
  return source.negative ? -result : result;
}

inline void check12(const float& source, size_t& budget) {
  (void)source; (void)budget;
}
struct View12 {
  float value{};
  explicit View12(const float& source) {
    (void)source;
    value = source;
  }
};
inline float from12(const float& source) {
  (void)source;
  return source;
}

inline void check13(const double& source, size_t& budget) {
  (void)source; (void)budget;
}
struct View13 {
  double value{};
  explicit View13(const double& source) {
    (void)source;
    value = source;
  }
};
inline double from13(const double& source) {
  (void)source;
  return source;
}

inline void check14(const std::string& source, size_t& budget) {
  (void)source; (void)budget;
  charge(budget, source.size(), 1);
}
struct View14 {
  nominalprimitivesubtypes_string value{};
  explicit View14(const std::string& source) {
    (void)source;
    value = nominalprimitivesubtypes_string{source.data(), source.size(), nullptr, nullptr};
  }
};
inline std::string from14(const nominalprimitivesubtypes_string& source) {
  (void)source;
  return source.length ? std::string(source.data, source.length) : std::string{};
}

inline void check15(const std::vector<uint8_t>& source, size_t& budget) {
  (void)source; (void)budget;
  charge(budget, source.size(), 1);
}
struct View15 {
  nominalprimitivesubtypes_bytes value{};
  explicit View15(const std::vector<uint8_t>& source) {
    (void)source;
    value = nominalprimitivesubtypes_bytes{source.data(), source.size(), nullptr, nullptr};
  }
};
inline std::vector<uint8_t> from15(const nominalprimitivesubtypes_bytes& source) {
  (void)source;
  return source.length ? std::vector<uint8_t>(source.data, source.data + source.length) : std::vector<uint8_t>{};
}

inline void check16(const char32_t& source, size_t& budget) {
  (void)source; (void)budget;
}
struct View16 {
  uint32_t value{};
  explicit View16(const char32_t& source) {
    (void)source;
    value = source;
  }
};
inline char32_t from16(const uint32_t& source) {
  (void)source;
  return source;
}

inline void check17(const uint64_t& source, size_t& budget) {
  (void)source; (void)budget;
}
struct View17 {
  uint64_t value{};
  explicit View17(const uint64_t& source) {
    (void)source;
    value = source;
  }
};
inline uint64_t from17(const uint64_t& source) {
  (void)source;
  return source;
}

inline void check18(const int64_t& source, size_t& budget) {
  (void)source; (void)budget;
}
struct View18 {
  int64_t value{};
  explicit View18(const int64_t& source) {
    (void)source;
    value = source;
  }
};
inline int64_t from18(const int64_t& source) {
  (void)source;
  return source;
}

inline void check19(const Packet& source, size_t& budget) {
  (void)source; (void)budget;
  charge(budget, 1, sizeof(nominalprimitivesubtypes_packet));
  check0(source.unit_value, budget);
  check1(source.bool_value, budget);
  check2(source.uint8_value, budget);
  check3(source.uint16_value, budget);
  check4(source.uint32_value, budget);
  check5(source.uint64_value, budget);
  check6(source.int8_value, budget);
  check7(source.int16_value, budget);
  check8(source.int32_value, budget);
  check9(source.int64_value, budget);
  check10(source.nat_value, budget);
  check11(source.int_value, budget);
  check12(source.float32_value, budget);
  check13(source.float64_value, budget);
  check14(source.text_value, budget);
  check15(source.bytes_value, budget);
  check16(source.char_value, budget);
  check17(source.usize_value, budget);
  check18(source.isize_value, budget);
  check10(source.digit, budget);
}
struct View19 {
  View0 field0;
  View1 field1;
  View2 field2;
  View3 field3;
  View4 field4;
  View5 field5;
  View6 field6;
  View7 field7;
  View8 field8;
  View9 field9;
  View10 field10;
  View11 field11;
  View12 field12;
  View13 field13;
  View14 field14;
  View15 field15;
  View16 field16;
  View17 field17;
  View18 field18;
  View10 field19;
  nominalprimitivesubtypes_packet value{};
  explicit View19(const Packet& source) : field0(source.unit_value), field1(source.bool_value), field2(source.uint8_value), field3(source.uint16_value), field4(source.uint32_value), field5(source.uint64_value), field6(source.int8_value), field7(source.int16_value), field8(source.int32_value), field9(source.int64_value), field10(source.nat_value), field11(source.int_value), field12(source.float32_value), field13(source.float64_value), field14(source.text_value), field15(source.bytes_value), field16(source.char_value), field17(source.usize_value), field18(source.isize_value), field19(source.digit) {
    (void)source;
    value = nominalprimitivesubtypes_packet{field0.value, field1.value, field2.value, field3.value, field4.value, field5.value, field6.value, field7.value, field8.value, field9.value, field10.value, field11.value, field12.value, field13.value, field14.value, field15.value, field16.value, field17.value, field18.value, field19.value};
  }
};
inline Packet from19(const nominalprimitivesubtypes_packet& source) {
  (void)source;
  return Packet{from0(source.unit_value), from1(source.bool_value), from2(source.uint8_value), from3(source.uint16_value), from4(source.uint32_value), from5(source.uint64_value), from6(source.int8_value), from7(source.int16_value), from8(source.int32_value), from9(source.int64_value), from10(source.nat_value), from11(source.int_value), from12(source.float32_value), from13(source.float64_value), from14(source.text_value), from15(source.bytes_value), from16(source.char_value), from17(source.usize_value), from18(source.isize_value), from10(source.digit)};
}

inline void check20(const std::optional<Packet>& source, size_t& budget) {
  (void)source; (void)budget;
  charge(budget, 1, sizeof(nominalprimitivesubtypes_option_lean_nominal_primitive_subtypes_packet_value));
  if (source.has_value()) check19(*source, budget);
}
struct View20 {
  std::unique_ptr<View19> field0;
  nominalprimitivesubtypes_option_lean_nominal_primitive_subtypes_packet_value value{};
  explicit View20(const std::optional<Packet>& source) {
    (void)source;
    if (source.has_value()) { field0 = std::make_unique<View19>(*source); value.value = field0->value; }
    value.has_value = source.has_value();
  }
};
inline std::optional<Packet> from20(const nominalprimitivesubtypes_option_lean_nominal_primitive_subtypes_packet_value& source) {
  (void)source;
  if (!source.has_value) return std::nullopt;
  return std::optional<Packet>{std::in_place, from19(source.value)};
}

inline void check21(const std::vector<std::optional<Packet>>& source, size_t& budget) {
  (void)source; (void)budget;
  charge(budget, source.size(), sizeof(nominalprimitivesubtypes_option_lean_nominal_primitive_subtypes_packet_value) > sizeof(void*) ? sizeof(nominalprimitivesubtypes_option_lean_nominal_primitive_subtypes_packet_value) : sizeof(void*));
  for (const auto& item : source) check20(item, budget);
}
struct View21 {
  std::vector<View20> items;
  std::unique_ptr<nominalprimitivesubtypes_option_lean_nominal_primitive_subtypes_packet_value[]> values;
  nominalprimitivesubtypes_array_option_lean_nominal_primitive_subtypes_packet_span value{};
  explicit View21(const std::vector<std::optional<Packet>>& source) {
    (void)source;
    items.reserve(source.size()); values = std::make_unique<nominalprimitivesubtypes_option_lean_nominal_primitive_subtypes_packet_value[]>(source.size());
    for (const auto& item : source) items.emplace_back(item);
    for (size_t i = 0; i < source.size(); ++i) values[i] = items[i].value;
    value = nominalprimitivesubtypes_array_option_lean_nominal_primitive_subtypes_packet_span{values.get(), source.size(), nullptr, nullptr};
  }
};
inline std::vector<std::optional<Packet>> from21(const nominalprimitivesubtypes_array_option_lean_nominal_primitive_subtypes_packet_span& source) {
  (void)source;
  std::vector<std::optional<Packet>> result; result.reserve(source.length);
  for (size_t i = 0; i < source.length; ++i) result.push_back(from20(source.data[i]));
  return result;
}

inline void check22(const std::pair<Packet, Packet>& source, size_t& budget) {
  (void)source; (void)budget;
  charge(budget, 1, sizeof(nominalprimitivesubtypes_tuple_lean_nominal_primitive_subtypes_packet_lean_nominal_primitive_subtypes_packet_value));
  check19(source.first, budget);
  check19(source.second, budget);
}
struct View22 {
  View19 field0;
  View19 field1;
  nominalprimitivesubtypes_tuple_lean_nominal_primitive_subtypes_packet_lean_nominal_primitive_subtypes_packet_value value{};
  explicit View22(const std::pair<Packet, Packet>& source) : field0(source.first), field1(source.second) {
    (void)source;
    value = nominalprimitivesubtypes_tuple_lean_nominal_primitive_subtypes_packet_lean_nominal_primitive_subtypes_packet_value{field0.value, field1.value};
  }
};
inline std::pair<Packet, Packet> from22(const nominalprimitivesubtypes_tuple_lean_nominal_primitive_subtypes_packet_lean_nominal_primitive_subtypes_packet_value& source) {
  (void)source;
  return std::pair<Packet, Packet>{from19(source.fst), from19(source.snd)};
}

inline void check23(const Result<Packet, Packet>& source, size_t& budget) {
  (void)source; (void)budget;
  charge(budget, 1, sizeof(nominalprimitivesubtypes_result_lean_nominal_primitive_subtypes_packet_lean_nominal_primitive_subtypes_packet_value));
  if (source.valueless_by_exception()) invalid("Result has no active branch");
  if (source.index() == 0) check19(std::get<0>(source).value, budget);
  if (source.index() == 1) check19(std::get<1>(source).value, budget);
}
struct View23 {
  std::unique_ptr<View19> field0;
  std::unique_ptr<View19> field1;
  nominalprimitivesubtypes_result_lean_nominal_primitive_subtypes_packet_lean_nominal_primitive_subtypes_packet_value value{};
  explicit View23(const Result<Packet, Packet>& source) {
    (void)source;
    if (source.index() == 0) { field0 = std::make_unique<View19>(std::get<0>(source).value); value.ok = field0->value; }
    if (source.index() == 1) { field1 = std::make_unique<View19>(std::get<1>(source).value); value.error = field1->value; }
    value.is_ok = source.index() == 0;
  }
};
inline Result<Packet, Packet> from23(const nominalprimitivesubtypes_result_lean_nominal_primitive_subtypes_packet_lean_nominal_primitive_subtypes_packet_value& source) {
  (void)source;
  if (source.is_ok) return Result<Packet, Packet>{Ok<Packet>{from19(source.ok)}};
  return Result<Packet, Packet>{Err<Packet>{from19(source.error)}};
}

inline void check24(const std::optional<Result<Packet, Packet>>& source, size_t& budget) {
  (void)source; (void)budget;
  charge(budget, 1, sizeof(nominalprimitivesubtypes_option_result_lean_nominal_primitive_subtypes_packet_lean_nominal_primitive_subtypes_packet_value));
  if (source.has_value()) check23(*source, budget);
}
struct View24 {
  std::unique_ptr<View23> field0;
  nominalprimitivesubtypes_option_result_lean_nominal_primitive_subtypes_packet_lean_nominal_primitive_subtypes_packet_value value{};
  explicit View24(const std::optional<Result<Packet, Packet>>& source) {
    (void)source;
    if (source.has_value()) { field0 = std::make_unique<View23>(*source); value.value = field0->value; }
    value.has_value = source.has_value();
  }
};
inline std::optional<Result<Packet, Packet>> from24(const nominalprimitivesubtypes_option_result_lean_nominal_primitive_subtypes_packet_lean_nominal_primitive_subtypes_packet_value& source) {
  (void)source;
  if (!source.has_value) return std::nullopt;
  return std::optional<Result<Packet, Packet>>{std::in_place, from23(source.value)};
}

inline void check25(const std::vector<std::optional<Result<Packet, Packet>>>& source, size_t& budget) {
  (void)source; (void)budget;
  charge(budget, source.size(), sizeof(nominalprimitivesubtypes_option_result_lean_nominal_primitive_subtypes_packet_lean_nominal_primitive_subtypes_packet_value) > sizeof(void*) ? sizeof(nominalprimitivesubtypes_option_result_lean_nominal_primitive_subtypes_packet_lean_nominal_primitive_subtypes_packet_value) : sizeof(void*));
  for (const auto& item : source) check24(item, budget);
}
struct View25 {
  std::vector<View24> items;
  std::unique_ptr<nominalprimitivesubtypes_option_result_lean_nominal_primitive_subtypes_packet_lean_nominal_primitive_subtypes_packet_value[]> values;
  nominalprimitivesubtypes_array_option_result_lean_nominal_primitive_subtypes_packet_lean_nominal_primitive_subtypes_packet_span value{};
  explicit View25(const std::vector<std::optional<Result<Packet, Packet>>>& source) {
    (void)source;
    items.reserve(source.size()); values = std::make_unique<nominalprimitivesubtypes_option_result_lean_nominal_primitive_subtypes_packet_lean_nominal_primitive_subtypes_packet_value[]>(source.size());
    for (const auto& item : source) items.emplace_back(item);
    for (size_t i = 0; i < source.size(); ++i) values[i] = items[i].value;
    value = nominalprimitivesubtypes_array_option_result_lean_nominal_primitive_subtypes_packet_lean_nominal_primitive_subtypes_packet_span{values.get(), source.size(), nullptr, nullptr};
  }
};
inline std::vector<std::optional<Result<Packet, Packet>>> from25(const nominalprimitivesubtypes_array_option_result_lean_nominal_primitive_subtypes_packet_lean_nominal_primitive_subtypes_packet_span& source) {
  (void)source;
  std::vector<std::optional<Result<Packet, Packet>>> result; result.reserve(source.length);
  for (size_t i = 0; i < source.length; ++i) result.push_back(from24(source.data[i]));
  return result;
}

inline void check26(const Event& source, size_t& budget) {
  (void)source; (void)budget;
  charge(budget, 1, sizeof(nominalprimitivesubtypes_event));
  if (source.valueless_by_exception()) invalid("Variant has no active branch");
  switch (source.index()) {
  case 0:
    break;
  case 1:
    check19(std::get<EventBox>(source).value, budget);
    break;
  case 2:
    check25(std::get<EventChoices>(source).values, budget);
    break;
  default: invalid("Variant has no active branch");
  }
}
struct View26 {
  std::unique_ptr<View19> field1_0;
  std::unique_ptr<View25> field2_0;
  nominalprimitivesubtypes_event value{};
  explicit View26(const Event& source) {
    (void)source;
    value.kind = static_cast<uint32_t>(source.index());
    switch (source.index()) {
    case 0:
      break;
    case 1:
      field1_0 = std::make_unique<View19>(std::get<EventBox>(source).value); value.cases.box.value = field1_0->value;
      break;
    case 2:
      field2_0 = std::make_unique<View25>(std::get<EventChoices>(source).values); value.cases.choices.values = field2_0->value;
      break;
    default: invalid("Variant has no active branch");
    }
  }
};
inline Event from26(const nominalprimitivesubtypes_event& source) {
  (void)source;
  switch (source.kind) {
  case 0: return EventEmpty{};
  case 1: return EventBox{from19(source.cases.box.value)};
  case 2: return EventChoices{from25(source.cases.choices.values)};
  default: invalid("Native variant has an invalid tag");
  }
}

inline void check27(const Pair& source, size_t& budget) {
  (void)source; (void)budget;
  charge(budget, 1, sizeof(nominalprimitivesubtypes_pair));
  check21(source.left, budget);
  check21(source.right, budget);
}
struct View27 {
  View21 field0;
  View21 field1;
  nominalprimitivesubtypes_pair value{};
  explicit View27(const Pair& source) : field0(source.left), field1(source.right) {
    (void)source;
    value = nominalprimitivesubtypes_pair{field0.value, field1.value};
  }
};
inline Pair from27(const nominalprimitivesubtypes_pair& source) {
  (void)source;
  return Pair{from21(source.left), from21(source.right)};
}

inline void check28(const RawPacket& source, size_t& budget) {
  (void)source; (void)budget;
  charge(budget, 1, sizeof(nominalprimitivesubtypes_raw_packet));
  check0(source.unit_value, budget);
  check1(source.bool_value, budget);
  check2(source.uint8_value, budget);
  check3(source.uint16_value, budget);
  check4(source.uint32_value, budget);
  check5(source.uint64_value, budget);
  check6(source.int8_value, budget);
  check7(source.int16_value, budget);
  check8(source.int32_value, budget);
  check9(source.int64_value, budget);
  check10(source.nat_value, budget);
  check11(source.int_value, budget);
  check12(source.float32_value, budget);
  check13(source.float64_value, budget);
  check14(source.text_value, budget);
  check15(source.bytes_value, budget);
  check16(source.char_value, budget);
  check17(source.usize_value, budget);
  check18(source.isize_value, budget);
  check10(source.digit, budget);
}
struct View28 {
  View0 field0;
  View1 field1;
  View2 field2;
  View3 field3;
  View4 field4;
  View5 field5;
  View6 field6;
  View7 field7;
  View8 field8;
  View9 field9;
  View10 field10;
  View11 field11;
  View12 field12;
  View13 field13;
  View14 field14;
  View15 field15;
  View16 field16;
  View17 field17;
  View18 field18;
  View10 field19;
  nominalprimitivesubtypes_raw_packet value{};
  explicit View28(const RawPacket& source) : field0(source.unit_value), field1(source.bool_value), field2(source.uint8_value), field3(source.uint16_value), field4(source.uint32_value), field5(source.uint64_value), field6(source.int8_value), field7(source.int16_value), field8(source.int32_value), field9(source.int64_value), field10(source.nat_value), field11(source.int_value), field12(source.float32_value), field13(source.float64_value), field14(source.text_value), field15(source.bytes_value), field16(source.char_value), field17(source.usize_value), field18(source.isize_value), field19(source.digit) {
    (void)source;
    value = nominalprimitivesubtypes_raw_packet{field0.value, field1.value, field2.value, field3.value, field4.value, field5.value, field6.value, field7.value, field8.value, field9.value, field10.value, field11.value, field12.value, field13.value, field14.value, field15.value, field16.value, field17.value, field18.value, field19.value};
  }
};
inline RawPacket from28(const nominalprimitivesubtypes_raw_packet& source) {
  (void)source;
  return RawPacket{from0(source.unit_value), from1(source.bool_value), from2(source.uint8_value), from3(source.uint16_value), from4(source.uint32_value), from5(source.uint64_value), from6(source.int8_value), from7(source.int16_value), from8(source.int32_value), from9(source.int64_value), from10(source.nat_value), from11(source.int_value), from12(source.float32_value), from13(source.float64_value), from14(source.text_value), from15(source.bytes_value), from16(source.char_value), from17(source.usize_value), from18(source.isize_value), from10(source.digit)};
}
inline void check(nominalprimitivesubtypes_status status, const nominalprimitivesubtypes_error& error) {
  if (status != NOMINALPRIMITIVESUBTYPES_STATUS_OK) throw Error(status, error);
}
template<class T, void (*Clear)(T*)> struct Owned {
  T* value;
  ~Owned() { Clear(value); }
  Owned(const Owned&) = delete;
  Owned& operator=(const Owned&) = delete;
  explicit Owned(T* input) : value(input) {}
};
}


inline std::vector<std::optional<Packet>> aliases(std::vector<std::optional<Packet>> const& arg0, std::vector<std::optional<Packet>> const& arg1) {
  nominalprimitivesubtypes_error _lb_error{}; size_t _lb_budget = 16u * 1024u * 1024u; (void)_lb_budget;
  detail::check21(arg0, _lb_budget);
  detail::check21(arg1, _lb_budget);
  detail::View21 _lb_arg0{arg0};
  detail::View21 _lb_arg1{arg1};
  nominalprimitivesubtypes_array_option_lean_nominal_primitive_subtypes_packet_span _lb_result{};
  detail::Owned<nominalprimitivesubtypes_array_option_lean_nominal_primitive_subtypes_packet_span, nominalprimitivesubtypes_array_option_lean_nominal_primitive_subtypes_packet_span_clear> _lb_owner{&_lb_result};
  const auto _lb_status = nominalprimitivesubtypes_aliases(&_lb_arg0.value, &_lb_arg1.value, &_lb_result, &_lb_error);
  detail::check(_lb_status, _lb_error);
  return detail::from21(_lb_result);
}

inline std::pair<Packet, Packet> combine(Packet const& arg0, Packet const& arg1) {
  nominalprimitivesubtypes_error _lb_error{}; size_t _lb_budget = 16u * 1024u * 1024u; (void)_lb_budget;
  detail::check19(arg0, _lb_budget);
  detail::check19(arg1, _lb_budget);
  detail::View19 _lb_arg0{arg0};
  detail::View19 _lb_arg1{arg1};
  nominalprimitivesubtypes_tuple_lean_nominal_primitive_subtypes_packet_lean_nominal_primitive_subtypes_packet_value _lb_result{};
  detail::Owned<nominalprimitivesubtypes_tuple_lean_nominal_primitive_subtypes_packet_lean_nominal_primitive_subtypes_packet_value, nominalprimitivesubtypes_tuple_lean_nominal_primitive_subtypes_packet_lean_nominal_primitive_subtypes_packet_value_clear> _lb_owner{&_lb_result};
  const auto _lb_status = nominalprimitivesubtypes_combine(&_lb_arg0.value, &_lb_arg1.value, &_lb_result, &_lb_error);
  detail::check(_lb_status, _lb_error);
  return detail::from22(_lb_result);
}

inline Packet echo_a(Packet const& arg0) {
  nominalprimitivesubtypes_error _lb_error{}; size_t _lb_budget = 16u * 1024u * 1024u; (void)_lb_budget;
  detail::check19(arg0, _lb_budget);
  detail::View19 _lb_arg0{arg0};
  nominalprimitivesubtypes_packet _lb_result{};
  detail::Owned<nominalprimitivesubtypes_packet, nominalprimitivesubtypes_packet_clear> _lb_owner{&_lb_result};
  const auto _lb_status = nominalprimitivesubtypes_echo_a(&_lb_arg0.value, &_lb_result, &_lb_error);
  detail::check(_lb_status, _lb_error);
  return detail::from19(_lb_result);
}

inline Packet echo_b(Packet const& arg0) {
  nominalprimitivesubtypes_error _lb_error{}; size_t _lb_budget = 16u * 1024u * 1024u; (void)_lb_budget;
  detail::check19(arg0, _lb_budget);
  detail::View19 _lb_arg0{arg0};
  nominalprimitivesubtypes_packet _lb_result{};
  detail::Owned<nominalprimitivesubtypes_packet, nominalprimitivesubtypes_packet_clear> _lb_owner{&_lb_result};
  const auto _lb_status = nominalprimitivesubtypes_echo_b(&_lb_arg0.value, &_lb_result, &_lb_error);
  detail::check(_lb_status, _lb_error);
  return detail::from19(_lb_result);
}

inline Event echo_event_a(Event const& arg0) {
  nominalprimitivesubtypes_error _lb_error{}; size_t _lb_budget = 16u * 1024u * 1024u; (void)_lb_budget;
  detail::check26(arg0, _lb_budget);
  detail::View26 _lb_arg0{arg0};
  nominalprimitivesubtypes_event _lb_result{};
  detail::Owned<nominalprimitivesubtypes_event, nominalprimitivesubtypes_event_clear> _lb_owner{&_lb_result};
  const auto _lb_status = nominalprimitivesubtypes_echo_event_a(&_lb_arg0.value, &_lb_result, &_lb_error);
  detail::check(_lb_status, _lb_error);
  return detail::from26(_lb_result);
}

inline Event echo_event_b(Event const& arg0) {
  nominalprimitivesubtypes_error _lb_error{}; size_t _lb_budget = 16u * 1024u * 1024u; (void)_lb_budget;
  detail::check26(arg0, _lb_budget);
  detail::View26 _lb_arg0{arg0};
  nominalprimitivesubtypes_event _lb_result{};
  detail::Owned<nominalprimitivesubtypes_event, nominalprimitivesubtypes_event_clear> _lb_owner{&_lb_result};
  const auto _lb_status = nominalprimitivesubtypes_echo_event_b(&_lb_arg0.value, &_lb_result, &_lb_error);
  detail::check(_lb_status, _lb_error);
  return detail::from26(_lb_result);
}

inline Pair echo_pair(Pair const& arg0) {
  nominalprimitivesubtypes_error _lb_error{}; size_t _lb_budget = 16u * 1024u * 1024u; (void)_lb_budget;
  detail::check27(arg0, _lb_budget);
  detail::View27 _lb_arg0{arg0};
  nominalprimitivesubtypes_pair _lb_result{};
  detail::Owned<nominalprimitivesubtypes_pair, nominalprimitivesubtypes_pair_clear> _lb_owner{&_lb_result};
  const auto _lb_status = nominalprimitivesubtypes_echo_pair(&_lb_arg0.value, &_lb_result, &_lb_error);
  detail::check(_lb_status, _lb_error);
  return detail::from27(_lb_result);
}

inline std::optional<Packet> produce(RawPacket const& arg0) {
  nominalprimitivesubtypes_error _lb_error{}; size_t _lb_budget = 16u * 1024u * 1024u; (void)_lb_budget;
  detail::check28(arg0, _lb_budget);
  detail::View28 _lb_arg0{arg0};
  nominalprimitivesubtypes_option_lean_nominal_primitive_subtypes_packet_value _lb_result{};
  detail::Owned<nominalprimitivesubtypes_option_lean_nominal_primitive_subtypes_packet_value, nominalprimitivesubtypes_option_lean_nominal_primitive_subtypes_packet_value_clear> _lb_owner{&_lb_result};
  const auto _lb_status = nominalprimitivesubtypes_produce(&_lb_arg0.value, &_lb_result, &_lb_error);
  detail::check(_lb_status, _lb_error);
  return detail::from20(_lb_result);
}

inline Event produce_choices(RawPacket const& arg0) {
  nominalprimitivesubtypes_error _lb_error{}; size_t _lb_budget = 16u * 1024u * 1024u; (void)_lb_budget;
  detail::check28(arg0, _lb_budget);
  detail::View28 _lb_arg0{arg0};
  nominalprimitivesubtypes_event _lb_result{};
  detail::Owned<nominalprimitivesubtypes_event, nominalprimitivesubtypes_event_clear> _lb_owner{&_lb_result};
  const auto _lb_status = nominalprimitivesubtypes_produce_choices(&_lb_arg0.value, &_lb_result, &_lb_error);
  detail::check(_lb_status, _lb_error);
  return detail::from26(_lb_result);
}

inline Event produce_event(RawPacket const& arg0) {
  nominalprimitivesubtypes_error _lb_error{}; size_t _lb_budget = 16u * 1024u * 1024u; (void)_lb_budget;
  detail::check28(arg0, _lb_budget);
  detail::View28 _lb_arg0{arg0};
  nominalprimitivesubtypes_event _lb_result{};
  detail::Owned<nominalprimitivesubtypes_event, nominalprimitivesubtypes_event_clear> _lb_owner{&_lb_result};
  const auto _lb_status = nominalprimitivesubtypes_produce_event(&_lb_arg0.value, &_lb_result, &_lb_error);
  detail::check(_lb_status, _lb_error);
  return detail::from26(_lb_result);
}

inline std::vector<std::optional<Packet>> produce_group(RawPacket const& arg0) {
  nominalprimitivesubtypes_error _lb_error{}; size_t _lb_budget = 16u * 1024u * 1024u; (void)_lb_budget;
  detail::check28(arg0, _lb_budget);
  detail::View28 _lb_arg0{arg0};
  nominalprimitivesubtypes_array_option_lean_nominal_primitive_subtypes_packet_span _lb_result{};
  detail::Owned<nominalprimitivesubtypes_array_option_lean_nominal_primitive_subtypes_packet_span, nominalprimitivesubtypes_array_option_lean_nominal_primitive_subtypes_packet_span_clear> _lb_owner{&_lb_result};
  const auto _lb_status = nominalprimitivesubtypes_produce_group(&_lb_arg0.value, &_lb_result, &_lb_error);
  detail::check(_lb_status, _lb_error);
  return detail::from21(_lb_result);
}

inline Pair produce_pair(RawPacket const& arg0) {
  nominalprimitivesubtypes_error _lb_error{}; size_t _lb_budget = 16u * 1024u * 1024u; (void)_lb_budget;
  detail::check28(arg0, _lb_budget);
  detail::View28 _lb_arg0{arg0};
  nominalprimitivesubtypes_pair _lb_result{};
  detail::Owned<nominalprimitivesubtypes_pair, nominalprimitivesubtypes_pair_clear> _lb_owner{&_lb_result};
  const auto _lb_status = nominalprimitivesubtypes_produce_pair(&_lb_arg0.value, &_lb_result, &_lb_error);
  detail::check(_lb_status, _lb_error);
  return detail::from27(_lb_result);
}

inline Packet refuse_unit(Packet const& arg0) {
  nominalprimitivesubtypes_error _lb_error{}; size_t _lb_budget = 16u * 1024u * 1024u; (void)_lb_budget;
  detail::check19(arg0, _lb_budget);
  detail::View19 _lb_arg0{arg0};
  nominalprimitivesubtypes_packet _lb_result{};
  detail::Owned<nominalprimitivesubtypes_packet, nominalprimitivesubtypes_packet_clear> _lb_owner{&_lb_result};
  const auto _lb_status = nominalprimitivesubtypes_refuse_unit(&_lb_arg0.value, &_lb_result, &_lb_error);
  detail::check(_lb_status, _lb_error);
  return detail::from19(_lb_result);
}

inline uint32_t word_bits() {
  nominalprimitivesubtypes_error _lb_error{}; size_t _lb_budget = 16u * 1024u * 1024u; (void)_lb_budget;
  uint32_t _lb_result{};
  const auto _lb_status = nominalprimitivesubtypes_word_bits(&_lb_result, &_lb_error);
  detail::check(_lb_status, _lb_error);
  return detail::from4(_lb_result);
}
}
