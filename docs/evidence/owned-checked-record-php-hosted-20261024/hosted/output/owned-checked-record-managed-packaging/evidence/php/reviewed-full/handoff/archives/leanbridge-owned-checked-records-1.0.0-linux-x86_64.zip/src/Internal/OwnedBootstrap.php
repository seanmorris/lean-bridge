<?php
declare(strict_types=1);
namespace LeanOwnedCheckedRecords\Internal;

require_once __DIR__ . '/Runtime.php';
require_once __DIR__ . '/OwnedAssets.php';

final class OwnedAssets
{
    private const DEFINITIONS = OwnedCallTypes::DEFINITIONS;
    public static function load(): \FFI {
        return \LeanBridge\OwnedNativeV1\Runtime::load(__DIR__ . '/../../native/linux-x64', json_decode(<<<'EVIDENCE'
{
  "componentId": "owned-checked-records@1.0.0",
  "componentLibrary": "libcomponent_161bdaa35ee11fef40c6.so",
  "componentReceiptSha256": "7be25f6ede61f525220025594a574d426a941f105fce281c6ce6b3b87121785c",
  "identity": "1be57e3b1182c819faf69838b431d01cddb0ef6d61dfe96272808b98e90917a3",
  "libraries": {
    "libcomponent_161bdaa35ee11fef40c6.so": "e2c9b5a4863b4160315e171d3fccaa77eca7f470f6f9a1c9f7a9740514064583",
    "libgmp-lean-bridge.so.10": "9687f8d50f5c413728d4fcc8d96328912239ce8b1269cbb9a1ff793e430a7b27",
    "liblean_bridge_native.so": "459fcd2098d4b646ab6ae0f4cdccd1f222908cb162562bfc3940a533cd4e4e21",
    "libleanshared.so": "d7768b88d8162736da4305777cd6f147676038fd885bd8a265c958b0ecea00b4",
    "libowned_checked_records_php.so": "2765a9f49c943112c293d5b1f8ff00326566757f354d7633e2f0e6940e6024fb"
  },
  "library": "libowned_checked_records_php.so",
  "ownedValues": {
    "callbackFailure": "raise-after-native-return",
    "callbackLifetime": "call",
    "exactIntegers": "brick-math",
    "explicitRetention": "retain",
    "gmp": "libgmp-lean-bridge.so.10",
    "headerSha256": "14504f2c161d24d2c6b6b743c4299a777298b231d5dad062dec816302bf1dac5",
    "inputTransfers": {
      "aliases": "shared-lease",
      "arguments": "ordinary-values",
      "borrowedInputs": "reject",
      "consumption": "before-lean-call",
      "failure": "consumed-after-handoff",
      "independentRetains": "preserved",
      "schemaVersion": 1,
      "validation": "before-consumption"
    },
    "integerDecimalDigits": 16384,
    "language": "php-8.2-nts-cli",
    "limits": {
      "bytes": 16777216,
      "depth": 128,
      "retained": 4096,
      "visits": 262144
    },
    "loaderSha256": "e6974d3de49f085510405fca4a888732e238debd4b9e6a46ebde4ec39b61ca35",
    "loadingPolicy": "linux-x64-deepbind-v1",
    "nativeSha256": "8b8da02d92c2b94f6ffe45ad1df3de582f74bf0590827364db0a74d0e379027a",
    "ownership": "checked-result-leases",
    "schemaVersion": 2,
    "sharedLoaderSha256": "057d6f64a05c18766d6b10663de7aeb70714818ce06f96c74d3f3894644dfc14",
    "sourcesSha256": {
      "src/Api.php": "395cf69c4193adaff4956d7308c9c78498b07b4430917576f62c708d24277609",
      "src/Internal/GraphTypes.php": "d98c66ab2142f1a4e9802d1f89c14d2461737c16bda2b456c0a813520dd540c3",
      "src/Internal/OwnedCallTypes.php": "8c7fb195e806dd4092ff99b22cae5e05d5b82e0f510f627ee944e85d244d7163",
      "src/Internal/OwnedCalls.php": "59bfe68662d9b8e1308e4d9d10ced666aa7793c800390e9be7816e9a64f7dc42",
      "src/Internal/OwnedConversions.php": "9d3a640f68e7c4c6ae700116211bf78e74a5282b45a522d275a324f681721b8b",
      "src/Internal/OwnedNativeTypes.php": "af651648ec12deb83cc1ad41280a89bb2f97aacb9aec7c21f9c3a48244f29cc0",
      "src/Internal/OwnedRuntime.php": "0961b10d1d6f2c49267ad61c3a1f9e07af52ef725e14ff7ed78134117610e542",
      "src/Internal/Values.php": "bcd665cf88bba996f1b0dd561a0aa5599acca476c2f297374beff45bfcc85578"
    }
  },
  "runtimeIdentity": "4b5a7fdf0cb11d4bb429181cfd50b330c5622ed8f5f5382a293955a439b595b5"
}
EVIDENCE, true, 512, JSON_THROW_ON_ERROR), self::DEFINITIONS);
    }
}

Native::configure(static fn(): OwnedRuntime => new OwnedRuntime(OwnedAssets::load(),
    \LeanBridge\CopiedNativeV1\Runtime::ensureProcess(...)));
