#include "component.h"
#include "lean_bridge_native_runtime.h"
static _Thread_local int lean_bridge_owned_callback_failure_9d942cb14affa6e2c46c_state;
int lean_bridge_owned_callback_failure_9d942cb14affa6e2c46c(void) { int result = lean_bridge_owned_callback_failure_9d942cb14affa6e2c46c_state; lean_bridge_owned_callback_failure_9d942cb14affa6e2c46c_state = 0; return result; }
