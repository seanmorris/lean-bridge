#pragma once
#include <stdint.h>
#include <stddef.h>
/* Private generated adapter values. Host APIs keep resource tokens opaque. */
typedef struct lbov_ab2f4e06fa6f10070455_t160ce821a84f6887bbfd lbov_ab2f4e06fa6f10070455_t160ce821a84f6887bbfd;
typedef struct lbov_ab2f4e06fa6f10070455_tb2825946e038e653bd2b lbov_ab2f4e06fa6f10070455_tb2825946e038e653bd2b;
typedef struct lbov_ab2f4e06fa6f10070455_td79b9bbde250ee1779da lbov_ab2f4e06fa6f10070455_td79b9bbde250ee1779da;
typedef struct lbov_ab2f4e06fa6f10070455_t167081552b6f9c1d1afd lbov_ab2f4e06fa6f10070455_t167081552b6f9c1d1afd;
typedef struct lbov_ab2f4e06fa6f10070455_tdc0347e1f7f5c4d928f1 lbov_ab2f4e06fa6f10070455_tdc0347e1f7f5c4d928f1;
struct lbov_ab2f4e06fa6f10070455_td79b9bbde250ee1779da {
  uint64_t token;
};
struct lbov_ab2f4e06fa6f10070455_t167081552b6f9c1d1afd {
  const uint32_t *data;
  size_t length;
};
struct lbov_ab2f4e06fa6f10070455_tdc0347e1f7f5c4d928f1 {
  const char *data;
  size_t length;
};
struct lbov_ab2f4e06fa6f10070455_t160ce821a84f6887bbfd {
  uint8_t tag;
  const lbov_ab2f4e06fa6f10070455_tb2825946e038e653bd2b *f0;
};
struct lbov_ab2f4e06fa6f10070455_tb2825946e038e653bd2b {
  lbov_ab2f4e06fa6f10070455_td79b9bbde250ee1779da f0;
  lbov_ab2f4e06fa6f10070455_t167081552b6f9c1d1afd f1;
};
