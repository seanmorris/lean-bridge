<?php
declare(strict_types=1);
namespace LeanOwnedCheckedRecords\Internal;

final class OwnedCallTypes
{
    public const DEFINITIONS = <<<'CDEFS'
typedef struct lb_php_integer lb_php_integer;
typedef const lb_php_integer *mpz_srcptr;
typedef uint8_t *lb_php_owned_bytes;
typedef uint8_t **lb_php_owned_slot;
typedef enum owned_checked_records_status { OWNED_CHECKED_RECORDS_OK = 0, OWNED_CHECKED_RECORDS_INVALID_ARGUMENT = 1, OWNED_CHECKED_RECORDS_LIMIT = 2, OWNED_CHECKED_RECORDS_ALLOCATION_FAILED = 3, OWNED_CHECKED_RECORDS_CLOSED = 4, OWNED_CHECKED_RECORDS_WRONG_THREAD = 5, OWNED_CHECKED_RECORDS_WRONG_PROCESS = 6, OWNED_CHECKED_RECORDS_RUNTIME_UNAVAILABLE = 7, OWNED_CHECKED_RECORDS_CALL_ORDER = 8, OWNED_CHECKED_RECORDS_MALFORMED_RESULT = 9, OWNED_CHECKED_RECORDS_CALLBACK_FAILED = 10 } owned_checked_records_status;
typedef struct owned_checked_records_session owned_checked_records_session;
typedef struct owned_checked_records_result owned_checked_records_result;
/* Immutable views: input children borrow caller storage for one call.
   Output children, including GMP integers, remain valid until result_release.
   Never free a child or mutate a returned GMP integer. Retain an identity
   before releasing its last owning result. Sessions are thread/process bound.
   Close invalidates resource use; result_release still frees copied storage.
   Output/result slots must not overlap and *owner must initially be NULL.
   GMP retains its normal fatal out-of-memory policy. */
owned_checked_records_status owned_checked_records_session_open(owned_checked_records_session **out);
owned_checked_records_status owned_checked_records_session_close(owned_checked_records_session **value);
owned_checked_records_status owned_checked_records_result_release(owned_checked_records_result **value);
/* Transferred arguments take an additional input-owner slot. All arguments
   and owners are validated before consumption. Each owner must be distinct
   and belong to this session; owner slots must not overlap output slots.
   Immediately before Lean runs, each entire input owner is consumed and
   its slot becomes NULL. A later failure does not restore consumed owners.
   Old views expire when this call returns. Independently retained owners
   remain valid. Failure before consumption leaves input owners unchanged. */
typedef struct owned_checked_records_value_160ce821a84f6887bbfd_t owned_checked_records_value_160ce821a84f6887bbfd_t;
typedef struct owned_checked_records_claim_closure_result_t_handle *owned_checked_records_claim_closure_result_t;
typedef struct owned_checked_records_with_claim_callback_argument1_t_handle *owned_checked_records_with_claim_callback_argument1_t;
typedef struct owned_checked_records_booking_t owned_checked_records_booking_t;
typedef struct owned_checked_records_claim_t owned_checked_records_claim_t;
typedef struct owned_checked_records_ticket_t_handle *owned_checked_records_ticket_t;
typedef struct owned_checked_records_window_t owned_checked_records_window_t;
typedef struct owned_checked_records_scalar_string_t owned_checked_records_scalar_string_t;
struct owned_checked_records_scalar_string_t {
  const char *data;
  size_t length;
};
struct owned_checked_records_value_160ce821a84f6887bbfd_t {
  bool has_value;
  owned_checked_records_claim_t const *value;
};
struct owned_checked_records_booking_t {
  owned_checked_records_ticket_t holder;
  owned_checked_records_window_t const *window;
};
struct owned_checked_records_claim_t {
  owned_checked_records_ticket_t holder;
  mpz_srcptr quota;
};
struct owned_checked_records_window_t {
  mpz_srcptr lo;
  mpz_srcptr hi;
};
typedef owned_checked_records_value_160ce821a84f6887bbfd_t owned_checked_records_claim_for_result_t;
/* Host callbacks borrow their context for the enclosing call only.
   Set exactly one of call or closure. recovery is an optional typed value;
   it is required if the signature has no finite recovery from its inputs.
   Failure never publishes recovery as a successful result.
   Callback arguments expire on return. Replies may borrow those arguments
   or context storage, or transfer an owning result (also released on error).
   Use a generated copy function to snapshot callback-local storage.
   Do not let C++ exceptions or longjmp cross a callback boundary. */
typedef struct owned_checked_records_claim_closure_result_t_host {
  owned_checked_records_status (*call)(void *context, owned_checked_records_session *session, owned_checked_records_claim_t const * a0, owned_checked_records_claim_t *out, owned_checked_records_result **owner);
  void *context;
  owned_checked_records_claim_closure_result_t closure;
  owned_checked_records_claim_t const *recovery;
} owned_checked_records_claim_closure_result_t_host;
typedef struct owned_checked_records_with_claim_callback_argument1_t_host {
  owned_checked_records_status (*call)(void *context, owned_checked_records_session *session, owned_checked_records_claim_t const * a0, owned_checked_records_claim_t *out, owned_checked_records_result **owner);
  void *context;
  owned_checked_records_with_claim_callback_argument1_t closure;
  owned_checked_records_claim_t const *recovery;
} owned_checked_records_with_claim_callback_argument1_t_host;
owned_checked_records_status owned_checked_records_claim_closure(owned_checked_records_session *session, owned_checked_records_claim_closure_result_t *out, owned_checked_records_result **owner);
owned_checked_records_status owned_checked_records_claim_for(owned_checked_records_session *session, owned_checked_records_ticket_t a0, owned_checked_records_value_160ce821a84f6887bbfd_t *out, owned_checked_records_result **owner);
owned_checked_records_status owned_checked_records_echo_booking(owned_checked_records_session *session, owned_checked_records_booking_t const * a0, owned_checked_records_booking_t *out, owned_checked_records_result **owner);
owned_checked_records_status owned_checked_records_echo_claim(owned_checked_records_session *session, owned_checked_records_claim_t const * a0, owned_checked_records_claim_t *out, owned_checked_records_result **owner);
owned_checked_records_status owned_checked_records_new_ticket(owned_checked_records_session *session, mpz_srcptr a0, owned_checked_records_scalar_string_t a1, owned_checked_records_ticket_t *out, owned_checked_records_result **owner);
owned_checked_records_status owned_checked_records_pair_claim(owned_checked_records_session *session, owned_checked_records_booking_t const * a0, owned_checked_records_claim_t const * a1, owned_checked_records_claim_t *out, owned_checked_records_result **owner);
owned_checked_records_status owned_checked_records_serial(owned_checked_records_session *session, owned_checked_records_ticket_t a0, mpz_srcptr *out, owned_checked_records_result **owner);
owned_checked_records_status owned_checked_records_transfer_claim(owned_checked_records_session *session, owned_checked_records_claim_t const * a0, owned_checked_records_result **a0_owner, owned_checked_records_claim_t *out, owned_checked_records_result **owner);
owned_checked_records_status owned_checked_records_with_claim_callback(owned_checked_records_session *session, owned_checked_records_claim_t const * a0, owned_checked_records_with_claim_callback_argument1_t_host const * a1, owned_checked_records_claim_t *out, owned_checked_records_result **owner);
owned_checked_records_status owned_checked_records_claim_closure_result_t_call(owned_checked_records_session *session, owned_checked_records_claim_closure_result_t a0, owned_checked_records_claim_t const * a1, owned_checked_records_claim_t *out, owned_checked_records_result **owner);
owned_checked_records_status owned_checked_records_with_claim_callback_argument1_t_call(owned_checked_records_session *session, owned_checked_records_with_claim_callback_argument1_t a0, owned_checked_records_claim_t const * a1, owned_checked_records_claim_t *out, owned_checked_records_result **owner);
owned_checked_records_status owned_checked_records_claim_closure_result_t_retain(owned_checked_records_session *session, owned_checked_records_claim_closure_result_t a0, owned_checked_records_claim_closure_result_t *out, owned_checked_records_result **owner);
owned_checked_records_status owned_checked_records_with_claim_callback_argument1_t_retain(owned_checked_records_session *session, owned_checked_records_with_claim_callback_argument1_t a0, owned_checked_records_with_claim_callback_argument1_t *out, owned_checked_records_result **owner);
owned_checked_records_status owned_checked_records_ticket_t_retain(owned_checked_records_session *session, owned_checked_records_ticket_t a0, owned_checked_records_ticket_t *out, owned_checked_records_result **owner);
owned_checked_records_status owned_checked_records_value_160ce821a84f6887bbfd_t_copy(owned_checked_records_session *session, owned_checked_records_value_160ce821a84f6887bbfd_t const * a0, owned_checked_records_value_160ce821a84f6887bbfd_t *out, owned_checked_records_result **owner);
owned_checked_records_status owned_checked_records_booking_t_copy(owned_checked_records_session *session, owned_checked_records_booking_t const * a0, owned_checked_records_booking_t *out, owned_checked_records_result **owner);
owned_checked_records_status owned_checked_records_claim_t_copy(owned_checked_records_session *session, owned_checked_records_claim_t const * a0, owned_checked_records_claim_t *out, owned_checked_records_result **owner);
owned_checked_records_status owned_checked_records_window_t_copy(owned_checked_records_session *session, owned_checked_records_window_t const * a0, owned_checked_records_window_t *out, owned_checked_records_result **owner);
owned_checked_records_status owned_checked_records_scalar_nat_copy(owned_checked_records_session *session, mpz_srcptr a0, mpz_srcptr *out, owned_checked_records_result **owner);
owned_checked_records_status owned_checked_records_scalar_string_copy(owned_checked_records_session *session, owned_checked_records_scalar_string_t a0, owned_checked_records_scalar_string_t *out, owned_checked_records_result **owner);

owned_checked_records_status owned_checked_records_php_integer_new(const char *, size_t, mpz_srcptr *);
void owned_checked_records_php_integer_free(mpz_srcptr *);
owned_checked_records_status owned_checked_records_php_integer_text(mpz_srcptr, char *, size_t, size_t *);

typedef struct owned_checked_records_php_callback_1 {
  uint32_t (*call)(void *, owned_checked_records_session *, void *, void *);
  void *context;
  owned_checked_records_claim_closure_result_t closure;
  owned_checked_records_claim_t const *recovery;
  uint32_t native_status;
} owned_checked_records_php_callback_1;
typedef struct owned_checked_records_php_callback_2 {
  uint32_t (*call)(void *, owned_checked_records_session *, void *, void *);
  void *context;
  owned_checked_records_with_claim_callback_argument1_t closure;
  owned_checked_records_claim_t const *recovery;
  uint32_t native_status;
} owned_checked_records_php_callback_2;
owned_checked_records_status owned_checked_records_php_call_8(owned_checked_records_session *session, owned_checked_records_claim_t const * a0, owned_checked_records_php_callback_2 * a1, owned_checked_records_claim_t *out, owned_checked_records_result **owner);
void lean_bridge_native_runtime_retire(void);
CDEFS;
    public const CALLS = [['symbol' => 'owned_checked_records_claim_closure', 'parameters' => [], 'result' => 1], ['symbol' => 'owned_checked_records_claim_for', 'parameters' => [['type' => 5, 'host' => false]], 'result' => 0], ['symbol' => 'owned_checked_records_echo_booking', 'parameters' => [['type' => 3, 'host' => false]], 'result' => 3], ['symbol' => 'owned_checked_records_echo_claim', 'parameters' => [['type' => 4, 'host' => false]], 'result' => 4], ['symbol' => 'owned_checked_records_new_ticket', 'parameters' => [['type' => 7, 'host' => false], ['type' => 8, 'host' => false]], 'result' => 5], ['symbol' => 'owned_checked_records_pair_claim', 'parameters' => [['type' => 3, 'host' => false], ['type' => 4, 'host' => false]], 'result' => 4], ['symbol' => 'owned_checked_records_serial', 'parameters' => [['type' => 5, 'host' => false]], 'result' => 7], ['symbol' => 'owned_checked_records_transfer_claim', 'parameters' => [['type' => 4, 'host' => false, 'transfer' => 'owned_checked_records_claim_t_copy']], 'result' => 4], ['symbol' => 'owned_checked_records_php_call_8', 'parameters' => [['type' => 4, 'host' => false], ['type' => 2, 'host' => true]], 'result' => 4], ['symbol' => 'owned_checked_records_claim_closure_result_t_call', 'parameters' => [['type' => 1, 'host' => false], ['type' => 4, 'host' => false]], 'result' => 4], ['symbol' => 'owned_checked_records_with_claim_callback_argument1_t_call', 'parameters' => [['type' => 2, 'host' => false], ['type' => 4, 'host' => false]], 'result' => 4], ['symbol' => 'owned_checked_records_claim_closure_result_t_retain', 'parameters' => [['type' => 1, 'host' => false]], 'result' => 1], ['symbol' => 'owned_checked_records_with_claim_callback_argument1_t_retain', 'parameters' => [['type' => 2, 'host' => false]], 'result' => 2], ['symbol' => 'owned_checked_records_ticket_t_retain', 'parameters' => [['type' => 5, 'host' => false]], 'result' => 5], ['symbol' => 'owned_checked_records_value_160ce821a84f6887bbfd_t_copy', 'parameters' => [['type' => 0, 'host' => false]], 'result' => 0], ['symbol' => 'owned_checked_records_booking_t_copy', 'parameters' => [['type' => 3, 'host' => false]], 'result' => 3], ['symbol' => 'owned_checked_records_claim_t_copy', 'parameters' => [['type' => 4, 'host' => false]], 'result' => 4], ['symbol' => 'owned_checked_records_window_t_copy', 'parameters' => [['type' => 6, 'host' => false]], 'result' => 6], ['symbol' => 'owned_checked_records_scalar_nat_copy', 'parameters' => [['type' => 7, 'host' => false]], 'result' => 7], ['symbol' => 'owned_checked_records_scalar_string_copy', 'parameters' => [['type' => 8, 'host' => false]], 'result' => 8]];
    public const CALLBACKS = ['1' => ['ctype' => 'owned_checked_records_php_callback_1', 'invoke' => 'owned_checked_records_php_callback_1_invoke', 'parameters' => [4], 'result' => 4, 'requiresRecovery' => false], '2' => ['ctype' => 'owned_checked_records_php_callback_2', 'invoke' => 'owned_checked_records_php_callback_2_invoke', 'parameters' => [4], 'result' => 4, 'requiresRecovery' => false]];
    public const FUNCTIONS = ['claim_closure' => 0, 'claim_for' => 1, 'echo_booking' => 2, 'echo_claim' => 3, 'new_ticket' => 4, 'pair_claim' => 5, 'serial' => 6, 'transfer_claim' => 7, 'with_claim_callback' => 8];
    public const CLOSURES = ['1' => 9, '2' => 10];
    public const RETAINS = ['1' => 11, '2' => 12, '5' => 13];
}
