import OwnedCheckedRecords
set_option maxRecDepth 10000
namespace LeanBridgeOwned66dace80cc05c9c0
def carrierValue {α : Type} (value : _root_.Array α) : _root_.Option α :=
  if bound : 0 < value.size then
    if value.size == 1 then .some (value[0]'bound) else .none
  else .none

def carrierResult {α : Type} (value : _root_.Option α) : _root_.Array α :=
  match value with | .none => #[] | .some result => #[result]

def carrierCollect {α : Type} (values : _root_.Array (_root_.Array α)) : _root_.Option (_root_.Array α) := Id.run do
  if values.size > 262144 then return .none
  let mut result := #[]
  for value in values do
    match carrierValue value with
    | .none => return .none
    | .some item => result := result.push item
  return .some result

def carrierListItems {α : Type} (values : _root_.List α) (limit : _root_.Nat) : _root_.Array (_root_.Array α) :=
  let rec loop : _root_.Nat → _root_.List α → _root_.Array (_root_.Array α) → _root_.Array (_root_.Array α)
    | 0, _, acc => acc
    | _, [], acc => acc
    | fuel + 1, head :: tail, acc => loop fuel tail (acc.push #[head])
  loop (min limit 262145) values #[]

structure LbOwnedErased.OwnedCheckedRecords.Window where
  «lo» : _root_.Nat
  «hi» : _root_.Nat

structure LbOwnedErased.OwnedCheckedRecords.Booking where
  «holder» : _root_.OwnedCheckedRecords.Ticket
  «window» : LbOwnedErased.OwnedCheckedRecords.Window

structure LbOwnedErased.OwnedCheckedRecords.Claim where
  «holder» : _root_.OwnedCheckedRecords.Ticket
  «quota» : _root_.Nat

@[export lean_bridge_owned_refine_5ba8ebacbf26c0755e45]
def lean_bridge_owned_refine_5ba8ebacbf26c0755e45 (carrier : _root_.Array LbOwnedErased.OwnedCheckedRecords.Booking) : _root_.UInt8 :=
  match carrierValue carrier with
  | .none => 0
  | .some value =>
    match (do let a0_0 ← (_root_.Option.some ((value).«holder»)); let a0_1 ← (do let a1_0 ← (_root_.Option.some (((value).«window»).«lo»)); let a1_1 ← (_root_.Option.some (((value).«window»).«hi»)); _root_.OwnedCheckedRecords.mkWindow a1_0 a1_1); pure (({ «holder» := a0_0, «window» := a0_1 } : _root_.OwnedCheckedRecords.Booking))) with
    | .some _ => 1
    | .none => 0

@[export lean_bridge_owned_refine_ca177b2570793a278657]
def lean_bridge_owned_refine_ca177b2570793a278657 (carrier : _root_.Array LbOwnedErased.OwnedCheckedRecords.Claim) : _root_.UInt8 :=
  match carrierValue carrier with
  | .none => 0
  | .some value =>
    match (do let a0_0 ← (_root_.Option.some ((value).«holder»)); let a0_1 ← (_root_.Option.some ((value).«quota»)); _root_.OwnedCheckedRecords.mkClaim a0_0 a0_1) with
    | .some _ => 1
    | .none => 0

@[export lean_bridge_owned_e594a580f4a100d0651c1d57_t160ce821a84f6887bbfd_branch]
def carrier0 (value : (_root_.Array (_root_.Option LbOwnedErased.OwnedCheckedRecords.Claim))) : _root_.UInt32 :=
  match carrierValue value with
  | .none => 4294967295
  | .some value =>
    match value with
    | .none => 0
    | .some _ => 1

@[export lean_bridge_owned_e594a580f4a100d0651c1d57_t160ce821a84f6887bbfd_none]
def carrier1 (_bridgeUnit : _root_.Unit) : (_root_.Array (_root_.Option LbOwnedErased.OwnedCheckedRecords.Claim)) :=
  carrierResult (do
    pure (.none)
  )

@[export lean_bridge_owned_e594a580f4a100d0651c1d57_t160ce821a84f6887bbfd_make0]
def carrier2 (a0 : (_root_.Array LbOwnedErased.OwnedCheckedRecords.Claim)) : (_root_.Array (_root_.Option LbOwnedErased.OwnedCheckedRecords.Claim)) :=
  carrierResult (do
    let a0 ← carrierValue a0
    pure (.some a0)
  )

@[export lean_bridge_owned_e594a580f4a100d0651c1d57_t160ce821a84f6887bbfd_field0]
def carrier3 (value : (_root_.Array (_root_.Option LbOwnedErased.OwnedCheckedRecords.Claim))) : (_root_.Array LbOwnedErased.OwnedCheckedRecords.Claim) :=
  carrierResult (do
    let value ← carrierValue value
    match value with
    | .some child => pure child
    | _ => .none
  )

@[export lean_bridge_owned_e594a580f4a100d0651c1d57_t648974cffb2d6c1d7951_apply]
def carrier4 (closure : (_root_.Array (_root_.OwnedCheckedRecords.Claim → _root_.OwnedCheckedRecords.Claim))) (a0 : (_root_.Array LbOwnedErased.OwnedCheckedRecords.Claim)) : (_root_.Array LbOwnedErased.OwnedCheckedRecords.Claim) :=
  carrierResult (do
    let closure ← carrierValue closure
    let a0 ← carrierValue a0
    let _source0 ← (do let a0_0 ← (_root_.Option.some ((a0).«holder»)); let a0_1 ← (_root_.Option.some ((a0).«quota»)); _root_.OwnedCheckedRecords.mkClaim a0_0 a0_1)
    pure ((LbOwnedErased.OwnedCheckedRecords.Claim.mk ((closure _source0).«holder») ((closure _source0).«quota»)))
  )

@[export lean_bridge_owned_e594a580f4a100d0651c1d57_t5035e6ea0903f12776d9_apply]
def carrier5 (closure : (_root_.Array (_root_.OwnedCheckedRecords.Claim → _root_.OwnedCheckedRecords.Claim))) (a0 : (_root_.Array LbOwnedErased.OwnedCheckedRecords.Claim)) : (_root_.Array LbOwnedErased.OwnedCheckedRecords.Claim) :=
  #[]

@[export lean_bridge_owned_e594a580f4a100d0651c1d57_t23107461f72b24c37654_make]
def carrier6 (a0 : (_root_.Array _root_.OwnedCheckedRecords.Ticket)) (a1 : (_root_.Array LbOwnedErased.OwnedCheckedRecords.Window)) : (_root_.Array LbOwnedErased.OwnedCheckedRecords.Booking) :=
  carrierResult (do
    let a0 ← carrierValue a0
    let a1 ← carrierValue a1
    pure (({ «holder» := a0, «window» := a1 } : LbOwnedErased.OwnedCheckedRecords.Booking))
  )

@[export lean_bridge_owned_e594a580f4a100d0651c1d57_t23107461f72b24c37654_field0]
def carrier7 (value : (_root_.Array LbOwnedErased.OwnedCheckedRecords.Booking)) : (_root_.Array _root_.OwnedCheckedRecords.Ticket) :=
  carrierResult (do
    let value ← carrierValue value
    pure value.«holder»
  )

@[export lean_bridge_owned_e594a580f4a100d0651c1d57_t23107461f72b24c37654_field1]
def carrier8 (value : (_root_.Array LbOwnedErased.OwnedCheckedRecords.Booking)) : (_root_.Array LbOwnedErased.OwnedCheckedRecords.Window) :=
  carrierResult (do
    let value ← carrierValue value
    pure value.«window»
  )

@[export lean_bridge_owned_e594a580f4a100d0651c1d57_tb2825946e038e653bd2b_make]
def carrier9 (a0 : (_root_.Array _root_.OwnedCheckedRecords.Ticket)) (a1 : (_root_.Array _root_.Nat)) : (_root_.Array LbOwnedErased.OwnedCheckedRecords.Claim) :=
  carrierResult (do
    let a0 ← carrierValue a0
    let a1 ← carrierValue a1
    pure (({ «holder» := a0, «quota» := a1 } : LbOwnedErased.OwnedCheckedRecords.Claim))
  )

@[export lean_bridge_owned_e594a580f4a100d0651c1d57_tb2825946e038e653bd2b_field0]
def carrier10 (value : (_root_.Array LbOwnedErased.OwnedCheckedRecords.Claim)) : (_root_.Array _root_.OwnedCheckedRecords.Ticket) :=
  carrierResult (do
    let value ← carrierValue value
    pure value.«holder»
  )

@[export lean_bridge_owned_e594a580f4a100d0651c1d57_tb2825946e038e653bd2b_field1]
def carrier11 (value : (_root_.Array LbOwnedErased.OwnedCheckedRecords.Claim)) : (_root_.Array _root_.Nat) :=
  carrierResult (do
    let value ← carrierValue value
    pure value.«quota»
  )

@[export lean_bridge_owned_e594a580f4a100d0651c1d57_t2a091437b2d587ce3891_make]
def carrier12 (a0 : (_root_.Array _root_.Nat)) (a1 : (_root_.Array _root_.Nat)) : (_root_.Array LbOwnedErased.OwnedCheckedRecords.Window) :=
  carrierResult (do
    let a0 ← carrierValue a0
    let a1 ← carrierValue a1
    pure (({ «lo» := a0, «hi» := a1 } : LbOwnedErased.OwnedCheckedRecords.Window))
  )

@[export lean_bridge_owned_e594a580f4a100d0651c1d57_t2a091437b2d587ce3891_field0]
def carrier13 (value : (_root_.Array LbOwnedErased.OwnedCheckedRecords.Window)) : (_root_.Array _root_.Nat) :=
  carrierResult (do
    let value ← carrierValue value
    pure value.«lo»
  )

@[export lean_bridge_owned_e594a580f4a100d0651c1d57_t2a091437b2d587ce3891_field1]
def carrier14 (value : (_root_.Array LbOwnedErased.OwnedCheckedRecords.Window)) : (_root_.Array _root_.Nat) :=
  carrierResult (do
    let value ← carrierValue value
    pure value.«hi»
  )

@[export lean_bridge_owned_e594a580f4a100d0651c1d57_fa3218a29f42862f9b113]
def carrier15 (_bridgeUnit : _root_.Unit) : (_root_.Array (_root_.OwnedCheckedRecords.Claim → _root_.OwnedCheckedRecords.Claim)) :=
  carrierResult (do
    pure (_root_.OwnedCheckedRecords.claimClosure )
  )

@[export lean_bridge_owned_e594a580f4a100d0651c1d57_f483485736ace9af57086]
def carrier16 (a0 : (_root_.Array _root_.OwnedCheckedRecords.Ticket)) : (_root_.Array (_root_.Option LbOwnedErased.OwnedCheckedRecords.Claim)) :=
  carrierResult (do
    let a0 ← carrierValue a0
    let _sourceResult := _root_.OwnedCheckedRecords.claimFor a0
    pure (((_sourceResult).map (fun _ownedValue0 => (LbOwnedErased.OwnedCheckedRecords.Claim.mk ((_ownedValue0).«holder») ((_ownedValue0).«quota»)))))
  )

@[export lean_bridge_owned_e594a580f4a100d0651c1d57_f0711e856cfa97d876c9a]
def carrier17 (a0 : (_root_.Array LbOwnedErased.OwnedCheckedRecords.Booking)) : (_root_.Array LbOwnedErased.OwnedCheckedRecords.Booking) :=
  carrierResult (do
    let a0 ← carrierValue a0
    let _source0 ← (do let a0_0 ← (_root_.Option.some ((a0).«holder»)); let a0_1 ← (do let a1_0 ← (_root_.Option.some (((a0).«window»).«lo»)); let a1_1 ← (_root_.Option.some (((a0).«window»).«hi»)); _root_.OwnedCheckedRecords.mkWindow a1_0 a1_1); pure (({ «holder» := a0_0, «window» := a0_1 } : _root_.OwnedCheckedRecords.Booking)))
    let _sourceResult := _root_.OwnedCheckedRecords.echoBooking _source0
    pure ((LbOwnedErased.OwnedCheckedRecords.Booking.mk ((_sourceResult).«holder») (LbOwnedErased.OwnedCheckedRecords.Window.mk (((_sourceResult).«window»).«lo») (((_sourceResult).«window»).«hi»))))
  )

@[export lean_bridge_owned_e594a580f4a100d0651c1d57_f535babcfd8d0f67ea0e6]
def carrier18 (a0 : (_root_.Array LbOwnedErased.OwnedCheckedRecords.Claim)) : (_root_.Array LbOwnedErased.OwnedCheckedRecords.Claim) :=
  carrierResult (do
    let a0 ← carrierValue a0
    let _source0 ← (do let a0_0 ← (_root_.Option.some ((a0).«holder»)); let a0_1 ← (_root_.Option.some ((a0).«quota»)); _root_.OwnedCheckedRecords.mkClaim a0_0 a0_1)
    let _sourceResult := _root_.OwnedCheckedRecords.echoClaim _source0
    pure ((LbOwnedErased.OwnedCheckedRecords.Claim.mk ((_sourceResult).«holder») ((_sourceResult).«quota»)))
  )

@[export lean_bridge_owned_e594a580f4a100d0651c1d57_fa1e5189bd92568e4b939]
def carrier19 (a0 : (_root_.Array _root_.Nat)) (a1 : (_root_.Array _root_.String)) : (_root_.Array _root_.OwnedCheckedRecords.Ticket) :=
  carrierResult (do
    let a0 ← carrierValue a0
    let a1 ← carrierValue a1
    pure (_root_.OwnedCheckedRecords.newTicket a0 a1)
  )

@[export lean_bridge_owned_e594a580f4a100d0651c1d57_feaac3cc8d9197bd7bbca]
def carrier20 (a0 : (_root_.Array LbOwnedErased.OwnedCheckedRecords.Booking)) (a1 : (_root_.Array LbOwnedErased.OwnedCheckedRecords.Claim)) : (_root_.Array LbOwnedErased.OwnedCheckedRecords.Claim) :=
  carrierResult (do
    let a0 ← carrierValue a0
    let a1 ← carrierValue a1
    let _source0 ← (do let a0_0 ← (_root_.Option.some ((a0).«holder»)); let a0_1 ← (do let a1_0 ← (_root_.Option.some (((a0).«window»).«lo»)); let a1_1 ← (_root_.Option.some (((a0).«window»).«hi»)); _root_.OwnedCheckedRecords.mkWindow a1_0 a1_1); pure (({ «holder» := a0_0, «window» := a0_1 } : _root_.OwnedCheckedRecords.Booking)))
    let _source1 ← (do let a0_0 ← (_root_.Option.some ((a1).«holder»)); let a0_1 ← (_root_.Option.some ((a1).«quota»)); _root_.OwnedCheckedRecords.mkClaim a0_0 a0_1)
    let _sourceResult := _root_.OwnedCheckedRecords.pairClaim _source0 _source1
    pure ((LbOwnedErased.OwnedCheckedRecords.Claim.mk ((_sourceResult).«holder») ((_sourceResult).«quota»)))
  )

@[export lean_bridge_owned_e594a580f4a100d0651c1d57_fec926afda994fba3abe2]
def carrier21 (a0 : (_root_.Array _root_.OwnedCheckedRecords.Ticket)) : (_root_.Array _root_.Nat) :=
  carrierResult (do
    let a0 ← carrierValue a0
    pure (_root_.OwnedCheckedRecords.serial a0)
  )

@[export lean_bridge_owned_e594a580f4a100d0651c1d57_f040aca3025d850fc12cc]
def carrier22 (a0 : (_root_.Array LbOwnedErased.OwnedCheckedRecords.Claim)) : (_root_.Array LbOwnedErased.OwnedCheckedRecords.Claim) :=
  carrierResult (do
    let a0 ← carrierValue a0
    let _source0 ← (do let a0_0 ← (_root_.Option.some ((a0).«holder»)); let a0_1 ← (_root_.Option.some ((a0).«quota»)); _root_.OwnedCheckedRecords.mkClaim a0_0 a0_1)
    let _sourceResult := _root_.OwnedCheckedRecords.transferClaim _source0
    pure ((LbOwnedErased.OwnedCheckedRecords.Claim.mk ((_sourceResult).«holder») ((_sourceResult).«quota»)))
  )

@[export lean_bridge_owned_e594a580f4a100d0651c1d57_f7d6c8617a0788c12de15]
def carrier23 (a0 : (_root_.Array LbOwnedErased.OwnedCheckedRecords.Claim)) (a1 : (_root_.Array (_root_.OwnedCheckedRecords.Claim → _root_.OwnedCheckedRecords.Claim))) : (_root_.Array LbOwnedErased.OwnedCheckedRecords.Claim) :=
  carrierResult (do
    let a0 ← carrierValue a0
    let a1 ← carrierValue a1
    let _source0 ← (do let a0_0 ← (_root_.Option.some ((a0).«holder»)); let a0_1 ← (_root_.Option.some ((a0).«quota»)); _root_.OwnedCheckedRecords.mkClaim a0_0 a0_1)
    let _sourceResult := _root_.OwnedCheckedRecords.withClaimCallback _source0 a1
    pure ((LbOwnedErased.OwnedCheckedRecords.Claim.mk ((_sourceResult).«holder») ((_sourceResult).«quota»)))
  )

@[extern "lean_bridge_owned_e594a580f4a100d0651c1d57_t648974cffb2d6c1d7951_invoke"]
opaque hostInvoke0 (token : _root_.USize) (a0 : (_root_.Array LbOwnedErased.OwnedCheckedRecords.Claim)) : (_root_.Array LbOwnedErased.OwnedCheckedRecords.Claim) := #[]

@[export lean_bridge_owned_e594a580f4a100d0651c1d57_t648974cffb2d6c1d7951_wrap]
def hostWrap0 (_token _explicit : _root_.USize) (_recovery : (_root_.Array LbOwnedErased.OwnedCheckedRecords.Claim)) : (_root_.Array (_root_.OwnedCheckedRecords.Claim → _root_.OwnedCheckedRecords.Claim)) := #[]

def hostRecovery1 (a0 : _root_.OwnedCheckedRecords.Claim) : _root_.OwnedCheckedRecords.Claim :=
  let recovery0 : _root_.OwnedCheckedRecords.Claim := a0
  recovery0

@[extern "lean_bridge_owned_e594a580f4a100d0651c1d57_t5035e6ea0903f12776d9_reject"]
opaque hostReject1 (token : _root_.USize) (recovery : _root_.OwnedCheckedRecords.Claim) : _root_.OwnedCheckedRecords.Claim := recovery

@[extern "lean_bridge_owned_e594a580f4a100d0651c1d57_t5035e6ea0903f12776d9_invoke"]
opaque hostInvoke1 (token : _root_.USize) (a0 : (_root_.Array LbOwnedErased.OwnedCheckedRecords.Claim)) : (_root_.Array LbOwnedErased.OwnedCheckedRecords.Claim) := #[]

@[export lean_bridge_owned_e594a580f4a100d0651c1d57_t5035e6ea0903f12776d9_wrap]
def hostWrap1 (token explicit : _root_.USize) (recovery : (_root_.Array LbOwnedErased.OwnedCheckedRecords.Claim)) : (_root_.Array (_root_.OwnedCheckedRecords.Claim → _root_.OwnedCheckedRecords.Claim)) :=
  match (do let value ← carrierValue recovery; (do let a0_0 ← (_root_.Option.some ((value).«holder»)); let a0_1 ← (_root_.Option.some ((value).«quota»)); _root_.OwnedCheckedRecords.mkClaim a0_0 a0_1)) with
  | .some fallback =>
    #[fun a0 => match (do let value ← carrierValue (hostInvoke1 token #[(LbOwnedErased.OwnedCheckedRecords.Claim.mk ((a0).«holder») ((a0).«quota»))]); (do let a0_0 ← (_root_.Option.some ((value).«holder»)); let a0_1 ← (_root_.Option.some ((value).«quota»)); _root_.OwnedCheckedRecords.mkClaim a0_0 a0_1)) with
      | .some value => value
      | .none => hostReject1 token (fallback)]
  | .none =>
    if explicit != 0 then #[] else
      #[fun a0 => match (do let value ← carrierValue (hostInvoke1 token #[(LbOwnedErased.OwnedCheckedRecords.Claim.mk ((a0).«holder») ((a0).«quota»))]); (do let a0_0 ← (_root_.Option.some ((value).«holder»)); let a0_1 ← (_root_.Option.some ((value).«quota»)); _root_.OwnedCheckedRecords.mkClaim a0_0 a0_1)) with
        | .some value => value
        | .none => hostReject1 token (hostRecovery1 a0)]

end LeanBridgeOwned66dace80cc05c9c0
