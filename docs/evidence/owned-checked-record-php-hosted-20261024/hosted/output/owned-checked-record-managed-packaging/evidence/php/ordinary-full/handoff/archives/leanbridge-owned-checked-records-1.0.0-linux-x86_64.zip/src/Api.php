<?php
declare(strict_types=1);
namespace LeanOwnedCheckedRecords;

require_once __DIR__ . '/Internal/Values.php';



final class LeanBridgeError extends \RuntimeException {}

final readonly class Bytes implements \Stringable, \Countable
{
    private function __construct(private string $value) {}
    public static function fromString(mixed $value): self {
        if (!\is_string($value)) throw new \TypeError('Bytes requires a string');
        return new self($value);
    }
    public function toString(): string { return $this->value; }
    public function __toString(): string { return $this->value; }
    public function count(): int { return \strlen($this->value); }

    public function equals(mixed $other): bool {
        return $other instanceof self && Internal\Values::equal($this, $other);
    }
    public function hashCode(): string { return Internal\Values::hash($this); }

}


/** @template T */
final readonly class Some
{
    /** @var T */
    public mixed $value;
    /** @param T $value */
    public function __construct(mixed $value) {
        if (\func_num_args() !== 1) throw new \ArgumentCountError('Some requires one payload');
        $this->value = $value;
    }

    public function equals(mixed $other): bool {
        return $other instanceof self && Internal\Values::equal($this, $other);
    }
    public function hashCode(): string { return Internal\Values::hash($this); }

}

/** @template T */
final readonly class Ok
{
    /** @var T */
    public mixed $value;
    /** @param T $value */
    public function __construct(mixed $value) {
        if (\func_num_args() !== 1) throw new \ArgumentCountError('Ok requires one payload');
        $this->value = $value;
    }

    public function equals(mixed $other): bool {
        return $other instanceof self && Internal\Values::equal($this, $other);
    }
    public function hashCode(): string { return Internal\Values::hash($this); }

}

/** @template T */
final readonly class Err
{
    /** @var T */
    public mixed $value;
    /** @param T $value */
    public function __construct(mixed $value) {
        if (\func_num_args() !== 1) throw new \ArgumentCountError('Err requires one payload');
        $this->value = $value;
    }

    public function equals(mixed $other): bool {
        return $other instanceof self && Internal\Values::equal($this, $other);
    }
    public function hashCode(): string { return Internal\Values::hash($this); }

}

final readonly class Booking
{
    /** @var Ticket */
    public Ticket $holder;
    /** @var Window */
    public Window $window;
    public function __construct(mixed $holder, mixed $window) {
        if (\func_num_args() !== 2) throw new \ArgumentCountError('Booking requires exactly 2 fields');
        Internal\Values::checkFields(self::class, [$holder, $window]);
        $this->holder = $holder;
        $this->window = $window;
    }

    public function equals(mixed $other): bool {
        return $other instanceof self && Internal\Values::equal($this, $other);
    }
    public function hashCode(): string { return Internal\Values::hash($this); }

}

final readonly class Claim
{
    /** @var Ticket */
    public Ticket $holder;
    /** @var \Brick\Math\BigInteger */
    public \Brick\Math\BigInteger $quota;
    public function __construct(mixed $holder, mixed $quota) {
        if (\func_num_args() !== 2) throw new \ArgumentCountError('Claim requires exactly 2 fields');
        Internal\Values::checkFields(self::class, [$holder, $quota]);
        $this->holder = $holder;
        $this->quota = $quota;
    }

    public function equals(mixed $other): bool {
        return $other instanceof self && Internal\Values::equal($this, $other);
    }
    public function hashCode(): string { return Internal\Values::hash($this); }

}

final readonly class Window
{
    /** @var \Brick\Math\BigInteger */
    public \Brick\Math\BigInteger $lo;
    /** @var \Brick\Math\BigInteger */
    public \Brick\Math\BigInteger $hi;
    public function __construct(mixed $lo, mixed $hi) {
        if (\func_num_args() !== 2) throw new \ArgumentCountError('Window requires exactly 2 fields');
        Internal\Values::checkFields(self::class, [$lo, $hi]);
        $this->lo = $lo;
        $this->hi = $hi;
    }

    public function equals(mixed $other): bool {
        return $other instanceof self && Internal\Values::equal($this, $other);
    }
    public function hashCode(): string { return Internal\Values::hash($this); }

}
final class Callback26621c40b48fce52ca37 extends Internal\Resource
{
    public function __invoke(mixed $argument0): mixed {
        if (\func_num_args() !== 1) throw new \ArgumentCountError('Lean closure requires 1 arguments');
        return Internal\ResourceAccess::invoke($this, [$argument0]);
    }
}

final class Callbackb2d3d6fd4e031785f278 extends Internal\Resource
{
    public function __invoke(mixed $argument0): mixed {
        if (\func_num_args() !== 1) throw new \ArgumentCountError('Lean closure requires 1 arguments');
        return Internal\ResourceAccess::invoke($this, [$argument0]);
    }
}

final class Ticket extends Internal\Resource
{
}

final readonly class WithRecovery
{
    public function __construct(public mixed $callback, public mixed $value) {
        if (\func_num_args() !== 2) throw new \ArgumentCountError('WithRecovery requires a callback and typed value');
    }
}
function with_recovery(mixed $callback, mixed $value): WithRecovery {
    if (\func_num_args() !== 2) throw new \ArgumentCountError('with_recovery requires two arguments');
    return new WithRecovery($callback, $value);
}
require_once __DIR__ . '/Internal/OwnedCalls.php';
/**

 * @return Callback26621c40b48fce52ca37
 */
function claim_closure(): Callback26621c40b48fce52ca37 {
    if (\func_num_args() !== 0) throw new \ArgumentCountError('claim_closure requires exactly 0 arguments');
    return Internal\Native::call('claim_closure', []);
}

/**
 * @param Ticket $arg0
 * @return Some<Claim>|null
 */
function claim_for(mixed $arg0): Some|null {
    if (\func_num_args() !== 1) throw new \ArgumentCountError('claim_for requires exactly 1 arguments');
    return Internal\Native::call('claim_for', [$arg0]);
}

/**
 * @param Booking $arg0
 * @return Booking
 */
function echo_booking(mixed $arg0): Booking {
    if (\func_num_args() !== 1) throw new \ArgumentCountError('echo_booking requires exactly 1 arguments');
    return Internal\Native::call('echo_booking', [$arg0]);
}

/**
 * @param Claim $arg0
 * @return Claim
 */
function echo_claim(mixed $arg0): Claim {
    if (\func_num_args() !== 1) throw new \ArgumentCountError('echo_claim requires exactly 1 arguments');
    return Internal\Native::call('echo_claim', [$arg0]);
}

/**
 * @param \Brick\Math\BigInteger $arg0
 * @param string $arg1
 * @return Ticket
 */
function new_ticket(mixed $arg0, mixed $arg1): Ticket {
    if (\func_num_args() !== 2) throw new \ArgumentCountError('new_ticket requires exactly 2 arguments');
    return Internal\Native::call('new_ticket', [$arg0, $arg1]);
}

/**
 * @param Booking $arg0
 * @param Claim $arg1
 * @return Claim
 */
function pair_claim(mixed $arg0, mixed $arg1): Claim {
    if (\func_num_args() !== 2) throw new \ArgumentCountError('pair_claim requires exactly 2 arguments');
    return Internal\Native::call('pair_claim', [$arg0, $arg1]);
}

/**
 * @param Ticket $arg0
 * @return \Brick\Math\BigInteger
 */
function serial(mixed $arg0): \Brick\Math\BigInteger {
    if (\func_num_args() !== 1) throw new \ArgumentCountError('serial requires exactly 1 arguments');
    return Internal\Native::call('serial', [$arg0]);
}

/**
 * @param Claim $arg0
 * Consumes resource leases in $arg0 at the Lean call boundary.
 * @return Claim
 */
function transfer_claim(mixed $arg0): Claim {
    if (\func_num_args() !== 1) throw new \ArgumentCountError('transfer_claim requires exactly 1 arguments');
    return Internal\Native::call('transfer_claim', [$arg0]);
}

/**
 * @param Claim $arg0
 * @param callable|Callbackb2d3d6fd4e031785f278|WithRecovery $arg1
 * @return Claim
 */
function with_claim_callback(mixed $arg0, mixed $arg1): Claim {
    if (\func_num_args() !== 2) throw new \ArgumentCountError('with_claim_callback requires exactly 2 arguments');
    return Internal\Native::call('with_claim_callback', [$arg0, $arg1]);
}

require_once __DIR__ . '/Internal/OwnedBootstrap.php';
