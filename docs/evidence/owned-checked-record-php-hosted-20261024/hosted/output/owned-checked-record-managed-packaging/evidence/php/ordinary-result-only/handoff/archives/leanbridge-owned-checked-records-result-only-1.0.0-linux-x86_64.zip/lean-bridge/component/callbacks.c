#include "component.h"
#include "lean_bridge_native_runtime.h"
static _Thread_local int lean_bridge_owned_callback_failure_ab2f4e06fa6f10070455_state;
int lean_bridge_owned_callback_failure_ab2f4e06fa6f10070455(void) { int result = lean_bridge_owned_callback_failure_ab2f4e06fa6f10070455_state; lean_bridge_owned_callback_failure_ab2f4e06fa6f10070455_state = 0; return result; }
