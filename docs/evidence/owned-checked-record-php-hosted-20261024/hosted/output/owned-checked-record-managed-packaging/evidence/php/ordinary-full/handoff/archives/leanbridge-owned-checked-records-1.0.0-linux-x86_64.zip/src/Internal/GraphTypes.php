<?php
declare(strict_types=1);
namespace LeanOwnedCheckedRecords\Internal;

final class GraphTypes
{
    public const NODES = [['kind' => 'option', 'element' => null, 'fields' => [[0, 4]], 'classes' => ['LeanOwnedCheckedRecords\\Some']], ['kind' => 'callback', 'element' => null, 'fields' => [], 'classes' => ['LeanOwnedCheckedRecords\\Callback26621c40b48fce52ca37']], ['kind' => 'callback', 'element' => null, 'fields' => [], 'classes' => ['LeanOwnedCheckedRecords\\Callbackb2d3d6fd4e031785f278']], ['kind' => 'record', 'element' => null, 'fields' => [['holder', 5], ['window', 6]], 'classes' => ['LeanOwnedCheckedRecords\\Booking']], ['kind' => 'record', 'element' => null, 'fields' => [['holder', 5], ['quota', 7]], 'classes' => ['LeanOwnedCheckedRecords\\Claim']], ['kind' => 'resource', 'element' => null, 'fields' => [], 'classes' => ['LeanOwnedCheckedRecords\\Ticket']], ['kind' => 'record', 'element' => null, 'fields' => [['lo', 7], ['hi', 7]], 'classes' => ['LeanOwnedCheckedRecords\\Window']], ['kind' => 'primitive', 'name' => 'nat', 'host' => 'bigint', 'min' => '0', 'max' => null], ['kind' => 'primitive', 'name' => 'string']];
    public const CLASSES = ['LeanOwnedCheckedRecords\\Booking' => ['fields' => [['holder', 5], ['window', 6]]], 'LeanOwnedCheckedRecords\\Claim' => ['fields' => [['holder', 5], ['quota', 7]]], 'LeanOwnedCheckedRecords\\Window' => ['fields' => [['lo', 7], ['hi', 7]]], 'LeanOwnedCheckedRecords\\Some' => ['fields' => [['value', null]]], 'LeanOwnedCheckedRecords\\Ok' => ['fields' => [['value', null]]], 'LeanOwnedCheckedRecords\\Err' => ['fields' => [['value', null]]]];
    public const IDENTITIES = ['LeanOwnedCheckedRecords\\Callback26621c40b48fce52ca37' => 1, 'LeanOwnedCheckedRecords\\Callbackb2d3d6fd4e031785f278' => 2, 'LeanOwnedCheckedRecords\\Ticket' => 5];
}
