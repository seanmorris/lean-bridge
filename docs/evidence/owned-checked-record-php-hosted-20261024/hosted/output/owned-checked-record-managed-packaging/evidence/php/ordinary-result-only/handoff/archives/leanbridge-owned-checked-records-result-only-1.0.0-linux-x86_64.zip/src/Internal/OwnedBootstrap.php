<?php
declare(strict_types=1);
namespace LeanOwnedCheckedRecords\Internal;

require_once __DIR__ . '/Runtime.php';
require_once __DIR__ . '/OwnedAssets.php';

final class OwnedAssets
{
    private const DEFINITIONS = OwnedCallTypes::DEFINITIONS;
    public static function load(): \FFI {
        return \LeanBridge\OwnedNativeV1\Runtime::load(__DIR__ . '/../../native/linux-x64', json_decode(<<<'EVIDENCE'
{
  "componentId": "owned-checked-records@1.0.0",
  "componentLibrary": "libcomponent_161bdaa35ee11fef40c6.so",
  "componentReceiptSha256": "ccf9b66d544745d59b3351a532232b499fb0e4088e0161ab85d431c626d9d7e7",
  "identity": "09ce545b0d4d26c899cb58aa6314d34bb068d4984bb805b18863e7693ba265e1",
  "libraries": {
    "libcomponent_161bdaa35ee11fef40c6.so": "46fdfa95b575891c8570a6cba5314370748ab571b7a561dc95b0594af483659f",
    "libgmp-lean-bridge.so.10": "9687f8d50f5c413728d4fcc8d96328912239ce8b1269cbb9a1ff793e430a7b27",
    "liblean_bridge_native.so": "459fcd2098d4b646ab6ae0f4cdccd1f222908cb162562bfc3940a533cd4e4e21",
    "libleanshared.so": "d7768b88d8162736da4305777cd6f147676038fd885bd8a265c958b0ecea00b4",
    "libowned_checked_records_php.so": "1274b89ddaf42ace7409d21aa6303bd4126c323175c3e52dad41c893447c4b8c"
  },
  "library": "libowned_checked_records_php.so",
  "ownedValues": {
    "callbackFailure": "raise-after-native-return",
    "callbackLifetime": "call",
    "exactIntegers": "brick-math",
    "explicitRetention": "retain",
    "gmp": "libgmp-lean-bridge.so.10",
    "headerSha256": "c17c476f8284121588b5229f8df081cb1014db30c716923e6d7ddaccb3b8ba93",
    "integerDecimalDigits": 16384,
    "language": "php-8.2-nts-cli",
    "limits": {
      "bytes": 16777216,
      "depth": 128,
      "retained": 4096,
      "visits": 262144
    },
    "loaderSha256": "e6974d3de49f085510405fca4a888732e238debd4b9e6a46ebde4ec39b61ca35",
    "loadingPolicy": "linux-x64-deepbind-v1",
    "nativeSha256": "40a92e10feeba0c352fb1349ecb103ee3d43d268a5f7b1df044ac7bec6ba31a4",
    "ownership": "checked-result-leases",
    "schemaVersion": 1,
    "sharedLoaderSha256": "057d6f64a05c18766d6b10663de7aeb70714818ce06f96c74d3f3894644dfc14",
    "sourcesSha256": {
      "src/Api.php": "9d4cf4e6674455ca246eed645f27706be7775f7cb54be1a7dd81f21bf85a9eba",
      "src/Internal/GraphTypes.php": "8c52ab3c6a2136e26c47dd5777f995c39381d79985c14c26700e68830a22ff87",
      "src/Internal/OwnedCallTypes.php": "c6e2e141a139b7910d048936df4ba0ccf8b440ca8dac1b3479d42cae30986d90",
      "src/Internal/OwnedCalls.php": "e5ea6301a6b8cbaceb61ec4e96247823ec0c0518f92465143bab1b0093ebeae6",
      "src/Internal/OwnedConversions.php": "a1ac0f43e01a101002d03b8d49f3b7c94182366fd0290a86f26bea5bb311ee19",
      "src/Internal/OwnedNativeTypes.php": "82e3122863756992744756a637e1d4d769f6483f6d3b0177aa245fd8922d20c7",
      "src/Internal/OwnedRuntime.php": "b5175b10cefeaaf19535160ce48ce78839750e3427fa3206bd1bff67c223cf35",
      "src/Internal/Values.php": "bcd665cf88bba996f1b0dd561a0aa5599acca476c2f297374beff45bfcc85578"
    }
  },
  "runtimeIdentity": "4b5a7fdf0cb11d4bb429181cfd50b330c5622ed8f5f5382a293955a439b595b5"
}
EVIDENCE, true, 512, JSON_THROW_ON_ERROR), self::DEFINITIONS);
    }
}

Native::configure(static fn(): OwnedRuntime => new OwnedRuntime(OwnedAssets::load(),
    \LeanBridge\CopiedNativeV1\Runtime::ensureProcess(...)));
