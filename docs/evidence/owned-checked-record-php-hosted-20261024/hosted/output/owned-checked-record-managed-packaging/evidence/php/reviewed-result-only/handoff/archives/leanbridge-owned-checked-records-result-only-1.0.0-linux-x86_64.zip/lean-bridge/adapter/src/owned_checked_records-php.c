#include "owned_checked_records.h"
#include "owned-values.h"
#include "carriers.h"

#include <stddef.h>
#include <stdint.h>
#include <string.h>
#include "owned-leases.h"
_Static_assert(sizeof(void *) == 8 && sizeof(size_t) == 8, "owned native values require 64-bit Lean");
enum { OV_RESULT = 9 };
typedef struct {
  size_t bytes, visits;
  struct { const void *address; size_t type; } path[129];
} ov_budget;
typedef struct ov_allocation {
  struct ov_allocation *next;
  max_align_t alignment;
  unsigned char data[];
} ov_allocation;
typedef struct {
  lb_owned_scope scope;
  ov_budget budget;
  ov_allocation *allocations;
} ov_transaction;
typedef struct ov_result_owner {
  struct ov_result_owner *self;
  lb_owned_context *context;
  lb_owned_batch batch;
  ov_allocation *allocations;
} ov_result_owner;

static inline void ov_release(ov_allocation *allocation) {
  while (allocation) {
    ov_allocation *next = allocation->next; LB_OWNED_FREE(allocation); allocation = next;
  }
}
static inline int ov_pointer(const void *value, size_t bytes, size_t alignment) {
  return value && (uintptr_t)value % alignment == 0 && bytes <= UINTPTR_MAX - (uintptr_t)value;
}
static inline int ov_charge(ov_budget *budget, size_t count, size_t width) {
  if (!width || count > budget->bytes / width) return LB_OWNED_LIMIT;
  budget->bytes -= count * width; return LB_OWNED_OK;
}
static inline int ov_visit(ov_budget *budget, size_t depth) {
  if (depth > 128 || !budget->visits) return LB_OWNED_LIMIT;
  --budget->visits; return LB_OWNED_OK;
}
static inline int ov_enter(ov_budget *budget, const void *value, size_t type, size_t depth) {
  int status = ov_visit(budget, depth);
  if (status) return status;
  for (size_t i = 0; i < depth; ++i)
    if (budget->path[i].address == value && budget->path[i].type == type) return LB_OWNED_INVALID;
  budget->path[depth].address = value; budget->path[depth].type = type;
  return LB_OWNED_OK;
}
static inline int ov_span(ov_budget *budget, const void *value, size_t count, size_t width, size_t alignment) {
  int status = ov_charge(budget, count, width);
  if (status) return status;
  return !count || ov_pointer(value, count * width, alignment) ? LB_OWNED_OK : LB_OWNED_INVALID;
}
static inline int ov_allocate(ov_transaction *transaction, size_t count, size_t width, void **out) {
  *out = NULL; if (!count) return LB_OWNED_OK;
  int status = ov_charge(&transaction->budget, count, width);
  if (!status) status = ov_charge(&transaction->budget, 1, sizeof(ov_allocation));
  if (status) return status;
  ov_allocation *allocation = LB_OWNED_ALLOC(sizeof(*allocation) + count * width);
  if (!allocation) return LB_OWNED_ALLOC_FAILED;
  allocation->next = transaction->allocations; transaction->allocations = allocation;
  memset(allocation->data, 0, count * width); *out = allocation->data; return LB_OWNED_OK;
}
static inline int ov_utf8(const uint8_t *data, size_t length) {
  size_t i = 0;
  while (i < length) {
    uint32_t point = data[i++], minimum; size_t extra;
    if (point < 0x80) continue;
    if (point >= 0xc2 && point <= 0xdf) { point &= 0x1f; extra = 1; minimum = 0x80; }
    else if (point >= 0xe0 && point <= 0xef) { point &= 0x0f; extra = 2; minimum = 0x800; }
    else if (point >= 0xf0 && point <= 0xf4) { point &= 7; extra = 3; minimum = 0x10000; }
    else return 0;
    if (extra > length - i) return 0;
    while (extra--) { uint8_t next = data[i++]; if ((next & 0xc0) != 0x80) return 0; point = (point << 6) | (next & 0x3f); }
    if (point < minimum || point > 0x10ffff || (point >= 0xd800 && point <= 0xdfff)) return 0;
  }
  return 1;
}
static inline lean_object *ov_nat_in(const uint32_t *data, size_t length) {
  lean_object *value = lean_box(0);
  while (length) {
    lean_object *shifted = lean_nat_shiftl(value, lean_box(32)); lean_dec(value);
    lean_object *limb = lean_uint32_to_nat(data[--length]);
    value = lean_nat_add(shifted, limb); lean_dec(shifted); lean_dec(limb);
  }
  return value;
}
static inline int ov_nat_out(lean_object *value, ov_transaction *transaction, const uint32_t **data, size_t *length) {
  *data = NULL; *length = 0;
  if (lean_nat_eq(value, lean_box(0))) return LB_OWNED_OK;
  lean_object *bits = lean_nat_log2(value);
  if (!lean_is_scalar(bits)) { lean_dec(bits); return LB_OWNED_LIMIT; }
  size_t count = lean_unbox(bits) / 32 + 1; lean_dec(bits);
  void *raw = NULL; int status = ov_allocate(transaction, count, sizeof(uint32_t), &raw);
  if (status) return status;
  uint32_t *limbs = raw; lean_inc(value);
  for (size_t i = 0; i < count; ++i) {
    limbs[i] = lean_uint32_of_nat(value);
    lean_object *next = lean_nat_shiftr(value, lean_box(32)); lean_dec(value); value = next;
  }
  lean_dec(value); *data = limbs; *length = count; return LB_OWNED_OK;
}
static inline lean_object *ov_carry(lean_object *value) {
  lean_object *carrier = lean_alloc_array(1, 1); lean_array_set_core(carrier, 0, value); return carrier;
}
static inline int ov_carrier(lean_object *value) {
  return value && !lean_is_scalar(value) && lean_is_array(value) && lean_array_size(value) == 1;
}
static inline int ov_finish(lean_object *value, lean_object **out) {
  if (!ov_carrier(value)) { if (value) lean_dec(value); return OV_RESULT; }
  *out = value; return LB_OWNED_OK;
}
static inline int ov_owner_empty(const ov_result_owner *owner) {
  return owner && !owner->self && !owner->context && !owner->allocations
    && !owner->batch.context && !owner->batch.entries && !owner->batch.next;
}
static inline int ov_owner_clear(ov_result_owner *owner) {
  if (!owner) return LB_OWNED_INVALID;
  if (ov_owner_empty(owner)) return LB_OWNED_OK;
  if (owner->self != owner || !owner->context) return LB_OWNED_INVALID;
  lb_owned_context *context = owner->context;
  if (context->self != context) return LB_OWNED_INVALID;
  if (context->process != getpid()) return LB_OWNED_PROCESS;
  if (!pthread_equal(context->thread, pthread_self()) || context->thread_serial != lb_owned_thread_serial)
    return LB_OWNED_THREAD;
  int status = LB_OWNED_OK;
  if (owner->batch.context) status = lb_owned_batch_release(context, &owner->batch);
  /* A broker error can be reported after release has drained the batch. */
  if (owner->batch.context) return status;
  ov_release(owner->allocations); *owner = (ov_result_owner){0}; return status;
}
static inline int ov_begin(ov_transaction *transaction, lb_owned_context *context, ov_result_owner *owner, const char *component) {
  if (!ov_owner_empty(owner)) return LB_OWNED_INVALID;
  int status = lb_owned_ready(context);
  if (status) return status;
  if (strcmp(context->component, component)) return LB_OWNED_INVALID;
  *transaction = (ov_transaction){0};
  transaction->budget.bytes = 16777216; transaction->budget.visits = 262144;
  return lb_owned_scope_begin(context, &transaction->scope);
}
static inline int ov_abort(ov_transaction *transaction, int status) {
  ov_release(transaction->allocations); transaction->allocations = NULL;
  if (transaction->scope.context) {
    if (status == OV_RESULT) lean_bridge_native_runtime_retire();
    int cleanup = lb_owned_scope_abort(&transaction->scope);
    if (!status) status = cleanup;
  }
  return status;
}
static inline int ov_commit(ov_transaction *transaction, ov_result_owner *owner) {
  lb_owned_context *context = transaction->scope.context;
  int status = lb_owned_scope_ready(&transaction->scope);
  if (status) return ov_abort(transaction, status);
  if (!transaction->allocations && !transaction->scope.outputs)
    return ov_abort(transaction, LB_OWNED_OK);
  status = lb_owned_scope_commit(&transaction->scope, &owner->batch);
  if (status) {
    /* Commit may have transferred outputs before dropping a failing input pin. */
    if (owner->batch.context) lb_owned_batch_release(context, &owner->batch);
    return ov_abort(transaction, status);
  }
  owner->self = owner; owner->context = context; owner->allocations = transaction->allocations;
  transaction->allocations = NULL; return LB_OWNED_OK;
}


enum { OV_CALLBACK = 10 };
typedef struct ov_callback_frame {
  struct ov_callback_frame *parent;
  ov_transaction *transaction;
  int status;
} ov_callback_frame;
static _Thread_local ov_callback_frame *ov_active_callback_frame;
static inline void ov_callback_fail(ov_callback_frame *frame, int status) {
  if (frame && !frame->status) frame->status = status;
}

static inline int lbov_9d942cb14affa6e2c46c_v160ce821a84f6887bbfd_in(const lbov_9d942cb14affa6e2c46c_t160ce821a84f6887bbfd *, size_t, int, ov_transaction *, lean_object **);
static inline int lbov_9d942cb14affa6e2c46c_v160ce821a84f6887bbfd_out(lbov_9d942cb14affa6e2c46c_t160ce821a84f6887bbfd *, lean_object *, size_t, ov_transaction *);
static inline int lbov_9d942cb14affa6e2c46c_vb2825946e038e653bd2b_in(const lbov_9d942cb14affa6e2c46c_tb2825946e038e653bd2b *, size_t, int, ov_transaction *, lean_object **);
static inline int lbov_9d942cb14affa6e2c46c_vb2825946e038e653bd2b_out(lbov_9d942cb14affa6e2c46c_tb2825946e038e653bd2b *, lean_object *, size_t, ov_transaction *);
static inline int lbov_9d942cb14affa6e2c46c_vd79b9bbde250ee1779da_in(const lbov_9d942cb14affa6e2c46c_td79b9bbde250ee1779da *, size_t, int, ov_transaction *, lean_object **);
static inline int lbov_9d942cb14affa6e2c46c_vd79b9bbde250ee1779da_out(lbov_9d942cb14affa6e2c46c_td79b9bbde250ee1779da *, lean_object *, size_t, ov_transaction *);
static inline int lbov_9d942cb14affa6e2c46c_v167081552b6f9c1d1afd_in(const lbov_9d942cb14affa6e2c46c_t167081552b6f9c1d1afd *, size_t, int, ov_transaction *, lean_object **);
static inline int lbov_9d942cb14affa6e2c46c_v167081552b6f9c1d1afd_out(lbov_9d942cb14affa6e2c46c_t167081552b6f9c1d1afd *, lean_object *, size_t, ov_transaction *);
static inline int lbov_9d942cb14affa6e2c46c_vdc0347e1f7f5c4d928f1_in(const lbov_9d942cb14affa6e2c46c_tdc0347e1f7f5c4d928f1 *, size_t, int, ov_transaction *, lean_object **);
static inline int lbov_9d942cb14affa6e2c46c_vdc0347e1f7f5c4d928f1_out(lbov_9d942cb14affa6e2c46c_tdc0347e1f7f5c4d928f1 *, lean_object *, size_t, ov_transaction *);
static inline int lbov_9d942cb14affa6e2c46c_v160ce821a84f6887bbfd_in(const lbov_9d942cb14affa6e2c46c_t160ce821a84f6887bbfd *value, size_t depth, int storage, ov_transaction *transaction, lean_object **out) {
  *out = NULL;
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_9d942cb14affa6e2c46c_t160ce821a84f6887bbfd))) return LB_OWNED_INVALID;
  int status = ov_enter(&transaction->budget, value, 0, depth);
  if (!status && storage) status = ov_charge(&transaction->budget, 1, sizeof(*value));
  if (status) return status;
  if (value->tag > 1) return LB_OWNED_INVALID;
  if (!value->tag) return ov_finish(lean_bridge_owned_c37ce895564546da1673e4bf_t160ce821a84f6887bbfd_none(lean_box(0)), out);
  if (value->tag == 1) {
    lean_object *child = NULL;
    status = lbov_9d942cb14affa6e2c46c_vb2825946e038e653bd2b_in(value->f0, depth + 1, 1, transaction, &child);
    if (status) return status;
    return ov_finish(lean_bridge_owned_c37ce895564546da1673e4bf_t160ce821a84f6887bbfd_make0(child), out);
  }
  return LB_OWNED_INVALID;
}
static inline int lbov_9d942cb14affa6e2c46c_v160ce821a84f6887bbfd_out(lbov_9d942cb14affa6e2c46c_t160ce821a84f6887bbfd *out, lean_object *value, size_t depth, ov_transaction *transaction) {
  int status = ov_visit(&transaction->budget, depth);
  if (status) { if (value) lean_dec(value); return status; }
  if (!ov_carrier(value)) { if (value) lean_dec(value); return OV_RESULT; }
  lean_inc(value);
  uint32_t tag = lean_bridge_owned_c37ce895564546da1673e4bf_t160ce821a84f6887bbfd_branch(value);
  if (tag > 1) { lean_dec(value); return OV_RESULT; }
  out->tag = (uint8_t)tag;
  if (out->tag == 1) {
  if (!status) {
    void *raw = NULL;
    status = ov_allocate(transaction, 1, sizeof(lbov_9d942cb14affa6e2c46c_tb2825946e038e653bd2b), &raw);
    out->f0 = raw;
    if (!status) {
      lean_inc(value);
      status = lbov_9d942cb14affa6e2c46c_vb2825946e038e653bd2b_out(raw, lean_bridge_owned_c37ce895564546da1673e4bf_t160ce821a84f6887bbfd_field0(value), depth + 1, transaction);
    }
  }
  }
  lean_dec(value); return status;
}
__attribute__((noinline)) static lean_object *lbov_9d942cb14affa6e2c46c_vb2825946e038e653bd2b_make(lean_object *items) {
  lean_object *a0 = lean_array_get_core(items, 0); lean_inc(a0);
  lean_object *a1 = lean_array_get_core(items, 1); lean_inc(a1);
  lean_dec(items);
  return lean_bridge_owned_c37ce895564546da1673e4bf_tb2825946e038e653bd2b_make(a0, a1);
}
static inline int lbov_9d942cb14affa6e2c46c_vb2825946e038e653bd2b_in(const lbov_9d942cb14affa6e2c46c_tb2825946e038e653bd2b *value, size_t depth, int storage, ov_transaction *transaction, lean_object **out) {
  *out = NULL;
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_9d942cb14affa6e2c46c_tb2825946e038e653bd2b))) return LB_OWNED_INVALID;
  int status = ov_enter(&transaction->budget, value, 1, depth);
  if (!status && storage) status = ov_charge(&transaction->budget, 1, sizeof(*value));
  if (status) return status;
  lean_object *items = lean_alloc_array(0, 2);
  lean_object *child = NULL;
  status = lbov_9d942cb14affa6e2c46c_vd79b9bbde250ee1779da_in(&value->f0, depth + 1, 0, transaction, &child);
  if (status) { lean_dec(items); return status; }
  items = lean_array_push(items, child);
  status = lbov_9d942cb14affa6e2c46c_v167081552b6f9c1d1afd_in(&value->f1, depth + 1, 0, transaction, &child);
  if (status) { lean_dec(items); return status; }
  items = lean_array_push(items, child);
  return ov_finish(lbov_9d942cb14affa6e2c46c_vb2825946e038e653bd2b_make(items), out);
}
static inline int lbov_9d942cb14affa6e2c46c_vb2825946e038e653bd2b_out(lbov_9d942cb14affa6e2c46c_tb2825946e038e653bd2b *out, lean_object *value, size_t depth, ov_transaction *transaction) {
  int status = ov_visit(&transaction->budget, depth);
  if (status) { if (value) lean_dec(value); return status; }
  if (!ov_carrier(value)) { if (value) lean_dec(value); return OV_RESULT; }
  if (!status) {
    if (!status) {
      lean_inc(value);
      status = lbov_9d942cb14affa6e2c46c_vd79b9bbde250ee1779da_out(&out->f0, lean_bridge_owned_c37ce895564546da1673e4bf_tb2825946e038e653bd2b_field0(value), depth + 1, transaction);
    }
  }
  if (!status) {
    if (!status) {
      lean_inc(value);
      status = lbov_9d942cb14affa6e2c46c_v167081552b6f9c1d1afd_out(&out->f1, lean_bridge_owned_c37ce895564546da1673e4bf_tb2825946e038e653bd2b_field1(value), depth + 1, transaction);
    }
  }
  lean_dec(value); return status;
}
static inline int lbov_9d942cb14affa6e2c46c_vd79b9bbde250ee1779da_in(const lbov_9d942cb14affa6e2c46c_td79b9bbde250ee1779da *value, size_t depth, int storage, ov_transaction *transaction, lean_object **out) {
  *out = NULL;
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_9d942cb14affa6e2c46c_td79b9bbde250ee1779da))) return LB_OWNED_INVALID;
  int status = ov_enter(&transaction->budget, value, 2, depth);
  if (!status && storage) status = ov_charge(&transaction->budget, 1, sizeof(*value));
  if (status) return status;
  lean_object *child = NULL;
  status = lb_owned_scope_borrow(&transaction->scope, "resource:OwnedCheckedRecords.Ticket", value->token, &child);
  if (status) return status;
  lean_inc(child); return ov_finish(ov_carry(child), out);
}
static inline int lbov_9d942cb14affa6e2c46c_vd79b9bbde250ee1779da_out(lbov_9d942cb14affa6e2c46c_td79b9bbde250ee1779da *out, lean_object *value, size_t depth, ov_transaction *transaction) {
  int status = ov_visit(&transaction->budget, depth);
  if (status) { if (value) lean_dec(value); return status; }
  if (!ov_carrier(value)) { if (value) lean_dec(value); return OV_RESULT; }
  lean_object *child = lean_array_get_core(value, 0);
  if (lean_is_scalar(child)) { lean_dec(value); return OV_RESULT; }
  status = lb_owned_scope_acquire(&transaction->scope, "resource:OwnedCheckedRecords.Ticket", child, &out->token);
  lean_dec(value); return status;
}
static inline int lbov_9d942cb14affa6e2c46c_v167081552b6f9c1d1afd_in(const lbov_9d942cb14affa6e2c46c_t167081552b6f9c1d1afd *value, size_t depth, int storage, ov_transaction *transaction, lean_object **out) {
  *out = NULL;
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_9d942cb14affa6e2c46c_t167081552b6f9c1d1afd))) return LB_OWNED_INVALID;
  int status = ov_enter(&transaction->budget, value, 3, depth);
  if (!status && storage) status = ov_charge(&transaction->budget, 1, sizeof(*value));
  if (status) return status;
  status = ov_span(&transaction->budget, value->data, value->length, sizeof(uint32_t), _Alignof(uint32_t));
  if (status) return status;
  return ov_finish(ov_carry(ov_nat_in(value->data, value->length)), out);
}
static inline int lbov_9d942cb14affa6e2c46c_v167081552b6f9c1d1afd_out(lbov_9d942cb14affa6e2c46c_t167081552b6f9c1d1afd *out, lean_object *value, size_t depth, ov_transaction *transaction) {
  int status = ov_visit(&transaction->budget, depth);
  if (status) { if (value) lean_dec(value); return status; }
  if (!ov_carrier(value)) { if (value) lean_dec(value); return OV_RESULT; }
  lean_object *child = lean_array_get_core(value, 0); lean_inc(child); lean_dec(value);
  if (!lean_is_scalar(child) && !lean_is_mpz(child)) { lean_dec(child); return OV_RESULT; }
  status = ov_nat_out(child, transaction, &out->data, &out->length);
  lean_dec(child); return status;
}
static inline int lbov_9d942cb14affa6e2c46c_vdc0347e1f7f5c4d928f1_in(const lbov_9d942cb14affa6e2c46c_tdc0347e1f7f5c4d928f1 *value, size_t depth, int storage, ov_transaction *transaction, lean_object **out) {
  *out = NULL;
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_9d942cb14affa6e2c46c_tdc0347e1f7f5c4d928f1))) return LB_OWNED_INVALID;
  int status = ov_enter(&transaction->budget, value, 4, depth);
  if (!status && storage) status = ov_charge(&transaction->budget, 1, sizeof(*value));
  if (status) return status;
  status = ov_span(&transaction->budget, value->data, value->length, 1, 1);
  if (status) return status;
  if (!ov_utf8((const uint8_t *)value->data, value->length)) return LB_OWNED_INVALID;
  return ov_finish(ov_carry(lean_mk_string_from_bytes(value->length ? value->data : "", value->length)), out);
}
static inline int lbov_9d942cb14affa6e2c46c_vdc0347e1f7f5c4d928f1_out(lbov_9d942cb14affa6e2c46c_tdc0347e1f7f5c4d928f1 *out, lean_object *value, size_t depth, ov_transaction *transaction) {
  int status = ov_visit(&transaction->budget, depth);
  if (status) { if (value) lean_dec(value); return status; }
  if (!ov_carrier(value)) { if (value) lean_dec(value); return OV_RESULT; }
  lean_object *child = lean_array_get_core(value, 0); lean_inc(child); lean_dec(value);
  if (lean_is_scalar(child) || !lean_is_string(child)) { lean_dec(child); return OV_RESULT; }
  size_t length = lean_string_size(child) - 1;
  if (!ov_utf8((const uint8_t *)lean_string_cstr(child), length)) { lean_dec(child); return OV_RESULT; }
  void *data = NULL;
  status = ov_allocate(transaction, length, 1, &data);
  if (!status) {
    if (length) memcpy(data, lean_string_cstr(child), length);
    out->data = data; out->length = length;
  }
  lean_dec(child); return status;
}
static inline int lbov_9d942cb14affa6e2c46c_f483485736ace9af57086(lb_owned_context *context, const lbov_9d942cb14affa6e2c46c_td79b9bbde250ee1779da *a0, lbov_9d942cb14affa6e2c46c_t160ce821a84f6887bbfd *out, ov_result_owner *owner) {
  if (!ov_pointer(out, sizeof(*out), _Alignof(lbov_9d942cb14affa6e2c46c_t160ce821a84f6887bbfd)) || !ov_pointer(owner, sizeof(*owner), _Alignof(ov_result_owner))) return LB_OWNED_INVALID;
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  status = ov_charge(&transaction.budget, 1, sizeof(*out));
  if (status) return ov_abort(&transaction, status);
  lean_object *arguments = lean_alloc_array(0, 1);
  {
    lean_object *child = NULL;
    status = lbov_9d942cb14affa6e2c46c_vd79b9bbde250ee1779da_in(a0, 0, 1, &transaction, &child);
    if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
    arguments = lean_array_push(arguments, child);
  }
  lean_object *v0 = lean_array_get_core(arguments, 0); lean_inc(v0);
  lean_dec(arguments);
  ov_callback_frame frame = { .parent = ov_active_callback_frame, .transaction = &transaction };
  if (!frame.parent) { (void)lb_native_callback_take_error(); (void)lean_bridge_owned_callback_failure_9d942cb14affa6e2c46c(); }
  ov_active_callback_frame = &frame;
  lean_object *returned = lean_bridge_owned_c37ce895564546da1673e4bf_f483485736ace9af57086(v0);
  ov_active_callback_frame = frame.parent; status = frame.status;
  int callback_error = lb_native_callback_take_error();
  int refinement_error = lean_bridge_owned_callback_failure_9d942cb14affa6e2c46c();
  if (refinement_error && !status) status = LB_OWNED_INVALID;
  else if (callback_error && !status) status = OV_CALLBACK;
  if (!status) status = lb_owned_scope_ready(&transaction.scope);
  if (status) { lean_dec(returned); return ov_abort(&transaction, status); }
  lbov_9d942cb14affa6e2c46c_t160ce821a84f6887bbfd converted = {0};
  status = lbov_9d942cb14affa6e2c46c_v160ce821a84f6887bbfd_out(&converted, returned, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  status = ov_commit(&transaction, owner);
  if (!status) *out = converted;
  return status;
}
static inline int lbov_9d942cb14affa6e2c46c_fa1e5189bd92568e4b939(lb_owned_context *context, const lbov_9d942cb14affa6e2c46c_t167081552b6f9c1d1afd *a0, const lbov_9d942cb14affa6e2c46c_tdc0347e1f7f5c4d928f1 *a1, lbov_9d942cb14affa6e2c46c_td79b9bbde250ee1779da *out, ov_result_owner *owner) {
  if (!ov_pointer(out, sizeof(*out), _Alignof(lbov_9d942cb14affa6e2c46c_td79b9bbde250ee1779da)) || !ov_pointer(owner, sizeof(*owner), _Alignof(ov_result_owner))) return LB_OWNED_INVALID;
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  status = ov_charge(&transaction.budget, 1, sizeof(*out));
  if (status) return ov_abort(&transaction, status);
  lean_object *arguments = lean_alloc_array(0, 2);
  {
    lean_object *child = NULL;
    status = lbov_9d942cb14affa6e2c46c_v167081552b6f9c1d1afd_in(a0, 0, 1, &transaction, &child);
    if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
    arguments = lean_array_push(arguments, child);
  }
  {
    lean_object *child = NULL;
    status = lbov_9d942cb14affa6e2c46c_vdc0347e1f7f5c4d928f1_in(a1, 0, 1, &transaction, &child);
    if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
    arguments = lean_array_push(arguments, child);
  }
  lean_object *v0 = lean_array_get_core(arguments, 0); lean_inc(v0);
  lean_object *v1 = lean_array_get_core(arguments, 1); lean_inc(v1);
  lean_dec(arguments);
  ov_callback_frame frame = { .parent = ov_active_callback_frame, .transaction = &transaction };
  if (!frame.parent) { (void)lb_native_callback_take_error(); (void)lean_bridge_owned_callback_failure_9d942cb14affa6e2c46c(); }
  ov_active_callback_frame = &frame;
  lean_object *returned = lean_bridge_owned_c37ce895564546da1673e4bf_fa1e5189bd92568e4b939(v0, v1);
  ov_active_callback_frame = frame.parent; status = frame.status;
  int callback_error = lb_native_callback_take_error();
  int refinement_error = lean_bridge_owned_callback_failure_9d942cb14affa6e2c46c();
  if (refinement_error && !status) status = LB_OWNED_INVALID;
  else if (callback_error && !status) status = OV_CALLBACK;
  if (!status) status = lb_owned_scope_ready(&transaction.scope);
  if (status) { lean_dec(returned); return ov_abort(&transaction, status); }
  lbov_9d942cb14affa6e2c46c_td79b9bbde250ee1779da converted = {0};
  status = lbov_9d942cb14affa6e2c46c_vd79b9bbde250ee1779da_out(&converted, returned, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  status = ov_commit(&transaction, owner);
  if (!status) *out = converted;
  return status;
}
static inline int lbov_9d942cb14affa6e2c46c_fec926afda994fba3abe2(lb_owned_context *context, const lbov_9d942cb14affa6e2c46c_td79b9bbde250ee1779da *a0, lbov_9d942cb14affa6e2c46c_t167081552b6f9c1d1afd *out, ov_result_owner *owner) {
  if (!ov_pointer(out, sizeof(*out), _Alignof(lbov_9d942cb14affa6e2c46c_t167081552b6f9c1d1afd)) || !ov_pointer(owner, sizeof(*owner), _Alignof(ov_result_owner))) return LB_OWNED_INVALID;
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  status = ov_charge(&transaction.budget, 1, sizeof(*out));
  if (status) return ov_abort(&transaction, status);
  lean_object *arguments = lean_alloc_array(0, 1);
  {
    lean_object *child = NULL;
    status = lbov_9d942cb14affa6e2c46c_vd79b9bbde250ee1779da_in(a0, 0, 1, &transaction, &child);
    if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
    arguments = lean_array_push(arguments, child);
  }
  lean_object *v0 = lean_array_get_core(arguments, 0); lean_inc(v0);
  lean_dec(arguments);
  ov_callback_frame frame = { .parent = ov_active_callback_frame, .transaction = &transaction };
  if (!frame.parent) { (void)lb_native_callback_take_error(); (void)lean_bridge_owned_callback_failure_9d942cb14affa6e2c46c(); }
  ov_active_callback_frame = &frame;
  lean_object *returned = lean_bridge_owned_c37ce895564546da1673e4bf_fec926afda994fba3abe2(v0);
  ov_active_callback_frame = frame.parent; status = frame.status;
  int callback_error = lb_native_callback_take_error();
  int refinement_error = lean_bridge_owned_callback_failure_9d942cb14affa6e2c46c();
  if (refinement_error && !status) status = LB_OWNED_INVALID;
  else if (callback_error && !status) status = OV_CALLBACK;
  if (!status) status = lb_owned_scope_ready(&transaction.scope);
  if (status) { lean_dec(returned); return ov_abort(&transaction, status); }
  lbov_9d942cb14affa6e2c46c_t167081552b6f9c1d1afd converted = {0};
  status = lbov_9d942cb14affa6e2c46c_v167081552b6f9c1d1afd_out(&converted, returned, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  status = ov_commit(&transaction, owner);
  if (!status) *out = converted;
  return status;
}


_Static_assert(sizeof(bool) == 1, "owned C values require one-byte bool storage");
typedef struct oc_block {
  struct oc_block *next;
  int integer_initialized;
  mpz_t integer;
  max_align_t alignment;
  unsigned char data[];
} oc_block;
typedef struct { oc_block *head; ov_budget *budget; } oc_arena;
typedef struct oc_session oc_session;
typedef struct oc_result {
  struct oc_result *next;
  uint64_t key;
  oc_session *session;
  ov_result_owner native;
  oc_block *blocks;
} oc_result;
struct oc_session {
  oc_session *next;
  uint64_t key;
  lb_owned_context native;
  size_t results, calls;
  int closed;
};
static _Thread_local oc_session *oc_sessions;
static _Thread_local oc_result *oc_results;
extern lean_object *initialize_LeanBridgeOwned1294136f0eb898e0(uint8_t);
static void *oc_initialize(uint8_t builtin) { return initialize_LeanBridgeOwned1294136f0eb898e0(builtin); }

static inline void oc_release(oc_block *block) {
  while (block) {
    oc_block *next = block->next;
    if (block->integer_initialized) mpz_clear(block->integer);
    LB_OWNED_FREE(block); block = next;
  }
}
static inline int oc_block_new(oc_arena *arena, size_t count, size_t width, oc_block **out) {
  int status = ov_charge(arena->budget, count, width);
  if (!status) status = ov_charge(arena->budget, 1, sizeof(oc_block));
  if (status) return status;
  oc_block *block = LB_OWNED_ALLOC(sizeof(*block) + count * width);
  if (!block) return LB_OWNED_ALLOC_FAILED;
  memset(block, 0, sizeof(*block) + count * width);
  block->next = arena->head; arena->head = block; *out = block;
  return LB_OWNED_OK;
}
static inline int oc_allocate(oc_arena *arena, size_t count, size_t width, void **out) {
  *out = NULL; if (!count) return LB_OWNED_OK;
  oc_block *block; int status = oc_block_new(arena, count, width, &block);
  if (!status) *out = block->data;
  return status;
}
static inline int oc_integer(oc_arena *arena, const uint32_t *limbs, size_t length, int negative, mpz_srcptr *out) {
  int status = ov_span(arena->budget, limbs, length, sizeof(uint32_t), _Alignof(uint32_t));
  if (status) return status;
  size_t bits = length * 32, count = bits / GMP_NUMB_BITS + (bits % GMP_NUMB_BITS != 0);
  status = ov_charge(arena->budget, count, sizeof(mp_limb_t));
  if (status) return status;
  oc_block *block; status = oc_block_new(arena, 0, 1, &block);
  if (status) return status;
  mpz_init(block->integer); block->integer_initialized = 1;
  if (length) mpz_import(block->integer, length, -1, sizeof(uint32_t), 0, 0, limbs);
  if (negative) mpz_neg(block->integer, block->integer);
  *out = block->integer; return LB_OWNED_OK;
}
static inline oc_session *oc_session_find(const owned_checked_records_session *key) {
  for (oc_session *item = oc_sessions; item; item = item->next)
    if (item->key == (uint64_t)(uintptr_t)key) return item;
  return NULL;
}
static inline int oc_session_get(const owned_checked_records_session *key, oc_session **out) {
  if (!lean_bridge_native_process_valid()) return LB_OWNED_PROCESS;
  oc_session *session = oc_session_find(key);
  if (!session) return LB_OWNED_INVALID;
  if (session->closed) return LB_OWNED_CLOSED;
  int status = lb_owned_ready(&session->native);
  if (!status) *out = session;
  return status;
}
static inline void oc_session_collect(oc_session *session) {
  if (!session->closed || session->results || session->calls) return;
  oc_session **slot = &oc_sessions;
  while (*slot != session) slot = &(*slot)->next;
  *slot = session->next;
  (void)lean_bridge_native_identity_release(session->key, "owned-c-session:owned-checked-records@1.0.0", session);
  LB_OWNED_FREE(session);
}
owned_checked_records_status owned_checked_records_session_open(owned_checked_records_session **out) {
  if (!ov_pointer(out, sizeof(*out), _Alignof(owned_checked_records_session *)) || *out) return (owned_checked_records_status)LB_OWNED_INVALID;
  if (!lean_bridge_native_process_valid()) return (owned_checked_records_status)LB_OWNED_PROCESS;
  if (!lean_bridge_native_component_initialize("owned-checked-records@1.0.0", oc_initialize)) return (owned_checked_records_status)LB_OWNED_RUNTIME;
  oc_session *session = LB_OWNED_ALLOC(sizeof(*session));
  if (!session) return (owned_checked_records_status)LB_OWNED_ALLOC_FAILED;
  memset(session, 0, sizeof(*session));
  int status = lb_owned_context_init(&session->native, "owned-checked-records@1.0.0");
  if (status) { LB_OWNED_FREE(session); return (owned_checked_records_status)status; }
  session->key = lean_bridge_native_identity_acquire("owned-c-session:owned-checked-records@1.0.0", session);
  if (!session->key) { lb_owned_context_close(&session->native); LB_OWNED_FREE(session); return (owned_checked_records_status)LB_OWNED_LIMIT; }
  session->next = oc_sessions; oc_sessions = session;
  *out = (owned_checked_records_session *)(uintptr_t)session->key;
  return (owned_checked_records_status)LB_OWNED_OK;
}
owned_checked_records_status owned_checked_records_session_close(owned_checked_records_session **value) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(owned_checked_records_session *))) return (owned_checked_records_status)LB_OWNED_INVALID;
  if (!lean_bridge_native_process_valid()) return (owned_checked_records_status)LB_OWNED_PROCESS;
  if (!*value) return (owned_checked_records_status)LB_OWNED_OK;
  oc_session *session = oc_session_find(*value);
  if (!session) return (owned_checked_records_status)LB_OWNED_INVALID;
  if (session->closed) return (owned_checked_records_status)LB_OWNED_CLOSED;
  int status = lb_owned_context_close(&session->native);
  if (status) return (owned_checked_records_status)status;
  session->closed = 1; *value = NULL;
  oc_session_collect(session); return (owned_checked_records_status)LB_OWNED_OK;
}
owned_checked_records_status owned_checked_records_result_release(owned_checked_records_result **value) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(owned_checked_records_result *))) return (owned_checked_records_status)LB_OWNED_INVALID;
  if (!lean_bridge_native_process_valid()) return (owned_checked_records_status)LB_OWNED_PROCESS;
  if (!*value) return (owned_checked_records_status)LB_OWNED_OK;
  oc_result **slot = &oc_results;
  while (*slot && (*slot)->key != (uint64_t)(uintptr_t)*value) slot = &(*slot)->next;
  if (!*slot) return (owned_checked_records_status)LB_OWNED_INVALID;
  oc_result *result = *slot; oc_session *session = result->session;
  int status = ov_owner_clear(&result->native);
  if (!ov_owner_empty(&result->native)) return (owned_checked_records_status)status;
  *slot = result->next; --session->results;
  if (lean_bridge_native_identity_release(result->key, "owned-c-result:owned-checked-records@1.0.0", result) < 0 && !status) status = LB_OWNED_RUNTIME;
  oc_release(result->blocks); LB_OWNED_FREE(result); *value = NULL;
  oc_session_collect(session); return (owned_checked_records_status)status;
}
static inline int oc_result_begin(oc_session *session, ov_budget *budget, oc_result **out) {
  if (session->calls == LB_OWNED_SCOPE_LIMIT) return LB_OWNED_LIMIT;
  int status = ov_charge(budget, 1, sizeof(oc_result));
  if (status) return status;
  oc_result *result = LB_OWNED_ALLOC(sizeof(*result));
  if (!result) return LB_OWNED_ALLOC_FAILED;
  memset(result, 0, sizeof(*result)); result->session = session;
  ++session->calls; *out = result; return LB_OWNED_OK;
}
static inline int oc_result_finish(oc_result *result, oc_arena *output, int status, owned_checked_records_result **owner) {
  oc_session *session = result->session;
  if (status == OV_RESULT) lean_bridge_native_runtime_retire();
  if (!status) status = lb_owned_ready(&session->native);
  if (!status) {
    result->key = lean_bridge_native_identity_acquire("owned-c-result:owned-checked-records@1.0.0", result);
    if (!result->key) status = LB_OWNED_LIMIT;
  }
  if (!status) {
    result->blocks = output->head; output->head = NULL;
    result->next = oc_results; oc_results = result; ++session->results;
    *owner = (owned_checked_records_result *)(uintptr_t)result->key;
  } else {
    (void)ov_owner_clear(&result->native);
    oc_release(output->head); output->head = NULL; LB_OWNED_FREE(result);
  }
  --session->calls; oc_session_collect(session); return status;
}
static inline ov_budget oc_budget(void) {
  return (ov_budget){ .bytes = 16777216, .visits = 262144 };
}
static inline int oc_outputs(const void *out, size_t bytes, size_t alignment, const void *owner) {
  if (!ov_pointer(out, bytes, alignment) || !ov_pointer(owner, sizeof(void *), _Alignof(void *))) return 0;
  uintptr_t a = (uintptr_t)out, b = (uintptr_t)owner;
  return a < b ? bytes <= b - a : sizeof(void *) <= a - b;
}

static inline int oc_v0_to(owned_checked_records_value_160ce821a84f6887bbfd_t const *, lbov_9d942cb14affa6e2c46c_t160ce821a84f6887bbfd *, size_t, oc_arena *);
static inline int oc_v0_from(const lbov_9d942cb14affa6e2c46c_t160ce821a84f6887bbfd *, owned_checked_records_value_160ce821a84f6887bbfd_t *, size_t, oc_arena *);
static inline int oc_v1_to(owned_checked_records_claim_t const *, lbov_9d942cb14affa6e2c46c_tb2825946e038e653bd2b *, size_t, oc_arena *);
static inline int oc_v1_from(const lbov_9d942cb14affa6e2c46c_tb2825946e038e653bd2b *, owned_checked_records_claim_t *, size_t, oc_arena *);
static inline int oc_v2_to(owned_checked_records_ticket_t const *, lbov_9d942cb14affa6e2c46c_td79b9bbde250ee1779da *, size_t, oc_arena *);
static inline int oc_v2_from(const lbov_9d942cb14affa6e2c46c_td79b9bbde250ee1779da *, owned_checked_records_ticket_t *, size_t, oc_arena *);
static inline int oc_v3_to(mpz_srcptr const *, lbov_9d942cb14affa6e2c46c_t167081552b6f9c1d1afd *, size_t, oc_arena *);
static inline int oc_v3_from(const lbov_9d942cb14affa6e2c46c_t167081552b6f9c1d1afd *, mpz_srcptr *, size_t, oc_arena *);
static inline int oc_v4_to(owned_checked_records_scalar_string_t const *, lbov_9d942cb14affa6e2c46c_tdc0347e1f7f5c4d928f1 *, size_t, oc_arena *);
static inline int oc_v4_from(const lbov_9d942cb14affa6e2c46c_tdc0347e1f7f5c4d928f1 *, owned_checked_records_scalar_string_t *, size_t, oc_arena *);
static inline int oc_v0_to(owned_checked_records_value_160ce821a84f6887bbfd_t const *value, lbov_9d942cb14affa6e2c46c_t160ce821a84f6887bbfd *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(owned_checked_records_value_160ce821a84f6887bbfd_t))) return LB_OWNED_INVALID;
  int status = ov_enter(arena->budget, value, 0, depth);
  if (status) return status;
  (void)out;
  uint8_t selected; memcpy(&selected, &value->has_value, 1);
  if (selected > 1) return LB_OWNED_INVALID;
  out->tag = selected;
  if (out->tag == 1) {
  {
    void *data = NULL;
    status = oc_allocate(arena, 1, sizeof(lbov_9d942cb14affa6e2c46c_tb2825946e038e653bd2b), &data);
    if (status) return status;
    out->f0 = data;
    status = oc_v1_to(value->value, data, depth + 1, arena);
    if (status) return status;
  }
  }
  return LB_OWNED_OK;
}
static inline int oc_v0_from(const lbov_9d942cb14affa6e2c46c_t160ce821a84f6887bbfd *value, owned_checked_records_value_160ce821a84f6887bbfd_t *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_9d942cb14affa6e2c46c_t160ce821a84f6887bbfd))) return OV_RESULT;
  int status = ov_enter(arena->budget, value, 0, depth);
  if (status) return status;
  (void)out;
  if (value->tag > 1) return OV_RESULT;
  out->has_value = value->tag != 0;
  if (value->tag == 1) {
  {
    void *data = NULL;
    status = oc_allocate(arena, 1, sizeof(owned_checked_records_claim_t), &data);
    if (status) return status;
    out->value = data;
    status = oc_v1_from(value->f0, data, depth + 1, arena);
    if (status) return status;
  }
  }
  return LB_OWNED_OK;
}
static inline int oc_v1_to(owned_checked_records_claim_t const *value, lbov_9d942cb14affa6e2c46c_tb2825946e038e653bd2b *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(owned_checked_records_claim_t))) return LB_OWNED_INVALID;
  int status = ov_enter(arena->budget, value, 1, depth);
  if (status) return status;
  (void)out;
  {
    status = oc_v2_to(&value->holder, &out->f0, depth + 1, arena);
    if (status) return status;
  }
  {
    status = oc_v3_to(&value->quota, &out->f1, depth + 1, arena);
    if (status) return status;
  }
  return LB_OWNED_OK;
}
static inline int oc_v1_from(const lbov_9d942cb14affa6e2c46c_tb2825946e038e653bd2b *value, owned_checked_records_claim_t *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_9d942cb14affa6e2c46c_tb2825946e038e653bd2b))) return OV_RESULT;
  int status = ov_enter(arena->budget, value, 1, depth);
  if (status) return status;
  (void)out;
  {
    status = oc_v2_from(&value->f0, &out->holder, depth + 1, arena);
    if (status) return status;
  }
  {
    status = oc_v3_from(&value->f1, &out->quota, depth + 1, arena);
    if (status) return status;
  }
  return LB_OWNED_OK;
}
static inline int oc_v2_to(owned_checked_records_ticket_t const *value, lbov_9d942cb14affa6e2c46c_td79b9bbde250ee1779da *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(owned_checked_records_ticket_t))) return LB_OWNED_INVALID;
  int status = ov_enter(arena->budget, value, 2, depth);
  if (status) return status;
  (void)out;
  if (!*value) return LB_OWNED_INVALID;
  out->token = (uint64_t)(uintptr_t)*value;
  return LB_OWNED_OK;
}
static inline int oc_v2_from(const lbov_9d942cb14affa6e2c46c_td79b9bbde250ee1779da *value, owned_checked_records_ticket_t *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_9d942cb14affa6e2c46c_td79b9bbde250ee1779da))) return OV_RESULT;
  int status = ov_enter(arena->budget, value, 2, depth);
  if (status) return status;
  (void)out;
  if (!value->token) return OV_RESULT;
  *out = (owned_checked_records_ticket_t)(uintptr_t)value->token;
  return LB_OWNED_OK;
}
static inline int oc_v3_to(mpz_srcptr const *value, lbov_9d942cb14affa6e2c46c_t167081552b6f9c1d1afd *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(mpz_srcptr))) return LB_OWNED_INVALID;
  int status = ov_enter(arena->budget, value, 3, depth);
  if (status) return status;
  (void)out;
  if (!ov_pointer(*value, sizeof(**value), _Alignof(__mpz_struct))) return LB_OWNED_INVALID;
  if (mpz_sgn(*value) < 0) return LB_OWNED_INVALID;
  if (mpz_size(*value) > arena->budget->bytes / sizeof(mp_limb_t) + 1) return LB_OWNED_LIMIT;
  size_t length = mpz_sgn(*value) ? (mpz_sizeinbase(*value, 2) - 1) / 32 + 1 : 0;
  void *data = NULL; status = oc_allocate(arena, length, sizeof(uint32_t), &data);
  if (status) return status;
  if (length) mpz_export(data, &length, -1, sizeof(uint32_t), 0, 0, *value);
  out->data = data; out->length = length;
  return LB_OWNED_OK;
}
static inline int oc_v3_from(const lbov_9d942cb14affa6e2c46c_t167081552b6f9c1d1afd *value, mpz_srcptr *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_9d942cb14affa6e2c46c_t167081552b6f9c1d1afd))) return OV_RESULT;
  int status = ov_enter(arena->budget, value, 3, depth);
  if (status) return status;
  (void)out;
  return oc_integer(arena, value->data, value->length, 0, out);
  return LB_OWNED_OK;
}
static inline int oc_v4_to(owned_checked_records_scalar_string_t const *value, lbov_9d942cb14affa6e2c46c_tdc0347e1f7f5c4d928f1 *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(owned_checked_records_scalar_string_t))) return LB_OWNED_INVALID;
  int status = ov_enter(arena->budget, value, 4, depth);
  if (status) return status;
  (void)out;
  status = ov_span(arena->budget, value->data, value->length, 1, 1);
  if (status) return status;
  if (!ov_utf8((const uint8_t *)value->data, value->length)) return LB_OWNED_INVALID;
  out->data = value->data; out->length = value->length;
  return LB_OWNED_OK;
}
static inline int oc_v4_from(const lbov_9d942cb14affa6e2c46c_tdc0347e1f7f5c4d928f1 *value, owned_checked_records_scalar_string_t *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_9d942cb14affa6e2c46c_tdc0347e1f7f5c4d928f1))) return OV_RESULT;
  int status = ov_enter(arena->budget, value, 4, depth);
  if (status) return status;
  (void)out;
  status = ov_span(arena->budget, value->data, value->length, 1, 1);
  if (status) return status;
  if (!ov_utf8((const uint8_t *)value->data, value->length)) return OV_RESULT;
  out->data = value->data; out->length = value->length;
  return LB_OWNED_OK;
}


static inline int lbov_9d942cb14affa6e2c46c_vd79b9bbde250ee1779da_retain(lb_owned_context *context, const lbov_9d942cb14affa6e2c46c_td79b9bbde250ee1779da *input, lbov_9d942cb14affa6e2c46c_td79b9bbde250ee1779da *out, ov_result_owner *owner) {
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  lean_object *value = NULL;
  status = lbov_9d942cb14affa6e2c46c_vd79b9bbde250ee1779da_in(input, 0, 1, &transaction, &value);
  if (status) return ov_abort(&transaction, status);
  status = lbov_9d942cb14affa6e2c46c_vd79b9bbde250ee1779da_out(out, value, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  return ov_commit(&transaction, owner);
}
static inline int lbov_9d942cb14affa6e2c46c_v160ce821a84f6887bbfd_retain(lb_owned_context *context, const lbov_9d942cb14affa6e2c46c_t160ce821a84f6887bbfd *input, lbov_9d942cb14affa6e2c46c_t160ce821a84f6887bbfd *out, ov_result_owner *owner) {
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  lean_object *value = NULL;
  status = lbov_9d942cb14affa6e2c46c_v160ce821a84f6887bbfd_in(input, 0, 1, &transaction, &value);
  if (status) return ov_abort(&transaction, status);
  status = lbov_9d942cb14affa6e2c46c_v160ce821a84f6887bbfd_out(out, value, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  return ov_commit(&transaction, owner);
}
static inline int lbov_9d942cb14affa6e2c46c_vb2825946e038e653bd2b_retain(lb_owned_context *context, const lbov_9d942cb14affa6e2c46c_tb2825946e038e653bd2b *input, lbov_9d942cb14affa6e2c46c_tb2825946e038e653bd2b *out, ov_result_owner *owner) {
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  lean_object *value = NULL;
  status = lbov_9d942cb14affa6e2c46c_vb2825946e038e653bd2b_in(input, 0, 1, &transaction, &value);
  if (status) return ov_abort(&transaction, status);
  status = lbov_9d942cb14affa6e2c46c_vb2825946e038e653bd2b_out(out, value, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  return ov_commit(&transaction, owner);
}
static inline int lbov_9d942cb14affa6e2c46c_v167081552b6f9c1d1afd_retain(lb_owned_context *context, const lbov_9d942cb14affa6e2c46c_t167081552b6f9c1d1afd *input, lbov_9d942cb14affa6e2c46c_t167081552b6f9c1d1afd *out, ov_result_owner *owner) {
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  lean_object *value = NULL;
  status = lbov_9d942cb14affa6e2c46c_v167081552b6f9c1d1afd_in(input, 0, 1, &transaction, &value);
  if (status) return ov_abort(&transaction, status);
  status = lbov_9d942cb14affa6e2c46c_v167081552b6f9c1d1afd_out(out, value, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  return ov_commit(&transaction, owner);
}
static inline int lbov_9d942cb14affa6e2c46c_vdc0347e1f7f5c4d928f1_retain(lb_owned_context *context, const lbov_9d942cb14affa6e2c46c_tdc0347e1f7f5c4d928f1 *input, lbov_9d942cb14affa6e2c46c_tdc0347e1f7f5c4d928f1 *out, ov_result_owner *owner) {
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  lean_object *value = NULL;
  status = lbov_9d942cb14affa6e2c46c_vdc0347e1f7f5c4d928f1_in(input, 0, 1, &transaction, &value);
  if (status) return ov_abort(&transaction, status);
  status = lbov_9d942cb14affa6e2c46c_vdc0347e1f7f5c4d928f1_out(out, value, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  return ov_commit(&transaction, owner);
}
owned_checked_records_status owned_checked_records_claim_for(owned_checked_records_session *session, owned_checked_records_ticket_t a0, owned_checked_records_value_160ce821a84f6887bbfd_t *out, owned_checked_records_result **owner) {
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_checked_records_value_160ce821a84f6887bbfd_t), owner) || *owner) return (owned_checked_records_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_status)status;
  lbov_9d942cb14affa6e2c46c_td79b9bbde250ee1779da raw0 = {0};
  lbov_9d942cb14affa6e2c46c_t160ce821a84f6887bbfd returned = {0};
  owned_checked_records_value_160ce821a84f6887bbfd_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v2_to(&a0, &raw0, 0, &input);
  if (!status) status = lbov_9d942cb14affa6e2c46c_f483485736ace9af57086(&active->native, &raw0, &returned, &result_owner->native);
  if (!status) {
    status = oc_v0_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_status)status;
}
owned_checked_records_status owned_checked_records_new_ticket(owned_checked_records_session *session, mpz_srcptr a0, owned_checked_records_scalar_string_t a1, owned_checked_records_ticket_t *out, owned_checked_records_result **owner) {
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_checked_records_ticket_t), owner) || *owner) return (owned_checked_records_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_status)status;
  lbov_9d942cb14affa6e2c46c_t167081552b6f9c1d1afd raw0 = {0};
  lbov_9d942cb14affa6e2c46c_tdc0347e1f7f5c4d928f1 raw1 = {0};
  lbov_9d942cb14affa6e2c46c_td79b9bbde250ee1779da returned = {0};
  owned_checked_records_ticket_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v3_to(&a0, &raw0, 0, &input);
  if (!status) status = oc_v4_to(&a1, &raw1, 0, &input);
  if (!status) status = lbov_9d942cb14affa6e2c46c_fa1e5189bd92568e4b939(&active->native, &raw0, &raw1, &returned, &result_owner->native);
  if (!status) {
    status = oc_v2_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_status)status;
}
owned_checked_records_status owned_checked_records_serial(owned_checked_records_session *session, owned_checked_records_ticket_t a0, mpz_srcptr *out, owned_checked_records_result **owner) {
  if (!oc_outputs(out, sizeof(*out), _Alignof(mpz_srcptr), owner) || *owner) return (owned_checked_records_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_status)status;
  lbov_9d942cb14affa6e2c46c_td79b9bbde250ee1779da raw0 = {0};
  lbov_9d942cb14affa6e2c46c_t167081552b6f9c1d1afd returned = {0};
  mpz_srcptr converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v2_to(&a0, &raw0, 0, &input);
  if (!status) status = lbov_9d942cb14affa6e2c46c_fec926afda994fba3abe2(&active->native, &raw0, &returned, &result_owner->native);
  if (!status) {
    status = oc_v3_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_status)status;
}
owned_checked_records_status owned_checked_records_ticket_t_retain(owned_checked_records_session *session, owned_checked_records_ticket_t a0, owned_checked_records_ticket_t *out, owned_checked_records_result **owner) {
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_checked_records_ticket_t), owner) || *owner) return (owned_checked_records_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_status)status;
  lbov_9d942cb14affa6e2c46c_td79b9bbde250ee1779da raw0 = {0};
  lbov_9d942cb14affa6e2c46c_td79b9bbde250ee1779da returned = {0};
  owned_checked_records_ticket_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v2_to(&a0, &raw0, 0, &input);
  if (!status) status = lbov_9d942cb14affa6e2c46c_vd79b9bbde250ee1779da_retain(&active->native, &raw0, &returned, &result_owner->native);
  if (!status) {
    status = oc_v2_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_status)status;
}
owned_checked_records_status owned_checked_records_value_160ce821a84f6887bbfd_t_copy(owned_checked_records_session *session, owned_checked_records_value_160ce821a84f6887bbfd_t const * a0, owned_checked_records_value_160ce821a84f6887bbfd_t *out, owned_checked_records_result **owner) {
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_checked_records_value_160ce821a84f6887bbfd_t), owner) || *owner) return (owned_checked_records_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_status)status;
  lbov_9d942cb14affa6e2c46c_t160ce821a84f6887bbfd raw0 = {0};
  lbov_9d942cb14affa6e2c46c_t160ce821a84f6887bbfd returned = {0};
  owned_checked_records_value_160ce821a84f6887bbfd_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v0_to(a0, &raw0, 0, &input);
  if (!status) status = lbov_9d942cb14affa6e2c46c_v160ce821a84f6887bbfd_retain(&active->native, &raw0, &returned, &result_owner->native);
  if (!status) {
    status = oc_v0_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_status)status;
}
owned_checked_records_status owned_checked_records_claim_t_copy(owned_checked_records_session *session, owned_checked_records_claim_t const * a0, owned_checked_records_claim_t *out, owned_checked_records_result **owner) {
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_checked_records_claim_t), owner) || *owner) return (owned_checked_records_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_status)status;
  lbov_9d942cb14affa6e2c46c_tb2825946e038e653bd2b raw0 = {0};
  lbov_9d942cb14affa6e2c46c_tb2825946e038e653bd2b returned = {0};
  owned_checked_records_claim_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v1_to(a0, &raw0, 0, &input);
  if (!status) status = lbov_9d942cb14affa6e2c46c_vb2825946e038e653bd2b_retain(&active->native, &raw0, &returned, &result_owner->native);
  if (!status) {
    status = oc_v1_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_status)status;
}
owned_checked_records_status owned_checked_records_scalar_nat_copy(owned_checked_records_session *session, mpz_srcptr a0, mpz_srcptr *out, owned_checked_records_result **owner) {
  if (!oc_outputs(out, sizeof(*out), _Alignof(mpz_srcptr), owner) || *owner) return (owned_checked_records_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_status)status;
  lbov_9d942cb14affa6e2c46c_t167081552b6f9c1d1afd raw0 = {0};
  lbov_9d942cb14affa6e2c46c_t167081552b6f9c1d1afd returned = {0};
  mpz_srcptr converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v3_to(&a0, &raw0, 0, &input);
  if (!status) status = lbov_9d942cb14affa6e2c46c_v167081552b6f9c1d1afd_retain(&active->native, &raw0, &returned, &result_owner->native);
  if (!status) {
    status = oc_v3_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_status)status;
}
owned_checked_records_status owned_checked_records_scalar_string_copy(owned_checked_records_session *session, owned_checked_records_scalar_string_t a0, owned_checked_records_scalar_string_t *out, owned_checked_records_result **owner) {
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_checked_records_scalar_string_t), owner) || *owner) return (owned_checked_records_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_status)status;
  lbov_9d942cb14affa6e2c46c_tdc0347e1f7f5c4d928f1 raw0 = {0};
  lbov_9d942cb14affa6e2c46c_tdc0347e1f7f5c4d928f1 returned = {0};
  owned_checked_records_scalar_string_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v4_to(&a0, &raw0, 0, &input);
  if (!status) status = lbov_9d942cb14affa6e2c46c_vdc0347e1f7f5c4d928f1_retain(&active->native, &raw0, &returned, &result_owner->native);
  if (!status) {
    status = oc_v4_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_status)status;
}

#include "owned_checked_records.h"
#include <stdlib.h>
#include <string.h>
#ifndef LB_OWNED_ALLOC
#define LB_OWNED_ALLOC malloc
#define LB_OWNED_FREE free
#endif
owned_checked_records_status owned_checked_records_php_integer_new(const char *text, size_t length, mpz_srcptr *out) {
  if (!out || *out || !text || !length || length > 16385) return OWNED_CHECKED_RECORDS_INVALID_ARGUMENT;
  size_t start = text[0] == '-' ? 1 : 0, digits = length - start;
  if (!digits || digits > 16384 || (text[start] == '0' && (digits != 1 || start))) return OWNED_CHECKED_RECORDS_INVALID_ARGUMENT;
  for (size_t i = start; i < length; ++i) if (text[i] < '0' || text[i] > '9') return OWNED_CHECKED_RECORDS_INVALID_ARGUMENT;
  mpz_ptr number = LB_OWNED_ALLOC(sizeof(*number));
  if (!number) return OWNED_CHECKED_RECORDS_ALLOCATION_FAILED;
  char *copy = LB_OWNED_ALLOC(length + 1);
  if (!copy) { LB_OWNED_FREE(number); return OWNED_CHECKED_RECORDS_ALLOCATION_FAILED; }
  memcpy(copy, text, length); copy[length] = 0;
  mpz_init(number); int status = mpz_set_str(number, copy, 10); LB_OWNED_FREE(copy);
  if (status) { mpz_clear(number); LB_OWNED_FREE(number); return OWNED_CHECKED_RECORDS_INVALID_ARGUMENT; }
  *out = number; return OWNED_CHECKED_RECORDS_OK;
}
void owned_checked_records_php_integer_free(mpz_srcptr *slot) {
  if (!slot || !*slot) return;
  mpz_ptr number = (mpz_ptr)*slot; *slot = NULL;
  mpz_clear(number); LB_OWNED_FREE(number);
}
owned_checked_records_status owned_checked_records_php_integer_text(mpz_srcptr value, char *out, size_t capacity, size_t *written) {
  if (!written || !value) return OWNED_CHECKED_RECORDS_MALFORMED_RESULT;
  *written = 0;
  size_t digits = mpz_sizeinbase(value, 10), sign = mpz_sgn(value) < 0 ? 1 : 0;
  /* GMP may overestimate the decimal digit count by one. */
  if (digits > 16385) return OWNED_CHECKED_RECORDS_LIMIT;
  size_t required = digits + sign + 1;
  if (!out) {
    if (capacity) return OWNED_CHECKED_RECORDS_INVALID_ARGUMENT;
    *written = required; return OWNED_CHECKED_RECORDS_OK;
  }
  if (capacity < required) return OWNED_CHECKED_RECORDS_INVALID_ARGUMENT;
  mpz_get_str(out, 10, value); size_t actual = strlen(out);
  if (actual - sign > 16384) return OWNED_CHECKED_RECORDS_LIMIT;
  *written = actual; return OWNED_CHECKED_RECORDS_OK;
}

