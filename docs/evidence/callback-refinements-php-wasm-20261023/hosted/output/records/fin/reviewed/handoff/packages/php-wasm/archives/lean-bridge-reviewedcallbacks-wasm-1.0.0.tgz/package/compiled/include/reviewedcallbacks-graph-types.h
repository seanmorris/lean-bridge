#ifndef REVIEWEDCALLBACKS_COPIED_GRAPH_H
#define REVIEWEDCALLBACKS_COPIED_GRAPH_H
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <string.h>

typedef struct reviewedcallbacks_graph_fe146e5012c4f116e9b6_t reviewedcallbacks_graph_fe146e5012c4f116e9b6_t;
typedef struct reviewedcallbacks_graph_3dda423e616bb2bf79f0_t reviewedcallbacks_graph_3dda423e616bb2bf79f0_t;
typedef struct reviewedcallbacks_tile_t reviewedcallbacks_tile_t;
typedef struct reviewedcallbacks_scalar_nat_t reviewedcallbacks_scalar_nat_t;
struct reviewedcallbacks_graph_fe146e5012c4f116e9b6_t {
  void *_bridge_owner;
  void (*_bridge_release)(void *owner);
  const reviewedcallbacks_tile_t *data;
  size_t length;
};
static inline void reviewedcallbacks_graph_fe146e5012c4f116e9b6_t_init(reviewedcallbacks_graph_fe146e5012c4f116e9b6_t *value) {
  if (!value) return;
  memset(value, 0, sizeof(*value));
}
static inline void reviewedcallbacks_graph_fe146e5012c4f116e9b6_t_clear(reviewedcallbacks_graph_fe146e5012c4f116e9b6_t *value) {
  if (!value) return;
  void *owner = value->_bridge_owner;
  void (*release)(void *) = value->_bridge_release;
  reviewedcallbacks_graph_fe146e5012c4f116e9b6_t_init(value);
  if (owner && release) release(owner);
}

struct reviewedcallbacks_graph_3dda423e616bb2bf79f0_t {
  void *_bridge_owner;
  void (*_bridge_release)(void *owner);
  const reviewedcallbacks_scalar_nat_t *data;
  size_t length;
};
static inline void reviewedcallbacks_graph_3dda423e616bb2bf79f0_t_init(reviewedcallbacks_graph_3dda423e616bb2bf79f0_t *value) {
  if (!value) return;
  memset(value, 0, sizeof(*value));
}
static inline void reviewedcallbacks_graph_3dda423e616bb2bf79f0_t_clear(reviewedcallbacks_graph_3dda423e616bb2bf79f0_t *value) {
  if (!value) return;
  void *owner = value->_bridge_owner;
  void (*release)(void *) = value->_bridge_release;
  reviewedcallbacks_graph_3dda423e616bb2bf79f0_t_init(value);
  if (owner && release) release(owner);
}

struct reviewedcallbacks_scalar_nat_t {
  void *_bridge_owner;
  void (*_bridge_release)(void *owner);
  const uint32_t *data;
  size_t length;
};
static inline void reviewedcallbacks_scalar_nat_t_init(reviewedcallbacks_scalar_nat_t *value) {
  if (!value) return;
  memset(value, 0, sizeof(*value));
}
static inline void reviewedcallbacks_scalar_nat_t_clear(reviewedcallbacks_scalar_nat_t *value) {
  if (!value) return;
  void *owner = value->_bridge_owner;
  void (*release)(void *) = value->_bridge_release;
  reviewedcallbacks_scalar_nat_t_init(value);
  if (owner && release) release(owner);
}

struct reviewedcallbacks_tile_t {
  void *_bridge_owner;
  void (*_bridge_release)(void *owner);
  reviewedcallbacks_scalar_nat_t digit;
  reviewedcallbacks_scalar_nat_t count;
};
static inline void reviewedcallbacks_tile_t_init(reviewedcallbacks_tile_t *value) {
  if (!value) return;
  memset(value, 0, sizeof(*value));
}
static inline void reviewedcallbacks_tile_t_clear(reviewedcallbacks_tile_t *value) {
  if (!value) return;
  void *owner = value->_bridge_owner;
  void (*release)(void *) = value->_bridge_release;
  reviewedcallbacks_tile_t_init(value);
  if (owner && release) release(owner);
}


#endif /* REVIEWEDCALLBACKS_COPIED_GRAPH_H */
