import ReviewedCallbacks
set_option maxRecDepth 10000
namespace LeanBridgeNative99d469b3ee044240
def carrierValue {α : Type} (value : _root_.Array α) : _root_.Option α :=
  if bound : 0 < value.size then
    if value.size == 1 then .some (value[0]'bound) else .none
  else .none

def carrierResult {α : Type} (value : _root_.Option α) : _root_.Array α :=
  match value with | .none => #[] | .some result => #[result]

def carrierCollect {α : Type} (values : _root_.Array (_root_.Array α)) : _root_.Option (_root_.Array α) := Id.run do
  if values.size > 262144 then return .none
  let mut result := #[]
  for value in values do
    match carrierValue value with
    | .none => return .none
    | .some item => result := result.push item
  return .some result

def carrierListItems {α : Type} (values : _root_.List α) : _root_.Array (_root_.Array α) :=
  let rec loop : _root_.Nat → _root_.List α → _root_.Array (_root_.Array α) → _root_.Array (_root_.Array α)
    | 0, _, acc => acc
    | _, [], acc => acc
    | fuel + 1, head :: tail, acc => loop fuel tail (acc.push #[head])
  loop 262145 values #[]

@[export lean_bridge_fa450d817b39ecc8598f3607_recursive_b80133b771640d801c25_make]
def makeb80133b771640d801c25 (a0 : (_root_.Array _root_.Nat)) (a1 : (_root_.Array _root_.Nat)) : (_root_.Array _root_.ReviewedCallbacks.Tile) :=
  carrierResult (do
    let a0 ← carrierValue a0
    let a1 ← carrierValue a1
    let a0 ← (if proof : (a0) < 5 then _root_.Option.some (⟨(a0), proof⟩ : _root_.Fin 5) else _root_.Option.none)
    pure (({ «digit» := a0, «count» := a1 } : _root_.ReviewedCallbacks.Tile))
  )

@[export lean_bridge_fa450d817b39ecc8598f3607_recursive_b80133b771640d801c25_field0]
def field0b80133b771640d801c25 (value : (_root_.Array _root_.ReviewedCallbacks.Tile)) : (_root_.Array _root_.Nat) :=
  carrierResult (do
    let value ← carrierValue value
    pure (value.«digit»).val
  )

@[export lean_bridge_fa450d817b39ecc8598f3607_recursive_b80133b771640d801c25_field1]
def field1b80133b771640d801c25 (value : (_root_.Array _root_.ReviewedCallbacks.Tile)) : (_root_.Array _root_.Nat) :=
  carrierResult (do
    let value ← carrierValue value
    pure value.«count»
  )

@[export lean_bridge_fa450d817b39ecc8598f3607_recursive_ec759c31d2054a0d5114_make]
def makeec759c31d2054a0d5114 (values : _root_.Array (_root_.Array _root_.ReviewedCallbacks.Tile)) : (_root_.Array (_root_.List _root_.ReviewedCallbacks.Tile)) :=
  carrierResult (do
    let values ← carrierCollect values
    pure values.toList
  )

@[export lean_bridge_fa450d817b39ecc8598f3607_recursive_ec759c31d2054a0d5114_items]
def itemsec759c31d2054a0d5114 (value : (_root_.Array (_root_.List _root_.ReviewedCallbacks.Tile))) : (_root_.Array (_root_.Array _root_.ReviewedCallbacks.Tile)) :=
  match carrierValue value with
  | .none => #[]
  | .some values => carrierListItems values

@[export lean_bridge_fa450d817b39ecc8598f3607_recursive_32e4ced859935847a5f5_make]
def make32e4ced859935847a5f5 (values : _root_.Array (_root_.Array _root_.Nat)) : (_root_.Array (_root_.Array _root_.Nat)) :=
  carrierResult (do
    let values ← carrierCollect values
    pure values
  )

@[export lean_bridge_fa450d817b39ecc8598f3607_recursive_32e4ced859935847a5f5_items]
def items32e4ced859935847a5f5 (value : (_root_.Array (_root_.Array _root_.Nat))) : (_root_.Array (_root_.Array _root_.Nat)) :=
  match carrierValue value with
  | .none => #[]
  | .some values => (values.extract 0 262145).map (fun child => #[child])

def callbackDefault_b80133b771640d801c25 : _root_.ReviewedCallbacks.Tile := { «digit» := (⟨0, by decide⟩ : _root_.Fin 5), «count» := 0 }

@[extern "lean_bridge_fa450d817b39ecc8598f3607_structured_1c8c62ab9d1ea80d3641b41193c41bc6de9a3096_invoke"]
opaque invoke_1c8c62ab9d1ea80d3641b41193c41bc6de9a3096 (token : _root_.USize) (a0 : (_root_.Array _root_.Nat)) : (_root_.Array _root_.Nat) := #[]

@[extern "lean_bridge_fa450d817b39ecc8598f3607_structured_1c8c62ab9d1ea80d3641b41193c41bc6de9a3096_recovery"]
opaque recovery_1c8c62ab9d1ea80d3641b41193c41bc6de9a3096 (token : _root_.USize) : (_root_.Array _root_.Nat) := #[]

@[extern "lean_bridge_fa450d817b39ecc8598f3607_structured_1c8c62ab9d1ea80d3641b41193c41bc6de9a3096_reject"]
opaque reject_1c8c62ab9d1ea80d3641b41193c41bc6de9a3096 (token : _root_.USize) (recovery : (_root_.Array _root_.Nat)) : (_root_.Array _root_.Nat) := recovery

@[export lean_bridge_fa450d817b39ecc8598f3607_structured_1c8c62ab9d1ea80d3641b41193c41bc6de9a3096_wrap]
def wrap_1c8c62ab9d1ea80d3641b41193c41bc6de9a3096 (token : _root_.USize) : (_root_.Array _root_.USize) := #[token]

@[export lean_bridge_fa450d817b39ecc8598f3607_structured_c9f9ab9808d5ed4cd9eb0c5380d7151c17138950_apply]
def apply_c9f9ab9808d5ed4cd9eb0c5380d7151c17138950 (closure : (_root_.Array (_root_.Nat → (_root_.Option _root_.Nat)))) (a0 : (_root_.Array _root_.Nat)) : (_root_.Array _root_.Nat) :=
  carrierResult (do
    let closure ← carrierValue closure
    let a0 ← carrierValue a0
    let result ← closure a0
    pure result
  )

@[export lean_bridge_fa450d817b39ecc8598f3607_structured_423e0c37f5780352153f2e471aebd23d81e23f74_apply]
def apply_423e0c37f5780352153f2e471aebd23d81e23f74 (closure : (_root_.Array ((_root_.Array _root_.Nat) → (_root_.Option _root_.Nat)))) (a0 : (_root_.Array (_root_.Array _root_.Nat))) : (_root_.Array _root_.Nat) :=
  carrierResult (do
    let closure ← carrierValue closure
    let a0 ← carrierValue a0
    let result ← closure a0
    pure result
  )

@[extern "lean_bridge_fa450d817b39ecc8598f3607_structured_ce903715575b2b74e1c334bc071ce4eceaad0558_invoke"]
opaque invoke_ce903715575b2b74e1c334bc071ce4eceaad0558 (token : _root_.USize) (a0 : (_root_.Array (_root_.List _root_.ReviewedCallbacks.Tile))) : (_root_.Array _root_.Nat) := #[]

@[export lean_bridge_fa450d817b39ecc8598f3607_structured_ce903715575b2b74e1c334bc071ce4eceaad0558_wrap]
def wrap_ce903715575b2b74e1c334bc071ce4eceaad0558 (token : _root_.USize) : (_root_.Array ((_root_.List _root_.ReviewedCallbacks.Tile) → _root_.Nat)) :=
  #[fun a0 =>
    match carrierValue (invoke_ce903715575b2b74e1c334bc071ce4eceaad0558 token #[a0]) with
    | .none => 0
    | .some value => value]

@[export lean_bridge_fa450d817b39ecc8598f3607_structured_ce903715575b2b74e1c334bc071ce4eceaad0558_apply]
def apply_ce903715575b2b74e1c334bc071ce4eceaad0558 (closure : (_root_.Array ((_root_.List _root_.ReviewedCallbacks.Tile) → _root_.Nat))) (a0 : (_root_.Array (_root_.List _root_.ReviewedCallbacks.Tile))) : (_root_.Array _root_.Nat) :=
  carrierResult (do
    let closure ← carrierValue closure
    let a0 ← carrierValue a0
    pure (closure a0)
  )

@[export lean_bridge_fa450d817b39ecc8598f3607_structured_3b911dc0ceee9737631b7e83276319d96008e83d_apply]
def apply_3b911dc0ceee9737631b7e83276319d96008e83d (closure : (_root_.Array (_root_.Nat → (_root_.Option _root_.Nat)))) (a0 : (_root_.Array _root_.Nat)) : (_root_.Array _root_.Nat) :=
  carrierResult (do
    let closure ← carrierValue closure
    let a0 ← carrierValue a0
    let result ← closure a0
    pure result
  )

@[extern "lean_bridge_fa450d817b39ecc8598f3607_structured_ffe59c1b227e089c6c50c0421d94e57562f09578_invoke"]
opaque invoke_ffe59c1b227e089c6c50c0421d94e57562f09578 (token : _root_.USize) (a0 : (_root_.Array _root_.Nat)) : (_root_.Array _root_.Nat) := #[]

@[extern "lean_bridge_fa450d817b39ecc8598f3607_structured_ffe59c1b227e089c6c50c0421d94e57562f09578_recovery"]
opaque recovery_ffe59c1b227e089c6c50c0421d94e57562f09578 (token : _root_.USize) : (_root_.Array _root_.Nat) := #[]

@[extern "lean_bridge_fa450d817b39ecc8598f3607_structured_ffe59c1b227e089c6c50c0421d94e57562f09578_reject"]
opaque reject_ffe59c1b227e089c6c50c0421d94e57562f09578 (token : _root_.USize) (recovery : (_root_.Array _root_.Nat)) : (_root_.Array _root_.Nat) := recovery

@[export lean_bridge_fa450d817b39ecc8598f3607_structured_ffe59c1b227e089c6c50c0421d94e57562f09578_wrap]
def wrap_ffe59c1b227e089c6c50c0421d94e57562f09578 (token : _root_.USize) : (_root_.Array _root_.USize) := #[token]

@[extern "lean_bridge_fa450d817b39ecc8598f3607_structured_d8cf2e9a7b0c40482bf9414b886a3e2086ac2e4e_invoke"]
opaque invoke_d8cf2e9a7b0c40482bf9414b886a3e2086ac2e4e (token : _root_.USize) (a0 : (_root_.Array _root_.Nat)) : (_root_.Array _root_.ReviewedCallbacks.Tile) := #[]

@[export lean_bridge_fa450d817b39ecc8598f3607_structured_d8cf2e9a7b0c40482bf9414b886a3e2086ac2e4e_wrap]
def wrap_d8cf2e9a7b0c40482bf9414b886a3e2086ac2e4e (token : _root_.USize) : (_root_.Array (_root_.Nat → _root_.ReviewedCallbacks.Tile)) :=
  #[fun a0 =>
    match carrierValue (invoke_d8cf2e9a7b0c40482bf9414b886a3e2086ac2e4e token #[a0]) with
    | .none => callbackDefault_b80133b771640d801c25
    | .some value => value]

@[export lean_bridge_fa450d817b39ecc8598f3607_structured_d8cf2e9a7b0c40482bf9414b886a3e2086ac2e4e_apply]
def apply_d8cf2e9a7b0c40482bf9414b886a3e2086ac2e4e (closure : (_root_.Array (_root_.Nat → _root_.ReviewedCallbacks.Tile))) (a0 : (_root_.Array _root_.Nat)) : (_root_.Array _root_.ReviewedCallbacks.Tile) :=
  carrierResult (do
    let closure ← carrierValue closure
    let a0 ← carrierValue a0
    pure (closure a0)
  )

@[extern "lean_bridge_fa450d817b39ecc8598f3607_structured_8a8a1e0d7d82df3b4bfabb94f5d59f8bf4b9ed1d_invoke"]
opaque invoke_8a8a1e0d7d82df3b4bfabb94f5d59f8bf4b9ed1d (token : _root_.USize) (a0 : (_root_.Array _root_.Nat)) : (_root_.Array _root_.Nat) := #[]

@[export lean_bridge_fa450d817b39ecc8598f3607_structured_8a8a1e0d7d82df3b4bfabb94f5d59f8bf4b9ed1d_wrap]
def wrap_8a8a1e0d7d82df3b4bfabb94f5d59f8bf4b9ed1d (token : _root_.USize) : (_root_.Array (_root_.Nat → _root_.Nat)) :=
  #[fun a0 =>
    match carrierValue (invoke_8a8a1e0d7d82df3b4bfabb94f5d59f8bf4b9ed1d token #[a0]) with
    | .none => 0
    | .some value => value]

@[export lean_bridge_fa450d817b39ecc8598f3607_structured_8a8a1e0d7d82df3b4bfabb94f5d59f8bf4b9ed1d_apply]
def apply_8a8a1e0d7d82df3b4bfabb94f5d59f8bf4b9ed1d (closure : (_root_.Array (_root_.Nat → _root_.Nat))) (a0 : (_root_.Array _root_.Nat)) : (_root_.Array _root_.Nat) :=
  carrierResult (do
    let closure ← carrierValue closure
    let a0 ← carrierValue a0
    pure (closure a0)
  )

@[export lean_bridge_fa450d817b39ecc8598f3607_lean]
def export0 (a0 : (_root_.Array (_root_.Nat → _root_.Nat))) (a1 : (_root_.Array _root_.Nat)) : (_root_.Array _root_.Nat) :=
  carrierResult (do
    let a0 ← carrierValue a0
    let a1 ← carrierValue a1
    pure (_root_.ReviewedCallbacks.apply a0 a1)
  )

@[export lean_bridge_53b0de0e75e4c429aaad48c8_lean]
def export1 (a0 : (_root_.Array _root_.Nat)) : (_root_.Array (_root_.Nat → (_root_.Option _root_.Nat))) :=
  carrierResult (do
    let a0 ← carrierValue a0
    do let _bridgeClosure := _root_.ReviewedCallbacks.counter a0; pure (fun (_bridgeCallbackResult_0 : _root_.Nat) => do pure ((_bridgeClosure _bridgeCallbackResult_0).val))
  )

@[export lean_bridge_8477254b8ea47a726adc68ad_lean]
def export2 (a0 : (_root_.Array _root_.Unit)) : (_root_.Array ((_root_.Array _root_.Nat) → (_root_.Option _root_.Nat))) :=
  carrierResult (do
    let a0 ← carrierValue a0
    do let _bridgeClosure := _root_.ReviewedCallbacks.digits a0; pure (fun (_bridgeCallbackResult_0 : (_root_.Array _root_.Nat)) => do let _bridgeCallbackChecked_0 ← ((_bridgeCallbackResult_0).mapM (fun _bridgeValue0 => (if proof : (_bridgeValue0) < 3 then _root_.Option.some (⟨(_bridgeValue0), proof⟩ : _root_.Fin 3) else _root_.Option.none))); pure ((_bridgeClosure _bridgeCallbackChecked_0)))
  )

@[export lean_bridge_fb3aeed37b46e0e2a78ba51c_lean]
def export3 (a0 : (_root_.Array _root_.Nat)) : (_root_.Array (_root_.Nat → (_root_.Option _root_.Nat))) :=
  carrierResult (do
    let a0 ← carrierValue a0
    do let _bridgeClosure := _root_.ReviewedCallbacks.scaler a0; pure (fun (_bridgeCallbackResult_0 : _root_.Nat) => do let _bridgeCallbackChecked_0 ← (if proof : (_bridgeCallbackResult_0) < 10 then _root_.Option.some (⟨(_bridgeCallbackResult_0), proof⟩ : _root_.Fin 10) else _root_.Option.none); pure ((_bridgeClosure _bridgeCallbackChecked_0)))
  )

@[export lean_bridge_2f9e82778120400da600fcee_refinement_1]
def export4_refinement_1 (carrier : _root_.Array _root_.Nat) : _root_.UInt8 :=
  match carrierValue carrier with
  | .none => 0
  | .some value =>
    match (if proof : (value) < 3 then _root_.Option.some (⟨(value), proof⟩ : _root_.Fin 3) else _root_.Option.none) with
    | .some _ => 1
    | .none => 0

@[export lean_bridge_2f9e82778120400da600fcee_lean]
def export4 (a0 : (_root_.Array _root_.USize)) (a1 : (_root_.Array _root_.Nat)) : (_root_.Array _root_.Nat) :=
  carrierResult (do
    let a0 ← carrierValue a0
    let a1 ← carrierValue a1
    let _bridgeRecoveryRaw0 ← carrierValue (recovery_ffe59c1b227e089c6c50c0421d94e57562f09578 a0)
    let _bridgeRecovery0 ← (if proof : (_bridgeRecoveryRaw0) < 3 then _root_.Option.some (⟨(_bridgeRecoveryRaw0), proof⟩ : _root_.Fin 3) else _root_.Option.none)
    if _bridgeFin1 : (a1) < 3 then
      pure ((_root_.ReviewedCallbacks.three (fun _bridgeCallback0_0 => match (do let _bridgeCallbackResult0 ← carrierValue (invoke_ffe59c1b227e089c6c50c0421d94e57562f09578 a0 #[(_bridgeCallback0_0).val]); (if proof : (_bridgeCallbackResult0) < 3 then _root_.Option.some (⟨(_bridgeCallbackResult0), proof⟩ : _root_.Fin 3) else _root_.Option.none)) with | .some value => value | .none => (match (do let value ← carrierValue (reject_ffe59c1b227e089c6c50c0421d94e57562f09578 a0 #[_bridgeRecoveryRaw0]); (if proof : (value) < 3 then _root_.Option.some (⟨(value), proof⟩ : _root_.Fin 3) else _root_.Option.none)) with | .some value => value | .none => _bridgeRecovery0)) ⟨a1, _bridgeFin1⟩).val)
    else
      .none
  )

@[export lean_bridge_e429d90b6e2575f2175e6951_lean]
def export5 (a0 : (_root_.Array _root_.Nat)) : (_root_.Array (_root_.Nat → _root_.ReviewedCallbacks.Tile)) :=
  carrierResult (do
    let a0 ← carrierValue a0
    pure (_root_.ReviewedCallbacks.tileMaker a0)
  )

@[export lean_bridge_b6410c4c69dffaa409842d74_lean]
def export6 (a0 : (_root_.Array _root_.Unit)) : (_root_.Array ((_root_.List _root_.ReviewedCallbacks.Tile) → _root_.Nat)) :=
  carrierResult (do
    let a0 ← carrierValue a0
    pure (_root_.ReviewedCallbacks.tiles a0)
  )

@[export lean_bridge_a4054277eb23862f1406fddb_lean]
def export7 (a0 : (_root_.Array _root_.USize)) : (_root_.Array _root_.Nat) :=
  carrierResult (do
    let a0 ← carrierValue a0
    let _bridgeRecoveryRaw0 ← carrierValue (recovery_1c8c62ab9d1ea80d3641b41193c41bc6de9a3096 a0)
    let _bridgeRecovery0 ← (_root_.Option.some (_bridgeRecoveryRaw0))
    pure (_root_.ReviewedCallbacks.visit (fun _bridgeCallback0_0 => match (do let _bridgeCallbackResult0 ← carrierValue (invoke_1c8c62ab9d1ea80d3641b41193c41bc6de9a3096 a0 #[(_bridgeCallback0_0).val]); (_root_.Option.some (_bridgeCallbackResult0))) with | .some value => value | .none => (match (do let value ← carrierValue (reject_1c8c62ab9d1ea80d3641b41193c41bc6de9a3096 a0 #[_bridgeRecoveryRaw0]); (_root_.Option.some (value))) with | .some value => value | .none => _bridgeRecovery0)))
  )

end LeanBridgeNative99d469b3ee044240
