<?php
declare(strict_types=1);
namespace LeanBridge\CopiedPhpWasmV1 {
if (!class_exists(Loader::class, false)) {
    final class Loader {
        private static ?string $failure = null;
        private static bool $loading = false;
        private static int $callbacks = 0;
        public static function enterCallback(): void { ++self::$callbacks; }
        public static function leaveCallback(): void { --self::$callbacks; }
        public static function load(string $library, string $function): void {
            if (self::$failure !== null) throw new \RuntimeException(self::$failure);
            if (self::$loading) throw new \RuntimeException('Reentrant PHP-Wasm extension loading is not supported');
            // dl may suspend the host to fetch or instantiate a side module.
            // The synchronous Lean stack cannot participate in that unwind.
            if (self::$callbacks !== 0) throw new \RuntimeException('Cannot load a PHP-Wasm extension inside a synchronous Lean callback. Use its startup descriptor or call that package before entering the callback.');
            $registration = '/__lean_bridge/php_wasm_lazy/' . $library . '.txt';
            if (!is_file($registration) || file_get_contents($registration) !== $library) {
                throw new \RuntimeException('Register this package lazy descriptor in dynamicLibs before PHP starts');
            }
            if (!function_exists('dl') || !ini_get('enable_dl')) {
                throw new \RuntimeException('PHP-Wasm lazy loading requires enable_dl=1');
            }
            self::$loading = true;
            try {
                set_error_handler(static function (int $severity, string $message): never {
                    throw new \RuntimeException($message);
                });
                try {
                    if (!dl($library) || !function_exists($function)) {
                        throw new \RuntimeException('The generated Zend transport did not load');
                    }
                } finally { restore_error_handler(); }
            } catch (\Throwable $error) {
                // Emscripten may retain a partially linked DSO after failure.
                // Do not attempt another lazy load in that PHP instance.
                self::$failure = 'PHP-Wasm extension loading failed; create a new PHP instance. ' . $error->getMessage();
                throw new \RuntimeException(self::$failure, 0, $error);
            } finally { self::$loading = false; }
        }
    }
}
}

namespace LeanReviewedcallbacks\Internal {
require_once __DIR__ . '/Wire.php';

final class CallableTransfers
{
    private static ?\Closure $walk = null;
    private static ?\Closure $validate = null;
    public static function check(int $type, mixed $value, GraphBudget $budget): void {
        self::$validate ??= \Closure::bind(static function($type, $value, $budget): void {
            foreach (Values::walk($value, $type, $budget) as $_) {}
        }, null, Values::class);
        (self::$validate)($type, $value, $budget);
    }
    public static function wire(int $type, mixed $value, bool $reading, GraphBudget $budget): mixed {
        self::$walk ??= \Closure::bind(static fn($type, $value, $reading, $budget) => GraphWire::walk($type, $value, $reading, $budget), null, GraphWire::class);
        $result = (self::$walk)($type, $value, $reading, $budget);
        if ($reading) {
            try { Values::check($type, $result); }
            catch (\TypeError|\ValueError $error) { throw new GraphInvalidWire($error->getMessage(), 0, $error); }
        }
        return $result;
    }
}

final class CallableFrame
{
    public ?\Throwable $failure = null;
    public bool $active = true;
    public readonly GraphBudget $validation;
    public readonly GraphBudget $writing;
    public readonly GraphBudget $reading;
    public function __construct() {
        $this->validation = new GraphBudget();
        $this->writing = new GraphBudget();
        $this->reading = new GraphBudget();
    }
}


final class Lease
{
    private bool $closed = false;
    private int $active = 0;
    public function __construct(private \Closure $invoke, private \Closure $dispose, private mixed $token, private int $arity) {
        self::ensureCall();
        if (!is_resource($token)) throw new \LogicException('Expected a private Lean closure resource');
    }
    public static function ensureCall(): void {
        if (\Fiber::getCurrent() !== null) throw new \LogicException('Lean callables require the main PHP execution context');
    }
    public function isClosed(): bool { return $this->closed; }
    public function invoke(array $arguments): mixed {
        self::ensureCall();
        if ($this->closed) throw new \LogicException('Lean closure is closed');
        if (!array_is_list($arguments) || count($arguments) !== $this->arity)
            throw new \ArgumentCountError('Lean closure requires exactly ' . $this->arity . ' positional arguments');
        ++$this->active;
        try { return ($this->invoke)($this->token, $arguments); }
        finally { --$this->active; if ($this->closed && $this->active === 0) $this->release(); }
    }
    private function release(): void {
        $token = $this->token; $this->token = null;
        if ($token !== null) ($this->dispose)($token);
    }
    public function close(): void { $this->closed = true; if ($this->active === 0) $this->release(); }
    private function __clone() {}
    public function __serialize(): array { throw new \LogicException('Lean closures cannot be serialized'); }
    public function __unserialize(array $data): void { throw new \LogicException('Lean closures cannot be unserialized'); }
    public function __destruct() { try { $this->close(); } catch (\Throwable $ignored) {} }
}

final class Native
{
    private const TRANSPORT = 'LeanReviewedcallbacks\\Internal\\GraphZendca3bc2636c3aa0c3';
    private const LIBRARY = 'php8.4-lb_reviewedcallbacks_graph_ca3bc2636c3aa0c3.so';
    private const CALLBACKS = [['direction' => 'host', 'parameters' => [3], 'result' => 3], ['direction' => 'closure', 'parameters' => [3], 'result' => 3], ['direction' => 'closure', 'parameters' => [1], 'result' => 3], ['direction' => null, 'parameters' => [0], 'result' => 3], ['direction' => 'closure', 'parameters' => [3], 'result' => 3], ['direction' => 'host', 'parameters' => [3], 'result' => 3], ['direction' => null, 'parameters' => [3], 'result' => 2], ['direction' => null, 'parameters' => [3], 'result' => 3]];
    private const FUNCTIONS = [['parameters' => [['callback' => 7], ['type' => 3]], 'result' => ['type' => 3]], ['parameters' => [['type' => 3]], 'result' => ['callback' => 4]], ['parameters' => [['type' => 4]], 'result' => ['callback' => 2]], ['parameters' => [['type' => 3]], 'result' => ['callback' => 1]], ['parameters' => [['callback' => 5], ['type' => 3]], 'result' => ['type' => 3]], ['parameters' => [['type' => 3]], 'result' => ['callback' => 6]], ['parameters' => [['type' => 4]], 'result' => ['callback' => 3]], ['parameters' => [['callback' => 0]], 'result' => ['type' => 3]]];

    private static int $depth = 0;
    private static ?\Closure $wrap = null;
    private static function malformed(GraphInvalidWire $error): never {
        $retire = self::TRANSPORT . '\\retire'; $retire();
        throw new \LeanReviewedcallbacks\LeanBridgeError($error->getMessage(), 4, $error);
    }
    private static function decode(int $type, mixed $value, CallableFrame $frame): mixed {
        try { return CallableTransfers::wire($type, $value, true, $frame->reading); }
        catch (GraphInvalidWire $error) { self::malformed($error); }
    }
    private static function borrow(int $signature, mixed $value, CallableFrame $frame): \Closure {
        if (!is_callable($value)) throw new \TypeError('Expected a synchronous callable');
        $callback = \Closure::fromCallable($value); $reflection = new \ReflectionFunction($callback);
        if ($reflection->isGenerator() || $reflection->returnsReference()) throw new \TypeError('Lean callbacks cannot be generators or return references');
        foreach ($reflection->getParameters() as $parameter)
            if ($parameter->isPassedByReference()) throw new \TypeError('Lean callbacks cannot take reference parameters');
        $frame->validation->charge(32);
        $fn = self::CALLBACKS[$signature];
        return static function (mixed ...$wire) use ($callback, $frame, $fn): mixed {
            if (!$frame->active) throw new \LogicException('Lean callback has expired');
            if ($frame->failure !== null) throw $frame->failure;
            \LeanBridge\CopiedPhpWasmV1\Loader::enterCallback();
            try {
                if (count($wire) !== count($fn['parameters'])) throw new GraphInvalidWire('Wrong native callback arity');
                $arguments = [];
                foreach ($fn['parameters'] as $index => $type) $arguments[] = self::decode($type, $wire[$index], $frame);
                $reply = $callback(...$arguments);
                CallableTransfers::check($fn['result'], $reply, $frame->validation);
                return CallableTransfers::wire($fn['result'], $reply, false, $frame->writing);
            } catch (GraphInvalidWire $error) {
                try { self::malformed($error); }
                catch (\Throwable $failure) { $frame->failure ??= $failure; throw $failure; }
            } catch (\Throwable $error) { $frame->failure ??= $error; throw $error; }
            finally { \LeanBridge\CopiedPhpWasmV1\Loader::leaveCallback(); }
        };
    }
    private static function own(int $signature, mixed $token): \LeanReviewedcallbacks\LeanClosure {
        if (!is_resource($token)) self::malformed(new GraphInvalidWire('Malformed native Lean closure resource'));
        $close = self::TRANSPORT . '\\close' . $signature;
        try {
            $fn = self::CALLBACKS[$signature];
            $lease = new Lease(static fn($token, $args) => self::execute('invoke' . $signature,
                array_map(static fn($type) => ['type' => $type], $fn['parameters']), ['type' => $fn['result']], $args, $token),
                static fn($token) => $close($token), $token, count($fn['parameters']));
            self::$wrap ??= \Closure::bind(static fn(Lease $lease) => new \LeanReviewedcallbacks\LeanClosure($lease), null, \LeanReviewedcallbacks\LeanClosure::class);
            return (self::$wrap)($lease);
        } catch (\Throwable $error) { if (!isset($lease)) $close($token); throw $error; }
    }
    private static function execute(string $entry, array $parameters, array $result, array $arguments, mixed $token = null): mixed {
        Lease::ensureCall();
        if (!array_is_list($arguments) || count($arguments) !== count($parameters)) throw new \ArgumentCountError('Wrong Lean callable arity');
        if (self::$depth === 64) throw new \OverflowException('Lean calls exceed 64 reentry levels');
        $frame = new CallableFrame(); ++self::$depth;
        try {
            $inputs = [];
            // Validate the entire public call before loading a native extension.
            foreach ($parameters as $index => $site) {
                if (isset($site['callback'])) {
                    $fn = self::CALLBACKS[$site['callback']];
                    if ($fn['direction'] === 'host') {
                        if (!$arguments[$index] instanceof \LeanReviewedcallbacks\WithRecovery)
                            throw new \TypeError('This callback requires with_recovery(function, value)');
                        CallableTransfers::check($fn['result'], $arguments[$index]->recovery, $frame->validation);
                    }
                }
                else CallableTransfers::check($site['type'], $arguments[$index], $frame->validation);
            }
            foreach ($parameters as $index => $site) {
                if (isset($site['callback'])) {
                    $fn = self::CALLBACKS[$site['callback']];
                    if ($fn['direction'] === 'host') $inputs[$index] = [
                        self::borrow($site['callback'], $arguments[$index]->function, $frame),
                        CallableTransfers::wire($fn['result'], $arguments[$index]->recovery, false, $frame->writing),
                    ];
                    else $inputs[$index] = self::borrow($site['callback'], $arguments[$index], $frame);
                } else $inputs[$index] = CallableTransfers::wire($site['type'], $arguments[$index], false, $frame->writing);
            }
            ksort($inputs);
            $symbol = self::TRANSPORT . '\\' . $entry;
            if (!function_exists($symbol)) {
                try { \LeanBridge\CopiedPhpWasmV1\Loader::load(self::LIBRARY, $symbol); }
                catch (\Throwable $error) { throw new \LeanReviewedcallbacks\LeanBridgeError($error->getMessage(), 0, $error); }
            }
            try { $output = $token === null ? $symbol(...$inputs) : $symbol($token, ...$inputs); }
            catch (\Throwable $error) {
                if ($frame->failure !== null) throw $frame->failure;
                if ($error instanceof \Exception) throw new \LeanReviewedcallbacks\LeanBridgeError($error->getMessage(), $error->getCode(), $error);
                throw $error;
            }
            if ($frame->failure !== null) throw $frame->failure;
            return isset($result['callback']) ? self::own($result['callback'], $output) : self::decode($result['type'], $output, $frame);
        } finally { $frame->active = false; --self::$depth; }
    }
    public static function call(int $index, array $arguments): mixed {
        $fn = self::FUNCTIONS[$index] ?? throw new \TypeError('Unknown Lean callable');
        return self::execute('call' . $index, $fn['parameters'], $fn['result'], $arguments);
    }

}
}
