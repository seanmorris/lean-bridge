#pragma once
#include "reviewedcallbacks-graph-types.h"
typedef struct reviewedcallbacks_callback_1c8c62ab9d1ea80d3641b41193c41bc6de9a3096 {
  uint32_t (*call)(void *, const reviewedcallbacks_scalar_nat_t *arg0, reviewedcallbacks_scalar_nat_t *out);
  void *context;
  const reviewedcallbacks_scalar_nat_t *recovery;
} reviewedcallbacks_callback_1c8c62ab9d1ea80d3641b41193c41bc6de9a3096;
typedef struct reviewedcallbacks_callback_c9f9ab9808d5ed4cd9eb0c5380d7151c17138950 {
  uint32_t (*call)(void *, const reviewedcallbacks_scalar_nat_t *arg0, reviewedcallbacks_scalar_nat_t *out);
  void *context;
} reviewedcallbacks_callback_c9f9ab9808d5ed4cd9eb0c5380d7151c17138950;
typedef struct reviewedcallbacks_callback_423e0c37f5780352153f2e471aebd23d81e23f74 {
  uint32_t (*call)(void *, const reviewedcallbacks_graph_3dda423e616bb2bf79f0_t *arg0, reviewedcallbacks_scalar_nat_t *out);
  void *context;
} reviewedcallbacks_callback_423e0c37f5780352153f2e471aebd23d81e23f74;
typedef struct reviewedcallbacks_callback_ce903715575b2b74e1c334bc071ce4eceaad0558 {
  uint32_t (*call)(void *, const reviewedcallbacks_graph_fe146e5012c4f116e9b6_t *arg0, reviewedcallbacks_scalar_nat_t *out);
  void *context;
} reviewedcallbacks_callback_ce903715575b2b74e1c334bc071ce4eceaad0558;
typedef struct reviewedcallbacks_callback_3b911dc0ceee9737631b7e83276319d96008e83d {
  uint32_t (*call)(void *, const reviewedcallbacks_scalar_nat_t *arg0, reviewedcallbacks_scalar_nat_t *out);
  void *context;
} reviewedcallbacks_callback_3b911dc0ceee9737631b7e83276319d96008e83d;
typedef struct reviewedcallbacks_callback_ffe59c1b227e089c6c50c0421d94e57562f09578 {
  uint32_t (*call)(void *, const reviewedcallbacks_scalar_nat_t *arg0, reviewedcallbacks_scalar_nat_t *out);
  void *context;
  const reviewedcallbacks_scalar_nat_t *recovery;
} reviewedcallbacks_callback_ffe59c1b227e089c6c50c0421d94e57562f09578;
typedef struct reviewedcallbacks_callback_d8cf2e9a7b0c40482bf9414b886a3e2086ac2e4e {
  uint32_t (*call)(void *, const reviewedcallbacks_scalar_nat_t *arg0, reviewedcallbacks_tile_t *out);
  void *context;
} reviewedcallbacks_callback_d8cf2e9a7b0c40482bf9414b886a3e2086ac2e4e;
typedef struct reviewedcallbacks_callback_8a8a1e0d7d82df3b4bfabb94f5d59f8bf4b9ed1d {
  uint32_t (*call)(void *, const reviewedcallbacks_scalar_nat_t *arg0, reviewedcallbacks_scalar_nat_t *out);
  void *context;
} reviewedcallbacks_callback_8a8a1e0d7d82df3b4bfabb94f5d59f8bf4b9ed1d;
