<?php
declare(strict_types=1);
namespace LeanReviewedcallbacks;

require_once __DIR__ . '/Internal/Values.php';


final class LeanBridgeError extends \RuntimeException {}

final readonly class Bytes implements \Stringable, \Countable
{
    private function __construct(private string $value) {}
    public static function fromString(mixed $value): self {
        if (!\is_string($value)) throw new \TypeError('Bytes requires a string');
        return new self($value);
    }
    public function toString(): string { return $this->value; }
    public function __toString(): string { return $this->value; }
    public function count(): int { return \strlen($this->value); }

    public function equals(mixed $other): bool {
        return $other instanceof self && Internal\Values::equal($this, $other);
    }
    public function hashCode(): string { return Internal\Values::hash($this); }

}


/** @template T */
final readonly class Some
{
    /** @var T */
    public mixed $value;
    /** @param T $value */
    public function __construct(mixed $value) {
        if (\func_num_args() !== 1) throw new \ArgumentCountError('Some requires one payload');
        $this->value = $value;
    }

    public function equals(mixed $other): bool {
        return $other instanceof self && Internal\Values::equal($this, $other);
    }
    public function hashCode(): string { return Internal\Values::hash($this); }

}

/** @template T */
final readonly class Ok
{
    /** @var T */
    public mixed $value;
    /** @param T $value */
    public function __construct(mixed $value) {
        if (\func_num_args() !== 1) throw new \ArgumentCountError('Ok requires one payload');
        $this->value = $value;
    }

    public function equals(mixed $other): bool {
        return $other instanceof self && Internal\Values::equal($this, $other);
    }
    public function hashCode(): string { return Internal\Values::hash($this); }

}

/** @template T */
final readonly class Err
{
    /** @var T */
    public mixed $value;
    /** @param T $value */
    public function __construct(mixed $value) {
        if (\func_num_args() !== 1) throw new \ArgumentCountError('Err requires one payload');
        $this->value = $value;
    }

    public function equals(mixed $other): bool {
        return $other instanceof self && Internal\Values::equal($this, $other);
    }
    public function hashCode(): string { return Internal\Values::hash($this); }

}

final readonly class Tile
{
    /** @var \Brick\Math\BigInteger */
    public \Brick\Math\BigInteger $digit;
    /** @var \Brick\Math\BigInteger */
    public \Brick\Math\BigInteger $count;
    public function __construct(mixed $digit, mixed $count) {
        if (\func_num_args() !== 2) throw new \ArgumentCountError('Tile requires exactly 2 fields');
        Internal\Values::checkFields(self::class, [$digit, $count]);
        $this->digit = $digit;
        $this->count = $count;
    }

    public function equals(mixed $other): bool {
        return $other instanceof self && Internal\Values::equal($this, $other);
    }
    public function hashCode(): string { return Internal\Values::hash($this); }

}


final class LeanClosure
{
    private function __construct(private Internal\Lease $lease) {}
    private function __clone() {}
    public function __invoke(mixed ...$arguments): mixed { return $this->lease->invoke($arguments); }
    public function isClosed(): bool { return $this->lease->isClosed(); }
    public function close(): void { $this->lease->close(); }
    public function __serialize(): array { throw new \LogicException('Lean closures cannot be serialized'); }
    public function __unserialize(array $data): void { throw new \LogicException('Lean closures cannot be unserialized'); }
}

final readonly class WithRecovery
{
    public function __construct(public mixed $function, public mixed $recovery) {
        if (\func_num_args() !== 2) throw new \ArgumentCountError('WithRecovery requires a callback and typed value');
        if (!\is_callable($function)) throw new \TypeError('WithRecovery requires a synchronous callable');
    }
}
function with_recovery(mixed $function, mixed $recovery): WithRecovery {
    if (\func_num_args() !== 2) throw new \ArgumentCountError('with_recovery requires two arguments');
    return new WithRecovery($function, $recovery);
}

require_once __DIR__ . '/Internal/Native.php';

/**
 * @param callable(\Brick\Math\BigInteger): \Brick\Math\BigInteger $arg0
 * @param \Brick\Math\BigInteger $arg1
 * @return \Brick\Math\BigInteger
 */
function apply(mixed $arg0, mixed $arg1): \Brick\Math\BigInteger {
    if (\func_num_args() !== 2) throw new \ArgumentCountError('apply requires exactly 2 arguments');
    return Internal\Native::call(0, [$arg0, $arg1]);
}

/**
 * @param \Brick\Math\BigInteger $arg0
 * @return LeanClosure&callable(\Brick\Math\BigInteger): \Brick\Math\BigInteger
 */
function counter(mixed $arg0): LeanClosure {
    if (\func_num_args() !== 1) throw new \ArgumentCountError('counter requires exactly 1 arguments');
    return Internal\Native::call(1, [$arg0]);
}

/**
 * @param null $arg0
 * @return LeanClosure&callable(list<\Brick\Math\BigInteger>): \Brick\Math\BigInteger
 */
function digits(mixed $arg0): LeanClosure {
    if (\func_num_args() !== 1) throw new \ArgumentCountError('digits requires exactly 1 arguments');
    return Internal\Native::call(2, [$arg0]);
}

/**
 * @param \Brick\Math\BigInteger $arg0
 * @return LeanClosure&callable(\Brick\Math\BigInteger): \Brick\Math\BigInteger
 */
function scaler(mixed $arg0): LeanClosure {
    if (\func_num_args() !== 1) throw new \ArgumentCountError('scaler requires exactly 1 arguments');
    return Internal\Native::call(3, [$arg0]);
}

/**
 * @param WithRecovery $arg0
 * @param \Brick\Math\BigInteger $arg1
 * @return \Brick\Math\BigInteger
 */
function three(mixed $arg0, mixed $arg1): \Brick\Math\BigInteger {
    if (\func_num_args() !== 2) throw new \ArgumentCountError('three requires exactly 2 arguments');
    return Internal\Native::call(4, [$arg0, $arg1]);
}

/**
 * @param \Brick\Math\BigInteger $arg0
 * @return LeanClosure&callable(\Brick\Math\BigInteger): Tile
 */
function tile_maker(mixed $arg0): LeanClosure {
    if (\func_num_args() !== 1) throw new \ArgumentCountError('tile_maker requires exactly 1 arguments');
    return Internal\Native::call(5, [$arg0]);
}

/**
 * @param null $arg0
 * @return LeanClosure&callable(list<Tile>): \Brick\Math\BigInteger
 */
function tiles(mixed $arg0): LeanClosure {
    if (\func_num_args() !== 1) throw new \ArgumentCountError('tiles requires exactly 1 arguments');
    return Internal\Native::call(6, [$arg0]);
}

/**
 * @param WithRecovery $arg0
 * @return \Brick\Math\BigInteger
 */
function visit(mixed $arg0): \Brick\Math\BigInteger {
    if (\func_num_args() !== 1) throw new \ArgumentCountError('visit requires exactly 1 arguments');
    return Internal\Native::call(7, [$arg0]);
}
