<?php
declare(strict_types=1);
namespace LeanReviewedcallbacks\Internal;

final class GraphTypes
{
    public const NODES = [
        ['kind' => 'list', 'element' => 2, 'fields' => [], 'classes' => []],
        ['kind' => 'array', 'element' => 3, 'fields' => [], 'classes' => []],
        ['kind' => 'record', 'element' => null, 'fields' => [['digit', 3], ['count', 3]], 'classes' => ['LeanReviewedcallbacks\\Tile']],
        ['kind' => 'primitive', 'name' => 'nat', 'host' => 'bigint', 'min' => '0', 'max' => null],
        ['kind' => 'primitive', 'name' => 'unit'],
    ];
    public const CLASSES = [
        'LeanReviewedcallbacks\\Tile' => ['fields' => [['digit', 3], ['count', 3]]],
        'LeanReviewedcallbacks\\Some' => ['fields' => [['value', null]]],
        'LeanReviewedcallbacks\\Ok' => ['fields' => [['value', null]]],
        'LeanReviewedcallbacks\\Err' => ['fields' => [['value', null]]],
    ];
}
