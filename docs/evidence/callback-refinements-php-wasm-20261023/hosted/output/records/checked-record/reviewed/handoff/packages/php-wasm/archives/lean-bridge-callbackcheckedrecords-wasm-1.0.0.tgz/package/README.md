# callbackcheckedrecords for PHP-Wasm

Import this package's default descriptor and include it in PHP-Wasm's `sharedLibs` array. npm installs the matching Lean runtime dependency. The descriptor registers that runtime once per PHP host and mounts the generated PHP files.

```js
import { PhpNode } from 'php-wasm/PhpNode';
import api from 'lean-bridge-callbackcheckedrecords-wasm';

const php = new PhpNode({ version: '8.4', sharedLibs: [api] });
await php.run(`<?php require '${api.autoload}';`);
```

Call the generated functions in the `LeanCallbackcheckedrecords` PHP namespace. The `compiled/src/Api.php` file contains their typed declarations. Other descriptors can share the same `sharedLibs` list. Conflicting runtime, component and PHP namespace identities are rejected before startup.

For a Composer application, install the companion `lean-bridge-callbackcheckedrecords/wasm:1.0.0` ZIP, mount your application's `vendor` directory into PHP-Wasm, and use the named `extensions` export in `sharedLibs` instead of the default descriptor. Require your normal `vendor/autoload.php`. This export registers the native libraries without preloading a second copy of the PHP files.

For first-call loading, import `{ lazy as api }` from this package and pass `dynamicLibs: [api]` instead. With Composer, use `api.extensions` in `dynamicLibs`. The host loads PHP declarations at startup but fetches the Lean runtime and this component only on its first valid API call. An unused component stays unloaded. Different components may choose different modes; registering the same component in both modes is rejected.

This package uses PHP-Wasm 0.1.0, PHP 8.4.1 and the default host variant in Node or Chromium. Register descriptors before constructing the host. Lazy loading requires `enable_dl=1`; await each host request before starting another. After an extension-loading failure, create a new PHP instance. No compiler, FFI extension or install script is required. The handoff receipt verifies package bytes; the descriptor checks compatibility identities, not downloaded byte integrity.

Records and variant cases are final readonly classes. List and Array use consecutive-key PHP arrays while retaining distinct Lean types. Products use nested two-element arrays. Option uses null for None and Some(value) for Some; Some(null) and nested Some preserve their declared nesting. Except uses Ok(value) or Err(error). Aliases use their target PHP values without extra wrappers. Generated PHPDoc describes nested types. Functions and constructors check exact arity and values in both weak and strict callers.

On this 32-bit host, UInt32, UInt64, Int64, Nat, Int and USize use Brick\Math\BigInteger. ISize is a signed 32-bit PHP int. Unit is null; Char is one UTF-8 Unicode scalar. String preserves UTF-8 and NUL; Bytes::fromString preserves arbitrary bytes. Float values require PHP float; Float32 rounds to binary32. Big integers have a 16384-decimal-digit limit.

Recursive values may share acyclic subvalues; returned values own independent copies. Cycles, malformed branches, unknown subclasses and uninitialized values reject. Each call permits 128 value levels and 262144 visits, with separate 16 MiB PHP, Zend and native-copy accounting limits. These do not measure all PHP overhead or Lean working memory. All arguments validate and convert before first-call extension loading. Output owners are released before PHP reconstruction, including on Zend bailout. Allocation and limit failures recover; malformed native results retire the shared runtime. Previously copied PHP values remain usable.

Generated records, variants, Some/Ok/Err and Bytes provide equals($other) and hashCode(). Comparisons preserve nominal and branch identity, compare NaNs as equal and distinguish signed zero. Readonly properties do not recursively freeze arbitrary payloads. Do not mutate values during a call or while using their hashes as lookup keys. Synchronous callbacks accept finite copied payloads, including recursive records and variants. Returned LeanClosure objects are invokable; close them in a finally block. Callback exceptions preserve their Throwable identity, and callback replies stay alive until native copying finishes. Closure identities remain private Zend resources, never PHP integers. Calls require the main PHP execution context; the pinned PHP-Wasm host cannot start Fibers. Resource-containing aggregates and asynchronous values remain unsupported.


