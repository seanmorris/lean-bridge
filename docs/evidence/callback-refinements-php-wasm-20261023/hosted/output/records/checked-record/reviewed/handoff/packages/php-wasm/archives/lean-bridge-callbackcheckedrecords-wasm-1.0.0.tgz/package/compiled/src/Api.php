<?php
declare(strict_types=1);
namespace LeanCallbackcheckedrecords;

require_once __DIR__ . '/Internal/Values.php';


final class LeanBridgeError extends \RuntimeException {}

final readonly class Bytes implements \Stringable, \Countable
{
    private function __construct(private string $value) {}
    public static function fromString(mixed $value): self {
        if (!\is_string($value)) throw new \TypeError('Bytes requires a string');
        return new self($value);
    }
    public function toString(): string { return $this->value; }
    public function __toString(): string { return $this->value; }
    public function count(): int { return \strlen($this->value); }

    public function equals(mixed $other): bool {
        return $other instanceof self && Internal\Values::equal($this, $other);
    }
    public function hashCode(): string { return Internal\Values::hash($this); }

}


/** @template T */
final readonly class Some
{
    /** @var T */
    public mixed $value;
    /** @param T $value */
    public function __construct(mixed $value) {
        if (\func_num_args() !== 1) throw new \ArgumentCountError('Some requires one payload');
        $this->value = $value;
    }

    public function equals(mixed $other): bool {
        return $other instanceof self && Internal\Values::equal($this, $other);
    }
    public function hashCode(): string { return Internal\Values::hash($this); }

}

/** @template T */
final readonly class Ok
{
    /** @var T */
    public mixed $value;
    /** @param T $value */
    public function __construct(mixed $value) {
        if (\func_num_args() !== 1) throw new \ArgumentCountError('Ok requires one payload');
        $this->value = $value;
    }

    public function equals(mixed $other): bool {
        return $other instanceof self && Internal\Values::equal($this, $other);
    }
    public function hashCode(): string { return Internal\Values::hash($this); }

}

/** @template T */
final readonly class Err
{
    /** @var T */
    public mixed $value;
    /** @param T $value */
    public function __construct(mixed $value) {
        if (\func_num_args() !== 1) throw new \ArgumentCountError('Err requires one payload');
        $this->value = $value;
    }

    public function equals(mixed $other): bool {
        return $other instanceof self && Internal\Values::equal($this, $other);
    }
    public function hashCode(): string { return Internal\Values::hash($this); }

}

final readonly class Interval
{
    /** @var \Brick\Math\BigInteger */
    public \Brick\Math\BigInteger $lo;
    /** @var \Brick\Math\BigInteger */
    public \Brick\Math\BigInteger $hi;
    public function __construct(mixed $lo, mixed $hi) {
        if (\func_num_args() !== 2) throw new \ArgumentCountError('Interval requires exactly 2 fields');
        Internal\Values::checkFields(self::class, [$lo, $hi]);
        $this->lo = $lo;
        $this->hi = $hi;
    }

    public function equals(mixed $other): bool {
        return $other instanceof self && Internal\Values::equal($this, $other);
    }
    public function hashCode(): string { return Internal\Values::hash($this); }

}

final readonly class Weighted
{
    /** @var \Brick\Math\BigInteger */
    public \Brick\Math\BigInteger $weight;
    /** @var \Brick\Math\BigInteger */
    public \Brick\Math\BigInteger $limit;
    public function __construct(mixed $weight, mixed $limit) {
        if (\func_num_args() !== 2) throw new \ArgumentCountError('Weighted requires exactly 2 fields');
        Internal\Values::checkFields(self::class, [$weight, $limit]);
        $this->weight = $weight;
        $this->limit = $limit;
    }

    public function equals(mixed $other): bool {
        return $other instanceof self && Internal\Values::equal($this, $other);
    }
    public function hashCode(): string { return Internal\Values::hash($this); }

}


final class LeanClosure
{
    private function __construct(private Internal\Lease $lease) {}
    private function __clone() {}
    public function __invoke(mixed ...$arguments): mixed { return $this->lease->invoke($arguments); }
    public function isClosed(): bool { return $this->lease->isClosed(); }
    public function close(): void { $this->lease->close(); }
    public function __serialize(): array { throw new \LogicException('Lean closures cannot be serialized'); }
    public function __unserialize(array $data): void { throw new \LogicException('Lean closures cannot be unserialized'); }
}

final readonly class WithRecovery
{
    public function __construct(public mixed $function, public mixed $recovery) {
        if (\func_num_args() !== 2) throw new \ArgumentCountError('WithRecovery requires a callback and typed value');
        if (!\is_callable($function)) throw new \TypeError('WithRecovery requires a synchronous callable');
    }
}
function with_recovery(mixed $function, mixed $recovery): WithRecovery {
    if (\func_num_args() !== 2) throw new \ArgumentCountError('with_recovery requires two arguments');
    return new WithRecovery($function, $recovery);
}

require_once __DIR__ . '/Internal/Native.php';

/**
 * @param WithRecovery $arg0
 * @return \Brick\Math\BigInteger
 */
function call_host(mixed $arg0): \Brick\Math\BigInteger {
    if (\func_num_args() !== 1) throw new \ArgumentCountError('call_host requires exactly 1 arguments');
    return Internal\Native::call(0, [$arg0]);
}

/**
 * @param WithRecovery $arg0
 * @return \Brick\Math\BigInteger
 */
function call_host_container(mixed $arg0): \Brick\Math\BigInteger {
    if (\func_num_args() !== 1) throw new \ArgumentCountError('call_host_container requires exactly 1 arguments');
    return Internal\Native::call(1, [$arg0]);
}

/**
 * @param WithRecovery $arg0
 * @return \Brick\Math\BigInteger
 */
function call_host_mixed(mixed $arg0): \Brick\Math\BigInteger {
    if (\func_num_args() !== 1) throw new \ArgumentCountError('call_host_mixed requires exactly 1 arguments');
    return Internal\Native::call(2, [$arg0]);
}

/**
 * @param WithRecovery $arg0
 * @return \Brick\Math\BigInteger
 */
function call_host_nested(mixed $arg0): \Brick\Math\BigInteger {
    if (\func_num_args() !== 1) throw new \ArgumentCountError('call_host_nested requires exactly 1 arguments');
    return Internal\Native::call(3, [$arg0]);
}

/**
 * @param \Brick\Math\BigInteger $arg0
 * @return LeanClosure&callable(Interval): \Brick\Math\BigInteger
 */
function make_closure(mixed $arg0): LeanClosure {
    if (\func_num_args() !== 1) throw new \ArgumentCountError('make_closure requires exactly 1 arguments');
    return Internal\Native::call(4, [$arg0]);
}

/**
 * @param \Brick\Math\BigInteger $arg0
 * @return LeanClosure&callable(list<Some<Interval>|null>): Some<Interval>|null
 */
function make_container_closure(mixed $arg0): LeanClosure {
    if (\func_num_args() !== 1) throw new \ArgumentCountError('make_container_closure requires exactly 1 arguments');
    return Internal\Native::call(5, [$arg0]);
}

/**
 * @param \Brick\Math\BigInteger $arg0
 * @return LeanClosure&callable(\Brick\Math\BigInteger, Interval): Interval
 */
function make_mixed_closure(mixed $arg0): LeanClosure {
    if (\func_num_args() !== 1) throw new \ArgumentCountError('make_mixed_closure requires exactly 1 arguments');
    return Internal\Native::call(6, [$arg0]);
}

/**
 * @param \Brick\Math\BigInteger $arg0
 * @return LeanClosure&callable(Weighted): \Brick\Math\BigInteger
 */
function make_nested_closure(mixed $arg0): LeanClosure {
    if (\func_num_args() !== 1) throw new \ArgumentCountError('make_nested_closure requires exactly 1 arguments');
    return Internal\Native::call(7, [$arg0]);
}
