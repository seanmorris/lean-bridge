from __future__ import annotations
from dataclasses import dataclass as _dataclass
from typing import ClassVar as _ClassVar, Literal as _Literal, TypeAlias as _TypeAlias

try:
    from typing import TypeAliasType as _TypeAliasType
except ImportError:
    from typing_extensions import TypeAliasType as _TypeAliasType

__all__ = ("LeanBridgeError", "LeanClosure", "WithRecovery", "with_recovery", "Some", "Option", "Ok", "Err", "Result", "Interval", "Weighted", "Callback115f6922f8f3e5b91c8e", "Callback44d43ec6a49b0f13f8ab", "Callback705cd2e64f6f37b7b3c5", "Callback96775311ba874014bff2", "Callback9edd7fa9a1ed11043b7d", "Callbackb782f62c1be9d8b0085a", "Callbacke7252f0aa280ee0b13ec", "Callbacke974ad5f8e66387c6d39", "call_host", "call_host_container", "call_host_mixed", "call_host_nested", "make_closure", "make_container_closure", "make_mixed_closure", "make_nested_closure",)

from typing import Generic as _Generic, TypeVar as _TypeVar

_T = _TypeVar("_T", covariant=True)
_E = _TypeVar("_E", covariant=True)

@_dataclass(frozen=True)
class Some(_Generic[_T]):
    value: _T

@_dataclass(frozen=True)
class Ok(_Generic[_T]):
    value: _T

@_dataclass(frozen=True)
class Err(_Generic[_E]):
    value: _E

Option = Some[_T] | None

Result = Ok[_T] | Err[_E]

@_dataclass(frozen=True, slots=True)
class Interval:
    lo: int
    hi: int

@_dataclass(frozen=True, slots=True)
class Weighted:
    weight: int
    limit: int

_Value0 = _TypeAliasType("_Value0", Option[Interval])
_Input0 = _TypeAliasType("_Input0", Option[Interval])
_Value1 = _TypeAliasType("_Value1", tuple[_Value0, ...])
_Input1 = _TypeAliasType("_Input1", tuple[_Input0, ...] | list[_Input0])
_Value2 = _TypeAliasType("_Value2", Result[_Value0, str])
_Input2 = _TypeAliasType("_Input2", Result[_Input0, str])

class LeanBridgeError(RuntimeError):
    status: int
    def __init__(self, status: int, message: str):
        super().__init__(message)
        self.status = status

from typing import Never as _Never
from typing import Callable as _Callable, Generic as _Generic, ParamSpec as _ParamSpec, TypeVar as _TypeVar
from types import TracebackType as _TracebackType

_P = _ParamSpec("_P")
_R = _TypeVar("_R")

class LeanClosure(_Generic[_P, _R]):
    """A same-thread Lean callable. Use with or close() to release it."""
    __slots__ = ("_lease", "__weakref__")

    def __init__(self) -> None:
        raise TypeError("Lean closures are returned by generated functions")

    def __call__(self, *args: _P.args, **kwargs: _P.kwargs) -> _R:
        return self._lease(*args, **kwargs)

    @property
    def closed(self) -> bool:
        return self._lease.closed

    def close(self) -> None:
        self._lease.close()

    def __enter__(self) -> LeanClosure[_P, _R]:
        self._lease.ensure_open()
        return self

    def __exit__(self, exc_type: type[BaseException] | None, exc: BaseException | None, traceback: _TracebackType | None) -> None:
        self.close()

    def __copy__(self) -> _Never:
        raise TypeError("Lean closures cannot be copied")

    def __deepcopy__(self, memo: dict[int, object]) -> _Never:
        raise TypeError("Lean closures cannot be copied")

    def __reduce__(self) -> _Never:
        raise TypeError("Lean closures cannot be serialized")


@_dataclass(frozen=True, slots=True)
class WithRecovery(_Generic[_P, _R]):
    function: _Callable[_P, _R]
    recovery: _R

def with_recovery(function: _Callable[_P, _R], recovery: _R) -> WithRecovery[_P, _R]:
    return WithRecovery(function, recovery)

Callback115f6922f8f3e5b91c8e: _TypeAlias = WithRecovery[[_Value0], _Input2]
Callback44d43ec6a49b0f13f8ab: _TypeAlias = WithRecovery[[int, Interval], Interval]
Callback705cd2e64f6f37b7b3c5: _TypeAlias = _Callable[[Interval], int]
Callback96775311ba874014bff2: _TypeAlias = WithRecovery[[Interval], Interval]
Callback9edd7fa9a1ed11043b7d: _TypeAlias = _Callable[[Weighted], int]
Callbackb782f62c1be9d8b0085a: _TypeAlias = WithRecovery[[Weighted], Weighted]
Callbacke7252f0aa280ee0b13ec: _TypeAlias = _Callable[[int, Interval], Interval]
Callbacke974ad5f8e66387c6d39: _TypeAlias = _Callable[[_Value1], _Input0]

def call_host(arg0: Callback96775311ba874014bff2) -> int:
    return _GraphNative._call0(arg0)

def call_host_container(arg0: Callback115f6922f8f3e5b91c8e) -> int:
    return _GraphNative._call1(arg0)

def call_host_mixed(arg0: Callback44d43ec6a49b0f13f8ab) -> int:
    return _GraphNative._call2(arg0)

def call_host_nested(arg0: Callbackb782f62c1be9d8b0085a) -> int:
    return _GraphNative._call3(arg0)

def make_closure(arg0: int) -> LeanClosure[[Interval], int]:
    return _GraphNative._call4(arg0)

def make_container_closure(arg0: int) -> LeanClosure[[_Input1], _Value0]:
    return _GraphNative._call5(arg0)

def make_mixed_closure(arg0: int) -> LeanClosure[[int, Interval], Interval]:
    return _GraphNative._call6(arg0)

def make_nested_closure(arg0: int) -> LeanClosure[[Weighted], int]:
    return _GraphNative._call7(arg0)

from . import _native as _GraphNative
