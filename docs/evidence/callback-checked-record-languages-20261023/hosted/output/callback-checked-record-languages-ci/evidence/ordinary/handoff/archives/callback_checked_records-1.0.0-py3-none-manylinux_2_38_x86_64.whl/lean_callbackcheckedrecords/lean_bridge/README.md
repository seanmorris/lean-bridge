# lean_callbackcheckedrecords

Install the prepared platform wheel and import lean_callbackcheckedrecords. The wheel loads its compatible shared Lean runtime automatically. Consumers need no Lean compiler or C build tools. The native profile requires GIL-enabled Python 3.11+ on Linux x86-64 with glibc matching the wheel tag. Free-threading, post-fork calls and incompatible runtime identities are rejected.

Records and variant constructors are frozen dataclasses. Arrays and Lists accept lists or tuples and return independent tuples. Option[T] is None or Some(value), preserving Some(None). Result[T,E] is Ok(value) or Err(value). Binary products keep their nested tuples. Recursive constructors and concrete aliases retain their names. Private native pointers and constructor numbers are not part of the public API.

Pass a synchronous Python callable to a callback parameter. Each invocation receives independently copied values. Exceptions and invalid callback results unwind the active Lean call and reach the original Python caller. Async functions and awaitable results are rejected. Borrowed callbacks expire when the exporting call returns; a Lean closure cannot extend that borrow.

A host callback whose result contains a checked Lean Subtype or checked record must use with_recovery(callback, value). The recovery has the callback's exact erased result type, is checked before Lean or the callback runs, and is never returned as success.


Returned LeanClosure values own their captured Lean values. Use them in a with block or call close(). Repeated close is safe. Invocation belongs to the creating thread's lifetime, not a reusable OS thread ID. Closing during a reentrant invocation releases the capture after the active call finishes. Copying and serialization are rejected. Finalization provides fallback cleanup.

Finite copied values may be at most 128 levels deep and visit 262,144 nodes. Each native call shares a 16 MiB copy budget across its inputs, callbacks and result. Python conversion storage has its own 16 MiB accounted budget. Cycles and uninhabited copied values are rejected. Temporary values clear on failure. Malformed native output retires the runtime; input validation, callback exceptions and recoverable allocation failures preserve usability. Same-thread nested calls are bounded to 64 active native invocations. Owned closures share the native runtime's 4,096-identity capacity. These bounds do not limit Lean working memory or every Python allocator overhead.

Python int preserves exact Nat and Int values. Fixed-width integers reject out-of-range values and Boolean coercion. Native words are 64-bit. Strings require Unicode scalar text and preserve NUL; ByteArray is bytes. Float32 rounds to binary32. Unit is None. Recursive runtime type aliases use TypeAliasType boundaries. Pip installs typing_extensions (>=4.6,<5) on Python 3.11 when needed; Python 3.12+ uses the standard library. Identity-bearing copied fields, asynchronous operations, subinterpreters and other platforms are outside this profile.

- lean_callbackcheckedrecords.call_host: lean:CallbackCheckedRecords.callHost
- lean_callbackcheckedrecords.call_host_container: lean:CallbackCheckedRecords.callHostContainer
- lean_callbackcheckedrecords.call_host_mixed: lean:CallbackCheckedRecords.callHostMixed
- lean_callbackcheckedrecords.call_host_nested: lean:CallbackCheckedRecords.callHostNested
- lean_callbackcheckedrecords.make_closure: lean:CallbackCheckedRecords.makeClosure
- lean_callbackcheckedrecords.make_container_closure: lean:CallbackCheckedRecords.makeContainerClosure
- lean_callbackcheckedrecords.make_mixed_closure: lean:CallbackCheckedRecords.makeMixedClosure
- lean_callbackcheckedrecords.make_nested_closure: lean:CallbackCheckedRecords.makeNestedClosure
