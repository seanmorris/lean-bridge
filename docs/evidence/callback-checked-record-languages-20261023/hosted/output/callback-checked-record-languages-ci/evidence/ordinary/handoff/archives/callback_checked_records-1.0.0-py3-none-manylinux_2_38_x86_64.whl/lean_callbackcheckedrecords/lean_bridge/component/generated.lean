import CallbackCheckedRecords
set_option maxRecDepth 10000
namespace LeanBridgeNative82670d9206f05718
structure LbErased.CallbackCheckedRecords.Interval where
  «lo» : _root_.Nat
  «hi» : _root_.Nat

def LbErased.CallbackCheckedRecords.Interval.erase (value : _root_.CallbackCheckedRecords.Interval) : LbErased.CallbackCheckedRecords.Interval :=
  LbErased.CallbackCheckedRecords.Interval.mk (value.«lo») (value.«hi»)

def LbErased.CallbackCheckedRecords.Interval.via_629dc2d7b4bbb92f (value : LbErased.CallbackCheckedRecords.Interval) : _root_.Option _root_.CallbackCheckedRecords.Interval := do
  let a0 ← (_root_.Option.some (value.«lo»))
  let a1 ← (_root_.Option.some (value.«hi»))
  _root_.CallbackCheckedRecords.mkInterval a0 a1

structure LbErased.CallbackCheckedRecords.Weighted where
  «weight» : _root_.Nat
  «limit» : _root_.Nat

def LbErased.CallbackCheckedRecords.Weighted.erase (value : _root_.CallbackCheckedRecords.Weighted) : LbErased.CallbackCheckedRecords.Weighted :=
  LbErased.CallbackCheckedRecords.Weighted.mk (_root_.Subtype.val (value.«weight»)) (value.«limit»)

def LbErased.CallbackCheckedRecords.Weighted.via_84123845c2b7aba2 (value : LbErased.CallbackCheckedRecords.Weighted) : _root_.Option _root_.CallbackCheckedRecords.Weighted := do
  let a0 ← _root_.CallbackCheckedRecords.checkedPositive value.«weight»
  let a1 ← (_root_.Option.some (value.«limit»))
  _root_.CallbackCheckedRecords.mkWeighted a0 a1

def carrierValue {α : Type} (value : _root_.Array α) : _root_.Option α :=
  if bound : 0 < value.size then
    if value.size == 1 then .some (value[0]'bound) else .none
  else .none

def carrierResult {α : Type} (value : _root_.Option α) : _root_.Array α :=
  match value with | .none => #[] | .some result => #[result]

def carrierCollect {α : Type} (values : _root_.Array (_root_.Array α)) : _root_.Option (_root_.Array α) := Id.run do
  if values.size > 262144 then return .none
  let mut result := #[]
  for value in values do
    match carrierValue value with
    | .none => return .none
    | .some item => result := result.push item
  return .some result

def carrierListItems {α : Type} (values : _root_.List α) : _root_.Array (_root_.Array α) :=
  let rec loop : _root_.Nat → _root_.List α → _root_.Array (_root_.Array α) → _root_.Array (_root_.Array α)
    | 0, _, acc => acc
    | _, [], acc => acc
    | fuel + 1, head :: tail, acc => loop fuel tail (acc.push #[head])
  loop 262145 values #[]

@[export lean_bridge_697151f2fc3cf6b95ff12b69_recursive_627c7a16d6bab0b64509_make]
def make627c7a16d6bab0b64509 (values : _root_.Array (_root_.Array (_root_.Option LbErased.CallbackCheckedRecords.Interval))) : (_root_.Array (_root_.Array (_root_.Option LbErased.CallbackCheckedRecords.Interval))) :=
  carrierResult (do
    let values ← carrierCollect values
    pure values
  )

@[export lean_bridge_697151f2fc3cf6b95ff12b69_recursive_627c7a16d6bab0b64509_items]
def items627c7a16d6bab0b64509 (value : (_root_.Array (_root_.Array (_root_.Option LbErased.CallbackCheckedRecords.Interval)))) : (_root_.Array (_root_.Array (_root_.Option LbErased.CallbackCheckedRecords.Interval))) :=
  match carrierValue value with
  | .none => #[]
  | .some values => (values.extract 0 262145).map (fun child => #[child])

@[export lean_bridge_697151f2fc3cf6b95ff12b69_recursive_e88ff0d30fe89ddedb96_branch]
def branche88ff0d30fe89ddedb96 (value : (_root_.Array (_root_.Option LbErased.CallbackCheckedRecords.Interval))) : _root_.UInt32 :=
  match carrierValue value with
  | .none => 4294967295
  | .some value =>
    match value with
    | .none => 0
    | .some _ => 1

@[export lean_bridge_697151f2fc3cf6b95ff12b69_recursive_e88ff0d30fe89ddedb96_none]
def nonee88ff0d30fe89ddedb96 (_bridgeUnit : _root_.Unit) : (_root_.Array (_root_.Option LbErased.CallbackCheckedRecords.Interval)) :=
  carrierResult (do
    pure (.none)
  )

@[export lean_bridge_697151f2fc3cf6b95ff12b69_recursive_e88ff0d30fe89ddedb96_make0]
def make0e88ff0d30fe89ddedb96 (a0 : (_root_.Array LbErased.CallbackCheckedRecords.Interval)) : (_root_.Array (_root_.Option LbErased.CallbackCheckedRecords.Interval)) :=
  carrierResult (do
    let a0 ← carrierValue a0
    pure (.some a0)
  )

@[export lean_bridge_697151f2fc3cf6b95ff12b69_recursive_e88ff0d30fe89ddedb96_field0]
def field0e88ff0d30fe89ddedb96 (value : (_root_.Array (_root_.Option LbErased.CallbackCheckedRecords.Interval))) : (_root_.Array LbErased.CallbackCheckedRecords.Interval) :=
  carrierResult (do
    let value ← carrierValue value
    match value with
    | .some child => pure child
    | _ => .none
  )

@[export lean_bridge_697151f2fc3cf6b95ff12b69_recursive_f77ed079c22c7f9e48ec_make]
def makef77ed079c22c7f9e48ec (a0 : (_root_.Array _root_.Nat)) (a1 : (_root_.Array _root_.Nat)) : (_root_.Array LbErased.CallbackCheckedRecords.Interval) :=
  carrierResult (do
    let a0 ← carrierValue a0
    let a1 ← carrierValue a1
    pure (({ «lo» := a0, «hi» := a1 } : LbErased.CallbackCheckedRecords.Interval))
  )

@[export lean_bridge_697151f2fc3cf6b95ff12b69_recursive_f77ed079c22c7f9e48ec_field0]
def field0f77ed079c22c7f9e48ec (value : (_root_.Array LbErased.CallbackCheckedRecords.Interval)) : (_root_.Array _root_.Nat) :=
  carrierResult (do
    let value ← carrierValue value
    pure value.«lo»
  )

@[export lean_bridge_697151f2fc3cf6b95ff12b69_recursive_f77ed079c22c7f9e48ec_field1]
def field1f77ed079c22c7f9e48ec (value : (_root_.Array LbErased.CallbackCheckedRecords.Interval)) : (_root_.Array _root_.Nat) :=
  carrierResult (do
    let value ← carrierValue value
    pure value.«hi»
  )

@[export lean_bridge_697151f2fc3cf6b95ff12b69_recursive_250c7a8f81cfc2c8e740_make]
def make250c7a8f81cfc2c8e740 (a0 : (_root_.Array _root_.Nat)) (a1 : (_root_.Array _root_.Nat)) : (_root_.Array LbErased.CallbackCheckedRecords.Weighted) :=
  carrierResult (do
    let a0 ← carrierValue a0
    let a1 ← carrierValue a1
    pure (({ «weight» := a0, «limit» := a1 } : LbErased.CallbackCheckedRecords.Weighted))
  )

@[export lean_bridge_697151f2fc3cf6b95ff12b69_recursive_250c7a8f81cfc2c8e740_field0]
def field0250c7a8f81cfc2c8e740 (value : (_root_.Array LbErased.CallbackCheckedRecords.Weighted)) : (_root_.Array _root_.Nat) :=
  carrierResult (do
    let value ← carrierValue value
    pure value.«weight»
  )

@[export lean_bridge_697151f2fc3cf6b95ff12b69_recursive_250c7a8f81cfc2c8e740_field1]
def field1250c7a8f81cfc2c8e740 (value : (_root_.Array LbErased.CallbackCheckedRecords.Weighted)) : (_root_.Array _root_.Nat) :=
  carrierResult (do
    let value ← carrierValue value
    pure value.«limit»
  )

@[export lean_bridge_697151f2fc3cf6b95ff12b69_recursive_cb7f8c41a24eac8674b6_branch]
def branchcb7f8c41a24eac8674b6 (value : (_root_.Array (_root_.Except _root_.String (_root_.Option LbErased.CallbackCheckedRecords.Interval)))) : _root_.UInt32 :=
  match carrierValue value with
  | .none => 4294967295
  | .some value =>
    match value with
    | .ok _ => 0
    | .error _ => 1

@[export lean_bridge_697151f2fc3cf6b95ff12b69_recursive_cb7f8c41a24eac8674b6_make0]
def make0cb7f8c41a24eac8674b6 (a0 : (_root_.Array (_root_.Option LbErased.CallbackCheckedRecords.Interval))) : (_root_.Array (_root_.Except _root_.String (_root_.Option LbErased.CallbackCheckedRecords.Interval))) :=
  carrierResult (do
    let a0 ← carrierValue a0
    pure (.ok a0)
  )

@[export lean_bridge_697151f2fc3cf6b95ff12b69_recursive_cb7f8c41a24eac8674b6_field0]
def field0cb7f8c41a24eac8674b6 (value : (_root_.Array (_root_.Except _root_.String (_root_.Option LbErased.CallbackCheckedRecords.Interval)))) : (_root_.Array (_root_.Option LbErased.CallbackCheckedRecords.Interval)) :=
  carrierResult (do
    let value ← carrierValue value
    match value with
    | .ok child => pure child
    | _ => .none
  )

@[export lean_bridge_697151f2fc3cf6b95ff12b69_recursive_cb7f8c41a24eac8674b6_make1]
def make1cb7f8c41a24eac8674b6 (a0 : (_root_.Array _root_.String)) : (_root_.Array (_root_.Except _root_.String (_root_.Option LbErased.CallbackCheckedRecords.Interval))) :=
  carrierResult (do
    let a0 ← carrierValue a0
    pure (.error a0)
  )

@[export lean_bridge_697151f2fc3cf6b95ff12b69_recursive_cb7f8c41a24eac8674b6_field1]
def field1cb7f8c41a24eac8674b6 (value : (_root_.Array (_root_.Except _root_.String (_root_.Option LbErased.CallbackCheckedRecords.Interval)))) : (_root_.Array _root_.String) :=
  carrierResult (do
    let value ← carrierValue value
    match value with
    | .error child => pure child
    | _ => .none
  )

def callbackDefault_f77ed079c22c7f9e48ec : LbErased.CallbackCheckedRecords.Interval := { «lo» := 0, «hi» := 0 }

def callbackDefault_250c7a8f81cfc2c8e740 : LbErased.CallbackCheckedRecords.Weighted := { «weight» := 0, «limit» := 0 }

@[extern "lean_bridge_697151f2fc3cf6b95ff12b69_structured_2663a58c7c0e71654db1d87936875f8677e197b2_invoke"]
opaque invoke_2663a58c7c0e71654db1d87936875f8677e197b2 (token : _root_.USize) (a0 : (_root_.Array (_root_.Option LbErased.CallbackCheckedRecords.Interval))) : (_root_.Array (_root_.Except _root_.String (_root_.Option LbErased.CallbackCheckedRecords.Interval))) := #[]

@[extern "lean_bridge_697151f2fc3cf6b95ff12b69_structured_2663a58c7c0e71654db1d87936875f8677e197b2_recovery"]
opaque recovery_2663a58c7c0e71654db1d87936875f8677e197b2 (token : _root_.USize) : (_root_.Array (_root_.Except _root_.String (_root_.Option LbErased.CallbackCheckedRecords.Interval))) := #[]

@[extern "lean_bridge_697151f2fc3cf6b95ff12b69_structured_2663a58c7c0e71654db1d87936875f8677e197b2_reject"]
opaque reject_2663a58c7c0e71654db1d87936875f8677e197b2 (token : _root_.USize) (recovery : (_root_.Array (_root_.Except _root_.String (_root_.Option LbErased.CallbackCheckedRecords.Interval)))) : (_root_.Array (_root_.Except _root_.String (_root_.Option LbErased.CallbackCheckedRecords.Interval))) := recovery

@[export lean_bridge_697151f2fc3cf6b95ff12b69_structured_2663a58c7c0e71654db1d87936875f8677e197b2_wrap]
def wrap_2663a58c7c0e71654db1d87936875f8677e197b2 (token : _root_.USize) : (_root_.Array _root_.USize) := #[token]

@[extern "lean_bridge_697151f2fc3cf6b95ff12b69_structured_526ba4a0f03797057c1f9a17ca435a5a42131510_invoke"]
opaque invoke_526ba4a0f03797057c1f9a17ca435a5a42131510 (token : _root_.USize) (a0 : (_root_.Array _root_.Nat)) (a1 : (_root_.Array LbErased.CallbackCheckedRecords.Interval)) : (_root_.Array LbErased.CallbackCheckedRecords.Interval) := #[]

@[extern "lean_bridge_697151f2fc3cf6b95ff12b69_structured_526ba4a0f03797057c1f9a17ca435a5a42131510_recovery"]
opaque recovery_526ba4a0f03797057c1f9a17ca435a5a42131510 (token : _root_.USize) : (_root_.Array LbErased.CallbackCheckedRecords.Interval) := #[]

@[extern "lean_bridge_697151f2fc3cf6b95ff12b69_structured_526ba4a0f03797057c1f9a17ca435a5a42131510_reject"]
opaque reject_526ba4a0f03797057c1f9a17ca435a5a42131510 (token : _root_.USize) (recovery : (_root_.Array LbErased.CallbackCheckedRecords.Interval)) : (_root_.Array LbErased.CallbackCheckedRecords.Interval) := recovery

@[export lean_bridge_697151f2fc3cf6b95ff12b69_structured_526ba4a0f03797057c1f9a17ca435a5a42131510_wrap]
def wrap_526ba4a0f03797057c1f9a17ca435a5a42131510 (token : _root_.USize) : (_root_.Array _root_.USize) := #[token]

@[export lean_bridge_697151f2fc3cf6b95ff12b69_structured_e014092ff0a1ee8527eeeb58a78e2de63bdf09fa_apply]
def apply_e014092ff0a1ee8527eeeb58a78e2de63bdf09fa (closure : (_root_.Array (LbErased.CallbackCheckedRecords.Interval → (_root_.Option _root_.Nat)))) (a0 : (_root_.Array LbErased.CallbackCheckedRecords.Interval)) : (_root_.Array _root_.Nat) :=
  carrierResult (do
    let closure ← carrierValue closure
    let a0 ← carrierValue a0
    let result ← closure a0
    pure result
  )

@[export lean_bridge_697151f2fc3cf6b95ff12b69_structured_e014092ff0a1ee8527eeeb58a78e2de63bdf09fa_closure_graph_refinement_0_c356a7238da028f9ec99]
def closure_e014092ff0a1ee8527eeeb58a78e2de63bdf09fa_graph_refinement_0_c356a7238da028f9ec99 (carrier : (_root_.Array LbErased.CallbackCheckedRecords.Interval)) : _root_.UInt8 :=
  match carrierValue carrier with
  | .none => 0
  | .some value =>
    match (LbErased.CallbackCheckedRecords.Interval.via_629dc2d7b4bbb92f (value)) with
    | .some _ => 1
    | .none => 0

@[extern "lean_bridge_697151f2fc3cf6b95ff12b69_structured_00652748bed3eb7036c9091f570efa39888f5490_invoke"]
opaque invoke_00652748bed3eb7036c9091f570efa39888f5490 (token : _root_.USize) (a0 : (_root_.Array LbErased.CallbackCheckedRecords.Interval)) : (_root_.Array LbErased.CallbackCheckedRecords.Interval) := #[]

@[extern "lean_bridge_697151f2fc3cf6b95ff12b69_structured_00652748bed3eb7036c9091f570efa39888f5490_recovery"]
opaque recovery_00652748bed3eb7036c9091f570efa39888f5490 (token : _root_.USize) : (_root_.Array LbErased.CallbackCheckedRecords.Interval) := #[]

@[extern "lean_bridge_697151f2fc3cf6b95ff12b69_structured_00652748bed3eb7036c9091f570efa39888f5490_reject"]
opaque reject_00652748bed3eb7036c9091f570efa39888f5490 (token : _root_.USize) (recovery : (_root_.Array LbErased.CallbackCheckedRecords.Interval)) : (_root_.Array LbErased.CallbackCheckedRecords.Interval) := recovery

@[export lean_bridge_697151f2fc3cf6b95ff12b69_structured_00652748bed3eb7036c9091f570efa39888f5490_wrap]
def wrap_00652748bed3eb7036c9091f570efa39888f5490 (token : _root_.USize) : (_root_.Array _root_.USize) := #[token]

@[export lean_bridge_697151f2fc3cf6b95ff12b69_structured_d885a7d82ec894d17b81e7a67a36bc2930adca13_apply]
def apply_d885a7d82ec894d17b81e7a67a36bc2930adca13 (closure : (_root_.Array (LbErased.CallbackCheckedRecords.Weighted → (_root_.Option _root_.Nat)))) (a0 : (_root_.Array LbErased.CallbackCheckedRecords.Weighted)) : (_root_.Array _root_.Nat) :=
  carrierResult (do
    let closure ← carrierValue closure
    let a0 ← carrierValue a0
    let result ← closure a0
    pure result
  )

@[export lean_bridge_697151f2fc3cf6b95ff12b69_structured_d885a7d82ec894d17b81e7a67a36bc2930adca13_closure_graph_refinement_0_93110217dc013facd35d]
def closure_d885a7d82ec894d17b81e7a67a36bc2930adca13_graph_refinement_0_93110217dc013facd35d (carrier : (_root_.Array LbErased.CallbackCheckedRecords.Weighted)) : _root_.UInt8 :=
  match carrierValue carrier with
  | .none => 0
  | .some value =>
    match (LbErased.CallbackCheckedRecords.Weighted.via_84123845c2b7aba2 (value)) with
    | .some _ => 1
    | .none => 0

@[export lean_bridge_697151f2fc3cf6b95ff12b69_structured_d885a7d82ec894d17b81e7a67a36bc2930adca13_closure_graph_refinement_0_b50ad1ac24da4bc3a6eb]
def closure_d885a7d82ec894d17b81e7a67a36bc2930adca13_graph_refinement_0_b50ad1ac24da4bc3a6eb (carrier : (_root_.Array _root_.Nat)) : _root_.UInt8 :=
  match carrierValue carrier with
  | .none => 0
  | .some value =>
    match _root_.CallbackCheckedRecords.checkedPositive value with
    | .some _ => 1
    | .none => 0

@[extern "lean_bridge_697151f2fc3cf6b95ff12b69_structured_cd01d463066ae86d043223e65eab1640e16b22ab_invoke"]
opaque invoke_cd01d463066ae86d043223e65eab1640e16b22ab (token : _root_.USize) (a0 : (_root_.Array LbErased.CallbackCheckedRecords.Weighted)) : (_root_.Array LbErased.CallbackCheckedRecords.Weighted) := #[]

@[extern "lean_bridge_697151f2fc3cf6b95ff12b69_structured_cd01d463066ae86d043223e65eab1640e16b22ab_recovery"]
opaque recovery_cd01d463066ae86d043223e65eab1640e16b22ab (token : _root_.USize) : (_root_.Array LbErased.CallbackCheckedRecords.Weighted) := #[]

@[extern "lean_bridge_697151f2fc3cf6b95ff12b69_structured_cd01d463066ae86d043223e65eab1640e16b22ab_reject"]
opaque reject_cd01d463066ae86d043223e65eab1640e16b22ab (token : _root_.USize) (recovery : (_root_.Array LbErased.CallbackCheckedRecords.Weighted)) : (_root_.Array LbErased.CallbackCheckedRecords.Weighted) := recovery

@[export lean_bridge_697151f2fc3cf6b95ff12b69_structured_cd01d463066ae86d043223e65eab1640e16b22ab_wrap]
def wrap_cd01d463066ae86d043223e65eab1640e16b22ab (token : _root_.USize) : (_root_.Array _root_.USize) := #[token]

@[export lean_bridge_697151f2fc3cf6b95ff12b69_structured_2e292aebff8c53f6a465ec3d5745e74400590434_apply]
def apply_2e292aebff8c53f6a465ec3d5745e74400590434 (closure : (_root_.Array (_root_.Nat → LbErased.CallbackCheckedRecords.Interval → (_root_.Option LbErased.CallbackCheckedRecords.Interval)))) (a0 : (_root_.Array _root_.Nat)) (a1 : (_root_.Array LbErased.CallbackCheckedRecords.Interval)) : (_root_.Array LbErased.CallbackCheckedRecords.Interval) :=
  carrierResult (do
    let closure ← carrierValue closure
    let a0 ← carrierValue a0
    let a1 ← carrierValue a1
    let result ← closure a0 a1
    pure result
  )

@[export lean_bridge_697151f2fc3cf6b95ff12b69_structured_2e292aebff8c53f6a465ec3d5745e74400590434_closure_graph_refinement_1_c356a7238da028f9ec99]
def closure_2e292aebff8c53f6a465ec3d5745e74400590434_graph_refinement_1_c356a7238da028f9ec99 (carrier : (_root_.Array LbErased.CallbackCheckedRecords.Interval)) : _root_.UInt8 :=
  match carrierValue carrier with
  | .none => 0
  | .some value =>
    match (LbErased.CallbackCheckedRecords.Interval.via_629dc2d7b4bbb92f (value)) with
    | .some _ => 1
    | .none => 0

@[export lean_bridge_697151f2fc3cf6b95ff12b69_structured_8994592329ecba032f0abfaa9703e59a57f3c6a1_apply]
def apply_8994592329ecba032f0abfaa9703e59a57f3c6a1 (closure : (_root_.Array ((_root_.Array (_root_.Option LbErased.CallbackCheckedRecords.Interval)) → (_root_.Option (_root_.Option LbErased.CallbackCheckedRecords.Interval))))) (a0 : (_root_.Array (_root_.Array (_root_.Option LbErased.CallbackCheckedRecords.Interval)))) : (_root_.Array (_root_.Option LbErased.CallbackCheckedRecords.Interval)) :=
  carrierResult (do
    let closure ← carrierValue closure
    let a0 ← carrierValue a0
    let result ← closure a0
    pure result
  )

@[export lean_bridge_697151f2fc3cf6b95ff12b69_structured_8994592329ecba032f0abfaa9703e59a57f3c6a1_closure_graph_refinement_0_c356a7238da028f9ec99]
def closure_8994592329ecba032f0abfaa9703e59a57f3c6a1_graph_refinement_0_c356a7238da028f9ec99 (carrier : (_root_.Array LbErased.CallbackCheckedRecords.Interval)) : _root_.UInt8 :=
  match carrierValue carrier with
  | .none => 0
  | .some value =>
    match (LbErased.CallbackCheckedRecords.Interval.via_629dc2d7b4bbb92f (value)) with
    | .some _ => 1
    | .none => 0

@[export lean_bridge_697151f2fc3cf6b95ff12b69_lean]
def export0 (a0 : (_root_.Array _root_.USize)) : (_root_.Array _root_.Nat) :=
  carrierResult (do
    let a0 ← carrierValue a0
    let _bridgeRecoveryRaw0 ← carrierValue (recovery_00652748bed3eb7036c9091f570efa39888f5490 a0)
    let _bridgeRecovery0 ← (LbErased.CallbackCheckedRecords.Interval.via_629dc2d7b4bbb92f (_bridgeRecoveryRaw0))
    pure (_root_.CallbackCheckedRecords.callHost (fun _bridgeCallback0_0 => match (do let _bridgeCallbackResult0 ← carrierValue (invoke_00652748bed3eb7036c9091f570efa39888f5490 a0 #[(LbErased.CallbackCheckedRecords.Interval.erase (_bridgeCallback0_0))]); (LbErased.CallbackCheckedRecords.Interval.via_629dc2d7b4bbb92f (_bridgeCallbackResult0))) with | .some value => value | .none => (match (do let value ← carrierValue (reject_00652748bed3eb7036c9091f570efa39888f5490 a0 #[_bridgeRecoveryRaw0]); (LbErased.CallbackCheckedRecords.Interval.via_629dc2d7b4bbb92f (value))) with | .some value => value | .none => _bridgeRecovery0)))
  )

@[export lean_bridge_413afe4aaf66162bb3ba3d3c_lean]
def export1 (a0 : (_root_.Array _root_.USize)) : (_root_.Array _root_.Nat) :=
  carrierResult (do
    let a0 ← carrierValue a0
    let _bridgeRecoveryRaw0 ← carrierValue (recovery_2663a58c7c0e71654db1d87936875f8677e197b2 a0)
    let _bridgeRecovery0 ← (match (_bridgeRecoveryRaw0) with | .ok _bridgeValue0 => ((match (_bridgeValue0) with | .none => _root_.Option.some _root_.Option.none | .some _bridgeValue1 => ((LbErased.CallbackCheckedRecords.Interval.via_629dc2d7b4bbb92f (_bridgeValue1))).map _root_.Option.some)).map _root_.Except.ok | .error _bridgeValue0 => ((_root_.Option.some (_bridgeValue0))).map _root_.Except.error)
    pure (_root_.CallbackCheckedRecords.callHostContainer (fun _bridgeCallback0_0 => match (do let _bridgeCallbackResult0 ← carrierValue (invoke_2663a58c7c0e71654db1d87936875f8677e197b2 a0 #[((_bridgeCallback0_0).map (fun _bridgeValue0 => (LbErased.CallbackCheckedRecords.Interval.erase (_bridgeValue0))))]); (match (_bridgeCallbackResult0) with | .ok _bridgeValue0 => ((match (_bridgeValue0) with | .none => _root_.Option.some _root_.Option.none | .some _bridgeValue1 => ((LbErased.CallbackCheckedRecords.Interval.via_629dc2d7b4bbb92f (_bridgeValue1))).map _root_.Option.some)).map _root_.Except.ok | .error _bridgeValue0 => ((_root_.Option.some (_bridgeValue0))).map _root_.Except.error)) with | .some value => value | .none => (match (do let value ← carrierValue (reject_2663a58c7c0e71654db1d87936875f8677e197b2 a0 #[_bridgeRecoveryRaw0]); (match (value) with | .ok _bridgeValue0 => ((match (_bridgeValue0) with | .none => _root_.Option.some _root_.Option.none | .some _bridgeValue1 => ((LbErased.CallbackCheckedRecords.Interval.via_629dc2d7b4bbb92f (_bridgeValue1))).map _root_.Option.some)).map _root_.Except.ok | .error _bridgeValue0 => ((_root_.Option.some (_bridgeValue0))).map _root_.Except.error)) with | .some value => value | .none => _bridgeRecovery0)))
  )

@[export lean_bridge_184bfb6b98fb39095f0bfec8_lean]
def export2 (a0 : (_root_.Array _root_.USize)) : (_root_.Array _root_.Nat) :=
  carrierResult (do
    let a0 ← carrierValue a0
    let _bridgeRecoveryRaw0 ← carrierValue (recovery_526ba4a0f03797057c1f9a17ca435a5a42131510 a0)
    let _bridgeRecovery0 ← (LbErased.CallbackCheckedRecords.Interval.via_629dc2d7b4bbb92f (_bridgeRecoveryRaw0))
    pure (_root_.CallbackCheckedRecords.callHostMixed (fun _bridgeCallback0_0 _bridgeCallback0_1 => match (do let _bridgeCallbackResult0 ← carrierValue (invoke_526ba4a0f03797057c1f9a17ca435a5a42131510 a0 #[_bridgeCallback0_0] #[(LbErased.CallbackCheckedRecords.Interval.erase (_bridgeCallback0_1))]); (LbErased.CallbackCheckedRecords.Interval.via_629dc2d7b4bbb92f (_bridgeCallbackResult0))) with | .some value => value | .none => (match (do let value ← carrierValue (reject_526ba4a0f03797057c1f9a17ca435a5a42131510 a0 #[_bridgeRecoveryRaw0]); (LbErased.CallbackCheckedRecords.Interval.via_629dc2d7b4bbb92f (value))) with | .some value => value | .none => _bridgeRecovery0)))
  )

@[export lean_bridge_f168e18f231fdb7eb1733b0e_lean]
def export3 (a0 : (_root_.Array _root_.USize)) : (_root_.Array _root_.Nat) :=
  carrierResult (do
    let a0 ← carrierValue a0
    let _bridgeRecoveryRaw0 ← carrierValue (recovery_cd01d463066ae86d043223e65eab1640e16b22ab a0)
    let _bridgeRecovery0 ← (LbErased.CallbackCheckedRecords.Weighted.via_84123845c2b7aba2 (_bridgeRecoveryRaw0))
    pure (_root_.CallbackCheckedRecords.callHostNested (fun _bridgeCallback0_0 => match (do let _bridgeCallbackResult0 ← carrierValue (invoke_cd01d463066ae86d043223e65eab1640e16b22ab a0 #[(LbErased.CallbackCheckedRecords.Weighted.erase (_bridgeCallback0_0))]); (LbErased.CallbackCheckedRecords.Weighted.via_84123845c2b7aba2 (_bridgeCallbackResult0))) with | .some value => value | .none => (match (do let value ← carrierValue (reject_cd01d463066ae86d043223e65eab1640e16b22ab a0 #[_bridgeRecoveryRaw0]); (LbErased.CallbackCheckedRecords.Weighted.via_84123845c2b7aba2 (value))) with | .some value => value | .none => _bridgeRecovery0)))
  )

@[export lean_bridge_97d7a19c3e5ee22681017ca9_lean]
def export4 (a0 : (_root_.Array _root_.Nat)) : (_root_.Array (LbErased.CallbackCheckedRecords.Interval → (_root_.Option _root_.Nat))) :=
  carrierResult (do
    let a0 ← carrierValue a0
    do let _bridgeClosure := _root_.CallbackCheckedRecords.makeClosure a0; pure (fun (_bridgeCallbackResult_0 : LbErased.CallbackCheckedRecords.Interval) => do let _bridgeCallbackChecked_0 ← (LbErased.CallbackCheckedRecords.Interval.via_629dc2d7b4bbb92f (_bridgeCallbackResult_0)); pure ((_bridgeClosure _bridgeCallbackChecked_0)))
  )

@[export lean_bridge_74ed57fc03e7ed555389a3ab_lean]
def export5 (a0 : (_root_.Array _root_.Nat)) : (_root_.Array ((_root_.Array (_root_.Option LbErased.CallbackCheckedRecords.Interval)) → (_root_.Option (_root_.Option LbErased.CallbackCheckedRecords.Interval)))) :=
  carrierResult (do
    let a0 ← carrierValue a0
    do let _bridgeClosure := _root_.CallbackCheckedRecords.makeContainerClosure a0; pure (fun (_bridgeCallbackResult_0 : (_root_.Array (_root_.Option LbErased.CallbackCheckedRecords.Interval))) => do let _bridgeCallbackChecked_0 ← ((_bridgeCallbackResult_0).mapM (fun _bridgeValue0 => (match (_bridgeValue0) with | .none => _root_.Option.some _root_.Option.none | .some _bridgeValue1 => ((LbErased.CallbackCheckedRecords.Interval.via_629dc2d7b4bbb92f (_bridgeValue1))).map _root_.Option.some))); pure (((_bridgeClosure _bridgeCallbackChecked_0).map (fun _bridgeValue0 => (LbErased.CallbackCheckedRecords.Interval.erase (_bridgeValue0))))))
  )

@[export lean_bridge_bbabc0c3fa2252f4f7a67708_lean]
def export6 (a0 : (_root_.Array _root_.Nat)) : (_root_.Array (_root_.Nat → LbErased.CallbackCheckedRecords.Interval → (_root_.Option LbErased.CallbackCheckedRecords.Interval))) :=
  carrierResult (do
    let a0 ← carrierValue a0
    do let _bridgeClosure := _root_.CallbackCheckedRecords.makeMixedClosure a0; pure (fun (_bridgeCallbackResult_0 : _root_.Nat) (_bridgeCallbackResult_1 : LbErased.CallbackCheckedRecords.Interval) => do let _bridgeCallbackChecked_1 ← (LbErased.CallbackCheckedRecords.Interval.via_629dc2d7b4bbb92f (_bridgeCallbackResult_1)); pure ((LbErased.CallbackCheckedRecords.Interval.erase (_bridgeClosure _bridgeCallbackResult_0 _bridgeCallbackChecked_1))))
  )

@[export lean_bridge_77496697d09177e0d1ebadfd_lean]
def export7 (a0 : (_root_.Array _root_.Nat)) : (_root_.Array (LbErased.CallbackCheckedRecords.Weighted → (_root_.Option _root_.Nat))) :=
  carrierResult (do
    let a0 ← carrierValue a0
    do let _bridgeClosure := _root_.CallbackCheckedRecords.makeNestedClosure a0; pure (fun (_bridgeCallbackResult_0 : LbErased.CallbackCheckedRecords.Weighted) => do let _bridgeCallbackChecked_0 ← (LbErased.CallbackCheckedRecords.Weighted.via_84123845c2b7aba2 (_bridgeCallbackResult_0)); pure ((_bridgeClosure _bridgeCallbackChecked_0)))
  )

end LeanBridgeNative82670d9206f05718
