from . import LeanBridgeError, LeanClosure, WithRecovery, Some, Ok, Err, Interval, Weighted
from . import _assets as _GraphAssets

import ctypes as _c
import builtins as _b

if _c.sizeof(_c.c_void_p) != 8:
    raise ImportError("Native copied graphs require 64-bit pointers")

class _GraphInvalidNative(LeanBridgeError):
    def __init__(self, message="Invalid native copied value"):
        super().__init__(4, message)

class _GraphLimit(ValueError):
    pass

def _graph_checkpoint():
    pass

class _GraphScope:
    def __init__(self, check_only=False):
        self.check_only = check_only
        self.nodes = 262144
        self.native = 16 * 1024 * 1024
        self.storage = 16 * 1024 * 1024
        self.active = set()
        self.owners = []

    def charge(self, field, count, width=1):
        remaining = getattr(self, field)
        if count < 0 or width < 1 or count > remaining // width:
            raise _GraphLimit("16 MiB copied graph conversion limit exceeded")
        setattr(self, field, remaining - count * width)

    def enter(self, key, depth, raw, native_storage, output=False):
        if depth > 128 or self.nodes == 0:
            raise _GraphLimit("Copied graph depth or node limit exceeded")
        self.nodes -= 1
        if native_storage:
            self.charge("native", 1, _c.sizeof(raw))
        if key is not None:
            if key in self.active:
                if output:
                    raise _GraphInvalidNative("Cyclic native copied value")
                raise ValueError("Cyclic Python copied value")
            self.active.add(key)

    def leave(self, key):
        if key is not None:
            self.active.remove(key)

    def value(self, raw, value=None):
        self.charge("storage", 1, _c.sizeof(raw) + 256)
        if self.check_only:
            return None
        _graph_checkpoint()
        result = raw() if value is None else raw(value)
        self.owners.append(result)
        return result

    def allocate(self, raw, count):
        self.charge("storage", count, _c.sizeof(raw))
        self.charge("storage", 256)
        if self.check_only:
            return None
        _graph_checkpoint()
        result = (raw * count)()
        self.owners.append(result)
        return result

    def close(self):
        self.owners.clear()
        self.active.clear()

def _graph_integer(value, minimum, maximum):
    if type(value) is not int:
        raise TypeError("Expected an int without Boolean or numeric coercion")
    if minimum is not None and value < minimum or maximum is not None and value > maximum:
        raise ValueError("Integer is outside the declared Lean range")
    return value

def _graph_text_size(value, limit):
    if len(value) > limit:
        raise _GraphLimit("Copied graph UTF-8 limit exceeded")
    if value.isascii():
        return len(value)
    size = 0
    for character in value:
        code = ord(character)
        if 0xd800 <= code <= 0xdfff:
            raise ValueError("String requires Unicode scalar values")
        size += 1 if code < 0x80 else 2 if code < 0x800 else 3 if code < 0x10000 else 4
        if size > limit:
            raise _GraphLimit("Copied graph UTF-8 limit exceeded")
    return size

def _graph_span(pointer, count, raw):
    if not count:
        return 0
    width = _c.sizeof(raw)
    if (not pointer or pointer % _c.alignment(raw)
            or count > ((1 << 63) - 1) // width
            or pointer > (1 << 64) - 1 - count * width):
        raise _GraphInvalidNative("Missing, misaligned or overflowing native span")
    # The authenticated adapter supplies readable process memory. Address checks
    # do not make arbitrary foreign pointers safe to dereference.
    return pointer

def _graph_read(pointer, raw):
    return raw.from_address(_graph_span(pointer, 1, raw))

def _graph_status(status):
    if status == 0:
        return
    if status not in (1, 2, 3, 5):
        raise _GraphInvalidNative()
    raise LeanBridgeError(status, {1: "Invalid native input", 2: "Native copied graph limit exceeded", 3: "Native allocation failed", 5: "Lean runtime is unavailable"}[status])

_GraphRelease = _c.CFUNCTYPE(None, _c.c_void_p)

def _graph_clear(value):
    if value is None or not _b.hasattr(value, "owner"):
        return
    owner, release = value.owner, value.release
    _c.memset(_c.addressof(value), 0, _c.sizeof(value))
    if owner and release:
        _GraphRelease(release)(owner)

class _GraphValues:
    Some = Some
    Ok = Ok
    Err = Err
    Interval = Interval
    Weighted = Weighted

class _Raw0(_c.Structure):
    pass

class _Raw1(_c.Structure):
    pass

class _Raw2(_c.Structure):
    pass

class _Raw3(_c.Structure):
    pass

class _Raw4(_c.Structure):
    pass

class _Raw5(_c.Structure):
    pass

class _Raw6(_c.Structure):
    pass

_Raw5._fields_ = [("owner", _c.c_void_p), ("release", _c.c_void_p), ("data", _c.c_void_p), ("length", _c.c_size_t)]

_Raw3._fields_ = [("owner", _c.c_void_p), ("release", _c.c_void_p), ("field0", _Raw5), ("field1", _Raw5)]

_Raw0._fields_ = [("owner", _c.c_void_p), ("release", _c.c_void_p), ("has_value", _c.c_uint8), ("field0", _Raw3)]

_Raw1._fields_ = [("owner", _c.c_void_p), ("release", _c.c_void_p), ("data", _c.c_void_p), ("length", _c.c_size_t)]

_Raw6._fields_ = [("owner", _c.c_void_p), ("release", _c.c_void_p), ("data", _c.c_void_p), ("length", _c.c_size_t)]

_Raw2._fields_ = [("owner", _c.c_void_p), ("release", _c.c_void_p), ("is_ok", _c.c_uint8), ("field0", _Raw0), ("field1", _Raw6)]

_Raw4._fields_ = [("owner", _c.c_void_p), ("release", _c.c_void_p), ("field0", _Raw5), ("field1", _Raw5)]

def _graph_input0(value, scope, depth=0, native_storage=True):
    key = _b.id(value)
    scope.enter(key, depth, _Raw0, native_storage)
    try:
        if value is None: return scope.value(_Raw0)
        if type(value) is _GraphValues.Some:
            out = scope.value(_Raw0)
            if not scope.check_only: out.has_value = 1
            child = _graph_input3(value.value, scope, depth + 1, False)
            if not scope.check_only:
                out.field0 = child
            return out
        raise TypeError("Expected None or Some(value)")
    finally:
        scope.leave(key)

def _graph_output0(value, scope, depth=0, native_storage=True):
    key = (0, _c.addressof(value))
    scope.enter(key, depth, _Raw0, native_storage, True)
    try:
        if value.has_value == 0: return None
        if value.has_value == 1:
            scope.charge("storage", 272)
            _graph_checkpoint()
            return _GraphValues.Some(_graph_output3(value.field0, scope, depth + 1, False))
        raise _GraphInvalidNative("Invalid native option flag")
    finally:
        scope.leave(key)

def _graph_input1(value, scope, depth=0, native_storage=True):
    key = _b.id(value)
    scope.enter(key, depth, _Raw1, native_storage)
    try:
        if type(value) not in (list, tuple): raise TypeError("Expected a list or tuple")
        length = len(value)
        if length > scope.nodes: raise _GraphLimit("Copied graph node limit exceeded")
        scope.charge("native", length, _c.sizeof(_Raw0))
        out = scope.value(_Raw1)
        buffer = scope.allocate(_Raw0, length)
        for index in range(length):
            child = _graph_input0(value[index], scope, depth + 1, False)
            if not scope.check_only: buffer[index] = child
        if len(value) != length: raise ValueError("Do not mutate copied input during conversion")
        if not scope.check_only:
            out.data = _c.addressof(buffer) if length else None
            out.length = length
        return out
    finally:
        scope.leave(key)

def _graph_output1(value, scope, depth=0, native_storage=True):
    key = (1, _c.addressof(value))
    scope.enter(key, depth, _Raw1, native_storage, True)
    try:
        if value.length > scope.nodes: raise _GraphLimit("Copied graph node limit exceeded")
        scope.charge("native", value.length, _c.sizeof(_Raw0))
        scope.charge("storage", value.length, 16)
        scope.charge("storage", 128)
        pointer = _graph_span(value.data, value.length, _Raw0)
        memory = (_Raw0 * value.length).from_address(pointer) if value.length else ()
        _graph_checkpoint()
        result = []
        for child in memory:
            result.append(_graph_output0(child, scope, depth + 1, False))
        _graph_checkpoint()
        return tuple(result)
    finally:
        scope.leave(key)

def _graph_input2(value, scope, depth=0, native_storage=True):
    key = _b.id(value)
    scope.enter(key, depth, _Raw2, native_storage)
    try:
        if type(value) is _GraphValues.Ok:
            out = scope.value(_Raw2)
            if not scope.check_only: out.is_ok = 1
            child = _graph_input0(value.value, scope, depth + 1, False)
            if not scope.check_only:
                out.field0 = child
            return out
        if type(value) is _GraphValues.Err:
            out = scope.value(_Raw2)
            if not scope.check_only: out.is_ok = 0
            child = _graph_input6(value.value, scope, depth + 1, False)
            if not scope.check_only:
                out.field1 = child
            return out
        raise TypeError("Expected Ok(value) or Err(value)")
    finally:
        scope.leave(key)

def _graph_output2(value, scope, depth=0, native_storage=True):
    key = (2, _c.addressof(value))
    scope.enter(key, depth, _Raw2, native_storage, True)
    try:
        if value.is_ok == 1:
            scope.charge("storage", 272)
            _graph_checkpoint()
            return _GraphValues.Ok(_graph_output0(value.field0, scope, depth + 1, False))
        if value.is_ok == 0:
            scope.charge("storage", 272)
            _graph_checkpoint()
            return _GraphValues.Err(_graph_output6(value.field1, scope, depth + 1, False))
        raise _GraphInvalidNative("Invalid native result flag")
    finally:
        scope.leave(key)

def _graph_input3(value, scope, depth=0, native_storage=True):
    key = _b.id(value)
    scope.enter(key, depth, _Raw3, native_storage)
    try:
        if type(value) is not _GraphValues.Interval: raise TypeError("Expected Interval")
        out = scope.value(_Raw3)
        child = _graph_input5(value.lo, scope, depth + 1, False)
        if not scope.check_only:
            out.field0 = child
        child = _graph_input5(value.hi, scope, depth + 1, False)
        if not scope.check_only:
            out.field1 = child
        return out
    finally:
        scope.leave(key)

def _graph_output3(value, scope, depth=0, native_storage=True):
    key = (3, _c.addressof(value))
    scope.enter(key, depth, _Raw3, native_storage, True)
    try:
        scope.charge("storage", 288)
        _graph_checkpoint()
        return _GraphValues.Interval(_graph_output5(value.field0, scope, depth + 1, False), _graph_output5(value.field1, scope, depth + 1, False))
    finally:
        scope.leave(key)

def _graph_input4(value, scope, depth=0, native_storage=True):
    key = _b.id(value)
    scope.enter(key, depth, _Raw4, native_storage)
    try:
        if type(value) is not _GraphValues.Weighted: raise TypeError("Expected Weighted")
        out = scope.value(_Raw4)
        child = _graph_input5(value.weight, scope, depth + 1, False)
        if not scope.check_only:
            out.field0 = child
        child = _graph_input5(value.limit, scope, depth + 1, False)
        if not scope.check_only:
            out.field1 = child
        return out
    finally:
        scope.leave(key)

def _graph_output4(value, scope, depth=0, native_storage=True):
    key = (4, _c.addressof(value))
    scope.enter(key, depth, _Raw4, native_storage, True)
    try:
        scope.charge("storage", 288)
        _graph_checkpoint()
        return _GraphValues.Weighted(_graph_output5(value.field0, scope, depth + 1, False), _graph_output5(value.field1, scope, depth + 1, False))
    finally:
        scope.leave(key)

def _graph_input5(value, scope, depth=0, native_storage=True):
    key = None
    scope.enter(key, depth, _Raw5, native_storage)
    try:
        _graph_integer(value, 0, None)
        length = (value.bit_length() + 31) // 32
        scope.charge("native", length, 4)
        scope.charge("storage", length, 8)
        out = scope.value(_Raw5)
        buffer = scope.allocate(_c.c_uint32, length)
        if not scope.check_only:
            data = abs(value).to_bytes(length * 4, "little")
            if length: _c.memmove(buffer, data, length * 4)
            out.data = _c.addressof(buffer) if length else None
            out.length = length
        return out
    finally:
        scope.leave(key)

def _graph_output5(value, scope, depth=0, native_storage=True):
    key = None
    scope.enter(key, depth, _Raw5, native_storage, True)
    try:
        scope.charge("native", value.length, 4)
        scope.charge("storage", value.length, 8)
        pointer = _graph_span(value.data, value.length, _c.c_uint32)
        _graph_checkpoint()
        data = _c.string_at(pointer, value.length * 4) if value.length else b""
        magnitude = int.from_bytes(data, "little")
        return magnitude
    finally:
        scope.leave(key)

def _graph_input6(value, scope, depth=0, native_storage=True):
    key = None
    scope.enter(key, depth, _Raw6, native_storage)
    try:
        if type(value) is not str: raise TypeError("Expected str")
        length = _graph_text_size(value, scope.native)
        scope.charge("native", length, 1)
        scope.charge("storage", length, 1)
        out = scope.value(_Raw6)
        buffer = scope.allocate(_c.c_uint8, length)
        if not scope.check_only:
            data = value.encode("utf-8", "strict")
            if length: _c.memmove(buffer, data, length * 1)
            out.data = _c.addressof(buffer) if length else None
            out.length = length
        return out
    finally:
        scope.leave(key)

def _graph_output6(value, scope, depth=0, native_storage=True):
    key = None
    scope.enter(key, depth, _Raw6, native_storage, True)
    try:
        scope.charge("native", value.length, 1)
        scope.charge("storage", value.length, 5)
        pointer = _graph_span(value.data, value.length, _c.c_uint8)
        _graph_checkpoint()
        data = _c.string_at(pointer, value.length * 1) if value.length else b""
        try:
            return data.decode("utf-8", "strict")
        except _b.UnicodeDecodeError as error:
            raise _GraphInvalidNative("Invalid native UTF-8") from error
    finally:
        scope.leave(key)

def _graph_input7(value, scope, depth=0, native_storage=True):
    key = None
    scope.enter(key, depth, _c.c_uint8, native_storage)
    try:
        if value is not None: raise TypeError("Unit requires None")
        return 0
    finally:
        scope.leave(key)

def _graph_output7(value, scope, depth=0, native_storage=True):
    key = None
    scope.enter(key, depth, _c.c_uint8, native_storage, True)
    try:
        if value != 0: raise _GraphInvalidNative("Invalid native Unit")
        return None
    finally:
        scope.leave(key)

def _graph_call_copied_payload0(invoke, arg0, arg1, arg2, arg3, arg4, arg5, *, lifecycle=None):
    checked = _GraphScope(True)
    try:
        _graph_input5(arg0, checked)
        _graph_input0(arg1, checked)
        _graph_input2(arg2, checked)
        _graph_input3(arg3, checked)
        _graph_input4(arg4, checked)
        _graph_input1(arg5, checked)
    finally:
        checked.close()
    scope = _GraphScope()
    output = None
    try:
        input0 = _graph_input5(arg0, scope)
        input1 = _graph_input0(arg1, scope)
        input2 = _graph_input2(arg2, scope)
        input3 = _graph_input3(arg3, scope)
        input4 = _graph_input4(arg4, scope)
        input5 = _graph_input1(arg5, scope)
        output = scope.value(_c.c_uint8)
        if lifecycle is not None: _graph_status(lifecycle[0]())
        _graph_status(invoke(_c.byref(input0), _c.byref(input1), _c.byref(input2), _c.byref(input3), _c.byref(input4), _c.byref(input5), _c.byref(output)))
        result = _graph_output7(output.value, scope)
        if lifecycle is not None and not lifecycle[1](): raise LeanBridgeError(5, "Lean runtime is unavailable")
        return result
    except _GraphInvalidNative:
        if lifecycle is not None: lifecycle[2]()
        raise
    finally:
        try:
            _graph_clear(output)
        finally:
            scope.close()


import inspect as _inspect
import os as _os
import threading as _threading

class _GraphCallableFrame:
    def __init__(self):
        self.scope = _GraphScope()
        self.failure = None
        self.thread = _threading.current_thread()
        self.alive = True

    def close(self):
        self.alive = False
        self.scope.close()

def _graph_require_callback(value):
    if (not callable(value) or _inspect.iscoroutinefunction(value)
            or _inspect.isasyncgenfunction(value)
            or _inspect.iscoroutinefunction(getattr(value, "__call__", None))
            or _inspect.isasyncgenfunction(getattr(value, "__call__", None))):
        raise TypeError("Expected a synchronous callable")

def _graph_synchronous(value):
    if _inspect.isawaitable(value):
        if _inspect.iscoroutine(value):
            value.close()
        raise TypeError("Callbacks must return synchronously")
    return value

def _graph_callable_status(status, frame):
    if frame.failure is not None:
        raise frame.failure
    if status == 6:
        raise LeanBridgeError(6, "Host callback failed")
    if status == 10:
        raise LeanBridgeError(1, "Host callback result failed its Lean constructor")
    _graph_status(status)

class _GraphLease:
    def __init__(self, invoke, dispose):
        self.pointer = _c.c_uint64()
        self.invoke = invoke
        self.dispose = dispose
        self.thread = _threading.current_thread()
        self.lock = _threading.RLock()
        self.active = 0
        self.closed = False

    def ensure_open(self):
        _GraphAssets._ensure_process()
        if self.closed:
            raise RuntimeError("Lean closure is closed")
        if _threading.current_thread() is not self.thread:
            raise RuntimeError("Lean closure must be called on its creating thread")

    def _release(self):
        token, self.pointer.value = self.pointer.value, 0
        if token:
            self.dispose(token)

    def __call__(self, *args, **kwargs):
        _GraphAssets._ensure_process()
        with self.lock:
            self.ensure_open()
            self.active += 1
            try:
                return self.invoke(self.pointer.value, *args, **kwargs)
            finally:
                self.active -= 1
                if self.closed and not self.active:
                    self._release()

    def close(self):
        _GraphAssets._ensure_process()
        with self.lock:
            self.closed = True
            if not self.active:
                self._release()

    def __del__(self):
        # A forked child must not enter an inherited native or Python lock.
        try:
            if _os.getpid() == _GraphAssets._PID:
                self.close()
        except BaseException:
            pass

def _graph_own(output, invoke, dispose):
    if not output.value:
        raise _GraphInvalidNative("Native result has a missing Lean closure")
    _graph_checkpoint()
    lease = _GraphLease(invoke, dispose)
    _graph_checkpoint()
    result = object.__new__(LeanClosure)
    result._lease = lease
    # Share one token box until the outer caller commits the transfer. Any
    # failure clears that same box, including the partially wrapped result.
    lease.pointer = output
    return result

_graph_initialize = _GraphAssets._LIBRARY["callbackcheckedrecords_graph_initialize"]
_graph_initialize.argtypes = []
_graph_initialize.restype = _c.c_uint32

_graph_ready = _GraphAssets._LIBRARY["callbackcheckedrecords_graph_ready"]
_graph_ready.argtypes = []
_graph_ready.restype = _c.c_int

_graph_retire = _GraphAssets._LIBRARY["callbackcheckedrecords_graph_retire"]
_graph_retire.argtypes = []
_graph_retire.restype = None

_CallbackFn0 = _c.CFUNCTYPE(_c.c_uint32, _c.c_void_p, _c.POINTER(_Raw0), _c.POINTER(_Raw2))
class _Callback0(_c.Structure):
    _fields_ = [("call", _CallbackFn0), ("context", _c.c_void_p), ("recovery", _c.POINTER(_Raw2))]

def _check_callback0(value, scope):
    if type(value) is not WithRecovery:
        raise TypeError("This callback requires with_recovery(function, value)")
    _graph_require_callback(value.function)
    _graph_input2(value.recovery, scope)

def _callback0(value, frame):
    if type(value) is not WithRecovery:
        raise TypeError("This callback requires with_recovery(function, value)")
    function, recovery_value = value.function, value.recovery
    _graph_require_callback(function)
    callback = function
    def invoke(_context, arg0, output):
        try:
            if not frame.alive or frame.failure is not None or _threading.current_thread() is not frame.thread:
                return 6
            value0 = _graph_output0(arg0.contents, frame.scope)
            result = _graph_synchronous(callback(value0))
            converted = _graph_input2(result, frame.scope)
            output[0] = converted
            return 0
        except BaseException as failure:
            if isinstance(failure, _GraphInvalidNative): _graph_retire()
            if frame.failure is None: frame.failure = failure
            return 6
    trampoline = _CallbackFn0(invoke)
    frame.scope.owners.append(trampoline)
    recovery = _graph_input2(recovery_value, frame.scope)
    return _Callback0(trampoline, None, _c.pointer(recovery))

_CallbackFn1 = _c.CFUNCTYPE(_c.c_uint32, _c.c_void_p, _c.POINTER(_Raw5), _c.POINTER(_Raw3), _c.POINTER(_Raw3))
class _Callback1(_c.Structure):
    _fields_ = [("call", _CallbackFn1), ("context", _c.c_void_p), ("recovery", _c.POINTER(_Raw3))]

def _check_callback1(value, scope):
    if type(value) is not WithRecovery:
        raise TypeError("This callback requires with_recovery(function, value)")
    _graph_require_callback(value.function)
    _graph_input3(value.recovery, scope)

def _callback1(value, frame):
    if type(value) is not WithRecovery:
        raise TypeError("This callback requires with_recovery(function, value)")
    function, recovery_value = value.function, value.recovery
    _graph_require_callback(function)
    callback = function
    def invoke(_context, arg0, arg1, output):
        try:
            if not frame.alive or frame.failure is not None or _threading.current_thread() is not frame.thread:
                return 6
            value0 = _graph_output5(arg0.contents, frame.scope)
            value1 = _graph_output3(arg1.contents, frame.scope)
            result = _graph_synchronous(callback(value0, value1))
            converted = _graph_input3(result, frame.scope)
            output[0] = converted
            return 0
        except BaseException as failure:
            if isinstance(failure, _GraphInvalidNative): _graph_retire()
            if frame.failure is None: frame.failure = failure
            return 6
    trampoline = _CallbackFn1(invoke)
    frame.scope.owners.append(trampoline)
    recovery = _graph_input3(recovery_value, frame.scope)
    return _Callback1(trampoline, None, _c.pointer(recovery))

_CallbackFn2 = _c.CFUNCTYPE(_c.c_uint32, _c.c_void_p, _c.POINTER(_Raw3), _c.POINTER(_Raw5))
class _Callback2(_c.Structure):
    _fields_ = [("call", _CallbackFn2), ("context", _c.c_void_p)]

_owned2 = _GraphAssets._LIBRARY["callbackcheckedrecords_callback_e014092ff0a1ee8527eeeb58a78e2de63bdf09fa_lease_call"]
_owned2.argtypes = [_c.c_uint64, _c.POINTER(_Raw3), _c.POINTER(_Raw5)]
_owned2.restype = _c.c_uint32
_dispose2 = _GraphAssets._LIBRARY["callbackcheckedrecords_callback_e014092ff0a1ee8527eeeb58a78e2de63bdf09fa_lease_dispose"]
_dispose2.argtypes = [_c.c_uint64]
_dispose2.restype = None

def _check_callback2(value, scope):
    _graph_require_callback(value)

def _callback2(value, frame):
    function = value
    _graph_require_callback(function)
    callback = function
    def invoke(_context, arg0, output):
        try:
            if not frame.alive or frame.failure is not None or _threading.current_thread() is not frame.thread:
                return 6
            value0 = _graph_output3(arg0.contents, frame.scope)
            result = _graph_synchronous(callback(value0))
            converted = _graph_input5(result, frame.scope)
            output[0] = converted
            return 0
        except BaseException as failure:
            if isinstance(failure, _GraphInvalidNative): _graph_retire()
            if frame.failure is None: frame.failure = failure
            return 6
    trampoline = _CallbackFn2(invoke)
    frame.scope.owners.append(trampoline)
    return _Callback2(trampoline, None)

_CallbackFn3 = _c.CFUNCTYPE(_c.c_uint32, _c.c_void_p, _c.POINTER(_Raw3), _c.POINTER(_Raw3))
class _Callback3(_c.Structure):
    _fields_ = [("call", _CallbackFn3), ("context", _c.c_void_p), ("recovery", _c.POINTER(_Raw3))]

def _check_callback3(value, scope):
    if type(value) is not WithRecovery:
        raise TypeError("This callback requires with_recovery(function, value)")
    _graph_require_callback(value.function)
    _graph_input3(value.recovery, scope)

def _callback3(value, frame):
    if type(value) is not WithRecovery:
        raise TypeError("This callback requires with_recovery(function, value)")
    function, recovery_value = value.function, value.recovery
    _graph_require_callback(function)
    callback = function
    def invoke(_context, arg0, output):
        try:
            if not frame.alive or frame.failure is not None or _threading.current_thread() is not frame.thread:
                return 6
            value0 = _graph_output3(arg0.contents, frame.scope)
            result = _graph_synchronous(callback(value0))
            converted = _graph_input3(result, frame.scope)
            output[0] = converted
            return 0
        except BaseException as failure:
            if isinstance(failure, _GraphInvalidNative): _graph_retire()
            if frame.failure is None: frame.failure = failure
            return 6
    trampoline = _CallbackFn3(invoke)
    frame.scope.owners.append(trampoline)
    recovery = _graph_input3(recovery_value, frame.scope)
    return _Callback3(trampoline, None, _c.pointer(recovery))

_CallbackFn4 = _c.CFUNCTYPE(_c.c_uint32, _c.c_void_p, _c.POINTER(_Raw4), _c.POINTER(_Raw5))
class _Callback4(_c.Structure):
    _fields_ = [("call", _CallbackFn4), ("context", _c.c_void_p)]

_owned4 = _GraphAssets._LIBRARY["callbackcheckedrecords_callback_d885a7d82ec894d17b81e7a67a36bc2930adca13_lease_call"]
_owned4.argtypes = [_c.c_uint64, _c.POINTER(_Raw4), _c.POINTER(_Raw5)]
_owned4.restype = _c.c_uint32
_dispose4 = _GraphAssets._LIBRARY["callbackcheckedrecords_callback_d885a7d82ec894d17b81e7a67a36bc2930adca13_lease_dispose"]
_dispose4.argtypes = [_c.c_uint64]
_dispose4.restype = None

def _check_callback4(value, scope):
    _graph_require_callback(value)

def _callback4(value, frame):
    function = value
    _graph_require_callback(function)
    callback = function
    def invoke(_context, arg0, output):
        try:
            if not frame.alive or frame.failure is not None or _threading.current_thread() is not frame.thread:
                return 6
            value0 = _graph_output4(arg0.contents, frame.scope)
            result = _graph_synchronous(callback(value0))
            converted = _graph_input5(result, frame.scope)
            output[0] = converted
            return 0
        except BaseException as failure:
            if isinstance(failure, _GraphInvalidNative): _graph_retire()
            if frame.failure is None: frame.failure = failure
            return 6
    trampoline = _CallbackFn4(invoke)
    frame.scope.owners.append(trampoline)
    return _Callback4(trampoline, None)

_CallbackFn5 = _c.CFUNCTYPE(_c.c_uint32, _c.c_void_p, _c.POINTER(_Raw4), _c.POINTER(_Raw4))
class _Callback5(_c.Structure):
    _fields_ = [("call", _CallbackFn5), ("context", _c.c_void_p), ("recovery", _c.POINTER(_Raw4))]

def _check_callback5(value, scope):
    if type(value) is not WithRecovery:
        raise TypeError("This callback requires with_recovery(function, value)")
    _graph_require_callback(value.function)
    _graph_input4(value.recovery, scope)

def _callback5(value, frame):
    if type(value) is not WithRecovery:
        raise TypeError("This callback requires with_recovery(function, value)")
    function, recovery_value = value.function, value.recovery
    _graph_require_callback(function)
    callback = function
    def invoke(_context, arg0, output):
        try:
            if not frame.alive or frame.failure is not None or _threading.current_thread() is not frame.thread:
                return 6
            value0 = _graph_output4(arg0.contents, frame.scope)
            result = _graph_synchronous(callback(value0))
            converted = _graph_input4(result, frame.scope)
            output[0] = converted
            return 0
        except BaseException as failure:
            if isinstance(failure, _GraphInvalidNative): _graph_retire()
            if frame.failure is None: frame.failure = failure
            return 6
    trampoline = _CallbackFn5(invoke)
    frame.scope.owners.append(trampoline)
    recovery = _graph_input4(recovery_value, frame.scope)
    return _Callback5(trampoline, None, _c.pointer(recovery))

_CallbackFn6 = _c.CFUNCTYPE(_c.c_uint32, _c.c_void_p, _c.POINTER(_Raw5), _c.POINTER(_Raw3), _c.POINTER(_Raw3))
class _Callback6(_c.Structure):
    _fields_ = [("call", _CallbackFn6), ("context", _c.c_void_p)]

_owned6 = _GraphAssets._LIBRARY["callbackcheckedrecords_callback_2e292aebff8c53f6a465ec3d5745e74400590434_lease_call"]
_owned6.argtypes = [_c.c_uint64, _c.POINTER(_Raw5), _c.POINTER(_Raw3), _c.POINTER(_Raw3)]
_owned6.restype = _c.c_uint32
_dispose6 = _GraphAssets._LIBRARY["callbackcheckedrecords_callback_2e292aebff8c53f6a465ec3d5745e74400590434_lease_dispose"]
_dispose6.argtypes = [_c.c_uint64]
_dispose6.restype = None

def _check_callback6(value, scope):
    _graph_require_callback(value)

def _callback6(value, frame):
    function = value
    _graph_require_callback(function)
    callback = function
    def invoke(_context, arg0, arg1, output):
        try:
            if not frame.alive or frame.failure is not None or _threading.current_thread() is not frame.thread:
                return 6
            value0 = _graph_output5(arg0.contents, frame.scope)
            value1 = _graph_output3(arg1.contents, frame.scope)
            result = _graph_synchronous(callback(value0, value1))
            converted = _graph_input3(result, frame.scope)
            output[0] = converted
            return 0
        except BaseException as failure:
            if isinstance(failure, _GraphInvalidNative): _graph_retire()
            if frame.failure is None: frame.failure = failure
            return 6
    trampoline = _CallbackFn6(invoke)
    frame.scope.owners.append(trampoline)
    return _Callback6(trampoline, None)

_CallbackFn7 = _c.CFUNCTYPE(_c.c_uint32, _c.c_void_p, _c.POINTER(_Raw1), _c.POINTER(_Raw0))
class _Callback7(_c.Structure):
    _fields_ = [("call", _CallbackFn7), ("context", _c.c_void_p)]

_owned7 = _GraphAssets._LIBRARY["callbackcheckedrecords_callback_8994592329ecba032f0abfaa9703e59a57f3c6a1_lease_call"]
_owned7.argtypes = [_c.c_uint64, _c.POINTER(_Raw1), _c.POINTER(_Raw0)]
_owned7.restype = _c.c_uint32
_dispose7 = _GraphAssets._LIBRARY["callbackcheckedrecords_callback_8994592329ecba032f0abfaa9703e59a57f3c6a1_lease_dispose"]
_dispose7.argtypes = [_c.c_uint64]
_dispose7.restype = None

def _check_callback7(value, scope):
    _graph_require_callback(value)

def _callback7(value, frame):
    function = value
    _graph_require_callback(function)
    callback = function
    def invoke(_context, arg0, output):
        try:
            if not frame.alive or frame.failure is not None or _threading.current_thread() is not frame.thread:
                return 6
            value0 = _graph_output1(arg0.contents, frame.scope)
            result = _graph_synchronous(callback(value0))
            converted = _graph_input0(result, frame.scope)
            output[0] = converted
            return 0
        except BaseException as failure:
            if isinstance(failure, _GraphInvalidNative): _graph_retire()
            if frame.failure is None: frame.failure = failure
            return 6
    trampoline = _CallbackFn7(invoke)
    frame.scope.owners.append(trampoline)
    return _Callback7(trampoline, None)

def _invoke2(_self, arg0):
    _GraphAssets._ensure_process()
    checked = _GraphScope(True)
    try:
        _graph_input3(arg0, checked)
    finally:
        checked.close()
    frame = _GraphCallableFrame()
    output = None
    try:
        input0 = _graph_input3(arg0, frame.scope)
        output = frame.scope.value(_Raw5)
        _graph_status(_graph_initialize())
        status = _owned2(_self, _c.byref(input0), _c.byref(output))
        _graph_callable_status(status, frame)
        if not _graph_ready(): raise LeanBridgeError(5, "Lean runtime is unavailable")
        return _graph_output5(output, frame.scope)
    except _GraphInvalidNative:
        _graph_retire()
        raise
    finally:
        try:
            _graph_clear(output)
        finally:
            frame.close()

def _invoke4(_self, arg0):
    _GraphAssets._ensure_process()
    checked = _GraphScope(True)
    try:
        _graph_input4(arg0, checked)
    finally:
        checked.close()
    frame = _GraphCallableFrame()
    output = None
    try:
        input0 = _graph_input4(arg0, frame.scope)
        output = frame.scope.value(_Raw5)
        _graph_status(_graph_initialize())
        status = _owned4(_self, _c.byref(input0), _c.byref(output))
        _graph_callable_status(status, frame)
        if not _graph_ready(): raise LeanBridgeError(5, "Lean runtime is unavailable")
        return _graph_output5(output, frame.scope)
    except _GraphInvalidNative:
        _graph_retire()
        raise
    finally:
        try:
            _graph_clear(output)
        finally:
            frame.close()

def _invoke6(_self, arg0, arg1):
    _GraphAssets._ensure_process()
    checked = _GraphScope(True)
    try:
        _graph_input5(arg0, checked)
        _graph_input3(arg1, checked)
    finally:
        checked.close()
    frame = _GraphCallableFrame()
    output = None
    try:
        input0 = _graph_input5(arg0, frame.scope)
        input1 = _graph_input3(arg1, frame.scope)
        output = frame.scope.value(_Raw3)
        _graph_status(_graph_initialize())
        status = _owned6(_self, _c.byref(input0), _c.byref(input1), _c.byref(output))
        _graph_callable_status(status, frame)
        if not _graph_ready(): raise LeanBridgeError(5, "Lean runtime is unavailable")
        return _graph_output3(output, frame.scope)
    except _GraphInvalidNative:
        _graph_retire()
        raise
    finally:
        try:
            _graph_clear(output)
        finally:
            frame.close()

def _invoke7(_self, arg0):
    _GraphAssets._ensure_process()
    checked = _GraphScope(True)
    try:
        _graph_input1(arg0, checked)
    finally:
        checked.close()
    frame = _GraphCallableFrame()
    output = None
    try:
        input0 = _graph_input1(arg0, frame.scope)
        output = frame.scope.value(_Raw0)
        _graph_status(_graph_initialize())
        status = _owned7(_self, _c.byref(input0), _c.byref(output))
        _graph_callable_status(status, frame)
        if not _graph_ready(): raise LeanBridgeError(5, "Lean runtime is unavailable")
        return _graph_output0(output, frame.scope)
    except _GraphInvalidNative:
        _graph_retire()
        raise
    finally:
        try:
            _graph_clear(output)
        finally:
            frame.close()

_fn0 = _GraphAssets._LIBRARY["lean_bridge_697151f2fc3cf6b95ff12b69_graph"]
_fn0.argtypes = [_c.POINTER(_Callback3), _c.POINTER(_Raw5)]
_fn0.restype = _c.c_uint32

def _call0(arg0):
    _GraphAssets._ensure_process()
    checked = _GraphScope(True)
    try:
        _check_callback3(arg0, checked)
    finally:
        checked.close()
    frame = _GraphCallableFrame()
    output = None
    try:
        input0 = _callback3(arg0, frame)
        output = frame.scope.value(_Raw5)
        _graph_status(_graph_initialize())
        status = _fn0(_c.byref(input0), _c.byref(output))
        _graph_callable_status(status, frame)
        if not _graph_ready(): raise LeanBridgeError(5, "Lean runtime is unavailable")
        return _graph_output5(output, frame.scope)
    except _GraphInvalidNative:
        _graph_retire()
        raise
    finally:
        try:
            _graph_clear(output)
        finally:
            frame.close()

_fn1 = _GraphAssets._LIBRARY["lean_bridge_413afe4aaf66162bb3ba3d3c_graph"]
_fn1.argtypes = [_c.POINTER(_Callback0), _c.POINTER(_Raw5)]
_fn1.restype = _c.c_uint32

def _call1(arg0):
    _GraphAssets._ensure_process()
    checked = _GraphScope(True)
    try:
        _check_callback0(arg0, checked)
    finally:
        checked.close()
    frame = _GraphCallableFrame()
    output = None
    try:
        input0 = _callback0(arg0, frame)
        output = frame.scope.value(_Raw5)
        _graph_status(_graph_initialize())
        status = _fn1(_c.byref(input0), _c.byref(output))
        _graph_callable_status(status, frame)
        if not _graph_ready(): raise LeanBridgeError(5, "Lean runtime is unavailable")
        return _graph_output5(output, frame.scope)
    except _GraphInvalidNative:
        _graph_retire()
        raise
    finally:
        try:
            _graph_clear(output)
        finally:
            frame.close()

_fn2 = _GraphAssets._LIBRARY["lean_bridge_184bfb6b98fb39095f0bfec8_graph"]
_fn2.argtypes = [_c.POINTER(_Callback1), _c.POINTER(_Raw5)]
_fn2.restype = _c.c_uint32

def _call2(arg0):
    _GraphAssets._ensure_process()
    checked = _GraphScope(True)
    try:
        _check_callback1(arg0, checked)
    finally:
        checked.close()
    frame = _GraphCallableFrame()
    output = None
    try:
        input0 = _callback1(arg0, frame)
        output = frame.scope.value(_Raw5)
        _graph_status(_graph_initialize())
        status = _fn2(_c.byref(input0), _c.byref(output))
        _graph_callable_status(status, frame)
        if not _graph_ready(): raise LeanBridgeError(5, "Lean runtime is unavailable")
        return _graph_output5(output, frame.scope)
    except _GraphInvalidNative:
        _graph_retire()
        raise
    finally:
        try:
            _graph_clear(output)
        finally:
            frame.close()

_fn3 = _GraphAssets._LIBRARY["lean_bridge_f168e18f231fdb7eb1733b0e_graph"]
_fn3.argtypes = [_c.POINTER(_Callback5), _c.POINTER(_Raw5)]
_fn3.restype = _c.c_uint32

def _call3(arg0):
    _GraphAssets._ensure_process()
    checked = _GraphScope(True)
    try:
        _check_callback5(arg0, checked)
    finally:
        checked.close()
    frame = _GraphCallableFrame()
    output = None
    try:
        input0 = _callback5(arg0, frame)
        output = frame.scope.value(_Raw5)
        _graph_status(_graph_initialize())
        status = _fn3(_c.byref(input0), _c.byref(output))
        _graph_callable_status(status, frame)
        if not _graph_ready(): raise LeanBridgeError(5, "Lean runtime is unavailable")
        return _graph_output5(output, frame.scope)
    except _GraphInvalidNative:
        _graph_retire()
        raise
    finally:
        try:
            _graph_clear(output)
        finally:
            frame.close()

_fn4 = _GraphAssets._LIBRARY["lean_bridge_97d7a19c3e5ee22681017ca9_graph"]
_fn4.argtypes = [_c.POINTER(_Raw5), _c.POINTER(_c.c_uint64)]
_fn4.restype = _c.c_uint32

def _call4(arg0):
    _GraphAssets._ensure_process()
    checked = _GraphScope(True)
    try:
        _graph_input5(arg0, checked)
    finally:
        checked.close()
    frame = _GraphCallableFrame()
    output = None
    try:
        input0 = _graph_input5(arg0, frame.scope)
        output = frame.scope.value(_c.c_uint64)
        _graph_status(_graph_initialize())
        status = _fn4(_c.byref(input0), _c.byref(output))
        _graph_callable_status(status, frame)
        if not _graph_ready(): raise LeanBridgeError(5, "Lean runtime is unavailable")
        result = _graph_own(output, _invoke2, _dispose2)
        output = None
        return result
    except _GraphInvalidNative:
        _graph_retire()
        raise
    finally:
        try:
            if output is not None and output.value:
                token, output.value = output.value, 0
                _dispose2(token)
        finally:
            frame.close()

_fn5 = _GraphAssets._LIBRARY["lean_bridge_74ed57fc03e7ed555389a3ab_graph"]
_fn5.argtypes = [_c.POINTER(_Raw5), _c.POINTER(_c.c_uint64)]
_fn5.restype = _c.c_uint32

def _call5(arg0):
    _GraphAssets._ensure_process()
    checked = _GraphScope(True)
    try:
        _graph_input5(arg0, checked)
    finally:
        checked.close()
    frame = _GraphCallableFrame()
    output = None
    try:
        input0 = _graph_input5(arg0, frame.scope)
        output = frame.scope.value(_c.c_uint64)
        _graph_status(_graph_initialize())
        status = _fn5(_c.byref(input0), _c.byref(output))
        _graph_callable_status(status, frame)
        if not _graph_ready(): raise LeanBridgeError(5, "Lean runtime is unavailable")
        result = _graph_own(output, _invoke7, _dispose7)
        output = None
        return result
    except _GraphInvalidNative:
        _graph_retire()
        raise
    finally:
        try:
            if output is not None and output.value:
                token, output.value = output.value, 0
                _dispose7(token)
        finally:
            frame.close()

_fn6 = _GraphAssets._LIBRARY["lean_bridge_bbabc0c3fa2252f4f7a67708_graph"]
_fn6.argtypes = [_c.POINTER(_Raw5), _c.POINTER(_c.c_uint64)]
_fn6.restype = _c.c_uint32

def _call6(arg0):
    _GraphAssets._ensure_process()
    checked = _GraphScope(True)
    try:
        _graph_input5(arg0, checked)
    finally:
        checked.close()
    frame = _GraphCallableFrame()
    output = None
    try:
        input0 = _graph_input5(arg0, frame.scope)
        output = frame.scope.value(_c.c_uint64)
        _graph_status(_graph_initialize())
        status = _fn6(_c.byref(input0), _c.byref(output))
        _graph_callable_status(status, frame)
        if not _graph_ready(): raise LeanBridgeError(5, "Lean runtime is unavailable")
        result = _graph_own(output, _invoke6, _dispose6)
        output = None
        return result
    except _GraphInvalidNative:
        _graph_retire()
        raise
    finally:
        try:
            if output is not None and output.value:
                token, output.value = output.value, 0
                _dispose6(token)
        finally:
            frame.close()

_fn7 = _GraphAssets._LIBRARY["lean_bridge_77496697d09177e0d1ebadfd_graph"]
_fn7.argtypes = [_c.POINTER(_Raw5), _c.POINTER(_c.c_uint64)]
_fn7.restype = _c.c_uint32

def _call7(arg0):
    _GraphAssets._ensure_process()
    checked = _GraphScope(True)
    try:
        _graph_input5(arg0, checked)
    finally:
        checked.close()
    frame = _GraphCallableFrame()
    output = None
    try:
        input0 = _graph_input5(arg0, frame.scope)
        output = frame.scope.value(_c.c_uint64)
        _graph_status(_graph_initialize())
        status = _fn7(_c.byref(input0), _c.byref(output))
        _graph_callable_status(status, frame)
        if not _graph_ready(): raise LeanBridgeError(5, "Lean runtime is unavailable")
        result = _graph_own(output, _invoke4, _dispose4)
        output = None
        return result
    except _GraphInvalidNative:
        _graph_retire()
        raise
    finally:
        try:
            if output is not None and output.value:
                token, output.value = output.value, 0
                _dispose4(token)
        finally:
            frame.close()
