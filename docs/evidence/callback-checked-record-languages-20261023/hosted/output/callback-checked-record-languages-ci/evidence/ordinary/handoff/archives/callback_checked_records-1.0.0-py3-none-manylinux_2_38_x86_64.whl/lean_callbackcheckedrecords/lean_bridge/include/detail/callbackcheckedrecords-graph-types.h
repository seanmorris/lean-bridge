#ifndef CALLBACKCHECKEDRECORDS_COPIED_GRAPH_H
#define CALLBACKCHECKEDRECORDS_COPIED_GRAPH_H
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <string.h>

typedef struct callbackcheckedrecords_graph_38a8689c2f20ead532ea_t callbackcheckedrecords_graph_38a8689c2f20ead532ea_t;
typedef struct callbackcheckedrecords_graph_7ee21eb6b8ea120b53f0_t callbackcheckedrecords_graph_7ee21eb6b8ea120b53f0_t;
typedef struct callbackcheckedrecords_graph_29468227bdfd05da1480_t callbackcheckedrecords_graph_29468227bdfd05da1480_t;
typedef struct callbackcheckedrecords_interval_t callbackcheckedrecords_interval_t;
typedef struct callbackcheckedrecords_weighted_t callbackcheckedrecords_weighted_t;
typedef struct callbackcheckedrecords_scalar_nat_t callbackcheckedrecords_scalar_nat_t;
typedef struct callbackcheckedrecords_scalar_string_t callbackcheckedrecords_scalar_string_t;
struct callbackcheckedrecords_scalar_nat_t {
  void *_bridge_owner;
  void (*_bridge_release)(void *owner);
  const uint32_t *data;
  size_t length;
};
static inline void callbackcheckedrecords_scalar_nat_t_init(callbackcheckedrecords_scalar_nat_t *value) {
  if (!value) return;
  memset(value, 0, sizeof(*value));
}
static inline void callbackcheckedrecords_scalar_nat_t_clear(callbackcheckedrecords_scalar_nat_t *value) {
  if (!value) return;
  void *owner = value->_bridge_owner;
  void (*release)(void *) = value->_bridge_release;
  callbackcheckedrecords_scalar_nat_t_init(value);
  if (owner && release) release(owner);
}

struct callbackcheckedrecords_interval_t {
  void *_bridge_owner;
  void (*_bridge_release)(void *owner);
  callbackcheckedrecords_scalar_nat_t lo;
  callbackcheckedrecords_scalar_nat_t hi;
};
static inline void callbackcheckedrecords_interval_t_init(callbackcheckedrecords_interval_t *value) {
  if (!value) return;
  memset(value, 0, sizeof(*value));
}
static inline void callbackcheckedrecords_interval_t_clear(callbackcheckedrecords_interval_t *value) {
  if (!value) return;
  void *owner = value->_bridge_owner;
  void (*release)(void *) = value->_bridge_release;
  callbackcheckedrecords_interval_t_init(value);
  if (owner && release) release(owner);
}

struct callbackcheckedrecords_graph_38a8689c2f20ead532ea_t {
  void *_bridge_owner;
  void (*_bridge_release)(void *owner);
  uint8_t has_value;
  callbackcheckedrecords_interval_t value;
};
static inline void callbackcheckedrecords_graph_38a8689c2f20ead532ea_t_init(callbackcheckedrecords_graph_38a8689c2f20ead532ea_t *value) {
  if (!value) return;
  memset(value, 0, sizeof(*value));
}
static inline void callbackcheckedrecords_graph_38a8689c2f20ead532ea_t_clear(callbackcheckedrecords_graph_38a8689c2f20ead532ea_t *value) {
  if (!value) return;
  void *owner = value->_bridge_owner;
  void (*release)(void *) = value->_bridge_release;
  callbackcheckedrecords_graph_38a8689c2f20ead532ea_t_init(value);
  if (owner && release) release(owner);
}

struct callbackcheckedrecords_graph_7ee21eb6b8ea120b53f0_t {
  void *_bridge_owner;
  void (*_bridge_release)(void *owner);
  const callbackcheckedrecords_graph_38a8689c2f20ead532ea_t *data;
  size_t length;
};
static inline void callbackcheckedrecords_graph_7ee21eb6b8ea120b53f0_t_init(callbackcheckedrecords_graph_7ee21eb6b8ea120b53f0_t *value) {
  if (!value) return;
  memset(value, 0, sizeof(*value));
}
static inline void callbackcheckedrecords_graph_7ee21eb6b8ea120b53f0_t_clear(callbackcheckedrecords_graph_7ee21eb6b8ea120b53f0_t *value) {
  if (!value) return;
  void *owner = value->_bridge_owner;
  void (*release)(void *) = value->_bridge_release;
  callbackcheckedrecords_graph_7ee21eb6b8ea120b53f0_t_init(value);
  if (owner && release) release(owner);
}

struct callbackcheckedrecords_scalar_string_t {
  void *_bridge_owner;
  void (*_bridge_release)(void *owner);
  const char *data;
  size_t length;
};
static inline void callbackcheckedrecords_scalar_string_t_init(callbackcheckedrecords_scalar_string_t *value) {
  if (!value) return;
  memset(value, 0, sizeof(*value));
}
static inline void callbackcheckedrecords_scalar_string_t_clear(callbackcheckedrecords_scalar_string_t *value) {
  if (!value) return;
  void *owner = value->_bridge_owner;
  void (*release)(void *) = value->_bridge_release;
  callbackcheckedrecords_scalar_string_t_init(value);
  if (owner && release) release(owner);
}

struct callbackcheckedrecords_graph_29468227bdfd05da1480_t {
  void *_bridge_owner;
  void (*_bridge_release)(void *owner);
  uint8_t is_ok;
  callbackcheckedrecords_graph_38a8689c2f20ead532ea_t ok;
  callbackcheckedrecords_scalar_string_t error;
};
static inline void callbackcheckedrecords_graph_29468227bdfd05da1480_t_init(callbackcheckedrecords_graph_29468227bdfd05da1480_t *value) {
  if (!value) return;
  memset(value, 0, sizeof(*value));
}
static inline void callbackcheckedrecords_graph_29468227bdfd05da1480_t_clear(callbackcheckedrecords_graph_29468227bdfd05da1480_t *value) {
  if (!value) return;
  void *owner = value->_bridge_owner;
  void (*release)(void *) = value->_bridge_release;
  callbackcheckedrecords_graph_29468227bdfd05da1480_t_init(value);
  if (owner && release) release(owner);
}

struct callbackcheckedrecords_weighted_t {
  void *_bridge_owner;
  void (*_bridge_release)(void *owner);
  callbackcheckedrecords_scalar_nat_t weight;
  callbackcheckedrecords_scalar_nat_t limit;
};
static inline void callbackcheckedrecords_weighted_t_init(callbackcheckedrecords_weighted_t *value) {
  if (!value) return;
  memset(value, 0, sizeof(*value));
}
static inline void callbackcheckedrecords_weighted_t_clear(callbackcheckedrecords_weighted_t *value) {
  if (!value) return;
  void *owner = value->_bridge_owner;
  void (*release)(void *) = value->_bridge_release;
  callbackcheckedrecords_weighted_t_init(value);
  if (owner && release) release(owner);
}


#endif /* CALLBACKCHECKEDRECORDS_COPIED_GRAPH_H */
