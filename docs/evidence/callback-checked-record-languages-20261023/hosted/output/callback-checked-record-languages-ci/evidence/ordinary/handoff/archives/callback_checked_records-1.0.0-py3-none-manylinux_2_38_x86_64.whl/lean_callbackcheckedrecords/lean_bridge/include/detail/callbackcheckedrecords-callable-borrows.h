#pragma once
#include "callbackcheckedrecords-graph-types.h"
typedef struct callbackcheckedrecords_callback_2663a58c7c0e71654db1d87936875f8677e197b2 {
  uint32_t (*call)(void *, const callbackcheckedrecords_graph_38a8689c2f20ead532ea_t *arg0, callbackcheckedrecords_graph_29468227bdfd05da1480_t *out);
  void *context;
  const callbackcheckedrecords_graph_29468227bdfd05da1480_t *recovery;
} callbackcheckedrecords_callback_2663a58c7c0e71654db1d87936875f8677e197b2;
typedef struct callbackcheckedrecords_callback_526ba4a0f03797057c1f9a17ca435a5a42131510 {
  uint32_t (*call)(void *, const callbackcheckedrecords_scalar_nat_t *arg0, const callbackcheckedrecords_interval_t *arg1, callbackcheckedrecords_interval_t *out);
  void *context;
  const callbackcheckedrecords_interval_t *recovery;
} callbackcheckedrecords_callback_526ba4a0f03797057c1f9a17ca435a5a42131510;
typedef struct callbackcheckedrecords_callback_e014092ff0a1ee8527eeeb58a78e2de63bdf09fa {
  uint32_t (*call)(void *, const callbackcheckedrecords_interval_t *arg0, callbackcheckedrecords_scalar_nat_t *out);
  void *context;
} callbackcheckedrecords_callback_e014092ff0a1ee8527eeeb58a78e2de63bdf09fa;
typedef struct callbackcheckedrecords_callback_00652748bed3eb7036c9091f570efa39888f5490 {
  uint32_t (*call)(void *, const callbackcheckedrecords_interval_t *arg0, callbackcheckedrecords_interval_t *out);
  void *context;
  const callbackcheckedrecords_interval_t *recovery;
} callbackcheckedrecords_callback_00652748bed3eb7036c9091f570efa39888f5490;
typedef struct callbackcheckedrecords_callback_d885a7d82ec894d17b81e7a67a36bc2930adca13 {
  uint32_t (*call)(void *, const callbackcheckedrecords_weighted_t *arg0, callbackcheckedrecords_scalar_nat_t *out);
  void *context;
} callbackcheckedrecords_callback_d885a7d82ec894d17b81e7a67a36bc2930adca13;
typedef struct callbackcheckedrecords_callback_cd01d463066ae86d043223e65eab1640e16b22ab {
  uint32_t (*call)(void *, const callbackcheckedrecords_weighted_t *arg0, callbackcheckedrecords_weighted_t *out);
  void *context;
  const callbackcheckedrecords_weighted_t *recovery;
} callbackcheckedrecords_callback_cd01d463066ae86d043223e65eab1640e16b22ab;
typedef struct callbackcheckedrecords_callback_2e292aebff8c53f6a465ec3d5745e74400590434 {
  uint32_t (*call)(void *, const callbackcheckedrecords_scalar_nat_t *arg0, const callbackcheckedrecords_interval_t *arg1, callbackcheckedrecords_interval_t *out);
  void *context;
} callbackcheckedrecords_callback_2e292aebff8c53f6a465ec3d5745e74400590434;
typedef struct callbackcheckedrecords_callback_8994592329ecba032f0abfaa9703e59a57f3c6a1 {
  uint32_t (*call)(void *, const callbackcheckedrecords_graph_7ee21eb6b8ea120b53f0_t *arg0, callbackcheckedrecords_graph_38a8689c2f20ead532ea_t *out);
  void *context;
} callbackcheckedrecords_callback_8994592329ecba032f0abfaa9703e59a57f3c6a1;
