import { createPhpWasmCopiedDescriptor } from './host.mjs';
const runtime = Object.freeze({"identity":"44535fd7b0e510b50f3aae5e2134970012d90e9f6be04048a04dce85bddbd966","loaderIdentity":"4c88837c0f4e612c0a1c8b345239db679c7bfc7a5e071ee99fc1b059959babba","library":"liblean_bridge_php_wasm_copied_abe4dea500dab9519b8d.so"});
export const createDescriptor = (component, assets) => createPhpWasmCopiedDescriptor({ ...runtime, url: new URL("./compiled/lib/liblean_bridge_php_wasm_copied_abe4dea500dab9519b8d.so", import.meta.url) }, component, assets);
