<?php
declare(strict_types=1);
namespace LeanBridge\CopiedPhpWasmV1 {
if (!class_exists(Loader::class, false)) {
    final class Loader {
        private static ?string $failure = null;
        private static bool $loading = false;
        private static int $callbacks = 0;
        public static function enterCallback(): void { ++self::$callbacks; }
        public static function leaveCallback(): void { --self::$callbacks; }
        public static function load(string $library, string $function): void {
            if (self::$failure !== null) throw new \RuntimeException(self::$failure);
            if (self::$loading) throw new \RuntimeException('Reentrant PHP-Wasm extension loading is not supported');
            // dl may suspend the host to fetch or instantiate a side module.
            // The synchronous Lean stack cannot participate in that unwind.
            if (self::$callbacks !== 0) throw new \RuntimeException('Cannot load a PHP-Wasm extension inside a synchronous Lean callback. Use its startup descriptor or call that package before entering the callback.');
            $registration = '/__lean_bridge/php_wasm_lazy/' . $library . '.txt';
            if (!is_file($registration) || file_get_contents($registration) !== $library) {
                throw new \RuntimeException('Register this package lazy descriptor in dynamicLibs before PHP starts');
            }
            if (!function_exists('dl') || !ini_get('enable_dl')) {
                throw new \RuntimeException('PHP-Wasm lazy loading requires enable_dl=1');
            }
            self::$loading = true;
            try {
                set_error_handler(static function (int $severity, string $message): never {
                    throw new \RuntimeException($message);
                });
                try {
                    if (!dl($library) || !function_exists($function)) {
                        throw new \RuntimeException('The generated Zend transport did not load');
                    }
                } finally { restore_error_handler(); }
            } catch (\Throwable $error) {
                // Emscripten may retain a partially linked DSO after failure.
                // Do not attempt another lazy load in that PHP instance.
                self::$failure = 'PHP-Wasm extension loading failed; create a new PHP instance. ' . $error->getMessage();
                throw new \RuntimeException(self::$failure, 0, $error);
            } finally { self::$loading = false; }
        }
    }
}
}

namespace LeanNestedcheckedrecords\Internal {

final class Budget
{
    private int $remaining = 16 * 1024 * 1024;
    public function charge(int $count, int $width = 1): void {
        if ($count < 0 || $width < 1 || $count > intdiv($this->remaining, $width)) {
            throw new \ValueError('16 MiB PHP conversion limit exceeded');
        }
        $this->remaining -= $count * $width;
    }
}
final class Checks
{
    public static function check0(mixed $value, Budget $budget): mixed {
        $budget->charge(1, 16);
        if (!$value instanceof \Brick\Math\BigInteger) throw new \TypeError('Expected Brick Math BigInteger');
        $decimal = (string) $value;
        if (strlen($decimal) > 16385 || strlen(ltrim($decimal, '-')) > 16384 || preg_match('/^(?:0|-?[1-9][0-9]*)$/D', $decimal) !== 1) throw new \ValueError('BigInteger requires canonical decimal text of at most 16384 digits');
        $budget->charge(strlen($decimal));
        if ($decimal[0] === '-') throw new \ValueError('Expected an unsigned integer');
        return $value;
    }
    public static function check1(mixed $value, Budget $budget): mixed {
        $budget->charge(1, 16);
        if (!$value instanceof \LeanNestedcheckedrecords\Packet) throw new \TypeError('Expected Packet');
        if (array_keys(get_object_vars($value)) !== ['digit', 'word']) throw new \TypeError('Packet requires exactly its initialized fields');
        self::check0($value->digit, $budget);
        self::check0($value->word, $budget);
        return $value;
    }
    public static function check2(mixed $value, Budget $budget): mixed {
        $budget->charge(1, 16);
        if (!is_array($value) || !array_is_list($value)) throw new \TypeError('Expected a list with consecutive integer keys');
        $budget->charge(count($value), 32);
        $result = [];
        foreach ($value as $item) $result[] = self::check1($item, $budget);
        return $result;
    }
    public static function check3(mixed $value, Budget $budget): mixed {
        $budget->charge(1, 16);
        if ($value === null) return null;
        if ($value instanceof \LeanNestedcheckedrecords\Some) {
            if (array_keys(get_object_vars($value)) !== ['value']) throw new \TypeError('Some requires one initialized value field');
            return new \LeanNestedcheckedrecords\Some(self::check1($value->value, $budget));
        }
        throw new \TypeError('Expected Some');
    }
}
final class Values
{
    private static function step(Budget $budget, int $depth): void {
        if ($depth > 32) throw new \ValueError('Value comparison exceeds 32 nesting levels');
        $budget->charge(1, 32);
    }
    private static function fields(object $value, Budget $budget): array {
        $expected = match ($value::class) {
            \LeanNestedcheckedrecords\Some::class => ['value'],
            \LeanNestedcheckedrecords\Packet::class => ['digit', 'word'],
            default => throw new \TypeError('Value comparison requires generated copied values'),
        };
        $budget->charge(count($expected), 32);
        $fields = get_object_vars($value);
        if (array_keys($fields) !== $expected) throw new \TypeError('Value comparison requires initialized fields');
        return $fields;
    }
    public static function equal(mixed $left, mixed $right): bool {
        return self::same($left, $right, new Budget(), 0);
    }
    private static function same(mixed $left, mixed $right, Budget $budget, int $depth): bool {
        self::step($budget, $depth);
        if (get_debug_type($left) !== get_debug_type($right)) return false;
        if (is_float($left)) return is_nan($left) ? is_nan($right) : pack('E', $left) === pack('E', $right);
        if ($left instanceof \Brick\Math\BigInteger) { $left = (string) $left; $right = (string) $right; }
        elseif ($left instanceof \LeanNestedcheckedrecords\Bytes) { $left = $left->toString(); $right = $right->toString(); }
        elseif (is_object($left)) {
            $left = self::fields($left, $budget); $right = self::fields($right, $budget);
            foreach ($left as $name => $value) if (!self::same($value, $right[$name], $budget, $depth + 1)) return false;
            return true;
        }
        if (is_string($left)) { $budget->charge(strlen($left)); $budget->charge(strlen($right)); return $left === $right; }
        if (is_array($left)) {
            $budget->charge(count($left), 32); $budget->charge(count($right), 32);
            if (!array_is_list($left) || !array_is_list($right)) throw new \TypeError('Value comparison requires consecutive-key lists');
            if (count($left) !== count($right)) return false;
            foreach ($left as $index => $value) if (!self::same($value, $right[$index], $budget, $depth + 1)) return false;
            return true;
        }
        if ($left === null || is_bool($left) || is_int($left)) return $left === $right;
        throw new \TypeError('Value comparison requires copied values');
    }
    private static function text(\HashContext $hash, string $tag, string $text, Budget $budget): void {
        $budget->charge(strlen($text));
        hash_update($hash, $tag . pack('N', strlen($text))); hash_update($hash, $text);
    }
    public static function hash(mixed $value): string {
        $hash = hash_init('sha256'); self::append($hash, $value, new Budget(), 0); return hash_final($hash);
    }
    private static function append(\HashContext $hash, mixed $value, Budget $budget, int $depth): void {
        self::step($budget, $depth);
        if ($value === null) hash_update($hash, 'n');
        elseif (is_bool($value)) hash_update($hash, $value ? 't' : 'f');
        elseif (is_int($value)) self::text($hash, 'i', (string) $value, $budget);
        elseif (is_float($value)) hash_update($hash, is_nan($value) ? 'q' : 'd' . pack('E', $value));
        elseif (is_string($value)) self::text($hash, 's', $value, $budget);
        elseif ($value instanceof \Brick\Math\BigInteger) self::text($hash, 'b', (string) $value, $budget);
        elseif ($value instanceof \LeanNestedcheckedrecords\Bytes) self::text($hash, 'y', $value->toString(), $budget);
        elseif (is_array($value)) {
            $budget->charge(count($value), 32);
            if (!array_is_list($value)) throw new \TypeError('Value hashing requires consecutive-key lists');
            hash_update($hash, 'a' . pack('N', count($value)));
            foreach ($value as $item) self::append($hash, $item, $budget, $depth + 1);
        } elseif (is_object($value)) {
            $fields = self::fields($value, $budget);
            self::text($hash, 'o', $value::class, $budget);
            foreach ($fields as $name => $item) { self::text($hash, 'k', $name, $budget); self::append($hash, $item, $budget, $depth + 1); }
        } else throw new \TypeError('Value hashing requires copied values');
    }
}


final class Native
{
    private static function to0(mixed $value): mixed { return (string) $value; }
    private static function from0(mixed $value): mixed { return \Brick\Math\BigInteger::of($value); }
    private static function to1(mixed $value): mixed { return [self::to0($value->digit), self::to0($value->word)]; }
    private static function from1(mixed $value): mixed { return new \LeanNestedcheckedrecords\Packet(self::from0($value[0]), self::from0($value[1])); }
    private static function to2(mixed $value): mixed { return array_map(self::to1(...), $value); }
    private static function from2(mixed $value): mixed { return array_map(self::from1(...), $value); }
    private static function to3(mixed $value): mixed { return $value === null ? null : [self::to1($value->value)]; }
    private static function from3(mixed $value): mixed { return $value === null ? null : new \LeanNestedcheckedrecords\Some(self::from1($value[0])); }

    public static function call0(mixed $arg0): mixed {
        $budget = new Budget();
        $input0 = self::to0(Checks::check0($arg0, $budget));
        if (!function_exists('LeanNestedcheckedrecords\Internal\Zendf56d840133a10b35\\call0')) {
            try { \LeanBridge\CopiedPhpWasmV1\Loader::load('php8.4-lb_nestedcheckedrecords_f56d840133a10b35.so', 'LeanNestedcheckedrecords\Internal\Zendf56d840133a10b35\\call0'); }
            catch (\Throwable $error) { throw new \LeanNestedcheckedrecords\LeanBridgeError($error->getMessage(), 0, $error); }
        }
        try { $output = \LeanNestedcheckedrecords\Internal\Zendf56d840133a10b35\call0($input0); }
        catch (\Exception $error) { throw new \LeanNestedcheckedrecords\LeanBridgeError($error->getMessage(), $error->getCode(), $error); }
        return self::from2($output);
    }
    public static function call1(mixed $arg0): mixed {
        $budget = new Budget();
        $input0 = self::to0(Checks::check0($arg0, $budget));
        if (!function_exists('LeanNestedcheckedrecords\Internal\Zendf56d840133a10b35\\call1')) {
            try { \LeanBridge\CopiedPhpWasmV1\Loader::load('php8.4-lb_nestedcheckedrecords_f56d840133a10b35.so', 'LeanNestedcheckedrecords\Internal\Zendf56d840133a10b35\\call1'); }
            catch (\Throwable $error) { throw new \LeanNestedcheckedrecords\LeanBridgeError($error->getMessage(), 0, $error); }
        }
        try { $output = \LeanNestedcheckedrecords\Internal\Zendf56d840133a10b35\call1($input0); }
        catch (\Exception $error) { throw new \LeanNestedcheckedrecords\LeanBridgeError($error->getMessage(), $error->getCode(), $error); }
        return self::from3($output);
    }
}
}
