#pragma once
#include "owned_checked_records.h"
#include <atomic>
#include <cstdint>
#include <list>
#include <memory>
#include <mutex>
#include <optional>
#include <stdexcept>
#include <string>
#include <thread>
#include <type_traits>
#include <utility>
#include <variant>
#include <vector>
#include <unistd.h>
#ifndef BOOST_MP_STANDALONE
#define BOOST_MP_STANDALONE
#endif
#include <boost/multiprecision/cpp_int.hpp>
namespace lean_bridge::owned_checked_records {

class Error final : public std::runtime_error {
public:
  owned_checked_records_status status;
  explicit Error(owned_checked_records_status value) : std::runtime_error("Lean ownership boundary rejected the operation"), status(value) {}
};
namespace detail {
inline void checked(owned_checked_records_status value) { if (value != OWNED_CHECKED_RECORDS_OK) throw Error(value); }
struct NativeOwner {
  owned_checked_records_result *value = nullptr;
  NativeOwner() = default;
  NativeOwner(const NativeOwner&) = delete;
  NativeOwner& operator=(const NativeOwner&) = delete;
  ~NativeOwner() { if (value) (void)owned_checked_records_result_release(&value); }
};
struct Slot {
  std::atomic<owned_checked_records_result *> owner{nullptr};
  bool pending = false;
};
struct BorrowScope { std::atomic<bool> active{true}; };
class State;
class Lease {
  std::shared_ptr<State> state_;
  std::shared_ptr<Slot> slot_;
  std::shared_ptr<BorrowScope> borrow_;
  friend class State;
  Lease(std::shared_ptr<State> state, std::shared_ptr<Slot> slot) noexcept
    : state_(std::move(state)), slot_(std::move(slot)) {}
  Lease(std::shared_ptr<State> state, std::shared_ptr<BorrowScope> borrow) noexcept
    : state_(std::move(state)), borrow_(std::move(borrow)) {}
public:
  Lease(const Lease&) = delete;
  Lease& operator=(const Lease&) = delete;
  ~Lease();
  const std::shared_ptr<State>& state() const noexcept { return state_; }
  void require() const;
  bool closed() const noexcept;
};
class State final : public std::enable_shared_from_this<State> {
  owned_checked_records_session *session_ = nullptr;
  const pid_t process_ = ::getpid();
  const std::thread::id thread_ = std::this_thread::get_id();
  std::atomic<bool> closed_{false}, exited_{false};
  std::mutex mutex_;
  std::list<std::shared_ptr<Slot>> slots_;
  friend class Lease;
  bool owner_thread() const noexcept { return process_ == ::getpid() && thread_ == std::this_thread::get_id(); }
  void affinity() const {
    if (process_ != ::getpid()) throw Error(OWNED_CHECKED_RECORDS_WRONG_PROCESS);
    if (exited_.load()) throw Error(OWNED_CHECKED_RECORDS_CLOSED);
    if (thread_ != std::this_thread::get_id()) throw Error(OWNED_CHECKED_RECORDS_WRONG_THREAD);
  }
  void release(const std::shared_ptr<Slot>& slot) noexcept {
    if (process_ != ::getpid() || exited_.load()) return;
    {
      std::lock_guard lock(mutex_);
      if (!slot->owner.load()) return;
      slot->pending = true;
    }
    if (owner_thread()) drain();
  }
public:
  State() { checked(owned_checked_records_session_open(&session_)); }
  State(const State&) = delete;
  State& operator=(const State&) = delete;
  ~State() { retire(); }
  bool closed() const noexcept { return process_ != ::getpid() || closed_.load() || exited_.load(); }
  void drain() noexcept {
    if (!owner_thread() || exited_.load()) return;
    for (;;) {
      std::shared_ptr<Slot> selected;
      owned_checked_records_result *owner = nullptr;
      {
        std::lock_guard lock(mutex_);
        for (const auto& slot : slots_) if (slot->pending && slot->owner.load()) {
          selected = slot; owner = slot->owner.exchange(nullptr); break;
        }
      }
      if (!selected) return;
      (void)owned_checked_records_result_release(&owner);
      {
        std::lock_guard lock(mutex_);
        if (owner) { selected->owner.store(owner); return; }
        slots_.remove(selected);
      }
    }
  }
  owned_checked_records_session *require() {
    affinity();
    if (closed_.load()) throw Error(OWNED_CHECKED_RECORDS_CLOSED);
    drain(); return session_;
  }
  std::shared_ptr<Lease> adopt(NativeOwner& owner) {
    (void)require();
    if (!owner.value) throw Error(OWNED_CHECKED_RECORDS_INVALID_ARGUMENT);
    auto slot = std::make_shared<Slot>();
    // Allocate every C++ control before moving native ownership out of the guard.
    auto lease = std::shared_ptr<Lease>(new Lease(shared_from_this(), slot));
    {
      std::lock_guard lock(mutex_);
      slots_.push_back(slot);
      slot->owner.store(owner.value); owner.value = nullptr;
    }
    return lease;
  }
  std::shared_ptr<Lease> borrow(const std::shared_ptr<BorrowScope>& scope) {
    (void)require();
    if (!scope || !scope->active.load()) throw Error(OWNED_CHECKED_RECORDS_CLOSED);
    return std::shared_ptr<Lease>(new Lease(shared_from_this(), scope));
  }
  void close() {
    affinity();
    if (!closed_.load()) { checked(owned_checked_records_session_close(&session_)); closed_.store(true); }
    {
      std::lock_guard lock(mutex_);
      for (const auto& slot : slots_) slot->pending = true;
    }
    drain();
  }
  void retire() noexcept {
    if (!owner_thread() || exited_.load()) return;
    try { close(); } catch (...) { return; }
    // No new adoption is possible after close. Mark thread exit only after all
    // registered owners have been visited on their native creating thread.
    exited_.store(true);
  }
};
inline Lease::~Lease() { if (slot_) state_->release(slot_); }
inline bool Lease::closed() const noexcept {
  return state_->closed() || (borrow_ ? !borrow_->active.load() : !slot_->owner.load());
}
inline void Lease::require() const {
  (void)state_->require();
  if (borrow_ ? !borrow_->active.load() : !slot_->owner.load()) throw Error(OWNED_CHECKED_RECORDS_CLOSED);
}
struct BorrowFrame {
  std::shared_ptr<BorrowScope> scope = std::make_shared<BorrowScope>();
  std::shared_ptr<Lease> lease;
  explicit BorrowFrame(const std::shared_ptr<State>& state) : lease(state->borrow(scope)) {}
  BorrowFrame(const BorrowFrame&) = delete;
  BorrowFrame& operator=(const BorrowFrame&) = delete;
  ~BorrowFrame() { scope->active.store(false); }
};
struct LocalState {
  std::shared_ptr<State> value;
  ~LocalState() { if (value) value->retire(); }
};
inline std::shared_ptr<State> current_state() {
  static thread_local LocalState local;
  if (!local.value) local.value = std::make_shared<State>();
  (void)local.value->require(); return local.value;
}
struct ResourceAccess;
template<class Kind> struct ResourceOps;
}
template<class Kind> class Resource {
  std::shared_ptr<detail::Lease> lease_;
  void *handle_ = nullptr;
  Resource(std::shared_ptr<detail::Lease> lease, void *handle) noexcept
    : lease_(std::move(lease)), handle_(handle) {}
  friend struct detail::ResourceAccess;
public:
  Resource() noexcept = default;
  Resource(const Resource&) noexcept = default;
  Resource& operator=(const Resource&) noexcept = default;
  Resource(Resource&& other) noexcept
    : lease_(std::move(other.lease_)), handle_(std::exchange(other.handle_, nullptr)) {}
  Resource& operator=(Resource&& other) noexcept {
    if (this != &other) { lease_ = std::move(other.lease_); handle_ = std::exchange(other.handle_, nullptr); }
    return *this;
  }
  void close() noexcept { lease_.reset(); handle_ = nullptr; }
  bool is_closed() const noexcept { return !lease_ || !handle_ || lease_->closed(); }
  Resource retain() const { return detail::ResourceOps<Kind>::retain(*this); }
  template<class... Args> decltype(auto) operator()(Args&&... args) const
    requires requires { detail::ResourceOps<Kind>::call(*this, std::forward<Args>(args)...); } {
    return detail::ResourceOps<Kind>::call(*this, std::forward<Args>(args)...);
  }
  friend bool operator==(const Resource& a, const Resource& b) noexcept {
    return a.handle_ == b.handle_ && ((!a.lease_ && !b.lease_)
      || (a.lease_ && b.lease_ && a.lease_->state() == b.lease_->state()));
  }
};
namespace detail {
struct ResourceAccess {
  template<class Kind> static Resource<Kind> make(std::shared_ptr<Lease> lease, void *handle) {
    if (!lease || !handle) throw Error(OWNED_CHECKED_RECORDS_INVALID_ARGUMENT);
    lease->require(); return Resource<Kind>(std::move(lease), handle);
  }
  template<class Native, class Kind> static Native get(const Resource<Kind>& value, const std::shared_ptr<State>& state) {
    if (!value.lease_ || !value.handle_) throw Error(OWNED_CHECKED_RECORDS_CLOSED);
    value.lease_->require();
    if (value.lease_->state() != state) throw Error(OWNED_CHECKED_RECORDS_INVALID_ARGUMENT);
    return reinterpret_cast<Native>(value.handle_);
  }
};
}

namespace detail {
template<class T, class U> struct BoxInput : std::is_same<T, U> {};
template<class... T, class U> struct BoxInput<std::variant<T...>, U>
  : std::bool_constant<std::is_same_v<std::variant<T...>, U> || (std::is_same_v<T, U> || ...)> {};
template<class T, class U> struct BoxInput<std::optional<T>, U>
  : std::bool_constant<std::is_same_v<std::optional<T>, U> || std::is_same_v<T, U> || std::is_same_v<std::nullopt_t, U>> {};
}
template<class T> class Box {
  std::unique_ptr<T> value_;
public:
  Box() noexcept = default;
  template<class U>
  requires detail::BoxInput<T, std::remove_cvref_t<U>>::value
  Box(U&& value) : value_(std::make_unique<T>(std::forward<U>(value))) {}
  Box(const Box& other) : value_(other ? std::make_unique<T>(*other) : nullptr) {}
  Box(Box&&) noexcept = default;
  Box& operator=(const Box& other) {
    if (this != &other) { Box copy(other); value_.swap(copy.value_); }
    return *this;
  }
  Box& operator=(Box&&) noexcept = default;
  template<class U>
  requires detail::BoxInput<T, std::remove_cvref_t<U>>::value
  Box& operator=(U&& value) {
    Box copy(std::forward<U>(value)); value_.swap(copy.value_); return *this;
  }
  explicit operator bool() const noexcept { return static_cast<bool>(value_); }
  T& operator*() { if (!value_) throw std::logic_error("Empty Lean value box"); return *value_; }
  const T& operator*() const { if (!value_) throw std::logic_error("Empty Lean value box"); return *value_; }
  T* operator->() { return &**this; }
  const T* operator->() const { return &**this; }
  friend bool operator==(const Box& a, const Box& b) {
    return a ? b && *a == *b : !b;
  }
};
template<class T> struct Ok { T value; friend bool operator==(const Ok&, const Ok&) = default; };
template<class E> struct Err { E value; friend bool operator==(const Err&, const Err&) = default; };
template<class T, class E> using Result = std::variant<Ok<T>, Err<E>>;
using Nat = boost::multiprecision::cpp_int;
using Int = boost::multiprecision::cpp_int;
struct Claim;
namespace detail { struct Identityd79b9bbde250ee1779da; }
using Ticket = Resource<detail::Identityd79b9bbde250ee1779da>;
struct Claim {
  Ticket holder{};
  Nat quota{};
  friend bool operator==(const Claim&, const Claim&);
};
using Value160ce821a84f6887bbfd = std::optional<Claim>;
inline bool operator==(const Claim&, const Claim&) = default;
}
