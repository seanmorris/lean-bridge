#pragma once
#include "owned_checked_records-conversions.hpp"
#include <concepts>
#include <exception>
#include <functional>
namespace lean_bridge::owned_checked_records {
namespace detail {
struct OwnedCall {
  std::shared_ptr<State> state; OwnedBudget budget; std::exception_ptr error;
  explicit OwnedCall(std::shared_ptr<State> value) : state(std::move(value)) {}
  ~OwnedCall() { state->drain(); }
};
template<class F, class R> struct RecoveredCallback { F function; R recovery; };
template<class F> constexpr bool owned_has_recovery = false;
template<class F, class R> constexpr bool owned_has_recovery<RecoveredCallback<F, R>> = true;
template<class F, class Expected> constexpr bool owned_recovery_matches = true;
template<class F, class R, class Expected> constexpr bool owned_recovery_matches<RecoveredCallback<F, R>, Expected> = std::same_as<R, Expected>;
template<class F> inline F& owned_function(F& function) { return function; }
template<class F, class R> inline F& owned_function(RecoveredCallback<F, R>& function) { return function.function; }
template<class F, class R> inline const F& owned_function(const RecoveredCallback<F, R>& function) { return function.function; }
inline Value160ce821a84f6887bbfd owned_invoke0(const Ticket& a0) {
  OwnedCall call(current_state());
  owned_check2(a0, 0, call.budget, call.state);
  OwnedView2 view0(a0, call.state);
  owned_checked_records_value_160ce821a84f6887bbfd_t returned{}; OwnedOutput output(call.state);
  const auto status = owned_checked_records_claim_for(call.state->require(), view0.value, &returned, &output.owner.value);
  if (call.error) std::rethrow_exception(call.error);
  checked(status);
  return owned_from0(returned, 0, call.budget, output);
}
inline Ticket owned_invoke1(const Nat& a0, const std::string& a1) {
  OwnedCall call(current_state());
  owned_check3(a0, 0, call.budget, call.state);
  owned_check4(a1, 0, call.budget, call.state);
  OwnedView3 view0(a0, call.state);
  OwnedView4 view1(a1, call.state);
  owned_checked_records_ticket_t returned{}; OwnedOutput output(call.state);
  const auto status = owned_checked_records_new_ticket(call.state->require(), view0.value, view1.value, &returned, &output.owner.value);
  if (call.error) std::rethrow_exception(call.error);
  checked(status);
  return owned_from2(returned, 0, call.budget, output);
}
inline Nat owned_invoke2(const Ticket& a0) {
  OwnedCall call(current_state());
  owned_check2(a0, 0, call.budget, call.state);
  OwnedView2 view0(a0, call.state);
  mpz_srcptr returned{}; OwnedOutput output(call.state);
  const auto status = owned_checked_records_serial(call.state->require(), view0.value, &returned, &output.owner.value);
  if (call.error) std::rethrow_exception(call.error);
  checked(status);
  return owned_from3(returned, 0, call.budget, output);
}
inline Ticket owned_invoke3(const Ticket& a0) {
  OwnedCall call(current_state());
  owned_check2(a0, 0, call.budget, call.state);
  OwnedView2 view0(a0, call.state);
  owned_checked_records_ticket_t returned{}; OwnedOutput output(call.state);
  const auto status = owned_checked_records_ticket_t_retain(call.state->require(), view0.value, &returned, &output.owner.value);
  if (call.error) std::rethrow_exception(call.error);
  checked(status);
  return owned_from2(returned, 0, call.budget, output);
}
template<> struct ResourceOps<Identityd79b9bbde250ee1779da> {
  static Ticket retain(const Ticket& self) { return owned_invoke3(self); }
};
}
// Recovery supplies a typed failure-path value for Lean cleanup, never a successful host result.
template<class F, class R> inline auto with_recovery(F&& function, R&& recovery) {
  return detail::RecoveredCallback<std::decay_t<F>, std::decay_t<R>>{std::forward<F>(function), std::forward<R>(recovery)};
}
inline Value160ce821a84f6887bbfd claim_for(const Ticket& a0) {
  return detail::owned_invoke0(a0);
}
inline Ticket new_ticket(const Nat& a0, const std::string& a1) {
  return detail::owned_invoke1(a0, a1);
}
inline Nat serial(const Ticket& a0) {
  return detail::owned_invoke2(a0);
}
}
