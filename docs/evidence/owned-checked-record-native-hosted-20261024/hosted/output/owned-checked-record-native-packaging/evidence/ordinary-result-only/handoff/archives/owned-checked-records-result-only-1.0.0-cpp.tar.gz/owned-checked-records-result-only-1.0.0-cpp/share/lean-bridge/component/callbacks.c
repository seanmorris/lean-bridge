#include "component.h"
#include "lean_bridge_native_runtime.h"
static _Thread_local int lean_bridge_owned_callback_failure_57f289e56b88ff350025_state;
int lean_bridge_owned_callback_failure_57f289e56b88ff350025(void) { int result = lean_bridge_owned_callback_failure_57f289e56b88ff350025_state; lean_bridge_owned_callback_failure_57f289e56b88ff350025_state = 0; return result; }
