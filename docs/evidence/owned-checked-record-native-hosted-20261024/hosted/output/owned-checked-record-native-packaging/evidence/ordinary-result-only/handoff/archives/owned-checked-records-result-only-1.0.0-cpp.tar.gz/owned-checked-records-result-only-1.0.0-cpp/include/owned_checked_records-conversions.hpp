#pragma once
#include "owned_checked_records-values.hpp"
#include <climits>
#include <cstring>
#include <iterator>
namespace lean_bridge::owned_checked_records::detail {
static_assert(sizeof(void*) == 8 && sizeof(size_t) == 8 && CHAR_BIT == 8 && sizeof(bool) == 1, "Verified native ownership ABI requires 64-bit pointers and 8-bit bytes");
struct OwnedBudget {
  size_t nodes = 262144, native_bytes = 16777216, storage_bytes = 16777216;
  static void charge(size_t& available, size_t count, size_t width) {
    if (width && count > available / width) throw Error(OWNED_CHECKED_RECORDS_LIMIT);
    available -= count * width;
  }
  void enter(size_t depth) { if (depth > 128 || !nodes) throw Error(OWNED_CHECKED_RECORDS_LIMIT); --nodes; }
  void native(size_t count, size_t width) { charge(native_bytes, count, width); }
  void storage(size_t count, size_t width) { charge(storage_bytes, count, width); }
};
template<class T> inline const T& owned_read(const T *value) {
  const auto address = reinterpret_cast<uintptr_t>(value);
  if (!value || address % alignof(T) || sizeof(T) > UINTPTR_MAX - address) throw Error(OWNED_CHECKED_RECORDS_MALFORMED_RESULT);
  return *value;
}
template<class T> inline void owned_span(const T *data, size_t count) {
  if (count) {
    if (count > (UINTPTR_MAX - reinterpret_cast<uintptr_t>(data)) / sizeof(T)) throw Error(OWNED_CHECKED_RECORDS_MALFORMED_RESULT);
    (void)owned_read(data);
  }
}
inline bool owned_bool(const bool& source) {
  uint8_t value; std::memcpy(&value, &source, 1);
  if (value > 1) throw Error(OWNED_CHECKED_RECORDS_MALFORMED_RESULT);
  return value != 0;
}
inline void owned_utf8(const char *data, size_t length, owned_checked_records_status status) {
  size_t i = 0;
  while (i < length) {
    uint32_t value = static_cast<uint8_t>(data[i++]), minimum; size_t remaining;
    if (value < 0x80) continue;
    if (value >= 0xc2 && value <= 0xdf) { value &= 0x1f; minimum = 0x80; remaining = 1; }
    else if (value >= 0xe0 && value <= 0xef) { value &= 0x0f; minimum = 0x800; remaining = 2; }
    else if (value >= 0xf0 && value <= 0xf4) { value &= 7; minimum = 0x10000; remaining = 3; }
    else throw Error(status);
    if (remaining > length - i) throw Error(status);
    while (remaining--) {
      uint8_t next = static_cast<uint8_t>(data[i++]);
      if ((next & 0xc0) != 0x80) throw Error(status);
      value = (value << 6) | (next & 0x3f);
    }
    if (value < minimum || value > 0x10ffff || (value >= 0xd800 && value <= 0xdfff)) throw Error(status);
  }
}
struct OwnedOutput {
  NativeOwner owner;
  std::shared_ptr<State> state;
  std::shared_ptr<Lease> lease;
  explicit OwnedOutput(std::shared_ptr<State> input, std::shared_ptr<Lease> borrowed = {})
    : state(std::move(input)), lease(std::move(borrowed)) {}
  const std::shared_ptr<Lease>& hold() {
    if (!lease) {
      if (!owner.value) throw Error(OWNED_CHECKED_RECORDS_MALFORMED_RESULT);
      lease = state->adopt(owner);
    }
    lease->require(); return lease;
  }
};
inline size_t owned_integer_limbs(const Nat& source) {
  auto high = source.backend().limbs()[source.backend().size() - 1]; size_t bits = 0;
  while (high) { ++bits; high >>= 1; }
  bits += (source.backend().size() - 1) * sizeof(*source.backend().limbs()) * CHAR_BIT;
  return (bits + GMP_NUMB_BITS - 1) / GMP_NUMB_BITS;
}
struct OwnedIntegerView {
  std::vector<mp_limb_t> limbs;
  __mpz_struct value{};
  explicit OwnedIntegerView(const Int& source) {
    limbs.reserve(owned_integer_limbs(source));
    if (source != 0) boost::multiprecision::export_bits(source, std::back_inserter(limbs), GMP_NUMB_BITS, false);
    const auto length = static_cast<mp_size_t>(limbs.size());
    (void)mpz_roinit_n(&value, limbs.data(), source < 0 ? -length : length);
  }
  OwnedIntegerView(const OwnedIntegerView&) = delete;
  OwnedIntegerView& operator=(const OwnedIntegerView&) = delete;
  // mpz_roinit_n borrows the C++ limb vector. Never clear or mutate this GMP view.
};

struct OwnedView0;
inline void owned_check0(const Value160ce821a84f6887bbfd&, size_t, OwnedBudget&, const std::shared_ptr<State>&);
inline Value160ce821a84f6887bbfd owned_from0(const owned_checked_records_value_160ce821a84f6887bbfd_t&, size_t, OwnedBudget&, OwnedOutput&);
struct OwnedView1;
inline void owned_check1(const Claim&, size_t, OwnedBudget&, const std::shared_ptr<State>&);
inline Claim owned_from1(const owned_checked_records_claim_t&, size_t, OwnedBudget&, OwnedOutput&);
struct OwnedView2;
inline void owned_check2(const Ticket&, size_t, OwnedBudget&, const std::shared_ptr<State>&);
inline Ticket owned_from2(const owned_checked_records_ticket_t&, size_t, OwnedBudget&, OwnedOutput&);
struct OwnedView3;
inline void owned_check3(const Nat&, size_t, OwnedBudget&, const std::shared_ptr<State>&);
inline Nat owned_from3(const mpz_srcptr&, size_t, OwnedBudget&, OwnedOutput&);
struct OwnedView4;
inline void owned_check4(const std::string&, size_t, OwnedBudget&, const std::shared_ptr<State>&);
inline std::string owned_from4(const owned_checked_records_scalar_string_t&, size_t, OwnedBudget&, OwnedOutput&);
struct OwnedView0 {
  std::unique_ptr<OwnedView1> field0;
  owned_checked_records_value_160ce821a84f6887bbfd_t value{};
  OwnedView0(const Value160ce821a84f6887bbfd&, const std::shared_ptr<State>&);
  ~OwnedView0();
  OwnedView0(OwnedView0&&) noexcept;
  OwnedView0(const OwnedView0&) = delete;
};
struct OwnedView1 {
  std::unique_ptr<OwnedView2> field0;
  std::unique_ptr<OwnedView3> field1;
  owned_checked_records_claim_t value{};
  OwnedView1(const Claim&, const std::shared_ptr<State>&);
  ~OwnedView1();
  OwnedView1(OwnedView1&&) noexcept;
  OwnedView1(const OwnedView1&) = delete;
};
struct OwnedView2 {
  owned_checked_records_ticket_t value{};
  OwnedView2(const Ticket&, const std::shared_ptr<State>&);
  ~OwnedView2();
  OwnedView2(OwnedView2&&) noexcept;
  OwnedView2(const OwnedView2&) = delete;
};
struct OwnedView3 {
  std::unique_ptr<OwnedIntegerView> integer;
  mpz_srcptr value{};
  OwnedView3(const Nat&, const std::shared_ptr<State>&);
  ~OwnedView3();
  OwnedView3(OwnedView3&&) noexcept;
  OwnedView3(const OwnedView3&) = delete;
};
struct OwnedView4 {
  owned_checked_records_scalar_string_t value{};
  OwnedView4(const std::string&, const std::shared_ptr<State>&);
  ~OwnedView4();
  OwnedView4(OwnedView4&&) noexcept;
  OwnedView4(const OwnedView4&) = delete;
};
inline OwnedView0::~OwnedView0() = default;
inline OwnedView0::OwnedView0(OwnedView0&&) noexcept = default;
inline void owned_check0(const Value160ce821a84f6887bbfd& source, size_t depth, OwnedBudget& budget, const std::shared_ptr<State>& state) {
  (void)source; (void)state; budget.enter(depth);
  budget.native(1, sizeof(owned_checked_records_value_160ce821a84f6887bbfd_t)); budget.storage(1, sizeof(OwnedView0));
  if (source.has_value()) {
  owned_check1(*source, depth + 1, budget, state);
  }
}
inline OwnedView0::OwnedView0(const Value160ce821a84f6887bbfd& source, const std::shared_ptr<State>& state) {
  (void)source; (void)state;
  value.has_value = source.has_value();
  if (source.has_value()) {
  field0 = std::make_unique<OwnedView1>(*source, state);
  value.value = &field0->value;
  }
}
inline Value160ce821a84f6887bbfd owned_from0(const owned_checked_records_value_160ce821a84f6887bbfd_t& source, size_t depth, OwnedBudget& budget, OwnedOutput& output) {
  (void)source; (void)output; budget.enter(depth);
  budget.native(1, sizeof(owned_checked_records_value_160ce821a84f6887bbfd_t)); budget.storage(1, sizeof(Value160ce821a84f6887bbfd));
  const bool selected = owned_bool(source.has_value);
  if (selected) return Value160ce821a84f6887bbfd{std::in_place, owned_from1(owned_read(source.value), depth + 1, budget, output)};
  return std::nullopt;
}
inline OwnedView1::~OwnedView1() = default;
inline OwnedView1::OwnedView1(OwnedView1&&) noexcept = default;
inline void owned_check1(const Claim& source, size_t depth, OwnedBudget& budget, const std::shared_ptr<State>& state) {
  (void)source; (void)state; budget.enter(depth);
  budget.native(1, sizeof(owned_checked_records_claim_t)); budget.storage(1, sizeof(OwnedView1));
  owned_check2(source.holder, depth + 1, budget, state);
  owned_check3(source.quota, depth + 1, budget, state);
}
inline OwnedView1::OwnedView1(const Claim& source, const std::shared_ptr<State>& state) {
  (void)source; (void)state;
  field0 = std::make_unique<OwnedView2>(source.holder, state);
  value.holder = field0->value;
  field1 = std::make_unique<OwnedView3>(source.quota, state);
  value.quota = field1->value;
}
inline Claim owned_from1(const owned_checked_records_claim_t& source, size_t depth, OwnedBudget& budget, OwnedOutput& output) {
  (void)source; (void)output; budget.enter(depth);
  budget.native(1, sizeof(owned_checked_records_claim_t)); budget.storage(1, sizeof(Claim));
  return Claim{owned_from2(source.holder, depth + 1, budget, output), owned_from3(source.quota, depth + 1, budget, output)};
}
inline OwnedView2::~OwnedView2() = default;
inline OwnedView2::OwnedView2(OwnedView2&&) noexcept = default;
inline void owned_check2(const Ticket& source, size_t depth, OwnedBudget& budget, const std::shared_ptr<State>& state) {
  (void)source; (void)state; budget.enter(depth);
  budget.native(1, sizeof(owned_checked_records_ticket_t)); budget.storage(1, sizeof(OwnedView2));
  (void)ResourceAccess::get<owned_checked_records_ticket_t>(source, state);
}
inline OwnedView2::OwnedView2(const Ticket& source, const std::shared_ptr<State>& state) {
  (void)source; (void)state;
  value = ResourceAccess::get<owned_checked_records_ticket_t>(source, state);
}
inline Ticket owned_from2(const owned_checked_records_ticket_t& source, size_t depth, OwnedBudget& budget, OwnedOutput& output) {
  (void)source; (void)output; budget.enter(depth);
  budget.native(1, sizeof(owned_checked_records_ticket_t)); budget.storage(1, sizeof(Ticket));
  if (!source) throw Error(OWNED_CHECKED_RECORDS_MALFORMED_RESULT);
  return ResourceAccess::make<Identityd79b9bbde250ee1779da>(output.hold(), source);
}
inline OwnedView3::~OwnedView3() = default;
inline OwnedView3::OwnedView3(OwnedView3&&) noexcept = default;
inline void owned_check3(const Nat& source, size_t depth, OwnedBudget& budget, const std::shared_ptr<State>& state) {
  (void)source; (void)state; budget.enter(depth);
  budget.native(1, sizeof(mpz_srcptr)); budget.storage(1, sizeof(OwnedView3));
  if (source < 0) throw Error(OWNED_CHECKED_RECORDS_INVALID_ARGUMENT);
  if (source.backend().size() > budget.native_bytes / sizeof(boost::multiprecision::limb_type) + 1) throw Error(OWNED_CHECKED_RECORDS_LIMIT);
  const size_t count = owned_integer_limbs(source);
  budget.native(count, sizeof(mp_limb_t)); budget.storage(count, sizeof(mp_limb_t));
}
inline OwnedView3::OwnedView3(const Nat& source, const std::shared_ptr<State>& state) {
  (void)source; (void)state;
  integer = std::make_unique<OwnedIntegerView>(source); value = &integer->value;
}
inline Nat owned_from3(const mpz_srcptr& source, size_t depth, OwnedBudget& budget, OwnedOutput& output) {
  (void)source; (void)output; budget.enter(depth);
  budget.native(1, sizeof(mpz_srcptr)); budget.storage(1, sizeof(Nat));
  const auto signed_count = owned_read(source)._mp_size;
  const size_t count = signed_count < 0 ? size_t(0) - static_cast<size_t>(signed_count) : static_cast<size_t>(signed_count);
  budget.native(count, sizeof(mp_limb_t)); budget.storage(count, sizeof(mp_limb_t));
  const mp_limb_t *limbs = mpz_limbs_read(source); owned_span(limbs, count);
  if (mpz_sgn(source) < 0) throw Error(OWNED_CHECKED_RECORDS_MALFORMED_RESULT);
  Nat result = 0;
  if (count) boost::multiprecision::import_bits(result, limbs, limbs + count, GMP_NUMB_BITS, false);
  return result;
}
inline OwnedView4::~OwnedView4() = default;
inline OwnedView4::OwnedView4(OwnedView4&&) noexcept = default;
inline void owned_check4(const std::string& source, size_t depth, OwnedBudget& budget, const std::shared_ptr<State>& state) {
  (void)source; (void)state; budget.enter(depth);
  budget.native(1, sizeof(owned_checked_records_scalar_string_t)); budget.storage(1, sizeof(OwnedView4));
  budget.native(source.size(), 1);
  owned_utf8(source.data(), source.size(), OWNED_CHECKED_RECORDS_INVALID_ARGUMENT);
}
inline OwnedView4::OwnedView4(const std::string& source, const std::shared_ptr<State>& state) {
  (void)source; (void)state;
  value.data = source.data(); value.length = source.size();
}
inline std::string owned_from4(const owned_checked_records_scalar_string_t& source, size_t depth, OwnedBudget& budget, OwnedOutput& output) {
  (void)source; (void)output; budget.enter(depth);
  budget.native(1, sizeof(owned_checked_records_scalar_string_t)); budget.storage(1, sizeof(std::string));
  budget.native(source.length, 1); owned_span(source.data, source.length);
  budget.storage(source.length + 1, 1);
  owned_utf8(source.data, source.length, OWNED_CHECKED_RECORDS_MALFORMED_RESULT);
  return source.length ? std::string(source.data, source.length) : std::string{};
}
}
