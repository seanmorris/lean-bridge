#pragma once
#include <lean/lean.h>
#include <stdint.h>
/* Private typed helpers consume their Array arguments and return an owned Array. */
uint32_t lean_bridge_owned_0adb087092615cb8cface9e3_t160ce821a84f6887bbfd_branch(lean_object *);
lean_object * lean_bridge_owned_0adb087092615cb8cface9e3_t160ce821a84f6887bbfd_none(lean_object *);
lean_object * lean_bridge_owned_0adb087092615cb8cface9e3_t160ce821a84f6887bbfd_make0(lean_object *);
lean_object * lean_bridge_owned_0adb087092615cb8cface9e3_t160ce821a84f6887bbfd_field0(lean_object *);
lean_object * lean_bridge_owned_0adb087092615cb8cface9e3_tb2825946e038e653bd2b_make(lean_object *, lean_object *);
lean_object * lean_bridge_owned_0adb087092615cb8cface9e3_tb2825946e038e653bd2b_field0(lean_object *);
lean_object * lean_bridge_owned_0adb087092615cb8cface9e3_tb2825946e038e653bd2b_field1(lean_object *);
lean_object * lean_bridge_owned_0adb087092615cb8cface9e3_f483485736ace9af57086(lean_object *);
lean_object * lean_bridge_owned_0adb087092615cb8cface9e3_fa1e5189bd92568e4b939(lean_object *, lean_object *);
lean_object * lean_bridge_owned_0adb087092615cb8cface9e3_fec926afda994fba3abe2(lean_object *);
int lean_bridge_owned_callback_failure_57f289e56b88ff350025(void);
