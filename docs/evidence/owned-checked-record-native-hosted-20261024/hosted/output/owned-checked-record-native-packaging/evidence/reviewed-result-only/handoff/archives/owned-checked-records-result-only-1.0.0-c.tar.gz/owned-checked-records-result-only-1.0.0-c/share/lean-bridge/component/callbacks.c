#include "component.h"
#include "lean_bridge_native_runtime.h"
static _Thread_local int lean_bridge_owned_callback_failure_66fdd0811f68ad128174_state;
int lean_bridge_owned_callback_failure_66fdd0811f68ad128174(void) { int result = lean_bridge_owned_callback_failure_66fdd0811f68ad128174_state; lean_bridge_owned_callback_failure_66fdd0811f68ad128174_state = 0; return result; }
