#include "runtime.h"
#include "component.h"
#include <lean/lean.h>
#ifndef LEAN_BRIDGE_23220A30761B2D3716C5B4ED_STRUCTURED_CALLBACK_CONTROLS_DEFINED
#define LEAN_BRIDGE_23220A30761B2D3716C5B4ED_STRUCTURED_CALLBACK_CONTROLS_DEFINED
typedef struct lean_bridge_23220a30761b2d3716c5b4ed_structured_callback_controls {
  lean_object *(*recovery)(void *);
  lean_object *(*reject)(void *, lean_object *);
} lean_bridge_23220a30761b2d3716c5b4ed_structured_callback_controls;
#endif
lean_object *lean_bridge_23220a30761b2d3716c5b4ed_structured_14cd8f1b0d065ede9a36f8590000c62c12d8e99c_wrap(size_t);
lean_object *lean_bridge_23220a30761b2d3716c5b4ed_structured_14cd8f1b0d065ede9a36f8590000c62c12d8e99c_invoke(size_t, lean_object *);
lean_object *lean_bridge_23220a30761b2d3716c5b4ed_structured_14cd8f1b0d065ede9a36f8590000c62c12d8e99c_recovery(size_t);
lean_object *lean_bridge_23220a30761b2d3716c5b4ed_structured_14cd8f1b0d065ede9a36f8590000c62c12d8e99c_reject(size_t, lean_object *);
lean_object *lean_bridge_23220a30761b2d3716c5b4ed_structured_c27fa7df7f1805196544d398fb121b21c179beb1_apply(lean_object *, lean_object *);
lean_object *lean_bridge_23220a30761b2d3716c5b4ed_structured_197d5bf19058d37bc5547c33a8e0bed3bf121ea7_wrap(size_t);
lean_object *lean_bridge_23220a30761b2d3716c5b4ed_structured_197d5bf19058d37bc5547c33a8e0bed3bf121ea7_invoke(size_t, lean_object *, lean_object *);
lean_object *lean_bridge_23220a30761b2d3716c5b4ed_structured_197d5bf19058d37bc5547c33a8e0bed3bf121ea7_recovery(size_t);
lean_object *lean_bridge_23220a30761b2d3716c5b4ed_structured_197d5bf19058d37bc5547c33a8e0bed3bf121ea7_reject(size_t, lean_object *);
lean_object *lean_bridge_23220a30761b2d3716c5b4ed_structured_51bfd752726fcfd8a9187a7c3a979ace51f7c1be_apply(lean_object *, lean_object *, lean_object *);
lean_object *lean_bridge_23220a30761b2d3716c5b4ed_structured_6cdd9c3be7604978d190e4f9d3a70db0539487ba_apply(lean_object *, lean_object *);
lean_object *lean_bridge_23220a30761b2d3716c5b4ed_structured_6bc98ee774b20d3238b9e42a92309a51ce9dad0a_wrap(size_t);
lean_object *lean_bridge_23220a30761b2d3716c5b4ed_structured_6bc98ee774b20d3238b9e42a92309a51ce9dad0a_invoke(size_t, lean_object *);
lean_object *lean_bridge_23220a30761b2d3716c5b4ed_structured_6bc98ee774b20d3238b9e42a92309a51ce9dad0a_recovery(size_t);
lean_object *lean_bridge_23220a30761b2d3716c5b4ed_structured_6bc98ee774b20d3238b9e42a92309a51ce9dad0a_reject(size_t, lean_object *);
lean_object *lean_bridge_23220a30761b2d3716c5b4ed_lean(lean_object *);
lean_object *lean_bridge_8ffe188578f9a7b74003cf3c_lean(lean_object *);
lean_object *lean_bridge_4f106adfac5064464a2a8e3f_lean(lean_object *);
lean_object *lean_bridge_e2d5407c03792441cb368ec1_lean(lean_object *);
lean_object *lean_bridge_07d8425a546c7304b285ddcd_lean(lean_object *);
lean_object *lean_bridge_36fd9c74c3921bfb2ead3644_lean(lean_object *);

#include "callbacksubtypes-callable-borrows.h"
#include "callbacksubtypes-graph.h"

#include <lean/lean.h>
#include <stdlib.h>
#include <string.h>
#include <stddef.h>
_Static_assert(sizeof(size_t) == 8 && sizeof(void *) == 8, "native graph transport requires 64-bit Lean");
_Static_assert(sizeof(bool) == 1, "native graph transport requires byte Bool storage");
#ifndef LB_GRAPH_MALLOC
#define LB_GRAPH_MALLOC malloc
#endif
#ifndef LB_GRAPH_FREE
#define LB_GRAPH_FREE free
#endif
#ifndef LB_GRAPH_DECODE
#define LB_GRAPH_DECODE() ((void)0)
#endif
#ifndef LB_GRAPH_ENCODE
#define LB_GRAPH_ENCODE(value) (value)
#endif
enum { NG_OK = 0, NG_INVALID = 1, NG_LIMIT = 2, NG_ALLOC = 3, NG_RESULT = 4, NG_RUNTIME = 5 };
typedef struct {
  size_t bytes, nodes;
  struct { const void *address; size_t type; } path[129];
} ng_budget;
typedef struct ng_allocation {
  struct ng_allocation *next;
  max_align_t alignment;
  unsigned char data[];
} ng_allocation;
typedef struct { ng_allocation *head; ng_budget *budget; } ng_arena;
static void ng_release(void *owner) {
  ng_allocation *allocation = owner;
  while (allocation) {
    ng_allocation *next = allocation->next;
    LB_GRAPH_FREE(allocation); allocation = next;
  }
}
static inline uint32_t ng_charge(ng_budget *budget, size_t count, size_t width) {
  if (!width || count > budget->bytes / width) return NG_LIMIT;
  budget->bytes -= count * width; return NG_OK;
}
static inline int ng_pointer(const void *pointer, size_t bytes, size_t alignment) {
  return pointer && (uintptr_t)pointer % alignment == 0 && bytes <= UINTPTR_MAX - (uintptr_t)pointer;
}
static inline uint32_t ng_enter(const void *value, size_t type, size_t depth, ng_budget *budget) {
  if (depth > 128 || !budget->nodes) return NG_LIMIT;
  for (size_t i = 0; i < depth; ++i)
    if (budget->path[i].address == value && budget->path[i].type == type) return NG_INVALID;
  budget->path[depth].address = value; budget->path[depth].type = type;
  --budget->nodes; return NG_OK;
}
static inline uint32_t ng_allocate(ng_arena *arena, size_t count, size_t width, void **out) {
  *out = NULL;
  if (!count) return NG_OK;
  uint32_t status = ng_charge(arena->budget, count, width);
  if (!status) status = ng_charge(arena->budget, 1, sizeof(ng_allocation));
  if (status) return status;
  ng_allocation *allocation = LB_GRAPH_MALLOC(sizeof(*allocation) + count * width);
  if (!allocation) return NG_ALLOC;
  allocation->next = arena->head; arena->head = allocation;
  memset(allocation->data, 0, count * width); *out = allocation->data; return NG_OK;
}
static inline uint32_t ng_span(const void *data, size_t count, size_t width, size_t alignment, ng_budget *budget) {
  uint32_t status = ng_charge(budget, count, width);
  if (status) return status;
  return !count || ng_pointer(data, count * width, alignment) ? NG_OK : NG_INVALID;
}
static inline int ng_utf8(const uint8_t *data, size_t length) {
  size_t i = 0;
  while (i < length) {
    uint32_t point = data[i++], minimum; size_t extra;
    if (point < 0x80) continue;
    if (point >= 0xc2 && point <= 0xdf) { point &= 0x1f; extra = 1; minimum = 0x80; }
    else if (point >= 0xe0 && point <= 0xef) { point &= 0x0f; extra = 2; minimum = 0x800; }
    else if (point >= 0xf0 && point <= 0xf4) { point &= 7; extra = 3; minimum = 0x10000; }
    else return 0;
    if (extra > length - i) return 0;
    while (extra--) { uint8_t next = data[i++]; if ((next & 0xc0) != 0x80) return 0; point = (point << 6) | (next & 0x3f); }
    if (point < minimum || point > 0x10ffff || (point >= 0xd800 && point <= 0xdfff)) return 0;
  }
  return 1;
}
static inline lean_object *ng_nat_in(const uint32_t *data, size_t length) {
  lean_object *value = lean_box(0);
  while (length) {
    lean_object *shifted = lean_nat_shiftl(value, lean_box(32)); lean_dec(value);
    lean_object *limb = lean_uint32_to_nat(data[--length]);
    value = lean_nat_add(shifted, limb); lean_dec(shifted); lean_dec(limb);
  }
  return value;
}
/* Borrow value, allocate exactly the required limbs, and own every temporary. */
static inline uint32_t ng_nat_out(lean_object *value, ng_arena *arena, const uint32_t **data, size_t *length) {
  *data = NULL; *length = 0;
  if (lean_nat_eq(value, lean_box(0))) return NG_OK;
  lean_object *bits = lean_nat_log2(value);
  if (!lean_is_scalar(bits)) { lean_dec(bits); return NG_LIMIT; }
  size_t count = lean_unbox(bits) / 32 + 1; lean_dec(bits);
  void *raw; uint32_t status = ng_allocate(arena, count, sizeof(uint32_t), &raw);
  if (status) return status;
  uint32_t *limbs = raw; lean_inc(value);
  for (size_t i = 0; i < count; ++i) {
    limbs[i] = lean_uint32_of_nat(value);
    lean_object *next = lean_nat_shiftr(value, lean_box(32)); lean_dec(value); value = next;
  }
  lean_dec(value); *data = limbs; *length = count; return NG_OK;
}

#include "lean_bridge_native_runtime.h"
#if !defined(LEAN_BRIDGE_NATIVE_RUNTIME_RETIREMENT_VERSION) || LEAN_BRIDGE_NATIVE_RUNTIME_RETIREMENT_VERSION != 1
#error "native graph calls require the retirement-aware shared runtime"
#endif
extern lean_object *initialize_LeanBridgeNative730462696d8af341(uint8_t);
static void *ng_initialize(uint8_t builtin) { return initialize_LeanBridgeNative730462696d8af341(builtin); }
static int ng_ready(void) { return lean_bridge_native_component_ready("callbacksubtypes@1.0.0"); }
static inline uint32_t ng_743764d1b67e81fcae92_check(const callbacksubtypes_graph_743764d1b67e81fcae92_t *, size_t, int, ng_budget *);
static inline lean_object *ng_743764d1b67e81fcae92_in(const callbacksubtypes_graph_743764d1b67e81fcae92_t *);
static inline uint32_t ng_743764d1b67e81fcae92_out(callbacksubtypes_graph_743764d1b67e81fcae92_t *, lean_object *, size_t, ng_arena *);
extern uint32_t lean_bridge_23220a30761b2d3716c5b4ed_recursive_3f262999893350bc4fb4_branch(lean_object *);
extern lean_object *lean_bridge_23220a30761b2d3716c5b4ed_recursive_3f262999893350bc4fb4_none(lean_object *);
extern lean_object *lean_bridge_23220a30761b2d3716c5b4ed_recursive_3f262999893350bc4fb4_make0(lean_object *);
extern lean_object *lean_bridge_23220a30761b2d3716c5b4ed_recursive_3f262999893350bc4fb4_field0(lean_object *);
static inline uint32_t ng_2c6f4131c8731fa67588_check(const callbacksubtypes_graph_2c6f4131c8731fa67588_t *, size_t, int, ng_budget *);
static inline lean_object *ng_2c6f4131c8731fa67588_in(const callbacksubtypes_graph_2c6f4131c8731fa67588_t *);
static inline uint32_t ng_2c6f4131c8731fa67588_out(callbacksubtypes_graph_2c6f4131c8731fa67588_t *, lean_object *, size_t, ng_arena *);
extern uint32_t lean_bridge_23220a30761b2d3716c5b4ed_recursive_ec3de31d02aa0faa1710_branch(lean_object *);
extern lean_object *lean_bridge_23220a30761b2d3716c5b4ed_recursive_ec3de31d02aa0faa1710_make0(lean_object *);
extern lean_object *lean_bridge_23220a30761b2d3716c5b4ed_recursive_ec3de31d02aa0faa1710_field0(lean_object *);
extern lean_object *lean_bridge_23220a30761b2d3716c5b4ed_recursive_ec3de31d02aa0faa1710_make1(lean_object *);
extern lean_object *lean_bridge_23220a30761b2d3716c5b4ed_recursive_ec3de31d02aa0faa1710_field1(lean_object *);
static inline uint32_t ng_6c9c0cf3d3abf9adeb4b_check(const callbacksubtypes_graph_6c9c0cf3d3abf9adeb4b_t *, size_t, int, ng_budget *);
static inline lean_object *ng_6c9c0cf3d3abf9adeb4b_in(const callbacksubtypes_graph_6c9c0cf3d3abf9adeb4b_t *);
static inline uint32_t ng_6c9c0cf3d3abf9adeb4b_out(callbacksubtypes_graph_6c9c0cf3d3abf9adeb4b_t *, lean_object *, size_t, ng_arena *);
extern lean_object *lean_bridge_23220a30761b2d3716c5b4ed_recursive_4fb79b80af1133bbb83d_make(lean_object *);
extern lean_object *lean_bridge_23220a30761b2d3716c5b4ed_recursive_4fb79b80af1133bbb83d_items(lean_object *);
static inline uint32_t ng_5f971a64123919686824_check(const callbacksubtypes_scalar_nat_t *, size_t, int, ng_budget *);
static inline lean_object *ng_5f971a64123919686824_in(const callbacksubtypes_scalar_nat_t *);
static inline uint32_t ng_5f971a64123919686824_out(callbacksubtypes_scalar_nat_t *, lean_object *, size_t, ng_arena *);
static inline uint32_t ng_b9cf7c895f258ccf97e9_check(const callbacksubtypes_scalar_string_t *, size_t, int, ng_budget *);
static inline lean_object *ng_b9cf7c895f258ccf97e9_in(const callbacksubtypes_scalar_string_t *);
static inline uint32_t ng_b9cf7c895f258ccf97e9_out(callbacksubtypes_scalar_string_t *, lean_object *, size_t, ng_arena *);
static inline uint32_t ng_79a0fdaea5f8b1c7df7d_check(const uint8_t *, size_t, int, ng_budget *);
static inline lean_object *ng_79a0fdaea5f8b1c7df7d_in(const uint8_t *);
static inline uint32_t ng_79a0fdaea5f8b1c7df7d_out(uint8_t *, lean_object *, size_t, ng_arena *);
static inline uint32_t ng_743764d1b67e81fcae92_check(const callbacksubtypes_graph_743764d1b67e81fcae92_t *value, size_t depth, int storage, ng_budget *budget) {
  if (!ng_pointer(value, sizeof(*value), _Alignof(callbacksubtypes_graph_743764d1b67e81fcae92_t))) return NG_INVALID;
  uint32_t status = ng_enter(value, 0, depth, budget);
  if (!status && storage) status = ng_charge(budget, 1, sizeof(*value));
  if (status) return status;
  if (value->has_value > 1) return NG_INVALID;
  if (value->has_value) {
  if ((status = ng_5f971a64123919686824_check(&value->value, depth + 1, 0, budget))) return status;
  }
  return NG_OK;
}
static inline lean_object *ng_743764d1b67e81fcae92_in(const callbacksubtypes_graph_743764d1b67e81fcae92_t *value) {
  (void)value; LB_GRAPH_DECODE();
  if (!value->has_value) return lean_bridge_23220a30761b2d3716c5b4ed_recursive_3f262999893350bc4fb4_none(lean_box(0));
  if (value->has_value) return lean_bridge_23220a30761b2d3716c5b4ed_recursive_3f262999893350bc4fb4_make0(ng_5f971a64123919686824_in(&value->value));
  return lean_alloc_array(0, 0);
}
static inline uint32_t ng_743764d1b67e81fcae92_out(callbacksubtypes_graph_743764d1b67e81fcae92_t *out, lean_object *value, size_t depth, ng_arena *arena) {
  (void)out; value = LB_GRAPH_ENCODE(value);
  if (depth > 128 || !arena->budget->nodes) { lean_dec(value); return NG_LIMIT; }
  --arena->budget->nodes;
  if (lean_is_scalar(value) || !lean_is_array(value) || lean_array_size(value) != 1) { lean_dec(value); return NG_RESULT; }
  lean_inc(value);
  uint32_t branch = lean_bridge_23220a30761b2d3716c5b4ed_recursive_3f262999893350bc4fb4_branch(value);
  if (branch > 1) { lean_dec(value); return NG_RESULT; }
  out->has_value = branch;
  uint32_t status = NG_OK;
  if (out->has_value) {
  if (!status) {
    if (!status) {
      lean_inc(value);
      status = ng_5f971a64123919686824_out(&out->value, lean_bridge_23220a30761b2d3716c5b4ed_recursive_3f262999893350bc4fb4_field0(value), depth + 1, arena);
    }
  }
  }
  lean_dec(value); return status;
}
static inline uint32_t ng_2c6f4131c8731fa67588_check(const callbacksubtypes_graph_2c6f4131c8731fa67588_t *value, size_t depth, int storage, ng_budget *budget) {
  if (!ng_pointer(value, sizeof(*value), _Alignof(callbacksubtypes_graph_2c6f4131c8731fa67588_t))) return NG_INVALID;
  uint32_t status = ng_enter(value, 1, depth, budget);
  if (!status && storage) status = ng_charge(budget, 1, sizeof(*value));
  if (status) return status;
  if (value->is_ok > 1) return NG_INVALID;
  if (value->is_ok) {
  if ((status = ng_743764d1b67e81fcae92_check(&value->ok, depth + 1, 0, budget))) return status;
  }
  if (!value->is_ok) {
  if ((status = ng_b9cf7c895f258ccf97e9_check(&value->error, depth + 1, 0, budget))) return status;
  }
  return NG_OK;
}
static inline lean_object *ng_2c6f4131c8731fa67588_in(const callbacksubtypes_graph_2c6f4131c8731fa67588_t *value) {
  (void)value; LB_GRAPH_DECODE();
  if (value->is_ok) return lean_bridge_23220a30761b2d3716c5b4ed_recursive_ec3de31d02aa0faa1710_make0(ng_743764d1b67e81fcae92_in(&value->ok));
  if (!value->is_ok) return lean_bridge_23220a30761b2d3716c5b4ed_recursive_ec3de31d02aa0faa1710_make1(ng_b9cf7c895f258ccf97e9_in(&value->error));
  return lean_alloc_array(0, 0);
}
static inline uint32_t ng_2c6f4131c8731fa67588_out(callbacksubtypes_graph_2c6f4131c8731fa67588_t *out, lean_object *value, size_t depth, ng_arena *arena) {
  (void)out; value = LB_GRAPH_ENCODE(value);
  if (depth > 128 || !arena->budget->nodes) { lean_dec(value); return NG_LIMIT; }
  --arena->budget->nodes;
  if (lean_is_scalar(value) || !lean_is_array(value) || lean_array_size(value) != 1) { lean_dec(value); return NG_RESULT; }
  lean_inc(value);
  uint32_t branch = lean_bridge_23220a30761b2d3716c5b4ed_recursive_ec3de31d02aa0faa1710_branch(value);
  if (branch > 1) { lean_dec(value); return NG_RESULT; }
  out->is_ok = branch == 0;
  uint32_t status = NG_OK;
  if (out->is_ok) {
  if (!status) {
    if (!status) {
      lean_inc(value);
      status = ng_743764d1b67e81fcae92_out(&out->ok, lean_bridge_23220a30761b2d3716c5b4ed_recursive_ec3de31d02aa0faa1710_field0(value), depth + 1, arena);
    }
  }
  }
  if (!out->is_ok) {
  if (!status) {
    if (!status) {
      lean_inc(value);
      status = ng_b9cf7c895f258ccf97e9_out(&out->error, lean_bridge_23220a30761b2d3716c5b4ed_recursive_ec3de31d02aa0faa1710_field1(value), depth + 1, arena);
    }
  }
  }
  lean_dec(value); return status;
}
static inline uint32_t ng_6c9c0cf3d3abf9adeb4b_check(const callbacksubtypes_graph_6c9c0cf3d3abf9adeb4b_t *value, size_t depth, int storage, ng_budget *budget) {
  if (!ng_pointer(value, sizeof(*value), _Alignof(callbacksubtypes_graph_6c9c0cf3d3abf9adeb4b_t))) return NG_INVALID;
  uint32_t status = ng_enter(value, 2, depth, budget);
  if (!status && storage) status = ng_charge(budget, 1, sizeof(*value));
  if (status) return status;
  if (value->length > budget->nodes) return NG_LIMIT;
  status = ng_span(value->data, value->length, sizeof(callbacksubtypes_graph_743764d1b67e81fcae92_t), _Alignof(callbacksubtypes_graph_743764d1b67e81fcae92_t), budget);
  if (status) return status;
  for (size_t i = 0; i < value->length; ++i) if ((status = ng_743764d1b67e81fcae92_check(value->data + i, depth + 1, 0, budget))) return status;
  return NG_OK;
}
static inline lean_object *ng_6c9c0cf3d3abf9adeb4b_in(const callbacksubtypes_graph_6c9c0cf3d3abf9adeb4b_t *value) {
  (void)value; LB_GRAPH_DECODE();
  lean_object *items = lean_alloc_array(value->length, value->length);
  for (size_t i = 0; i < value->length; ++i) lean_array_set_core(items, i, ng_743764d1b67e81fcae92_in(value->data + i));
  return lean_bridge_23220a30761b2d3716c5b4ed_recursive_4fb79b80af1133bbb83d_make(items);
}
static inline uint32_t ng_6c9c0cf3d3abf9adeb4b_out(callbacksubtypes_graph_6c9c0cf3d3abf9adeb4b_t *out, lean_object *value, size_t depth, ng_arena *arena) {
  (void)out; value = LB_GRAPH_ENCODE(value);
  if (depth > 128 || !arena->budget->nodes) { lean_dec(value); return NG_LIMIT; }
  --arena->budget->nodes;
  if (lean_is_scalar(value) || !lean_is_array(value) || lean_array_size(value) != 1) { lean_dec(value); return NG_RESULT; }
  value = lean_bridge_23220a30761b2d3716c5b4ed_recursive_4fb79b80af1133bbb83d_items(value);
  if (lean_is_scalar(value) || !lean_is_array(value)) { lean_dec(value); return NG_RESULT; }
  size_t count = lean_array_size(value);
  if (count > arena->budget->nodes) { lean_dec(value); return NG_LIMIT; }
  void *raw;
  uint32_t status = ng_allocate(arena, count, sizeof(callbacksubtypes_graph_743764d1b67e81fcae92_t), &raw);
  out->data = raw; out->length = count; callbacksubtypes_graph_743764d1b67e81fcae92_t *data = raw;
  for (size_t i = 0; !status && i < count; ++i) {
    lean_object *child = lean_array_get_core(value, i); lean_inc(child);
    status = ng_743764d1b67e81fcae92_out(data + i, child, depth + 1, arena);
  }
  lean_dec(value); return status;
}
static inline uint32_t ng_5f971a64123919686824_check(const callbacksubtypes_scalar_nat_t *value, size_t depth, int storage, ng_budget *budget) {
  if (!ng_pointer(value, sizeof(*value), _Alignof(callbacksubtypes_scalar_nat_t))) return NG_INVALID;
  uint32_t status = ng_enter(value, 3, depth, budget);
  if (!status && storage) status = ng_charge(budget, 1, sizeof(*value));
  if (status) return status;
  status = ng_span(value->data, value->length, sizeof(uint32_t), _Alignof(uint32_t), budget);
  if (status) return status;
  return NG_OK;
}
static inline lean_object *ng_5f971a64123919686824_in(const callbacksubtypes_scalar_nat_t *value) {
  (void)value; LB_GRAPH_DECODE();
  lean_object *carrier = lean_alloc_array(1, 1);
  lean_array_set_core(carrier, 0, ng_nat_in(value->data, value->length));
  return carrier;
}
static inline uint32_t ng_5f971a64123919686824_out(callbacksubtypes_scalar_nat_t *out, lean_object *value, size_t depth, ng_arena *arena) {
  (void)out; value = LB_GRAPH_ENCODE(value);
  if (depth > 128 || !arena->budget->nodes) { lean_dec(value); return NG_LIMIT; }
  --arena->budget->nodes;
  if (lean_is_scalar(value) || !lean_is_array(value) || lean_array_size(value) != 1) { lean_dec(value); return NG_RESULT; }
  lean_object *child = lean_array_get_core(value, 0); lean_inc(child); lean_dec(value);
  uint32_t status = NG_OK;
  status = ng_nat_out(child, arena, &out->data, &out->length);
  lean_dec(child); return status;
}
static inline uint32_t ng_b9cf7c895f258ccf97e9_check(const callbacksubtypes_scalar_string_t *value, size_t depth, int storage, ng_budget *budget) {
  if (!ng_pointer(value, sizeof(*value), _Alignof(callbacksubtypes_scalar_string_t))) return NG_INVALID;
  uint32_t status = ng_enter(value, 4, depth, budget);
  if (!status && storage) status = ng_charge(budget, 1, sizeof(*value));
  if (status) return status;
  status = ng_span(value->data, value->length, 1, 1, budget);
  if (status) return status;
  if (!ng_utf8((const uint8_t *)value->data, value->length)) return NG_INVALID;
  return NG_OK;
}
static inline lean_object *ng_b9cf7c895f258ccf97e9_in(const callbacksubtypes_scalar_string_t *value) {
  (void)value; LB_GRAPH_DECODE();
  lean_object *carrier = lean_alloc_array(1, 1);
  lean_array_set_core(carrier, 0, lean_mk_string_from_bytes(value->length ? value->data : "", value->length));
  return carrier;
}
static inline uint32_t ng_b9cf7c895f258ccf97e9_out(callbacksubtypes_scalar_string_t *out, lean_object *value, size_t depth, ng_arena *arena) {
  (void)out; value = LB_GRAPH_ENCODE(value);
  if (depth > 128 || !arena->budget->nodes) { lean_dec(value); return NG_LIMIT; }
  --arena->budget->nodes;
  if (lean_is_scalar(value) || !lean_is_array(value) || lean_array_size(value) != 1) { lean_dec(value); return NG_RESULT; }
  lean_object *child = lean_array_get_core(value, 0); lean_inc(child); lean_dec(value);
  uint32_t status = NG_OK;
  if (lean_is_scalar(child) || !lean_is_string(child)) { lean_dec(child); return NG_RESULT; }
  size_t length = lean_string_size(child) - 1;
  if (!ng_utf8((const uint8_t *)lean_string_cstr(child), length)) { lean_dec(child); return NG_RESULT; }
  void *data;
  status = ng_allocate(arena, length, 1, &data);
  if (!status) {
    if (length) memcpy(data, lean_string_cstr(child), length);
    out->data = data; out->length = length;
  }
  lean_dec(child); return status;
}
static inline uint32_t ng_79a0fdaea5f8b1c7df7d_check(const uint8_t *value, size_t depth, int storage, ng_budget *budget) {
  if (!ng_pointer(value, sizeof(*value), _Alignof(uint8_t))) return NG_INVALID;
  uint32_t status = ng_enter(value, 5, depth, budget);
  if (!status && storage) status = ng_charge(budget, 1, sizeof(*value));
  if (status) return status;
  if (*value) return NG_INVALID;
  return NG_OK;
}
static inline lean_object *ng_79a0fdaea5f8b1c7df7d_in(const uint8_t *value) {
  (void)value; LB_GRAPH_DECODE();
  lean_object *carrier = lean_alloc_array(1, 1);
  lean_array_set_core(carrier, 0, lean_box(0));
  return carrier;
}
static inline uint32_t ng_79a0fdaea5f8b1c7df7d_out(uint8_t *out, lean_object *value, size_t depth, ng_arena *arena) {
  (void)out; value = LB_GRAPH_ENCODE(value);
  if (depth > 128 || !arena->budget->nodes) { lean_dec(value); return NG_LIMIT; }
  --arena->budget->nodes;
  if (lean_is_scalar(value) || !lean_is_array(value) || lean_array_size(value) != 1) { lean_dec(value); return NG_RESULT; }
  lean_object *child = lean_array_get_core(value, 0); lean_inc(child); lean_dec(value);
  uint32_t status = NG_OK;
  if (!lean_is_scalar(child) || lean_unbox(child) > 0) { lean_dec(child); return NG_RESULT; }
  *out = (uint8_t)lean_unbox(child);
  lean_dec(child); return status;
}
enum { NG_CALLBACK = 6, NG_CALLBACK_RESULT = 10 };
typedef struct ng_borrow_frame { ng_budget budget; uint32_t status; void (*observe)(struct ng_borrow_frame *); } ng_borrow_frame;
static inline void ng_borrow_fail(ng_borrow_frame *frame, uint32_t status) {
  if (!frame->status && status) frame->status = status == NG_CALLBACK_RESULT ? status : status <= NG_CALLBACK ? status : NG_CALLBACK;
}
static inline void ng_borrow_observe(ng_borrow_frame *frame) { if (frame->observe) frame->observe(frame); }
typedef struct { lean_bridge_23220a30761b2d3716c5b4ed_structured_callback_controls controls; callbacksubtypes_callback_14cd8f1b0d065ede9a36f8590000c62c12d8e99c callback; ng_borrow_frame *frame; } ng_borrow_14cd8f1b0d065ede9a36f8590000c62c12d8e99c;
static inline lean_object *ng_invoke_14cd8f1b0d065ede9a36f8590000c62c12d8e99c(void *context, lean_object *value0) {
  ng_borrow_14cd8f1b0d065ede9a36f8590000c62c12d8e99c *host = context; ng_borrow_frame *frame = host->frame;
  ng_arena arena = { .head = NULL, .budget = &frame->budget };
  lean_object *returned = NULL;
  callbacksubtypes_graph_2c6f4131c8731fa67588_t reply = {0};
  callbacksubtypes_graph_743764d1b67e81fcae92_t arg0 = {0};
  ng_borrow_observe(frame);
  if (frame->status) goto cleanup;
  ng_borrow_fail(frame, ng_charge(&frame->budget, 1, sizeof(arg0)));
  if (frame->status) goto cleanup;
  ng_borrow_fail(frame, ng_743764d1b67e81fcae92_out(&arg0, value0, 0, &arena));
  value0 = NULL;
  if (frame->status) goto cleanup;
  if (!host->callback.call) { ng_borrow_fail(frame, NG_INVALID); goto cleanup; }
  ng_borrow_fail(frame, host->callback.call(host->callback.context, &arg0, &reply));
  ng_borrow_observe(frame);
  if (frame->status) goto cleanup;
  ng_borrow_fail(frame, ng_2c6f4131c8731fa67588_check(&reply, 0, 1, &frame->budget));
  if (!frame->status) returned = ng_2c6f4131c8731fa67588_in(&reply);
cleanup:
  callbacksubtypes_graph_2c6f4131c8731fa67588_t_clear(&reply);
  if (value0) lean_dec(value0);
  ng_release(arena.head);
  ng_borrow_observe(frame);
  if (frame->status && returned) { lean_dec(returned); returned = NULL; }
  return returned ? returned : lean_alloc_array(0, 0);
}
static inline lean_object *ng_recovery_14cd8f1b0d065ede9a36f8590000c62c12d8e99c(void *context) {
  ng_borrow_14cd8f1b0d065ede9a36f8590000c62c12d8e99c *host = context; ng_borrow_frame *frame = host->frame;
  ng_borrow_observe(frame);
  if (!frame->status && !host->callback.recovery) ng_borrow_fail(frame, NG_INVALID);
  if (!frame->status) ng_borrow_fail(frame, ng_2c6f4131c8731fa67588_check(host->callback.recovery, 0, 1, &frame->budget));
  return frame->status ? lean_alloc_array(0, 0) : ng_2c6f4131c8731fa67588_in(host->callback.recovery);
}
static inline lean_object *ng_reject_14cd8f1b0d065ede9a36f8590000c62c12d8e99c(void *context, lean_object *recovery) {
  ng_borrow_14cd8f1b0d065ede9a36f8590000c62c12d8e99c *host = context;
  ng_borrow_fail(host->frame, NG_CALLBACK_RESULT);
  return recovery;
}
typedef struct { callbacksubtypes_callback_c27fa7df7f1805196544d398fb121b21c179beb1 callback; ng_borrow_frame *frame; } ng_borrow_c27fa7df7f1805196544d398fb121b21c179beb1;
static inline lean_object *ng_invoke_c27fa7df7f1805196544d398fb121b21c179beb1(void *context, lean_object *value0) {
  ng_borrow_c27fa7df7f1805196544d398fb121b21c179beb1 *host = context; ng_borrow_frame *frame = host->frame;
  ng_arena arena = { .head = NULL, .budget = &frame->budget };
  lean_object *returned = NULL;
  callbacksubtypes_scalar_nat_t reply = {0};
  callbacksubtypes_scalar_nat_t arg0 = {0};
  ng_borrow_observe(frame);
  if (frame->status) goto cleanup;
  ng_borrow_fail(frame, ng_charge(&frame->budget, 1, sizeof(arg0)));
  if (frame->status) goto cleanup;
  ng_borrow_fail(frame, ng_5f971a64123919686824_out(&arg0, value0, 0, &arena));
  value0 = NULL;
  if (frame->status) goto cleanup;
  if (!host->callback.call) { ng_borrow_fail(frame, NG_INVALID); goto cleanup; }
  ng_borrow_fail(frame, host->callback.call(host->callback.context, &arg0, &reply));
  ng_borrow_observe(frame);
  if (frame->status) goto cleanup;
  ng_borrow_fail(frame, ng_5f971a64123919686824_check(&reply, 0, 1, &frame->budget));
  if (!frame->status) returned = ng_5f971a64123919686824_in(&reply);
cleanup:
  callbacksubtypes_scalar_nat_t_clear(&reply);
  if (value0) lean_dec(value0);
  ng_release(arena.head);
  ng_borrow_observe(frame);
  if (frame->status && returned) { lean_dec(returned); returned = NULL; }
  return returned ? returned : lean_alloc_array(0, 0);
}
typedef struct { lean_bridge_23220a30761b2d3716c5b4ed_structured_callback_controls controls; callbacksubtypes_callback_197d5bf19058d37bc5547c33a8e0bed3bf121ea7 callback; ng_borrow_frame *frame; } ng_borrow_197d5bf19058d37bc5547c33a8e0bed3bf121ea7;
static inline lean_object *ng_invoke_197d5bf19058d37bc5547c33a8e0bed3bf121ea7(void *context, lean_object *value0, lean_object *value1) {
  ng_borrow_197d5bf19058d37bc5547c33a8e0bed3bf121ea7 *host = context; ng_borrow_frame *frame = host->frame;
  ng_arena arena = { .head = NULL, .budget = &frame->budget };
  lean_object *returned = NULL;
  callbacksubtypes_scalar_nat_t reply = {0};
  callbacksubtypes_scalar_nat_t arg0 = {0};
  callbacksubtypes_scalar_nat_t arg1 = {0};
  ng_borrow_observe(frame);
  if (frame->status) goto cleanup;
  ng_borrow_fail(frame, ng_charge(&frame->budget, 1, sizeof(arg0)));
  if (frame->status) goto cleanup;
  ng_borrow_fail(frame, ng_5f971a64123919686824_out(&arg0, value0, 0, &arena));
  value0 = NULL;
  if (frame->status) goto cleanup;
  ng_borrow_fail(frame, ng_charge(&frame->budget, 1, sizeof(arg1)));
  if (frame->status) goto cleanup;
  ng_borrow_fail(frame, ng_5f971a64123919686824_out(&arg1, value1, 0, &arena));
  value1 = NULL;
  if (frame->status) goto cleanup;
  if (!host->callback.call) { ng_borrow_fail(frame, NG_INVALID); goto cleanup; }
  ng_borrow_fail(frame, host->callback.call(host->callback.context, &arg0, &arg1, &reply));
  ng_borrow_observe(frame);
  if (frame->status) goto cleanup;
  ng_borrow_fail(frame, ng_5f971a64123919686824_check(&reply, 0, 1, &frame->budget));
  if (!frame->status) returned = ng_5f971a64123919686824_in(&reply);
cleanup:
  callbacksubtypes_scalar_nat_t_clear(&reply);
  if (value0) lean_dec(value0);
  if (value1) lean_dec(value1);
  ng_release(arena.head);
  ng_borrow_observe(frame);
  if (frame->status && returned) { lean_dec(returned); returned = NULL; }
  return returned ? returned : lean_alloc_array(0, 0);
}
static inline lean_object *ng_recovery_197d5bf19058d37bc5547c33a8e0bed3bf121ea7(void *context) {
  ng_borrow_197d5bf19058d37bc5547c33a8e0bed3bf121ea7 *host = context; ng_borrow_frame *frame = host->frame;
  ng_borrow_observe(frame);
  if (!frame->status && !host->callback.recovery) ng_borrow_fail(frame, NG_INVALID);
  if (!frame->status) ng_borrow_fail(frame, ng_5f971a64123919686824_check(host->callback.recovery, 0, 1, &frame->budget));
  return frame->status ? lean_alloc_array(0, 0) : ng_5f971a64123919686824_in(host->callback.recovery);
}
static inline lean_object *ng_reject_197d5bf19058d37bc5547c33a8e0bed3bf121ea7(void *context, lean_object *recovery) {
  ng_borrow_197d5bf19058d37bc5547c33a8e0bed3bf121ea7 *host = context;
  ng_borrow_fail(host->frame, NG_CALLBACK_RESULT);
  return recovery;
}
typedef struct { callbacksubtypes_callback_51bfd752726fcfd8a9187a7c3a979ace51f7c1be callback; ng_borrow_frame *frame; } ng_borrow_51bfd752726fcfd8a9187a7c3a979ace51f7c1be;
static inline lean_object *ng_invoke_51bfd752726fcfd8a9187a7c3a979ace51f7c1be(void *context, lean_object *value0, lean_object *value1) {
  ng_borrow_51bfd752726fcfd8a9187a7c3a979ace51f7c1be *host = context; ng_borrow_frame *frame = host->frame;
  ng_arena arena = { .head = NULL, .budget = &frame->budget };
  lean_object *returned = NULL;
  callbacksubtypes_scalar_nat_t reply = {0};
  callbacksubtypes_scalar_nat_t arg0 = {0};
  callbacksubtypes_scalar_nat_t arg1 = {0};
  ng_borrow_observe(frame);
  if (frame->status) goto cleanup;
  ng_borrow_fail(frame, ng_charge(&frame->budget, 1, sizeof(arg0)));
  if (frame->status) goto cleanup;
  ng_borrow_fail(frame, ng_5f971a64123919686824_out(&arg0, value0, 0, &arena));
  value0 = NULL;
  if (frame->status) goto cleanup;
  ng_borrow_fail(frame, ng_charge(&frame->budget, 1, sizeof(arg1)));
  if (frame->status) goto cleanup;
  ng_borrow_fail(frame, ng_5f971a64123919686824_out(&arg1, value1, 0, &arena));
  value1 = NULL;
  if (frame->status) goto cleanup;
  if (!host->callback.call) { ng_borrow_fail(frame, NG_INVALID); goto cleanup; }
  ng_borrow_fail(frame, host->callback.call(host->callback.context, &arg0, &arg1, &reply));
  ng_borrow_observe(frame);
  if (frame->status) goto cleanup;
  ng_borrow_fail(frame, ng_5f971a64123919686824_check(&reply, 0, 1, &frame->budget));
  if (!frame->status) returned = ng_5f971a64123919686824_in(&reply);
cleanup:
  callbacksubtypes_scalar_nat_t_clear(&reply);
  if (value0) lean_dec(value0);
  if (value1) lean_dec(value1);
  ng_release(arena.head);
  ng_borrow_observe(frame);
  if (frame->status && returned) { lean_dec(returned); returned = NULL; }
  return returned ? returned : lean_alloc_array(0, 0);
}
typedef struct { callbacksubtypes_callback_6cdd9c3be7604978d190e4f9d3a70db0539487ba callback; ng_borrow_frame *frame; } ng_borrow_6cdd9c3be7604978d190e4f9d3a70db0539487ba;
static inline lean_object *ng_invoke_6cdd9c3be7604978d190e4f9d3a70db0539487ba(void *context, lean_object *value0) {
  ng_borrow_6cdd9c3be7604978d190e4f9d3a70db0539487ba *host = context; ng_borrow_frame *frame = host->frame;
  ng_arena arena = { .head = NULL, .budget = &frame->budget };
  lean_object *returned = NULL;
  callbacksubtypes_graph_743764d1b67e81fcae92_t reply = {0};
  callbacksubtypes_graph_6c9c0cf3d3abf9adeb4b_t arg0 = {0};
  ng_borrow_observe(frame);
  if (frame->status) goto cleanup;
  ng_borrow_fail(frame, ng_charge(&frame->budget, 1, sizeof(arg0)));
  if (frame->status) goto cleanup;
  ng_borrow_fail(frame, ng_6c9c0cf3d3abf9adeb4b_out(&arg0, value0, 0, &arena));
  value0 = NULL;
  if (frame->status) goto cleanup;
  if (!host->callback.call) { ng_borrow_fail(frame, NG_INVALID); goto cleanup; }
  ng_borrow_fail(frame, host->callback.call(host->callback.context, &arg0, &reply));
  ng_borrow_observe(frame);
  if (frame->status) goto cleanup;
  ng_borrow_fail(frame, ng_743764d1b67e81fcae92_check(&reply, 0, 1, &frame->budget));
  if (!frame->status) returned = ng_743764d1b67e81fcae92_in(&reply);
cleanup:
  callbacksubtypes_graph_743764d1b67e81fcae92_t_clear(&reply);
  if (value0) lean_dec(value0);
  ng_release(arena.head);
  ng_borrow_observe(frame);
  if (frame->status && returned) { lean_dec(returned); returned = NULL; }
  return returned ? returned : lean_alloc_array(0, 0);
}
typedef struct { lean_bridge_23220a30761b2d3716c5b4ed_structured_callback_controls controls; callbacksubtypes_callback_6bc98ee774b20d3238b9e42a92309a51ce9dad0a callback; ng_borrow_frame *frame; } ng_borrow_6bc98ee774b20d3238b9e42a92309a51ce9dad0a;
static inline lean_object *ng_invoke_6bc98ee774b20d3238b9e42a92309a51ce9dad0a(void *context, lean_object *value0) {
  ng_borrow_6bc98ee774b20d3238b9e42a92309a51ce9dad0a *host = context; ng_borrow_frame *frame = host->frame;
  ng_arena arena = { .head = NULL, .budget = &frame->budget };
  lean_object *returned = NULL;
  callbacksubtypes_scalar_nat_t reply = {0};
  callbacksubtypes_scalar_nat_t arg0 = {0};
  ng_borrow_observe(frame);
  if (frame->status) goto cleanup;
  ng_borrow_fail(frame, ng_charge(&frame->budget, 1, sizeof(arg0)));
  if (frame->status) goto cleanup;
  ng_borrow_fail(frame, ng_5f971a64123919686824_out(&arg0, value0, 0, &arena));
  value0 = NULL;
  if (frame->status) goto cleanup;
  if (!host->callback.call) { ng_borrow_fail(frame, NG_INVALID); goto cleanup; }
  ng_borrow_fail(frame, host->callback.call(host->callback.context, &arg0, &reply));
  ng_borrow_observe(frame);
  if (frame->status) goto cleanup;
  ng_borrow_fail(frame, ng_5f971a64123919686824_check(&reply, 0, 1, &frame->budget));
  if (!frame->status) returned = ng_5f971a64123919686824_in(&reply);
cleanup:
  callbacksubtypes_scalar_nat_t_clear(&reply);
  if (value0) lean_dec(value0);
  ng_release(arena.head);
  ng_borrow_observe(frame);
  if (frame->status && returned) { lean_dec(returned); returned = NULL; }
  return returned ? returned : lean_alloc_array(0, 0);
}
static inline lean_object *ng_recovery_6bc98ee774b20d3238b9e42a92309a51ce9dad0a(void *context) {
  ng_borrow_6bc98ee774b20d3238b9e42a92309a51ce9dad0a *host = context; ng_borrow_frame *frame = host->frame;
  ng_borrow_observe(frame);
  if (!frame->status && !host->callback.recovery) ng_borrow_fail(frame, NG_INVALID);
  if (!frame->status) ng_borrow_fail(frame, ng_5f971a64123919686824_check(host->callback.recovery, 0, 1, &frame->budget));
  return frame->status ? lean_alloc_array(0, 0) : ng_5f971a64123919686824_in(host->callback.recovery);
}
static inline lean_object *ng_reject_6bc98ee774b20d3238b9e42a92309a51ce9dad0a(void *context, lean_object *recovery) {
  ng_borrow_6bc98ee774b20d3238b9e42a92309a51ce9dad0a *host = context;
  ng_borrow_fail(host->frame, NG_CALLBACK_RESULT);
  return recovery;
}


#include <pthread.h>
#include <unistd.h>
typedef struct {
  ng_borrow_frame borrowed;
  uint64_t tokens[32];
  size_t count;
} ng_call_frame;
static _Thread_local ng_call_frame ng_call_frames[64];
static _Thread_local size_t ng_call_depth;
static void ng_call_observe(ng_borrow_frame *borrowed) {
  ng_call_frame *frame = (ng_call_frame *)borrowed;
  if (!ng_ready()) ng_borrow_fail(borrowed, NG_RUNTIME);
  if (lb_native_callback_take_error()) ng_borrow_fail(borrowed, NG_INVALID);
  for (size_t i = 0; i < frame->count; ++i)
    if (lb_native_callback_wrong_thread(frame->tokens[i])) ng_borrow_fail(borrowed, NG_INVALID);
}
static ng_call_frame *ng_call_enter(void) {
  if (ng_call_depth) ng_call_observe(&ng_call_frames[ng_call_depth - 1].borrowed);
  if (ng_call_depth == 64) return NULL;
  ng_call_frame *frame = &ng_call_frames[ng_call_depth++];
  *frame = (ng_call_frame){ .borrowed = {
    .budget = { .bytes = 16u * 1024u * 1024u, .nodes = 262144 },
    .observe = ng_call_observe } };
  return frame;
}
static uint32_t ng_call_leave(ng_call_frame *frame) {
  ng_call_observe(&frame->borrowed);
  for (size_t i = 0; i < frame->count; ++i) lb_native_callback_release(frame->tokens[i]);
  frame->count = 0; --ng_call_depth;
  return frame->borrowed.status;
}
typedef struct {
  uint64_t token;
  lean_object *value;
  const char *kind;
  uint64_t thread;
  pid_t process;
} ng_closure_lease;
static ng_closure_lease ng_closure_leases[4096];
static pthread_mutex_t ng_closure_mutex = PTHREAD_MUTEX_INITIALIZER;
/* pthread_t and TLS addresses can be reused after a thread exits. A lease must
   stay bound to the original thread lifetime, not a recycled OS identifier. */
static uint64_t ng_closure_thread_serial;
static _Thread_local uint64_t ng_closure_thread;
static uint64_t ng_closure_store(lean_object *value, const char *kind) {
  uint64_t token = 0;
  pthread_mutex_lock(&ng_closure_mutex);
  if (!ng_closure_thread) {
    if (ng_closure_thread_serial == UINT64_MAX) { pthread_mutex_unlock(&ng_closure_mutex); return 0; }
    ng_closure_thread = ++ng_closure_thread_serial;
  }
  for (size_t i = 0; i < 4096; ++i) {
    ng_closure_lease *slot = &ng_closure_leases[i];
    if (slot->token) continue;
    token = lean_bridge_native_identity_acquire(kind, slot);
    if (token) {
      lean_mark_mt(value);
      *slot = (ng_closure_lease){token, value, kind, ng_closure_thread, getpid()};
    }
    break;
  }
  pthread_mutex_unlock(&ng_closure_mutex);
  return token;
}
static lean_object *ng_closure_borrow(uint64_t token, const char *kind) {
  lean_object *value = NULL;
  pthread_mutex_lock(&ng_closure_mutex);
  for (size_t i = 0; token && i < 4096; ++i) {
    ng_closure_lease *slot = &ng_closure_leases[i];
    if (slot->token == token && !strcmp(slot->kind, kind) && slot->process == getpid()
        && slot->thread == ng_closure_thread) {
      value = slot->value; lean_inc(value); break;
    }
  }
  pthread_mutex_unlock(&ng_closure_mutex);
  return value;
}
static void ng_closure_drop(uint64_t token, const char *kind) {
  lean_object *value = NULL;
  pthread_mutex_lock(&ng_closure_mutex);
  for (size_t i = 0; token && i < 4096; ++i) {
    ng_closure_lease *slot = &ng_closure_leases[i];
    if (slot->token == token && !strcmp(slot->kind, kind) && slot->process == getpid()) {
      value = slot->value;
      (void)lean_bridge_native_identity_release(token, kind, slot);
      *slot = (ng_closure_lease){0}; break;
    }
  }
  pthread_mutex_unlock(&ng_closure_mutex);
  if (value) lean_dec(value);
}


enum { NG_REFINEMENT_MESSAGE_LIMIT = 16384 };
static _Thread_local char ng_refinement_message[NG_REFINEMENT_MESSAGE_LIMIT + 1];
static _Thread_local size_t ng_refinement_length;
static inline void ng_refinement_reset(void) { ng_refinement_length = 0; ng_refinement_message[0] = 0; }
static inline size_t ng_refinement_mark(void) { return ng_refinement_length; }
static inline void ng_refinement_restore(size_t mark) { ng_refinement_length = mark; ng_refinement_message[mark] = 0; }
static inline void ng_refinement_overflow(void) {
  static const char message[] = "Refinement diagnostic exceeds 16 KiB";
  memcpy(ng_refinement_message, message, sizeof(message)); ng_refinement_length = sizeof(message) - 1;
}
static inline int ng_refinement_text(const char *text, size_t length) {
  if (length > NG_REFINEMENT_MESSAGE_LIMIT - ng_refinement_length) { ng_refinement_overflow(); return 0; }
  memcpy(ng_refinement_message + ng_refinement_length, text, length); ng_refinement_length += length;
  ng_refinement_message[ng_refinement_length] = 0; return 1;
}
static inline int ng_refinement_index(size_t value) {
  char digits[3 * sizeof(size_t) + 1]; size_t length = 0;
  do { digits[length++] = (char)('0' + value % 10); value /= 10; } while (value);
  if (!ng_refinement_text("[", 1)) return 0;
  while (length) if (!ng_refinement_text(&digits[--length], 1)) return 0;
  return ng_refinement_text("]", 1);
}
static inline uint32_t ng_refinement_reject(const char *suffix) {
  return ng_refinement_text(suffix, strlen(suffix)) ? NG_INVALID : NG_LIMIT;
}
static inline int ng_fin_below(const uint32_t *data, size_t length, const uint32_t *bound, size_t bound_length) {
  while (length && data[length - 1] == 0) --length;
  if (length != bound_length) return length < bound_length;
  while (length--) if (data[length] != bound[length]) return data[length] < bound[length];
  return 0;
}
const char *callbacksubtypes_callable_graph_error(void) {
  const char *result = ng_refinement_length ? ng_refinement_message : NULL;
  ng_refinement_length = 0;
  return result;
}

extern uint8_t lean_bridge_23220a30761b2d3716c5b4ed_structured_51bfd752726fcfd8a9187a7c3a979ace51f7c1be_closure_graph_refinement_1_ba12b83e7ba38842c8fd(lean_object *);
extern uint8_t lean_bridge_23220a30761b2d3716c5b4ed_structured_6cdd9c3be7604978d190e4f9d3a70db0539487ba_closure_graph_refinement_0_ba12b83e7ba38842c8fd(lean_object *);
extern uint8_t lean_bridge_23220a30761b2d3716c5b4ed_structured_c27fa7df7f1805196544d398fb121b21c179beb1_closure_graph_refinement_0_ba12b83e7ba38842c8fd(lean_object *);
static uint32_t ng_refinement_3e9cccf08fb963ffb7b3(const callbacksubtypes_scalar_nat_t *, uint32_t, uint32_t *);
static uint32_t ng_refinement_c4a264645d530ca4505b(const callbacksubtypes_scalar_nat_t *, uint32_t, uint32_t *);
static uint32_t ng_refinement_d0a1f84cbe4441737844(const callbacksubtypes_graph_6c9c0cf3d3abf9adeb4b_t *, uint32_t, uint32_t *);
static uint32_t ng_refinement_7da98f5a4279d10ca253(const callbacksubtypes_graph_743764d1b67e81fcae92_t *, uint32_t, uint32_t *);
static uint32_t ng_refinement_f89a69f3ad0a09c2ed27(const callbacksubtypes_scalar_nat_t *, uint32_t, uint32_t *);
static uint32_t ng_refinement_3e9cccf08fb963ffb7b3(const callbacksubtypes_scalar_nat_t *value, uint32_t depth, uint32_t *nodes) {
  if (depth > 128 || !*nodes) return NG_LIMIT;
  --*nodes;
  if (!lean_bridge_23220a30761b2d3716c5b4ed_structured_c27fa7df7f1805196544d398fb121b21c179beb1_closure_graph_refinement_0_ba12b83e7ba38842c8fd(ng_5f971a64123919686824_in(value)))
    return ng_refinement_reject(" was rejected by CallbackSubtypes.checkedPositive");
  return NG_OK;
}
static uint32_t ng_refinement_c4a264645d530ca4505b(const callbacksubtypes_scalar_nat_t *value, uint32_t depth, uint32_t *nodes) {
  if (depth > 128 || !*nodes) return NG_LIMIT;
  --*nodes;
  if (!lean_bridge_23220a30761b2d3716c5b4ed_structured_51bfd752726fcfd8a9187a7c3a979ace51f7c1be_closure_graph_refinement_1_ba12b83e7ba38842c8fd(ng_5f971a64123919686824_in(value)))
    return ng_refinement_reject(" was rejected by CallbackSubtypes.checkedPositive");
  return NG_OK;
}
static uint32_t ng_refinement_d0a1f84cbe4441737844(const callbacksubtypes_graph_6c9c0cf3d3abf9adeb4b_t *value, uint32_t depth, uint32_t *nodes) {
  if (depth > 128 || !*nodes) return NG_LIMIT;
  --*nodes;
  for (size_t i1 = 0; i1 < value->length; ++i1) {
    size_t mark2 = ng_refinement_mark();
    if (!ng_refinement_index(i1)) return NG_LIMIT;
    uint32_t status2 = ng_refinement_7da98f5a4279d10ca253(value->data + i1, depth + 1, nodes);
    if (status2) return status2;
    ng_refinement_restore(mark2);
  }
  return NG_OK;
}
static uint32_t ng_refinement_7da98f5a4279d10ca253(const callbacksubtypes_graph_743764d1b67e81fcae92_t *value, uint32_t depth, uint32_t *nodes) {
  if (depth > 128 || !*nodes) return NG_LIMIT;
  --*nodes;
  if (value->has_value) {
    size_t mark0 = ng_refinement_mark();
    if (!ng_refinement_text("?", sizeof("?") - 1)) return NG_LIMIT;
    uint32_t status0 = ng_refinement_f89a69f3ad0a09c2ed27(&value->value, depth + 1, nodes);
    if (status0) return status0;
    ng_refinement_restore(mark0);
  }
  return NG_OK;
}
static uint32_t ng_refinement_f89a69f3ad0a09c2ed27(const callbacksubtypes_scalar_nat_t *value, uint32_t depth, uint32_t *nodes) {
  if (depth > 128 || !*nodes) return NG_LIMIT;
  --*nodes;
  if (!lean_bridge_23220a30761b2d3716c5b4ed_structured_6cdd9c3be7604978d190e4f9d3a70db0539487ba_closure_graph_refinement_0_ba12b83e7ba38842c8fd(ng_5f971a64123919686824_in(value)))
    return ng_refinement_reject(" was rejected by CallbackSubtypes.checkedPositive");
  return NG_OK;
}
static uint32_t ng_closure_refusal_c27fa7df7f1805196544d398fb121b21c179beb1(const callbacksubtypes_scalar_nat_t *a0) {
  uint32_t status;
  ng_refinement_reset();
  uint32_t refinement_nodes = 262144;
  size_t refinement_mark_0_0 = ng_refinement_mark();
  if (!ng_refinement_text("arg0", sizeof("arg0") - 1)) return NG_LIMIT;
  if ((status = ng_refinement_3e9cccf08fb963ffb7b3(a0, 0, &refinement_nodes))) return status;
  ng_refinement_restore(refinement_mark_0_0);
  return NG_OK;
}
static uint32_t ng_closure_refusal_51bfd752726fcfd8a9187a7c3a979ace51f7c1be(const callbacksubtypes_scalar_nat_t *a0, const callbacksubtypes_scalar_nat_t *a1) {
  (void)a0;
  uint32_t status;
  ng_refinement_reset();
  uint32_t refinement_nodes = 262144;
  size_t refinement_mark_0_0 = ng_refinement_mark();
  if (!ng_refinement_text("arg1", sizeof("arg1") - 1)) return NG_LIMIT;
  if ((status = ng_refinement_c4a264645d530ca4505b(a1, 0, &refinement_nodes))) return status;
  ng_refinement_restore(refinement_mark_0_0);
  return NG_OK;
}
static uint32_t ng_closure_refusal_6cdd9c3be7604978d190e4f9d3a70db0539487ba(const callbacksubtypes_graph_6c9c0cf3d3abf9adeb4b_t *a0) {
  uint32_t status;
  ng_refinement_reset();
  uint32_t refinement_nodes = 262144;
  size_t refinement_mark_0_0 = ng_refinement_mark();
  if (!ng_refinement_text("arg0", sizeof("arg0") - 1)) return NG_LIMIT;
  if ((status = ng_refinement_d0a1f84cbe4441737844(a0, 0, &refinement_nodes))) return status;
  ng_refinement_restore(refinement_mark_0_0);
  return NG_OK;
}
uint32_t lean_bridge_23220a30761b2d3716c5b4ed_graph(const callbacksubtypes_callback_6bc98ee774b20d3238b9e42a92309a51ce9dad0a *a0, callbacksubtypes_scalar_nat_t *out) {
  ng_refinement_reset();
  if (!ng_pointer(out, sizeof(*out), _Alignof(callbacksubtypes_scalar_nat_t))) return NG_INVALID;
  if (out->_bridge_owner || out->_bridge_release) return NG_INVALID;
  if (!lean_bridge_native_component_initialize("callbacksubtypes@1.0.0", ng_initialize)) return NG_RUNTIME;
  ng_call_frame *call = ng_call_enter(); if (!call) return NG_LIMIT;
  ng_borrow_frame *frame = &call->borrowed;
  ng_arena arena = { .head = NULL, .budget = &frame->budget };
  callbacksubtypes_scalar_nat_t result = {0};
  lean_object *value = NULL;
  ng_borrow_6bc98ee774b20d3238b9e42a92309a51ce9dad0a host0 = {0};
  uint64_t token0 = 0;
  ng_borrow_fail(frame, ng_charge(&frame->budget, 1, sizeof(result)));
  if (frame->status) goto cleanup;
  if (!ng_pointer(a0, sizeof(*a0), _Alignof(callbacksubtypes_callback_6bc98ee774b20d3238b9e42a92309a51ce9dad0a)) || !a0->call || !a0->recovery) { ng_borrow_fail(frame, NG_INVALID); goto cleanup; }
  host0 = (ng_borrow_6bc98ee774b20d3238b9e42a92309a51ce9dad0a){{ng_recovery_6bc98ee774b20d3238b9e42a92309a51ce9dad0a, ng_reject_6bc98ee774b20d3238b9e42a92309a51ce9dad0a}, *a0, frame};
  token0 = lb_native_callback_register((void (*)(void))ng_invoke_6bc98ee774b20d3238b9e42a92309a51ce9dad0a, &host0);
  if (!token0) { ng_borrow_fail(frame, NG_ALLOC); goto cleanup; }
  call->tokens[call->count++] = token0;
  value = lean_bridge_23220a30761b2d3716c5b4ed_lean(lean_bridge_23220a30761b2d3716c5b4ed_structured_6bc98ee774b20d3238b9e42a92309a51ce9dad0a_wrap((size_t)token0));
  ng_call_observe(frame);
  if (frame->status) goto cleanup;
  if (!lean_is_scalar(value) && lean_is_array(value) && lean_array_size(value) == 0) {
    lean_dec(value); value = NULL; ng_borrow_fail(frame, NG_INVALID); goto cleanup;
  }
  ng_borrow_fail(frame, ng_5f971a64123919686824_out(&result, value, 0, &arena));
  value = NULL; /* The walker consumes its carrier on every path. */
cleanup:
  if (value) lean_dec(value);
  if (frame->status == NG_RESULT) lean_bridge_native_runtime_retire();
  uint32_t status = ng_call_leave(call);
  ng_refinement_reset();
  if (status) {
    ng_release(arena.head); return status;
  }
  result._bridge_owner = arena.head;
  result._bridge_release = arena.head ? ng_release : NULL;
  *out = result; return NG_OK;
}
uint32_t lean_bridge_8ffe188578f9a7b74003cf3c_graph(const callbacksubtypes_callback_14cd8f1b0d065ede9a36f8590000c62c12d8e99c *a0, callbacksubtypes_graph_2c6f4131c8731fa67588_t *out) {
  ng_refinement_reset();
  if (!ng_pointer(out, sizeof(*out), _Alignof(callbacksubtypes_graph_2c6f4131c8731fa67588_t))) return NG_INVALID;
  if (out->_bridge_owner || out->_bridge_release) return NG_INVALID;
  if (!lean_bridge_native_component_initialize("callbacksubtypes@1.0.0", ng_initialize)) return NG_RUNTIME;
  ng_call_frame *call = ng_call_enter(); if (!call) return NG_LIMIT;
  ng_borrow_frame *frame = &call->borrowed;
  ng_arena arena = { .head = NULL, .budget = &frame->budget };
  callbacksubtypes_graph_2c6f4131c8731fa67588_t result = {0};
  lean_object *value = NULL;
  ng_borrow_14cd8f1b0d065ede9a36f8590000c62c12d8e99c host0 = {0};
  uint64_t token0 = 0;
  ng_borrow_fail(frame, ng_charge(&frame->budget, 1, sizeof(result)));
  if (frame->status) goto cleanup;
  if (!ng_pointer(a0, sizeof(*a0), _Alignof(callbacksubtypes_callback_14cd8f1b0d065ede9a36f8590000c62c12d8e99c)) || !a0->call || !a0->recovery) { ng_borrow_fail(frame, NG_INVALID); goto cleanup; }
  host0 = (ng_borrow_14cd8f1b0d065ede9a36f8590000c62c12d8e99c){{ng_recovery_14cd8f1b0d065ede9a36f8590000c62c12d8e99c, ng_reject_14cd8f1b0d065ede9a36f8590000c62c12d8e99c}, *a0, frame};
  token0 = lb_native_callback_register((void (*)(void))ng_invoke_14cd8f1b0d065ede9a36f8590000c62c12d8e99c, &host0);
  if (!token0) { ng_borrow_fail(frame, NG_ALLOC); goto cleanup; }
  call->tokens[call->count++] = token0;
  value = lean_bridge_8ffe188578f9a7b74003cf3c_lean(lean_bridge_23220a30761b2d3716c5b4ed_structured_14cd8f1b0d065ede9a36f8590000c62c12d8e99c_wrap((size_t)token0));
  ng_call_observe(frame);
  if (frame->status) goto cleanup;
  if (!lean_is_scalar(value) && lean_is_array(value) && lean_array_size(value) == 0) {
    lean_dec(value); value = NULL; ng_borrow_fail(frame, NG_INVALID); goto cleanup;
  }
  ng_borrow_fail(frame, ng_2c6f4131c8731fa67588_out(&result, value, 0, &arena));
  value = NULL; /* The walker consumes its carrier on every path. */
cleanup:
  if (value) lean_dec(value);
  if (frame->status == NG_RESULT) lean_bridge_native_runtime_retire();
  uint32_t status = ng_call_leave(call);
  ng_refinement_reset();
  if (status) {
    ng_release(arena.head); return status;
  }
  result._bridge_owner = arena.head;
  result._bridge_release = arena.head ? ng_release : NULL;
  *out = result; return NG_OK;
}
uint32_t lean_bridge_4f106adfac5064464a2a8e3f_graph(const callbacksubtypes_callback_197d5bf19058d37bc5547c33a8e0bed3bf121ea7 *a0, callbacksubtypes_scalar_nat_t *out) {
  ng_refinement_reset();
  if (!ng_pointer(out, sizeof(*out), _Alignof(callbacksubtypes_scalar_nat_t))) return NG_INVALID;
  if (out->_bridge_owner || out->_bridge_release) return NG_INVALID;
  if (!lean_bridge_native_component_initialize("callbacksubtypes@1.0.0", ng_initialize)) return NG_RUNTIME;
  ng_call_frame *call = ng_call_enter(); if (!call) return NG_LIMIT;
  ng_borrow_frame *frame = &call->borrowed;
  ng_arena arena = { .head = NULL, .budget = &frame->budget };
  callbacksubtypes_scalar_nat_t result = {0};
  lean_object *value = NULL;
  ng_borrow_197d5bf19058d37bc5547c33a8e0bed3bf121ea7 host0 = {0};
  uint64_t token0 = 0;
  ng_borrow_fail(frame, ng_charge(&frame->budget, 1, sizeof(result)));
  if (frame->status) goto cleanup;
  if (!ng_pointer(a0, sizeof(*a0), _Alignof(callbacksubtypes_callback_197d5bf19058d37bc5547c33a8e0bed3bf121ea7)) || !a0->call || !a0->recovery) { ng_borrow_fail(frame, NG_INVALID); goto cleanup; }
  host0 = (ng_borrow_197d5bf19058d37bc5547c33a8e0bed3bf121ea7){{ng_recovery_197d5bf19058d37bc5547c33a8e0bed3bf121ea7, ng_reject_197d5bf19058d37bc5547c33a8e0bed3bf121ea7}, *a0, frame};
  token0 = lb_native_callback_register((void (*)(void))ng_invoke_197d5bf19058d37bc5547c33a8e0bed3bf121ea7, &host0);
  if (!token0) { ng_borrow_fail(frame, NG_ALLOC); goto cleanup; }
  call->tokens[call->count++] = token0;
  value = lean_bridge_4f106adfac5064464a2a8e3f_lean(lean_bridge_23220a30761b2d3716c5b4ed_structured_197d5bf19058d37bc5547c33a8e0bed3bf121ea7_wrap((size_t)token0));
  ng_call_observe(frame);
  if (frame->status) goto cleanup;
  if (!lean_is_scalar(value) && lean_is_array(value) && lean_array_size(value) == 0) {
    lean_dec(value); value = NULL; ng_borrow_fail(frame, NG_INVALID); goto cleanup;
  }
  ng_borrow_fail(frame, ng_5f971a64123919686824_out(&result, value, 0, &arena));
  value = NULL; /* The walker consumes its carrier on every path. */
cleanup:
  if (value) lean_dec(value);
  if (frame->status == NG_RESULT) lean_bridge_native_runtime_retire();
  uint32_t status = ng_call_leave(call);
  ng_refinement_reset();
  if (status) {
    ng_release(arena.head); return status;
  }
  result._bridge_owner = arena.head;
  result._bridge_release = arena.head ? ng_release : NULL;
  *out = result; return NG_OK;
}
uint32_t lean_bridge_e2d5407c03792441cb368ec1_graph(const callbacksubtypes_scalar_nat_t *a0, uint64_t *out) {
  ng_refinement_reset();
  if (!ng_pointer(out, sizeof(*out), _Alignof(uint64_t))) return NG_INVALID;
  if (*out) return NG_INVALID;
  if (!lean_bridge_native_component_initialize("callbacksubtypes@1.0.0", ng_initialize)) return NG_RUNTIME;
  ng_call_frame *call = ng_call_enter(); if (!call) return NG_LIMIT;
  ng_borrow_frame *frame = &call->borrowed;
  ng_arena arena = { .head = NULL, .budget = &frame->budget };
  uint64_t result = {0};
  lean_object *value = NULL;
  ng_borrow_fail(frame, ng_charge(&frame->budget, 1, sizeof(result)));
  if (frame->status) goto cleanup;
  ng_borrow_fail(frame, ng_5f971a64123919686824_check(a0, 0, 1, &frame->budget));
  if (frame->status) goto cleanup;
  value = lean_bridge_e2d5407c03792441cb368ec1_lean(ng_5f971a64123919686824_in(a0));
  ng_call_observe(frame);
  if (frame->status) goto cleanup;
  if (lean_is_scalar(value) || !lean_is_array(value) || lean_array_size(value) != 1) { ng_borrow_fail(frame, NG_RESULT); goto cleanup; }
  result = ng_closure_store(value, "callbacksubtypes@1.0.0:graph-callback:c27fa7df7f1805196544d398fb121b21c179beb1");
  if (!result) { ng_borrow_fail(frame, NG_ALLOC); goto cleanup; }
  value = NULL;
cleanup:
  if (value) lean_dec(value);
  if (frame->status == NG_RESULT) lean_bridge_native_runtime_retire();
  uint32_t status = ng_call_leave(call);
  ng_refinement_reset();
  if (status) {
    if (result) ng_closure_drop(result, "callbacksubtypes@1.0.0:graph-callback:c27fa7df7f1805196544d398fb121b21c179beb1");
    ng_release(arena.head); return status;
  }
  ng_release(arena.head);
  *out = result; return NG_OK;
}
uint32_t lean_bridge_07d8425a546c7304b285ddcd_graph(const callbacksubtypes_scalar_nat_t *a0, uint64_t *out) {
  ng_refinement_reset();
  if (!ng_pointer(out, sizeof(*out), _Alignof(uint64_t))) return NG_INVALID;
  if (*out) return NG_INVALID;
  if (!lean_bridge_native_component_initialize("callbacksubtypes@1.0.0", ng_initialize)) return NG_RUNTIME;
  ng_call_frame *call = ng_call_enter(); if (!call) return NG_LIMIT;
  ng_borrow_frame *frame = &call->borrowed;
  ng_arena arena = { .head = NULL, .budget = &frame->budget };
  uint64_t result = {0};
  lean_object *value = NULL;
  ng_borrow_fail(frame, ng_charge(&frame->budget, 1, sizeof(result)));
  if (frame->status) goto cleanup;
  ng_borrow_fail(frame, ng_5f971a64123919686824_check(a0, 0, 1, &frame->budget));
  if (frame->status) goto cleanup;
  value = lean_bridge_07d8425a546c7304b285ddcd_lean(ng_5f971a64123919686824_in(a0));
  ng_call_observe(frame);
  if (frame->status) goto cleanup;
  if (lean_is_scalar(value) || !lean_is_array(value) || lean_array_size(value) != 1) { ng_borrow_fail(frame, NG_RESULT); goto cleanup; }
  result = ng_closure_store(value, "callbacksubtypes@1.0.0:graph-callback:6cdd9c3be7604978d190e4f9d3a70db0539487ba");
  if (!result) { ng_borrow_fail(frame, NG_ALLOC); goto cleanup; }
  value = NULL;
cleanup:
  if (value) lean_dec(value);
  if (frame->status == NG_RESULT) lean_bridge_native_runtime_retire();
  uint32_t status = ng_call_leave(call);
  ng_refinement_reset();
  if (status) {
    if (result) ng_closure_drop(result, "callbacksubtypes@1.0.0:graph-callback:6cdd9c3be7604978d190e4f9d3a70db0539487ba");
    ng_release(arena.head); return status;
  }
  ng_release(arena.head);
  *out = result; return NG_OK;
}
uint32_t lean_bridge_36fd9c74c3921bfb2ead3644_graph(const callbacksubtypes_scalar_nat_t *a0, uint64_t *out) {
  ng_refinement_reset();
  if (!ng_pointer(out, sizeof(*out), _Alignof(uint64_t))) return NG_INVALID;
  if (*out) return NG_INVALID;
  if (!lean_bridge_native_component_initialize("callbacksubtypes@1.0.0", ng_initialize)) return NG_RUNTIME;
  ng_call_frame *call = ng_call_enter(); if (!call) return NG_LIMIT;
  ng_borrow_frame *frame = &call->borrowed;
  ng_arena arena = { .head = NULL, .budget = &frame->budget };
  uint64_t result = {0};
  lean_object *value = NULL;
  ng_borrow_fail(frame, ng_charge(&frame->budget, 1, sizeof(result)));
  if (frame->status) goto cleanup;
  ng_borrow_fail(frame, ng_5f971a64123919686824_check(a0, 0, 1, &frame->budget));
  if (frame->status) goto cleanup;
  value = lean_bridge_36fd9c74c3921bfb2ead3644_lean(ng_5f971a64123919686824_in(a0));
  ng_call_observe(frame);
  if (frame->status) goto cleanup;
  if (lean_is_scalar(value) || !lean_is_array(value) || lean_array_size(value) != 1) { ng_borrow_fail(frame, NG_RESULT); goto cleanup; }
  result = ng_closure_store(value, "callbacksubtypes@1.0.0:graph-callback:51bfd752726fcfd8a9187a7c3a979ace51f7c1be");
  if (!result) { ng_borrow_fail(frame, NG_ALLOC); goto cleanup; }
  value = NULL;
cleanup:
  if (value) lean_dec(value);
  if (frame->status == NG_RESULT) lean_bridge_native_runtime_retire();
  uint32_t status = ng_call_leave(call);
  ng_refinement_reset();
  if (status) {
    if (result) ng_closure_drop(result, "callbacksubtypes@1.0.0:graph-callback:51bfd752726fcfd8a9187a7c3a979ace51f7c1be");
    ng_release(arena.head); return status;
  }
  ng_release(arena.head);
  *out = result; return NG_OK;
}
uint32_t callbacksubtypes_callback_c27fa7df7f1805196544d398fb121b21c179beb1_lease_call(uint64_t self, const callbacksubtypes_scalar_nat_t *a0, callbacksubtypes_scalar_nat_t *out) {
  ng_refinement_reset();
  int refused = 0;
  if (!ng_pointer(out, sizeof(*out), _Alignof(callbacksubtypes_scalar_nat_t))) return NG_INVALID;
  if (out->_bridge_owner || out->_bridge_release) return NG_INVALID;
  if (!lean_bridge_native_component_initialize("callbacksubtypes@1.0.0", ng_initialize)) return NG_RUNTIME;
  ng_call_frame *call = ng_call_enter(); if (!call) return NG_LIMIT;
  ng_borrow_frame *frame = &call->borrowed;
  ng_arena arena = { .head = NULL, .budget = &frame->budget };
  callbacksubtypes_scalar_nat_t result = {0};
  lean_object *value = NULL;
  lean_object *closure = NULL;
  ng_borrow_fail(frame, ng_charge(&frame->budget, 1, sizeof(result)));
  if (frame->status) goto cleanup;
  ng_borrow_fail(frame, ng_5f971a64123919686824_check(a0, 0, 1, &frame->budget));
  if (frame->status) goto cleanup;
  closure = ng_closure_borrow(self, "callbacksubtypes@1.0.0:graph-callback:c27fa7df7f1805196544d398fb121b21c179beb1");
  if (!closure) { ng_borrow_fail(frame, NG_INVALID); goto cleanup; }
  value = lean_bridge_23220a30761b2d3716c5b4ed_structured_c27fa7df7f1805196544d398fb121b21c179beb1_apply(closure, ng_5f971a64123919686824_in(a0));
  closure = NULL; /* The typed Lean apply consumed this call's reference. */
  ng_call_observe(frame);
  if (frame->status) goto cleanup;
  if (!lean_is_scalar(value) && lean_is_array(value) && lean_array_size(value) == 0) {
    refused = ng_closure_refusal_c27fa7df7f1805196544d398fb121b21c179beb1(a0) == NG_INVALID;
    lean_dec(value); value = NULL; ng_borrow_fail(frame, NG_INVALID); goto cleanup;
  }
  ng_borrow_fail(frame, ng_5f971a64123919686824_out(&result, value, 0, &arena));
  value = NULL; /* The walker consumes its carrier on every path. */
cleanup:
  if (value) lean_dec(value);
  if (closure) lean_dec(closure);
  if (frame->status == NG_RESULT) lean_bridge_native_runtime_retire();
  uint32_t status = ng_call_leave(call);
  if (status != NG_INVALID || !refused) ng_refinement_reset();
  if (status) {
    ng_release(arena.head); return status;
  }
  result._bridge_owner = arena.head;
  result._bridge_release = arena.head ? ng_release : NULL;
  *out = result; return NG_OK;
}
void callbacksubtypes_callback_c27fa7df7f1805196544d398fb121b21c179beb1_lease_dispose(uint64_t token) { ng_closure_drop(token, "callbacksubtypes@1.0.0:graph-callback:c27fa7df7f1805196544d398fb121b21c179beb1"); }
uint32_t callbacksubtypes_callback_51bfd752726fcfd8a9187a7c3a979ace51f7c1be_lease_call(uint64_t self, const callbacksubtypes_scalar_nat_t *a0, const callbacksubtypes_scalar_nat_t *a1, callbacksubtypes_scalar_nat_t *out) {
  ng_refinement_reset();
  int refused = 0;
  if (!ng_pointer(out, sizeof(*out), _Alignof(callbacksubtypes_scalar_nat_t))) return NG_INVALID;
  if (out->_bridge_owner || out->_bridge_release) return NG_INVALID;
  if (!lean_bridge_native_component_initialize("callbacksubtypes@1.0.0", ng_initialize)) return NG_RUNTIME;
  ng_call_frame *call = ng_call_enter(); if (!call) return NG_LIMIT;
  ng_borrow_frame *frame = &call->borrowed;
  ng_arena arena = { .head = NULL, .budget = &frame->budget };
  callbacksubtypes_scalar_nat_t result = {0};
  lean_object *value = NULL;
  lean_object *closure = NULL;
  ng_borrow_fail(frame, ng_charge(&frame->budget, 1, sizeof(result)));
  if (frame->status) goto cleanup;
  ng_borrow_fail(frame, ng_5f971a64123919686824_check(a0, 0, 1, &frame->budget));
  if (frame->status) goto cleanup;
  ng_borrow_fail(frame, ng_5f971a64123919686824_check(a1, 0, 1, &frame->budget));
  if (frame->status) goto cleanup;
  closure = ng_closure_borrow(self, "callbacksubtypes@1.0.0:graph-callback:51bfd752726fcfd8a9187a7c3a979ace51f7c1be");
  if (!closure) { ng_borrow_fail(frame, NG_INVALID); goto cleanup; }
  value = lean_bridge_23220a30761b2d3716c5b4ed_structured_51bfd752726fcfd8a9187a7c3a979ace51f7c1be_apply(closure, ng_5f971a64123919686824_in(a0), ng_5f971a64123919686824_in(a1));
  closure = NULL; /* The typed Lean apply consumed this call's reference. */
  ng_call_observe(frame);
  if (frame->status) goto cleanup;
  if (!lean_is_scalar(value) && lean_is_array(value) && lean_array_size(value) == 0) {
    refused = ng_closure_refusal_51bfd752726fcfd8a9187a7c3a979ace51f7c1be(a0, a1) == NG_INVALID;
    lean_dec(value); value = NULL; ng_borrow_fail(frame, NG_INVALID); goto cleanup;
  }
  ng_borrow_fail(frame, ng_5f971a64123919686824_out(&result, value, 0, &arena));
  value = NULL; /* The walker consumes its carrier on every path. */
cleanup:
  if (value) lean_dec(value);
  if (closure) lean_dec(closure);
  if (frame->status == NG_RESULT) lean_bridge_native_runtime_retire();
  uint32_t status = ng_call_leave(call);
  if (status != NG_INVALID || !refused) ng_refinement_reset();
  if (status) {
    ng_release(arena.head); return status;
  }
  result._bridge_owner = arena.head;
  result._bridge_release = arena.head ? ng_release : NULL;
  *out = result; return NG_OK;
}
void callbacksubtypes_callback_51bfd752726fcfd8a9187a7c3a979ace51f7c1be_lease_dispose(uint64_t token) { ng_closure_drop(token, "callbacksubtypes@1.0.0:graph-callback:51bfd752726fcfd8a9187a7c3a979ace51f7c1be"); }
uint32_t callbacksubtypes_callback_6cdd9c3be7604978d190e4f9d3a70db0539487ba_lease_call(uint64_t self, const callbacksubtypes_graph_6c9c0cf3d3abf9adeb4b_t *a0, callbacksubtypes_graph_743764d1b67e81fcae92_t *out) {
  ng_refinement_reset();
  int refused = 0;
  if (!ng_pointer(out, sizeof(*out), _Alignof(callbacksubtypes_graph_743764d1b67e81fcae92_t))) return NG_INVALID;
  if (out->_bridge_owner || out->_bridge_release) return NG_INVALID;
  if (!lean_bridge_native_component_initialize("callbacksubtypes@1.0.0", ng_initialize)) return NG_RUNTIME;
  ng_call_frame *call = ng_call_enter(); if (!call) return NG_LIMIT;
  ng_borrow_frame *frame = &call->borrowed;
  ng_arena arena = { .head = NULL, .budget = &frame->budget };
  callbacksubtypes_graph_743764d1b67e81fcae92_t result = {0};
  lean_object *value = NULL;
  lean_object *closure = NULL;
  ng_borrow_fail(frame, ng_charge(&frame->budget, 1, sizeof(result)));
  if (frame->status) goto cleanup;
  ng_borrow_fail(frame, ng_6c9c0cf3d3abf9adeb4b_check(a0, 0, 1, &frame->budget));
  if (frame->status) goto cleanup;
  closure = ng_closure_borrow(self, "callbacksubtypes@1.0.0:graph-callback:6cdd9c3be7604978d190e4f9d3a70db0539487ba");
  if (!closure) { ng_borrow_fail(frame, NG_INVALID); goto cleanup; }
  value = lean_bridge_23220a30761b2d3716c5b4ed_structured_6cdd9c3be7604978d190e4f9d3a70db0539487ba_apply(closure, ng_6c9c0cf3d3abf9adeb4b_in(a0));
  closure = NULL; /* The typed Lean apply consumed this call's reference. */
  ng_call_observe(frame);
  if (frame->status) goto cleanup;
  if (!lean_is_scalar(value) && lean_is_array(value) && lean_array_size(value) == 0) {
    refused = ng_closure_refusal_6cdd9c3be7604978d190e4f9d3a70db0539487ba(a0) == NG_INVALID;
    lean_dec(value); value = NULL; ng_borrow_fail(frame, NG_INVALID); goto cleanup;
  }
  ng_borrow_fail(frame, ng_743764d1b67e81fcae92_out(&result, value, 0, &arena));
  value = NULL; /* The walker consumes its carrier on every path. */
cleanup:
  if (value) lean_dec(value);
  if (closure) lean_dec(closure);
  if (frame->status == NG_RESULT) lean_bridge_native_runtime_retire();
  uint32_t status = ng_call_leave(call);
  if (status != NG_INVALID || !refused) ng_refinement_reset();
  if (status) {
    ng_release(arena.head); return status;
  }
  result._bridge_owner = arena.head;
  result._bridge_release = arena.head ? ng_release : NULL;
  *out = result; return NG_OK;
}
void callbacksubtypes_callback_6cdd9c3be7604978d190e4f9d3a70db0539487ba_lease_dispose(uint64_t token) { ng_closure_drop(token, "callbacksubtypes@1.0.0:graph-callback:6cdd9c3be7604978d190e4f9d3a70db0539487ba"); }

#include "callbacksubtypes-graph.h"

#include "EXTERN.h"
#include "perl.h"
#include "XSUB.h"
#include <stdlib.h>
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <stdio.h>
_Static_assert(sizeof(void *) == 8 && sizeof(IV) == 8 && sizeof(UV) == 8, "Perl graph conversion requires a 64-bit ABI");
#ifndef LB_PERL_GRAPH_MALLOC
#define LB_PERL_GRAPH_MALLOC malloc
#endif
#ifndef LB_PERL_GRAPH_FREE
#define LB_PERL_GRAPH_FREE free
#endif
#ifndef LB_PERL_GRAPH_CHECKPOINT
#define LB_PERL_GRAPH_CHECKPOINT() ((void)0)
#endif
typedef struct lpg_allocation {
  struct lpg_allocation *next;
  max_align_t alignment;
  unsigned char data[];
} lpg_allocation;
typedef struct {
  lpg_allocation *allocations;
  void *output;
  void (*clear)(void *);
  void (*retire)(void);
  size_t native_bytes, storage_bytes, nodes;
  struct { const void *address; size_t type; } path[129];
} lpg_scope;
static void lpg_close(lpg_scope *scope) {
  void *output = scope->output; scope->output = NULL;
  if (output && scope->clear) scope->clear(output);
  lpg_allocation *allocation = scope->allocations; scope->allocations = NULL;
  while (allocation) {
    lpg_allocation *next = allocation->next;
    LB_PERL_GRAPH_FREE(allocation); allocation = next;
  }
}
static void lpg_end(pTHX_ void *value) {
  PERL_UNUSED_CONTEXT;
  lpg_scope *scope = value; lpg_close(scope); LB_PERL_GRAPH_FREE(scope);
}
static lpg_scope *lpg_begin(pTHX_ void (*retire)(void)) {
  /* Grow Perl's save stack before acquiring memory needing its destructor. */
  SSGROW(4);
  LB_PERL_GRAPH_CHECKPOINT();
  lpg_scope *scope = LB_PERL_GRAPH_MALLOC(sizeof(*scope));
  if (!scope) croak("Perl graph allocation failed");
  memset(scope, 0, sizeof(*scope));
  SAVEDESTRUCTOR_X(lpg_end, scope);
  scope->retire = retire;
  scope->native_bytes = scope->storage_bytes = 16 * 1024 * 1024;
  scope->nodes = 262144;
  return scope;
}
static void lpg_charge(pTHX_ size_t *remaining, size_t count, size_t width) {
  if (!width || count > *remaining / width) croak("Perl copied graph storage limit exceeded");
  *remaining -= count * width;
}
static void *lpg_allocate(pTHX_ lpg_scope *scope, size_t count, size_t width) {
  if (!count) return NULL;
  lpg_charge(aTHX_ &scope->storage_bytes, count, width);
  lpg_charge(aTHX_ &scope->storage_bytes, 1, sizeof(lpg_allocation));
  LB_PERL_GRAPH_CHECKPOINT();
  lpg_allocation *allocation = LB_PERL_GRAPH_MALLOC(sizeof(*allocation) + count * width);
  if (!allocation) croak("Perl graph allocation failed");
  allocation->next = scope->allocations; scope->allocations = allocation;
  memset(allocation->data, 0, count * width); return allocation->data;
}
static void lpg_invalid(pTHX_ lpg_scope *scope, const char *message) {
  if (scope->retire) scope->retire();
  croak("Invalid native copied graph: %s", message);
}
static void lpg_enter(pTHX_ lpg_scope *scope, const void *value, size_t type, size_t depth, size_t native_storage, int output) {
  if (depth > 128 || !scope->nodes) croak("Perl copied graph depth or node limit exceeded");
  --scope->nodes;
  lpg_charge(aTHX_ &scope->native_bytes, native_storage, 1);
  for (size_t i = 0; value && i < depth; ++i) if (scope->path[i].address == value && scope->path[i].type == type) {
    if (output) lpg_invalid(aTHX_ scope, "cycle");
    croak("Cyclic Perl copied value");
  }
  scope->path[depth].address = value; scope->path[depth].type = type;
}
static void lpg_pointer(pTHX_ lpg_scope *scope, const void *pointer, size_t count, size_t width, size_t alignment) {
  if (!count) return;
  if (!pointer || (uintptr_t)pointer % alignment || count > (UINTPTR_MAX - (uintptr_t)pointer) / width)
    lpg_invalid(aTHX_ scope, "missing, misaligned or overflowing span");
  /* Authenticated native producers supply readable process memory. */
}
static SV *lpg_pin(pTHX_ SV *value) {
  EXTEND_MORTAL(1); return sv_2mortal(SvREFCNT_inc(value));
}
static SV *lpg_sv(pTHX_ lpg_scope *scope) {
  lpg_charge(aTHX_ &scope->storage_bytes, 1, sizeof(SV) + 64);
  LB_PERL_GRAPH_CHECKPOINT(); EXTEND_MORTAL(1);
  return sv_2mortal(newSV(0));
}
static SV *lpg_text(pTHX_ lpg_scope *scope, const char *text, size_t length, int unicode) {
  lpg_charge(aTHX_ &scope->storage_bytes, length + 1, 1);
  SV *value = lpg_sv(aTHX_ scope);
  LB_PERL_GRAPH_CHECKPOINT(); sv_setpvn(value, length ? text : "", length);
  if (unicode) SvUTF8_on(value);
  return value;
}
static HV *lpg_hash(pTHX_ lpg_scope *scope) {
  lpg_charge(aTHX_ &scope->storage_bytes, 1, sizeof(HV) + 128);
  LB_PERL_GRAPH_CHECKPOINT(); EXTEND_MORTAL(1);
  return (HV *)sv_2mortal((SV *)newHV());
}
static AV *lpg_array(pTHX_ lpg_scope *scope, size_t length) {
  lpg_charge(aTHX_ &scope->storage_bytes, length, sizeof(SV *) + sizeof(SV) + 64);
  lpg_charge(aTHX_ &scope->storage_bytes, 1, sizeof(AV) + 128);
  LB_PERL_GRAPH_CHECKPOINT(); EXTEND_MORTAL(1);
  AV *value = (AV *)sv_2mortal((SV *)newAV());
  if (length) { LB_PERL_GRAPH_CHECKPOINT(); av_extend(value, length - 1); }
  return value;
}
static SV *lpg_reference(pTHX_ lpg_scope *scope, SV *referent, const char *package) {
  SV *value = lpg_sv(aTHX_ scope);
  LB_PERL_GRAPH_CHECKPOINT(); sv_setrv_inc(value, referent);
  if (package) { LB_PERL_GRAPH_CHECKPOINT(); sv_bless(value, gv_stashpv(package, GV_ADD)); }
  return value;
}
static void lpg_store(pTHX_ lpg_scope *scope, HV *hash, const char *field, SV *value) {
  lpg_charge(aTHX_ &scope->storage_bytes, 1, sizeof(SV) + 64 + strlen(field));
  LB_PERL_GRAPH_CHECKPOINT(); SV **slot = hv_fetch(hash, field, strlen(field), 1);
  if (!slot) croak("Perl graph field allocation failed");
  LB_PERL_GRAPH_CHECKPOINT(); sv_setsv(*slot, value);
}
static void lpg_append(pTHX_ AV *array, size_t index, SV *value) {
  LB_PERL_GRAPH_CHECKPOINT(); SV **slot = av_fetch(array, index, 1);
  if (!slot) croak("Perl graph element allocation failed");
  LB_PERL_GRAPH_CHECKPOINT(); sv_setsv(*slot, value);
}
static int lpg_branch(SV *value, const char *package) {
  if (!SvROK(value) || SvTYPE(SvRV(value)) != SVt_PVHV || SvMAGICAL(SvRV(value)) || !SvOBJECT(SvRV(value))) return 0;
  HV *stash = SvSTASH(SvRV(value));
  const char *name = stash ? HvNAME(stash) : NULL;
  return name && strEQ(name, package);
}
static SV **lpg_fields(pTHX_ lpg_scope *scope, SV *value, const char *package, const char *const *fields, size_t count) {
  if (!lpg_branch(value, package)) croak("Expected exact %s with a plain untied hash", package);
  HV *input = (HV *)lpg_pin(aTHX_ SvRV(value));
  if (HvUSEDKEYS(input) != count) croak("Perl graph fields do not match the generated schema");
  SV **slots = lpg_allocate(aTHX_ scope, count, sizeof(SV *));
  /* Pin every slot before a child conversion can invoke Perl. */
  for (size_t i = 0; i < count; ++i) {
    SV **entry = hv_fetch(input, fields[i], strlen(fields[i]), 0);
    if (!entry) croak("Missing Perl graph field %s", fields[i]);
    slots[i] = lpg_pin(aTHX_ *entry);
  }
  return slots;
}
static SV **lpg_sequence(pTHX_ lpg_scope *scope, SV *value, size_t *length) {
  if (!SvROK(value) || SvTYPE(SvRV(value)) != SVt_PVAV || SvOBJECT(SvRV(value)) ||
      (SvMAGICAL(SvRV(value)) && mg_find(SvRV(value), PERL_MAGIC_tied))) croak("Expected a plain untied array reference");
  AV *array = (AV *)lpg_pin(aTHX_ SvRV(value)); *length = av_count(array);
  if (*length > scope->nodes) croak("Perl copied graph node limit exceeded");
  SV **slots = lpg_allocate(aTHX_ scope, *length, sizeof(SV *));
  for (size_t i = 0; i < *length; ++i) {
    SV **entry = av_fetch(array, i, 0);
    if (!entry) croak("Sparse Perl copied arrays are unsupported");
    slots[i] = lpg_pin(aTHX_ *entry);
  }
  return slots;
}
static uint64_t lpg_unsigned(pTHX_ SV *value, uint64_t maximum) {
  if (!SvIOK(value) || (!SvIsUV(value) && SvIV(value) < 0) || SvUV(value) > maximum)
    croak("Unsigned integer is out of range or not an exact integer scalar");
  return (uint64_t)SvUV(value);
}
static int64_t lpg_signed(pTHX_ SV *value, int64_t minimum, int64_t maximum) {
  if (!SvIOK(value) || (SvIsUV(value) && SvUV(value) > (uint64_t)maximum) ||
      (!SvIsUV(value) && (SvIV(value) < minimum || SvIV(value) > maximum)))
    croak("Signed integer is out of range or not an exact integer scalar");
  return (int64_t)SvIV(value);
}
static SV *lpg_bigint_text(pTHX_ lpg_scope *scope, SV *value, int natural) {
  if (!SvROK(value) || !sv_derived_from(value, "Math::BigInt")) croak("Expected Math::BigInt");
  LB_PERL_GRAPH_CHECKPOINT();
  dSP; PUSHMARK(SP); XPUSHs(value); PUTBACK;
  int count = call_method("bstr", G_SCALAR); SPAGAIN;
  if (count != 1) { SP -= count; PUTBACK; croak("Math::BigInt must return one decimal value"); }
  SV *text = POPs; PUTBACK; lpg_pin(aTHX_ text); SvGETMAGIC(text);
  if (SvROK(text) || (!SvPOK(text) && !SvIOK(text) && !SvNOK(text))) croak("Math::BigInt must return a decimal scalar");
  LB_PERL_GRAPH_CHECKPOINT();
  STRLEN length; const char *bytes = SvPV_nomg(text, length);
  lpg_charge(aTHX_ &scope->storage_bytes, length, 1);
  size_t i = 0;
  if (!length) croak("Invalid Math::BigInt");
  if (bytes[0] == '-') { if (natural) croak("Nat cannot be negative"); i = 1; }
  if (i == length) croak("Invalid Math::BigInt");
  for (; i < length; ++i) if (bytes[i] < '0' || bytes[i] > '9') croak("Math::BigInt must be finite and integral");
  return text;
}
static const uint32_t *lpg_limbs(pTHX_ lpg_scope *scope, SV *value, int natural, size_t *count, int *negative) {
  SV *text = lpg_bigint_text(aTHX_ scope, value, natural);
  STRLEN length; const char *bytes = SvPV_nomg(text, length);
  *negative = bytes[0] == '-'; bytes += *negative; length -= *negative;
  while (length && *bytes == '0') { ++bytes; --length; }
  if (!length) { *count = 0; *negative = 0; return NULL; }
  size_t capacity = length / 9 + 1;
  uint32_t *limbs = lpg_allocate(aTHX_ scope, capacity, sizeof(uint32_t));
  size_t used = 0;
  while (length) {
    size_t digits = length % 9; if (!digits) digits = 9;
    uint32_t factor = 1, chunk = 0;
    for (size_t i = 0; i < digits; ++i) { factor *= 10; chunk = chunk * 10 + (bytes[i] - '0'); }
    uint64_t carry = chunk;
    for (size_t i = 0; i < used; ++i) { carry += (uint64_t)limbs[i] * factor; limbs[i] = (uint32_t)carry; carry >>= 32; }
    if (carry) { if (used == capacity) croak("Perl graph limb capacity exceeded"); limbs[used++] = (uint32_t)carry; }
    bytes += digits; length -= digits;
  }
  lpg_charge(aTHX_ &scope->native_bytes, used, sizeof(uint32_t));
  *count = used; return limbs;
}
static SV *lpg_bigint(pTHX_ lpg_scope *scope, const uint32_t *limbs, size_t count, int negative) {
  while (count && !limbs[count - 1]) --count;
  uint32_t *work = lpg_allocate(aTHX_ scope, count, sizeof(uint32_t));
  if (count) memcpy(work, limbs, count * sizeof(uint32_t));
  size_t capacity = count * 2 + 1;
  uint32_t *chunks = lpg_allocate(aTHX_ scope, capacity, sizeof(uint32_t));
  size_t used = 0;
  while (count) {
    uint64_t remainder = 0;
    for (size_t i = count; i > 0; --i) { uint64_t value = (remainder << 32) | work[i - 1]; work[i - 1] = value / 1000000000; remainder = value % 1000000000; }
    chunks[used++] = remainder;
    while (count && !work[count - 1]) --count;
  }
  char *bytes = lpg_allocate(aTHX_ scope, used * 9 + 3, 1), *cursor = bytes;
  if (negative && used) *cursor++ = '-';
  if (!used) *cursor++ = '0';
  else { cursor += sprintf(cursor, "%u", chunks[--used]); while (used) cursor += sprintf(cursor, "%09u", chunks[--used]); }
  SV *text = lpg_text(aTHX_ scope, bytes, cursor - bytes, 0), *klass = lpg_text(aTHX_ scope, "Math::BigInt", 12, 0);
  LB_PERL_GRAPH_CHECKPOINT(); dSP; PUSHMARK(SP); XPUSHs(klass); XPUSHs(text); PUTBACK;
  int returns = call_method("new", G_SCALAR); SPAGAIN;
  if (returns != 1) { SP -= returns; PUTBACK; croak("Math::BigInt construction failed"); }
  SV *result = POPs; PUTBACK; lpg_pin(aTHX_ result);
  if (!SvROK(result) || !sv_derived_from(result, "Math::BigInt")) croak("Math::BigInt constructor returned an invalid value");
  return result;
}

#include "callbacksubtypes-graph-types.h"
static void lpg_read0(pTHX_ lpg_scope *, SV *, callbacksubtypes_graph_743764d1b67e81fcae92_t *, size_t, int);
static SV *lpg_write0(pTHX_ lpg_scope *, const callbacksubtypes_graph_743764d1b67e81fcae92_t *, size_t, int);
static void lpg_read1(pTHX_ lpg_scope *, SV *, callbacksubtypes_graph_2c6f4131c8731fa67588_t *, size_t, int);
static SV *lpg_write1(pTHX_ lpg_scope *, const callbacksubtypes_graph_2c6f4131c8731fa67588_t *, size_t, int);
static void lpg_read2(pTHX_ lpg_scope *, SV *, callbacksubtypes_graph_6c9c0cf3d3abf9adeb4b_t *, size_t, int);
static SV *lpg_write2(pTHX_ lpg_scope *, const callbacksubtypes_graph_6c9c0cf3d3abf9adeb4b_t *, size_t, int);
static void lpg_read3(pTHX_ lpg_scope *, SV *, callbacksubtypes_scalar_nat_t *, size_t, int);
static SV *lpg_write3(pTHX_ lpg_scope *, const callbacksubtypes_scalar_nat_t *, size_t, int);
static void lpg_read4(pTHX_ lpg_scope *, SV *, callbacksubtypes_scalar_string_t *, size_t, int);
static SV *lpg_write4(pTHX_ lpg_scope *, const callbacksubtypes_scalar_string_t *, size_t, int);
static void lpg_read5(pTHX_ lpg_scope *, SV *, uint8_t *, size_t, int);
static SV *lpg_write5(pTHX_ lpg_scope *, const uint8_t *, size_t, int);
static void lpg_read0(pTHX_ lpg_scope *scope, SV *value, callbacksubtypes_graph_743764d1b67e81fcae92_t *out, size_t depth, int storage) {
  (void)out; SvGETMAGIC(value);
  lpg_enter(aTHX_ scope, SvROK(value) ? SvRV(value) : NULL, 0, depth, storage ? sizeof(*out) : 0, 0);
  if (!SvOK(value)) { out->has_value = 0; return; }
  if (lpg_branch(value, "LeanBridge::CallbackSubtypes::Some")) { out->has_value = 1;
  static const char *const fields[] = {"value"};
  SV **slots = lpg_fields(aTHX_ scope, value, "LeanBridge::CallbackSubtypes::Some", fields, 1); (void)slots;
  lpg_read3(aTHX_ scope, slots[0], &out->value, depth + 1, 0);
  return;
  }
  croak("Expected undef or Some");
}
static SV *lpg_write0(pTHX_ lpg_scope *scope, const callbacksubtypes_graph_743764d1b67e81fcae92_t *value, size_t depth, int storage) {
  lpg_pointer(aTHX_ scope, value, 1, sizeof(*value), _Alignof(callbacksubtypes_graph_743764d1b67e81fcae92_t));
  lpg_enter(aTHX_ scope, value, 0, depth, storage ? sizeof(*value) : 0, 1);
  if (value->has_value > 1) lpg_invalid(aTHX_ scope, "branch flag");
  if (!value->has_value) return &PL_sv_undef;
  {
  HV *result = lpg_hash(aTHX_ scope);
  lpg_store(aTHX_ scope, result, "value", lpg_write3(aTHX_ scope, &value->value, depth + 1, 0));
  return lpg_reference(aTHX_ scope, (SV *)result, "LeanBridge::CallbackSubtypes::Some");
  }
}

static void lpg_read1(pTHX_ lpg_scope *scope, SV *value, callbacksubtypes_graph_2c6f4131c8731fa67588_t *out, size_t depth, int storage) {
  (void)out; SvGETMAGIC(value);
  lpg_enter(aTHX_ scope, SvROK(value) ? SvRV(value) : NULL, 1, depth, storage ? sizeof(*out) : 0, 0);
  if (lpg_branch(value, "LeanBridge::CallbackSubtypes::Ok")) { out->is_ok = 1;
  static const char *const fields[] = {"value"};
  SV **slots = lpg_fields(aTHX_ scope, value, "LeanBridge::CallbackSubtypes::Ok", fields, 1); (void)slots;
  lpg_read0(aTHX_ scope, slots[0], &out->ok, depth + 1, 0);
  return;
  }
  if (lpg_branch(value, "LeanBridge::CallbackSubtypes::Err")) { out->is_ok = 0;
  static const char *const fields[] = {"value"};
  SV **slots = lpg_fields(aTHX_ scope, value, "LeanBridge::CallbackSubtypes::Err", fields, 1); (void)slots;
  lpg_read4(aTHX_ scope, slots[0], &out->error, depth + 1, 0);
  return;
  }
  croak("Expected Ok or Err");
}
static SV *lpg_write1(pTHX_ lpg_scope *scope, const callbacksubtypes_graph_2c6f4131c8731fa67588_t *value, size_t depth, int storage) {
  lpg_pointer(aTHX_ scope, value, 1, sizeof(*value), _Alignof(callbacksubtypes_graph_2c6f4131c8731fa67588_t));
  lpg_enter(aTHX_ scope, value, 1, depth, storage ? sizeof(*value) : 0, 1);
  if (value->is_ok > 1) lpg_invalid(aTHX_ scope, "branch flag");
  if (value->is_ok) {
  HV *result = lpg_hash(aTHX_ scope);
  lpg_store(aTHX_ scope, result, "value", lpg_write0(aTHX_ scope, &value->ok, depth + 1, 0));
  return lpg_reference(aTHX_ scope, (SV *)result, "LeanBridge::CallbackSubtypes::Ok");
  }
  else {
  HV *result = lpg_hash(aTHX_ scope);
  lpg_store(aTHX_ scope, result, "value", lpg_write4(aTHX_ scope, &value->error, depth + 1, 0));
  return lpg_reference(aTHX_ scope, (SV *)result, "LeanBridge::CallbackSubtypes::Err");
  }
}

static void lpg_read2(pTHX_ lpg_scope *scope, SV *value, callbacksubtypes_graph_6c9c0cf3d3abf9adeb4b_t *out, size_t depth, int storage) {
  (void)out; SvGETMAGIC(value);
  lpg_enter(aTHX_ scope, SvROK(value) ? SvRV(value) : NULL, 2, depth, storage ? sizeof(*out) : 0, 0);
  size_t length; SV **slots = lpg_sequence(aTHX_ scope, value, &length);
  lpg_charge(aTHX_ &scope->native_bytes, length, sizeof(callbacksubtypes_graph_743764d1b67e81fcae92_t));
  callbacksubtypes_graph_743764d1b67e81fcae92_t *data = lpg_allocate(aTHX_ scope, length, sizeof(*data)); out->data = data; out->length = length;
  for (size_t i = 0; i < length; ++i) lpg_read0(aTHX_ scope, slots[i], &data[i], depth + 1, 0);
}
static SV *lpg_write2(pTHX_ lpg_scope *scope, const callbacksubtypes_graph_6c9c0cf3d3abf9adeb4b_t *value, size_t depth, int storage) {
  lpg_pointer(aTHX_ scope, value, 1, sizeof(*value), _Alignof(callbacksubtypes_graph_6c9c0cf3d3abf9adeb4b_t));
  lpg_enter(aTHX_ scope, value, 2, depth, storage ? sizeof(*value) : 0, 1);
  lpg_charge(aTHX_ &scope->native_bytes, value->length, sizeof(callbacksubtypes_graph_743764d1b67e81fcae92_t));
  if (value->length > scope->nodes) croak("Perl copied graph node limit exceeded");
  lpg_pointer(aTHX_ scope, value->data, value->length, sizeof(callbacksubtypes_graph_743764d1b67e81fcae92_t), _Alignof(callbacksubtypes_graph_743764d1b67e81fcae92_t));
  AV *result = lpg_array(aTHX_ scope, value->length);
  for (size_t i = 0; i < value->length; ++i) lpg_append(aTHX_ result, i, lpg_write0(aTHX_ scope, &value->data[i], depth + 1, 0));
  return lpg_reference(aTHX_ scope, (SV *)result, NULL);
}

static void lpg_read3(pTHX_ lpg_scope *scope, SV *value, callbacksubtypes_scalar_nat_t *out, size_t depth, int storage) {
  (void)out; SvGETMAGIC(value);
  lpg_enter(aTHX_ scope, SvROK(value) ? SvRV(value) : NULL, 3, depth, storage ? sizeof(*out) : 0, 0);
  int negative; out->data = lpg_limbs(aTHX_ scope, value, 1, &out->length, &negative);
  (void)negative;
}
static SV *lpg_write3(pTHX_ lpg_scope *scope, const callbacksubtypes_scalar_nat_t *value, size_t depth, int storage) {
  lpg_pointer(aTHX_ scope, value, 1, sizeof(*value), _Alignof(callbacksubtypes_scalar_nat_t));
  lpg_enter(aTHX_ scope, value, 3, depth, storage ? sizeof(*value) : 0, 1);
  lpg_charge(aTHX_ &scope->native_bytes, value->length, sizeof(uint32_t));
  lpg_pointer(aTHX_ scope, value->data, value->length, sizeof(uint32_t), _Alignof(uint32_t));
  uint8_t negative = 0;
  return lpg_bigint(aTHX_ scope, value->data, value->length, negative);
}

static void lpg_read4(pTHX_ lpg_scope *scope, SV *value, callbacksubtypes_scalar_string_t *out, size_t depth, int storage) {
  (void)out; SvGETMAGIC(value);
  lpg_enter(aTHX_ scope, SvROK(value) ? SvRV(value) : NULL, 4, depth, storage ? sizeof(*out) : 0, 0);
  if (SvROK(value)) croak("Expected a scalar value");
  if (!SvPOK(value)) croak("Expected a string scalar");
  STRLEN length; const U8 *bytes = (const U8 *)SvPV_nomg(value, length); size_t size = length;
  if (SvUTF8(value)) { if (length && !is_utf8_string_flags(bytes, length, UTF8_DISALLOW_SURROGATE | UTF8_DISALLOW_SUPER)) croak("String contains invalid Unicode"); }
  else { for (size_t i = 0; i < length; ++i) if (bytes[i] >= 128) { if (size == SIZE_MAX) croak("String size overflow"); ++size; } }
  lpg_charge(aTHX_ &scope->native_bytes, size, 1);
  U8 *data = lpg_allocate(aTHX_ scope, size, 1); out->data = (const void *)data; out->length = size;
  if (!SvUTF8(value)) { size_t j = 0; for (size_t i = 0; i < length; ++i) { U8 point = bytes[i]; if (point >= 128) { data[j++] = 0xc0 | (point >> 6); data[j++] = 0x80 | (point & 63); } else data[j++] = point; } }
  else if (length) memcpy(data, bytes, length);
}
static SV *lpg_write4(pTHX_ lpg_scope *scope, const callbacksubtypes_scalar_string_t *value, size_t depth, int storage) {
  lpg_pointer(aTHX_ scope, value, 1, sizeof(*value), _Alignof(callbacksubtypes_scalar_string_t));
  lpg_enter(aTHX_ scope, value, 4, depth, storage ? sizeof(*value) : 0, 1);
  lpg_charge(aTHX_ &scope->native_bytes, value->length, 1);
  lpg_pointer(aTHX_ scope, value->data, value->length, 1, 1);
  if (value->length && !is_utf8_string_flags((const U8 *)value->data, value->length, UTF8_DISALLOW_SURROGATE | UTF8_DISALLOW_SUPER)) lpg_invalid(aTHX_ scope, "UTF-8");
  return lpg_text(aTHX_ scope, (const char *)value->data, value->length, 1);
}

static void lpg_read5(pTHX_ lpg_scope *scope, SV *value, uint8_t *out, size_t depth, int storage) {
  (void)out; SvGETMAGIC(value);
  lpg_enter(aTHX_ scope, SvROK(value) ? SvRV(value) : NULL, 5, depth, storage ? sizeof(*out) : 0, 0);
  if (SvROK(value)) croak("Expected a scalar value");
  if (SvOK(value)) croak("Unit requires undef");
  *out = 0;
}
static SV *lpg_write5(pTHX_ lpg_scope *scope, const uint8_t *value, size_t depth, int storage) {
  lpg_pointer(aTHX_ scope, value, 1, sizeof(*value), _Alignof(uint8_t));
  lpg_enter(aTHX_ scope, value, 5, depth, storage ? sizeof(*value) : 0, 1);
  if (*value) lpg_invalid(aTHX_ scope, "Unit");
  return &PL_sv_undef;
}

static void lpg_retire(void);
static int lpg_ready(void);

typedef struct {
  lpg_scope *scope;
  SV *error;
  SV *replacement;
} lpc_frame;
typedef struct lpc_lease lpc_lease;
typedef struct {
  lpc_frame *frame;
  SV *code;
  CV *invoker;
  lpc_lease *lease;
} lpc_callback;
typedef struct {
  lpc_callback *callback;
  const void **arguments;
  void *output;
  int returned;
} lpc_invocation;
static lpc_invocation *lpc_active;
static void lpc_frame_end(pTHX_ void *value) {
  lpc_frame *frame = value;
  SvREFCNT_dec(frame->error); SvREFCNT_dec(frame->replacement);
}
static lpc_frame *lpc_begin(pTHX_ lpg_scope *scope) {
  lpc_frame *frame = lpg_allocate(aTHX_ scope, 1, sizeof(*frame));
  SSGROW(4); SAVEDESTRUCTOR_X(lpc_frame_end, frame);
  frame->scope = scope;
  /* Preserve aliases to the caller's $@ scalar. Only the localized scalar is
     transferred when a callback fails; normal Perl unwinding restores it. */
  save_scalar(PL_errgv);
  /* Allocate before native entry. Taking an exception from ERRSV later must
     not allocate or run user overloads while native cleanup is pending. */
  LB_PERL_GRAPH_CHECKPOINT(); frame->replacement = newSVpvs("");
  return frame;
}
static uint32_t lpc_invoke(lpc_callback *callback, const void **arguments, void *output) {
  dTHX; dSP;
  lpc_frame *frame = callback->frame;
  if (frame->error) return 6;
  lpc_invocation invocation = { callback, arguments, output, 0 }, *previous = lpc_active;
  lpc_active = &invocation;
  PUSHMARK(SP); PUTBACK;
  /* G_DISCARD frees temporaries after Perl has popped its eval boundary.
     The converter instead frees its temporaries inside that boundary. */
  int count = call_sv((SV *)callback->invoker, G_VOID | G_EVAL);
  SPAGAIN; SP -= count;
  if (SvROK(ERRSV) || SvTRUE(ERRSV)) {
    /* Transfer the global scalar's existing ownership. Exception objects and
       false-looking exceptions retain identity without stringification. */
    frame->error = GvSV(PL_errgv);
    GvSV(PL_errgv) = frame->replacement; frame->replacement = NULL;
  }
  PUTBACK;
  lpc_active = previous;
  return !frame->error && invocation.returned ? 0 : 6;
}
static void lpc_finish(pTHX_ lpc_frame *frame, uint32_t status) {
  if (frame->error) croak_sv(frame->error);
  if (status == 4) lpg_invalid(aTHX_ frame->scope, "carrier or callback result");
  const char *message = status == 1 ? "invalid argument or expired callback borrow" : status == 2 ? "conversion limit exceeded" :
    status == 3 ? "native allocation failed" : status == 5 ? "shared runtime unavailable" : status == 6 ? "host callback failed" : "unknown status";
  if (status) croak("Lean Bridge callable graph failed (status=%u): %s", (unsigned)status, message);
}
struct lpc_lease {
  uint64_t token;
  size_t signature;
  unsigned active;
  int closed, orphan;
  pid_t process;
  void (*dispose)(uint64_t);
};
static void lpc_lease_drop(lpc_lease *lease) {
  if (!lease->active && lease->token) {
    uint64_t token = lease->token; lease->token = 0;
    /* A forked child's finalizer never enters inherited native locks. */
    if (lease->process == getpid()) lease->dispose(token);
  }
}
static int lpc_lease_free(pTHX_ SV *value, MAGIC *magic) {
  PERL_UNUSED_CONTEXT; (void)value;
  lpc_lease *lease = (lpc_lease *)magic->mg_ptr; magic->mg_ptr = NULL;
  if (lease) {
    lease->closed = lease->orphan = 1; lpc_lease_drop(lease);
    if (!lease->active) LB_PERL_GRAPH_FREE(lease);
  }
  return 0;
}
#ifdef USE_ITHREADS
static int lpc_lease_dup(pTHX_ MAGIC *magic, CLONE_PARAMS *params) {
  PERL_UNUSED_CONTEXT; (void)params; magic->mg_ptr = NULL; return 0;
}
#endif
static MGVTBL lpc_lease_magic = {
  .svt_free = lpc_lease_free,
#ifdef USE_ITHREADS
  .svt_dup = lpc_lease_dup,
#endif
};
static lpc_lease *lpc_get_lease(pTHX_ SV *value) {
  lbp_check_interpreter(aTHX);
  if (!SvROK(value)) croak("Expected a generated Lean closure");
  MAGIC *magic = mg_findext(SvRV(value), PERL_MAGIC_ext, &lpc_lease_magic);
  if (!magic || !magic->mg_ptr) croak("Invalid or foreign Lean closure");
  return (lpc_lease *)magic->mg_ptr;
}
static SV *lpc_lease_new(pTHX_ lpg_scope *scope, size_t signature, void (*dispose)(uint64_t), const char *package, lpc_lease **out) {
  HV *hash = lpg_hash(aTHX_ scope);
  SV *value = lpg_reference(aTHX_ scope, (SV *)hash, package);
  LB_PERL_GRAPH_CHECKPOINT();
  MAGIC *magic = sv_magicext((SV *)hash, NULL, PERL_MAGIC_ext, &lpc_lease_magic, NULL, 0);
#ifdef USE_ITHREADS
  magic->mg_flags |= MGf_DUP;
#endif
  lpg_charge(aTHX_ &scope->storage_bytes, 1, sizeof(lpc_lease));
  LB_PERL_GRAPH_CHECKPOINT();
  lpc_lease *lease = LB_PERL_GRAPH_MALLOC(sizeof(*lease));
  if (!lease) croak("Perl closure allocation failed");
  *lease = (lpc_lease){ .signature = signature, .dispose = dispose, .process = getpid() };
  magic->mg_ptr = (char *)lease; *out = lease;
  return value;
}
typedef struct { lpc_lease *lease; } lpc_lease_guard;
static void lpc_guard_end(pTHX_ void *value) {
  PERL_UNUSED_CONTEXT;
  lpc_lease *lease = ((lpc_lease_guard *)value)->lease;
  if (lease) {
    --lease->active;
    if (lease->closed) lpc_lease_drop(lease);
    if (lease->orphan && !lease->active) LB_PERL_GRAPH_FREE(lease);
  }
}
static lpc_lease *lpc_lease_enter(pTHX_ lpg_scope *scope, SV *value, size_t signature) {
  lpc_lease *lease = lpc_get_lease(aTHX_ value);
  if (lease->signature != signature) croak("Wrong Lean closure signature");
  if (lease->closed || !lease->token) croak("Lean closure is closed");
  if (lease->active == 64) croak("Lean closure reentry limit exceeded");
  lpc_lease_guard *guard = lpg_allocate(aTHX_ scope, 1, sizeof(*guard));
  SSGROW(4); SAVEDESTRUCTOR_X(lpc_guard_end, guard);
  guard->lease = lease; ++lease->active;
  return lease;
}
static lpc_callback *lpc_callback_new(pTHX_ lpc_frame *frame, SV *code, size_t signature, const char *converter) {
  SvGETMAGIC(code);
  int closure = !(SvROK(code) && SvTYPE(SvRV(code)) == SVt_PVCV && !SvOBJECT(SvRV(code)));
  lpc_lease *lease = closure ? lpc_lease_enter(aTHX_ frame->scope, code, signature) : NULL;
  CV *invoker = get_cv(converter, 0);
  if (!invoker) croak("Missing generated callback converter");
  lpc_callback *callback = lpg_allocate(aTHX_ frame->scope, 1, sizeof(*callback));
  callback->frame = frame;
  callback->lease = lease;
  callback->code = closure ? NULL : lpg_pin(aTHX_ SvRV(code));
  callback->invoker = (CV *)lpg_pin(aTHX_ (SV *)invoker);
  return callback;
}

static uint32_t lpc_callback_0(void *context, const callbacksubtypes_graph_743764d1b67e81fcae92_t *a0, callbacksubtypes_graph_2c6f4131c8731fa67588_t *out) {
  lpc_callback *callback = context;
  if (callback->frame->error) return 6;
  
  const void *arguments[] = { a0 };
  return lpc_invoke(context, arguments, out);
}
static uint32_t lpc_callback_1(void *context, const callbacksubtypes_scalar_nat_t *a0, callbacksubtypes_scalar_nat_t *out) {
  lpc_callback *callback = context;
  if (callback->frame->error) return 6;
  if (callback->lease) return callbacksubtypes_callback_c27fa7df7f1805196544d398fb121b21c179beb1_lease_call(callback->lease->token, a0, out);
  const void *arguments[] = { a0 };
  return lpc_invoke(context, arguments, out);
}
static uint32_t lpc_callback_2(void *context, const callbacksubtypes_scalar_nat_t *a0, const callbacksubtypes_scalar_nat_t *a1, callbacksubtypes_scalar_nat_t *out) {
  lpc_callback *callback = context;
  if (callback->frame->error) return 6;
  
  const void *arguments[] = { a0, a1 };
  return lpc_invoke(context, arguments, out);
}
static uint32_t lpc_callback_3(void *context, const callbacksubtypes_scalar_nat_t *a0, const callbacksubtypes_scalar_nat_t *a1, callbacksubtypes_scalar_nat_t *out) {
  lpc_callback *callback = context;
  if (callback->frame->error) return 6;
  if (callback->lease) return callbacksubtypes_callback_51bfd752726fcfd8a9187a7c3a979ace51f7c1be_lease_call(callback->lease->token, a0, a1, out);
  const void *arguments[] = { a0, a1 };
  return lpc_invoke(context, arguments, out);
}
static uint32_t lpc_callback_4(void *context, const callbacksubtypes_graph_6c9c0cf3d3abf9adeb4b_t *a0, callbacksubtypes_graph_743764d1b67e81fcae92_t *out) {
  lpc_callback *callback = context;
  if (callback->frame->error) return 6;
  if (callback->lease) return callbacksubtypes_callback_6cdd9c3be7604978d190e4f9d3a70db0539487ba_lease_call(callback->lease->token, a0, out);
  const void *arguments[] = { a0 };
  return lpc_invoke(context, arguments, out);
}
static uint32_t lpc_callback_5(void *context, const callbacksubtypes_scalar_nat_t *a0, callbacksubtypes_scalar_nat_t *out) {
  lpc_callback *callback = context;
  if (callback->frame->error) return 6;
  
  const void *arguments[] = { a0 };
  return lpc_invoke(context, arguments, out);
}
static void lpc_clear0(void *value) { callbacksubtypes_graph_743764d1b67e81fcae92_t_clear(value); }
static void lpc_clear1(void *value) { callbacksubtypes_graph_2c6f4131c8731fa67588_t_clear(value); }
static void lpc_clear2(void *value) { callbacksubtypes_graph_6c9c0cf3d3abf9adeb4b_t_clear(value); }
static void lpc_clear3(void *value) { callbacksubtypes_scalar_nat_t_clear(value); }
static void lpc_clear4(void *value) { callbacksubtypes_scalar_string_t_clear(value); }
static int lpg_ready(void) { return ng_ready(); }
static void lpg_retire(void) { lean_bridge_native_runtime_retire(); }

MODULE = LeanBridge::CallbackSubtypes PACKAGE = LeanBridge::CallbackSubtypes
PROTOTYPES: DISABLE

void
_callback_14cd8f1b0d065ede9a36f8590000c62c12d8e99c(...)
  PPCODE:
    lbp_check_interpreter(aTHX);
    if (!lpc_active || lpc_active->callback->invoker != cv) croak("Callback converter requires its active native invocation");
    lpc_invocation *invocation = lpc_active;
    lpg_scope *scope = invocation->callback->frame->scope;
    ENTER; SAVETMPS;
    if (!lpg_ready()) croak("Shared Lean runtime is unavailable");
    SV *argument0 = lpg_write0(aTHX_ scope, invocation->arguments[0], 0, 1);
    SPAGAIN; PUSHMARK(SP); EXTEND(SP, 1);
    PUSHs(argument0); PUTBACK;
    int count = call_sv(invocation->callback->code, G_SCALAR);
    SPAGAIN;
    if (count != 1) { SP -= count; PUTBACK; croak("Host callback must return one value"); }
    SV *returned = POPs; PUTBACK; lpg_pin(aTHX_ returned);
    lbp_check_interpreter(aTHX);
    if (!lpg_ready()) croak("Shared Lean runtime is unavailable");
    /* Allocate replies in the initiating scope. The native caller copies them
       only after this converter and its eval have returned. */
    lpg_read1(aTHX_ scope, returned, invocation->output, 0, 1);
    FREETMPS; LEAVE;
    invocation->returned = 1;
    XSRETURN_EMPTY;

void
_callback_c27fa7df7f1805196544d398fb121b21c179beb1(...)
  PPCODE:
    lbp_check_interpreter(aTHX);
    if (!lpc_active || lpc_active->callback->invoker != cv) croak("Callback converter requires its active native invocation");
    lpc_invocation *invocation = lpc_active;
    lpg_scope *scope = invocation->callback->frame->scope;
    ENTER; SAVETMPS;
    if (!lpg_ready()) croak("Shared Lean runtime is unavailable");
    SV *argument0 = lpg_write3(aTHX_ scope, invocation->arguments[0], 0, 1);
    SPAGAIN; PUSHMARK(SP); EXTEND(SP, 1);
    PUSHs(argument0); PUTBACK;
    int count = call_sv(invocation->callback->code, G_SCALAR);
    SPAGAIN;
    if (count != 1) { SP -= count; PUTBACK; croak("Host callback must return one value"); }
    SV *returned = POPs; PUTBACK; lpg_pin(aTHX_ returned);
    lbp_check_interpreter(aTHX);
    if (!lpg_ready()) croak("Shared Lean runtime is unavailable");
    /* Allocate replies in the initiating scope. The native caller copies them
       only after this converter and its eval have returned. */
    lpg_read3(aTHX_ scope, returned, invocation->output, 0, 1);
    FREETMPS; LEAVE;
    invocation->returned = 1;
    XSRETURN_EMPTY;

void
_callback_197d5bf19058d37bc5547c33a8e0bed3bf121ea7(...)
  PPCODE:
    lbp_check_interpreter(aTHX);
    if (!lpc_active || lpc_active->callback->invoker != cv) croak("Callback converter requires its active native invocation");
    lpc_invocation *invocation = lpc_active;
    lpg_scope *scope = invocation->callback->frame->scope;
    ENTER; SAVETMPS;
    if (!lpg_ready()) croak("Shared Lean runtime is unavailable");
    SV *argument0 = lpg_write3(aTHX_ scope, invocation->arguments[0], 0, 1);
    SV *argument1 = lpg_write3(aTHX_ scope, invocation->arguments[1], 0, 1);
    SPAGAIN; PUSHMARK(SP); EXTEND(SP, 2);
    PUSHs(argument0); PUSHs(argument1); PUTBACK;
    int count = call_sv(invocation->callback->code, G_SCALAR);
    SPAGAIN;
    if (count != 1) { SP -= count; PUTBACK; croak("Host callback must return one value"); }
    SV *returned = POPs; PUTBACK; lpg_pin(aTHX_ returned);
    lbp_check_interpreter(aTHX);
    if (!lpg_ready()) croak("Shared Lean runtime is unavailable");
    /* Allocate replies in the initiating scope. The native caller copies them
       only after this converter and its eval have returned. */
    lpg_read3(aTHX_ scope, returned, invocation->output, 0, 1);
    FREETMPS; LEAVE;
    invocation->returned = 1;
    XSRETURN_EMPTY;

void
_callback_51bfd752726fcfd8a9187a7c3a979ace51f7c1be(...)
  PPCODE:
    lbp_check_interpreter(aTHX);
    if (!lpc_active || lpc_active->callback->invoker != cv) croak("Callback converter requires its active native invocation");
    lpc_invocation *invocation = lpc_active;
    lpg_scope *scope = invocation->callback->frame->scope;
    ENTER; SAVETMPS;
    if (!lpg_ready()) croak("Shared Lean runtime is unavailable");
    SV *argument0 = lpg_write3(aTHX_ scope, invocation->arguments[0], 0, 1);
    SV *argument1 = lpg_write3(aTHX_ scope, invocation->arguments[1], 0, 1);
    SPAGAIN; PUSHMARK(SP); EXTEND(SP, 2);
    PUSHs(argument0); PUSHs(argument1); PUTBACK;
    int count = call_sv(invocation->callback->code, G_SCALAR);
    SPAGAIN;
    if (count != 1) { SP -= count; PUTBACK; croak("Host callback must return one value"); }
    SV *returned = POPs; PUTBACK; lpg_pin(aTHX_ returned);
    lbp_check_interpreter(aTHX);
    if (!lpg_ready()) croak("Shared Lean runtime is unavailable");
    /* Allocate replies in the initiating scope. The native caller copies them
       only after this converter and its eval have returned. */
    lpg_read3(aTHX_ scope, returned, invocation->output, 0, 1);
    FREETMPS; LEAVE;
    invocation->returned = 1;
    XSRETURN_EMPTY;

void
_callback_6cdd9c3be7604978d190e4f9d3a70db0539487ba(...)
  PPCODE:
    lbp_check_interpreter(aTHX);
    if (!lpc_active || lpc_active->callback->invoker != cv) croak("Callback converter requires its active native invocation");
    lpc_invocation *invocation = lpc_active;
    lpg_scope *scope = invocation->callback->frame->scope;
    ENTER; SAVETMPS;
    if (!lpg_ready()) croak("Shared Lean runtime is unavailable");
    SV *argument0 = lpg_write2(aTHX_ scope, invocation->arguments[0], 0, 1);
    SPAGAIN; PUSHMARK(SP); EXTEND(SP, 1);
    PUSHs(argument0); PUTBACK;
    int count = call_sv(invocation->callback->code, G_SCALAR);
    SPAGAIN;
    if (count != 1) { SP -= count; PUTBACK; croak("Host callback must return one value"); }
    SV *returned = POPs; PUTBACK; lpg_pin(aTHX_ returned);
    lbp_check_interpreter(aTHX);
    if (!lpg_ready()) croak("Shared Lean runtime is unavailable");
    /* Allocate replies in the initiating scope. The native caller copies them
       only after this converter and its eval have returned. */
    lpg_read0(aTHX_ scope, returned, invocation->output, 0, 1);
    FREETMPS; LEAVE;
    invocation->returned = 1;
    XSRETURN_EMPTY;

void
_callback_6bc98ee774b20d3238b9e42a92309a51ce9dad0a(...)
  PPCODE:
    lbp_check_interpreter(aTHX);
    if (!lpc_active || lpc_active->callback->invoker != cv) croak("Callback converter requires its active native invocation");
    lpc_invocation *invocation = lpc_active;
    lpg_scope *scope = invocation->callback->frame->scope;
    ENTER; SAVETMPS;
    if (!lpg_ready()) croak("Shared Lean runtime is unavailable");
    SV *argument0 = lpg_write3(aTHX_ scope, invocation->arguments[0], 0, 1);
    SPAGAIN; PUSHMARK(SP); EXTEND(SP, 1);
    PUSHs(argument0); PUTBACK;
    int count = call_sv(invocation->callback->code, G_SCALAR);
    SPAGAIN;
    if (count != 1) { SP -= count; PUTBACK; croak("Host callback must return one value"); }
    SV *returned = POPs; PUTBACK; lpg_pin(aTHX_ returned);
    lbp_check_interpreter(aTHX);
    if (!lpg_ready()) croak("Shared Lean runtime is unavailable");
    /* Allocate replies in the initiating scope. The native caller copies them
       only after this converter and its eval have returned. */
    lpg_read3(aTHX_ scope, returned, invocation->output, 0, 1);
    FREETMPS; LEAVE;
    invocation->returned = 1;
    XSRETURN_EMPTY;

void
call_host(...)
  PPCODE:
    if (items != 1) croak("call_host expects 1 arguments");
    lbp_check_interpreter(aTHX);
    ENTER;
    lpg_scope *scope = lpg_begin(aTHX_ lpg_retire);
    lpc_frame *frame = lpc_begin(aTHX_ scope);
    SV *argument0 = lpg_pin(aTHX_ ST(0));
    
    static const char *const callback0_fields[] = {"code", "recovery"};
    SV **callback0_slots = lpg_fields(aTHX_ scope, argument0, "LeanBridge::CallbackSubtypes::Runtime::Callback", callback0_fields, 2);
    callbacksubtypes_scalar_nat_t *recovery0 = lpg_allocate(aTHX_ scope, 1, sizeof(*recovery0));
    lpg_read3(aTHX_ scope, callback0_slots[1], recovery0, 0, 1);
    callbacksubtypes_callback_6bc98ee774b20d3238b9e42a92309a51ce9dad0a input0 = {lpc_callback_5, lpc_callback_new(aTHX_ frame, callback0_slots[0], 5, "LeanBridge::CallbackSubtypes::_callback_6bc98ee774b20d3238b9e42a92309a51ce9dad0a"), recovery0};
    callbacksubtypes_scalar_nat_t *output = lpg_allocate(aTHX_ scope, 1, sizeof(*output));
    scope->output = output; scope->clear = lpc_clear3;
    lbp_check_interpreter(aTHX);
    uint32_t status = lean_bridge_23220a30761b2d3716c5b4ed_graph(&input0, output);
    lpc_finish(aTHX_ frame, status);
    if (!lpg_ready()) croak("Shared Lean runtime is unavailable");
    SV *out = lpg_write3(aTHX_ scope, output, 0, 1);
    lbp_check_interpreter(aTHX);
    if (!lpg_ready()) croak("Shared Lean runtime is unavailable");
    /* Guards and errors refer to scope storage, so LEAVE must run them before
       lpg_end frees that storage. */
    LEAVE;
    SPAGAIN; SP -= items; EXTEND(SP, 1); XPUSHs(out);

void
call_host_container(...)
  PPCODE:
    if (items != 1) croak("call_host_container expects 1 arguments");
    lbp_check_interpreter(aTHX);
    ENTER;
    lpg_scope *scope = lpg_begin(aTHX_ lpg_retire);
    lpc_frame *frame = lpc_begin(aTHX_ scope);
    SV *argument0 = lpg_pin(aTHX_ ST(0));
    
    static const char *const callback0_fields[] = {"code", "recovery"};
    SV **callback0_slots = lpg_fields(aTHX_ scope, argument0, "LeanBridge::CallbackSubtypes::Runtime::Callback", callback0_fields, 2);
    callbacksubtypes_graph_2c6f4131c8731fa67588_t *recovery0 = lpg_allocate(aTHX_ scope, 1, sizeof(*recovery0));
    lpg_read1(aTHX_ scope, callback0_slots[1], recovery0, 0, 1);
    callbacksubtypes_callback_14cd8f1b0d065ede9a36f8590000c62c12d8e99c input0 = {lpc_callback_0, lpc_callback_new(aTHX_ frame, callback0_slots[0], 0, "LeanBridge::CallbackSubtypes::_callback_14cd8f1b0d065ede9a36f8590000c62c12d8e99c"), recovery0};
    callbacksubtypes_graph_2c6f4131c8731fa67588_t *output = lpg_allocate(aTHX_ scope, 1, sizeof(*output));
    scope->output = output; scope->clear = lpc_clear1;
    lbp_check_interpreter(aTHX);
    uint32_t status = lean_bridge_8ffe188578f9a7b74003cf3c_graph(&input0, output);
    lpc_finish(aTHX_ frame, status);
    if (!lpg_ready()) croak("Shared Lean runtime is unavailable");
    SV *out = lpg_write1(aTHX_ scope, output, 0, 1);
    lbp_check_interpreter(aTHX);
    if (!lpg_ready()) croak("Shared Lean runtime is unavailable");
    /* Guards and errors refer to scope storage, so LEAVE must run them before
       lpg_end frees that storage. */
    LEAVE;
    SPAGAIN; SP -= items; EXTEND(SP, 1); XPUSHs(out);

void
call_host_mixed(...)
  PPCODE:
    if (items != 1) croak("call_host_mixed expects 1 arguments");
    lbp_check_interpreter(aTHX);
    ENTER;
    lpg_scope *scope = lpg_begin(aTHX_ lpg_retire);
    lpc_frame *frame = lpc_begin(aTHX_ scope);
    SV *argument0 = lpg_pin(aTHX_ ST(0));
    
    static const char *const callback0_fields[] = {"code", "recovery"};
    SV **callback0_slots = lpg_fields(aTHX_ scope, argument0, "LeanBridge::CallbackSubtypes::Runtime::Callback", callback0_fields, 2);
    callbacksubtypes_scalar_nat_t *recovery0 = lpg_allocate(aTHX_ scope, 1, sizeof(*recovery0));
    lpg_read3(aTHX_ scope, callback0_slots[1], recovery0, 0, 1);
    callbacksubtypes_callback_197d5bf19058d37bc5547c33a8e0bed3bf121ea7 input0 = {lpc_callback_2, lpc_callback_new(aTHX_ frame, callback0_slots[0], 2, "LeanBridge::CallbackSubtypes::_callback_197d5bf19058d37bc5547c33a8e0bed3bf121ea7"), recovery0};
    callbacksubtypes_scalar_nat_t *output = lpg_allocate(aTHX_ scope, 1, sizeof(*output));
    scope->output = output; scope->clear = lpc_clear3;
    lbp_check_interpreter(aTHX);
    uint32_t status = lean_bridge_4f106adfac5064464a2a8e3f_graph(&input0, output);
    lpc_finish(aTHX_ frame, status);
    if (!lpg_ready()) croak("Shared Lean runtime is unavailable");
    SV *out = lpg_write3(aTHX_ scope, output, 0, 1);
    lbp_check_interpreter(aTHX);
    if (!lpg_ready()) croak("Shared Lean runtime is unavailable");
    /* Guards and errors refer to scope storage, so LEAVE must run them before
       lpg_end frees that storage. */
    LEAVE;
    SPAGAIN; SP -= items; EXTEND(SP, 1); XPUSHs(out);

void
make_closure(...)
  PPCODE:
    if (items != 1) croak("make_closure expects 1 arguments");
    lbp_check_interpreter(aTHX);
    ENTER;
    lpg_scope *scope = lpg_begin(aTHX_ lpg_retire);
    lpc_frame *frame = lpc_begin(aTHX_ scope);
    SV *argument0 = lpg_pin(aTHX_ ST(0));
    
    callbacksubtypes_scalar_nat_t *input0 = lpg_allocate(aTHX_ scope, 1, sizeof(*input0));
    lpg_read3(aTHX_ scope, argument0, input0, 0, 1);
    lpc_lease *created;
    SV *out = lpc_lease_new(aTHX_ scope, 1, callbacksubtypes_callback_c27fa7df7f1805196544d398fb121b21c179beb1_lease_dispose, "LeanBridge::CallbackSubtypes::Closurec27fa7df7f1805196544d398fb121b21c179beb1", &created);
    lbp_check_interpreter(aTHX);
    uint32_t status = lean_bridge_e2d5407c03792441cb368ec1_graph(input0, &created->token);
    lpc_finish(aTHX_ frame, status);
    if (!lpg_ready()) croak("Shared Lean runtime is unavailable");
    
    lbp_check_interpreter(aTHX);
    if (!lpg_ready()) croak("Shared Lean runtime is unavailable");
    /* Guards and errors refer to scope storage, so LEAVE must run them before
       lpg_end frees that storage. */
    LEAVE;
    SPAGAIN; SP -= items; EXTEND(SP, 1); XPUSHs(out);

void
make_container_closure(...)
  PPCODE:
    if (items != 1) croak("make_container_closure expects 1 arguments");
    lbp_check_interpreter(aTHX);
    ENTER;
    lpg_scope *scope = lpg_begin(aTHX_ lpg_retire);
    lpc_frame *frame = lpc_begin(aTHX_ scope);
    SV *argument0 = lpg_pin(aTHX_ ST(0));
    
    callbacksubtypes_scalar_nat_t *input0 = lpg_allocate(aTHX_ scope, 1, sizeof(*input0));
    lpg_read3(aTHX_ scope, argument0, input0, 0, 1);
    lpc_lease *created;
    SV *out = lpc_lease_new(aTHX_ scope, 4, callbacksubtypes_callback_6cdd9c3be7604978d190e4f9d3a70db0539487ba_lease_dispose, "LeanBridge::CallbackSubtypes::Closure6cdd9c3be7604978d190e4f9d3a70db0539487ba", &created);
    lbp_check_interpreter(aTHX);
    uint32_t status = lean_bridge_07d8425a546c7304b285ddcd_graph(input0, &created->token);
    lpc_finish(aTHX_ frame, status);
    if (!lpg_ready()) croak("Shared Lean runtime is unavailable");
    
    lbp_check_interpreter(aTHX);
    if (!lpg_ready()) croak("Shared Lean runtime is unavailable");
    /* Guards and errors refer to scope storage, so LEAVE must run them before
       lpg_end frees that storage. */
    LEAVE;
    SPAGAIN; SP -= items; EXTEND(SP, 1); XPUSHs(out);

void
make_mixed_closure(...)
  PPCODE:
    if (items != 1) croak("make_mixed_closure expects 1 arguments");
    lbp_check_interpreter(aTHX);
    ENTER;
    lpg_scope *scope = lpg_begin(aTHX_ lpg_retire);
    lpc_frame *frame = lpc_begin(aTHX_ scope);
    SV *argument0 = lpg_pin(aTHX_ ST(0));
    
    callbacksubtypes_scalar_nat_t *input0 = lpg_allocate(aTHX_ scope, 1, sizeof(*input0));
    lpg_read3(aTHX_ scope, argument0, input0, 0, 1);
    lpc_lease *created;
    SV *out = lpc_lease_new(aTHX_ scope, 3, callbacksubtypes_callback_51bfd752726fcfd8a9187a7c3a979ace51f7c1be_lease_dispose, "LeanBridge::CallbackSubtypes::Closure51bfd752726fcfd8a9187a7c3a979ace51f7c1be", &created);
    lbp_check_interpreter(aTHX);
    uint32_t status = lean_bridge_36fd9c74c3921bfb2ead3644_graph(input0, &created->token);
    lpc_finish(aTHX_ frame, status);
    if (!lpg_ready()) croak("Shared Lean runtime is unavailable");
    
    lbp_check_interpreter(aTHX);
    if (!lpg_ready()) croak("Shared Lean runtime is unavailable");
    /* Guards and errors refer to scope storage, so LEAVE must run them before
       lpg_end frees that storage. */
    LEAVE;
    SPAGAIN; SP -= items; EXTEND(SP, 1); XPUSHs(out);

MODULE = LeanBridge::CallbackSubtypes PACKAGE = LeanBridge::CallbackSubtypes::Closurec27fa7df7f1805196544d398fb121b21c179beb1
void
call(...)
  PPCODE:
    if (items != 2) croak("call expects 2 arguments");
    lbp_check_interpreter(aTHX);
    ENTER;
    lpg_scope *scope = lpg_begin(aTHX_ lpg_retire);
    lpc_frame *frame = lpc_begin(aTHX_ scope);
    SV *argument0 = lpg_pin(aTHX_ ST(0));
    SV *argument1 = lpg_pin(aTHX_ ST(1));
    lpc_lease *self = lpc_lease_enter(aTHX_ scope, argument0, 1);
    callbacksubtypes_scalar_nat_t *input0 = lpg_allocate(aTHX_ scope, 1, sizeof(*input0));
    lpg_read3(aTHX_ scope, argument1, input0, 0, 1);
    callbacksubtypes_scalar_nat_t *output = lpg_allocate(aTHX_ scope, 1, sizeof(*output));
    scope->output = output; scope->clear = lpc_clear3;
    lbp_check_interpreter(aTHX);
    uint32_t status = callbacksubtypes_callback_c27fa7df7f1805196544d398fb121b21c179beb1_lease_call(self->token, input0, output);
    lpc_finish(aTHX_ frame, status);
    if (!lpg_ready()) croak("Shared Lean runtime is unavailable");
    SV *out = lpg_write3(aTHX_ scope, output, 0, 1);
    lbp_check_interpreter(aTHX);
    if (!lpg_ready()) croak("Shared Lean runtime is unavailable");
    /* Guards and errors refer to scope storage, so LEAVE must run them before
       lpg_end frees that storage. */
    LEAVE;
    SPAGAIN; SP -= items; EXTEND(SP, 1); XPUSHs(out);

MODULE = LeanBridge::CallbackSubtypes PACKAGE = LeanBridge::CallbackSubtypes::Closure51bfd752726fcfd8a9187a7c3a979ace51f7c1be
void
call(...)
  PPCODE:
    if (items != 3) croak("call expects 3 arguments");
    lbp_check_interpreter(aTHX);
    ENTER;
    lpg_scope *scope = lpg_begin(aTHX_ lpg_retire);
    lpc_frame *frame = lpc_begin(aTHX_ scope);
    SV *argument0 = lpg_pin(aTHX_ ST(0));
    SV *argument1 = lpg_pin(aTHX_ ST(1));
    SV *argument2 = lpg_pin(aTHX_ ST(2));
    lpc_lease *self = lpc_lease_enter(aTHX_ scope, argument0, 3);
    callbacksubtypes_scalar_nat_t *input0 = lpg_allocate(aTHX_ scope, 1, sizeof(*input0));
    lpg_read3(aTHX_ scope, argument1, input0, 0, 1);
    callbacksubtypes_scalar_nat_t *input1 = lpg_allocate(aTHX_ scope, 1, sizeof(*input1));
    lpg_read3(aTHX_ scope, argument2, input1, 0, 1);
    callbacksubtypes_scalar_nat_t *output = lpg_allocate(aTHX_ scope, 1, sizeof(*output));
    scope->output = output; scope->clear = lpc_clear3;
    lbp_check_interpreter(aTHX);
    uint32_t status = callbacksubtypes_callback_51bfd752726fcfd8a9187a7c3a979ace51f7c1be_lease_call(self->token, input0, input1, output);
    lpc_finish(aTHX_ frame, status);
    if (!lpg_ready()) croak("Shared Lean runtime is unavailable");
    SV *out = lpg_write3(aTHX_ scope, output, 0, 1);
    lbp_check_interpreter(aTHX);
    if (!lpg_ready()) croak("Shared Lean runtime is unavailable");
    /* Guards and errors refer to scope storage, so LEAVE must run them before
       lpg_end frees that storage. */
    LEAVE;
    SPAGAIN; SP -= items; EXTEND(SP, 1); XPUSHs(out);

MODULE = LeanBridge::CallbackSubtypes PACKAGE = LeanBridge::CallbackSubtypes::Closure6cdd9c3be7604978d190e4f9d3a70db0539487ba
void
call(...)
  PPCODE:
    if (items != 2) croak("call expects 2 arguments");
    lbp_check_interpreter(aTHX);
    ENTER;
    lpg_scope *scope = lpg_begin(aTHX_ lpg_retire);
    lpc_frame *frame = lpc_begin(aTHX_ scope);
    SV *argument0 = lpg_pin(aTHX_ ST(0));
    SV *argument1 = lpg_pin(aTHX_ ST(1));
    lpc_lease *self = lpc_lease_enter(aTHX_ scope, argument0, 4);
    callbacksubtypes_graph_6c9c0cf3d3abf9adeb4b_t *input0 = lpg_allocate(aTHX_ scope, 1, sizeof(*input0));
    lpg_read2(aTHX_ scope, argument1, input0, 0, 1);
    callbacksubtypes_graph_743764d1b67e81fcae92_t *output = lpg_allocate(aTHX_ scope, 1, sizeof(*output));
    scope->output = output; scope->clear = lpc_clear0;
    lbp_check_interpreter(aTHX);
    uint32_t status = callbacksubtypes_callback_6cdd9c3be7604978d190e4f9d3a70db0539487ba_lease_call(self->token, input0, output);
    lpc_finish(aTHX_ frame, status);
    if (!lpg_ready()) croak("Shared Lean runtime is unavailable");
    SV *out = lpg_write0(aTHX_ scope, output, 0, 1);
    lbp_check_interpreter(aTHX);
    if (!lpg_ready()) croak("Shared Lean runtime is unavailable");
    /* Guards and errors refer to scope storage, so LEAVE must run them before
       lpg_end frees that storage. */
    LEAVE;
    SPAGAIN; SP -= items; EXTEND(SP, 1); XPUSHs(out);

MODULE = LeanBridge::CallbackSubtypes PACKAGE = LeanBridge::CallbackSubtypes::LeanClosure

void
close(value)
    SV *value
  PPCODE:
    lpc_lease *lease = lpc_get_lease(aTHX_ value);
    lease->closed = 1; lpc_lease_drop(lease);
    XSRETURN_EMPTY;

void
closed(value)
    SV *value
  PPCODE:
    XPUSHs(boolSV(lpc_get_lease(aTHX_ value)->closed));

BOOT:
  lbp_check_interpreter(aTHX);
