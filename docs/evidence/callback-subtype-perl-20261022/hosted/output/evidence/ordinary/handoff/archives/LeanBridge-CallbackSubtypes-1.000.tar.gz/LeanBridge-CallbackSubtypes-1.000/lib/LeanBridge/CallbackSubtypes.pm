package LeanBridge::CallbackSubtypes;
use strict;
use warnings;
use Math::BigInt;
# Finite declarations only. Conversion performs payload validation at calls.

sub true () { !!1 }
sub false () { !!0 }
package LeanBridge::CallbackSubtypes::Some;
sub new {
  CORE::die "Some->new expects one payload\n" unless @_ == 2 && CORE::defined($_[0]) && !CORE::ref($_[0]) && $_[0] eq 'LeanBridge::CallbackSubtypes::Some';
  return CORE::bless {value => $_[1]}, 'LeanBridge::CallbackSubtypes::Some';
}
sub value { $_[0]->{value} }

package LeanBridge::CallbackSubtypes::Ok;
sub new {
  CORE::die "Ok->new expects one payload\n" unless @_ == 2 && CORE::defined($_[0]) && !CORE::ref($_[0]) && $_[0] eq 'LeanBridge::CallbackSubtypes::Ok';
  return CORE::bless {value => $_[1]}, 'LeanBridge::CallbackSubtypes::Ok';
}
sub value { $_[0]->{value} }

package LeanBridge::CallbackSubtypes::Err;
sub new {
  CORE::die "Err->new expects one payload\n" unless @_ == 2 && CORE::defined($_[0]) && !CORE::ref($_[0]) && $_[0] eq 'LeanBridge::CallbackSubtypes::Err';
  return CORE::bless {value => $_[1]}, 'LeanBridge::CallbackSubtypes::Err';
}
sub value { $_[0]->{value} }


1;

package LeanBridge::CallbackSubtypes::Runtime::Callback;
sub new {
  CORE::die "LeanBridge::CallbackSubtypes::Runtime::Callback->new expects code and recovery\n"
    unless @_ == 5 && CORE::defined($_[0]) && !CORE::ref($_[0]) && $_[0] eq 'LeanBridge::CallbackSubtypes::Runtime::Callback';
  CORE::shift; my %fields = @_;
  CORE::die "expected code and recovery fields\n"
    unless CORE::keys(%fields) == 2 && CORE::exists($fields{code}) && CORE::exists($fields{recovery});
  CORE::die "expected a Perl code reference\n" unless CORE::ref($fields{code}) eq 'CODE';
  return CORE::bless \%fields, 'LeanBridge::CallbackSubtypes::Runtime::Callback';
}

package LeanBridge::CallbackSubtypes::LeanClosure;
sub new { CORE::die "Use a generated Lean closure factory\n" }
sub CLONE_SKIP { 1 }
sub STORABLE_freeze { CORE::die "Lean closures cannot be serialized\n" }
sub STORABLE_thaw { CORE::die "Lean closures cannot be deserialized\n" }
package LeanBridge::CallbackSubtypes::Closurec27fa7df7f1805196544d398fb121b21c179beb1;
our @ISA = ('LeanBridge::CallbackSubtypes::LeanClosure');
sub CLONE_SKIP { 1 }

package LeanBridge::CallbackSubtypes::Closure51bfd752726fcfd8a9187a7c3a979ace51f7c1be;
our @ISA = ('LeanBridge::CallbackSubtypes::LeanClosure');
sub CLONE_SKIP { 1 }

package LeanBridge::CallbackSubtypes::Closure6cdd9c3be7604978d190e4f9d3a70db0539487ba;
our @ISA = ('LeanBridge::CallbackSubtypes::LeanClosure');
sub CLONE_SKIP { 1 }

1;

package LeanBridge::CallbackSubtypes;
use LeanBridge::Runtime;
die "Incompatible shared Lean runtime package version\n" unless $LeanBridge::Runtime::VERSION eq '0.0020130180835253351074425099676719723942806298898514237203907626409680523998624031';
use XSLoader;
our $VERSION = '1.000';
LeanBridge::Runtime::_load_component(__FILE__, 'libcomponent_730462696d8af341b48a.so', '839154183007ffb79cbb7071ba40955d9fb28103f2c1d778d7e5744b713275e4', '6f4dbd1e2e112f4678734553d1c9bb8722fad3e6290adbff1ac46d05e5eff7dd', { 'CallbackSubtypes' => '4eef12901f9b50dbecd449a8f03c112a5e9977618093637cb9e2a22fee7359f6' }, 'callbacksubtypes@1.0.0');
XSLoader::load(__PACKAGE__, $VERSION);
sub CLONE_SKIP { 1 }
1;

__END__
=head1 NAME

LeanBridge::CallbackSubtypes - Generated recursive values and synchronous Lean callbacks

=head1 API

=head2 call_host

Calls C<CallbackSubtypes.callHost> in the compiled Lean component.

=head2 call_host_container

Calls C<CallbackSubtypes.callHostContainer> in the compiled Lean component.

=head2 call_host_mixed

Calls C<CallbackSubtypes.callHostMixed> in the compiled Lean component.

=head2 make_closure

Calls C<CallbackSubtypes.makeClosure> in the compiled Lean component.

=head2 make_container_closure

Calls C<CallbackSubtypes.makeContainerClosure> in the compiled Lean component.

=head2 make_mixed_closure

Calls C<CallbackSubtypes.makeMixedClosure> in the compiled Lean component.

=head1 VALUES

Records and variants use generated named-field classes. Arrays, Lists and
products use plain array references. None and Unit use undef; Some->new(undef)
keeps optional Unit distinct from None. Ok and Err retain result branches.
Nat and Int use Math::BigInt. Strings retain Unicode and NUL; ByteArray uses
octets. Aliases keep their copied target representation.

Calls check exact classes, fields and scalar representations, and reject
cycles, sparse arrays and tied containers. Callback arguments and results,
returned captures and ordinary results own independent copied storage.

=head1 CALLBACKS AND OWNERSHIP

Pass a CODE reference or a matching generated Lean closure as a synchronous
callback. A host callback whose result contains a checked Lean Subtype or checked record must use
C<LeanBridge::CallbackSubtypes::Runtime::Callback-E<gt>new(code =E<gt> $callback, recovery =E<gt> $value)>.
The recovery has the callback's declared erased result shape, a generated
record carrying only payload fields for a checked record, and is validated
before Lean or the callback runs. Lean applies the selected constructor to the
callback's actual reply, nested checked fields before their record.
Constructor rejection or a callback exception fails the enclosing call; the
recovery is used only to finish Lean's failure path and is never returned as a
successful result. A returned Lean closure constructs its checked record
arguments the same way before its body runs and projects a checked record
result without proof fields. Returned Lean closures provide call, close and closed. Close each
closure when finished. Close is idempotent and an active call retains its
borrow until native cleanup finishes. Automatic finalization also releases
the native lease. Closures cannot be serialized or used by another interpreter
or process. Host callbacks must not escape their initiating native call.

Perl callback exceptions retain their identity and are rethrown after native
cleanup. Reply buffers remain allocated until Lean copies them. Malformed
native results retire the shared runtime; input, callback and limit failures
leave it usable. Libraries remain loaded until process exit.

=head1 LIMITS

Conversions share a depth limit of 128, 262,144 nodes, a 16 MiB native-copy
budget and a separate 16 MiB conversion-storage budget. Reentry is limited to
64 native calls and the component supports up to 4,096 live closure leases.
These limits do not bound Lean working memory or all Perl allocator overhead.
Resource-containing copied values and asynchronous callbacks remain unsupported.

=cut
