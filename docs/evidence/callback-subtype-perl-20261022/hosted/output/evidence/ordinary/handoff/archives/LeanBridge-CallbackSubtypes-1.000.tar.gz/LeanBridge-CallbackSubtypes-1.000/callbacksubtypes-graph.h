#pragma once
#include "callbacksubtypes-callable-borrows.h"
#ifdef __cplusplus
extern "C" {
#endif
const char *callbacksubtypes_callable_graph_error(void);
__attribute__((visibility("hidden"))) uint32_t lean_bridge_23220a30761b2d3716c5b4ed_graph(const callbacksubtypes_callback_6bc98ee774b20d3238b9e42a92309a51ce9dad0a *a0, callbacksubtypes_scalar_nat_t *out);
__attribute__((visibility("hidden"))) uint32_t lean_bridge_8ffe188578f9a7b74003cf3c_graph(const callbacksubtypes_callback_14cd8f1b0d065ede9a36f8590000c62c12d8e99c *a0, callbacksubtypes_graph_2c6f4131c8731fa67588_t *out);
__attribute__((visibility("hidden"))) uint32_t lean_bridge_4f106adfac5064464a2a8e3f_graph(const callbacksubtypes_callback_197d5bf19058d37bc5547c33a8e0bed3bf121ea7 *a0, callbacksubtypes_scalar_nat_t *out);
__attribute__((visibility("hidden"))) uint32_t lean_bridge_e2d5407c03792441cb368ec1_graph(const callbacksubtypes_scalar_nat_t *a0, uint64_t *out);
__attribute__((visibility("hidden"))) uint32_t lean_bridge_07d8425a546c7304b285ddcd_graph(const callbacksubtypes_scalar_nat_t *a0, uint64_t *out);
__attribute__((visibility("hidden"))) uint32_t lean_bridge_36fd9c74c3921bfb2ead3644_graph(const callbacksubtypes_scalar_nat_t *a0, uint64_t *out);
__attribute__((visibility("hidden"))) uint32_t callbacksubtypes_callback_c27fa7df7f1805196544d398fb121b21c179beb1_lease_call(uint64_t self, const callbacksubtypes_scalar_nat_t *a0, callbacksubtypes_scalar_nat_t *out);
__attribute__((visibility("hidden"))) void callbacksubtypes_callback_c27fa7df7f1805196544d398fb121b21c179beb1_lease_dispose(uint64_t token);
__attribute__((visibility("hidden"))) uint32_t callbacksubtypes_callback_51bfd752726fcfd8a9187a7c3a979ace51f7c1be_lease_call(uint64_t self, const callbacksubtypes_scalar_nat_t *a0, const callbacksubtypes_scalar_nat_t *a1, callbacksubtypes_scalar_nat_t *out);
__attribute__((visibility("hidden"))) void callbacksubtypes_callback_51bfd752726fcfd8a9187a7c3a979ace51f7c1be_lease_dispose(uint64_t token);
__attribute__((visibility("hidden"))) uint32_t callbacksubtypes_callback_6cdd9c3be7604978d190e4f9d3a70db0539487ba_lease_call(uint64_t self, const callbacksubtypes_graph_6c9c0cf3d3abf9adeb4b_t *a0, callbacksubtypes_graph_743764d1b67e81fcae92_t *out);
__attribute__((visibility("hidden"))) void callbacksubtypes_callback_6cdd9c3be7604978d190e4f9d3a70db0539487ba_lease_dispose(uint64_t token);
#ifdef __cplusplus
}
#endif
