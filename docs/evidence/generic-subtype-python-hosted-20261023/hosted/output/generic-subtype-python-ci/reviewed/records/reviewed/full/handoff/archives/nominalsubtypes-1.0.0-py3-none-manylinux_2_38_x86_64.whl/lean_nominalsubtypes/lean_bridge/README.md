# lean_nominalsubtypes

Install the prepared platform wheel and import lean_nominalsubtypes. Native Lean libraries and runtime loading are included. No Lean compiler or extension build is needed by consumers. Python 3.11+, Linux x86-64 with glibc matching the wheel tag.

Unit is None in every position. Fixed-width integers are range checked; Nat and Int use exact Python integers. Boolean and numeric coercions are rejected. Float32 rounds a Python float to binary32, preserving NaN classification, infinities and signed zero. String is strict Unicode str, including NUL; ByteArray is bytes. Arrays accept tuples or lists and return tuples. Records are frozen dataclasses; nested copied values remain independent.

Types must be pure, acyclic and at most 32 levels deep. Python conversions and native input/output copies each have a 16 MiB budget. Python array conversions count at least eight bytes per element, and strings account for encoding/decoding. These limits do not bound the Lean algorithm's working memory. Native outputs are cleared in finally even if conversion raises. Calls can run on separate threads with independent scratch; do not mutate an input during its conversion. Compatible packages share a synchronized loader and native runtime. Free-threading and post-fork calls are rejected; subinterpreters and other Python implementations have not been accepted.

- lean_nominalsubtypes.echo_generic_first: lean:NominalSubtypes.GenericCompositions.echoGenericFirst
- lean_nominalsubtypes.echo_generic_second: lean:NominalSubtypes.GenericCompositions.echoGenericSecond
- lean_nominalsubtypes.generic_use: lean:NominalSubtypes.GenericCompositions.genericUse
- lean_nominalsubtypes.aliases: lean:NominalSubtypes.aliases
- lean_nominalsubtypes.array_values: lean:NominalSubtypes.arrayValues
- lean_nominalsubtypes.branch: lean:NominalSubtypes.branch
- lean_nominalsubtypes.combine: lean:NominalSubtypes.combine
- lean_nominalsubtypes.echo: lean:NominalSubtypes.echo
- lean_nominalsubtypes.echo_event: lean:NominalSubtypes.echoEvent
- lean_nominalsubtypes.echo_groups: lean:NominalSubtypes.echoGroups
- lean_nominalsubtypes.echo_pair: lean:NominalSubtypes.echoPair
- lean_nominalsubtypes.event_choices: lean:NominalSubtypes.eventChoices
- lean_nominalsubtypes.event_empty: lean:NominalSubtypes.eventEmpty
- lean_nominalsubtypes.event_first: lean:NominalSubtypes.eventFirst
- lean_nominalsubtypes.event_second: lean:NominalSubtypes.eventSecond
- lean_nominalsubtypes.event_value: lean:NominalSubtypes.eventValue
- lean_nominalsubtypes.first: lean:NominalSubtypes.first
- lean_nominalsubtypes.group_values: lean:NominalSubtypes.groupValues
- lean_nominalsubtypes.inspect_alias_pair: lean:NominalSubtypes.inspectAliasPair
- lean_nominalsubtypes.list_values: lean:NominalSubtypes.listValues
- lean_nominalsubtypes.nested: lean:NominalSubtypes.nested
- lean_nominalsubtypes.no_items: lean:NominalSubtypes.noItems
- lean_nominalsubtypes.optional: lean:NominalSubtypes.optional
- lean_nominalsubtypes.pair_values: lean:NominalSubtypes.pairValues
- lean_nominalsubtypes.plain_fin: lean:NominalSubtypes.plainFin
- lean_nominalsubtypes.produce_envelope: lean:NominalSubtypes.produceEnvelope
- lean_nominalsubtypes.product: lean:NominalSubtypes.product
- lean_nominalsubtypes.scalar: lean:NominalSubtypes.scalar
- lean_nominalsubtypes.second: lean:NominalSubtypes.second

Lean Fin n parameters and results are exact Python int values below n. The bundled native library compares each argument with its exact bound, including bounds wider than 64 bits, before any Lean code runs. A Boolean or other non-int argument raises TypeError and a negative int raises ValueError, as for Nat; an int at or above its bound raises LeanBridgeError with status 1, naming the parameter and bound. Fin 0 has no values, so every call to a function taking one is rejected. Results are int values below their declared bound. Fin inside arrays, lists, options, products, Except values, records and variants is checked before Lean runs: every array or list element, a present option value, both product components, only the active Except branch, every record field and only the fields of the active variant case. An empty array, an absent option or an inactive branch or case is valid even for Fin 0. Bounds below list every element as name[*], a present option value as name?, product components as name.0 and name.1, the active branch as name.ok or name.error, a record field as name.field and a field of the active variant case as name.Case.field. Fin inside callbacks or generic record instantiations is not supported in Python packages.


Lean Subtype parameters cross as their base value. The bundled native library runs the author's checked constructor, named below, before the export runs; a value the constructor rejects fails the call with the invalid-argument error naming the parameter and constructor, and the export receives the constructed value, which may differ from the input. Arrays, Lists, options, products and active result branches apply the same constructor checks to each Subtype leaf. Rejections identify the argument and nested element path. Subtype results are the base value. Reviewed APIs select the constructor and reconcile it with fresh Lean compilation. Copied plain records check each selected field; variants check only the active case. Repeated uses of one type retain their own constructor choices, and every Fin bound is checked before any constructor. Recursive, generic, owned and callback Subtype positions remain unsupported.
- lean_nominalsubtypes.echo_generic_first: value0.value checked by NominalSubtypes.plusOne; result.value projects the Subtype base value
- lean_nominalsubtypes.echo_generic_second: value0.value checked by NominalSubtypes.plusTwo; result.value projects the Subtype base value
- lean_nominalsubtypes.generic_use: value0.value checked by NominalSubtypes.plusOne
- lean_nominalsubtypes.aliases: value0[*]?.payload checked by NominalSubtypes.plusOne; value0[*]?.digit < 3; value1[*]?.payload checked by NominalSubtypes.plusTwo; value1[*]?.digit < 3
- lean_nominalsubtypes.array_values: result[*] projects the Subtype base value
- lean_nominalsubtypes.branch: result.ok projects the Subtype base value; result.error projects the Subtype base value
- lean_nominalsubtypes.combine: value0.payload checked by NominalSubtypes.plusOne; value0.digit < 3; value1.payload checked by NominalSubtypes.plusTwo; value1.digit < 3
- lean_nominalsubtypes.echo: value0.payload checked by NominalSubtypes.plusOne; value0.digit < 3; result.payload projects the Subtype base value; result.digit < 3
- lean_nominalsubtypes.echo_event: value0.box.value.payload checked by NominalSubtypes.plusOne; value0.box.value.digit < 3; value0.choices.values[*]?.ok checked by NominalSubtypes.plusOne; value0.choices.values[*]?.error checked by NominalSubtypes.plusTwo; result.box.value.payload projects the Subtype base value; result.box.value.digit < 3; result.choices.values[*]?.ok projects the Subtype base value; result.choices.values[*]?.error projects the Subtype base value
- lean_nominalsubtypes.echo_groups: value0[*]?.payload checked by NominalSubtypes.plusOne; value0[*]?.digit < 3; result[*]?.payload projects the Subtype base value; result[*]?.digit < 3
- lean_nominalsubtypes.echo_pair: value0.left[*]?.payload checked by NominalSubtypes.plusOne; value0.left[*]?.digit < 3; value0.right[*]?.payload checked by NominalSubtypes.plusTwo; value0.right[*]?.digit < 3; result.left[*]?.payload projects the Subtype base value; result.left[*]?.digit < 3; result.right[*]?.payload projects the Subtype base value; result.right[*]?.digit < 3
- lean_nominalsubtypes.event_choices: result.box.value.payload projects the Subtype base value; result.box.value.digit < 3; result.choices.values[*]?.ok projects the Subtype base value; result.choices.values[*]?.error projects the Subtype base value
- lean_nominalsubtypes.event_empty: result.box.value.payload projects the Subtype base value; result.box.value.digit < 3; result.choices.values[*]?.ok projects the Subtype base value; result.choices.values[*]?.error projects the Subtype base value
- lean_nominalsubtypes.event_first: value0.box.value.payload checked by NominalSubtypes.plusOne; value0.box.value.digit < 3; value0.choices.values[*]?.ok checked by NominalSubtypes.plusOne; value0.choices.values[*]?.error checked by NominalSubtypes.plusTwo
- lean_nominalsubtypes.event_second: value0.box.value.payload checked by NominalSubtypes.plusTwo; value0.box.value.digit < 3; value0.choices.values[*]?.ok checked by NominalSubtypes.plusTwo; value0.choices.values[*]?.error checked by NominalSubtypes.plusOne
- lean_nominalsubtypes.event_value: result.box.value.payload projects the Subtype base value; result.box.value.digit < 3; result.choices.values[*]?.ok projects the Subtype base value; result.choices.values[*]?.error projects the Subtype base value
- lean_nominalsubtypes.first: value0.payload checked by NominalSubtypes.plusOne; value0.digit < 3
- lean_nominalsubtypes.group_values: result[*]?.payload projects the Subtype base value; result[*]?.digit < 3
- lean_nominalsubtypes.inspect_alias_pair: value0.left[*]?.payload checked by NominalSubtypes.plusOne; value0.left[*]?.digit < 3; value0.right[*]?.payload checked by NominalSubtypes.plusTwo; value0.right[*]?.digit < 3
- lean_nominalsubtypes.list_values: result[*] projects the Subtype base value
- lean_nominalsubtypes.nested: value0.left.payload checked by NominalSubtypes.plusOne; value0.left.digit < 3; value0.right.payload checked by NominalSubtypes.plusTwo; value0.right.digit < 3
- lean_nominalsubtypes.no_items: result[*] projects the Subtype base value
- lean_nominalsubtypes.optional: result? projects the Subtype base value
- lean_nominalsubtypes.pair_values: result.left[*]?.payload projects the Subtype base value; result.left[*]?.digit < 3; result.right[*]?.payload projects the Subtype base value; result.right[*]?.digit < 3
- lean_nominalsubtypes.plain_fin: value0 < 3
- lean_nominalsubtypes.produce_envelope: result.payload projects the Subtype base value; result.digit < 3
- lean_nominalsubtypes.product: result.0 projects the Subtype base value; result.1 projects the Subtype base value
- lean_nominalsubtypes.scalar: result projects the Subtype base value
- lean_nominalsubtypes.second: value0.payload checked by NominalSubtypes.plusTwo; value0.digit < 3

Option[T] is None or Some(value). Some(None) preserves a present Unit or absent inner Option; nested options retain every layer. Result[T, E] is Ok(value) or Err(value), including when both payload types match. These generated wrappers are frozen dataclasses with a value field. Domain errors return Err, not exceptions. Binary products use exact two-element tuples and retain their nesting. Copies can contain these types, arrays and records; resources and callbacks cannot be hidden in them.

Synchronous primitive host callbacks accept typed Python callables. Returned Lean closures are callable LeanClosure values: use a with block or close(), and invoke them on their creating thread. close() is idempotent and defers disposal during active reentry. Garbage collection is a fallback. Callback exceptions return as the original Python exception after native cleanup; later invocations in that call are suppressed. Callback values use the same checked primitive conversions and share the call's copy budgets. Host callbacks are borrowed only for the exporting call. Async or retained host callbacks, callable containers, resources and other effects are not enabled by this adapter.

Lean List values accept exact Python lists or tuples and return independent tuples, including nested copied values. Order, duplicates and empty Lists are preserved. List and Array retain distinct contract identities. List callback payloads remain unsupported.

Copied Lean variants export one frozen, slotted dataclass per constructor, with the variant name as a type union. Construct named cases and use isinstance or structural pattern matching to inspect them. The class-level kind string retains the Lean constructor name; conversion selects the constructor by its exact generated class, never by a supplied numeric tag or arbitrary kind attribute. Payload fields use snake_case, with reserved names gaining a trailing underscore. Only the active case is converted. Empty constructors and Unit payloads stay distinct. Results own independent copied storage. Variant payloads may contain supported copied records and containers; recursive, callable and identity-bearing payloads remain unsupported.

Concrete copied Lean aliases export named Python TypeAlias declarations in both the module and its type stub. Aliases reuse their target values and validation without NewType wrappers. Aliased arrays and Lists retain tuple-or-list inputs and return independent tuples. Aliased records remain the same frozen dataclass. An alias of Nat still rejects negative input. Recursive and identity-bearing alias targets, and compound callable payloads remain unsupported.
