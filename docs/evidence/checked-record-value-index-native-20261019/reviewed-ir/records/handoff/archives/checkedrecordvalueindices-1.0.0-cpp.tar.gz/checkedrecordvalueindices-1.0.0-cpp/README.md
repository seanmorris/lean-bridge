# checkedrecordvalueindices 1.0.0

Compiled C++20 and C11 API from checkedrecordvalueindices@1.0.0. Linux x86-64, glibc 2.38 or newer. Lean is not required by consumers. The shared native runtime is included in lib/ and loads automatically.

Include checkedrecordvalueindices.hpp. Use pkg-config package checkedrecordvalueindices, or find_package(LeanBridgeCheckedrecordvalueindices CONFIG REQUIRED) and link LeanBridge::checkedrecordvalueindices. C++ functions live in lean_bridge::checkedrecordvalueindices.

C inputs borrow caller buffers for one call. Initialize C result structs to zero and call the matching checkedrecordvalueindices_TYPE_clear function after use, before reusing a result slot. Clear is idempotent. C++ results own their memory and release C buffers automatically, including when a C++ allocation throws.

Strings are length-delimited UTF-8, including embedded NUL. Byte arrays are uninterpreted bytes. Nat and Int are Boost.Multiprecision cpp_int values. Negative Nat inputs reject. Packages using these types include Boost 1.90.0 standalone headers, license and source hashes; CMake and pkg-config configure them automatically. Unit parameters are zero in C and std::monostate in C++; Unit results have no output. Fixed-width integers use exact-width host types; floating-point values retain IEEE special values. Input and output copies share a 16 MiB per-call budget. Invalid input leaves the output unchanged and returns a status (C) or throws Error (C++).

Arrays and acyclic records can nest up to 32 types deep. C spans own their nested elements through their release callback; record clear functions clear their fields. Do not shallow-copy an owned result and clear both copies. C++ uses owned vectors and structs, with scoped input views. The 16 MiB conversion budget includes input and output payloads, array slots (at least pointer-sized), output ownership headers and record storage; it does not bound the Lean algorithm's working memory.

- checkedrecordvalueindices_ab_string_index: lean:CheckedRecordValueIndices.abStringIndex
- checkedrecordvalueindices_empty_sized_index: lean:CheckedRecordValueIndices.emptySizedIndex
- checkedrecordvalueindices_empty_string_index: lean:CheckedRecordValueIndices.emptyStringIndex
- checkedrecordvalueindices_false_bool_index: lean:CheckedRecordValueIndices.falseBoolIndex
- checkedrecordvalueindices_produce_ab: lean:CheckedRecordValueIndices.produceAb
- checkedrecordvalueindices_produce_empty_sized: lean:CheckedRecordValueIndices.produceEmptySized
- checkedrecordvalueindices_produce_empty_string: lean:CheckedRecordValueIndices.produceEmptyString
- checkedrecordvalueindices_produce_false_bool: lean:CheckedRecordValueIndices.produceFalseBool
- checkedrecordvalueindices_produce_true_bool: lean:CheckedRecordValueIndices.produceTrueBool
- checkedrecordvalueindices_produce_unicode_string: lean:CheckedRecordValueIndices.produceUnicodeString
- checkedrecordvalueindices_produce_wide_nat: lean:CheckedRecordValueIndices.produceWideNat
- checkedrecordvalueindices_produce_zero_nat: lean:CheckedRecordValueIndices.produceZeroNat
- checkedrecordvalueindices_true_bool_index: lean:CheckedRecordValueIndices.trueBoolIndex
- checkedrecordvalueindices_unicode_string_index: lean:CheckedRecordValueIndices.unicodeStringIndex
- checkedrecordvalueindices_wide_nat_index: lean:CheckedRecordValueIndices.wideNatIndex
- checkedrecordvalueindices_zero_nat_index: lean:CheckedRecordValueIndices.zeroNatIndex
