# checkedrecordvalueindices 1.0.0

Compiled C11 API from checkedrecordvalueindices@1.0.0. Linux x86-64, glibc 2.38 or newer. Lean is not required by consumers. The shared native runtime is included in lib/ and loads automatically.

Include checkedrecordvalueindices.h. Use pkg-config package checkedrecordvalueindices, or find_package(LeanBridgeCheckedrecordvalueindices CONFIG REQUIRED) and link LeanBridge::checkedrecordvalueindices. C++ functions live in lean_bridge::checkedrecordvalueindices.

C inputs borrow caller buffers for one call. Initialize Nat/Int with mpz_init and aggregate structs with checkedrecordvalueindices_TYPE_init before first use. Never initialize an mpz_t with a shallow struct copy. Nat/Int inputs are borrowed mpz_srcptr values; outputs are initialized mpz_ptr values. Successful calls replace initialized copied outputs; failures leave them unchanged. Clear structs with checkedrecordvalueindices_TYPE_clear. Clear resets their fields to initialized empty values and is idempotent. Finish standalone integers with mpz_clear. GMP callback inputs are borrowed read-only values; callback output integers are already initialized, so assign with mpz_set, not mpz_init. Do not clear callback integer arguments or outputs. C++ results own their memory and release C buffers automatically, including when a C++ allocation throws.

Strings are length-delimited UTF-8, including embedded NUL. Byte arrays are uninterpreted bytes. Nat and Int are GMP mpz_t values. Negative Nat inputs reject. GMP 6.3.0 headers and a replaceable shared library ship in the archive and link automatically through CMake or pkg-config. Its complete corresponding source, build settings and LGPL/GPL notices are under share/lean-bridge/. GMP allocation failures abort by default; the bridge does not replace GMP allocation hooks. Unit parameters are zero in C and std::monostate in C++; Unit results have no output. Fixed-width integers use exact-width host types; floating-point values retain IEEE special values. Input and output copies share a 16 MiB per-call budget. Invalid input leaves the output unchanged and returns a status (C) or throws Error (C++).

Arrays and acyclic records can nest up to 32 types deep. C spans own their nested elements through their release callback; record clear functions clear their fields. Do not shallow-copy an owned result and clear both copies. C++ uses owned vectors and structs, with scoped input views. The 16 MiB conversion budget includes input and output payloads, array slots (at least pointer-sized), output ownership headers and record storage; it does not bound the Lean algorithm's working memory.

- checkedrecordvalueindices_produce_ab: lean:CheckedRecordValueIndices.produceAb
- checkedrecordvalueindices_produce_empty_sized: lean:CheckedRecordValueIndices.produceEmptySized
- checkedrecordvalueindices_produce_empty_string: lean:CheckedRecordValueIndices.produceEmptyString
- checkedrecordvalueindices_produce_false_bool: lean:CheckedRecordValueIndices.produceFalseBool
- checkedrecordvalueindices_produce_true_bool: lean:CheckedRecordValueIndices.produceTrueBool
- checkedrecordvalueindices_produce_unicode_string: lean:CheckedRecordValueIndices.produceUnicodeString
- checkedrecordvalueindices_produce_wide_nat: lean:CheckedRecordValueIndices.produceWideNat
- checkedrecordvalueindices_produce_zero_nat: lean:CheckedRecordValueIndices.produceZeroNat
