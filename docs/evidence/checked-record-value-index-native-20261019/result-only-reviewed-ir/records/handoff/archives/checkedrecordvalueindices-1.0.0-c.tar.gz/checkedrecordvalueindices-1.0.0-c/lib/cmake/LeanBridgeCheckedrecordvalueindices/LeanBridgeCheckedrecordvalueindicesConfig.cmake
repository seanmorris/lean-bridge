get_filename_component(_LB_PREFIX "${CMAKE_CURRENT_LIST_DIR}/../../.." ABSOLUTE)
if(NOT TARGET LeanBridge::checkedrecordvalueindices)
  add_library(LeanBridge::checkedrecordvalueindices SHARED IMPORTED)
  set_target_properties(LeanBridge::checkedrecordvalueindices PROPERTIES
    IMPORTED_LOCATION "${_LB_PREFIX}/lib/libcheckedrecordvalueindices_gmp.so"
    INTERFACE_INCLUDE_DIRECTORIES "${_LB_PREFIX}/include"
    INTERFACE_COMPILE_FEATURES "c_std_11"
    INTERFACE_LINK_LIBRARIES "${_LB_PREFIX}/lib/libgmp.so.10"
  )
endif()
unset(_LB_PREFIX)
