#pragma once
#include "checkedrecordvalueindices.h"
#include <stdexcept>
#include <memory>
#include <string>
#include <variant>
#include <optional>
#include <vector>
#include <utility>

#ifndef BOOST_MP_STANDALONE
#define BOOST_MP_STANDALONE
#endif
#include <boost/multiprecision/cpp_int.hpp>

namespace lean_bridge::checkedrecordvalueindices {

using Nat = boost::multiprecision::cpp_int;
using Int = boost::multiprecision::cpp_int;
struct Ab {
  Nat size{};
  friend bool operator==(const Ab&, const Ab&) = default;
};
struct EmptySized {
  std::vector<Nat> data{};
  friend bool operator==(const EmptySized&, const EmptySized&) = default;
};
struct EmptyToken {
  Nat count{};
  friend bool operator==(const EmptyToken&, const EmptyToken&) = default;
};
struct Off {
  Nat count{};
  friend bool operator==(const Off&, const Off&) = default;
};
struct On {
  Nat count{};
  friend bool operator==(const On&, const On&) = default;
};
struct UnicodeToken {
  Nat count{};
  friend bool operator==(const UnicodeToken&, const UnicodeToken&) = default;
};
struct WideToken {
  Nat count{};
  friend bool operator==(const WideToken&, const WideToken&) = default;
};
struct ZeroToken {
  Nat count{};
  friend bool operator==(const ZeroToken&, const ZeroToken&) = default;
};
class Error final : public std::runtime_error {
public:
  checkedrecordvalueindices_status status;
  checkedrecordvalueindices_error_code code;
  Error(checkedrecordvalueindices_status value, const checkedrecordvalueindices_error& error)
    : std::runtime_error(error.message ? std::string(error.message, error.message_length) : "Lean call failed"), status(value), code(error.code) {}
};
namespace detail {
[[noreturn]] inline void invalid(const char* message) {
  const checkedrecordvalueindices_error error{CHECKEDRECORDVALUEINDICES_ERROR_INVALID_ARGUMENT, message, std::char_traits<char>::length(message)};
  throw Error(CHECKEDRECORDVALUEINDICES_STATUS_INVALID_ARGUMENT, error);
}
inline void charge(size_t& budget, size_t count, size_t width) {
  if (count > budget / width) {
    const checkedrecordvalueindices_error error{CHECKEDRECORDVALUEINDICES_ERROR_INVALID_ARGUMENT, "16 MiB call limit exceeded", 26};
    throw Error(CHECKEDRECORDVALUEINDICES_STATUS_INVALID_ARGUMENT, error);
  }
  budget -= count * width;
}
inline void check0(const Nat& source, size_t& budget) {
  (void)source; (void)budget;
  if (source < 0) invalid("Nat must be nonnegative");
  charge(budget, source == 0 ? 0 : (boost::multiprecision::msb(source < 0 ? -source : source) / 32 + 1), sizeof(uint32_t));
}
struct View0 {
  std::vector<uint32_t> limbs;
  checkedrecordvalueindices_nat value{};
  explicit View0(const Nat& source) {
    (void)source;
    if (source != 0) boost::multiprecision::export_bits(source, std::back_inserter(limbs), 32, false);
    value = checkedrecordvalueindices_nat{limbs.data(), limbs.size(), nullptr, nullptr};
  }
};
inline Nat from0(const checkedrecordvalueindices_nat& source) {
  (void)source;
  Nat result = 0;
  if (source.length) boost::multiprecision::import_bits(result, source.data, source.data + source.length, 32, false);
  return result;
}

inline void check1(const Ab& source, size_t& budget) {
  (void)source; (void)budget;
  charge(budget, 1, sizeof(checkedrecordvalueindices_ab));
  check0(source.size, budget);
}
struct View1 {
  View0 field0;
  checkedrecordvalueindices_ab value{};
  explicit View1(const Ab& source) : field0(source.size) {
    (void)source;
    value = checkedrecordvalueindices_ab{field0.value};
  }
};
inline Ab from1(const checkedrecordvalueindices_ab& source) {
  (void)source;
  return Ab{from0(source.size)};
}

inline void check2(const std::vector<Nat>& source, size_t& budget) {
  (void)source; (void)budget;
  charge(budget, source.size(), sizeof(checkedrecordvalueindices_nat) > sizeof(void*) ? sizeof(checkedrecordvalueindices_nat) : sizeof(void*));
  for (const auto& item : source) check0(item, budget);
}
struct View2 {
  std::vector<View0> items;
  std::unique_ptr<checkedrecordvalueindices_nat[]> values;
  checkedrecordvalueindices_array_nat_span value{};
  explicit View2(const std::vector<Nat>& source) {
    (void)source;
    items.reserve(source.size()); values = std::make_unique<checkedrecordvalueindices_nat[]>(source.size());
    for (const auto& item : source) items.emplace_back(item);
    for (size_t i = 0; i < source.size(); ++i) values[i] = items[i].value;
    value = checkedrecordvalueindices_array_nat_span{values.get(), source.size(), nullptr, nullptr};
  }
};
inline std::vector<Nat> from2(const checkedrecordvalueindices_array_nat_span& source) {
  (void)source;
  std::vector<Nat> result; result.reserve(source.length);
  for (size_t i = 0; i < source.length; ++i) result.push_back(from0(source.data[i]));
  return result;
}

inline void check3(const EmptySized& source, size_t& budget) {
  (void)source; (void)budget;
  charge(budget, 1, sizeof(checkedrecordvalueindices_empty_sized));
  check2(source.data, budget);
}
struct View3 {
  View2 field0;
  checkedrecordvalueindices_empty_sized value{};
  explicit View3(const EmptySized& source) : field0(source.data) {
    (void)source;
    value = checkedrecordvalueindices_empty_sized{field0.value};
  }
};
inline EmptySized from3(const checkedrecordvalueindices_empty_sized& source) {
  (void)source;
  return EmptySized{from2(source.data)};
}

inline void check4(const EmptyToken& source, size_t& budget) {
  (void)source; (void)budget;
  charge(budget, 1, sizeof(checkedrecordvalueindices_empty_token));
  check0(source.count, budget);
}
struct View4 {
  View0 field0;
  checkedrecordvalueindices_empty_token value{};
  explicit View4(const EmptyToken& source) : field0(source.count) {
    (void)source;
    value = checkedrecordvalueindices_empty_token{field0.value};
  }
};
inline EmptyToken from4(const checkedrecordvalueindices_empty_token& source) {
  (void)source;
  return EmptyToken{from0(source.count)};
}

inline void check5(const Off& source, size_t& budget) {
  (void)source; (void)budget;
  charge(budget, 1, sizeof(checkedrecordvalueindices_off));
  check0(source.count, budget);
}
struct View5 {
  View0 field0;
  checkedrecordvalueindices_off value{};
  explicit View5(const Off& source) : field0(source.count) {
    (void)source;
    value = checkedrecordvalueindices_off{field0.value};
  }
};
inline Off from5(const checkedrecordvalueindices_off& source) {
  (void)source;
  return Off{from0(source.count)};
}

inline void check6(const On& source, size_t& budget) {
  (void)source; (void)budget;
  charge(budget, 1, sizeof(checkedrecordvalueindices_on));
  check0(source.count, budget);
}
struct View6 {
  View0 field0;
  checkedrecordvalueindices_on value{};
  explicit View6(const On& source) : field0(source.count) {
    (void)source;
    value = checkedrecordvalueindices_on{field0.value};
  }
};
inline On from6(const checkedrecordvalueindices_on& source) {
  (void)source;
  return On{from0(source.count)};
}

inline void check7(const UnicodeToken& source, size_t& budget) {
  (void)source; (void)budget;
  charge(budget, 1, sizeof(checkedrecordvalueindices_unicode_token));
  check0(source.count, budget);
}
struct View7 {
  View0 field0;
  checkedrecordvalueindices_unicode_token value{};
  explicit View7(const UnicodeToken& source) : field0(source.count) {
    (void)source;
    value = checkedrecordvalueindices_unicode_token{field0.value};
  }
};
inline UnicodeToken from7(const checkedrecordvalueindices_unicode_token& source) {
  (void)source;
  return UnicodeToken{from0(source.count)};
}

inline void check8(const WideToken& source, size_t& budget) {
  (void)source; (void)budget;
  charge(budget, 1, sizeof(checkedrecordvalueindices_wide_token));
  check0(source.count, budget);
}
struct View8 {
  View0 field0;
  checkedrecordvalueindices_wide_token value{};
  explicit View8(const WideToken& source) : field0(source.count) {
    (void)source;
    value = checkedrecordvalueindices_wide_token{field0.value};
  }
};
inline WideToken from8(const checkedrecordvalueindices_wide_token& source) {
  (void)source;
  return WideToken{from0(source.count)};
}

inline void check9(const ZeroToken& source, size_t& budget) {
  (void)source; (void)budget;
  charge(budget, 1, sizeof(checkedrecordvalueindices_zero_token));
  check0(source.count, budget);
}
struct View9 {
  View0 field0;
  checkedrecordvalueindices_zero_token value{};
  explicit View9(const ZeroToken& source) : field0(source.count) {
    (void)source;
    value = checkedrecordvalueindices_zero_token{field0.value};
  }
};
inline ZeroToken from9(const checkedrecordvalueindices_zero_token& source) {
  (void)source;
  return ZeroToken{from0(source.count)};
}
inline void check(checkedrecordvalueindices_status status, const checkedrecordvalueindices_error& error) {
  if (status != CHECKEDRECORDVALUEINDICES_STATUS_OK) throw Error(status, error);
}
template<class T, void (*Clear)(T*)> struct Owned {
  T* value;
  ~Owned() { Clear(value); }
  Owned(const Owned&) = delete;
  Owned& operator=(const Owned&) = delete;
  explicit Owned(T* input) : value(input) {}
};
}


inline Nat ab_string_index(Ab const& arg0) {
  checkedrecordvalueindices_error _lb_error{}; size_t _lb_budget = 16u * 1024u * 1024u; (void)_lb_budget;
  detail::check1(arg0, _lb_budget);
  detail::View1 _lb_arg0{arg0};
  checkedrecordvalueindices_nat _lb_result{};
  detail::Owned<checkedrecordvalueindices_nat, checkedrecordvalueindices_nat_clear> _lb_owner{&_lb_result};
  const auto _lb_status = checkedrecordvalueindices_ab_string_index(&_lb_arg0.value, &_lb_result, &_lb_error);
  detail::check(_lb_status, _lb_error);
  return detail::from0(_lb_result);
}

inline Nat empty_sized_index(EmptySized const& arg0) {
  checkedrecordvalueindices_error _lb_error{}; size_t _lb_budget = 16u * 1024u * 1024u; (void)_lb_budget;
  detail::check3(arg0, _lb_budget);
  detail::View3 _lb_arg0{arg0};
  checkedrecordvalueindices_nat _lb_result{};
  detail::Owned<checkedrecordvalueindices_nat, checkedrecordvalueindices_nat_clear> _lb_owner{&_lb_result};
  const auto _lb_status = checkedrecordvalueindices_empty_sized_index(&_lb_arg0.value, &_lb_result, &_lb_error);
  detail::check(_lb_status, _lb_error);
  return detail::from0(_lb_result);
}

inline Nat empty_string_index(EmptyToken const& arg0) {
  checkedrecordvalueindices_error _lb_error{}; size_t _lb_budget = 16u * 1024u * 1024u; (void)_lb_budget;
  detail::check4(arg0, _lb_budget);
  detail::View4 _lb_arg0{arg0};
  checkedrecordvalueindices_nat _lb_result{};
  detail::Owned<checkedrecordvalueindices_nat, checkedrecordvalueindices_nat_clear> _lb_owner{&_lb_result};
  const auto _lb_status = checkedrecordvalueindices_empty_string_index(&_lb_arg0.value, &_lb_result, &_lb_error);
  detail::check(_lb_status, _lb_error);
  return detail::from0(_lb_result);
}

inline Nat false_bool_index(Off const& arg0) {
  checkedrecordvalueindices_error _lb_error{}; size_t _lb_budget = 16u * 1024u * 1024u; (void)_lb_budget;
  detail::check5(arg0, _lb_budget);
  detail::View5 _lb_arg0{arg0};
  checkedrecordvalueindices_nat _lb_result{};
  detail::Owned<checkedrecordvalueindices_nat, checkedrecordvalueindices_nat_clear> _lb_owner{&_lb_result};
  const auto _lb_status = checkedrecordvalueindices_false_bool_index(&_lb_arg0.value, &_lb_result, &_lb_error);
  detail::check(_lb_status, _lb_error);
  return detail::from0(_lb_result);
}

inline Ab produce_ab() {
  checkedrecordvalueindices_error _lb_error{}; size_t _lb_budget = 16u * 1024u * 1024u; (void)_lb_budget;
  checkedrecordvalueindices_ab _lb_result{};
  detail::Owned<checkedrecordvalueindices_ab, checkedrecordvalueindices_ab_clear> _lb_owner{&_lb_result};
  const auto _lb_status = checkedrecordvalueindices_produce_ab(&_lb_result, &_lb_error);
  detail::check(_lb_status, _lb_error);
  return detail::from1(_lb_result);
}

inline EmptySized produce_empty_sized() {
  checkedrecordvalueindices_error _lb_error{}; size_t _lb_budget = 16u * 1024u * 1024u; (void)_lb_budget;
  checkedrecordvalueindices_empty_sized _lb_result{};
  detail::Owned<checkedrecordvalueindices_empty_sized, checkedrecordvalueindices_empty_sized_clear> _lb_owner{&_lb_result};
  const auto _lb_status = checkedrecordvalueindices_produce_empty_sized(&_lb_result, &_lb_error);
  detail::check(_lb_status, _lb_error);
  return detail::from3(_lb_result);
}

inline EmptyToken produce_empty_string(Nat const& arg0) {
  checkedrecordvalueindices_error _lb_error{}; size_t _lb_budget = 16u * 1024u * 1024u; (void)_lb_budget;
  detail::check0(arg0, _lb_budget);
  detail::View0 _lb_arg0{arg0};
  checkedrecordvalueindices_empty_token _lb_result{};
  detail::Owned<checkedrecordvalueindices_empty_token, checkedrecordvalueindices_empty_token_clear> _lb_owner{&_lb_result};
  const auto _lb_status = checkedrecordvalueindices_produce_empty_string(&_lb_arg0.value, &_lb_result, &_lb_error);
  detail::check(_lb_status, _lb_error);
  return detail::from4(_lb_result);
}

inline Off produce_false_bool() {
  checkedrecordvalueindices_error _lb_error{}; size_t _lb_budget = 16u * 1024u * 1024u; (void)_lb_budget;
  checkedrecordvalueindices_off _lb_result{};
  detail::Owned<checkedrecordvalueindices_off, checkedrecordvalueindices_off_clear> _lb_owner{&_lb_result};
  const auto _lb_status = checkedrecordvalueindices_produce_false_bool(&_lb_result, &_lb_error);
  detail::check(_lb_status, _lb_error);
  return detail::from5(_lb_result);
}

inline On produce_true_bool() {
  checkedrecordvalueindices_error _lb_error{}; size_t _lb_budget = 16u * 1024u * 1024u; (void)_lb_budget;
  checkedrecordvalueindices_on _lb_result{};
  detail::Owned<checkedrecordvalueindices_on, checkedrecordvalueindices_on_clear> _lb_owner{&_lb_result};
  const auto _lb_status = checkedrecordvalueindices_produce_true_bool(&_lb_result, &_lb_error);
  detail::check(_lb_status, _lb_error);
  return detail::from6(_lb_result);
}

inline UnicodeToken produce_unicode_string(Nat const& arg0) {
  checkedrecordvalueindices_error _lb_error{}; size_t _lb_budget = 16u * 1024u * 1024u; (void)_lb_budget;
  detail::check0(arg0, _lb_budget);
  detail::View0 _lb_arg0{arg0};
  checkedrecordvalueindices_unicode_token _lb_result{};
  detail::Owned<checkedrecordvalueindices_unicode_token, checkedrecordvalueindices_unicode_token_clear> _lb_owner{&_lb_result};
  const auto _lb_status = checkedrecordvalueindices_produce_unicode_string(&_lb_arg0.value, &_lb_result, &_lb_error);
  detail::check(_lb_status, _lb_error);
  return detail::from7(_lb_result);
}

inline WideToken produce_wide_nat(Nat const& arg0) {
  checkedrecordvalueindices_error _lb_error{}; size_t _lb_budget = 16u * 1024u * 1024u; (void)_lb_budget;
  detail::check0(arg0, _lb_budget);
  detail::View0 _lb_arg0{arg0};
  checkedrecordvalueindices_wide_token _lb_result{};
  detail::Owned<checkedrecordvalueindices_wide_token, checkedrecordvalueindices_wide_token_clear> _lb_owner{&_lb_result};
  const auto _lb_status = checkedrecordvalueindices_produce_wide_nat(&_lb_arg0.value, &_lb_result, &_lb_error);
  detail::check(_lb_status, _lb_error);
  return detail::from8(_lb_result);
}

inline ZeroToken produce_zero_nat(Nat const& arg0) {
  checkedrecordvalueindices_error _lb_error{}; size_t _lb_budget = 16u * 1024u * 1024u; (void)_lb_budget;
  detail::check0(arg0, _lb_budget);
  detail::View0 _lb_arg0{arg0};
  checkedrecordvalueindices_zero_token _lb_result{};
  detail::Owned<checkedrecordvalueindices_zero_token, checkedrecordvalueindices_zero_token_clear> _lb_owner{&_lb_result};
  const auto _lb_status = checkedrecordvalueindices_produce_zero_nat(&_lb_arg0.value, &_lb_result, &_lb_error);
  detail::check(_lb_status, _lb_error);
  return detail::from9(_lb_result);
}

inline Nat true_bool_index(On const& arg0) {
  checkedrecordvalueindices_error _lb_error{}; size_t _lb_budget = 16u * 1024u * 1024u; (void)_lb_budget;
  detail::check6(arg0, _lb_budget);
  detail::View6 _lb_arg0{arg0};
  checkedrecordvalueindices_nat _lb_result{};
  detail::Owned<checkedrecordvalueindices_nat, checkedrecordvalueindices_nat_clear> _lb_owner{&_lb_result};
  const auto _lb_status = checkedrecordvalueindices_true_bool_index(&_lb_arg0.value, &_lb_result, &_lb_error);
  detail::check(_lb_status, _lb_error);
  return detail::from0(_lb_result);
}

inline Nat unicode_string_index(UnicodeToken const& arg0) {
  checkedrecordvalueindices_error _lb_error{}; size_t _lb_budget = 16u * 1024u * 1024u; (void)_lb_budget;
  detail::check7(arg0, _lb_budget);
  detail::View7 _lb_arg0{arg0};
  checkedrecordvalueindices_nat _lb_result{};
  detail::Owned<checkedrecordvalueindices_nat, checkedrecordvalueindices_nat_clear> _lb_owner{&_lb_result};
  const auto _lb_status = checkedrecordvalueindices_unicode_string_index(&_lb_arg0.value, &_lb_result, &_lb_error);
  detail::check(_lb_status, _lb_error);
  return detail::from0(_lb_result);
}

inline Nat wide_nat_index(WideToken const& arg0) {
  checkedrecordvalueindices_error _lb_error{}; size_t _lb_budget = 16u * 1024u * 1024u; (void)_lb_budget;
  detail::check8(arg0, _lb_budget);
  detail::View8 _lb_arg0{arg0};
  checkedrecordvalueindices_nat _lb_result{};
  detail::Owned<checkedrecordvalueindices_nat, checkedrecordvalueindices_nat_clear> _lb_owner{&_lb_result};
  const auto _lb_status = checkedrecordvalueindices_wide_nat_index(&_lb_arg0.value, &_lb_result, &_lb_error);
  detail::check(_lb_status, _lb_error);
  return detail::from0(_lb_result);
}

inline Nat zero_nat_index(ZeroToken const& arg0) {
  checkedrecordvalueindices_error _lb_error{}; size_t _lb_budget = 16u * 1024u * 1024u; (void)_lb_budget;
  detail::check9(arg0, _lb_budget);
  detail::View9 _lb_arg0{arg0};
  checkedrecordvalueindices_nat _lb_result{};
  detail::Owned<checkedrecordvalueindices_nat, checkedrecordvalueindices_nat_clear> _lb_owner{&_lb_result};
  const auto _lb_status = checkedrecordvalueindices_zero_nat_index(&_lb_arg0.value, &_lb_result, &_lb_error);
  detail::check(_lb_status, _lb_error);
  return detail::from0(_lb_result);
}
}
