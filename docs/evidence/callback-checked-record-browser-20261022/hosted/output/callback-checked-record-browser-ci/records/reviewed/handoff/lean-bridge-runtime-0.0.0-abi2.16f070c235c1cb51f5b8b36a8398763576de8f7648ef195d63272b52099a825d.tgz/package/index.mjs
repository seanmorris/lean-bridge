import createMain from "./internal/main.mjs";
import { createComponentRuntime } from "./internal/component-runtime.mjs";
export const { loadComponent } = await createComponentRuntime(createMain, new URL("./internal/main.wasm", import.meta.url));
