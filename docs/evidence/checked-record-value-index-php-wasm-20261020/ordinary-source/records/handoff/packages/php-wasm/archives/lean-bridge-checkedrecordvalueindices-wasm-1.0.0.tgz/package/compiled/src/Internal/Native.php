<?php
declare(strict_types=1);
namespace LeanBridge\CopiedPhpWasmV1 {
if (!class_exists(Loader::class, false)) {
    final class Loader {
        private static ?string $failure = null;
        private static bool $loading = false;
        private static int $callbacks = 0;
        public static function enterCallback(): void { ++self::$callbacks; }
        public static function leaveCallback(): void { --self::$callbacks; }
        public static function load(string $library, string $function): void {
            if (self::$failure !== null) throw new \RuntimeException(self::$failure);
            if (self::$loading) throw new \RuntimeException('Reentrant PHP-Wasm extension loading is not supported');
            // dl may suspend the host to fetch or instantiate a side module.
            // The synchronous Lean stack cannot participate in that unwind.
            if (self::$callbacks !== 0) throw new \RuntimeException('Cannot load a PHP-Wasm extension inside a synchronous Lean callback. Use its startup descriptor or call that package before entering the callback.');
            $registration = '/__lean_bridge/php_wasm_lazy/' . $library . '.txt';
            if (!is_file($registration) || file_get_contents($registration) !== $library) {
                throw new \RuntimeException('Register this package lazy descriptor in dynamicLibs before PHP starts');
            }
            if (!function_exists('dl') || !ini_get('enable_dl')) {
                throw new \RuntimeException('PHP-Wasm lazy loading requires enable_dl=1');
            }
            self::$loading = true;
            try {
                set_error_handler(static function (int $severity, string $message): never {
                    throw new \RuntimeException($message);
                });
                try {
                    if (!dl($library) || !function_exists($function)) {
                        throw new \RuntimeException('The generated Zend transport did not load');
                    }
                } finally { restore_error_handler(); }
            } catch (\Throwable $error) {
                // Emscripten may retain a partially linked DSO after failure.
                // Do not attempt another lazy load in that PHP instance.
                self::$failure = 'PHP-Wasm extension loading failed; create a new PHP instance. ' . $error->getMessage();
                throw new \RuntimeException(self::$failure, 0, $error);
            } finally { self::$loading = false; }
        }
    }
}
}

namespace LeanCheckedrecordvalueindices\Internal {

final class Budget
{
    private int $remaining = 16 * 1024 * 1024;
    public function charge(int $count, int $width = 1): void {
        if ($count < 0 || $width < 1 || $count > intdiv($this->remaining, $width)) {
            throw new \ValueError('16 MiB PHP conversion limit exceeded');
        }
        $this->remaining -= $count * $width;
    }
}
final class Checks
{
    public static function check0(mixed $value, Budget $budget): mixed {
        $budget->charge(1, 16);
        if (!$value instanceof \Brick\Math\BigInteger) throw new \TypeError('Expected Brick Math BigInteger');
        $decimal = (string) $value;
        if (strlen($decimal) > 16385 || strlen(ltrim($decimal, '-')) > 16384 || preg_match('/^(?:0|-?[1-9][0-9]*)$/D', $decimal) !== 1) throw new \ValueError('BigInteger requires canonical decimal text of at most 16384 digits');
        $budget->charge(strlen($decimal));
        if ($decimal[0] === '-') throw new \ValueError('Expected an unsigned integer');
        return $value;
    }
    public static function check1(mixed $value, Budget $budget): mixed {
        $budget->charge(1, 16);
        if (!$value instanceof \LeanCheckedrecordvalueindices\Ab) throw new \TypeError('Expected Ab');
        if (array_keys(get_object_vars($value)) !== ['size']) throw new \TypeError('Ab requires exactly its initialized fields');
        self::check0($value->size, $budget);
        return $value;
    }
    public static function check2(mixed $value, Budget $budget): mixed {
        $budget->charge(1, 16);
        if (!is_array($value) || !array_is_list($value)) throw new \TypeError('Expected a list with consecutive integer keys');
        $budget->charge(count($value), 32);
        $result = [];
        foreach ($value as $item) $result[] = self::check0($item, $budget);
        return $result;
    }
    public static function check3(mixed $value, Budget $budget): mixed {
        $budget->charge(1, 16);
        if (!$value instanceof \LeanCheckedrecordvalueindices\EmptySized) throw new \TypeError('Expected EmptySized');
        if (array_keys(get_object_vars($value)) !== ['data']) throw new \TypeError('EmptySized requires exactly its initialized fields');
        self::check2($value->data, $budget);
        return $value;
    }
    public static function check4(mixed $value, Budget $budget): mixed {
        $budget->charge(1, 16);
        if (!$value instanceof \LeanCheckedrecordvalueindices\EmptyToken) throw new \TypeError('Expected EmptyToken');
        if (array_keys(get_object_vars($value)) !== ['count']) throw new \TypeError('EmptyToken requires exactly its initialized fields');
        self::check0($value->count, $budget);
        return $value;
    }
    public static function check5(mixed $value, Budget $budget): mixed {
        $budget->charge(1, 16);
        if (!$value instanceof \LeanCheckedrecordvalueindices\Off) throw new \TypeError('Expected Off');
        if (array_keys(get_object_vars($value)) !== ['count']) throw new \TypeError('Off requires exactly its initialized fields');
        self::check0($value->count, $budget);
        return $value;
    }
    public static function check6(mixed $value, Budget $budget): mixed {
        $budget->charge(1, 16);
        if (!$value instanceof \LeanCheckedrecordvalueindices\On) throw new \TypeError('Expected On');
        if (array_keys(get_object_vars($value)) !== ['count']) throw new \TypeError('On requires exactly its initialized fields');
        self::check0($value->count, $budget);
        return $value;
    }
    public static function check7(mixed $value, Budget $budget): mixed {
        $budget->charge(1, 16);
        if (!$value instanceof \LeanCheckedrecordvalueindices\UnicodeToken) throw new \TypeError('Expected UnicodeToken');
        if (array_keys(get_object_vars($value)) !== ['count']) throw new \TypeError('UnicodeToken requires exactly its initialized fields');
        self::check0($value->count, $budget);
        return $value;
    }
    public static function check8(mixed $value, Budget $budget): mixed {
        $budget->charge(1, 16);
        if (!$value instanceof \LeanCheckedrecordvalueindices\WideToken) throw new \TypeError('Expected WideToken');
        if (array_keys(get_object_vars($value)) !== ['count']) throw new \TypeError('WideToken requires exactly its initialized fields');
        self::check0($value->count, $budget);
        return $value;
    }
    public static function check9(mixed $value, Budget $budget): mixed {
        $budget->charge(1, 16);
        if (!$value instanceof \LeanCheckedrecordvalueindices\ZeroToken) throw new \TypeError('Expected ZeroToken');
        if (array_keys(get_object_vars($value)) !== ['count']) throw new \TypeError('ZeroToken requires exactly its initialized fields');
        self::check0($value->count, $budget);
        return $value;
    }
}
final class Values
{
    private static function step(Budget $budget, int $depth): void {
        if ($depth > 32) throw new \ValueError('Value comparison exceeds 32 nesting levels');
        $budget->charge(1, 32);
    }
    private static function fields(object $value, Budget $budget): array {
        $expected = match ($value::class) {
            \LeanCheckedrecordvalueindices\Ab::class => ['size'],
            \LeanCheckedrecordvalueindices\EmptySized::class => ['data'],
            \LeanCheckedrecordvalueindices\EmptyToken::class => ['count'],
            \LeanCheckedrecordvalueindices\Off::class => ['count'],
            \LeanCheckedrecordvalueindices\On::class => ['count'],
            \LeanCheckedrecordvalueindices\UnicodeToken::class => ['count'],
            \LeanCheckedrecordvalueindices\WideToken::class => ['count'],
            \LeanCheckedrecordvalueindices\ZeroToken::class => ['count'],
            default => throw new \TypeError('Value comparison requires generated copied values'),
        };
        $budget->charge(count($expected), 32);
        $fields = get_object_vars($value);
        if (array_keys($fields) !== $expected) throw new \TypeError('Value comparison requires initialized fields');
        return $fields;
    }
    public static function equal(mixed $left, mixed $right): bool {
        return self::same($left, $right, new Budget(), 0);
    }
    private static function same(mixed $left, mixed $right, Budget $budget, int $depth): bool {
        self::step($budget, $depth);
        if (get_debug_type($left) !== get_debug_type($right)) return false;
        if (is_float($left)) return is_nan($left) ? is_nan($right) : pack('E', $left) === pack('E', $right);
        if ($left instanceof \Brick\Math\BigInteger) { $left = (string) $left; $right = (string) $right; }
        elseif ($left instanceof \LeanCheckedrecordvalueindices\Bytes) { $left = $left->toString(); $right = $right->toString(); }
        elseif (is_object($left)) {
            $left = self::fields($left, $budget); $right = self::fields($right, $budget);
            foreach ($left as $name => $value) if (!self::same($value, $right[$name], $budget, $depth + 1)) return false;
            return true;
        }
        if (is_string($left)) { $budget->charge(strlen($left)); $budget->charge(strlen($right)); return $left === $right; }
        if (is_array($left)) {
            $budget->charge(count($left), 32); $budget->charge(count($right), 32);
            if (!array_is_list($left) || !array_is_list($right)) throw new \TypeError('Value comparison requires consecutive-key lists');
            if (count($left) !== count($right)) return false;
            foreach ($left as $index => $value) if (!self::same($value, $right[$index], $budget, $depth + 1)) return false;
            return true;
        }
        if ($left === null || is_bool($left) || is_int($left)) return $left === $right;
        throw new \TypeError('Value comparison requires copied values');
    }
    private static function text(\HashContext $hash, string $tag, string $text, Budget $budget): void {
        $budget->charge(strlen($text));
        hash_update($hash, $tag . pack('N', strlen($text))); hash_update($hash, $text);
    }
    public static function hash(mixed $value): string {
        $hash = hash_init('sha256'); self::append($hash, $value, new Budget(), 0); return hash_final($hash);
    }
    private static function append(\HashContext $hash, mixed $value, Budget $budget, int $depth): void {
        self::step($budget, $depth);
        if ($value === null) hash_update($hash, 'n');
        elseif (is_bool($value)) hash_update($hash, $value ? 't' : 'f');
        elseif (is_int($value)) self::text($hash, 'i', (string) $value, $budget);
        elseif (is_float($value)) hash_update($hash, is_nan($value) ? 'q' : 'd' . pack('E', $value));
        elseif (is_string($value)) self::text($hash, 's', $value, $budget);
        elseif ($value instanceof \Brick\Math\BigInteger) self::text($hash, 'b', (string) $value, $budget);
        elseif ($value instanceof \LeanCheckedrecordvalueindices\Bytes) self::text($hash, 'y', $value->toString(), $budget);
        elseif (is_array($value)) {
            $budget->charge(count($value), 32);
            if (!array_is_list($value)) throw new \TypeError('Value hashing requires consecutive-key lists');
            hash_update($hash, 'a' . pack('N', count($value)));
            foreach ($value as $item) self::append($hash, $item, $budget, $depth + 1);
        } elseif (is_object($value)) {
            $fields = self::fields($value, $budget);
            self::text($hash, 'o', $value::class, $budget);
            foreach ($fields as $name => $item) { self::text($hash, 'k', $name, $budget); self::append($hash, $item, $budget, $depth + 1); }
        } else throw new \TypeError('Value hashing requires copied values');
    }
}


final class Native
{
    private static function to0(mixed $value): mixed { return (string) $value; }
    private static function from0(mixed $value): mixed { return \Brick\Math\BigInteger::of($value); }
    private static function to1(mixed $value): mixed { return [self::to0($value->size)]; }
    private static function from1(mixed $value): mixed { return new \LeanCheckedrecordvalueindices\Ab(self::from0($value[0])); }
    private static function to2(mixed $value): mixed { return array_map(self::to0(...), $value); }
    private static function from2(mixed $value): mixed { return array_map(self::from0(...), $value); }
    private static function to3(mixed $value): mixed { return [self::to2($value->data)]; }
    private static function from3(mixed $value): mixed { return new \LeanCheckedrecordvalueindices\EmptySized(self::from2($value[0])); }
    private static function to4(mixed $value): mixed { return [self::to0($value->count)]; }
    private static function from4(mixed $value): mixed { return new \LeanCheckedrecordvalueindices\EmptyToken(self::from0($value[0])); }
    private static function to5(mixed $value): mixed { return [self::to0($value->count)]; }
    private static function from5(mixed $value): mixed { return new \LeanCheckedrecordvalueindices\Off(self::from0($value[0])); }
    private static function to6(mixed $value): mixed { return [self::to0($value->count)]; }
    private static function from6(mixed $value): mixed { return new \LeanCheckedrecordvalueindices\On(self::from0($value[0])); }
    private static function to7(mixed $value): mixed { return [self::to0($value->count)]; }
    private static function from7(mixed $value): mixed { return new \LeanCheckedrecordvalueindices\UnicodeToken(self::from0($value[0])); }
    private static function to8(mixed $value): mixed { return [self::to0($value->count)]; }
    private static function from8(mixed $value): mixed { return new \LeanCheckedrecordvalueindices\WideToken(self::from0($value[0])); }
    private static function to9(mixed $value): mixed { return [self::to0($value->count)]; }
    private static function from9(mixed $value): mixed { return new \LeanCheckedrecordvalueindices\ZeroToken(self::from0($value[0])); }

    public static function call0(mixed $arg0): mixed {
        $budget = new Budget();
        $input0 = self::to1(Checks::check1($arg0, $budget));
        if (!function_exists('LeanCheckedrecordvalueindices\Internal\Zend8c86fcce6e6ebd66\\call0')) {
            try { \LeanBridge\CopiedPhpWasmV1\Loader::load('php8.4-lb_checkedrecordvalueindices_8c86fcce6e6ebd66.so', 'LeanCheckedrecordvalueindices\Internal\Zend8c86fcce6e6ebd66\\call0'); }
            catch (\Throwable $error) { throw new \LeanCheckedrecordvalueindices\LeanBridgeError($error->getMessage(), 0, $error); }
        }
        try { $output = \LeanCheckedrecordvalueindices\Internal\Zend8c86fcce6e6ebd66\call0($input0); }
        catch (\Exception $error) { throw new \LeanCheckedrecordvalueindices\LeanBridgeError($error->getMessage(), $error->getCode(), $error); }
        return self::from0($output);
    }
    public static function call1(mixed $arg0): mixed {
        $budget = new Budget();
        $input0 = self::to3(Checks::check3($arg0, $budget));
        if (!function_exists('LeanCheckedrecordvalueindices\Internal\Zend8c86fcce6e6ebd66\\call1')) {
            try { \LeanBridge\CopiedPhpWasmV1\Loader::load('php8.4-lb_checkedrecordvalueindices_8c86fcce6e6ebd66.so', 'LeanCheckedrecordvalueindices\Internal\Zend8c86fcce6e6ebd66\\call1'); }
            catch (\Throwable $error) { throw new \LeanCheckedrecordvalueindices\LeanBridgeError($error->getMessage(), 0, $error); }
        }
        try { $output = \LeanCheckedrecordvalueindices\Internal\Zend8c86fcce6e6ebd66\call1($input0); }
        catch (\Exception $error) { throw new \LeanCheckedrecordvalueindices\LeanBridgeError($error->getMessage(), $error->getCode(), $error); }
        return self::from0($output);
    }
    public static function call2(mixed $arg0): mixed {
        $budget = new Budget();
        $input0 = self::to4(Checks::check4($arg0, $budget));
        if (!function_exists('LeanCheckedrecordvalueindices\Internal\Zend8c86fcce6e6ebd66\\call2')) {
            try { \LeanBridge\CopiedPhpWasmV1\Loader::load('php8.4-lb_checkedrecordvalueindices_8c86fcce6e6ebd66.so', 'LeanCheckedrecordvalueindices\Internal\Zend8c86fcce6e6ebd66\\call2'); }
            catch (\Throwable $error) { throw new \LeanCheckedrecordvalueindices\LeanBridgeError($error->getMessage(), 0, $error); }
        }
        try { $output = \LeanCheckedrecordvalueindices\Internal\Zend8c86fcce6e6ebd66\call2($input0); }
        catch (\Exception $error) { throw new \LeanCheckedrecordvalueindices\LeanBridgeError($error->getMessage(), $error->getCode(), $error); }
        return self::from0($output);
    }
    public static function call3(mixed $arg0): mixed {
        $budget = new Budget();
        $input0 = self::to5(Checks::check5($arg0, $budget));
        if (!function_exists('LeanCheckedrecordvalueindices\Internal\Zend8c86fcce6e6ebd66\\call3')) {
            try { \LeanBridge\CopiedPhpWasmV1\Loader::load('php8.4-lb_checkedrecordvalueindices_8c86fcce6e6ebd66.so', 'LeanCheckedrecordvalueindices\Internal\Zend8c86fcce6e6ebd66\\call3'); }
            catch (\Throwable $error) { throw new \LeanCheckedrecordvalueindices\LeanBridgeError($error->getMessage(), 0, $error); }
        }
        try { $output = \LeanCheckedrecordvalueindices\Internal\Zend8c86fcce6e6ebd66\call3($input0); }
        catch (\Exception $error) { throw new \LeanCheckedrecordvalueindices\LeanBridgeError($error->getMessage(), $error->getCode(), $error); }
        return self::from0($output);
    }
    public static function call4(): mixed {
        $budget = new Budget();

        if (!function_exists('LeanCheckedrecordvalueindices\Internal\Zend8c86fcce6e6ebd66\\call4')) {
            try { \LeanBridge\CopiedPhpWasmV1\Loader::load('php8.4-lb_checkedrecordvalueindices_8c86fcce6e6ebd66.so', 'LeanCheckedrecordvalueindices\Internal\Zend8c86fcce6e6ebd66\\call4'); }
            catch (\Throwable $error) { throw new \LeanCheckedrecordvalueindices\LeanBridgeError($error->getMessage(), 0, $error); }
        }
        try { $output = \LeanCheckedrecordvalueindices\Internal\Zend8c86fcce6e6ebd66\call4(); }
        catch (\Exception $error) { throw new \LeanCheckedrecordvalueindices\LeanBridgeError($error->getMessage(), $error->getCode(), $error); }
        return self::from1($output);
    }
    public static function call5(): mixed {
        $budget = new Budget();

        if (!function_exists('LeanCheckedrecordvalueindices\Internal\Zend8c86fcce6e6ebd66\\call5')) {
            try { \LeanBridge\CopiedPhpWasmV1\Loader::load('php8.4-lb_checkedrecordvalueindices_8c86fcce6e6ebd66.so', 'LeanCheckedrecordvalueindices\Internal\Zend8c86fcce6e6ebd66\\call5'); }
            catch (\Throwable $error) { throw new \LeanCheckedrecordvalueindices\LeanBridgeError($error->getMessage(), 0, $error); }
        }
        try { $output = \LeanCheckedrecordvalueindices\Internal\Zend8c86fcce6e6ebd66\call5(); }
        catch (\Exception $error) { throw new \LeanCheckedrecordvalueindices\LeanBridgeError($error->getMessage(), $error->getCode(), $error); }
        return self::from3($output);
    }
    public static function call6(mixed $arg0): mixed {
        $budget = new Budget();
        $input0 = self::to0(Checks::check0($arg0, $budget));
        if (!function_exists('LeanCheckedrecordvalueindices\Internal\Zend8c86fcce6e6ebd66\\call6')) {
            try { \LeanBridge\CopiedPhpWasmV1\Loader::load('php8.4-lb_checkedrecordvalueindices_8c86fcce6e6ebd66.so', 'LeanCheckedrecordvalueindices\Internal\Zend8c86fcce6e6ebd66\\call6'); }
            catch (\Throwable $error) { throw new \LeanCheckedrecordvalueindices\LeanBridgeError($error->getMessage(), 0, $error); }
        }
        try { $output = \LeanCheckedrecordvalueindices\Internal\Zend8c86fcce6e6ebd66\call6($input0); }
        catch (\Exception $error) { throw new \LeanCheckedrecordvalueindices\LeanBridgeError($error->getMessage(), $error->getCode(), $error); }
        return self::from4($output);
    }
    public static function call7(): mixed {
        $budget = new Budget();

        if (!function_exists('LeanCheckedrecordvalueindices\Internal\Zend8c86fcce6e6ebd66\\call7')) {
            try { \LeanBridge\CopiedPhpWasmV1\Loader::load('php8.4-lb_checkedrecordvalueindices_8c86fcce6e6ebd66.so', 'LeanCheckedrecordvalueindices\Internal\Zend8c86fcce6e6ebd66\\call7'); }
            catch (\Throwable $error) { throw new \LeanCheckedrecordvalueindices\LeanBridgeError($error->getMessage(), 0, $error); }
        }
        try { $output = \LeanCheckedrecordvalueindices\Internal\Zend8c86fcce6e6ebd66\call7(); }
        catch (\Exception $error) { throw new \LeanCheckedrecordvalueindices\LeanBridgeError($error->getMessage(), $error->getCode(), $error); }
        return self::from5($output);
    }
    public static function call8(): mixed {
        $budget = new Budget();

        if (!function_exists('LeanCheckedrecordvalueindices\Internal\Zend8c86fcce6e6ebd66\\call8')) {
            try { \LeanBridge\CopiedPhpWasmV1\Loader::load('php8.4-lb_checkedrecordvalueindices_8c86fcce6e6ebd66.so', 'LeanCheckedrecordvalueindices\Internal\Zend8c86fcce6e6ebd66\\call8'); }
            catch (\Throwable $error) { throw new \LeanCheckedrecordvalueindices\LeanBridgeError($error->getMessage(), 0, $error); }
        }
        try { $output = \LeanCheckedrecordvalueindices\Internal\Zend8c86fcce6e6ebd66\call8(); }
        catch (\Exception $error) { throw new \LeanCheckedrecordvalueindices\LeanBridgeError($error->getMessage(), $error->getCode(), $error); }
        return self::from6($output);
    }
    public static function call9(mixed $arg0): mixed {
        $budget = new Budget();
        $input0 = self::to0(Checks::check0($arg0, $budget));
        if (!function_exists('LeanCheckedrecordvalueindices\Internal\Zend8c86fcce6e6ebd66\\call9')) {
            try { \LeanBridge\CopiedPhpWasmV1\Loader::load('php8.4-lb_checkedrecordvalueindices_8c86fcce6e6ebd66.so', 'LeanCheckedrecordvalueindices\Internal\Zend8c86fcce6e6ebd66\\call9'); }
            catch (\Throwable $error) { throw new \LeanCheckedrecordvalueindices\LeanBridgeError($error->getMessage(), 0, $error); }
        }
        try { $output = \LeanCheckedrecordvalueindices\Internal\Zend8c86fcce6e6ebd66\call9($input0); }
        catch (\Exception $error) { throw new \LeanCheckedrecordvalueindices\LeanBridgeError($error->getMessage(), $error->getCode(), $error); }
        return self::from7($output);
    }
    public static function call10(mixed $arg0): mixed {
        $budget = new Budget();
        $input0 = self::to0(Checks::check0($arg0, $budget));
        if (!function_exists('LeanCheckedrecordvalueindices\Internal\Zend8c86fcce6e6ebd66\\call10')) {
            try { \LeanBridge\CopiedPhpWasmV1\Loader::load('php8.4-lb_checkedrecordvalueindices_8c86fcce6e6ebd66.so', 'LeanCheckedrecordvalueindices\Internal\Zend8c86fcce6e6ebd66\\call10'); }
            catch (\Throwable $error) { throw new \LeanCheckedrecordvalueindices\LeanBridgeError($error->getMessage(), 0, $error); }
        }
        try { $output = \LeanCheckedrecordvalueindices\Internal\Zend8c86fcce6e6ebd66\call10($input0); }
        catch (\Exception $error) { throw new \LeanCheckedrecordvalueindices\LeanBridgeError($error->getMessage(), $error->getCode(), $error); }
        return self::from8($output);
    }
    public static function call11(mixed $arg0): mixed {
        $budget = new Budget();
        $input0 = self::to0(Checks::check0($arg0, $budget));
        if (!function_exists('LeanCheckedrecordvalueindices\Internal\Zend8c86fcce6e6ebd66\\call11')) {
            try { \LeanBridge\CopiedPhpWasmV1\Loader::load('php8.4-lb_checkedrecordvalueindices_8c86fcce6e6ebd66.so', 'LeanCheckedrecordvalueindices\Internal\Zend8c86fcce6e6ebd66\\call11'); }
            catch (\Throwable $error) { throw new \LeanCheckedrecordvalueindices\LeanBridgeError($error->getMessage(), 0, $error); }
        }
        try { $output = \LeanCheckedrecordvalueindices\Internal\Zend8c86fcce6e6ebd66\call11($input0); }
        catch (\Exception $error) { throw new \LeanCheckedrecordvalueindices\LeanBridgeError($error->getMessage(), $error->getCode(), $error); }
        return self::from9($output);
    }
    public static function call12(mixed $arg0): mixed {
        $budget = new Budget();
        $input0 = self::to6(Checks::check6($arg0, $budget));
        if (!function_exists('LeanCheckedrecordvalueindices\Internal\Zend8c86fcce6e6ebd66\\call12')) {
            try { \LeanBridge\CopiedPhpWasmV1\Loader::load('php8.4-lb_checkedrecordvalueindices_8c86fcce6e6ebd66.so', 'LeanCheckedrecordvalueindices\Internal\Zend8c86fcce6e6ebd66\\call12'); }
            catch (\Throwable $error) { throw new \LeanCheckedrecordvalueindices\LeanBridgeError($error->getMessage(), 0, $error); }
        }
        try { $output = \LeanCheckedrecordvalueindices\Internal\Zend8c86fcce6e6ebd66\call12($input0); }
        catch (\Exception $error) { throw new \LeanCheckedrecordvalueindices\LeanBridgeError($error->getMessage(), $error->getCode(), $error); }
        return self::from0($output);
    }
    public static function call13(mixed $arg0): mixed {
        $budget = new Budget();
        $input0 = self::to7(Checks::check7($arg0, $budget));
        if (!function_exists('LeanCheckedrecordvalueindices\Internal\Zend8c86fcce6e6ebd66\\call13')) {
            try { \LeanBridge\CopiedPhpWasmV1\Loader::load('php8.4-lb_checkedrecordvalueindices_8c86fcce6e6ebd66.so', 'LeanCheckedrecordvalueindices\Internal\Zend8c86fcce6e6ebd66\\call13'); }
            catch (\Throwable $error) { throw new \LeanCheckedrecordvalueindices\LeanBridgeError($error->getMessage(), 0, $error); }
        }
        try { $output = \LeanCheckedrecordvalueindices\Internal\Zend8c86fcce6e6ebd66\call13($input0); }
        catch (\Exception $error) { throw new \LeanCheckedrecordvalueindices\LeanBridgeError($error->getMessage(), $error->getCode(), $error); }
        return self::from0($output);
    }
    public static function call14(mixed $arg0): mixed {
        $budget = new Budget();
        $input0 = self::to8(Checks::check8($arg0, $budget));
        if (!function_exists('LeanCheckedrecordvalueindices\Internal\Zend8c86fcce6e6ebd66\\call14')) {
            try { \LeanBridge\CopiedPhpWasmV1\Loader::load('php8.4-lb_checkedrecordvalueindices_8c86fcce6e6ebd66.so', 'LeanCheckedrecordvalueindices\Internal\Zend8c86fcce6e6ebd66\\call14'); }
            catch (\Throwable $error) { throw new \LeanCheckedrecordvalueindices\LeanBridgeError($error->getMessage(), 0, $error); }
        }
        try { $output = \LeanCheckedrecordvalueindices\Internal\Zend8c86fcce6e6ebd66\call14($input0); }
        catch (\Exception $error) { throw new \LeanCheckedrecordvalueindices\LeanBridgeError($error->getMessage(), $error->getCode(), $error); }
        return self::from0($output);
    }
    public static function call15(mixed $arg0): mixed {
        $budget = new Budget();
        $input0 = self::to9(Checks::check9($arg0, $budget));
        if (!function_exists('LeanCheckedrecordvalueindices\Internal\Zend8c86fcce6e6ebd66\\call15')) {
            try { \LeanBridge\CopiedPhpWasmV1\Loader::load('php8.4-lb_checkedrecordvalueindices_8c86fcce6e6ebd66.so', 'LeanCheckedrecordvalueindices\Internal\Zend8c86fcce6e6ebd66\\call15'); }
            catch (\Throwable $error) { throw new \LeanCheckedrecordvalueindices\LeanBridgeError($error->getMessage(), 0, $error); }
        }
        try { $output = \LeanCheckedrecordvalueindices\Internal\Zend8c86fcce6e6ebd66\call15($input0); }
        catch (\Exception $error) { throw new \LeanCheckedrecordvalueindices\LeanBridgeError($error->getMessage(), $error->getCode(), $error); }
        return self::from0($output);
    }
}
}
