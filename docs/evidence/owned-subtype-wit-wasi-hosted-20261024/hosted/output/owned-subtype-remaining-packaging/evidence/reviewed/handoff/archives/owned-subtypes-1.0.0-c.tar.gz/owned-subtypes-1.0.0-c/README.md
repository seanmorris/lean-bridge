# owned-subtypes 1.0.0

Compiled ownership-aware C11 API from owned-subtypes@1.0.0. Linux x86-64,
glibc 2.38 or newer. Consumers do not need Lean. The archive includes
the shared Lean runtime and GMP 6.3.0 with headers, corresponding source and notices.

Include owned_subtypes.h. Use pkg-config package owned-subtypes, or
find_package(LeanBridgeOwnedSubtypes CONFIG REQUIRED) and link LeanBridge::owned_subtypes.
Both methods link GMP automatically. The libraries load their bundled dependencies.

Open a session with owned_subtypes_session_open. Each successful call returns a typed value
view and a separate result owner. Release that owner with owned_subtypes_result_release.
Copying a view does not create ownership. Retain a resource or returned Lean closure
with its generated _retain function to keep it beyond the original owner's lifetime.
Close sessions with owned_subtypes_session_close. Copied result storage survives session close
until result release; resource calls do not. Sessions and results belong to their
creating thread and process. Inherited handles reject after fork. Cleanup remains
available after runtime retirement. Initialize output handles to NULL; functions
publish outputs only on success. Keep and release earlier owners before reusing slots.
Transferred inputs take an additional result-owner pointer immediately after the
value. Supply a distinct owner from the same session for each transferred argument.
Every resource in the value must belong to that owner. The bridge validates all
arguments before consuming any owner. Immediately before Lean runs, it consumes
each entire owner and sets its slot to NULL, including owners of empty values.
Failures before consumption preserve all input owners; later failures leave them
consumed. Do not reuse old views after the call returns. Independently retained
owners remain valid. Owner slots must not overlap output values or output owners.


Records use named fields, variants use named KIND enums and named payloads, and
containers use typed spans, has_value, is_ok and fst/snd. Nat and Int are borrowed
read-only mpz_srcptr views. Initialize caller integers with mpz_init, assign using
mpz_set, and finish them with mpz_clear. Do not clear or mutate returned integers.
GMP uses its default fatal allocation-failure policy. Strings are length-delimited
UTF-8, including NUL; bytes are uninterpreted. Inputs must point to readable storage.

Each C conversion and native conversion has its own cumulative 16 MiB storage and
262,144-visit budget. Value depth is limited to 128, cycles reject, and native
transactions retain at most 4,096 references. Limits do not cap Lean algorithm
working memory or every GMP allocator overhead. Invalid input or bridge allocation
failure preserves outputs and releases partial ownership. Malformed native replies
retire the runtime. Returned Lean closures have typed _call operations. Host
callbacks use generated _host descriptors with call/context or an existing closure.
The descriptor borrows the enclosing call's lifetime. Lean cannot invoke a host
callback after that borrow ends. Callback arguments expire on return. Reply views
may borrow those arguments or context storage; use a generated _copy function for
callback-local storage. Transfer its result owner with the reply, including on
error. The bridge releases that owner and retains returned resources for the caller.

REQUIRES_RECOVERY macros identify signatures that need a real typed recovery value
in the descriptor before the call starts. Other signatures recover from real
arguments or productive constructors. The bridge never fabricates a resource or
publishes a recovery value as successful output. Callback failure suppresses later
host invocations in the same call; subsequent independent calls can recover.
No C++ exception or longjmp may cross a callback boundary.

- echoRecord: lean:Owned.echoRecord
- echoRecordAlternate: lean:Owned.echoRecordAlternate
- newTicket: lean:Owned.newTicket
- serial: lean:Owned.serial
- transferRecord: lean:Owned.transferRecord
