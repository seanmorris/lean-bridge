#include "component.h"
#include "lean_bridge_native_runtime.h"
static _Thread_local int lean_bridge_owned_callback_failure_aed6bc1917801bda6f74_state;
int lean_bridge_owned_callback_failure_aed6bc1917801bda6f74(void) { int result = lean_bridge_owned_callback_failure_aed6bc1917801bda6f74_state; lean_bridge_owned_callback_failure_aed6bc1917801bda6f74_state = 0; return result; }
