#include "component.h"
#include "lean_bridge_native_runtime.h"
static _Thread_local int lean_bridge_owned_callback_failure_3f3a180be481eb26999f_state;
int lean_bridge_owned_callback_failure_3f3a180be481eb26999f(void) { int result = lean_bridge_owned_callback_failure_3f3a180be481eb26999f_state; lean_bridge_owned_callback_failure_3f3a180be481eb26999f_state = 0; return result; }
