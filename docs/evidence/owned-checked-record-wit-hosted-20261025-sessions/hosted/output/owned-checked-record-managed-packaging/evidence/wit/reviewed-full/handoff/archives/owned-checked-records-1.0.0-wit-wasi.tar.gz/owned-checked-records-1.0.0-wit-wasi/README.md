# owned-checked-records 1.0.0

Compiled ownership-aware WIT API from owned-checked-records@1.0.0. Linux x86-64,
glibc 2.38 or newer. The archive includes Wasmtime 42.0.1, the shared Lean
runtime, GMP 6.3.0 and its corresponding source and notices. Consumers need a
C11 compiler, not Lean. Keep the installed files together and unchanged.

Include owned_checked_records_wasmtime.h. Use pkg-config owned-checked-records-wit, or
find_package(LeanBridgeOwnedCheckedRecordsWasmtime CONFIG REQUIRED) and link LeanBridge::owned_checked_records_wasmtime.
Both supply the bundled GMP dependency. The host loads Wasmtime and Lean
automatically. Do not link the Lean shared library directly into the executable.

## Sessions and calls

Open with owned_checked_records_wasmtime_session_open and call the typed functions declared in the header.
Every exported function and returned Lean closure invocation crosses the embedded
Component Model binary. Retain and copy helpers only manage local ownership.
component/owned-checked-records.wasm contains that same binary; wit/owned-checked-records.wit
describes its contract. The component requires this native host. It is not a
standalone WASI command or a browser module. Raw Wasmtime resource handles and
custom caller-owned stores are not part of this public API.

Initialize each output owner to NULL. A successful call returns a typed value and
an independent result owner. Release it with owned_checked_records_wasmtime_result_release. Failure leaves
both output slots unchanged. Inputs borrow unless their declaration specifies transfer. A result owns all
its copied storage and resource leaves; aliases expire when that owner is released.
Use the generated retain/copy helpers to acquire independent ownership.

## Consuming inputs

An input declared transfer adds a result-owner pointer beside its value. Pass
the address of that value's owning result. Every consuming argument needs a
distinct owner from the same session. An owner covers its entire result, including
aliases and sibling resources, even when only one member is passed to the call.

The adapter validates every input before consuming any owner. At the native
handoff it invalidates the original owners and sets every supplied owner slot to
NULL before Lean runs, including before callbacks reenter. Failures after handoff
do not restore those owners. Their copied storage remains pinned until the call
returns. Retain or copy first when you need independent ownership.

The WIT contract uses own resources for consuming inputs and borrow resources
for borrowed inputs. The bundled session passes the original native ownership
frame to its trusted import, so the Component Model call cannot postpone or
bypass native owner validation. Raw caller-owned Wasmtime stores are not part
of this public API.

Close with owned_checked_records_wasmtime_session_close. Resource operations reject closed sessions. Copied
result storage remains readable until its result owner is released, even after
session close. Sessions and owners belong to their creating thread and process.
Wrong-thread and inherited post-fork calls reject without consuming the owner.
Use exec to start a fresh consumer after fork. Close during a callback defers
store destruction until active calls unwind. Reentrant calls use separate stores.

## Values and callbacks

Records have source-named fields, variants have named constructors, and sequences
use typed data/length views. Options have explicit presence flags; results keep
Ok and Err distinct. Recursive values use typed pointers with checked traversal.
Unit, absent values, present Unit and nested options remain distinct. Nat and Int
use exact GMP integers; negative Nat inputs reject. Strings are UTF-8 with explicit
lengths, including embedded NUL. Bytes use byte spans. Resource identities and
returned closures are opaque checked handles, never serialized pointer values.

Typed host callbacks borrow their arguments for the callback invocation. Retain
resources during that invocation to keep them. Callback replies transfer an owned
result to the adapter; it releases that result after conversion, including on
failure. A callback error prevents the outer call from publishing a successful
result. Recovery values follow the typed callback descriptor in the header.
Retaining a Lean closure that captured a host callback does not extend that
callback's call-scoped borrow. Retained host callbacks and asynchronous callbacks
are not supported.

Input, callback and output conversions enforce the limits recorded in
binding-manifest.json. Canonical scratch memory is capped at 64 MiB per active
store. These limits do not cap Lean algorithm, GMP or Wasmtime working memory.
Native conversion allocation failures return status codes and roll back partial
owners. Wasmtime and GMP allocation APIs do not expose recoverable out-of-memory
errors. See the header for status codes and individual function signatures.

## Loaded-library identity

Before entering Lean or Wasmtime, the host checks the loaded component, both Lean
runtime libraries, GMP and Wasmtime against their compiler receipt sizes and
SHA-256 hashes. A different library already loaded under the same name makes
public calls return a runtime error. All inherited host calls, including cleanup,
return a process error after fork; the parent retains responsibility for cleanup.

## Exports

- booking-span: lean:OwnedCheckedRecords.bookingSpan
- claim-closure: lean:OwnedCheckedRecords.claimClosure
- claim-for: lean:OwnedCheckedRecords.claimFor
- claim-quota: lean:OwnedCheckedRecords.claimQuota
- echo-booking: lean:OwnedCheckedRecords.echoBooking
- echo-claim: lean:OwnedCheckedRecords.echoClaim
- echo-claims: lean:OwnedCheckedRecords.echoClaims
- echo-grant: lean:OwnedCheckedRecords.echoGrant
- new-ticket: lean:OwnedCheckedRecords.newTicket
- pair-claim: lean:OwnedCheckedRecords.pairClaim
- serial: lean:OwnedCheckedRecords.serial
- transfer-claim: lean:OwnedCheckedRecords.transferClaim
- transfer-pair-claim: lean:OwnedCheckedRecords.transferPairClaim
- transfer-with-claim-callback: lean:OwnedCheckedRecords.transferWithClaimCallback
- with-claim-callback: lean:OwnedCheckedRecords.withClaimCallback
- invoke-identity-callback26621c40b48fce52ca37: bridge:Callback26621c40b48fce52ca37
- invoke-identity-callbackb2d3d6fd4e031785f278: bridge:Callbackb2d3d6fd4e031785f278
