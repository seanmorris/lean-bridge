#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif
#include <dlfcn.h>
#include <link.h>

#include <errno.h>
#include <fcntl.h>
#include <stdint.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

typedef struct {
  uint32_t words[8];
  uint64_t bytes;
  size_t used;
  unsigned char block[64];
} lb_receipt_hash;

static uint32_t lb_receipt_rotr(uint32_t x, unsigned n) {
  return (x >> n) | (x << (32u - n));
}
static void lb_receipt_block(lb_receipt_hash *hash, const unsigned char *block) {
  static const uint32_t constants[64] = {
    0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
    0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
    0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
    0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
    0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
    0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
    0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
    0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2
  };
  uint32_t w[64];
  for (size_t i = 0; i < 16; ++i)
    w[i] = ((uint32_t)block[4*i] << 24) | ((uint32_t)block[4*i+1] << 16)
      | ((uint32_t)block[4*i+2] << 8) | block[4*i+3];
  for (size_t i = 16; i < 64; ++i) {
    uint32_t x = w[i-15], y = w[i-2];
    w[i] = w[i-16] + (lb_receipt_rotr(x,7) ^ lb_receipt_rotr(x,18) ^ (x >> 3))
      + w[i-7] + (lb_receipt_rotr(y,17) ^ lb_receipt_rotr(y,19) ^ (y >> 10));
  }
  uint32_t a=hash->words[0], b=hash->words[1], c=hash->words[2], d=hash->words[3];
  uint32_t e=hash->words[4], f=hash->words[5], g=hash->words[6], h=hash->words[7];
  for (size_t i = 0; i < 64; ++i) {
    uint32_t t1 = h + (lb_receipt_rotr(e,6) ^ lb_receipt_rotr(e,11) ^ lb_receipt_rotr(e,25))
      + ((e & f) ^ (~e & g)) + constants[i] + w[i];
    uint32_t t2 = (lb_receipt_rotr(a,2) ^ lb_receipt_rotr(a,13) ^ lb_receipt_rotr(a,22))
      + ((a & b) ^ (a & c) ^ (b & c));
    h=g; g=f; f=e; e=d+t1; d=c; c=b; b=a; a=t1+t2;
  }
  hash->words[0]+=a; hash->words[1]+=b; hash->words[2]+=c; hash->words[3]+=d;
  hash->words[4]+=e; hash->words[5]+=f; hash->words[6]+=g; hash->words[7]+=h;
}
static void lb_receipt_update(lb_receipt_hash *hash, const unsigned char *bytes, size_t count) {
  hash->bytes += count;
  while (count) {
    size_t take = 64 - hash->used;
    if (take > count) take = count;
    memcpy(hash->block + hash->used, bytes, take);
    hash->used += take; bytes += take; count -= take;
    if (hash->used == 64) { lb_receipt_block(hash, hash->block); hash->used = 0; }
  }
}
static void lb_receipt_finish(lb_receipt_hash *hash, char out[65]) {
  static const char hex[] = "0123456789abcdef";
  uint64_t bits = hash->bytes * UINT64_C(8);
  unsigned char padding[128] = {0x80};
  size_t count = hash->used < 56 ? 56 - hash->used : 120 - hash->used;
  for (size_t i = 0; i < 8; ++i) padding[count+i] = (unsigned char)(bits >> (56-8*i));
  lb_receipt_update(hash, padding, count + 8);
  for (size_t i = 0; i < 32; ++i) {
    unsigned byte = (hash->words[i/4] >> (24-8*(i%4))) & 255u;
    out[2*i] = hex[byte >> 4]; out[2*i+1] = hex[byte & 15];
  }
  out[64] = 0;
}
static int lb_receipt_file_matches(const char *path, uint64_t bytes, const char *expected) {
  int fd = open(path, O_RDONLY | O_CLOEXEC | O_NOFOLLOW | O_NONBLOCK);
  if (fd < 0) return 0;
  struct stat before, after;
  int valid = !fstat(fd, &before) && S_ISREG(before.st_mode) && before.st_size >= 0
    && (uint64_t)before.st_size == bytes && bytes <= UINT64_MAX/8;
  lb_receipt_hash hash = {.words = {0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,
    0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19}};
  unsigned char buffer[16384];
  while (valid) {
    ssize_t count = read(fd, buffer, sizeof(buffer));
    if (count < 0 && errno == EINTR) continue;
    if (count < 0) { valid = 0; break; }
    if (!count) break;
    if ((uint64_t)count > bytes - hash.bytes) { valid = 0; break; }
    lb_receipt_update(&hash, buffer, (size_t)count);
  }
  valid = valid && hash.bytes == bytes && !fstat(fd, &after)
    && before.st_size == after.st_size
    && before.st_mtim.tv_sec == after.st_mtim.tv_sec && before.st_mtim.tv_nsec == after.st_mtim.tv_nsec
    && before.st_ctim.tv_sec == after.st_ctim.tv_sec && before.st_ctim.tv_nsec == after.st_ctim.tv_nsec;
  if (close(fd)) valid = 0;
  char actual[65]; lb_receipt_finish(&hash, actual);
  return valid && !strcmp(actual, expected);
}


static pid_t lb_package_pid;
/* Private loader handshake, not a consumer API. Keep each host's origin local
 * even when another host exports the same handshake symbol. */
__attribute__((visibility("default"))) pid_t __lean_bridge_wit_host_process_origin_v1(void) {
  return lb_package_pid;
}
static const char *lb_package_problem = "WIT package dependencies have not been verified";
static const struct { const char *name; uint64_t bytes; const char *sha256; } lb_package_libraries[] = {
  {"libcomponent_161bdaa35ee11fef40c6.so", UINT64_C(130744), "45d763ba43175f7a37a12de5778b84c3d487f4015ca1466cb562fa2f0a0eb495"},
  {"libgmp.so.10", UINT64_C(735208), "1980c7331f830ab5291a3ec606e03fdc4d00ce7b8a93da6c64da10806ea36cd7"},
  {"liblean_bridge_native.so", UINT64_C(21632), "459fcd2098d4b646ab6ae0f4cdccd1f222908cb162562bfc3940a533cd4e4e21"},
  {"libleanshared.so", UINT64_C(158401256), "d7768b88d8162736da4305777cd6f147676038fd885bd8a265c958b0ecea00b4"},
  {"libwasmtime.so", UINT64_C(22277728), "566e57cfeabafd6d44fab1b5e6660b4569a71aae4cff2e4d89563a424ee799f3"}
};
typedef struct { unsigned seen[5]; const char *failure; } lb_package_scan;
static int lb_package_process(struct dl_phdr_info *info, size_t size, void *data) {
  (void)size;
  lb_package_scan *scan = data;
  const char *path = info->dlpi_name;
  if (!path || !*path) return 0;
  const char *slash = strrchr(path, '/'), *name = slash ? slash+1 : path;
  const char suffix[] = "_wasmtime.so";
  size_t length = strlen(name);
  if (length <= 3 + sizeof(suffix)-1 || strncmp(name, "lib", 3)
      || strcmp(name+length-(sizeof(suffix)-1), suffix)) return 0;
  void *loaded = dlopen(path, RTLD_NOW | RTLD_NOLOAD);
  if (!loaded) { scan->failure = "Cannot inspect loaded WIT host"; return 1; }
  void *address = dlsym(loaded, "__lean_bridge_wit_host_process_origin_v1");
  Dl_info owner;
  /* dlsym also searches dependencies. Only use this library's own marker. */
  if (address && dladdr(address, &owner) && owner.dli_fbase == (void *)info->dlpi_addr) {
    pid_t (*origin)(void);
    _Static_assert(sizeof(origin) == sizeof(address), "POSIX function pointer");
    memcpy(&origin, &address, sizeof(origin));
    pid_t process = origin();
    /* A host whose constructor has not run yet has no Wasmtime state. */
    if (process && process != getpid())
      scan->failure = "WIT hosts cannot be used after fork; exec a fresh process";
  }
  dlclose(loaded);
  return scan->failure != NULL;
}
static int lb_package_library(struct dl_phdr_info *info, size_t size, void *data) {
  (void)size;
  lb_package_scan *scan = data;
  const char *path = info->dlpi_name;
  if (!path || !*path) return 0;
  const char *slash = strrchr(path, '/'), *name = slash ? slash+1 : path;
  for (size_t i = 0; i < sizeof(lb_package_libraries)/sizeof(lb_package_libraries[0]); ++i) {
    if (strcmp(name, lb_package_libraries[i].name)) continue;
    if (!lb_receipt_file_matches(path, lb_package_libraries[i].bytes, lb_package_libraries[i].sha256)) {
      scan->failure = "WIT package dependency conflict: loaded library differs from its receipt";
      return 1;
    }
    /* Resolve lazy dependency relocations before another host is loaded. */
    void *loaded = dlopen(path, RTLD_NOW | RTLD_NOLOAD);
    if (!loaded) { scan->failure = "Cannot bind verified WIT dependency"; return 1; }
    dlclose(loaded);
    scan->seen[i] = 1;
  }
  return 0;
}
__attribute__((constructor)) static void lb_package_verify(void) {
  lb_package_pid = getpid();
  lb_package_scan scan = {0};
  dl_iterate_phdr(lb_package_process, &scan);
  if (!scan.failure) dl_iterate_phdr(lb_package_library, &scan);
  for (size_t i = 0; i < sizeof(scan.seen)/sizeof(scan.seen[0]); ++i)
    if (!scan.seen[i] && !scan.failure) scan.failure = "WIT package dependency is missing from the loaded libraries";
  lb_package_problem = scan.failure;
}
static const char *lb_package_failure(void) {
  if (getpid() != lb_package_pid) return "WIT hosts cannot be used after fork; exec a fresh process";
  return lb_package_problem;
}
#include "owned_checked_records_wasmtime.h"
#include "owned-values.h"
#include "carriers.h"

#include <stddef.h>
#include <stdint.h>
#include <string.h>
#include "owned-leases.h"
_Static_assert(sizeof(void *) == 8 && sizeof(size_t) == 8, "owned native values require 64-bit Lean");
enum { OV_RESULT = 9 };
typedef struct {
  size_t bytes, visits;
  struct { const void *address; size_t type; } path[129];
} ov_budget;
typedef struct ov_allocation {
  struct ov_allocation *next;
  max_align_t alignment;
  unsigned char data[];
} ov_allocation;
typedef struct {
  lb_owned_scope scope;
  lb_owned_batch *input_owner;
  int input_transfer;
  ov_budget budget;
  ov_allocation *allocations;
} ov_transaction;
typedef struct ov_result_owner {
  struct ov_result_owner *self;
  lb_owned_context *context;
  lb_owned_batch batch;
  ov_allocation *allocations;
} ov_result_owner;

static inline void ov_release(ov_allocation *allocation) {
  while (allocation) {
    ov_allocation *next = allocation->next; LB_OWNED_FREE(allocation); allocation = next;
  }
}
static inline int ov_pointer(const void *value, size_t bytes, size_t alignment) {
  return value && (uintptr_t)value % alignment == 0 && bytes <= UINTPTR_MAX - (uintptr_t)value;
}
static inline int ov_charge(ov_budget *budget, size_t count, size_t width) {
  if (!width || count > budget->bytes / width) return LB_OWNED_LIMIT;
  budget->bytes -= count * width; return LB_OWNED_OK;
}
static inline int ov_visit(ov_budget *budget, size_t depth) {
  if (depth > 128 || !budget->visits) return LB_OWNED_LIMIT;
  --budget->visits; return LB_OWNED_OK;
}
static inline int ov_enter(ov_budget *budget, const void *value, size_t type, size_t depth) {
  int status = ov_visit(budget, depth);
  if (status) return status;
  for (size_t i = 0; i < depth; ++i)
    if (budget->path[i].address == value && budget->path[i].type == type) return LB_OWNED_INVALID;
  budget->path[depth].address = value; budget->path[depth].type = type;
  return LB_OWNED_OK;
}
static inline int ov_span(ov_budget *budget, const void *value, size_t count, size_t width, size_t alignment) {
  int status = ov_charge(budget, count, width);
  if (status) return status;
  return !count || ov_pointer(value, count * width, alignment) ? LB_OWNED_OK : LB_OWNED_INVALID;
}
static inline int ov_allocate(ov_transaction *transaction, size_t count, size_t width, void **out) {
  *out = NULL; if (!count) return LB_OWNED_OK;
  int status = ov_charge(&transaction->budget, count, width);
  if (!status) status = ov_charge(&transaction->budget, 1, sizeof(ov_allocation));
  if (status) return status;
  ov_allocation *allocation = LB_OWNED_ALLOC(sizeof(*allocation) + count * width);
  if (!allocation) return LB_OWNED_ALLOC_FAILED;
  allocation->next = transaction->allocations; transaction->allocations = allocation;
  memset(allocation->data, 0, count * width); *out = allocation->data; return LB_OWNED_OK;
}
static inline int ov_utf8(const uint8_t *data, size_t length) {
  size_t i = 0;
  while (i < length) {
    uint32_t point = data[i++], minimum; size_t extra;
    if (point < 0x80) continue;
    if (point >= 0xc2 && point <= 0xdf) { point &= 0x1f; extra = 1; minimum = 0x80; }
    else if (point >= 0xe0 && point <= 0xef) { point &= 0x0f; extra = 2; minimum = 0x800; }
    else if (point >= 0xf0 && point <= 0xf4) { point &= 7; extra = 3; minimum = 0x10000; }
    else return 0;
    if (extra > length - i) return 0;
    while (extra--) { uint8_t next = data[i++]; if ((next & 0xc0) != 0x80) return 0; point = (point << 6) | (next & 0x3f); }
    if (point < minimum || point > 0x10ffff || (point >= 0xd800 && point <= 0xdfff)) return 0;
  }
  return 1;
}
static inline lean_object *ov_nat_in(const uint32_t *data, size_t length) {
  lean_object *value = lean_box(0);
  while (length) {
    lean_object *shifted = lean_nat_shiftl(value, lean_box(32)); lean_dec(value);
    lean_object *limb = lean_uint32_to_nat(data[--length]);
    value = lean_nat_add(shifted, limb); lean_dec(shifted); lean_dec(limb);
  }
  return value;
}
static inline int ov_nat_out(lean_object *value, ov_transaction *transaction, const uint32_t **data, size_t *length) {
  *data = NULL; *length = 0;
  if (lean_nat_eq(value, lean_box(0))) return LB_OWNED_OK;
  lean_object *bits = lean_nat_log2(value);
  if (!lean_is_scalar(bits)) { lean_dec(bits); return LB_OWNED_LIMIT; }
  size_t count = lean_unbox(bits) / 32 + 1; lean_dec(bits);
  void *raw = NULL; int status = ov_allocate(transaction, count, sizeof(uint32_t), &raw);
  if (status) return status;
  uint32_t *limbs = raw; lean_inc(value);
  for (size_t i = 0; i < count; ++i) {
    limbs[i] = lean_uint32_of_nat(value);
    lean_object *next = lean_nat_shiftr(value, lean_box(32)); lean_dec(value); value = next;
  }
  lean_dec(value); *data = limbs; *length = count; return LB_OWNED_OK;
}
static inline lean_object *ov_carry(lean_object *value) {
  lean_object *carrier = lean_alloc_array(1, 1); lean_array_set_core(carrier, 0, value); return carrier;
}
static inline int ov_carrier(lean_object *value) {
  return value && !lean_is_scalar(value) && lean_is_array(value) && lean_array_size(value) == 1;
}
static inline int ov_finish(lean_object *value, lean_object **out) {
  if (!ov_carrier(value)) { if (value) lean_dec(value); return OV_RESULT; }
  *out = value; return LB_OWNED_OK;
}
static inline int ov_owner_empty(const ov_result_owner *owner) {
  return owner && !owner->self && !owner->context && !owner->allocations
    && !owner->batch.context && !owner->batch.entries && !owner->batch.next;
}
static inline int ov_owner_clear(ov_result_owner *owner) {
  if (!owner) return LB_OWNED_INVALID;
  if (ov_owner_empty(owner)) return LB_OWNED_OK;
  if (owner->self != owner || !owner->context) return LB_OWNED_INVALID;
  lb_owned_context *context = owner->context;
  if (context->self != context) return LB_OWNED_INVALID;
  if (context->process != getpid()) return LB_OWNED_PROCESS;
  if (!pthread_equal(context->thread, pthread_self()) || context->thread_serial != lb_owned_thread_serial)
    return LB_OWNED_THREAD;
  int status = LB_OWNED_OK;
  if (owner->batch.context) status = lb_owned_batch_release(context, &owner->batch);
  /* A broker error can be reported after release has drained the batch. */
  if (owner->batch.context) return status;
  ov_release(owner->allocations); *owner = (ov_result_owner){0}; return status;
}
static inline int ov_begin(ov_transaction *transaction, lb_owned_context *context, ov_result_owner *owner, const char *component) {
  if (!ov_owner_empty(owner)) return LB_OWNED_INVALID;
  int status = lb_owned_ready(context);
  if (status) return status;
  if (strcmp(context->component, component)) return LB_OWNED_INVALID;
  *transaction = (ov_transaction){0};
  transaction->budget.bytes = 16777216; transaction->budget.visits = 262144;
  return lb_owned_scope_begin(context, &transaction->scope);
}
static inline int ov_abort(ov_transaction *transaction, int status) {
  ov_release(transaction->allocations); transaction->allocations = NULL;
  if (transaction->scope.context) {
    if (status == OV_RESULT) lean_bridge_native_runtime_retire();
    int cleanup = lb_owned_scope_abort(&transaction->scope);
    if (!status) status = cleanup;
  }
  return status;
}
static inline int ov_commit(ov_transaction *transaction, ov_result_owner *owner) {
  lb_owned_context *context = transaction->scope.context;
  int status = lb_owned_scope_ready(&transaction->scope);
  if (status) return ov_abort(transaction, status);
  if (!transaction->allocations && !transaction->scope.outputs)
    return ov_abort(transaction, LB_OWNED_OK);
  status = lb_owned_scope_commit(&transaction->scope, &owner->batch);
  if (status) {
    /* Commit may have transferred outputs before dropping a failing input pin. */
    if (owner->batch.context) lb_owned_batch_release(context, &owner->batch);
    return ov_abort(transaction, status);
  }
  owner->self = owner; owner->context = context; owner->allocations = transaction->allocations;
  transaction->allocations = NULL; return LB_OWNED_OK;
}


typedef struct {
  ov_result_owner *const *owners;
  size_t count;
  void (*consume)(void *context);
  void *context;
  int consumed;
} ov_input_transfers;

static inline int ov_transfers_prepare(ov_transaction *transaction,
    ov_input_transfers *transfer, size_t expected, lb_owned_batch **batches,
    size_t *batch_count) {
  int status = lb_owned_scope_ready(&transaction->scope);
  if (status) return status;
  if (!ov_pointer(transfer, sizeof(*transfer), _Alignof(ov_input_transfers)) ||
      transfer->count != expected || transfer->consumed || !transfer->consume)
    return LB_OWNED_INVALID;
  if (expected > LB_OWNED_RETAINED_LIMIT) return LB_OWNED_LIMIT;
  status = ov_span(&transaction->budget, transfer->owners, expected,
      sizeof(ov_result_owner *), _Alignof(ov_result_owner *));
  if (status) return status;
  *batch_count = 0;
  for (size_t i = 0; i < expected; ++i) {
    ov_result_owner *owner = transfer->owners[i];
    if (!ov_pointer(owner, sizeof(*owner), _Alignof(ov_result_owner))) return LB_OWNED_INVALID;
    for (size_t j = 0; j < i; ++j)
      if (owner == transfer->owners[j]) return LB_OWNED_INVALID;
    /* Empty variants can have a public owner but no native allocation or batch.
       Its registration and session are validated by the public adapter. */
    if (ov_owner_empty(owner)) continue;
    if (owner->self != owner || owner->context != transaction->scope.context)
      return LB_OWNED_INVALID;
    lb_owned_batch *batch = transaction->scope.context->batches;
    while (batch && batch != &owner->batch) batch = batch->next;
    if (!batch) return LB_OWNED_INVALID;
    batches[(*batch_count)++] = batch;
  }
  return LB_OWNED_OK;
}


enum { OV_CALLBACK = 10 };
typedef struct ov_callback_frame {
  struct ov_callback_frame *parent;
  ov_transaction *transaction;
  int status;
} ov_callback_frame;
static _Thread_local ov_callback_frame *ov_active_callback_frame;
static inline void ov_callback_fail(ov_callback_frame *frame, int status) {
  if (frame && !frame->status) frame->status = status;
}

static inline int lbov_7fab4b2842f6c64d9621_vf790309465bbf573c7b9_in(const lbov_7fab4b2842f6c64d9621_tf790309465bbf573c7b9 *, size_t, int, ov_transaction *, lean_object **);
static inline int lbov_7fab4b2842f6c64d9621_vf790309465bbf573c7b9_out(lbov_7fab4b2842f6c64d9621_tf790309465bbf573c7b9 *, lean_object *, size_t, ov_transaction *);
static inline int lbov_7fab4b2842f6c64d9621_v160ce821a84f6887bbfd_in(const lbov_7fab4b2842f6c64d9621_t160ce821a84f6887bbfd *, size_t, int, ov_transaction *, lean_object **);
static inline int lbov_7fab4b2842f6c64d9621_v160ce821a84f6887bbfd_out(lbov_7fab4b2842f6c64d9621_t160ce821a84f6887bbfd *, lean_object *, size_t, ov_transaction *);
static inline int lbov_7fab4b2842f6c64d9621_v648974cffb2d6c1d7951_in(const lbov_7fab4b2842f6c64d9621_t648974cffb2d6c1d7951 *, size_t, int, ov_transaction *, lean_object **);
static inline int lbov_7fab4b2842f6c64d9621_v648974cffb2d6c1d7951_out(lbov_7fab4b2842f6c64d9621_t648974cffb2d6c1d7951 *, lean_object *, size_t, ov_transaction *);
static inline int lbov_7fab4b2842f6c64d9621_v5035e6ea0903f12776d9_in(const lbov_7fab4b2842f6c64d9621_t5035e6ea0903f12776d9 *, size_t, int, ov_transaction *, lean_object **);
static inline int lbov_7fab4b2842f6c64d9621_v5035e6ea0903f12776d9_out(lbov_7fab4b2842f6c64d9621_t5035e6ea0903f12776d9 *, lean_object *, size_t, ov_transaction *);
static inline int lbov_7fab4b2842f6c64d9621_v23107461f72b24c37654_in(const lbov_7fab4b2842f6c64d9621_t23107461f72b24c37654 *, size_t, int, ov_transaction *, lean_object **);
static inline int lbov_7fab4b2842f6c64d9621_v23107461f72b24c37654_out(lbov_7fab4b2842f6c64d9621_t23107461f72b24c37654 *, lean_object *, size_t, ov_transaction *);
static inline int lbov_7fab4b2842f6c64d9621_vb2825946e038e653bd2b_in(const lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b *, size_t, int, ov_transaction *, lean_object **);
static inline int lbov_7fab4b2842f6c64d9621_vb2825946e038e653bd2b_out(lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b *, lean_object *, size_t, ov_transaction *);
static inline int lbov_7fab4b2842f6c64d9621_v4ce841c87ea3b1559bfb_in(const lbov_7fab4b2842f6c64d9621_t4ce841c87ea3b1559bfb *, size_t, int, ov_transaction *, lean_object **);
static inline int lbov_7fab4b2842f6c64d9621_v4ce841c87ea3b1559bfb_out(lbov_7fab4b2842f6c64d9621_t4ce841c87ea3b1559bfb *, lean_object *, size_t, ov_transaction *);
static inline int lbov_7fab4b2842f6c64d9621_vd79b9bbde250ee1779da_in(const lbov_7fab4b2842f6c64d9621_td79b9bbde250ee1779da *, size_t, int, ov_transaction *, lean_object **);
static inline int lbov_7fab4b2842f6c64d9621_vd79b9bbde250ee1779da_out(lbov_7fab4b2842f6c64d9621_td79b9bbde250ee1779da *, lean_object *, size_t, ov_transaction *);
static inline int lbov_7fab4b2842f6c64d9621_v2a091437b2d587ce3891_in(const lbov_7fab4b2842f6c64d9621_t2a091437b2d587ce3891 *, size_t, int, ov_transaction *, lean_object **);
static inline int lbov_7fab4b2842f6c64d9621_v2a091437b2d587ce3891_out(lbov_7fab4b2842f6c64d9621_t2a091437b2d587ce3891 *, lean_object *, size_t, ov_transaction *);
static inline int lbov_7fab4b2842f6c64d9621_v167081552b6f9c1d1afd_in(const lbov_7fab4b2842f6c64d9621_t167081552b6f9c1d1afd *, size_t, int, ov_transaction *, lean_object **);
static inline int lbov_7fab4b2842f6c64d9621_v167081552b6f9c1d1afd_out(lbov_7fab4b2842f6c64d9621_t167081552b6f9c1d1afd *, lean_object *, size_t, ov_transaction *);
static inline int lbov_7fab4b2842f6c64d9621_vdc0347e1f7f5c4d928f1_in(const lbov_7fab4b2842f6c64d9621_tdc0347e1f7f5c4d928f1 *, size_t, int, ov_transaction *, lean_object **);
static inline int lbov_7fab4b2842f6c64d9621_vdc0347e1f7f5c4d928f1_out(lbov_7fab4b2842f6c64d9621_tdc0347e1f7f5c4d928f1 *, lean_object *, size_t, ov_transaction *);
static inline int lbov_7fab4b2842f6c64d9621_vf790309465bbf573c7b9_in(const lbov_7fab4b2842f6c64d9621_tf790309465bbf573c7b9 *value, size_t depth, int storage, ov_transaction *transaction, lean_object **out) {
  *out = NULL;
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_7fab4b2842f6c64d9621_tf790309465bbf573c7b9))) return LB_OWNED_INVALID;
  int status = ov_enter(&transaction->budget, value, 0, depth);
  if (!status && storage) status = ov_charge(&transaction->budget, 1, sizeof(*value));
  if (status) return status;
  if (value->length > transaction->budget.visits) return LB_OWNED_LIMIT;
  status = ov_span(&transaction->budget, value->data, value->length, sizeof(lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b), _Alignof(lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b));
  if (status) return status;
  lean_object *items = lean_alloc_array(0, value->length);
  for (size_t i = 0; i < value->length; ++i) {
    lean_object *child = NULL;
    status = lbov_7fab4b2842f6c64d9621_vb2825946e038e653bd2b_in(value->data + i, depth + 1, 0, transaction, &child);
    if (status) { lean_dec(items); return status; }
    items = lean_array_push(items, child);
  }
  return ov_finish(lean_bridge_owned_0d662a6486ef7827f9e97a02_tf790309465bbf573c7b9_make(items), out);
}
static inline int lbov_7fab4b2842f6c64d9621_vf790309465bbf573c7b9_out(lbov_7fab4b2842f6c64d9621_tf790309465bbf573c7b9 *out, lean_object *value, size_t depth, ov_transaction *transaction) {
  int status = ov_visit(&transaction->budget, depth);
  if (status) { if (value) lean_dec(value); return status; }
  if (!ov_carrier(value)) { if (value) lean_dec(value); return OV_RESULT; }
  size_t limit = transaction->budget.bytes / sizeof(lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b);
  if (limit > transaction->budget.visits) limit = transaction->budget.visits;
  if (depth == 128) limit = 0;
  value = lean_bridge_owned_0d662a6486ef7827f9e97a02_tf790309465bbf573c7b9_itemsBounded(value, lean_box(limit));
  if (!value || lean_is_scalar(value) || !lean_is_array(value)) { if (value) lean_dec(value); return OV_RESULT; }
  size_t count = lean_array_size(value);
  if (count > limit) { lean_dec(value); return LB_OWNED_LIMIT; }
  void *raw = NULL;
  status = ov_allocate(transaction, count, sizeof(lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b), &raw);
  out->data = raw; out->length = count; lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b *data = raw;
  for (size_t i = 0; !status && i < count; ++i) {
    lean_object *child = lean_array_get_core(value, i); lean_inc(child);
    status = lbov_7fab4b2842f6c64d9621_vb2825946e038e653bd2b_out(data + i, child, depth + 1, transaction);
  }
  lean_dec(value); return status;
}
static inline int lbov_7fab4b2842f6c64d9621_v160ce821a84f6887bbfd_in(const lbov_7fab4b2842f6c64d9621_t160ce821a84f6887bbfd *value, size_t depth, int storage, ov_transaction *transaction, lean_object **out) {
  *out = NULL;
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_7fab4b2842f6c64d9621_t160ce821a84f6887bbfd))) return LB_OWNED_INVALID;
  int status = ov_enter(&transaction->budget, value, 1, depth);
  if (!status && storage) status = ov_charge(&transaction->budget, 1, sizeof(*value));
  if (status) return status;
  if (value->tag > 1) return LB_OWNED_INVALID;
  if (!value->tag) return ov_finish(lean_bridge_owned_0d662a6486ef7827f9e97a02_t160ce821a84f6887bbfd_none(lean_box(0)), out);
  if (value->tag == 1) {
    lean_object *child = NULL;
    status = lbov_7fab4b2842f6c64d9621_vb2825946e038e653bd2b_in(value->f0, depth + 1, 1, transaction, &child);
    if (status) return status;
    return ov_finish(lean_bridge_owned_0d662a6486ef7827f9e97a02_t160ce821a84f6887bbfd_make0(child), out);
  }
  return LB_OWNED_INVALID;
}
static inline int lbov_7fab4b2842f6c64d9621_v160ce821a84f6887bbfd_out(lbov_7fab4b2842f6c64d9621_t160ce821a84f6887bbfd *out, lean_object *value, size_t depth, ov_transaction *transaction) {
  int status = ov_visit(&transaction->budget, depth);
  if (status) { if (value) lean_dec(value); return status; }
  if (!ov_carrier(value)) { if (value) lean_dec(value); return OV_RESULT; }
  lean_inc(value);
  uint32_t tag = lean_bridge_owned_0d662a6486ef7827f9e97a02_t160ce821a84f6887bbfd_branch(value);
  if (tag > 1) { lean_dec(value); return OV_RESULT; }
  out->tag = (uint8_t)tag;
  if (out->tag == 1) {
  if (!status) {
    void *raw = NULL;
    status = ov_allocate(transaction, 1, sizeof(lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b), &raw);
    out->f0 = raw;
    if (!status) {
      lean_inc(value);
      status = lbov_7fab4b2842f6c64d9621_vb2825946e038e653bd2b_out(raw, lean_bridge_owned_0d662a6486ef7827f9e97a02_t160ce821a84f6887bbfd_field0(value), depth + 1, transaction);
    }
  }
  }
  lean_dec(value); return status;
}
static inline int lbov_7fab4b2842f6c64d9621_v648974cffb2d6c1d7951_in(const lbov_7fab4b2842f6c64d9621_t648974cffb2d6c1d7951 *value, size_t depth, int storage, ov_transaction *transaction, lean_object **out) {
  *out = NULL;
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_7fab4b2842f6c64d9621_t648974cffb2d6c1d7951))) return LB_OWNED_INVALID;
  int status = ov_enter(&transaction->budget, value, 2, depth);
  if (!status && storage) status = ov_charge(&transaction->budget, 1, sizeof(*value));
  if (status) return status;
  lean_object *child = NULL;
  status = transaction->input_transfer
  ? lb_owned_scope_transfer_borrow(&transaction->scope, transaction->input_owner, "callable:owned-checked-records@1.0.0:bridge:Callback26621c40b48fce52ca37", value->token, &child)
  : lb_owned_scope_borrow(&transaction->scope, "callable:owned-checked-records@1.0.0:bridge:Callback26621c40b48fce52ca37", value->token, &child);
  if (status) return status;
  lean_inc(child); return ov_finish(ov_carry(child), out);
}
static inline int lbov_7fab4b2842f6c64d9621_v648974cffb2d6c1d7951_out(lbov_7fab4b2842f6c64d9621_t648974cffb2d6c1d7951 *out, lean_object *value, size_t depth, ov_transaction *transaction) {
  int status = ov_visit(&transaction->budget, depth);
  if (status) { if (value) lean_dec(value); return status; }
  if (!ov_carrier(value)) { if (value) lean_dec(value); return OV_RESULT; }
  lean_object *child = lean_array_get_core(value, 0);
  if (lean_is_scalar(child)) { lean_dec(value); return OV_RESULT; }
  if (lean_is_scalar(child) || !lean_is_closure(child)) { lean_dec(value); return OV_RESULT; }
  status = lb_owned_scope_acquire(&transaction->scope, "callable:owned-checked-records@1.0.0:bridge:Callback26621c40b48fce52ca37", child, &out->token);
  lean_dec(value); return status;
}
static inline int lbov_7fab4b2842f6c64d9621_v5035e6ea0903f12776d9_in(const lbov_7fab4b2842f6c64d9621_t5035e6ea0903f12776d9 *value, size_t depth, int storage, ov_transaction *transaction, lean_object **out) {
  *out = NULL;
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_7fab4b2842f6c64d9621_t5035e6ea0903f12776d9))) return LB_OWNED_INVALID;
  int status = ov_enter(&transaction->budget, value, 3, depth);
  if (!status && storage) status = ov_charge(&transaction->budget, 1, sizeof(*value));
  if (status) return status;
  lean_object *child = NULL;
  status = transaction->input_transfer
  ? lb_owned_scope_transfer_borrow(&transaction->scope, transaction->input_owner, "callable:owned-checked-records@1.0.0:bridge:Callbackb2d3d6fd4e031785f278", value->token, &child)
  : lb_owned_scope_borrow(&transaction->scope, "callable:owned-checked-records@1.0.0:bridge:Callbackb2d3d6fd4e031785f278", value->token, &child);
  if (status) return status;
  lean_inc(child); return ov_finish(ov_carry(child), out);
}
static inline int lbov_7fab4b2842f6c64d9621_v5035e6ea0903f12776d9_out(lbov_7fab4b2842f6c64d9621_t5035e6ea0903f12776d9 *out, lean_object *value, size_t depth, ov_transaction *transaction) {
  int status = ov_visit(&transaction->budget, depth);
  if (status) { if (value) lean_dec(value); return status; }
  if (!ov_carrier(value)) { if (value) lean_dec(value); return OV_RESULT; }
  lean_object *child = lean_array_get_core(value, 0);
  if (lean_is_scalar(child)) { lean_dec(value); return OV_RESULT; }
  if (lean_is_scalar(child) || !lean_is_closure(child)) { lean_dec(value); return OV_RESULT; }
  status = lb_owned_scope_acquire(&transaction->scope, "callable:owned-checked-records@1.0.0:bridge:Callbackb2d3d6fd4e031785f278", child, &out->token);
  lean_dec(value); return status;
}
__attribute__((noinline)) static lean_object *lbov_7fab4b2842f6c64d9621_v23107461f72b24c37654_make(lean_object *items) {
  lean_object *a0 = lean_array_get_core(items, 0); lean_inc(a0);
  lean_object *a1 = lean_array_get_core(items, 1); lean_inc(a1);
  lean_dec(items);
  return lean_bridge_owned_0d662a6486ef7827f9e97a02_t23107461f72b24c37654_make(a0, a1);
}
static inline int lbov_7fab4b2842f6c64d9621_v23107461f72b24c37654_in(const lbov_7fab4b2842f6c64d9621_t23107461f72b24c37654 *value, size_t depth, int storage, ov_transaction *transaction, lean_object **out) {
  *out = NULL;
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_7fab4b2842f6c64d9621_t23107461f72b24c37654))) return LB_OWNED_INVALID;
  int status = ov_enter(&transaction->budget, value, 4, depth);
  if (!status && storage) status = ov_charge(&transaction->budget, 1, sizeof(*value));
  if (status) return status;
  lean_object *items = lean_alloc_array(0, 2);
  lean_object *child = NULL;
  status = lbov_7fab4b2842f6c64d9621_vd79b9bbde250ee1779da_in(&value->f0, depth + 1, 0, transaction, &child);
  if (status) { lean_dec(items); return status; }
  items = lean_array_push(items, child);
  status = lbov_7fab4b2842f6c64d9621_v2a091437b2d587ce3891_in(value->f1, depth + 1, 1, transaction, &child);
  if (status) { lean_dec(items); return status; }
  items = lean_array_push(items, child);
  return ov_finish(lbov_7fab4b2842f6c64d9621_v23107461f72b24c37654_make(items), out);
}
static inline int lbov_7fab4b2842f6c64d9621_v23107461f72b24c37654_out(lbov_7fab4b2842f6c64d9621_t23107461f72b24c37654 *out, lean_object *value, size_t depth, ov_transaction *transaction) {
  int status = ov_visit(&transaction->budget, depth);
  if (status) { if (value) lean_dec(value); return status; }
  if (!ov_carrier(value)) { if (value) lean_dec(value); return OV_RESULT; }
  if (!status) {
    if (!status) {
      lean_inc(value);
      status = lbov_7fab4b2842f6c64d9621_vd79b9bbde250ee1779da_out(&out->f0, lean_bridge_owned_0d662a6486ef7827f9e97a02_t23107461f72b24c37654_field0(value), depth + 1, transaction);
    }
  }
  if (!status) {
    void *raw = NULL;
    status = ov_allocate(transaction, 1, sizeof(lbov_7fab4b2842f6c64d9621_t2a091437b2d587ce3891), &raw);
    out->f1 = raw;
    if (!status) {
      lean_inc(value);
      status = lbov_7fab4b2842f6c64d9621_v2a091437b2d587ce3891_out(raw, lean_bridge_owned_0d662a6486ef7827f9e97a02_t23107461f72b24c37654_field1(value), depth + 1, transaction);
    }
  }
  lean_dec(value); return status;
}
__attribute__((noinline)) static lean_object *lbov_7fab4b2842f6c64d9621_vb2825946e038e653bd2b_make(lean_object *items) {
  lean_object *a0 = lean_array_get_core(items, 0); lean_inc(a0);
  lean_object *a1 = lean_array_get_core(items, 1); lean_inc(a1);
  lean_dec(items);
  return lean_bridge_owned_0d662a6486ef7827f9e97a02_tb2825946e038e653bd2b_make(a0, a1);
}
static inline int lbov_7fab4b2842f6c64d9621_vb2825946e038e653bd2b_in(const lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b *value, size_t depth, int storage, ov_transaction *transaction, lean_object **out) {
  *out = NULL;
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b))) return LB_OWNED_INVALID;
  int status = ov_enter(&transaction->budget, value, 5, depth);
  if (!status && storage) status = ov_charge(&transaction->budget, 1, sizeof(*value));
  if (status) return status;
  lean_object *items = lean_alloc_array(0, 2);
  lean_object *child = NULL;
  status = lbov_7fab4b2842f6c64d9621_vd79b9bbde250ee1779da_in(&value->f0, depth + 1, 0, transaction, &child);
  if (status) { lean_dec(items); return status; }
  items = lean_array_push(items, child);
  status = lbov_7fab4b2842f6c64d9621_v167081552b6f9c1d1afd_in(&value->f1, depth + 1, 0, transaction, &child);
  if (status) { lean_dec(items); return status; }
  items = lean_array_push(items, child);
  return ov_finish(lbov_7fab4b2842f6c64d9621_vb2825946e038e653bd2b_make(items), out);
}
static inline int lbov_7fab4b2842f6c64d9621_vb2825946e038e653bd2b_out(lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b *out, lean_object *value, size_t depth, ov_transaction *transaction) {
  int status = ov_visit(&transaction->budget, depth);
  if (status) { if (value) lean_dec(value); return status; }
  if (!ov_carrier(value)) { if (value) lean_dec(value); return OV_RESULT; }
  if (!status) {
    if (!status) {
      lean_inc(value);
      status = lbov_7fab4b2842f6c64d9621_vd79b9bbde250ee1779da_out(&out->f0, lean_bridge_owned_0d662a6486ef7827f9e97a02_tb2825946e038e653bd2b_field0(value), depth + 1, transaction);
    }
  }
  if (!status) {
    if (!status) {
      lean_inc(value);
      status = lbov_7fab4b2842f6c64d9621_v167081552b6f9c1d1afd_out(&out->f1, lean_bridge_owned_0d662a6486ef7827f9e97a02_tb2825946e038e653bd2b_field1(value), depth + 1, transaction);
    }
  }
  lean_dec(value); return status;
}
__attribute__((noinline)) static lean_object *lbov_7fab4b2842f6c64d9621_v4ce841c87ea3b1559bfb_make(lean_object *items) {
  lean_object *a0 = lean_array_get_core(items, 0); lean_inc(a0);
  lean_object *a1 = lean_array_get_core(items, 1); lean_inc(a1);
  lean_object *a2 = lean_array_get_core(items, 2); lean_inc(a2);
  lean_dec(items);
  return lean_bridge_owned_0d662a6486ef7827f9e97a02_t4ce841c87ea3b1559bfb_make(a0, a1, a2);
}
static inline int lbov_7fab4b2842f6c64d9621_v4ce841c87ea3b1559bfb_in(const lbov_7fab4b2842f6c64d9621_t4ce841c87ea3b1559bfb *value, size_t depth, int storage, ov_transaction *transaction, lean_object **out) {
  *out = NULL;
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_7fab4b2842f6c64d9621_t4ce841c87ea3b1559bfb))) return LB_OWNED_INVALID;
  int status = ov_enter(&transaction->budget, value, 6, depth);
  if (!status && storage) status = ov_charge(&transaction->budget, 1, sizeof(*value));
  if (status) return status;
  lean_object *items = lean_alloc_array(0, 3);
  lean_object *child = NULL;
  status = lbov_7fab4b2842f6c64d9621_vd79b9bbde250ee1779da_in(&value->f0, depth + 1, 0, transaction, &child);
  if (status) { lean_dec(items); return status; }
  items = lean_array_push(items, child);
  status = lbov_7fab4b2842f6c64d9621_v167081552b6f9c1d1afd_in(&value->f1, depth + 1, 0, transaction, &child);
  if (status) { lean_dec(items); return status; }
  items = lean_array_push(items, child);
  status = lbov_7fab4b2842f6c64d9621_v167081552b6f9c1d1afd_in(&value->f2, depth + 1, 0, transaction, &child);
  if (status) { lean_dec(items); return status; }
  items = lean_array_push(items, child);
  return ov_finish(lbov_7fab4b2842f6c64d9621_v4ce841c87ea3b1559bfb_make(items), out);
}
static inline int lbov_7fab4b2842f6c64d9621_v4ce841c87ea3b1559bfb_out(lbov_7fab4b2842f6c64d9621_t4ce841c87ea3b1559bfb *out, lean_object *value, size_t depth, ov_transaction *transaction) {
  int status = ov_visit(&transaction->budget, depth);
  if (status) { if (value) lean_dec(value); return status; }
  if (!ov_carrier(value)) { if (value) lean_dec(value); return OV_RESULT; }
  if (!status) {
    if (!status) {
      lean_inc(value);
      status = lbov_7fab4b2842f6c64d9621_vd79b9bbde250ee1779da_out(&out->f0, lean_bridge_owned_0d662a6486ef7827f9e97a02_t4ce841c87ea3b1559bfb_field0(value), depth + 1, transaction);
    }
  }
  if (!status) {
    if (!status) {
      lean_inc(value);
      status = lbov_7fab4b2842f6c64d9621_v167081552b6f9c1d1afd_out(&out->f1, lean_bridge_owned_0d662a6486ef7827f9e97a02_t4ce841c87ea3b1559bfb_field1(value), depth + 1, transaction);
    }
  }
  if (!status) {
    if (!status) {
      lean_inc(value);
      status = lbov_7fab4b2842f6c64d9621_v167081552b6f9c1d1afd_out(&out->f2, lean_bridge_owned_0d662a6486ef7827f9e97a02_t4ce841c87ea3b1559bfb_field2(value), depth + 1, transaction);
    }
  }
  lean_dec(value); return status;
}
static inline int lbov_7fab4b2842f6c64d9621_vd79b9bbde250ee1779da_in(const lbov_7fab4b2842f6c64d9621_td79b9bbde250ee1779da *value, size_t depth, int storage, ov_transaction *transaction, lean_object **out) {
  *out = NULL;
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_7fab4b2842f6c64d9621_td79b9bbde250ee1779da))) return LB_OWNED_INVALID;
  int status = ov_enter(&transaction->budget, value, 7, depth);
  if (!status && storage) status = ov_charge(&transaction->budget, 1, sizeof(*value));
  if (status) return status;
  lean_object *child = NULL;
  status = transaction->input_transfer
  ? lb_owned_scope_transfer_borrow(&transaction->scope, transaction->input_owner, "resource:OwnedCheckedRecords.Ticket", value->token, &child)
  : lb_owned_scope_borrow(&transaction->scope, "resource:OwnedCheckedRecords.Ticket", value->token, &child);
  if (status) return status;
  lean_inc(child); return ov_finish(ov_carry(child), out);
}
static inline int lbov_7fab4b2842f6c64d9621_vd79b9bbde250ee1779da_out(lbov_7fab4b2842f6c64d9621_td79b9bbde250ee1779da *out, lean_object *value, size_t depth, ov_transaction *transaction) {
  int status = ov_visit(&transaction->budget, depth);
  if (status) { if (value) lean_dec(value); return status; }
  if (!ov_carrier(value)) { if (value) lean_dec(value); return OV_RESULT; }
  lean_object *child = lean_array_get_core(value, 0);
  if (lean_is_scalar(child)) { lean_dec(value); return OV_RESULT; }
  status = lb_owned_scope_acquire(&transaction->scope, "resource:OwnedCheckedRecords.Ticket", child, &out->token);
  lean_dec(value); return status;
}
__attribute__((noinline)) static lean_object *lbov_7fab4b2842f6c64d9621_v2a091437b2d587ce3891_make(lean_object *items) {
  lean_object *a0 = lean_array_get_core(items, 0); lean_inc(a0);
  lean_object *a1 = lean_array_get_core(items, 1); lean_inc(a1);
  lean_dec(items);
  return lean_bridge_owned_0d662a6486ef7827f9e97a02_t2a091437b2d587ce3891_make(a0, a1);
}
static inline int lbov_7fab4b2842f6c64d9621_v2a091437b2d587ce3891_in(const lbov_7fab4b2842f6c64d9621_t2a091437b2d587ce3891 *value, size_t depth, int storage, ov_transaction *transaction, lean_object **out) {
  *out = NULL;
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_7fab4b2842f6c64d9621_t2a091437b2d587ce3891))) return LB_OWNED_INVALID;
  int status = ov_enter(&transaction->budget, value, 8, depth);
  if (!status && storage) status = ov_charge(&transaction->budget, 1, sizeof(*value));
  if (status) return status;
  lean_object *items = lean_alloc_array(0, 2);
  lean_object *child = NULL;
  status = lbov_7fab4b2842f6c64d9621_v167081552b6f9c1d1afd_in(&value->f0, depth + 1, 0, transaction, &child);
  if (status) { lean_dec(items); return status; }
  items = lean_array_push(items, child);
  status = lbov_7fab4b2842f6c64d9621_v167081552b6f9c1d1afd_in(&value->f1, depth + 1, 0, transaction, &child);
  if (status) { lean_dec(items); return status; }
  items = lean_array_push(items, child);
  return ov_finish(lbov_7fab4b2842f6c64d9621_v2a091437b2d587ce3891_make(items), out);
}
static inline int lbov_7fab4b2842f6c64d9621_v2a091437b2d587ce3891_out(lbov_7fab4b2842f6c64d9621_t2a091437b2d587ce3891 *out, lean_object *value, size_t depth, ov_transaction *transaction) {
  int status = ov_visit(&transaction->budget, depth);
  if (status) { if (value) lean_dec(value); return status; }
  if (!ov_carrier(value)) { if (value) lean_dec(value); return OV_RESULT; }
  if (!status) {
    if (!status) {
      lean_inc(value);
      status = lbov_7fab4b2842f6c64d9621_v167081552b6f9c1d1afd_out(&out->f0, lean_bridge_owned_0d662a6486ef7827f9e97a02_t2a091437b2d587ce3891_field0(value), depth + 1, transaction);
    }
  }
  if (!status) {
    if (!status) {
      lean_inc(value);
      status = lbov_7fab4b2842f6c64d9621_v167081552b6f9c1d1afd_out(&out->f1, lean_bridge_owned_0d662a6486ef7827f9e97a02_t2a091437b2d587ce3891_field1(value), depth + 1, transaction);
    }
  }
  lean_dec(value); return status;
}
static inline int lbov_7fab4b2842f6c64d9621_v167081552b6f9c1d1afd_in(const lbov_7fab4b2842f6c64d9621_t167081552b6f9c1d1afd *value, size_t depth, int storage, ov_transaction *transaction, lean_object **out) {
  *out = NULL;
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_7fab4b2842f6c64d9621_t167081552b6f9c1d1afd))) return LB_OWNED_INVALID;
  int status = ov_enter(&transaction->budget, value, 9, depth);
  if (!status && storage) status = ov_charge(&transaction->budget, 1, sizeof(*value));
  if (status) return status;
  status = ov_span(&transaction->budget, value->data, value->length, sizeof(uint32_t), _Alignof(uint32_t));
  if (status) return status;
  return ov_finish(ov_carry(ov_nat_in(value->data, value->length)), out);
}
static inline int lbov_7fab4b2842f6c64d9621_v167081552b6f9c1d1afd_out(lbov_7fab4b2842f6c64d9621_t167081552b6f9c1d1afd *out, lean_object *value, size_t depth, ov_transaction *transaction) {
  int status = ov_visit(&transaction->budget, depth);
  if (status) { if (value) lean_dec(value); return status; }
  if (!ov_carrier(value)) { if (value) lean_dec(value); return OV_RESULT; }
  lean_object *child = lean_array_get_core(value, 0); lean_inc(child); lean_dec(value);
  if (!lean_is_scalar(child) && !lean_is_mpz(child)) { lean_dec(child); return OV_RESULT; }
  status = ov_nat_out(child, transaction, &out->data, &out->length);
  lean_dec(child); return status;
}
static inline int lbov_7fab4b2842f6c64d9621_vdc0347e1f7f5c4d928f1_in(const lbov_7fab4b2842f6c64d9621_tdc0347e1f7f5c4d928f1 *value, size_t depth, int storage, ov_transaction *transaction, lean_object **out) {
  *out = NULL;
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_7fab4b2842f6c64d9621_tdc0347e1f7f5c4d928f1))) return LB_OWNED_INVALID;
  int status = ov_enter(&transaction->budget, value, 10, depth);
  if (!status && storage) status = ov_charge(&transaction->budget, 1, sizeof(*value));
  if (status) return status;
  status = ov_span(&transaction->budget, value->data, value->length, 1, 1);
  if (status) return status;
  if (!ov_utf8((const uint8_t *)value->data, value->length)) return LB_OWNED_INVALID;
  return ov_finish(ov_carry(lean_mk_string_from_bytes(value->length ? value->data : "", value->length)), out);
}
static inline int lbov_7fab4b2842f6c64d9621_vdc0347e1f7f5c4d928f1_out(lbov_7fab4b2842f6c64d9621_tdc0347e1f7f5c4d928f1 *out, lean_object *value, size_t depth, ov_transaction *transaction) {
  int status = ov_visit(&transaction->budget, depth);
  if (status) { if (value) lean_dec(value); return status; }
  if (!ov_carrier(value)) { if (value) lean_dec(value); return OV_RESULT; }
  lean_object *child = lean_array_get_core(value, 0); lean_inc(child); lean_dec(value);
  if (lean_is_scalar(child) || !lean_is_string(child)) { lean_dec(child); return OV_RESULT; }
  size_t length = lean_string_size(child) - 1;
  if (!ov_utf8((const uint8_t *)lean_string_cstr(child), length)) { lean_dec(child); return OV_RESULT; }
  void *data = NULL;
  status = ov_allocate(transaction, length, 1, &data);
  if (!status) {
    if (length) memcpy(data, lean_string_cstr(child), length);
    out->data = data; out->length = length;
  }
  lean_dec(child); return status;
}
static inline int lbov_7fab4b2842f6c64d9621_f61fa6d001212787ff6aa(lb_owned_context *context, const lbov_7fab4b2842f6c64d9621_t23107461f72b24c37654 *a0, lbov_7fab4b2842f6c64d9621_t167081552b6f9c1d1afd *out, ov_result_owner *owner) {
  if (!ov_pointer(out, sizeof(*out), _Alignof(lbov_7fab4b2842f6c64d9621_t167081552b6f9c1d1afd)) || !ov_pointer(owner, sizeof(*owner), _Alignof(ov_result_owner))) return LB_OWNED_INVALID;
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  status = ov_charge(&transaction.budget, 1, sizeof(*out));
  if (status) return ov_abort(&transaction, status);
  lean_object *arguments = lean_alloc_array(0, 1);
  {
    lean_object *child = NULL;
    status = lbov_7fab4b2842f6c64d9621_v23107461f72b24c37654_in(a0, 0, 1, &transaction, &child);
    if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
    lean_inc(child);
    if (!lean_bridge_owned_refine_5ba8ebacbf26c0755e45(child)) { lean_dec(child); lean_dec(arguments); return ov_abort(&transaction, LB_OWNED_INVALID); }
    arguments = lean_array_push(arguments, child);
  }
  lean_object *v0 = lean_array_get_core(arguments, 0); lean_inc(v0);
  lean_dec(arguments);
  ov_callback_frame frame = { .parent = ov_active_callback_frame, .transaction = &transaction };
  if (!frame.parent) { (void)lb_native_callback_take_error(); (void)lean_bridge_owned_callback_failure_7fab4b2842f6c64d9621(); }
  ov_active_callback_frame = &frame;
  lean_object *returned = lean_bridge_owned_0d662a6486ef7827f9e97a02_f61fa6d001212787ff6aa(v0);
  ov_active_callback_frame = frame.parent; status = frame.status;
  int callback_error = lb_native_callback_take_error();
  int refinement_error = lean_bridge_owned_callback_failure_7fab4b2842f6c64d9621();
  if (refinement_error && !status) status = LB_OWNED_INVALID;
  else if (callback_error && !status) status = OV_CALLBACK;
  if (!status) status = lb_owned_scope_ready(&transaction.scope);
  if (status) { lean_dec(returned); return ov_abort(&transaction, status); }
  lbov_7fab4b2842f6c64d9621_t167081552b6f9c1d1afd converted = {0};
  status = lbov_7fab4b2842f6c64d9621_v167081552b6f9c1d1afd_out(&converted, returned, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  status = ov_commit(&transaction, owner);
  if (!status) *out = converted;
  return status;
}
static inline int lbov_7fab4b2842f6c64d9621_fa3218a29f42862f9b113(lb_owned_context *context, lbov_7fab4b2842f6c64d9621_t648974cffb2d6c1d7951 *out, ov_result_owner *owner) {
  if (!ov_pointer(out, sizeof(*out), _Alignof(lbov_7fab4b2842f6c64d9621_t648974cffb2d6c1d7951)) || !ov_pointer(owner, sizeof(*owner), _Alignof(ov_result_owner))) return LB_OWNED_INVALID;
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  status = ov_charge(&transaction.budget, 1, sizeof(*out));
  if (status) return ov_abort(&transaction, status);
  lean_object *arguments = lean_alloc_array(0, 0);
  lean_dec(arguments);
  ov_callback_frame frame = { .parent = ov_active_callback_frame, .transaction = &transaction };
  if (!frame.parent) { (void)lb_native_callback_take_error(); (void)lean_bridge_owned_callback_failure_7fab4b2842f6c64d9621(); }
  ov_active_callback_frame = &frame;
  lean_object *returned = lean_bridge_owned_0d662a6486ef7827f9e97a02_fa3218a29f42862f9b113(lean_box(0));
  ov_active_callback_frame = frame.parent; status = frame.status;
  int callback_error = lb_native_callback_take_error();
  int refinement_error = lean_bridge_owned_callback_failure_7fab4b2842f6c64d9621();
  if (refinement_error && !status) status = LB_OWNED_INVALID;
  else if (callback_error && !status) status = OV_CALLBACK;
  if (!status) status = lb_owned_scope_ready(&transaction.scope);
  if (status) { lean_dec(returned); return ov_abort(&transaction, status); }
  lbov_7fab4b2842f6c64d9621_t648974cffb2d6c1d7951 converted = {0};
  status = lbov_7fab4b2842f6c64d9621_v648974cffb2d6c1d7951_out(&converted, returned, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  status = ov_commit(&transaction, owner);
  if (!status) *out = converted;
  return status;
}
static inline int lbov_7fab4b2842f6c64d9621_f483485736ace9af57086(lb_owned_context *context, const lbov_7fab4b2842f6c64d9621_td79b9bbde250ee1779da *a0, lbov_7fab4b2842f6c64d9621_t160ce821a84f6887bbfd *out, ov_result_owner *owner) {
  if (!ov_pointer(out, sizeof(*out), _Alignof(lbov_7fab4b2842f6c64d9621_t160ce821a84f6887bbfd)) || !ov_pointer(owner, sizeof(*owner), _Alignof(ov_result_owner))) return LB_OWNED_INVALID;
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  status = ov_charge(&transaction.budget, 1, sizeof(*out));
  if (status) return ov_abort(&transaction, status);
  lean_object *arguments = lean_alloc_array(0, 1);
  {
    lean_object *child = NULL;
    status = lbov_7fab4b2842f6c64d9621_vd79b9bbde250ee1779da_in(a0, 0, 1, &transaction, &child);
    if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
    arguments = lean_array_push(arguments, child);
  }
  lean_object *v0 = lean_array_get_core(arguments, 0); lean_inc(v0);
  lean_dec(arguments);
  ov_callback_frame frame = { .parent = ov_active_callback_frame, .transaction = &transaction };
  if (!frame.parent) { (void)lb_native_callback_take_error(); (void)lean_bridge_owned_callback_failure_7fab4b2842f6c64d9621(); }
  ov_active_callback_frame = &frame;
  lean_object *returned = lean_bridge_owned_0d662a6486ef7827f9e97a02_f483485736ace9af57086(v0);
  ov_active_callback_frame = frame.parent; status = frame.status;
  int callback_error = lb_native_callback_take_error();
  int refinement_error = lean_bridge_owned_callback_failure_7fab4b2842f6c64d9621();
  if (refinement_error && !status) status = LB_OWNED_INVALID;
  else if (callback_error && !status) status = OV_CALLBACK;
  if (!status) status = lb_owned_scope_ready(&transaction.scope);
  if (status) { lean_dec(returned); return ov_abort(&transaction, status); }
  lbov_7fab4b2842f6c64d9621_t160ce821a84f6887bbfd converted = {0};
  status = lbov_7fab4b2842f6c64d9621_v160ce821a84f6887bbfd_out(&converted, returned, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  status = ov_commit(&transaction, owner);
  if (!status) *out = converted;
  return status;
}
static inline int lbov_7fab4b2842f6c64d9621_f2f69e4eb3cbfdff310da(lb_owned_context *context, const lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b *a0, lbov_7fab4b2842f6c64d9621_t167081552b6f9c1d1afd *out, ov_result_owner *owner) {
  if (!ov_pointer(out, sizeof(*out), _Alignof(lbov_7fab4b2842f6c64d9621_t167081552b6f9c1d1afd)) || !ov_pointer(owner, sizeof(*owner), _Alignof(ov_result_owner))) return LB_OWNED_INVALID;
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  status = ov_charge(&transaction.budget, 1, sizeof(*out));
  if (status) return ov_abort(&transaction, status);
  lean_object *arguments = lean_alloc_array(0, 1);
  {
    lean_object *child = NULL;
    status = lbov_7fab4b2842f6c64d9621_vb2825946e038e653bd2b_in(a0, 0, 1, &transaction, &child);
    if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
    lean_inc(child);
    if (!lean_bridge_owned_refine_ca177b2570793a278657(child)) { lean_dec(child); lean_dec(arguments); return ov_abort(&transaction, LB_OWNED_INVALID); }
    arguments = lean_array_push(arguments, child);
  }
  lean_object *v0 = lean_array_get_core(arguments, 0); lean_inc(v0);
  lean_dec(arguments);
  ov_callback_frame frame = { .parent = ov_active_callback_frame, .transaction = &transaction };
  if (!frame.parent) { (void)lb_native_callback_take_error(); (void)lean_bridge_owned_callback_failure_7fab4b2842f6c64d9621(); }
  ov_active_callback_frame = &frame;
  lean_object *returned = lean_bridge_owned_0d662a6486ef7827f9e97a02_f2f69e4eb3cbfdff310da(v0);
  ov_active_callback_frame = frame.parent; status = frame.status;
  int callback_error = lb_native_callback_take_error();
  int refinement_error = lean_bridge_owned_callback_failure_7fab4b2842f6c64d9621();
  if (refinement_error && !status) status = LB_OWNED_INVALID;
  else if (callback_error && !status) status = OV_CALLBACK;
  if (!status) status = lb_owned_scope_ready(&transaction.scope);
  if (status) { lean_dec(returned); return ov_abort(&transaction, status); }
  lbov_7fab4b2842f6c64d9621_t167081552b6f9c1d1afd converted = {0};
  status = lbov_7fab4b2842f6c64d9621_v167081552b6f9c1d1afd_out(&converted, returned, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  status = ov_commit(&transaction, owner);
  if (!status) *out = converted;
  return status;
}
static inline int lbov_7fab4b2842f6c64d9621_f0711e856cfa97d876c9a(lb_owned_context *context, const lbov_7fab4b2842f6c64d9621_t23107461f72b24c37654 *a0, lbov_7fab4b2842f6c64d9621_t23107461f72b24c37654 *out, ov_result_owner *owner) {
  if (!ov_pointer(out, sizeof(*out), _Alignof(lbov_7fab4b2842f6c64d9621_t23107461f72b24c37654)) || !ov_pointer(owner, sizeof(*owner), _Alignof(ov_result_owner))) return LB_OWNED_INVALID;
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  status = ov_charge(&transaction.budget, 1, sizeof(*out));
  if (status) return ov_abort(&transaction, status);
  lean_object *arguments = lean_alloc_array(0, 1);
  {
    lean_object *child = NULL;
    status = lbov_7fab4b2842f6c64d9621_v23107461f72b24c37654_in(a0, 0, 1, &transaction, &child);
    if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
    lean_inc(child);
    if (!lean_bridge_owned_refine_5ba8ebacbf26c0755e45(child)) { lean_dec(child); lean_dec(arguments); return ov_abort(&transaction, LB_OWNED_INVALID); }
    arguments = lean_array_push(arguments, child);
  }
  lean_object *v0 = lean_array_get_core(arguments, 0); lean_inc(v0);
  lean_dec(arguments);
  ov_callback_frame frame = { .parent = ov_active_callback_frame, .transaction = &transaction };
  if (!frame.parent) { (void)lb_native_callback_take_error(); (void)lean_bridge_owned_callback_failure_7fab4b2842f6c64d9621(); }
  ov_active_callback_frame = &frame;
  lean_object *returned = lean_bridge_owned_0d662a6486ef7827f9e97a02_f0711e856cfa97d876c9a(v0);
  ov_active_callback_frame = frame.parent; status = frame.status;
  int callback_error = lb_native_callback_take_error();
  int refinement_error = lean_bridge_owned_callback_failure_7fab4b2842f6c64d9621();
  if (refinement_error && !status) status = LB_OWNED_INVALID;
  else if (callback_error && !status) status = OV_CALLBACK;
  if (!status) status = lb_owned_scope_ready(&transaction.scope);
  if (status) { lean_dec(returned); return ov_abort(&transaction, status); }
  lbov_7fab4b2842f6c64d9621_t23107461f72b24c37654 converted = {0};
  status = lbov_7fab4b2842f6c64d9621_v23107461f72b24c37654_out(&converted, returned, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  status = ov_commit(&transaction, owner);
  if (!status) *out = converted;
  return status;
}
static inline int lbov_7fab4b2842f6c64d9621_f535babcfd8d0f67ea0e6(lb_owned_context *context, const lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b *a0, lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b *out, ov_result_owner *owner) {
  if (!ov_pointer(out, sizeof(*out), _Alignof(lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b)) || !ov_pointer(owner, sizeof(*owner), _Alignof(ov_result_owner))) return LB_OWNED_INVALID;
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  status = ov_charge(&transaction.budget, 1, sizeof(*out));
  if (status) return ov_abort(&transaction, status);
  lean_object *arguments = lean_alloc_array(0, 1);
  {
    lean_object *child = NULL;
    status = lbov_7fab4b2842f6c64d9621_vb2825946e038e653bd2b_in(a0, 0, 1, &transaction, &child);
    if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
    lean_inc(child);
    if (!lean_bridge_owned_refine_ca177b2570793a278657(child)) { lean_dec(child); lean_dec(arguments); return ov_abort(&transaction, LB_OWNED_INVALID); }
    arguments = lean_array_push(arguments, child);
  }
  lean_object *v0 = lean_array_get_core(arguments, 0); lean_inc(v0);
  lean_dec(arguments);
  ov_callback_frame frame = { .parent = ov_active_callback_frame, .transaction = &transaction };
  if (!frame.parent) { (void)lb_native_callback_take_error(); (void)lean_bridge_owned_callback_failure_7fab4b2842f6c64d9621(); }
  ov_active_callback_frame = &frame;
  lean_object *returned = lean_bridge_owned_0d662a6486ef7827f9e97a02_f535babcfd8d0f67ea0e6(v0);
  ov_active_callback_frame = frame.parent; status = frame.status;
  int callback_error = lb_native_callback_take_error();
  int refinement_error = lean_bridge_owned_callback_failure_7fab4b2842f6c64d9621();
  if (refinement_error && !status) status = LB_OWNED_INVALID;
  else if (callback_error && !status) status = OV_CALLBACK;
  if (!status) status = lb_owned_scope_ready(&transaction.scope);
  if (status) { lean_dec(returned); return ov_abort(&transaction, status); }
  lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b converted = {0};
  status = lbov_7fab4b2842f6c64d9621_vb2825946e038e653bd2b_out(&converted, returned, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  status = ov_commit(&transaction, owner);
  if (!status) *out = converted;
  return status;
}
static inline int lbov_7fab4b2842f6c64d9621_f25326d75f45c4daa9d9d(lb_owned_context *context, const lbov_7fab4b2842f6c64d9621_tf790309465bbf573c7b9 *a0, lbov_7fab4b2842f6c64d9621_tf790309465bbf573c7b9 *out, ov_result_owner *owner) {
  if (!ov_pointer(out, sizeof(*out), _Alignof(lbov_7fab4b2842f6c64d9621_tf790309465bbf573c7b9)) || !ov_pointer(owner, sizeof(*owner), _Alignof(ov_result_owner))) return LB_OWNED_INVALID;
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  status = ov_charge(&transaction.budget, 1, sizeof(*out));
  if (status) return ov_abort(&transaction, status);
  lean_object *arguments = lean_alloc_array(0, 1);
  {
    lean_object *child = NULL;
    status = lbov_7fab4b2842f6c64d9621_vf790309465bbf573c7b9_in(a0, 0, 1, &transaction, &child);
    if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
    lean_inc(child);
    if (!lean_bridge_owned_refine_be1666fcf441d2cede51(child)) { lean_dec(child); lean_dec(arguments); return ov_abort(&transaction, LB_OWNED_INVALID); }
    arguments = lean_array_push(arguments, child);
  }
  lean_object *v0 = lean_array_get_core(arguments, 0); lean_inc(v0);
  lean_dec(arguments);
  ov_callback_frame frame = { .parent = ov_active_callback_frame, .transaction = &transaction };
  if (!frame.parent) { (void)lb_native_callback_take_error(); (void)lean_bridge_owned_callback_failure_7fab4b2842f6c64d9621(); }
  ov_active_callback_frame = &frame;
  lean_object *returned = lean_bridge_owned_0d662a6486ef7827f9e97a02_f25326d75f45c4daa9d9d(v0);
  ov_active_callback_frame = frame.parent; status = frame.status;
  int callback_error = lb_native_callback_take_error();
  int refinement_error = lean_bridge_owned_callback_failure_7fab4b2842f6c64d9621();
  if (refinement_error && !status) status = LB_OWNED_INVALID;
  else if (callback_error && !status) status = OV_CALLBACK;
  if (!status) status = lb_owned_scope_ready(&transaction.scope);
  if (status) { lean_dec(returned); return ov_abort(&transaction, status); }
  lbov_7fab4b2842f6c64d9621_tf790309465bbf573c7b9 converted = {0};
  status = lbov_7fab4b2842f6c64d9621_vf790309465bbf573c7b9_out(&converted, returned, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  status = ov_commit(&transaction, owner);
  if (!status) *out = converted;
  return status;
}
static inline int lbov_7fab4b2842f6c64d9621_feb082cf837ef02082ea8(lb_owned_context *context, const lbov_7fab4b2842f6c64d9621_t4ce841c87ea3b1559bfb *a0, lbov_7fab4b2842f6c64d9621_t4ce841c87ea3b1559bfb *out, ov_result_owner *owner) {
  if (!ov_pointer(out, sizeof(*out), _Alignof(lbov_7fab4b2842f6c64d9621_t4ce841c87ea3b1559bfb)) || !ov_pointer(owner, sizeof(*owner), _Alignof(ov_result_owner))) return LB_OWNED_INVALID;
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  status = ov_charge(&transaction.budget, 1, sizeof(*out));
  if (status) return ov_abort(&transaction, status);
  lean_object *arguments = lean_alloc_array(0, 1);
  {
    lean_object *child = NULL;
    status = lbov_7fab4b2842f6c64d9621_v4ce841c87ea3b1559bfb_in(a0, 0, 1, &transaction, &child);
    if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
    lean_inc(child);
    if (!lean_bridge_owned_refine_5593f0b9830f059702a4(child)) { lean_dec(child); lean_dec(arguments); return ov_abort(&transaction, LB_OWNED_INVALID); }
    arguments = lean_array_push(arguments, child);
  }
  lean_object *v0 = lean_array_get_core(arguments, 0); lean_inc(v0);
  lean_dec(arguments);
  ov_callback_frame frame = { .parent = ov_active_callback_frame, .transaction = &transaction };
  if (!frame.parent) { (void)lb_native_callback_take_error(); (void)lean_bridge_owned_callback_failure_7fab4b2842f6c64d9621(); }
  ov_active_callback_frame = &frame;
  lean_object *returned = lean_bridge_owned_0d662a6486ef7827f9e97a02_feb082cf837ef02082ea8(v0);
  ov_active_callback_frame = frame.parent; status = frame.status;
  int callback_error = lb_native_callback_take_error();
  int refinement_error = lean_bridge_owned_callback_failure_7fab4b2842f6c64d9621();
  if (refinement_error && !status) status = LB_OWNED_INVALID;
  else if (callback_error && !status) status = OV_CALLBACK;
  if (!status) status = lb_owned_scope_ready(&transaction.scope);
  if (status) { lean_dec(returned); return ov_abort(&transaction, status); }
  lbov_7fab4b2842f6c64d9621_t4ce841c87ea3b1559bfb converted = {0};
  status = lbov_7fab4b2842f6c64d9621_v4ce841c87ea3b1559bfb_out(&converted, returned, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  status = ov_commit(&transaction, owner);
  if (!status) *out = converted;
  return status;
}
static inline int lbov_7fab4b2842f6c64d9621_fa1e5189bd92568e4b939(lb_owned_context *context, const lbov_7fab4b2842f6c64d9621_t167081552b6f9c1d1afd *a0, const lbov_7fab4b2842f6c64d9621_tdc0347e1f7f5c4d928f1 *a1, lbov_7fab4b2842f6c64d9621_td79b9bbde250ee1779da *out, ov_result_owner *owner) {
  if (!ov_pointer(out, sizeof(*out), _Alignof(lbov_7fab4b2842f6c64d9621_td79b9bbde250ee1779da)) || !ov_pointer(owner, sizeof(*owner), _Alignof(ov_result_owner))) return LB_OWNED_INVALID;
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  status = ov_charge(&transaction.budget, 1, sizeof(*out));
  if (status) return ov_abort(&transaction, status);
  lean_object *arguments = lean_alloc_array(0, 2);
  {
    lean_object *child = NULL;
    status = lbov_7fab4b2842f6c64d9621_v167081552b6f9c1d1afd_in(a0, 0, 1, &transaction, &child);
    if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
    arguments = lean_array_push(arguments, child);
  }
  {
    lean_object *child = NULL;
    status = lbov_7fab4b2842f6c64d9621_vdc0347e1f7f5c4d928f1_in(a1, 0, 1, &transaction, &child);
    if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
    arguments = lean_array_push(arguments, child);
  }
  lean_object *v0 = lean_array_get_core(arguments, 0); lean_inc(v0);
  lean_object *v1 = lean_array_get_core(arguments, 1); lean_inc(v1);
  lean_dec(arguments);
  ov_callback_frame frame = { .parent = ov_active_callback_frame, .transaction = &transaction };
  if (!frame.parent) { (void)lb_native_callback_take_error(); (void)lean_bridge_owned_callback_failure_7fab4b2842f6c64d9621(); }
  ov_active_callback_frame = &frame;
  lean_object *returned = lean_bridge_owned_0d662a6486ef7827f9e97a02_fa1e5189bd92568e4b939(v0, v1);
  ov_active_callback_frame = frame.parent; status = frame.status;
  int callback_error = lb_native_callback_take_error();
  int refinement_error = lean_bridge_owned_callback_failure_7fab4b2842f6c64d9621();
  if (refinement_error && !status) status = LB_OWNED_INVALID;
  else if (callback_error && !status) status = OV_CALLBACK;
  if (!status) status = lb_owned_scope_ready(&transaction.scope);
  if (status) { lean_dec(returned); return ov_abort(&transaction, status); }
  lbov_7fab4b2842f6c64d9621_td79b9bbde250ee1779da converted = {0};
  status = lbov_7fab4b2842f6c64d9621_vd79b9bbde250ee1779da_out(&converted, returned, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  status = ov_commit(&transaction, owner);
  if (!status) *out = converted;
  return status;
}
static inline int lbov_7fab4b2842f6c64d9621_feaac3cc8d9197bd7bbca(lb_owned_context *context, const lbov_7fab4b2842f6c64d9621_t23107461f72b24c37654 *a0, const lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b *a1, lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b *out, ov_result_owner *owner) {
  if (!ov_pointer(out, sizeof(*out), _Alignof(lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b)) || !ov_pointer(owner, sizeof(*owner), _Alignof(ov_result_owner))) return LB_OWNED_INVALID;
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  status = ov_charge(&transaction.budget, 1, sizeof(*out));
  if (status) return ov_abort(&transaction, status);
  lean_object *arguments = lean_alloc_array(0, 2);
  {
    lean_object *child = NULL;
    status = lbov_7fab4b2842f6c64d9621_v23107461f72b24c37654_in(a0, 0, 1, &transaction, &child);
    if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
    lean_inc(child);
    if (!lean_bridge_owned_refine_5ba8ebacbf26c0755e45(child)) { lean_dec(child); lean_dec(arguments); return ov_abort(&transaction, LB_OWNED_INVALID); }
    arguments = lean_array_push(arguments, child);
  }
  {
    lean_object *child = NULL;
    status = lbov_7fab4b2842f6c64d9621_vb2825946e038e653bd2b_in(a1, 0, 1, &transaction, &child);
    if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
    lean_inc(child);
    if (!lean_bridge_owned_refine_ca177b2570793a278657(child)) { lean_dec(child); lean_dec(arguments); return ov_abort(&transaction, LB_OWNED_INVALID); }
    arguments = lean_array_push(arguments, child);
  }
  lean_object *v0 = lean_array_get_core(arguments, 0); lean_inc(v0);
  lean_object *v1 = lean_array_get_core(arguments, 1); lean_inc(v1);
  lean_dec(arguments);
  ov_callback_frame frame = { .parent = ov_active_callback_frame, .transaction = &transaction };
  if (!frame.parent) { (void)lb_native_callback_take_error(); (void)lean_bridge_owned_callback_failure_7fab4b2842f6c64d9621(); }
  ov_active_callback_frame = &frame;
  lean_object *returned = lean_bridge_owned_0d662a6486ef7827f9e97a02_feaac3cc8d9197bd7bbca(v0, v1);
  ov_active_callback_frame = frame.parent; status = frame.status;
  int callback_error = lb_native_callback_take_error();
  int refinement_error = lean_bridge_owned_callback_failure_7fab4b2842f6c64d9621();
  if (refinement_error && !status) status = LB_OWNED_INVALID;
  else if (callback_error && !status) status = OV_CALLBACK;
  if (!status) status = lb_owned_scope_ready(&transaction.scope);
  if (status) { lean_dec(returned); return ov_abort(&transaction, status); }
  lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b converted = {0};
  status = lbov_7fab4b2842f6c64d9621_vb2825946e038e653bd2b_out(&converted, returned, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  status = ov_commit(&transaction, owner);
  if (!status) *out = converted;
  return status;
}
static inline int lbov_7fab4b2842f6c64d9621_fec926afda994fba3abe2(lb_owned_context *context, const lbov_7fab4b2842f6c64d9621_td79b9bbde250ee1779da *a0, lbov_7fab4b2842f6c64d9621_t167081552b6f9c1d1afd *out, ov_result_owner *owner) {
  if (!ov_pointer(out, sizeof(*out), _Alignof(lbov_7fab4b2842f6c64d9621_t167081552b6f9c1d1afd)) || !ov_pointer(owner, sizeof(*owner), _Alignof(ov_result_owner))) return LB_OWNED_INVALID;
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  status = ov_charge(&transaction.budget, 1, sizeof(*out));
  if (status) return ov_abort(&transaction, status);
  lean_object *arguments = lean_alloc_array(0, 1);
  {
    lean_object *child = NULL;
    status = lbov_7fab4b2842f6c64d9621_vd79b9bbde250ee1779da_in(a0, 0, 1, &transaction, &child);
    if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
    arguments = lean_array_push(arguments, child);
  }
  lean_object *v0 = lean_array_get_core(arguments, 0); lean_inc(v0);
  lean_dec(arguments);
  ov_callback_frame frame = { .parent = ov_active_callback_frame, .transaction = &transaction };
  if (!frame.parent) { (void)lb_native_callback_take_error(); (void)lean_bridge_owned_callback_failure_7fab4b2842f6c64d9621(); }
  ov_active_callback_frame = &frame;
  lean_object *returned = lean_bridge_owned_0d662a6486ef7827f9e97a02_fec926afda994fba3abe2(v0);
  ov_active_callback_frame = frame.parent; status = frame.status;
  int callback_error = lb_native_callback_take_error();
  int refinement_error = lean_bridge_owned_callback_failure_7fab4b2842f6c64d9621();
  if (refinement_error && !status) status = LB_OWNED_INVALID;
  else if (callback_error && !status) status = OV_CALLBACK;
  if (!status) status = lb_owned_scope_ready(&transaction.scope);
  if (status) { lean_dec(returned); return ov_abort(&transaction, status); }
  lbov_7fab4b2842f6c64d9621_t167081552b6f9c1d1afd converted = {0};
  status = lbov_7fab4b2842f6c64d9621_v167081552b6f9c1d1afd_out(&converted, returned, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  status = ov_commit(&transaction, owner);
  if (!status) *out = converted;
  return status;
}
static inline int lbov_7fab4b2842f6c64d9621_f040aca3025d850fc12cc(lb_owned_context *context, const lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b *a0, ov_input_transfers *transfer, lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b *out, ov_result_owner *owner) {
  if (!ov_pointer(out, sizeof(*out), _Alignof(lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b)) || !ov_pointer(owner, sizeof(*owner), _Alignof(ov_result_owner))) return LB_OWNED_INVALID;
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  status = ov_charge(&transaction.budget, 1, sizeof(*out));
  if (status) return ov_abort(&transaction, status);
  lb_owned_batch *batches[1] = {0}; size_t batch_count = 0;
  status = ov_transfers_prepare(&transaction, transfer, 1, batches, &batch_count);
  if (status) return ov_abort(&transaction, status);
  lean_object *arguments = lean_alloc_array(0, 1);
  {
    lean_object *child = NULL;
    transaction.input_transfer = 1;
    transaction.input_owner = &transfer->owners[0]->batch;
    status = lbov_7fab4b2842f6c64d9621_vb2825946e038e653bd2b_in(a0, 0, 1, &transaction, &child);
    if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
    lean_inc(child);
    if (!lean_bridge_owned_refine_ca177b2570793a278657(child)) { lean_dec(child); lean_dec(arguments); return ov_abort(&transaction, LB_OWNED_INVALID); }
    arguments = lean_array_push(arguments, child);
  }
  transaction.input_transfer = 0; transaction.input_owner = NULL;
  status = lb_owned_scope_transfer_many(&transaction.scope, batches, batch_count);
  if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
  transfer->consumed = 1; transfer->consume(transfer->context);
  lean_object *v0 = lean_array_get_core(arguments, 0); lean_inc(v0);
  lean_dec(arguments);
  ov_callback_frame frame = { .parent = ov_active_callback_frame, .transaction = &transaction };
  if (!frame.parent) { (void)lb_native_callback_take_error(); (void)lean_bridge_owned_callback_failure_7fab4b2842f6c64d9621(); }
  ov_active_callback_frame = &frame;
  lean_object *returned = lean_bridge_owned_0d662a6486ef7827f9e97a02_f040aca3025d850fc12cc(v0);
  ov_active_callback_frame = frame.parent; status = frame.status;
  int callback_error = lb_native_callback_take_error();
  int refinement_error = lean_bridge_owned_callback_failure_7fab4b2842f6c64d9621();
  if (refinement_error && !status) status = LB_OWNED_INVALID;
  else if (callback_error && !status) status = OV_CALLBACK;
  if (!status) status = lb_owned_scope_ready(&transaction.scope);
  if (status) { lean_dec(returned); return ov_abort(&transaction, status); }
  lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b converted = {0};
  status = lbov_7fab4b2842f6c64d9621_vb2825946e038e653bd2b_out(&converted, returned, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  status = ov_commit(&transaction, owner);
  if (!status) *out = converted;
  return status;
}
static inline int lbov_7fab4b2842f6c64d9621_fc4cffe83b4b420b09021(lb_owned_context *context, const lbov_7fab4b2842f6c64d9621_t23107461f72b24c37654 *a0, const lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b *a1, ov_input_transfers *transfer, lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b *out, ov_result_owner *owner) {
  if (!ov_pointer(out, sizeof(*out), _Alignof(lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b)) || !ov_pointer(owner, sizeof(*owner), _Alignof(ov_result_owner))) return LB_OWNED_INVALID;
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  status = ov_charge(&transaction.budget, 1, sizeof(*out));
  if (status) return ov_abort(&transaction, status);
  lb_owned_batch *batches[2] = {0}; size_t batch_count = 0;
  status = ov_transfers_prepare(&transaction, transfer, 2, batches, &batch_count);
  if (status) return ov_abort(&transaction, status);
  lean_object *arguments = lean_alloc_array(0, 2);
  {
    lean_object *child = NULL;
    transaction.input_transfer = 1;
    transaction.input_owner = &transfer->owners[0]->batch;
    status = lbov_7fab4b2842f6c64d9621_v23107461f72b24c37654_in(a0, 0, 1, &transaction, &child);
    if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
    lean_inc(child);
    if (!lean_bridge_owned_refine_5ba8ebacbf26c0755e45(child)) { lean_dec(child); lean_dec(arguments); return ov_abort(&transaction, LB_OWNED_INVALID); }
    arguments = lean_array_push(arguments, child);
  }
  {
    lean_object *child = NULL;
    transaction.input_transfer = 1;
    transaction.input_owner = &transfer->owners[1]->batch;
    status = lbov_7fab4b2842f6c64d9621_vb2825946e038e653bd2b_in(a1, 0, 1, &transaction, &child);
    if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
    lean_inc(child);
    if (!lean_bridge_owned_refine_ca177b2570793a278657(child)) { lean_dec(child); lean_dec(arguments); return ov_abort(&transaction, LB_OWNED_INVALID); }
    arguments = lean_array_push(arguments, child);
  }
  transaction.input_transfer = 0; transaction.input_owner = NULL;
  status = lb_owned_scope_transfer_many(&transaction.scope, batches, batch_count);
  if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
  transfer->consumed = 1; transfer->consume(transfer->context);
  lean_object *v0 = lean_array_get_core(arguments, 0); lean_inc(v0);
  lean_object *v1 = lean_array_get_core(arguments, 1); lean_inc(v1);
  lean_dec(arguments);
  ov_callback_frame frame = { .parent = ov_active_callback_frame, .transaction = &transaction };
  if (!frame.parent) { (void)lb_native_callback_take_error(); (void)lean_bridge_owned_callback_failure_7fab4b2842f6c64d9621(); }
  ov_active_callback_frame = &frame;
  lean_object *returned = lean_bridge_owned_0d662a6486ef7827f9e97a02_fc4cffe83b4b420b09021(v0, v1);
  ov_active_callback_frame = frame.parent; status = frame.status;
  int callback_error = lb_native_callback_take_error();
  int refinement_error = lean_bridge_owned_callback_failure_7fab4b2842f6c64d9621();
  if (refinement_error && !status) status = LB_OWNED_INVALID;
  else if (callback_error && !status) status = OV_CALLBACK;
  if (!status) status = lb_owned_scope_ready(&transaction.scope);
  if (status) { lean_dec(returned); return ov_abort(&transaction, status); }
  lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b converted = {0};
  status = lbov_7fab4b2842f6c64d9621_vb2825946e038e653bd2b_out(&converted, returned, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  status = ov_commit(&transaction, owner);
  if (!status) *out = converted;
  return status;
}
static inline int lbov_7fab4b2842f6c64d9621_f33442f0a4409864e6a4a(lb_owned_context *context, const lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b *a0, const lbov_7fab4b2842f6c64d9621_t5035e6ea0903f12776d9 *a1, ov_input_transfers *transfer, lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b *out, ov_result_owner *owner) {
  if (!ov_pointer(out, sizeof(*out), _Alignof(lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b)) || !ov_pointer(owner, sizeof(*owner), _Alignof(ov_result_owner))) return LB_OWNED_INVALID;
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  status = ov_charge(&transaction.budget, 1, sizeof(*out));
  if (status) return ov_abort(&transaction, status);
  lb_owned_batch *batches[1] = {0}; size_t batch_count = 0;
  status = ov_transfers_prepare(&transaction, transfer, 1, batches, &batch_count);
  if (status) return ov_abort(&transaction, status);
  lean_object *arguments = lean_alloc_array(0, 2);
  {
    lean_object *child = NULL;
    transaction.input_transfer = 1;
    transaction.input_owner = &transfer->owners[0]->batch;
    status = lbov_7fab4b2842f6c64d9621_vb2825946e038e653bd2b_in(a0, 0, 1, &transaction, &child);
    if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
    lean_inc(child);
    if (!lean_bridge_owned_refine_ca177b2570793a278657(child)) { lean_dec(child); lean_dec(arguments); return ov_abort(&transaction, LB_OWNED_INVALID); }
    arguments = lean_array_push(arguments, child);
  }
  {
    lean_object *child = NULL;
    transaction.input_transfer = 0;
    transaction.input_owner = NULL;
    status = lbov_7fab4b2842f6c64d9621_v5035e6ea0903f12776d9_in(a1, 0, 1, &transaction, &child);
    if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
    arguments = lean_array_push(arguments, child);
  }
  transaction.input_transfer = 0; transaction.input_owner = NULL;
  status = lb_owned_scope_transfer_many(&transaction.scope, batches, batch_count);
  if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
  transfer->consumed = 1; transfer->consume(transfer->context);
  lean_object *v0 = lean_array_get_core(arguments, 0); lean_inc(v0);
  lean_object *v1 = lean_array_get_core(arguments, 1); lean_inc(v1);
  lean_dec(arguments);
  ov_callback_frame frame = { .parent = ov_active_callback_frame, .transaction = &transaction };
  if (!frame.parent) { (void)lb_native_callback_take_error(); (void)lean_bridge_owned_callback_failure_7fab4b2842f6c64d9621(); }
  ov_active_callback_frame = &frame;
  lean_object *returned = lean_bridge_owned_0d662a6486ef7827f9e97a02_f33442f0a4409864e6a4a(v0, v1);
  ov_active_callback_frame = frame.parent; status = frame.status;
  int callback_error = lb_native_callback_take_error();
  int refinement_error = lean_bridge_owned_callback_failure_7fab4b2842f6c64d9621();
  if (refinement_error && !status) status = LB_OWNED_INVALID;
  else if (callback_error && !status) status = OV_CALLBACK;
  if (!status) status = lb_owned_scope_ready(&transaction.scope);
  if (status) { lean_dec(returned); return ov_abort(&transaction, status); }
  lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b converted = {0};
  status = lbov_7fab4b2842f6c64d9621_vb2825946e038e653bd2b_out(&converted, returned, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  status = ov_commit(&transaction, owner);
  if (!status) *out = converted;
  return status;
}
static inline int lbov_7fab4b2842f6c64d9621_f7d6c8617a0788c12de15(lb_owned_context *context, const lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b *a0, const lbov_7fab4b2842f6c64d9621_t5035e6ea0903f12776d9 *a1, lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b *out, ov_result_owner *owner) {
  if (!ov_pointer(out, sizeof(*out), _Alignof(lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b)) || !ov_pointer(owner, sizeof(*owner), _Alignof(ov_result_owner))) return LB_OWNED_INVALID;
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  status = ov_charge(&transaction.budget, 1, sizeof(*out));
  if (status) return ov_abort(&transaction, status);
  lean_object *arguments = lean_alloc_array(0, 2);
  {
    lean_object *child = NULL;
    status = lbov_7fab4b2842f6c64d9621_vb2825946e038e653bd2b_in(a0, 0, 1, &transaction, &child);
    if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
    lean_inc(child);
    if (!lean_bridge_owned_refine_ca177b2570793a278657(child)) { lean_dec(child); lean_dec(arguments); return ov_abort(&transaction, LB_OWNED_INVALID); }
    arguments = lean_array_push(arguments, child);
  }
  {
    lean_object *child = NULL;
    status = lbov_7fab4b2842f6c64d9621_v5035e6ea0903f12776d9_in(a1, 0, 1, &transaction, &child);
    if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
    arguments = lean_array_push(arguments, child);
  }
  lean_object *v0 = lean_array_get_core(arguments, 0); lean_inc(v0);
  lean_object *v1 = lean_array_get_core(arguments, 1); lean_inc(v1);
  lean_dec(arguments);
  ov_callback_frame frame = { .parent = ov_active_callback_frame, .transaction = &transaction };
  if (!frame.parent) { (void)lb_native_callback_take_error(); (void)lean_bridge_owned_callback_failure_7fab4b2842f6c64d9621(); }
  ov_active_callback_frame = &frame;
  lean_object *returned = lean_bridge_owned_0d662a6486ef7827f9e97a02_f7d6c8617a0788c12de15(v0, v1);
  ov_active_callback_frame = frame.parent; status = frame.status;
  int callback_error = lb_native_callback_take_error();
  int refinement_error = lean_bridge_owned_callback_failure_7fab4b2842f6c64d9621();
  if (refinement_error && !status) status = LB_OWNED_INVALID;
  else if (callback_error && !status) status = OV_CALLBACK;
  if (!status) status = lb_owned_scope_ready(&transaction.scope);
  if (status) { lean_dec(returned); return ov_abort(&transaction, status); }
  lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b converted = {0};
  status = lbov_7fab4b2842f6c64d9621_vb2825946e038e653bd2b_out(&converted, returned, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  status = ov_commit(&transaction, owner);
  if (!status) *out = converted;
  return status;
}
static inline int lbov_7fab4b2842f6c64d9621_v648974cffb2d6c1d7951_apply(lb_owned_context *context, const lbov_7fab4b2842f6c64d9621_t648974cffb2d6c1d7951 *a0, const lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b *a1, lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b *out, ov_result_owner *owner) {
  if (!ov_pointer(out, sizeof(*out), _Alignof(lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b)) || !ov_pointer(owner, sizeof(*owner), _Alignof(ov_result_owner))) return LB_OWNED_INVALID;
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  status = ov_charge(&transaction.budget, 1, sizeof(*out));
  if (status) return ov_abort(&transaction, status);
  lean_object *arguments = lean_alloc_array(0, 2);
  {
    lean_object *child = NULL;
    status = lbov_7fab4b2842f6c64d9621_v648974cffb2d6c1d7951_in(a0, 0, 1, &transaction, &child);
    if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
    arguments = lean_array_push(arguments, child);
  }
  {
    lean_object *child = NULL;
    status = lbov_7fab4b2842f6c64d9621_vb2825946e038e653bd2b_in(a1, 0, 1, &transaction, &child);
    if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
    lean_inc(child);
    if (!lean_bridge_owned_refine_ca177b2570793a278657(child)) { lean_dec(child); lean_dec(arguments); return ov_abort(&transaction, LB_OWNED_INVALID); }
    arguments = lean_array_push(arguments, child);
  }
  lean_object *v0 = lean_array_get_core(arguments, 0); lean_inc(v0);
  lean_object *v1 = lean_array_get_core(arguments, 1); lean_inc(v1);
  lean_dec(arguments);
  ov_callback_frame frame = { .parent = ov_active_callback_frame, .transaction = &transaction };
  if (!frame.parent) { (void)lb_native_callback_take_error(); (void)lean_bridge_owned_callback_failure_7fab4b2842f6c64d9621(); }
  ov_active_callback_frame = &frame;
  lean_object *returned = lean_bridge_owned_0d662a6486ef7827f9e97a02_t648974cffb2d6c1d7951_apply(v0, v1);
  ov_active_callback_frame = frame.parent; status = frame.status;
  int callback_error = lb_native_callback_take_error();
  int refinement_error = lean_bridge_owned_callback_failure_7fab4b2842f6c64d9621();
  if (refinement_error && !status) status = LB_OWNED_INVALID;
  else if (callback_error && !status) status = OV_CALLBACK;
  if (!status) status = lb_owned_scope_ready(&transaction.scope);
  if (status) { lean_dec(returned); return ov_abort(&transaction, status); }
  lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b converted = {0};
  status = lbov_7fab4b2842f6c64d9621_vb2825946e038e653bd2b_out(&converted, returned, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  status = ov_commit(&transaction, owner);
  if (!status) *out = converted;
  return status;
}
static inline int lbov_7fab4b2842f6c64d9621_v5035e6ea0903f12776d9_apply(lb_owned_context *context, const lbov_7fab4b2842f6c64d9621_t5035e6ea0903f12776d9 *a0, const lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b *a1, lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b *out, ov_result_owner *owner) {
  if (!ov_pointer(out, sizeof(*out), _Alignof(lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b)) || !ov_pointer(owner, sizeof(*owner), _Alignof(ov_result_owner))) return LB_OWNED_INVALID;
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  status = ov_charge(&transaction.budget, 1, sizeof(*out));
  if (status) return ov_abort(&transaction, status);
  lean_object *arguments = lean_alloc_array(0, 2);
  {
    lean_object *child = NULL;
    status = lbov_7fab4b2842f6c64d9621_v5035e6ea0903f12776d9_in(a0, 0, 1, &transaction, &child);
    if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
    arguments = lean_array_push(arguments, child);
  }
  {
    lean_object *child = NULL;
    status = lbov_7fab4b2842f6c64d9621_vb2825946e038e653bd2b_in(a1, 0, 1, &transaction, &child);
    if (status) { lean_dec(arguments); return ov_abort(&transaction, status); }
    arguments = lean_array_push(arguments, child);
  }
  lean_object *v0 = lean_array_get_core(arguments, 0); lean_inc(v0);
  lean_object *v1 = lean_array_get_core(arguments, 1); lean_inc(v1);
  lean_dec(arguments);
  ov_callback_frame frame = { .parent = ov_active_callback_frame, .transaction = &transaction };
  if (!frame.parent) { (void)lb_native_callback_take_error(); (void)lean_bridge_owned_callback_failure_7fab4b2842f6c64d9621(); }
  ov_active_callback_frame = &frame;
  lean_object *returned = lean_bridge_owned_0d662a6486ef7827f9e97a02_t5035e6ea0903f12776d9_apply(v0, v1);
  ov_active_callback_frame = frame.parent; status = frame.status;
  int callback_error = lb_native_callback_take_error();
  int refinement_error = lean_bridge_owned_callback_failure_7fab4b2842f6c64d9621();
  if (refinement_error && !status) status = LB_OWNED_INVALID;
  else if (callback_error && !status) status = OV_CALLBACK;
  if (!status) status = lb_owned_scope_ready(&transaction.scope);
  if (status) { lean_dec(returned); return ov_abort(&transaction, status); }
  lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b converted = {0};
  status = lbov_7fab4b2842f6c64d9621_vb2825946e038e653bd2b_out(&converted, returned, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  status = ov_commit(&transaction, owner);
  if (!status) *out = converted;
  return status;
}

#define OW_GRAPH_ALLOC(bytes) LB_OWNED_ALLOC(bytes)
#define OW_GRAPH_FREE(pointer) LB_OWNED_FREE(pointer)
#include <wasmtime.h>
#include <wasmtime/component.h>
#ifndef OW_GRAPH_ALLOC
#define OW_GRAPH_ALLOC(bytes) calloc(1, bytes)
#endif
#ifndef OW_GRAPH_FREE
#define OW_GRAPH_FREE(pointer) free(pointer)
#endif

_Static_assert(sizeof(bool) == 1, "WIT bool validation requires a one-byte representation");
typedef struct lb_allocation { struct lb_allocation *next; } lb_allocation;
typedef struct { size_t remaining; lb_allocation *allocations; unsigned failure; } lb_scope;
/* Native callers still own valid backing storage; this checks shape, alignment
 * and address arithmetic, not the allocation extent of an arbitrary pointer. */
static inline bool lb_buffer(const void *data, size_t count, size_t width, size_t alignment) {
  if (!count) return true;
  if (!data || !width || !alignment || (uintptr_t)data % alignment || count > SIZE_MAX / width) return false;
  return count * width <= UINTPTR_MAX - (uintptr_t)data;
}
static inline bool lb_boolean(const void *data, bool *out) {
  uint8_t raw; memcpy(&raw, data, sizeof(raw));
  if (raw > 1) return false;
  *out = raw != 0; return true;
}
static inline bool lb_charge(lb_scope *scope, size_t count, size_t width) {
  if (count && width > scope->remaining / count) { scope->failure = 2; return false; }
  scope->remaining -= count * width; return true;
}
static inline void *lb_alloc(lb_scope *scope, size_t count, size_t width) {
  if (!count) return NULL;
  if (width > (SIZE_MAX - sizeof(lb_allocation)) / count) { scope->failure = 2; return NULL; }
  lb_allocation *allocation = OW_GRAPH_ALLOC(sizeof(*allocation) + count * width);
  if (!allocation) { scope->failure = 3; return NULL; }
  memset(allocation, 0, sizeof(*allocation) + count * width);
  allocation->next = scope->allocations; scope->allocations = allocation;
  return allocation + 1;
}
static inline void lb_scope_close(lb_scope *scope) {
  while (scope->allocations) { lb_allocation *next = scope->allocations->next; OW_GRAPH_FREE(scope->allocations); scope->allocations = next; }
}
static inline bool lb_name(const wasm_name_t *name, const char *expected) {
  size_t length = strlen(expected);
  return name->size == length && lb_buffer(name->data, length, 1, 1) && (!length || memcmp(name->data, expected, length) == 0);
}
static inline bool lb_utf8(const char *text, size_t length) {
  const uint8_t *p = (const uint8_t *)text;
  if (!lb_buffer(p, length, 1, 1)) return false;
  for (size_t i = 0; i < length;) {
    uint32_t c = p[i++]; size_t extra = 0; uint32_t minimum = 0;
    if (c < 0x80) continue;
    if (c >= 0xc2 && c <= 0xdf) { extra = 1; minimum = 0x80; c &= 0x1f; }
    else if (c >= 0xe0 && c <= 0xef) { extra = 2; minimum = 0x800; c &= 0x0f; }
    else if (c >= 0xf0 && c <= 0xf4) { extra = 3; minimum = 0x10000; c &= 7; }
    else return false;
    if (extra > length - i) return false;
    while (extra--) { uint8_t b = p[i++]; if ((b & 0xc0) != 0x80) return false; c = (c << 6) | (b & 0x3f); }
    if (c < minimum || c > 0x10ffff || (c >= 0xd800 && c <= 0xdfff)) return false;
  }
  return true;
}
static inline bool lb_limbs_in(const wasmtime_component_val_t *value, lb_scope *scope, uint32_t **out, size_t *length) {
  if (value->kind != WASMTIME_COMPONENT_LIST) return false;
  size_t count = value->of.list.size;
  if (!lb_buffer(value->of.list.data, count, sizeof(wasmtime_component_val_t), _Alignof(wasmtime_component_val_t)) || !lb_charge(scope, count, sizeof(wasmtime_component_val_t) + sizeof(uint32_t))) return false;
  for (size_t i = 0; i < count; ++i) if (value->of.list.data[i].kind != WASMTIME_COMPONENT_U32) return false;
  if (count && value->of.list.data[count - 1].of.u32 == 0) return false;
  if (out) {
    *out = lb_alloc(scope, count, sizeof(uint32_t)); if (count && !*out) return false;
    for (size_t i = 0; i < count; ++i) (*out)[i] = value->of.list.data[i].of.u32;
    *length = count;
  }
  return true;
}
static inline bool lb_limbs_out(const uint32_t *data, size_t length, lb_scope *scope, wasmtime_component_val_t *out) {
  if (!lb_buffer(data, length, sizeof(uint32_t), _Alignof(uint32_t)) || !lb_charge(scope, length, sizeof(wasmtime_component_val_t))) return false;
  if (length && (!data || !data[length - 1])) return false;
  out->kind = WASMTIME_COMPONENT_LIST;
  wasmtime_component_vallist_new_uninit(&out->of.list, length);
  for (size_t i = 0; i < length; ++i) out->of.list.data[i] = (wasmtime_component_val_t){.kind = WASMTIME_COMPONENT_U32, .of.u32 = data[i]};
  return true;
}

#define OW_TYPES 11
#define OW_DEPTH 128
#define OW_NODES 262144
#define OW_BYTES 16777216
typedef struct {
  void *data;
  bool (*read)(void *, size_t, bool, const wasmtime_component_val_t *, uint64_t *);
  bool (*write)(void *, size_t, bool, uint64_t, wasmtime_component_val_t *);
  void (*discard)(void *, wasmtime_component_resource_any_t *);
} ow_identities;
typedef struct { lb_scope memory; size_t visits; ow_identities identities; } ow_scope;
typedef struct { size_t type; const char *name; } ow_table_schema;
typedef struct { size_t count; const ow_table_schema *tables; } ow_schema;
typedef struct { size_t type; uint32_t index; const void *address; } ow_path;
typedef struct {
  ow_scope *scope; bool borrowed;
  const wasmtime_component_vallist_t *tables[OW_TYPES];
  size_t offsets[OW_TYPES], total, visited, active;
  uint8_t *seen;
  ow_path path[OW_DEPTH + 1];
} ow_input;
typedef struct ow_row { struct ow_row *next; wasmtime_component_val_t value; } ow_row;
typedef struct { ow_row *head, *tail; uint32_t count; } ow_table;
typedef struct {
  ow_scope *scope; bool borrowed; const ow_schema *schema;
  ow_table tables[OW_TYPES]; size_t active;
  ow_path path[OW_DEPTH + 1];
} ow_output;
static inline bool ow_visit(ow_scope *scope, unsigned depth, size_t bytes) {
  if (depth > OW_DEPTH || !scope->visits) { scope->memory.failure = 2; return false; }
  --scope->visits; return lb_charge(&scope->memory, 1, bytes);
}
static inline bool ow_count(ow_scope *scope, size_t count) {
  if (count > scope->visits) { scope->memory.failure = 2; return false; }
  return true;
}
/* Traverse only values constructed by these encoders, never unchecked inputs. */
static inline void ow_discard_resources(ow_scope *scope, wasmtime_component_val_t *value) {
  switch (value->kind) {
  case WASMTIME_COMPONENT_RESOURCE:
    if (value->of.resource && scope->identities.discard) scope->identities.discard(scope->identities.data, value->of.resource);
    break;
  case WASMTIME_COMPONENT_RECORD:
    for (size_t i = 0; i < value->of.record.size; ++i) ow_discard_resources(scope, &value->of.record.data[i].val);
    break;
  case WASMTIME_COMPONENT_LIST:
    for (size_t i = 0; i < value->of.list.size; ++i) ow_discard_resources(scope, &value->of.list.data[i]);
    break;
  case WASMTIME_COMPONENT_TUPLE:
    for (size_t i = 0; i < value->of.tuple.size; ++i) ow_discard_resources(scope, &value->of.tuple.data[i]);
    break;
  case WASMTIME_COMPONENT_VARIANT:
    if (value->of.variant.val) ow_discard_resources(scope, value->of.variant.val);
    break;
  case WASMTIME_COMPONENT_OPTION:
    if (value->of.option) ow_discard_resources(scope, value->of.option);
    break;
  case WASMTIME_COMPONENT_RESULT:
    if (value->of.result.val) ow_discard_resources(scope, value->of.result.val);
    break;
  default: break;
  }
}
static inline void ow_value_delete(ow_scope *scope, wasmtime_component_val_t *value) {
  ow_discard_resources(scope, value); wasmtime_component_val_delete(value);
  *value = (wasmtime_component_val_t){0};
}
static inline bool ow_record_in(const wasmtime_component_val_t *value, size_t count, ow_scope *scope) {
  return lb_buffer(value, 1, sizeof(*value), _Alignof(wasmtime_component_val_t))
    && value->kind == WASMTIME_COMPONENT_RECORD && value->of.record.size == count
    && lb_buffer(value->of.record.data, count, sizeof(*value->of.record.data), _Alignof(wasmtime_component_valrecord_entry_t))
    && lb_charge(&scope->memory, count, sizeof(*value->of.record.data));
}
static inline bool ow_record_out(wasmtime_component_val_t *value, size_t count, ow_scope *scope) {
  if (!lb_charge(&scope->memory, count, sizeof(wasmtime_component_valrecord_entry_t))) return false;
  value->kind = WASMTIME_COMPONENT_RECORD; wasmtime_component_valrecord_new_uninit(&value->of.record, count);
  if (count) memset(value->of.record.data, 0, count * sizeof(*value->of.record.data));
  return true;
}
static inline bool ow_field_out(wasmtime_component_valrecord_entry_t *field, const char *name, ow_scope *scope) {
  size_t length = strlen(name);
  if (!lb_charge(&scope->memory, length, 1)) return false;
  wasm_name_new(&field->name, length, name); return true;
}
static inline ow_input *ow_open(const wasmtime_component_val_t *value, ow_scope *scope, const ow_schema *schema, bool borrowed) {
  if (!ow_record_in(value, 2, scope) || !lb_name(&value->of.record.data[0].name, "root") || !lb_name(&value->of.record.data[1].name, "nodes")) return NULL;
  const wasmtime_component_val_t *arena = &value->of.record.data[1].val;
  if (!ow_record_in(arena, schema->count, scope) || !lb_charge(&scope->memory, 1, sizeof(ow_input))) return NULL;
  ow_input *context = lb_alloc(&scope->memory, 1, sizeof(*context));
  if (!context) return NULL;
  context->scope = scope; context->borrowed = borrowed;
  for (size_t i = 0; i < schema->count; ++i) {
    const wasmtime_component_valrecord_entry_t *field = &arena->of.record.data[i];
    size_t type = schema->tables[i].type;
    if (!lb_name(&field->name, schema->tables[i].name) || field->val.kind != WASMTIME_COMPONENT_LIST) return NULL;
    const wasmtime_component_vallist_t *table = &field->val.of.list;
    if (table->size > OW_NODES - context->total) { scope->memory.failure = 2; return NULL; }
    if (!lb_buffer(table->data, table->size, sizeof(*table->data), _Alignof(wasmtime_component_val_t)) || !lb_charge(&scope->memory, table->size, sizeof(*table->data) + 1)) return NULL;
    context->tables[type] = table; context->offsets[type] = context->total; context->total += table->size;
  }
  context->seen = lb_alloc(&scope->memory, context->total, 1);
  if (context->total && !context->seen) return NULL;
  return context;
}
static inline const wasmtime_component_val_t *ow_dereference(ow_input *context, size_t type, const wasmtime_component_val_t *value) {
  if (context->active > OW_DEPTH) { context->scope->memory.failure = 2; return NULL; }
  if (!ow_record_in(value, 1, context->scope) || !lb_name(&value->of.record.data[0].name, "index") || value->of.record.data[0].val.kind != WASMTIME_COMPONENT_U32) return NULL;
  uint32_t index = value->of.record.data[0].val.of.u32;
  if (!context->tables[type] || index >= context->tables[type]->size) return NULL;
  for (size_t i = 0; i < context->active; ++i) if (context->path[i].type == type && context->path[i].index == index) return NULL;
  context->path[context->active++] = (ow_path){.type = type, .index = index};
  size_t position = context->offsets[type] + index;
  if (!context->seen[position]) { context->seen[position] = 1; ++context->visited; }
  return &context->tables[type]->data[index];
}
static inline wasmtime_component_val_t *ow_append(ow_output *context, size_t type, const void *address, wasmtime_component_val_t *reference) {
  if (context->active > OW_DEPTH) { context->scope->memory.failure = 2; return NULL; }
  for (size_t i = 0; i < context->active; ++i) if (context->path[i].type == type && context->path[i].address == address) return NULL;
  ow_table *table = &context->tables[type];
  if (table->count >= OW_NODES) { context->scope->memory.failure = 2; return NULL; }
  if (!lb_charge(&context->scope->memory, 1, sizeof(ow_row))) return NULL;
  ow_row *row = lb_alloc(&context->scope->memory, 1, sizeof(*row));
  if (!row) return NULL;
  if (table->tail) table->tail->next = row; else table->head = row;
  table->tail = row;
  if (!ow_record_out(reference, 1, context->scope) || !ow_field_out(&reference->of.record.data[0], "index", context->scope)) return NULL;
  reference->of.record.data[0].val = (wasmtime_component_val_t){.kind = WASMTIME_COMPONENT_U32, .of.u32 = table->count++};
  context->path[context->active++] = (ow_path){.type = type, .address = address}; return &row->value;
}
static inline void ow_output_close(ow_output *context) {
  for (size_t i = 0; i < OW_TYPES; ++i)
    for (ow_row *row = context->tables[i].head; row; row = row->next) ow_value_delete(context->scope, &row->value);
}
static inline bool ow_finish(ow_output *context, wasmtime_component_val_t *arena) {
  if (!ow_record_out(arena, context->schema->count, context->scope)) return false;
  for (size_t i = 0; i < context->schema->count; ++i) {
    const ow_table_schema *schema = &context->schema->tables[i];
    wasmtime_component_valrecord_entry_t *field = &arena->of.record.data[i];
    ow_table *table = &context->tables[schema->type];
    if (!ow_field_out(field, schema->name, context->scope) || !lb_charge(&context->scope->memory, table->count, sizeof(wasmtime_component_val_t))) return false;
    field->val.kind = WASMTIME_COMPONENT_LIST;
    wasmtime_component_vallist_new_uninit(&field->val.of.list, table->count);
    size_t offset = 0;
    for (ow_row *row = table->head; row; row = row->next) { field->val.of.list.data[offset++] = row->value; row->value = (wasmtime_component_val_t){0}; }
  }
  return true;
}
static inline bool lb_in_9(const wasmtime_component_val_t *value, lb_scope *scope, lbov_7fab4b2842f6c64d9621_t167081552b6f9c1d1afd *out) {
  (void)out;
  if (!lb_buffer(value, 1, sizeof(*value), _Alignof(wasmtime_component_val_t)) || (out && !lb_buffer(out, 1, sizeof(*out), _Alignof(lbov_7fab4b2842f6c64d9621_t167081552b6f9c1d1afd))) || !lb_charge(scope, 1, sizeof(wasmtime_component_val_t))) return false;
  uint32_t *limbs = NULL; size_t length = 0;
  if (!lb_limbs_in(value, scope, out ? &limbs : NULL, &length)) return false;
  if (out) *out = (lbov_7fab4b2842f6c64d9621_t167081552b6f9c1d1afd){.data = limbs, .length = length};
  return true;
}
static inline bool lb_out_9(const lbov_7fab4b2842f6c64d9621_t167081552b6f9c1d1afd *value, lb_scope *scope, wasmtime_component_val_t *out) {
  (void)value;
  if (!lb_buffer(value, 1, sizeof(*value), _Alignof(lbov_7fab4b2842f6c64d9621_t167081552b6f9c1d1afd)) || !lb_buffer(out, 1, sizeof(*out), _Alignof(wasmtime_component_val_t)) || !lb_charge(scope, 1, sizeof(wasmtime_component_val_t))) return false;
  return lb_limbs_out(value->data, value->length, scope, out);
  return true;
}

static inline bool lb_in_10(const wasmtime_component_val_t *value, lb_scope *scope, lbov_7fab4b2842f6c64d9621_tdc0347e1f7f5c4d928f1 *out) {
  (void)out;
  if (!lb_buffer(value, 1, sizeof(*value), _Alignof(wasmtime_component_val_t)) || (out && !lb_buffer(out, 1, sizeof(*out), _Alignof(lbov_7fab4b2842f6c64d9621_tdc0347e1f7f5c4d928f1))) || !lb_charge(scope, 1, sizeof(wasmtime_component_val_t))) return false;
  if (value->kind != WASMTIME_COMPONENT_STRING || !lb_charge(scope, value->of.string.size, 1) || !lb_utf8(value->of.string.data, value->of.string.size)) return false;
  if (out) *out = (lbov_7fab4b2842f6c64d9621_tdc0347e1f7f5c4d928f1){.data = value->of.string.data, .length = value->of.string.size};
  return true;
}
static inline bool lb_out_10(const lbov_7fab4b2842f6c64d9621_tdc0347e1f7f5c4d928f1 *value, lb_scope *scope, wasmtime_component_val_t *out) {
  (void)value;
  if (!lb_buffer(value, 1, sizeof(*value), _Alignof(lbov_7fab4b2842f6c64d9621_tdc0347e1f7f5c4d928f1)) || !lb_buffer(out, 1, sizeof(*out), _Alignof(wasmtime_component_val_t)) || !lb_charge(scope, 1, sizeof(wasmtime_component_val_t))) return false;
  if (!lb_charge(scope, value->length, 1) || !lb_utf8(value->data, value->length)) return false;
  out->kind = WASMTIME_COMPONENT_STRING; wasm_name_new(&out->of.string, value->length, value->data);
  return true;
}static inline bool ow_read_0(const wasmtime_component_val_t *, ow_input *, unsigned, lbov_7fab4b2842f6c64d9621_tf790309465bbf573c7b9 *);
static inline bool ow_write_0(const lbov_7fab4b2842f6c64d9621_tf790309465bbf573c7b9 *, ow_output *, unsigned, wasmtime_component_val_t *);
static inline bool ow_read_1(const wasmtime_component_val_t *, ow_input *, unsigned, lbov_7fab4b2842f6c64d9621_t160ce821a84f6887bbfd *);
static inline bool ow_write_1(const lbov_7fab4b2842f6c64d9621_t160ce821a84f6887bbfd *, ow_output *, unsigned, wasmtime_component_val_t *);
static inline bool ow_read_2(const wasmtime_component_val_t *, ow_input *, unsigned, lbov_7fab4b2842f6c64d9621_t648974cffb2d6c1d7951 *);
static inline bool ow_write_2(const lbov_7fab4b2842f6c64d9621_t648974cffb2d6c1d7951 *, ow_output *, unsigned, wasmtime_component_val_t *);
static inline bool ow_read_3(const wasmtime_component_val_t *, ow_input *, unsigned, lbov_7fab4b2842f6c64d9621_t5035e6ea0903f12776d9 *);
static inline bool ow_write_3(const lbov_7fab4b2842f6c64d9621_t5035e6ea0903f12776d9 *, ow_output *, unsigned, wasmtime_component_val_t *);
static inline bool ow_read_4(const wasmtime_component_val_t *, ow_input *, unsigned, lbov_7fab4b2842f6c64d9621_t23107461f72b24c37654 *);
static inline bool ow_write_4(const lbov_7fab4b2842f6c64d9621_t23107461f72b24c37654 *, ow_output *, unsigned, wasmtime_component_val_t *);
static inline bool ow_read_5(const wasmtime_component_val_t *, ow_input *, unsigned, lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b *);
static inline bool ow_write_5(const lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b *, ow_output *, unsigned, wasmtime_component_val_t *);
static inline bool ow_read_6(const wasmtime_component_val_t *, ow_input *, unsigned, lbov_7fab4b2842f6c64d9621_t4ce841c87ea3b1559bfb *);
static inline bool ow_write_6(const lbov_7fab4b2842f6c64d9621_t4ce841c87ea3b1559bfb *, ow_output *, unsigned, wasmtime_component_val_t *);
static inline bool ow_read_7(const wasmtime_component_val_t *, ow_input *, unsigned, lbov_7fab4b2842f6c64d9621_td79b9bbde250ee1779da *);
static inline bool ow_write_7(const lbov_7fab4b2842f6c64d9621_td79b9bbde250ee1779da *, ow_output *, unsigned, wasmtime_component_val_t *);
static inline bool ow_read_8(const wasmtime_component_val_t *, ow_input *, unsigned, lbov_7fab4b2842f6c64d9621_t2a091437b2d587ce3891 *);
static inline bool ow_write_8(const lbov_7fab4b2842f6c64d9621_t2a091437b2d587ce3891 *, ow_output *, unsigned, wasmtime_component_val_t *);
static inline bool ow_read_9(const wasmtime_component_val_t *, ow_input *, unsigned, lbov_7fab4b2842f6c64d9621_t167081552b6f9c1d1afd *);
static inline bool ow_write_9(const lbov_7fab4b2842f6c64d9621_t167081552b6f9c1d1afd *, ow_output *, unsigned, wasmtime_component_val_t *);
static inline bool ow_read_10(const wasmtime_component_val_t *, ow_input *, unsigned, lbov_7fab4b2842f6c64d9621_tdc0347e1f7f5c4d928f1 *);
static inline bool ow_write_10(const lbov_7fab4b2842f6c64d9621_tdc0347e1f7f5c4d928f1 *, ow_output *, unsigned, wasmtime_component_val_t *);
static inline bool ow_read_0(const wasmtime_component_val_t *value, ow_input *context, unsigned depth, lbov_7fab4b2842f6c64d9621_tf790309465bbf573c7b9 *out) {
  (void)out;
  if (!ow_visit(context->scope, depth, sizeof(lbov_7fab4b2842f6c64d9621_tf790309465bbf573c7b9) + sizeof(wasmtime_component_val_t)) || !lb_buffer(value, 1, sizeof(*value), _Alignof(wasmtime_component_val_t))) return false;
  value = ow_dereference(context, 0, value);
  if (!value) return false;
  if (value->kind != WASMTIME_COMPONENT_LIST) return false;
  size_t count = value->of.list.size;
  if (!ow_count(context->scope, count) || !lb_buffer(value->of.list.data, count, sizeof(wasmtime_component_val_t), _Alignof(wasmtime_component_val_t)) || !lb_charge(&context->scope->memory, count, sizeof(lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b) + sizeof(wasmtime_component_val_t))) return false;
  lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b *items = out ? lb_alloc(&context->scope->memory, count, sizeof(lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b)) : NULL;
  if (out && count && !items) return false;
  if (out) { out->data = items; out->length = count; }
  for (size_t i = 0; i < count; ++i) if (!ow_read_5(&value->of.list.data[i], context, depth + 1, out ? &items[i] : NULL)) return false;
  --context->active;
  return true;
}
static inline bool ow_write_0(const lbov_7fab4b2842f6c64d9621_tf790309465bbf573c7b9 *value, ow_output *context, unsigned depth, wasmtime_component_val_t *out) {
  if (!ow_visit(context->scope, depth, sizeof(wasmtime_component_val_t)) || !lb_buffer(value, 1, sizeof(*value), _Alignof(lbov_7fab4b2842f6c64d9621_tf790309465bbf573c7b9))) return false;
  out = ow_append(context, 0, value, out);
  if (!out) return false;
  if (!ow_count(context->scope, value->length) || !lb_buffer(value->data, value->length, sizeof(lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b), _Alignof(lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b)) || !lb_charge(&context->scope->memory, value->length, sizeof(wasmtime_component_val_t))) return false;
  out->kind = WASMTIME_COMPONENT_LIST; wasmtime_component_vallist_new_uninit(&out->of.list, value->length);
  if (value->length) memset(out->of.list.data, 0, value->length * sizeof(*out->of.list.data));
  for (size_t i = 0; i < value->length; ++i) if (!ow_write_5(&value->data[i], context, depth + 1, &out->of.list.data[i])) return false;
  --context->active;
  return true;
}

static inline bool ow_read_1(const wasmtime_component_val_t *value, ow_input *context, unsigned depth, lbov_7fab4b2842f6c64d9621_t160ce821a84f6887bbfd *out) {
  (void)out;
  if (!ow_visit(context->scope, depth, sizeof(lbov_7fab4b2842f6c64d9621_t160ce821a84f6887bbfd) + sizeof(wasmtime_component_val_t)) || !lb_buffer(value, 1, sizeof(*value), _Alignof(wasmtime_component_val_t))) return false;
  value = ow_dereference(context, 1, value);
  if (!value) return false;
  if (value->kind != WASMTIME_COMPONENT_OPTION) return false;
  bool selected = value->of.option != NULL;
  if (out) out->tag = selected;
  if (selected) {
  if (!lb_charge(&context->scope->memory, 1, sizeof(lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b))) return false;
  lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b *child0 = out ? lb_alloc(&context->scope->memory, 1, sizeof(lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b)) : NULL;
  if (out && !child0) return false;
  if (out) out->f0 = child0;
  if (!ow_read_5(value->of.option, context, depth + 1, child0)) return false;
  }
  --context->active;
  return true;
}
static inline bool ow_write_1(const lbov_7fab4b2842f6c64d9621_t160ce821a84f6887bbfd *value, ow_output *context, unsigned depth, wasmtime_component_val_t *out) {
  if (!ow_visit(context->scope, depth, sizeof(wasmtime_component_val_t)) || !lb_buffer(value, 1, sizeof(*value), _Alignof(lbov_7fab4b2842f6c64d9621_t160ce821a84f6887bbfd))) return false;
  out = ow_append(context, 1, value, out);
  if (!out) return false;
  if (value->tag > 1) return false;
  out->kind = WASMTIME_COMPONENT_OPTION;
  out->of.option = NULL;
  if (value->tag) {
  if (!lb_charge(&context->scope->memory, 1, sizeof(wasmtime_component_val_t))) return false;
  wasmtime_component_val_t empty = {0}; out->of.option = wasmtime_component_val_new(&empty);
  if (!ow_write_5(value->f0, context, depth + 1, out->of.option)) return false;
  }
  --context->active;
  return true;
}

static inline bool ow_read_2(const wasmtime_component_val_t *value, ow_input *context, unsigned depth, lbov_7fab4b2842f6c64d9621_t648974cffb2d6c1d7951 *out) {
  (void)out;
  if (!ow_visit(context->scope, depth, sizeof(lbov_7fab4b2842f6c64d9621_t648974cffb2d6c1d7951) + sizeof(wasmtime_component_val_t)) || !lb_buffer(value, 1, sizeof(*value), _Alignof(wasmtime_component_val_t))) return false;
  if (value->kind != WASMTIME_COMPONENT_RESOURCE || !value->of.resource || !context->scope->identities.read) return false;
  if (!context->scope->identities.read(context->scope->identities.data, 2, context->borrowed, value, out ? &out->token : NULL)) return false;
  return !out || out->token != 0;
}
static inline bool ow_write_2(const lbov_7fab4b2842f6c64d9621_t648974cffb2d6c1d7951 *value, ow_output *context, unsigned depth, wasmtime_component_val_t *out) {
  if (!ow_visit(context->scope, depth, sizeof(wasmtime_component_val_t)) || !lb_buffer(value, 1, sizeof(*value), _Alignof(lbov_7fab4b2842f6c64d9621_t648974cffb2d6c1d7951))) return false;
  if (!value->token || !context->scope->identities.write || !context->scope->identities.discard) return false;
  if (!context->scope->identities.write(context->scope->identities.data, 2, context->borrowed, value->token, out)) return false;
  return out->kind == WASMTIME_COMPONENT_RESOURCE && out->of.resource;
}

static inline bool ow_read_3(const wasmtime_component_val_t *value, ow_input *context, unsigned depth, lbov_7fab4b2842f6c64d9621_t5035e6ea0903f12776d9 *out) {
  (void)out;
  if (!ow_visit(context->scope, depth, sizeof(lbov_7fab4b2842f6c64d9621_t5035e6ea0903f12776d9) + sizeof(wasmtime_component_val_t)) || !lb_buffer(value, 1, sizeof(*value), _Alignof(wasmtime_component_val_t))) return false;
  if (value->kind != WASMTIME_COMPONENT_RESOURCE || !value->of.resource || !context->scope->identities.read) return false;
  if (!context->scope->identities.read(context->scope->identities.data, 3, context->borrowed, value, out ? &out->token : NULL)) return false;
  return !out || out->token != 0;
}
static inline bool ow_write_3(const lbov_7fab4b2842f6c64d9621_t5035e6ea0903f12776d9 *value, ow_output *context, unsigned depth, wasmtime_component_val_t *out) {
  if (!ow_visit(context->scope, depth, sizeof(wasmtime_component_val_t)) || !lb_buffer(value, 1, sizeof(*value), _Alignof(lbov_7fab4b2842f6c64d9621_t5035e6ea0903f12776d9))) return false;
  if (!value->token || !context->scope->identities.write || !context->scope->identities.discard) return false;
  if (!context->scope->identities.write(context->scope->identities.data, 3, context->borrowed, value->token, out)) return false;
  return out->kind == WASMTIME_COMPONENT_RESOURCE && out->of.resource;
}

static inline bool ow_read_4(const wasmtime_component_val_t *value, ow_input *context, unsigned depth, lbov_7fab4b2842f6c64d9621_t23107461f72b24c37654 *out) {
  (void)out;
  if (!ow_visit(context->scope, depth, sizeof(lbov_7fab4b2842f6c64d9621_t23107461f72b24c37654) + sizeof(wasmtime_component_val_t)) || !lb_buffer(value, 1, sizeof(*value), _Alignof(wasmtime_component_val_t))) return false;
  value = ow_dereference(context, 4, value);
  if (!value) return false;
  if (!ow_record_in(value, 2, context->scope)) return false;
  if (!lb_name(&value->of.record.data[0].name, "holder")) return false;
  if (!ow_read_7(&value->of.record.data[0].val, context, depth + 1, out ? &out->f0 : NULL)) return false;
  if (!lb_name(&value->of.record.data[1].name, "window")) return false;
  if (!lb_charge(&context->scope->memory, 1, sizeof(lbov_7fab4b2842f6c64d9621_t2a091437b2d587ce3891))) return false;
  lbov_7fab4b2842f6c64d9621_t2a091437b2d587ce3891 *child1 = out ? lb_alloc(&context->scope->memory, 1, sizeof(lbov_7fab4b2842f6c64d9621_t2a091437b2d587ce3891)) : NULL;
  if (out && !child1) return false;
  if (out) out->f1 = child1;
  if (!ow_read_8(&value->of.record.data[1].val, context, depth + 1, child1)) return false;
  --context->active;
  return true;
}
static inline bool ow_write_4(const lbov_7fab4b2842f6c64d9621_t23107461f72b24c37654 *value, ow_output *context, unsigned depth, wasmtime_component_val_t *out) {
  if (!ow_visit(context->scope, depth, sizeof(wasmtime_component_val_t)) || !lb_buffer(value, 1, sizeof(*value), _Alignof(lbov_7fab4b2842f6c64d9621_t23107461f72b24c37654))) return false;
  out = ow_append(context, 4, value, out);
  if (!out) return false;
  if (!ow_record_out(out, 2, context->scope)) return false;
  if (!ow_field_out(&out->of.record.data[0], "holder", context->scope)) return false;
  if (!ow_write_7(&value->f0, context, depth + 1, &out->of.record.data[0].val)) return false;
  if (!ow_field_out(&out->of.record.data[1], "window", context->scope)) return false;
  if (!ow_write_8(value->f1, context, depth + 1, &out->of.record.data[1].val)) return false;
  --context->active;
  return true;
}

static inline bool ow_read_5(const wasmtime_component_val_t *value, ow_input *context, unsigned depth, lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b *out) {
  (void)out;
  if (!ow_visit(context->scope, depth, sizeof(lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b) + sizeof(wasmtime_component_val_t)) || !lb_buffer(value, 1, sizeof(*value), _Alignof(wasmtime_component_val_t))) return false;
  value = ow_dereference(context, 5, value);
  if (!value) return false;
  if (!ow_record_in(value, 2, context->scope)) return false;
  if (!lb_name(&value->of.record.data[0].name, "holder")) return false;
  if (!ow_read_7(&value->of.record.data[0].val, context, depth + 1, out ? &out->f0 : NULL)) return false;
  if (!lb_name(&value->of.record.data[1].name, "quota")) return false;
  if (!ow_read_9(&value->of.record.data[1].val, context, depth + 1, out ? &out->f1 : NULL)) return false;
  --context->active;
  return true;
}
static inline bool ow_write_5(const lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b *value, ow_output *context, unsigned depth, wasmtime_component_val_t *out) {
  if (!ow_visit(context->scope, depth, sizeof(wasmtime_component_val_t)) || !lb_buffer(value, 1, sizeof(*value), _Alignof(lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b))) return false;
  out = ow_append(context, 5, value, out);
  if (!out) return false;
  if (!ow_record_out(out, 2, context->scope)) return false;
  if (!ow_field_out(&out->of.record.data[0], "holder", context->scope)) return false;
  if (!ow_write_7(&value->f0, context, depth + 1, &out->of.record.data[0].val)) return false;
  if (!ow_field_out(&out->of.record.data[1], "quota", context->scope)) return false;
  if (!ow_write_9(&value->f1, context, depth + 1, &out->of.record.data[1].val)) return false;
  --context->active;
  return true;
}

static inline bool ow_read_6(const wasmtime_component_val_t *value, ow_input *context, unsigned depth, lbov_7fab4b2842f6c64d9621_t4ce841c87ea3b1559bfb *out) {
  (void)out;
  if (!ow_visit(context->scope, depth, sizeof(lbov_7fab4b2842f6c64d9621_t4ce841c87ea3b1559bfb) + sizeof(wasmtime_component_val_t)) || !lb_buffer(value, 1, sizeof(*value), _Alignof(wasmtime_component_val_t))) return false;
  value = ow_dereference(context, 6, value);
  if (!value) return false;
  if (!ow_record_in(value, 3, context->scope)) return false;
  if (!lb_name(&value->of.record.data[0].name, "holder")) return false;
  if (!ow_read_7(&value->of.record.data[0].val, context, depth + 1, out ? &out->f0 : NULL)) return false;
  if (!lb_name(&value->of.record.data[1].name, "weight")) return false;
  if (!ow_read_9(&value->of.record.data[1].val, context, depth + 1, out ? &out->f1 : NULL)) return false;
  if (!lb_name(&value->of.record.data[2].name, "limit")) return false;
  if (!ow_read_9(&value->of.record.data[2].val, context, depth + 1, out ? &out->f2 : NULL)) return false;
  --context->active;
  return true;
}
static inline bool ow_write_6(const lbov_7fab4b2842f6c64d9621_t4ce841c87ea3b1559bfb *value, ow_output *context, unsigned depth, wasmtime_component_val_t *out) {
  if (!ow_visit(context->scope, depth, sizeof(wasmtime_component_val_t)) || !lb_buffer(value, 1, sizeof(*value), _Alignof(lbov_7fab4b2842f6c64d9621_t4ce841c87ea3b1559bfb))) return false;
  out = ow_append(context, 6, value, out);
  if (!out) return false;
  if (!ow_record_out(out, 3, context->scope)) return false;
  if (!ow_field_out(&out->of.record.data[0], "holder", context->scope)) return false;
  if (!ow_write_7(&value->f0, context, depth + 1, &out->of.record.data[0].val)) return false;
  if (!ow_field_out(&out->of.record.data[1], "weight", context->scope)) return false;
  if (!ow_write_9(&value->f1, context, depth + 1, &out->of.record.data[1].val)) return false;
  if (!ow_field_out(&out->of.record.data[2], "limit", context->scope)) return false;
  if (!ow_write_9(&value->f2, context, depth + 1, &out->of.record.data[2].val)) return false;
  --context->active;
  return true;
}

static inline bool ow_read_7(const wasmtime_component_val_t *value, ow_input *context, unsigned depth, lbov_7fab4b2842f6c64d9621_td79b9bbde250ee1779da *out) {
  (void)out;
  if (!ow_visit(context->scope, depth, sizeof(lbov_7fab4b2842f6c64d9621_td79b9bbde250ee1779da) + sizeof(wasmtime_component_val_t)) || !lb_buffer(value, 1, sizeof(*value), _Alignof(wasmtime_component_val_t))) return false;
  if (value->kind != WASMTIME_COMPONENT_RESOURCE || !value->of.resource || !context->scope->identities.read) return false;
  if (!context->scope->identities.read(context->scope->identities.data, 7, context->borrowed, value, out ? &out->token : NULL)) return false;
  return !out || out->token != 0;
}
static inline bool ow_write_7(const lbov_7fab4b2842f6c64d9621_td79b9bbde250ee1779da *value, ow_output *context, unsigned depth, wasmtime_component_val_t *out) {
  if (!ow_visit(context->scope, depth, sizeof(wasmtime_component_val_t)) || !lb_buffer(value, 1, sizeof(*value), _Alignof(lbov_7fab4b2842f6c64d9621_td79b9bbde250ee1779da))) return false;
  if (!value->token || !context->scope->identities.write || !context->scope->identities.discard) return false;
  if (!context->scope->identities.write(context->scope->identities.data, 7, context->borrowed, value->token, out)) return false;
  return out->kind == WASMTIME_COMPONENT_RESOURCE && out->of.resource;
}

static inline bool ow_read_8(const wasmtime_component_val_t *value, ow_input *context, unsigned depth, lbov_7fab4b2842f6c64d9621_t2a091437b2d587ce3891 *out) {
  (void)out;
  if (!ow_visit(context->scope, depth, sizeof(lbov_7fab4b2842f6c64d9621_t2a091437b2d587ce3891) + sizeof(wasmtime_component_val_t)) || !lb_buffer(value, 1, sizeof(*value), _Alignof(wasmtime_component_val_t))) return false;
  value = ow_dereference(context, 8, value);
  if (!value) return false;
  if (!ow_record_in(value, 2, context->scope)) return false;
  if (!lb_name(&value->of.record.data[0].name, "lo")) return false;
  if (!ow_read_9(&value->of.record.data[0].val, context, depth + 1, out ? &out->f0 : NULL)) return false;
  if (!lb_name(&value->of.record.data[1].name, "hi")) return false;
  if (!ow_read_9(&value->of.record.data[1].val, context, depth + 1, out ? &out->f1 : NULL)) return false;
  --context->active;
  return true;
}
static inline bool ow_write_8(const lbov_7fab4b2842f6c64d9621_t2a091437b2d587ce3891 *value, ow_output *context, unsigned depth, wasmtime_component_val_t *out) {
  if (!ow_visit(context->scope, depth, sizeof(wasmtime_component_val_t)) || !lb_buffer(value, 1, sizeof(*value), _Alignof(lbov_7fab4b2842f6c64d9621_t2a091437b2d587ce3891))) return false;
  out = ow_append(context, 8, value, out);
  if (!out) return false;
  if (!ow_record_out(out, 2, context->scope)) return false;
  if (!ow_field_out(&out->of.record.data[0], "lo", context->scope)) return false;
  if (!ow_write_9(&value->f0, context, depth + 1, &out->of.record.data[0].val)) return false;
  if (!ow_field_out(&out->of.record.data[1], "hi", context->scope)) return false;
  if (!ow_write_9(&value->f1, context, depth + 1, &out->of.record.data[1].val)) return false;
  --context->active;
  return true;
}

static inline bool ow_read_9(const wasmtime_component_val_t *value, ow_input *context, unsigned depth, lbov_7fab4b2842f6c64d9621_t167081552b6f9c1d1afd *out) {
  (void)out;
  if (!ow_visit(context->scope, depth, sizeof(lbov_7fab4b2842f6c64d9621_t167081552b6f9c1d1afd) + sizeof(wasmtime_component_val_t)) || !lb_buffer(value, 1, sizeof(*value), _Alignof(wasmtime_component_val_t))) return false;
  if (!lb_in_9(value, &context->scope->memory, out)) return false;
  return true;
}
static inline bool ow_write_9(const lbov_7fab4b2842f6c64d9621_t167081552b6f9c1d1afd *value, ow_output *context, unsigned depth, wasmtime_component_val_t *out) {
  if (!ow_visit(context->scope, depth, sizeof(wasmtime_component_val_t)) || !lb_buffer(value, 1, sizeof(*value), _Alignof(lbov_7fab4b2842f6c64d9621_t167081552b6f9c1d1afd))) return false;
  return lb_out_9(value, &context->scope->memory, out);
}

static inline bool ow_read_10(const wasmtime_component_val_t *value, ow_input *context, unsigned depth, lbov_7fab4b2842f6c64d9621_tdc0347e1f7f5c4d928f1 *out) {
  (void)out;
  if (!ow_visit(context->scope, depth, sizeof(lbov_7fab4b2842f6c64d9621_tdc0347e1f7f5c4d928f1) + sizeof(wasmtime_component_val_t)) || !lb_buffer(value, 1, sizeof(*value), _Alignof(wasmtime_component_val_t))) return false;
  if (!lb_in_10(value, &context->scope->memory, out)) return false;
  if (out && out->length) {
    char *text = lb_alloc(&context->scope->memory, out->length, 1);
    if (!text) return false;
    memcpy(text, out->data, out->length); out->data = text;
  }
  return true;
}
static inline bool ow_write_10(const lbov_7fab4b2842f6c64d9621_tdc0347e1f7f5c4d928f1 *value, ow_output *context, unsigned depth, wasmtime_component_val_t *out) {
  if (!ow_visit(context->scope, depth, sizeof(wasmtime_component_val_t)) || !lb_buffer(value, 1, sizeof(*value), _Alignof(lbov_7fab4b2842f6c64d9621_tdc0347e1f7f5c4d928f1))) return false;
  return lb_out_10(value, &context->scope->memory, out);
}static const ow_table_schema ow_schema_0_input_tables[] = {{0, "nodes0"}, {5, "nodes5"}};
static const ow_schema ow_schema_0_input = {2, ow_schema_0_input_tables};

static inline bool ow_decode_0_input(const wasmtime_component_val_t *value, ow_scope *scope, lbov_7fab4b2842f6c64d9621_tf790309465bbf573c7b9 *out) {
  if (out && !lb_buffer(out, 1, sizeof(*out), _Alignof(lbov_7fab4b2842f6c64d9621_tf790309465bbf573c7b9))) return false;
  lbov_7fab4b2842f6c64d9621_tf790309465bbf573c7b9 converted = {0};
  ow_input *context = ow_open(value, scope, &ow_schema_0_input, true);
  if (!context || !ow_read_0(&value->of.record.data[0].val, context, 0, out ? &converted : NULL) || context->visited != context->total) return false;
  if (out) *out = converted;
  return true;
}
static inline bool ow_encode_0_input(const lbov_7fab4b2842f6c64d9621_tf790309465bbf573c7b9 *value, ow_scope *scope, wasmtime_component_val_t *out) {
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(wasmtime_component_val_t))) return false;
  wasmtime_component_val_t converted = {0};
  if (!lb_charge(&scope->memory, 1, sizeof(ow_output))) return false;
  ow_output *context = lb_alloc(&scope->memory, 1, sizeof(*context)); if (!context) return false;
  context->scope = scope; context->borrowed = true; context->schema = &ow_schema_0_input;
  bool valid = ow_record_out(&converted, 2, scope)
    && ow_field_out(&converted.of.record.data[0], "root", scope)
    && ow_field_out(&converted.of.record.data[1], "nodes", scope)
    && ow_write_0(value, context, 0, &converted.of.record.data[0].val)
    && ow_finish(context, &converted.of.record.data[1].val);
  ow_output_close(context);
  if (valid) *out = converted; else ow_value_delete(scope, &converted);
  return valid;
}

static const ow_table_schema ow_schema_0_output_tables[] = {{0, "nodes0"}, {5, "nodes5"}};
static const ow_schema ow_schema_0_output = {2, ow_schema_0_output_tables};

static inline bool ow_decode_0_output(const wasmtime_component_val_t *value, ow_scope *scope, lbov_7fab4b2842f6c64d9621_tf790309465bbf573c7b9 *out) {
  if (out && !lb_buffer(out, 1, sizeof(*out), _Alignof(lbov_7fab4b2842f6c64d9621_tf790309465bbf573c7b9))) return false;
  lbov_7fab4b2842f6c64d9621_tf790309465bbf573c7b9 converted = {0};
  ow_input *context = ow_open(value, scope, &ow_schema_0_output, false);
  if (!context || !ow_read_0(&value->of.record.data[0].val, context, 0, out ? &converted : NULL) || context->visited != context->total) return false;
  if (out) *out = converted;
  return true;
}
static inline bool ow_encode_0_output(const lbov_7fab4b2842f6c64d9621_tf790309465bbf573c7b9 *value, ow_scope *scope, wasmtime_component_val_t *out) {
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(wasmtime_component_val_t))) return false;
  wasmtime_component_val_t converted = {0};
  if (!lb_charge(&scope->memory, 1, sizeof(ow_output))) return false;
  ow_output *context = lb_alloc(&scope->memory, 1, sizeof(*context)); if (!context) return false;
  context->scope = scope; context->borrowed = false; context->schema = &ow_schema_0_output;
  bool valid = ow_record_out(&converted, 2, scope)
    && ow_field_out(&converted.of.record.data[0], "root", scope)
    && ow_field_out(&converted.of.record.data[1], "nodes", scope)
    && ow_write_0(value, context, 0, &converted.of.record.data[0].val)
    && ow_finish(context, &converted.of.record.data[1].val);
  ow_output_close(context);
  if (valid) *out = converted; else ow_value_delete(scope, &converted);
  return valid;
}

static const ow_table_schema ow_schema_1_output_tables[] = {{1, "nodes1"}, {5, "nodes5"}};
static const ow_schema ow_schema_1_output = {2, ow_schema_1_output_tables};

static inline bool ow_decode_1_output(const wasmtime_component_val_t *value, ow_scope *scope, lbov_7fab4b2842f6c64d9621_t160ce821a84f6887bbfd *out) {
  if (out && !lb_buffer(out, 1, sizeof(*out), _Alignof(lbov_7fab4b2842f6c64d9621_t160ce821a84f6887bbfd))) return false;
  lbov_7fab4b2842f6c64d9621_t160ce821a84f6887bbfd converted = {0};
  ow_input *context = ow_open(value, scope, &ow_schema_1_output, false);
  if (!context || !ow_read_1(&value->of.record.data[0].val, context, 0, out ? &converted : NULL) || context->visited != context->total) return false;
  if (out) *out = converted;
  return true;
}
static inline bool ow_encode_1_output(const lbov_7fab4b2842f6c64d9621_t160ce821a84f6887bbfd *value, ow_scope *scope, wasmtime_component_val_t *out) {
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(wasmtime_component_val_t))) return false;
  wasmtime_component_val_t converted = {0};
  if (!lb_charge(&scope->memory, 1, sizeof(ow_output))) return false;
  ow_output *context = lb_alloc(&scope->memory, 1, sizeof(*context)); if (!context) return false;
  context->scope = scope; context->borrowed = false; context->schema = &ow_schema_1_output;
  bool valid = ow_record_out(&converted, 2, scope)
    && ow_field_out(&converted.of.record.data[0], "root", scope)
    && ow_field_out(&converted.of.record.data[1], "nodes", scope)
    && ow_write_1(value, context, 0, &converted.of.record.data[0].val)
    && ow_finish(context, &converted.of.record.data[1].val);
  ow_output_close(context);
  if (valid) *out = converted; else ow_value_delete(scope, &converted);
  return valid;
}


static inline bool ow_decode_2_input(const wasmtime_component_val_t *value, ow_scope *scope, lbov_7fab4b2842f6c64d9621_t648974cffb2d6c1d7951 *out) {
  if (out && !lb_buffer(out, 1, sizeof(*out), _Alignof(lbov_7fab4b2842f6c64d9621_t648974cffb2d6c1d7951))) return false;
  lbov_7fab4b2842f6c64d9621_t648974cffb2d6c1d7951 converted = {0};
  ow_input context = {.scope = scope, .borrowed = true};
  if (!ow_read_2(value, &context, 0, out ? &converted : NULL)) return false;
  if (out) *out = converted;
  return true;
}
static inline bool ow_encode_2_input(const lbov_7fab4b2842f6c64d9621_t648974cffb2d6c1d7951 *value, ow_scope *scope, wasmtime_component_val_t *out) {
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(wasmtime_component_val_t))) return false;
  wasmtime_component_val_t converted = {0};
  ow_output context = {.scope = scope, .borrowed = true};
  bool valid = ow_write_2(value, &context, 0, &converted);
  if (valid) *out = converted; else ow_value_delete(scope, &converted);
  return valid;
}


static inline bool ow_decode_2_output(const wasmtime_component_val_t *value, ow_scope *scope, lbov_7fab4b2842f6c64d9621_t648974cffb2d6c1d7951 *out) {
  if (out && !lb_buffer(out, 1, sizeof(*out), _Alignof(lbov_7fab4b2842f6c64d9621_t648974cffb2d6c1d7951))) return false;
  lbov_7fab4b2842f6c64d9621_t648974cffb2d6c1d7951 converted = {0};
  ow_input context = {.scope = scope, .borrowed = false};
  if (!ow_read_2(value, &context, 0, out ? &converted : NULL)) return false;
  if (out) *out = converted;
  return true;
}
static inline bool ow_encode_2_output(const lbov_7fab4b2842f6c64d9621_t648974cffb2d6c1d7951 *value, ow_scope *scope, wasmtime_component_val_t *out) {
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(wasmtime_component_val_t))) return false;
  wasmtime_component_val_t converted = {0};
  ow_output context = {.scope = scope, .borrowed = false};
  bool valid = ow_write_2(value, &context, 0, &converted);
  if (valid) *out = converted; else ow_value_delete(scope, &converted);
  return valid;
}


static inline bool ow_decode_3_input(const wasmtime_component_val_t *value, ow_scope *scope, lbov_7fab4b2842f6c64d9621_t5035e6ea0903f12776d9 *out) {
  if (out && !lb_buffer(out, 1, sizeof(*out), _Alignof(lbov_7fab4b2842f6c64d9621_t5035e6ea0903f12776d9))) return false;
  lbov_7fab4b2842f6c64d9621_t5035e6ea0903f12776d9 converted = {0};
  ow_input context = {.scope = scope, .borrowed = true};
  if (!ow_read_3(value, &context, 0, out ? &converted : NULL)) return false;
  if (out) *out = converted;
  return true;
}
static inline bool ow_encode_3_input(const lbov_7fab4b2842f6c64d9621_t5035e6ea0903f12776d9 *value, ow_scope *scope, wasmtime_component_val_t *out) {
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(wasmtime_component_val_t))) return false;
  wasmtime_component_val_t converted = {0};
  ow_output context = {.scope = scope, .borrowed = true};
  bool valid = ow_write_3(value, &context, 0, &converted);
  if (valid) *out = converted; else ow_value_delete(scope, &converted);
  return valid;
}


static inline bool ow_decode_3_output(const wasmtime_component_val_t *value, ow_scope *scope, lbov_7fab4b2842f6c64d9621_t5035e6ea0903f12776d9 *out) {
  if (out && !lb_buffer(out, 1, sizeof(*out), _Alignof(lbov_7fab4b2842f6c64d9621_t5035e6ea0903f12776d9))) return false;
  lbov_7fab4b2842f6c64d9621_t5035e6ea0903f12776d9 converted = {0};
  ow_input context = {.scope = scope, .borrowed = false};
  if (!ow_read_3(value, &context, 0, out ? &converted : NULL)) return false;
  if (out) *out = converted;
  return true;
}
static inline bool ow_encode_3_output(const lbov_7fab4b2842f6c64d9621_t5035e6ea0903f12776d9 *value, ow_scope *scope, wasmtime_component_val_t *out) {
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(wasmtime_component_val_t))) return false;
  wasmtime_component_val_t converted = {0};
  ow_output context = {.scope = scope, .borrowed = false};
  bool valid = ow_write_3(value, &context, 0, &converted);
  if (valid) *out = converted; else ow_value_delete(scope, &converted);
  return valid;
}

static const ow_table_schema ow_schema_4_input_tables[] = {{4, "nodes4"}, {8, "nodes8"}};
static const ow_schema ow_schema_4_input = {2, ow_schema_4_input_tables};

static inline bool ow_decode_4_input(const wasmtime_component_val_t *value, ow_scope *scope, lbov_7fab4b2842f6c64d9621_t23107461f72b24c37654 *out) {
  if (out && !lb_buffer(out, 1, sizeof(*out), _Alignof(lbov_7fab4b2842f6c64d9621_t23107461f72b24c37654))) return false;
  lbov_7fab4b2842f6c64d9621_t23107461f72b24c37654 converted = {0};
  ow_input *context = ow_open(value, scope, &ow_schema_4_input, true);
  if (!context || !ow_read_4(&value->of.record.data[0].val, context, 0, out ? &converted : NULL) || context->visited != context->total) return false;
  if (out) *out = converted;
  return true;
}
static inline bool ow_encode_4_input(const lbov_7fab4b2842f6c64d9621_t23107461f72b24c37654 *value, ow_scope *scope, wasmtime_component_val_t *out) {
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(wasmtime_component_val_t))) return false;
  wasmtime_component_val_t converted = {0};
  if (!lb_charge(&scope->memory, 1, sizeof(ow_output))) return false;
  ow_output *context = lb_alloc(&scope->memory, 1, sizeof(*context)); if (!context) return false;
  context->scope = scope; context->borrowed = true; context->schema = &ow_schema_4_input;
  bool valid = ow_record_out(&converted, 2, scope)
    && ow_field_out(&converted.of.record.data[0], "root", scope)
    && ow_field_out(&converted.of.record.data[1], "nodes", scope)
    && ow_write_4(value, context, 0, &converted.of.record.data[0].val)
    && ow_finish(context, &converted.of.record.data[1].val);
  ow_output_close(context);
  if (valid) *out = converted; else ow_value_delete(scope, &converted);
  return valid;
}

static const ow_table_schema ow_schema_4_output_tables[] = {{4, "nodes4"}, {8, "nodes8"}};
static const ow_schema ow_schema_4_output = {2, ow_schema_4_output_tables};

static inline bool ow_decode_4_output(const wasmtime_component_val_t *value, ow_scope *scope, lbov_7fab4b2842f6c64d9621_t23107461f72b24c37654 *out) {
  if (out && !lb_buffer(out, 1, sizeof(*out), _Alignof(lbov_7fab4b2842f6c64d9621_t23107461f72b24c37654))) return false;
  lbov_7fab4b2842f6c64d9621_t23107461f72b24c37654 converted = {0};
  ow_input *context = ow_open(value, scope, &ow_schema_4_output, false);
  if (!context || !ow_read_4(&value->of.record.data[0].val, context, 0, out ? &converted : NULL) || context->visited != context->total) return false;
  if (out) *out = converted;
  return true;
}
static inline bool ow_encode_4_output(const lbov_7fab4b2842f6c64d9621_t23107461f72b24c37654 *value, ow_scope *scope, wasmtime_component_val_t *out) {
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(wasmtime_component_val_t))) return false;
  wasmtime_component_val_t converted = {0};
  if (!lb_charge(&scope->memory, 1, sizeof(ow_output))) return false;
  ow_output *context = lb_alloc(&scope->memory, 1, sizeof(*context)); if (!context) return false;
  context->scope = scope; context->borrowed = false; context->schema = &ow_schema_4_output;
  bool valid = ow_record_out(&converted, 2, scope)
    && ow_field_out(&converted.of.record.data[0], "root", scope)
    && ow_field_out(&converted.of.record.data[1], "nodes", scope)
    && ow_write_4(value, context, 0, &converted.of.record.data[0].val)
    && ow_finish(context, &converted.of.record.data[1].val);
  ow_output_close(context);
  if (valid) *out = converted; else ow_value_delete(scope, &converted);
  return valid;
}

static const ow_table_schema ow_schema_5_input_tables[] = {{5, "nodes5"}};
static const ow_schema ow_schema_5_input = {1, ow_schema_5_input_tables};

static inline bool ow_decode_5_input(const wasmtime_component_val_t *value, ow_scope *scope, lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b *out) {
  if (out && !lb_buffer(out, 1, sizeof(*out), _Alignof(lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b))) return false;
  lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b converted = {0};
  ow_input *context = ow_open(value, scope, &ow_schema_5_input, true);
  if (!context || !ow_read_5(&value->of.record.data[0].val, context, 0, out ? &converted : NULL) || context->visited != context->total) return false;
  if (out) *out = converted;
  return true;
}
static inline bool ow_encode_5_input(const lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b *value, ow_scope *scope, wasmtime_component_val_t *out) {
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(wasmtime_component_val_t))) return false;
  wasmtime_component_val_t converted = {0};
  if (!lb_charge(&scope->memory, 1, sizeof(ow_output))) return false;
  ow_output *context = lb_alloc(&scope->memory, 1, sizeof(*context)); if (!context) return false;
  context->scope = scope; context->borrowed = true; context->schema = &ow_schema_5_input;
  bool valid = ow_record_out(&converted, 2, scope)
    && ow_field_out(&converted.of.record.data[0], "root", scope)
    && ow_field_out(&converted.of.record.data[1], "nodes", scope)
    && ow_write_5(value, context, 0, &converted.of.record.data[0].val)
    && ow_finish(context, &converted.of.record.data[1].val);
  ow_output_close(context);
  if (valid) *out = converted; else ow_value_delete(scope, &converted);
  return valid;
}

static const ow_table_schema ow_schema_5_output_tables[] = {{5, "nodes5"}};
static const ow_schema ow_schema_5_output = {1, ow_schema_5_output_tables};

static inline bool ow_decode_5_output(const wasmtime_component_val_t *value, ow_scope *scope, lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b *out) {
  if (out && !lb_buffer(out, 1, sizeof(*out), _Alignof(lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b))) return false;
  lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b converted = {0};
  ow_input *context = ow_open(value, scope, &ow_schema_5_output, false);
  if (!context || !ow_read_5(&value->of.record.data[0].val, context, 0, out ? &converted : NULL) || context->visited != context->total) return false;
  if (out) *out = converted;
  return true;
}
static inline bool ow_encode_5_output(const lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b *value, ow_scope *scope, wasmtime_component_val_t *out) {
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(wasmtime_component_val_t))) return false;
  wasmtime_component_val_t converted = {0};
  if (!lb_charge(&scope->memory, 1, sizeof(ow_output))) return false;
  ow_output *context = lb_alloc(&scope->memory, 1, sizeof(*context)); if (!context) return false;
  context->scope = scope; context->borrowed = false; context->schema = &ow_schema_5_output;
  bool valid = ow_record_out(&converted, 2, scope)
    && ow_field_out(&converted.of.record.data[0], "root", scope)
    && ow_field_out(&converted.of.record.data[1], "nodes", scope)
    && ow_write_5(value, context, 0, &converted.of.record.data[0].val)
    && ow_finish(context, &converted.of.record.data[1].val);
  ow_output_close(context);
  if (valid) *out = converted; else ow_value_delete(scope, &converted);
  return valid;
}

static const ow_table_schema ow_schema_6_input_tables[] = {{6, "nodes6"}};
static const ow_schema ow_schema_6_input = {1, ow_schema_6_input_tables};

static inline bool ow_decode_6_input(const wasmtime_component_val_t *value, ow_scope *scope, lbov_7fab4b2842f6c64d9621_t4ce841c87ea3b1559bfb *out) {
  if (out && !lb_buffer(out, 1, sizeof(*out), _Alignof(lbov_7fab4b2842f6c64d9621_t4ce841c87ea3b1559bfb))) return false;
  lbov_7fab4b2842f6c64d9621_t4ce841c87ea3b1559bfb converted = {0};
  ow_input *context = ow_open(value, scope, &ow_schema_6_input, true);
  if (!context || !ow_read_6(&value->of.record.data[0].val, context, 0, out ? &converted : NULL) || context->visited != context->total) return false;
  if (out) *out = converted;
  return true;
}
static inline bool ow_encode_6_input(const lbov_7fab4b2842f6c64d9621_t4ce841c87ea3b1559bfb *value, ow_scope *scope, wasmtime_component_val_t *out) {
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(wasmtime_component_val_t))) return false;
  wasmtime_component_val_t converted = {0};
  if (!lb_charge(&scope->memory, 1, sizeof(ow_output))) return false;
  ow_output *context = lb_alloc(&scope->memory, 1, sizeof(*context)); if (!context) return false;
  context->scope = scope; context->borrowed = true; context->schema = &ow_schema_6_input;
  bool valid = ow_record_out(&converted, 2, scope)
    && ow_field_out(&converted.of.record.data[0], "root", scope)
    && ow_field_out(&converted.of.record.data[1], "nodes", scope)
    && ow_write_6(value, context, 0, &converted.of.record.data[0].val)
    && ow_finish(context, &converted.of.record.data[1].val);
  ow_output_close(context);
  if (valid) *out = converted; else ow_value_delete(scope, &converted);
  return valid;
}

static const ow_table_schema ow_schema_6_output_tables[] = {{6, "nodes6"}};
static const ow_schema ow_schema_6_output = {1, ow_schema_6_output_tables};

static inline bool ow_decode_6_output(const wasmtime_component_val_t *value, ow_scope *scope, lbov_7fab4b2842f6c64d9621_t4ce841c87ea3b1559bfb *out) {
  if (out && !lb_buffer(out, 1, sizeof(*out), _Alignof(lbov_7fab4b2842f6c64d9621_t4ce841c87ea3b1559bfb))) return false;
  lbov_7fab4b2842f6c64d9621_t4ce841c87ea3b1559bfb converted = {0};
  ow_input *context = ow_open(value, scope, &ow_schema_6_output, false);
  if (!context || !ow_read_6(&value->of.record.data[0].val, context, 0, out ? &converted : NULL) || context->visited != context->total) return false;
  if (out) *out = converted;
  return true;
}
static inline bool ow_encode_6_output(const lbov_7fab4b2842f6c64d9621_t4ce841c87ea3b1559bfb *value, ow_scope *scope, wasmtime_component_val_t *out) {
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(wasmtime_component_val_t))) return false;
  wasmtime_component_val_t converted = {0};
  if (!lb_charge(&scope->memory, 1, sizeof(ow_output))) return false;
  ow_output *context = lb_alloc(&scope->memory, 1, sizeof(*context)); if (!context) return false;
  context->scope = scope; context->borrowed = false; context->schema = &ow_schema_6_output;
  bool valid = ow_record_out(&converted, 2, scope)
    && ow_field_out(&converted.of.record.data[0], "root", scope)
    && ow_field_out(&converted.of.record.data[1], "nodes", scope)
    && ow_write_6(value, context, 0, &converted.of.record.data[0].val)
    && ow_finish(context, &converted.of.record.data[1].val);
  ow_output_close(context);
  if (valid) *out = converted; else ow_value_delete(scope, &converted);
  return valid;
}


static inline bool ow_decode_7_input(const wasmtime_component_val_t *value, ow_scope *scope, lbov_7fab4b2842f6c64d9621_td79b9bbde250ee1779da *out) {
  if (out && !lb_buffer(out, 1, sizeof(*out), _Alignof(lbov_7fab4b2842f6c64d9621_td79b9bbde250ee1779da))) return false;
  lbov_7fab4b2842f6c64d9621_td79b9bbde250ee1779da converted = {0};
  ow_input context = {.scope = scope, .borrowed = true};
  if (!ow_read_7(value, &context, 0, out ? &converted : NULL)) return false;
  if (out) *out = converted;
  return true;
}
static inline bool ow_encode_7_input(const lbov_7fab4b2842f6c64d9621_td79b9bbde250ee1779da *value, ow_scope *scope, wasmtime_component_val_t *out) {
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(wasmtime_component_val_t))) return false;
  wasmtime_component_val_t converted = {0};
  ow_output context = {.scope = scope, .borrowed = true};
  bool valid = ow_write_7(value, &context, 0, &converted);
  if (valid) *out = converted; else ow_value_delete(scope, &converted);
  return valid;
}


static inline bool ow_decode_7_output(const wasmtime_component_val_t *value, ow_scope *scope, lbov_7fab4b2842f6c64d9621_td79b9bbde250ee1779da *out) {
  if (out && !lb_buffer(out, 1, sizeof(*out), _Alignof(lbov_7fab4b2842f6c64d9621_td79b9bbde250ee1779da))) return false;
  lbov_7fab4b2842f6c64d9621_td79b9bbde250ee1779da converted = {0};
  ow_input context = {.scope = scope, .borrowed = false};
  if (!ow_read_7(value, &context, 0, out ? &converted : NULL)) return false;
  if (out) *out = converted;
  return true;
}
static inline bool ow_encode_7_output(const lbov_7fab4b2842f6c64d9621_td79b9bbde250ee1779da *value, ow_scope *scope, wasmtime_component_val_t *out) {
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(wasmtime_component_val_t))) return false;
  wasmtime_component_val_t converted = {0};
  ow_output context = {.scope = scope, .borrowed = false};
  bool valid = ow_write_7(value, &context, 0, &converted);
  if (valid) *out = converted; else ow_value_delete(scope, &converted);
  return valid;
}


static inline bool ow_decode_9_input(const wasmtime_component_val_t *value, ow_scope *scope, lbov_7fab4b2842f6c64d9621_t167081552b6f9c1d1afd *out) {
  if (out && !lb_buffer(out, 1, sizeof(*out), _Alignof(lbov_7fab4b2842f6c64d9621_t167081552b6f9c1d1afd))) return false;
  lbov_7fab4b2842f6c64d9621_t167081552b6f9c1d1afd converted = {0};
  ow_input context = {.scope = scope, .borrowed = true};
  if (!ow_read_9(value, &context, 0, out ? &converted : NULL)) return false;
  if (out) *out = converted;
  return true;
}
static inline bool ow_encode_9_input(const lbov_7fab4b2842f6c64d9621_t167081552b6f9c1d1afd *value, ow_scope *scope, wasmtime_component_val_t *out) {
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(wasmtime_component_val_t))) return false;
  wasmtime_component_val_t converted = {0};
  ow_output context = {.scope = scope, .borrowed = true};
  bool valid = ow_write_9(value, &context, 0, &converted);
  if (valid) *out = converted; else ow_value_delete(scope, &converted);
  return valid;
}


static inline bool ow_decode_9_output(const wasmtime_component_val_t *value, ow_scope *scope, lbov_7fab4b2842f6c64d9621_t167081552b6f9c1d1afd *out) {
  if (out && !lb_buffer(out, 1, sizeof(*out), _Alignof(lbov_7fab4b2842f6c64d9621_t167081552b6f9c1d1afd))) return false;
  lbov_7fab4b2842f6c64d9621_t167081552b6f9c1d1afd converted = {0};
  ow_input context = {.scope = scope, .borrowed = false};
  if (!ow_read_9(value, &context, 0, out ? &converted : NULL)) return false;
  if (out) *out = converted;
  return true;
}
static inline bool ow_encode_9_output(const lbov_7fab4b2842f6c64d9621_t167081552b6f9c1d1afd *value, ow_scope *scope, wasmtime_component_val_t *out) {
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(wasmtime_component_val_t))) return false;
  wasmtime_component_val_t converted = {0};
  ow_output context = {.scope = scope, .borrowed = false};
  bool valid = ow_write_9(value, &context, 0, &converted);
  if (valid) *out = converted; else ow_value_delete(scope, &converted);
  return valid;
}


static inline bool ow_decode_10_input(const wasmtime_component_val_t *value, ow_scope *scope, lbov_7fab4b2842f6c64d9621_tdc0347e1f7f5c4d928f1 *out) {
  if (out && !lb_buffer(out, 1, sizeof(*out), _Alignof(lbov_7fab4b2842f6c64d9621_tdc0347e1f7f5c4d928f1))) return false;
  lbov_7fab4b2842f6c64d9621_tdc0347e1f7f5c4d928f1 converted = {0};
  ow_input context = {.scope = scope, .borrowed = true};
  if (!ow_read_10(value, &context, 0, out ? &converted : NULL)) return false;
  if (out) *out = converted;
  return true;
}
static inline bool ow_encode_10_input(const lbov_7fab4b2842f6c64d9621_tdc0347e1f7f5c4d928f1 *value, ow_scope *scope, wasmtime_component_val_t *out) {
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(wasmtime_component_val_t))) return false;
  wasmtime_component_val_t converted = {0};
  ow_output context = {.scope = scope, .borrowed = true};
  bool valid = ow_write_10(value, &context, 0, &converted);
  if (valid) *out = converted; else ow_value_delete(scope, &converted);
  return valid;
}


static inline bool ow_decode_10_output(const wasmtime_component_val_t *value, ow_scope *scope, lbov_7fab4b2842f6c64d9621_tdc0347e1f7f5c4d928f1 *out) {
  if (out && !lb_buffer(out, 1, sizeof(*out), _Alignof(lbov_7fab4b2842f6c64d9621_tdc0347e1f7f5c4d928f1))) return false;
  lbov_7fab4b2842f6c64d9621_tdc0347e1f7f5c4d928f1 converted = {0};
  ow_input context = {.scope = scope, .borrowed = false};
  if (!ow_read_10(value, &context, 0, out ? &converted : NULL)) return false;
  if (out) *out = converted;
  return true;
}
static inline bool ow_encode_10_output(const lbov_7fab4b2842f6c64d9621_tdc0347e1f7f5c4d928f1 *value, ow_scope *scope, wasmtime_component_val_t *out) {
  if (!lb_buffer(out, 1, sizeof(*out), _Alignof(wasmtime_component_val_t))) return false;
  wasmtime_component_val_t converted = {0};
  ow_output context = {.scope = scope, .borrowed = false};
  bool valid = ow_write_10(value, &context, 0, &converted);
  if (valid) *out = converted; else ow_value_delete(scope, &converted);
  return valid;
}


#define OW_RESOURCE_CAPACITY LB_OWNED_RETAINED_LIMIT
typedef struct ow_native_host ow_native_host;
typedef struct ow_native_call ow_native_call;
typedef struct {
  uint32_t rep;
  size_t type;
  uint64_t token;
  lb_owned_batch lease;
  ow_native_call *pending;
  bool transient;
} ow_native_entry;
struct ow_native_call { ow_native_host *host; ow_native_call *parent; };
struct ow_native_host {
  ow_native_host *self;
  lb_owned_context *native;
  wasmtime_context_t *context;
  ow_native_entry *entries;
  uint32_t tags[OW_TYPES], next_rep;
  size_t live, depth;
  int status;
  ow_native_call *call;
  ov_input_transfers *input_transfers;
  bool closing;
  wasmtime_error_t *failure;
};
typedef struct ow_native_read {
  struct ow_native_read *next;
  const wasmtime_component_resource_any_t *handle;
  uint32_t rep;
  size_t type;
  bool borrowed;
} ow_native_read;
typedef struct { ow_native_host *host; ow_scope scope; ow_native_read *reads; } ow_native_conversion;
static _Atomic uint32_t ow_native_next_tag;
static const char *const ow_native_kinds[OW_TYPES] = {
  [2] = "callable:owned-checked-records@1.0.0:bridge:Callback26621c40b48fce52ca37",
  [3] = "callable:owned-checked-records@1.0.0:bridge:Callbackb2d3d6fd4e031785f278",
  [7] = "resource:OwnedCheckedRecords.Ticket",
};
static inline bool ow_native_ready(ow_native_host *host) {
  return host && host->self == host && host->native && !host->closing
    && !lb_owned_ready(host->native) && host->context && host->entries;
}
static inline bool ow_native_affinity(ow_native_host *host) {
  return host && host->self == host && host->native && !lb_owned_affinity(host->native);
}
static inline int ow_native_status(ow_native_host *host, int status) {
  if (status && !host->status) host->status = status;
  return host->status;
}
static inline void ow_native_error(ow_native_host *host, wasmtime_error_t *error) {
  if (!error) return;
  (void)ow_native_status(host, LB_OWNED_RUNTIME);
  if (!host->failure) host->failure = error; else wasmtime_error_delete(error);
}
static inline ow_native_entry *ow_native_find(ow_native_host *host, uint32_t rep) {
  for (size_t i = 0; rep && i < OW_RESOURCE_CAPACITY; ++i)
    if (host->entries[i].rep == rep) return &host->entries[i];
  return NULL;
}
static inline bool ow_native_release(ow_native_host *host, ow_native_entry *entry) {
  if (!entry || !entry->rep || !ow_native_affinity(host)) return false;
  int status = lb_owned_batch_release(host->native, &entry->lease);
  if (entry->lease.context) return false;
  *entry = (ow_native_entry){0}; --host->live;
  if (status) ow_native_error(host, wasmtime_error_new("Native resource lease release failed"));
  return !status;
}
static inline bool ow_native_host_init(ow_native_host *host, lb_owned_context *native, wasmtime_context_t *context) {
  if (!host || host->self || host->entries || !context || lb_owned_ready(native)) return false;
  ow_native_entry *entries = LB_OWNED_ALLOC(OW_RESOURCE_CAPACITY * sizeof(*entries));
  if (!entries) { host->status = LB_OWNED_ALLOC_FAILED; return false; }
  memset(entries, 0, OW_RESOURCE_CAPACITY * sizeof(*entries));
  *host = (ow_native_host){.self = host, .native = native, .context = context, .entries = entries};
  for (size_t i = 0; i < OW_TYPES; ++i) if (ow_native_kinds[i]) {
    uint32_t previous = atomic_load(&ow_native_next_tag);
    do {
      if (previous == UINT32_MAX) { LB_OWNED_FREE(entries); *host = (ow_native_host){.status = LB_OWNED_LIMIT}; return false; }
    } while (!atomic_compare_exchange_weak(&ow_native_next_tag, &previous, previous + 1));
    host->tags[i] = previous + 1;
  }
  return true;
}
static inline bool ow_native_call_begin(ow_native_host *host, ow_native_call *call) {
  if (!ow_native_ready(host) || !call || call->host || call->parent || host->depth == LB_OWNED_SCOPE_LIMIT) return false;
  if (!host->call && host->failure) { wasmtime_error_delete(host->failure); host->failure = NULL; }
  if (!host->call) host->status = LB_OWNED_OK;
  if (host->failure) return false;
  *call = (ow_native_call){.host = host, .parent = host->call}; host->call = call; ++host->depth; return true;
}
static inline bool ow_native_call_end(ow_native_call *call, bool success) {
  if (!call || !ow_native_affinity(call->host) || call->host->call != call) return false;
  ow_native_host *host = call->host;
  /* Conversion status reports an atomic, recoverable failure. The caller can
   * still commit unrelated work; Wasmtime errors and close prevent commit. */
  success = success && !host->failure && !host->closing;
  /* Finish fallible temporary cleanup before publishing any pending owner. */
  if (success) for (size_t i = 0; i < OW_RESOURCE_CAPACITY; ++i) {
    ow_native_entry *entry = &host->entries[i];
    if (entry->rep && entry->pending == call && entry->transient && !ow_native_release(host, entry)) success = false;
  }
  for (size_t i = 0; i < OW_RESOURCE_CAPACITY; ++i) {
    ow_native_entry *entry = &host->entries[i];
    if (!entry->rep || entry->pending != call) continue;
    if (!success) {
      if (!ow_native_release(host, entry)) success = false;
    } else entry->pending = call->parent;
  }
  host->call = call->parent; --host->depth; *call = (ow_native_call){0}; return success;
}
/* Close native leases even when a trapped component store cannot drop borrows.
 * Store replacement/destruction belongs to the owning session, after unwind. */
static inline bool ow_native_host_close(ow_native_host *host) {
  if (!ow_native_affinity(host) || host->call) return false;
  host->closing = true;
  bool valid = true;
  for (size_t i = 0; i < OW_RESOURCE_CAPACITY; ++i)
    if (host->entries[i].rep && !ow_native_release(host, &host->entries[i])) valid = false;
  if (host->live) return false;
  LB_OWNED_FREE(host->entries);
  if (host->failure) wasmtime_error_delete(host->failure);
  *host = (ow_native_host){0}; return valid;
}
static inline bool ow_native_type(ow_native_host *host, size_t type, const wasmtime_component_resource_any_t *resource) {
  if (type >= OW_TYPES || !host->tags[type] || !resource) return false;
  wasmtime_component_resource_type_t *actual = wasmtime_component_resource_any_type(resource);
  wasmtime_component_resource_type_t *expected = wasmtime_component_resource_type_new_host(host->tags[type]);
  bool matches = wasmtime_component_resource_type_equal(actual, expected);
  wasmtime_component_resource_type_delete(actual); wasmtime_component_resource_type_delete(expected); return matches;
}
/* Import arguments have already crossed this host's store. Never call this
 * converter on an arbitrary resource from another Wasmtime store. */
static bool ow_native_read_identity(void *data, size_t type, bool borrowed,
    const wasmtime_component_val_t *value, uint64_t *out) {
  ow_native_conversion *conversion = data; ow_native_host *host = conversion->host;
  if (!ow_native_ready(host) || !host->call || host->failure
      || !ow_native_type(host, type, value->of.resource) || wasmtime_component_resource_any_owned(value->of.resource) == borrowed) return false;
  ow_native_read *read = conversion->reads;
  while (read && read->handle != value->of.resource) read = read->next;
  if (!read) {
    if (!lb_charge(&conversion->scope.memory, 1, sizeof(*read))) return false;
    read = lb_alloc(&conversion->scope.memory, 1, sizeof(*read));
    if (!read) return false;
    wasmtime_component_resource_host_t *resource = NULL;
    wasmtime_error_t *error = wasmtime_component_resource_any_to_host(host->context, value->of.resource, &resource);
    if (error) { ow_native_error(host, error); return false; }
    *read = (ow_native_read){.next = conversion->reads, .handle = value->of.resource,
      .rep = wasmtime_component_resource_host_rep(resource), .type = type,
      .borrowed = !wasmtime_component_resource_host_owned(resource)};
    uint32_t tag = wasmtime_component_resource_host_type(resource);
    wasmtime_component_resource_host_delete(resource);
    conversion->reads = read;
    if (tag != host->tags[type]) return false;
  }
  ow_native_entry *entry = ow_native_find(host, read->rep);
  if (!entry || read->type != type || read->borrowed != borrowed || entry->type != type
      || !lb_owned_find(host->native, ow_native_kinds[type], entry->token)) return false;
  if (out) *out = entry->token;
  return true;
}
static bool ow_native_write_identity(void *data, size_t type, bool borrowed,
    uint64_t token, wasmtime_component_val_t *out) {
  ow_native_conversion *conversion = data; ow_native_host *host = conversion->host;
  if (!ow_native_ready(host) || !host->call || host->failure || type >= OW_TYPES || !host->tags[type] || !token) return false;
  if (host->live == OW_RESOURCE_CAPACITY || host->next_rep == UINT32_MAX) {
    (void)ow_native_status(host, LB_OWNED_LIMIT); return false;
  }
  ow_native_entry *entry = NULL;
  for (size_t i = 0; i < OW_RESOURCE_CAPACITY; ++i) if (!host->entries[i].rep) { entry = &host->entries[i]; break; }
  if (!entry) return false;
  lb_owned_scope scope = {0}; lean_object *object = NULL; uint64_t retained = 0;
  int status = lb_owned_scope_begin(host->native, &scope);
  if (!status) status = lb_owned_scope_borrow(&scope, ow_native_kinds[type], token, &object);
  if (!status) status = lb_owned_scope_acquire(&scope, ow_native_kinds[type], object, &retained);
  if (!status) status = lb_owned_scope_commit(&scope, &entry->lease);
  if (scope.context) (void)lb_owned_scope_abort(&scope);
  if (status) {
    (void)ow_native_status(host, status);
    if (entry->lease.context) (void)lb_owned_batch_release(host->native, &entry->lease);
    return false;
  }
  entry->rep = ++host->next_rep; entry->type = type; entry->token = retained;
  entry->pending = host->call; entry->transient = borrowed; ++host->live;
  wasmtime_component_resource_host_t *resource = wasmtime_component_resource_host_new(!borrowed, entry->rep, host->tags[type]);
  wasmtime_component_resource_any_t *handle = NULL;
  wasmtime_error_t *error = wasmtime_component_resource_host_to_any(host->context, resource, &handle);
  wasmtime_component_resource_host_delete(resource);
  if (error) { ow_native_error(host, error); (void)ow_native_release(host, entry); return false; }
  *out = (wasmtime_component_val_t){.kind = WASMTIME_COMPONENT_RESOURCE, .of.resource = handle}; return true;
}
/* Deleting an unpublished ResourceAny box alone does not release its native
 * lease. Extract its trusted host representation, then close that exact lease. */
static void ow_native_discard_identity(void *data, wasmtime_component_resource_any_t *value) {
  ow_native_conversion *conversion = data; ow_native_host *host = conversion->host;
  if (!ow_native_affinity(host)) return;
  wasmtime_component_resource_host_t *resource = NULL;
  wasmtime_error_t *error = wasmtime_component_resource_any_to_host(host->context, value, &resource);
  if (error) { ow_native_error(host, error); return; }
  uint32_t rep = wasmtime_component_resource_host_rep(resource), tag = wasmtime_component_resource_host_type(resource);
  ow_native_entry *entry = ow_native_find(host, rep);
  wasmtime_component_resource_host_delete(resource);
  if (!entry || host->tags[entry->type] != tag || !ow_native_release(host, entry))
    ow_native_error(host, wasmtime_error_new("Unknown or expired native WIT resource during cleanup"));
}
static inline void ow_native_conversion_init(ow_native_conversion *conversion, ow_native_host *host) {
  *conversion = (ow_native_conversion){.host = host, .scope = {
    .memory = {.remaining = OW_BYTES}, .visits = OW_NODES,
    .identities = {.data = conversion, .read = ow_native_read_identity,
      .write = ow_native_write_identity, .discard = ow_native_discard_identity}}};
}
static inline void ow_native_conversion_close(ow_native_conversion *conversion) {
  lb_scope_close(&conversion->scope.memory); conversion->reads = NULL;
}
static wasmtime_error_t *ow_native_resource_drop(void *data, wasmtime_context_t *context, uint32_t rep) {
  ow_native_host *host = data;
  if (!ow_native_affinity(host) || context != host->context) return wasmtime_error_new("Wrong native WIT resource session");
  ow_native_entry *entry = ow_native_find(host, rep);
  if (!entry || !ow_native_release(host, entry)) return wasmtime_error_new("Closed native WIT resource");
  return NULL;
}


static wasmtime_error_t *ow_native_import_0(void *data, wasmtime_context_t *context,
    const wasmtime_component_func_type_t *type, wasmtime_component_val_t *args, size_t count,
    wasmtime_component_val_t *results, size_t result_count) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  (void)type;
  ow_native_host *host = data;
  if (!ow_native_ready(host) || context != host->context || !host->call || host->failure
      || count != 1 || result_count != 1
      || !lb_buffer(args, count, sizeof(*args), _Alignof(wasmtime_component_val_t))
      || !lb_buffer(results, 1, sizeof(*results), _Alignof(wasmtime_component_val_t))) return wasmtime_error_new("Unavailable owned WIT import or signature mismatch");
  ow_native_conversion input, output;
  ow_native_conversion_init(&input, host); ow_native_conversion_init(&output, host);
  ov_result_owner owner = {0}; lbov_7fab4b2842f6c64d9621_t167081552b6f9c1d1afd value = {0};
  wasmtime_component_val_t converted = {0}; wasmtime_error_t *failure = NULL;
  int status = 0;
  lbov_7fab4b2842f6c64d9621_t23107461f72b24c37654 arg0 = {0};
  if (!ow_decode_4_input(&args[0], &input.scope, &arg0)) {
    (void)ow_native_status(host, input.scope.memory.failure ? (int)input.scope.memory.failure : LB_OWNED_INVALID);
    failure = wasmtime_error_new("Invalid owned WIT input, expired resource or conversion limit"); goto done;
  }
  status = lbov_7fab4b2842f6c64d9621_f61fa6d001212787ff6aa(host->native, &arg0, &value, &owner);
  if (status) {
    (void)ow_native_status(host, status);
    if (status == OV_RESULT) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new("Owned Lean call failed"); goto done;
  }
  if (!ow_encode_9_output(&value, &output.scope, &converted)) {
    (void)ow_native_status(host, output.scope.memory.failure ? (int)output.scope.memory.failure : OV_RESULT);
    failure = wasmtime_error_new("Owned WIT result conversion or resource acquisition failed"); goto done;
  }
  if (!ow_native_ready(host) || host->failure) { failure = wasmtime_error_new("Owned WIT session became unavailable"); goto done; }
  results[0] = converted; converted = (wasmtime_component_val_t){0};
done:
  ow_value_delete(&output.scope, &converted);
  status = ov_owner_clear(&owner);
  if (status) {
    (void)ow_native_status(host, status);
    if (!failure) failure = wasmtime_error_new("Owned Lean result release failed");
  }
  ow_native_conversion_close(&output); ow_native_conversion_close(&input);
  return failure;
}


static wasmtime_error_t *ow_native_import_1(void *data, wasmtime_context_t *context,
    const wasmtime_component_func_type_t *type, wasmtime_component_val_t *args, size_t count,
    wasmtime_component_val_t *results, size_t result_count) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  (void)type;
  ow_native_host *host = data;
  if (!ow_native_ready(host) || context != host->context || !host->call || host->failure
      || count != 0 || result_count != 1
      || !lb_buffer(args, count, sizeof(*args), _Alignof(wasmtime_component_val_t))
      || !lb_buffer(results, 1, sizeof(*results), _Alignof(wasmtime_component_val_t))) return wasmtime_error_new("Unavailable owned WIT import or signature mismatch");
  ow_native_conversion input, output;
  ow_native_conversion_init(&input, host); ow_native_conversion_init(&output, host);
  ov_result_owner owner = {0}; lbov_7fab4b2842f6c64d9621_t648974cffb2d6c1d7951 value = {0};
  wasmtime_component_val_t converted = {0}; wasmtime_error_t *failure = NULL;
  int status = 0;


  status = lbov_7fab4b2842f6c64d9621_fa3218a29f42862f9b113(host->native, &value, &owner);
  if (status) {
    (void)ow_native_status(host, status);
    if (status == OV_RESULT) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new("Owned Lean call failed"); goto done;
  }
  if (!ow_encode_2_output(&value, &output.scope, &converted)) {
    (void)ow_native_status(host, output.scope.memory.failure ? (int)output.scope.memory.failure : OV_RESULT);
    failure = wasmtime_error_new("Owned WIT result conversion or resource acquisition failed"); goto done;
  }
  if (!ow_native_ready(host) || host->failure) { failure = wasmtime_error_new("Owned WIT session became unavailable"); goto done; }
  results[0] = converted; converted = (wasmtime_component_val_t){0};
done:
  ow_value_delete(&output.scope, &converted);
  status = ov_owner_clear(&owner);
  if (status) {
    (void)ow_native_status(host, status);
    if (!failure) failure = wasmtime_error_new("Owned Lean result release failed");
  }
  ow_native_conversion_close(&output); ow_native_conversion_close(&input);
  return failure;
}


static wasmtime_error_t *ow_native_import_2(void *data, wasmtime_context_t *context,
    const wasmtime_component_func_type_t *type, wasmtime_component_val_t *args, size_t count,
    wasmtime_component_val_t *results, size_t result_count) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  (void)type;
  ow_native_host *host = data;
  if (!ow_native_ready(host) || context != host->context || !host->call || host->failure
      || count != 1 || result_count != 1
      || !lb_buffer(args, count, sizeof(*args), _Alignof(wasmtime_component_val_t))
      || !lb_buffer(results, 1, sizeof(*results), _Alignof(wasmtime_component_val_t))) return wasmtime_error_new("Unavailable owned WIT import or signature mismatch");
  ow_native_conversion input, output;
  ow_native_conversion_init(&input, host); ow_native_conversion_init(&output, host);
  ov_result_owner owner = {0}; lbov_7fab4b2842f6c64d9621_t160ce821a84f6887bbfd value = {0};
  wasmtime_component_val_t converted = {0}; wasmtime_error_t *failure = NULL;
  int status = 0;
  lbov_7fab4b2842f6c64d9621_td79b9bbde250ee1779da arg0 = {0};
  if (!ow_decode_7_input(&args[0], &input.scope, &arg0)) {
    (void)ow_native_status(host, input.scope.memory.failure ? (int)input.scope.memory.failure : LB_OWNED_INVALID);
    failure = wasmtime_error_new("Invalid owned WIT input, expired resource or conversion limit"); goto done;
  }
  status = lbov_7fab4b2842f6c64d9621_f483485736ace9af57086(host->native, &arg0, &value, &owner);
  if (status) {
    (void)ow_native_status(host, status);
    if (status == OV_RESULT) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new("Owned Lean call failed"); goto done;
  }
  if (!ow_encode_1_output(&value, &output.scope, &converted)) {
    (void)ow_native_status(host, output.scope.memory.failure ? (int)output.scope.memory.failure : OV_RESULT);
    failure = wasmtime_error_new("Owned WIT result conversion or resource acquisition failed"); goto done;
  }
  if (!ow_native_ready(host) || host->failure) { failure = wasmtime_error_new("Owned WIT session became unavailable"); goto done; }
  results[0] = converted; converted = (wasmtime_component_val_t){0};
done:
  ow_value_delete(&output.scope, &converted);
  status = ov_owner_clear(&owner);
  if (status) {
    (void)ow_native_status(host, status);
    if (!failure) failure = wasmtime_error_new("Owned Lean result release failed");
  }
  ow_native_conversion_close(&output); ow_native_conversion_close(&input);
  return failure;
}


static wasmtime_error_t *ow_native_import_3(void *data, wasmtime_context_t *context,
    const wasmtime_component_func_type_t *type, wasmtime_component_val_t *args, size_t count,
    wasmtime_component_val_t *results, size_t result_count) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  (void)type;
  ow_native_host *host = data;
  if (!ow_native_ready(host) || context != host->context || !host->call || host->failure
      || count != 1 || result_count != 1
      || !lb_buffer(args, count, sizeof(*args), _Alignof(wasmtime_component_val_t))
      || !lb_buffer(results, 1, sizeof(*results), _Alignof(wasmtime_component_val_t))) return wasmtime_error_new("Unavailable owned WIT import or signature mismatch");
  ow_native_conversion input, output;
  ow_native_conversion_init(&input, host); ow_native_conversion_init(&output, host);
  ov_result_owner owner = {0}; lbov_7fab4b2842f6c64d9621_t167081552b6f9c1d1afd value = {0};
  wasmtime_component_val_t converted = {0}; wasmtime_error_t *failure = NULL;
  int status = 0;
  lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b arg0 = {0};
  if (!ow_decode_5_input(&args[0], &input.scope, &arg0)) {
    (void)ow_native_status(host, input.scope.memory.failure ? (int)input.scope.memory.failure : LB_OWNED_INVALID);
    failure = wasmtime_error_new("Invalid owned WIT input, expired resource or conversion limit"); goto done;
  }
  status = lbov_7fab4b2842f6c64d9621_f2f69e4eb3cbfdff310da(host->native, &arg0, &value, &owner);
  if (status) {
    (void)ow_native_status(host, status);
    if (status == OV_RESULT) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new("Owned Lean call failed"); goto done;
  }
  if (!ow_encode_9_output(&value, &output.scope, &converted)) {
    (void)ow_native_status(host, output.scope.memory.failure ? (int)output.scope.memory.failure : OV_RESULT);
    failure = wasmtime_error_new("Owned WIT result conversion or resource acquisition failed"); goto done;
  }
  if (!ow_native_ready(host) || host->failure) { failure = wasmtime_error_new("Owned WIT session became unavailable"); goto done; }
  results[0] = converted; converted = (wasmtime_component_val_t){0};
done:
  ow_value_delete(&output.scope, &converted);
  status = ov_owner_clear(&owner);
  if (status) {
    (void)ow_native_status(host, status);
    if (!failure) failure = wasmtime_error_new("Owned Lean result release failed");
  }
  ow_native_conversion_close(&output); ow_native_conversion_close(&input);
  return failure;
}


static wasmtime_error_t *ow_native_import_4(void *data, wasmtime_context_t *context,
    const wasmtime_component_func_type_t *type, wasmtime_component_val_t *args, size_t count,
    wasmtime_component_val_t *results, size_t result_count) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  (void)type;
  ow_native_host *host = data;
  if (!ow_native_ready(host) || context != host->context || !host->call || host->failure
      || count != 1 || result_count != 1
      || !lb_buffer(args, count, sizeof(*args), _Alignof(wasmtime_component_val_t))
      || !lb_buffer(results, 1, sizeof(*results), _Alignof(wasmtime_component_val_t))) return wasmtime_error_new("Unavailable owned WIT import or signature mismatch");
  ow_native_conversion input, output;
  ow_native_conversion_init(&input, host); ow_native_conversion_init(&output, host);
  ov_result_owner owner = {0}; lbov_7fab4b2842f6c64d9621_t23107461f72b24c37654 value = {0};
  wasmtime_component_val_t converted = {0}; wasmtime_error_t *failure = NULL;
  int status = 0;
  lbov_7fab4b2842f6c64d9621_t23107461f72b24c37654 arg0 = {0};
  if (!ow_decode_4_input(&args[0], &input.scope, &arg0)) {
    (void)ow_native_status(host, input.scope.memory.failure ? (int)input.scope.memory.failure : LB_OWNED_INVALID);
    failure = wasmtime_error_new("Invalid owned WIT input, expired resource or conversion limit"); goto done;
  }
  status = lbov_7fab4b2842f6c64d9621_f0711e856cfa97d876c9a(host->native, &arg0, &value, &owner);
  if (status) {
    (void)ow_native_status(host, status);
    if (status == OV_RESULT) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new("Owned Lean call failed"); goto done;
  }
  if (!ow_encode_4_output(&value, &output.scope, &converted)) {
    (void)ow_native_status(host, output.scope.memory.failure ? (int)output.scope.memory.failure : OV_RESULT);
    failure = wasmtime_error_new("Owned WIT result conversion or resource acquisition failed"); goto done;
  }
  if (!ow_native_ready(host) || host->failure) { failure = wasmtime_error_new("Owned WIT session became unavailable"); goto done; }
  results[0] = converted; converted = (wasmtime_component_val_t){0};
done:
  ow_value_delete(&output.scope, &converted);
  status = ov_owner_clear(&owner);
  if (status) {
    (void)ow_native_status(host, status);
    if (!failure) failure = wasmtime_error_new("Owned Lean result release failed");
  }
  ow_native_conversion_close(&output); ow_native_conversion_close(&input);
  return failure;
}


static wasmtime_error_t *ow_native_import_5(void *data, wasmtime_context_t *context,
    const wasmtime_component_func_type_t *type, wasmtime_component_val_t *args, size_t count,
    wasmtime_component_val_t *results, size_t result_count) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  (void)type;
  ow_native_host *host = data;
  if (!ow_native_ready(host) || context != host->context || !host->call || host->failure
      || count != 1 || result_count != 1
      || !lb_buffer(args, count, sizeof(*args), _Alignof(wasmtime_component_val_t))
      || !lb_buffer(results, 1, sizeof(*results), _Alignof(wasmtime_component_val_t))) return wasmtime_error_new("Unavailable owned WIT import or signature mismatch");
  ow_native_conversion input, output;
  ow_native_conversion_init(&input, host); ow_native_conversion_init(&output, host);
  ov_result_owner owner = {0}; lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b value = {0};
  wasmtime_component_val_t converted = {0}; wasmtime_error_t *failure = NULL;
  int status = 0;
  lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b arg0 = {0};
  if (!ow_decode_5_input(&args[0], &input.scope, &arg0)) {
    (void)ow_native_status(host, input.scope.memory.failure ? (int)input.scope.memory.failure : LB_OWNED_INVALID);
    failure = wasmtime_error_new("Invalid owned WIT input, expired resource or conversion limit"); goto done;
  }
  status = lbov_7fab4b2842f6c64d9621_f535babcfd8d0f67ea0e6(host->native, &arg0, &value, &owner);
  if (status) {
    (void)ow_native_status(host, status);
    if (status == OV_RESULT) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new("Owned Lean call failed"); goto done;
  }
  if (!ow_encode_5_output(&value, &output.scope, &converted)) {
    (void)ow_native_status(host, output.scope.memory.failure ? (int)output.scope.memory.failure : OV_RESULT);
    failure = wasmtime_error_new("Owned WIT result conversion or resource acquisition failed"); goto done;
  }
  if (!ow_native_ready(host) || host->failure) { failure = wasmtime_error_new("Owned WIT session became unavailable"); goto done; }
  results[0] = converted; converted = (wasmtime_component_val_t){0};
done:
  ow_value_delete(&output.scope, &converted);
  status = ov_owner_clear(&owner);
  if (status) {
    (void)ow_native_status(host, status);
    if (!failure) failure = wasmtime_error_new("Owned Lean result release failed");
  }
  ow_native_conversion_close(&output); ow_native_conversion_close(&input);
  return failure;
}


static wasmtime_error_t *ow_native_import_6(void *data, wasmtime_context_t *context,
    const wasmtime_component_func_type_t *type, wasmtime_component_val_t *args, size_t count,
    wasmtime_component_val_t *results, size_t result_count) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  (void)type;
  ow_native_host *host = data;
  if (!ow_native_ready(host) || context != host->context || !host->call || host->failure
      || count != 1 || result_count != 1
      || !lb_buffer(args, count, sizeof(*args), _Alignof(wasmtime_component_val_t))
      || !lb_buffer(results, 1, sizeof(*results), _Alignof(wasmtime_component_val_t))) return wasmtime_error_new("Unavailable owned WIT import or signature mismatch");
  ow_native_conversion input, output;
  ow_native_conversion_init(&input, host); ow_native_conversion_init(&output, host);
  ov_result_owner owner = {0}; lbov_7fab4b2842f6c64d9621_tf790309465bbf573c7b9 value = {0};
  wasmtime_component_val_t converted = {0}; wasmtime_error_t *failure = NULL;
  int status = 0;
  lbov_7fab4b2842f6c64d9621_tf790309465bbf573c7b9 arg0 = {0};
  if (!ow_decode_0_input(&args[0], &input.scope, &arg0)) {
    (void)ow_native_status(host, input.scope.memory.failure ? (int)input.scope.memory.failure : LB_OWNED_INVALID);
    failure = wasmtime_error_new("Invalid owned WIT input, expired resource or conversion limit"); goto done;
  }
  status = lbov_7fab4b2842f6c64d9621_f25326d75f45c4daa9d9d(host->native, &arg0, &value, &owner);
  if (status) {
    (void)ow_native_status(host, status);
    if (status == OV_RESULT) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new("Owned Lean call failed"); goto done;
  }
  if (!ow_encode_0_output(&value, &output.scope, &converted)) {
    (void)ow_native_status(host, output.scope.memory.failure ? (int)output.scope.memory.failure : OV_RESULT);
    failure = wasmtime_error_new("Owned WIT result conversion or resource acquisition failed"); goto done;
  }
  if (!ow_native_ready(host) || host->failure) { failure = wasmtime_error_new("Owned WIT session became unavailable"); goto done; }
  results[0] = converted; converted = (wasmtime_component_val_t){0};
done:
  ow_value_delete(&output.scope, &converted);
  status = ov_owner_clear(&owner);
  if (status) {
    (void)ow_native_status(host, status);
    if (!failure) failure = wasmtime_error_new("Owned Lean result release failed");
  }
  ow_native_conversion_close(&output); ow_native_conversion_close(&input);
  return failure;
}


static wasmtime_error_t *ow_native_import_7(void *data, wasmtime_context_t *context,
    const wasmtime_component_func_type_t *type, wasmtime_component_val_t *args, size_t count,
    wasmtime_component_val_t *results, size_t result_count) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  (void)type;
  ow_native_host *host = data;
  if (!ow_native_ready(host) || context != host->context || !host->call || host->failure
      || count != 1 || result_count != 1
      || !lb_buffer(args, count, sizeof(*args), _Alignof(wasmtime_component_val_t))
      || !lb_buffer(results, 1, sizeof(*results), _Alignof(wasmtime_component_val_t))) return wasmtime_error_new("Unavailable owned WIT import or signature mismatch");
  ow_native_conversion input, output;
  ow_native_conversion_init(&input, host); ow_native_conversion_init(&output, host);
  ov_result_owner owner = {0}; lbov_7fab4b2842f6c64d9621_t4ce841c87ea3b1559bfb value = {0};
  wasmtime_component_val_t converted = {0}; wasmtime_error_t *failure = NULL;
  int status = 0;
  lbov_7fab4b2842f6c64d9621_t4ce841c87ea3b1559bfb arg0 = {0};
  if (!ow_decode_6_input(&args[0], &input.scope, &arg0)) {
    (void)ow_native_status(host, input.scope.memory.failure ? (int)input.scope.memory.failure : LB_OWNED_INVALID);
    failure = wasmtime_error_new("Invalid owned WIT input, expired resource or conversion limit"); goto done;
  }
  status = lbov_7fab4b2842f6c64d9621_feb082cf837ef02082ea8(host->native, &arg0, &value, &owner);
  if (status) {
    (void)ow_native_status(host, status);
    if (status == OV_RESULT) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new("Owned Lean call failed"); goto done;
  }
  if (!ow_encode_6_output(&value, &output.scope, &converted)) {
    (void)ow_native_status(host, output.scope.memory.failure ? (int)output.scope.memory.failure : OV_RESULT);
    failure = wasmtime_error_new("Owned WIT result conversion or resource acquisition failed"); goto done;
  }
  if (!ow_native_ready(host) || host->failure) { failure = wasmtime_error_new("Owned WIT session became unavailable"); goto done; }
  results[0] = converted; converted = (wasmtime_component_val_t){0};
done:
  ow_value_delete(&output.scope, &converted);
  status = ov_owner_clear(&owner);
  if (status) {
    (void)ow_native_status(host, status);
    if (!failure) failure = wasmtime_error_new("Owned Lean result release failed");
  }
  ow_native_conversion_close(&output); ow_native_conversion_close(&input);
  return failure;
}


static wasmtime_error_t *ow_native_import_8(void *data, wasmtime_context_t *context,
    const wasmtime_component_func_type_t *type, wasmtime_component_val_t *args, size_t count,
    wasmtime_component_val_t *results, size_t result_count) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  (void)type;
  ow_native_host *host = data;
  if (!ow_native_ready(host) || context != host->context || !host->call || host->failure
      || count != 2 || result_count != 1
      || !lb_buffer(args, count, sizeof(*args), _Alignof(wasmtime_component_val_t))
      || !lb_buffer(results, 1, sizeof(*results), _Alignof(wasmtime_component_val_t))) return wasmtime_error_new("Unavailable owned WIT import or signature mismatch");
  ow_native_conversion input, output;
  ow_native_conversion_init(&input, host); ow_native_conversion_init(&output, host);
  ov_result_owner owner = {0}; lbov_7fab4b2842f6c64d9621_td79b9bbde250ee1779da value = {0};
  wasmtime_component_val_t converted = {0}; wasmtime_error_t *failure = NULL;
  int status = 0;
  lbov_7fab4b2842f6c64d9621_t167081552b6f9c1d1afd arg0 = {0};
  lbov_7fab4b2842f6c64d9621_tdc0347e1f7f5c4d928f1 arg1 = {0};
  if (!ow_decode_9_input(&args[0], &input.scope, &arg0)) {
    (void)ow_native_status(host, input.scope.memory.failure ? (int)input.scope.memory.failure : LB_OWNED_INVALID);
    failure = wasmtime_error_new("Invalid owned WIT input, expired resource or conversion limit"); goto done;
  }
  if (!ow_decode_10_input(&args[1], &input.scope, &arg1)) {
    (void)ow_native_status(host, input.scope.memory.failure ? (int)input.scope.memory.failure : LB_OWNED_INVALID);
    failure = wasmtime_error_new("Invalid owned WIT input, expired resource or conversion limit"); goto done;
  }
  status = lbov_7fab4b2842f6c64d9621_fa1e5189bd92568e4b939(host->native, &arg0, &arg1, &value, &owner);
  if (status) {
    (void)ow_native_status(host, status);
    if (status == OV_RESULT) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new("Owned Lean call failed"); goto done;
  }
  if (!ow_encode_7_output(&value, &output.scope, &converted)) {
    (void)ow_native_status(host, output.scope.memory.failure ? (int)output.scope.memory.failure : OV_RESULT);
    failure = wasmtime_error_new("Owned WIT result conversion or resource acquisition failed"); goto done;
  }
  if (!ow_native_ready(host) || host->failure) { failure = wasmtime_error_new("Owned WIT session became unavailable"); goto done; }
  results[0] = converted; converted = (wasmtime_component_val_t){0};
done:
  ow_value_delete(&output.scope, &converted);
  status = ov_owner_clear(&owner);
  if (status) {
    (void)ow_native_status(host, status);
    if (!failure) failure = wasmtime_error_new("Owned Lean result release failed");
  }
  ow_native_conversion_close(&output); ow_native_conversion_close(&input);
  return failure;
}


static wasmtime_error_t *ow_native_import_9(void *data, wasmtime_context_t *context,
    const wasmtime_component_func_type_t *type, wasmtime_component_val_t *args, size_t count,
    wasmtime_component_val_t *results, size_t result_count) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  (void)type;
  ow_native_host *host = data;
  if (!ow_native_ready(host) || context != host->context || !host->call || host->failure
      || count != 2 || result_count != 1
      || !lb_buffer(args, count, sizeof(*args), _Alignof(wasmtime_component_val_t))
      || !lb_buffer(results, 1, sizeof(*results), _Alignof(wasmtime_component_val_t))) return wasmtime_error_new("Unavailable owned WIT import or signature mismatch");
  ow_native_conversion input, output;
  ow_native_conversion_init(&input, host); ow_native_conversion_init(&output, host);
  ov_result_owner owner = {0}; lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b value = {0};
  wasmtime_component_val_t converted = {0}; wasmtime_error_t *failure = NULL;
  int status = 0;
  lbov_7fab4b2842f6c64d9621_t23107461f72b24c37654 arg0 = {0};
  lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b arg1 = {0};
  if (!ow_decode_4_input(&args[0], &input.scope, &arg0)) {
    (void)ow_native_status(host, input.scope.memory.failure ? (int)input.scope.memory.failure : LB_OWNED_INVALID);
    failure = wasmtime_error_new("Invalid owned WIT input, expired resource or conversion limit"); goto done;
  }
  if (!ow_decode_5_input(&args[1], &input.scope, &arg1)) {
    (void)ow_native_status(host, input.scope.memory.failure ? (int)input.scope.memory.failure : LB_OWNED_INVALID);
    failure = wasmtime_error_new("Invalid owned WIT input, expired resource or conversion limit"); goto done;
  }
  status = lbov_7fab4b2842f6c64d9621_feaac3cc8d9197bd7bbca(host->native, &arg0, &arg1, &value, &owner);
  if (status) {
    (void)ow_native_status(host, status);
    if (status == OV_RESULT) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new("Owned Lean call failed"); goto done;
  }
  if (!ow_encode_5_output(&value, &output.scope, &converted)) {
    (void)ow_native_status(host, output.scope.memory.failure ? (int)output.scope.memory.failure : OV_RESULT);
    failure = wasmtime_error_new("Owned WIT result conversion or resource acquisition failed"); goto done;
  }
  if (!ow_native_ready(host) || host->failure) { failure = wasmtime_error_new("Owned WIT session became unavailable"); goto done; }
  results[0] = converted; converted = (wasmtime_component_val_t){0};
done:
  ow_value_delete(&output.scope, &converted);
  status = ov_owner_clear(&owner);
  if (status) {
    (void)ow_native_status(host, status);
    if (!failure) failure = wasmtime_error_new("Owned Lean result release failed");
  }
  ow_native_conversion_close(&output); ow_native_conversion_close(&input);
  return failure;
}


static wasmtime_error_t *ow_native_import_10(void *data, wasmtime_context_t *context,
    const wasmtime_component_func_type_t *type, wasmtime_component_val_t *args, size_t count,
    wasmtime_component_val_t *results, size_t result_count) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  (void)type;
  ow_native_host *host = data;
  if (!ow_native_ready(host) || context != host->context || !host->call || host->failure
      || count != 1 || result_count != 1
      || !lb_buffer(args, count, sizeof(*args), _Alignof(wasmtime_component_val_t))
      || !lb_buffer(results, 1, sizeof(*results), _Alignof(wasmtime_component_val_t))) return wasmtime_error_new("Unavailable owned WIT import or signature mismatch");
  ow_native_conversion input, output;
  ow_native_conversion_init(&input, host); ow_native_conversion_init(&output, host);
  ov_result_owner owner = {0}; lbov_7fab4b2842f6c64d9621_t167081552b6f9c1d1afd value = {0};
  wasmtime_component_val_t converted = {0}; wasmtime_error_t *failure = NULL;
  int status = 0;
  lbov_7fab4b2842f6c64d9621_td79b9bbde250ee1779da arg0 = {0};
  if (!ow_decode_7_input(&args[0], &input.scope, &arg0)) {
    (void)ow_native_status(host, input.scope.memory.failure ? (int)input.scope.memory.failure : LB_OWNED_INVALID);
    failure = wasmtime_error_new("Invalid owned WIT input, expired resource or conversion limit"); goto done;
  }
  status = lbov_7fab4b2842f6c64d9621_fec926afda994fba3abe2(host->native, &arg0, &value, &owner);
  if (status) {
    (void)ow_native_status(host, status);
    if (status == OV_RESULT) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new("Owned Lean call failed"); goto done;
  }
  if (!ow_encode_9_output(&value, &output.scope, &converted)) {
    (void)ow_native_status(host, output.scope.memory.failure ? (int)output.scope.memory.failure : OV_RESULT);
    failure = wasmtime_error_new("Owned WIT result conversion or resource acquisition failed"); goto done;
  }
  if (!ow_native_ready(host) || host->failure) { failure = wasmtime_error_new("Owned WIT session became unavailable"); goto done; }
  results[0] = converted; converted = (wasmtime_component_val_t){0};
done:
  ow_value_delete(&output.scope, &converted);
  status = ov_owner_clear(&owner);
  if (status) {
    (void)ow_native_status(host, status);
    if (!failure) failure = wasmtime_error_new("Owned Lean result release failed");
  }
  ow_native_conversion_close(&output); ow_native_conversion_close(&input);
  return failure;
}


static wasmtime_error_t *ow_native_import_11(void *data, wasmtime_context_t *context,
    const wasmtime_component_func_type_t *type, wasmtime_component_val_t *args, size_t count,
    wasmtime_component_val_t *results, size_t result_count) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  (void)type;
  ow_native_host *host = data;
  if (!ow_native_ready(host) || context != host->context || !host->call || host->failure
      || count != 1 || result_count != 1
      || !lb_buffer(args, count, sizeof(*args), _Alignof(wasmtime_component_val_t))
      || !lb_buffer(results, 1, sizeof(*results), _Alignof(wasmtime_component_val_t))) return wasmtime_error_new("Unavailable owned WIT import or signature mismatch");
  ow_native_conversion input, output;
  ow_native_conversion_init(&input, host); ow_native_conversion_init(&output, host);
  ov_result_owner owner = {0}; lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b value = {0};
  wasmtime_component_val_t converted = {0}; wasmtime_error_t *failure = NULL;
  int status = 0;
  lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b arg0 = {0};
  if (!ow_decode_5_output(&args[0], &input.scope, &arg0)) {
    (void)ow_native_status(host, input.scope.memory.failure ? (int)input.scope.memory.failure : LB_OWNED_INVALID);
    failure = wasmtime_error_new("Invalid owned WIT input, expired resource or conversion limit"); goto done;
  }
  status = lbov_7fab4b2842f6c64d9621_f040aca3025d850fc12cc(host->native, &arg0, host->input_transfers, &value, &owner);
  if (status) {
    (void)ow_native_status(host, status);
    if (status == OV_RESULT) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new("Owned Lean call failed"); goto done;
  }
  if (!ow_encode_5_output(&value, &output.scope, &converted)) {
    (void)ow_native_status(host, output.scope.memory.failure ? (int)output.scope.memory.failure : OV_RESULT);
    failure = wasmtime_error_new("Owned WIT result conversion or resource acquisition failed"); goto done;
  }
  if (!ow_native_ready(host) || host->failure) { failure = wasmtime_error_new("Owned WIT session became unavailable"); goto done; }
  results[0] = converted; converted = (wasmtime_component_val_t){0};
done:
  ow_value_delete(&output.scope, &converted);
  status = ov_owner_clear(&owner);
  if (status) {
    (void)ow_native_status(host, status);
    if (!failure) failure = wasmtime_error_new("Owned Lean result release failed");
  }
  ow_native_conversion_close(&output); ow_native_conversion_close(&input);
  return failure;
}


static wasmtime_error_t *ow_native_import_12(void *data, wasmtime_context_t *context,
    const wasmtime_component_func_type_t *type, wasmtime_component_val_t *args, size_t count,
    wasmtime_component_val_t *results, size_t result_count) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  (void)type;
  ow_native_host *host = data;
  if (!ow_native_ready(host) || context != host->context || !host->call || host->failure
      || count != 2 || result_count != 1
      || !lb_buffer(args, count, sizeof(*args), _Alignof(wasmtime_component_val_t))
      || !lb_buffer(results, 1, sizeof(*results), _Alignof(wasmtime_component_val_t))) return wasmtime_error_new("Unavailable owned WIT import or signature mismatch");
  ow_native_conversion input, output;
  ow_native_conversion_init(&input, host); ow_native_conversion_init(&output, host);
  ov_result_owner owner = {0}; lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b value = {0};
  wasmtime_component_val_t converted = {0}; wasmtime_error_t *failure = NULL;
  int status = 0;
  lbov_7fab4b2842f6c64d9621_t23107461f72b24c37654 arg0 = {0};
  lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b arg1 = {0};
  if (!ow_decode_4_output(&args[0], &input.scope, &arg0)) {
    (void)ow_native_status(host, input.scope.memory.failure ? (int)input.scope.memory.failure : LB_OWNED_INVALID);
    failure = wasmtime_error_new("Invalid owned WIT input, expired resource or conversion limit"); goto done;
  }
  if (!ow_decode_5_output(&args[1], &input.scope, &arg1)) {
    (void)ow_native_status(host, input.scope.memory.failure ? (int)input.scope.memory.failure : LB_OWNED_INVALID);
    failure = wasmtime_error_new("Invalid owned WIT input, expired resource or conversion limit"); goto done;
  }
  status = lbov_7fab4b2842f6c64d9621_fc4cffe83b4b420b09021(host->native, &arg0, &arg1, host->input_transfers, &value, &owner);
  if (status) {
    (void)ow_native_status(host, status);
    if (status == OV_RESULT) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new("Owned Lean call failed"); goto done;
  }
  if (!ow_encode_5_output(&value, &output.scope, &converted)) {
    (void)ow_native_status(host, output.scope.memory.failure ? (int)output.scope.memory.failure : OV_RESULT);
    failure = wasmtime_error_new("Owned WIT result conversion or resource acquisition failed"); goto done;
  }
  if (!ow_native_ready(host) || host->failure) { failure = wasmtime_error_new("Owned WIT session became unavailable"); goto done; }
  results[0] = converted; converted = (wasmtime_component_val_t){0};
done:
  ow_value_delete(&output.scope, &converted);
  status = ov_owner_clear(&owner);
  if (status) {
    (void)ow_native_status(host, status);
    if (!failure) failure = wasmtime_error_new("Owned Lean result release failed");
  }
  ow_native_conversion_close(&output); ow_native_conversion_close(&input);
  return failure;
}


static wasmtime_error_t *ow_native_import_13(void *data, wasmtime_context_t *context,
    const wasmtime_component_func_type_t *type, wasmtime_component_val_t *args, size_t count,
    wasmtime_component_val_t *results, size_t result_count) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  (void)type;
  ow_native_host *host = data;
  if (!ow_native_ready(host) || context != host->context || !host->call || host->failure
      || count != 2 || result_count != 1
      || !lb_buffer(args, count, sizeof(*args), _Alignof(wasmtime_component_val_t))
      || !lb_buffer(results, 1, sizeof(*results), _Alignof(wasmtime_component_val_t))) return wasmtime_error_new("Unavailable owned WIT import or signature mismatch");
  ow_native_conversion input, output;
  ow_native_conversion_init(&input, host); ow_native_conversion_init(&output, host);
  ov_result_owner owner = {0}; lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b value = {0};
  wasmtime_component_val_t converted = {0}; wasmtime_error_t *failure = NULL;
  int status = 0;
  lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b arg0 = {0};
  lbov_7fab4b2842f6c64d9621_t5035e6ea0903f12776d9 arg1 = {0};
  if (!ow_decode_5_output(&args[0], &input.scope, &arg0)) {
    (void)ow_native_status(host, input.scope.memory.failure ? (int)input.scope.memory.failure : LB_OWNED_INVALID);
    failure = wasmtime_error_new("Invalid owned WIT input, expired resource or conversion limit"); goto done;
  }
  if (!ow_decode_3_input(&args[1], &input.scope, &arg1)) {
    (void)ow_native_status(host, input.scope.memory.failure ? (int)input.scope.memory.failure : LB_OWNED_INVALID);
    failure = wasmtime_error_new("Invalid owned WIT input, expired resource or conversion limit"); goto done;
  }
  status = lbov_7fab4b2842f6c64d9621_f33442f0a4409864e6a4a(host->native, &arg0, &arg1, host->input_transfers, &value, &owner);
  if (status) {
    (void)ow_native_status(host, status);
    if (status == OV_RESULT) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new("Owned Lean call failed"); goto done;
  }
  if (!ow_encode_5_output(&value, &output.scope, &converted)) {
    (void)ow_native_status(host, output.scope.memory.failure ? (int)output.scope.memory.failure : OV_RESULT);
    failure = wasmtime_error_new("Owned WIT result conversion or resource acquisition failed"); goto done;
  }
  if (!ow_native_ready(host) || host->failure) { failure = wasmtime_error_new("Owned WIT session became unavailable"); goto done; }
  results[0] = converted; converted = (wasmtime_component_val_t){0};
done:
  ow_value_delete(&output.scope, &converted);
  status = ov_owner_clear(&owner);
  if (status) {
    (void)ow_native_status(host, status);
    if (!failure) failure = wasmtime_error_new("Owned Lean result release failed");
  }
  ow_native_conversion_close(&output); ow_native_conversion_close(&input);
  return failure;
}


static wasmtime_error_t *ow_native_import_14(void *data, wasmtime_context_t *context,
    const wasmtime_component_func_type_t *type, wasmtime_component_val_t *args, size_t count,
    wasmtime_component_val_t *results, size_t result_count) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  (void)type;
  ow_native_host *host = data;
  if (!ow_native_ready(host) || context != host->context || !host->call || host->failure
      || count != 2 || result_count != 1
      || !lb_buffer(args, count, sizeof(*args), _Alignof(wasmtime_component_val_t))
      || !lb_buffer(results, 1, sizeof(*results), _Alignof(wasmtime_component_val_t))) return wasmtime_error_new("Unavailable owned WIT import or signature mismatch");
  ow_native_conversion input, output;
  ow_native_conversion_init(&input, host); ow_native_conversion_init(&output, host);
  ov_result_owner owner = {0}; lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b value = {0};
  wasmtime_component_val_t converted = {0}; wasmtime_error_t *failure = NULL;
  int status = 0;
  lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b arg0 = {0};
  lbov_7fab4b2842f6c64d9621_t5035e6ea0903f12776d9 arg1 = {0};
  if (!ow_decode_5_input(&args[0], &input.scope, &arg0)) {
    (void)ow_native_status(host, input.scope.memory.failure ? (int)input.scope.memory.failure : LB_OWNED_INVALID);
    failure = wasmtime_error_new("Invalid owned WIT input, expired resource or conversion limit"); goto done;
  }
  if (!ow_decode_3_input(&args[1], &input.scope, &arg1)) {
    (void)ow_native_status(host, input.scope.memory.failure ? (int)input.scope.memory.failure : LB_OWNED_INVALID);
    failure = wasmtime_error_new("Invalid owned WIT input, expired resource or conversion limit"); goto done;
  }
  status = lbov_7fab4b2842f6c64d9621_f7d6c8617a0788c12de15(host->native, &arg0, &arg1, &value, &owner);
  if (status) {
    (void)ow_native_status(host, status);
    if (status == OV_RESULT) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new("Owned Lean call failed"); goto done;
  }
  if (!ow_encode_5_output(&value, &output.scope, &converted)) {
    (void)ow_native_status(host, output.scope.memory.failure ? (int)output.scope.memory.failure : OV_RESULT);
    failure = wasmtime_error_new("Owned WIT result conversion or resource acquisition failed"); goto done;
  }
  if (!ow_native_ready(host) || host->failure) { failure = wasmtime_error_new("Owned WIT session became unavailable"); goto done; }
  results[0] = converted; converted = (wasmtime_component_val_t){0};
done:
  ow_value_delete(&output.scope, &converted);
  status = ov_owner_clear(&owner);
  if (status) {
    (void)ow_native_status(host, status);
    if (!failure) failure = wasmtime_error_new("Owned Lean result release failed");
  }
  ow_native_conversion_close(&output); ow_native_conversion_close(&input);
  return failure;
}


static wasmtime_error_t *ow_native_import_15(void *data, wasmtime_context_t *context,
    const wasmtime_component_func_type_t *type, wasmtime_component_val_t *args, size_t count,
    wasmtime_component_val_t *results, size_t result_count) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  (void)type;
  ow_native_host *host = data;
  if (!ow_native_ready(host) || context != host->context || !host->call || host->failure
      || count != 2 || result_count != 1
      || !lb_buffer(args, count, sizeof(*args), _Alignof(wasmtime_component_val_t))
      || !lb_buffer(results, 1, sizeof(*results), _Alignof(wasmtime_component_val_t))) return wasmtime_error_new("Unavailable owned WIT import or signature mismatch");
  ow_native_conversion input, output;
  ow_native_conversion_init(&input, host); ow_native_conversion_init(&output, host);
  ov_result_owner owner = {0}; lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b value = {0};
  wasmtime_component_val_t converted = {0}; wasmtime_error_t *failure = NULL;
  int status = 0;
  lbov_7fab4b2842f6c64d9621_t648974cffb2d6c1d7951 arg0 = {0};
  lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b arg1 = {0};
  if (!ow_decode_2_input(&args[0], &input.scope, &arg0)) {
    (void)ow_native_status(host, input.scope.memory.failure ? (int)input.scope.memory.failure : LB_OWNED_INVALID);
    failure = wasmtime_error_new("Invalid owned WIT input, expired resource or conversion limit"); goto done;
  }
  if (!ow_decode_5_input(&args[1], &input.scope, &arg1)) {
    (void)ow_native_status(host, input.scope.memory.failure ? (int)input.scope.memory.failure : LB_OWNED_INVALID);
    failure = wasmtime_error_new("Invalid owned WIT input, expired resource or conversion limit"); goto done;
  }
  status = lbov_7fab4b2842f6c64d9621_v648974cffb2d6c1d7951_apply(host->native, &arg0, &arg1, &value, &owner);
  if (status) {
    (void)ow_native_status(host, status);
    if (status == OV_RESULT) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new("Owned Lean call failed"); goto done;
  }
  if (!ow_encode_5_output(&value, &output.scope, &converted)) {
    (void)ow_native_status(host, output.scope.memory.failure ? (int)output.scope.memory.failure : OV_RESULT);
    failure = wasmtime_error_new("Owned WIT result conversion or resource acquisition failed"); goto done;
  }
  if (!ow_native_ready(host) || host->failure) { failure = wasmtime_error_new("Owned WIT session became unavailable"); goto done; }
  results[0] = converted; converted = (wasmtime_component_val_t){0};
done:
  ow_value_delete(&output.scope, &converted);
  status = ov_owner_clear(&owner);
  if (status) {
    (void)ow_native_status(host, status);
    if (!failure) failure = wasmtime_error_new("Owned Lean result release failed");
  }
  ow_native_conversion_close(&output); ow_native_conversion_close(&input);
  return failure;
}


static wasmtime_error_t *ow_native_import_16(void *data, wasmtime_context_t *context,
    const wasmtime_component_func_type_t *type, wasmtime_component_val_t *args, size_t count,
    wasmtime_component_val_t *results, size_t result_count) {
  const char *package_failure = lb_package_failure();
  if (package_failure) return wasmtime_error_new(package_failure);
  (void)type;
  ow_native_host *host = data;
  if (!ow_native_ready(host) || context != host->context || !host->call || host->failure
      || count != 2 || result_count != 1
      || !lb_buffer(args, count, sizeof(*args), _Alignof(wasmtime_component_val_t))
      || !lb_buffer(results, 1, sizeof(*results), _Alignof(wasmtime_component_val_t))) return wasmtime_error_new("Unavailable owned WIT import or signature mismatch");
  ow_native_conversion input, output;
  ow_native_conversion_init(&input, host); ow_native_conversion_init(&output, host);
  ov_result_owner owner = {0}; lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b value = {0};
  wasmtime_component_val_t converted = {0}; wasmtime_error_t *failure = NULL;
  int status = 0;
  lbov_7fab4b2842f6c64d9621_t5035e6ea0903f12776d9 arg0 = {0};
  lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b arg1 = {0};
  if (!ow_decode_3_input(&args[0], &input.scope, &arg0)) {
    (void)ow_native_status(host, input.scope.memory.failure ? (int)input.scope.memory.failure : LB_OWNED_INVALID);
    failure = wasmtime_error_new("Invalid owned WIT input, expired resource or conversion limit"); goto done;
  }
  if (!ow_decode_5_input(&args[1], &input.scope, &arg1)) {
    (void)ow_native_status(host, input.scope.memory.failure ? (int)input.scope.memory.failure : LB_OWNED_INVALID);
    failure = wasmtime_error_new("Invalid owned WIT input, expired resource or conversion limit"); goto done;
  }
  status = lbov_7fab4b2842f6c64d9621_v5035e6ea0903f12776d9_apply(host->native, &arg0, &arg1, &value, &owner);
  if (status) {
    (void)ow_native_status(host, status);
    if (status == OV_RESULT) lean_bridge_native_runtime_retire();
    failure = wasmtime_error_new("Owned Lean call failed"); goto done;
  }
  if (!ow_encode_5_output(&value, &output.scope, &converted)) {
    (void)ow_native_status(host, output.scope.memory.failure ? (int)output.scope.memory.failure : OV_RESULT);
    failure = wasmtime_error_new("Owned WIT result conversion or resource acquisition failed"); goto done;
  }
  if (!ow_native_ready(host) || host->failure) { failure = wasmtime_error_new("Owned WIT session became unavailable"); goto done; }
  results[0] = converted; converted = (wasmtime_component_val_t){0};
done:
  ow_value_delete(&output.scope, &converted);
  status = ov_owner_clear(&owner);
  if (status) {
    (void)ow_native_status(host, status);
    if (!failure) failure = wasmtime_error_new("Owned Lean result release failed");
  }
  ow_native_conversion_close(&output); ow_native_conversion_close(&input);
  return failure;
}

static inline wasmtime_error_t *ow_native_link(ow_native_host *host, wasmtime_component_linker_t *linker) {
  if (!ow_native_ready(host) || !linker) return wasmtime_error_new("Invalid owned WIT host");
  wasmtime_component_linker_instance_t *root = wasmtime_component_linker_root(linker), *native = NULL;
  wasmtime_error_t *error = wasmtime_component_linker_instance_add_instance(root, "lean-bridge:owned-checked-records/native@1.0.0", 46, &native);
  if (!error) {
    if (!error) {
      wasmtime_component_resource_type_t *type = wasmtime_component_resource_type_new_host(host->tags[2]);
      error = wasmtime_component_linker_instance_add_resource(native, "identity-callback26621c40b48fce52ca37", 37, type, ow_native_resource_drop, host, NULL);
      wasmtime_component_resource_type_delete(type);
    }
    if (!error) {
      wasmtime_component_resource_type_t *type = wasmtime_component_resource_type_new_host(host->tags[3]);
      error = wasmtime_component_linker_instance_add_resource(native, "identity-callbackb2d3d6fd4e031785f278", 37, type, ow_native_resource_drop, host, NULL);
      wasmtime_component_resource_type_delete(type);
    }
    if (!error) {
      wasmtime_component_resource_type_t *type = wasmtime_component_resource_type_new_host(host->tags[7]);
      error = wasmtime_component_linker_instance_add_resource(native, "identity-ticket", 15, type, ow_native_resource_drop, host, NULL);
      wasmtime_component_resource_type_delete(type);
    }
    if (!error) error = wasmtime_component_linker_instance_add_func(native, "booking-span", 12, ow_native_import_0, host, NULL);
    if (!error) error = wasmtime_component_linker_instance_add_func(native, "claim-closure", 13, ow_native_import_1, host, NULL);
    if (!error) error = wasmtime_component_linker_instance_add_func(native, "claim-for", 9, ow_native_import_2, host, NULL);
    if (!error) error = wasmtime_component_linker_instance_add_func(native, "claim-quota", 11, ow_native_import_3, host, NULL);
    if (!error) error = wasmtime_component_linker_instance_add_func(native, "echo-booking", 12, ow_native_import_4, host, NULL);
    if (!error) error = wasmtime_component_linker_instance_add_func(native, "echo-claim", 10, ow_native_import_5, host, NULL);
    if (!error) error = wasmtime_component_linker_instance_add_func(native, "echo-claims", 11, ow_native_import_6, host, NULL);
    if (!error) error = wasmtime_component_linker_instance_add_func(native, "echo-grant", 10, ow_native_import_7, host, NULL);
    if (!error) error = wasmtime_component_linker_instance_add_func(native, "new-ticket", 10, ow_native_import_8, host, NULL);
    if (!error) error = wasmtime_component_linker_instance_add_func(native, "pair-claim", 10, ow_native_import_9, host, NULL);
    if (!error) error = wasmtime_component_linker_instance_add_func(native, "serial", 6, ow_native_import_10, host, NULL);
    if (!error) error = wasmtime_component_linker_instance_add_func(native, "transfer-claim", 14, ow_native_import_11, host, NULL);
    if (!error) error = wasmtime_component_linker_instance_add_func(native, "transfer-pair-claim", 19, ow_native_import_12, host, NULL);
    if (!error) error = wasmtime_component_linker_instance_add_func(native, "transfer-with-claim-callback", 28, ow_native_import_13, host, NULL);
    if (!error) error = wasmtime_component_linker_instance_add_func(native, "with-claim-callback", 19, ow_native_import_14, host, NULL);
    if (!error) error = wasmtime_component_linker_instance_add_func(native, "invoke-identity-callback26621c40b48fce52ca37", 44, ow_native_import_15, host, NULL);
    if (!error) error = wasmtime_component_linker_instance_add_func(native, "invoke-identity-callbackb2d3d6fd4e031785f278", 44, ow_native_import_16, host, NULL);
    wasmtime_component_linker_instance_delete(native);
  }
  wasmtime_component_linker_instance_delete(root); return error;
}

static const uint8_t ows_component_bytes[] = {0,97,115,109,13,0,1,0,7,249,20,1,66,149,1,4,0,37,105,100,101,110,116,105,116,121,45,99,97,108,108,98,97,99,107,50,54,54,50,49,99,52,48,98,52,56,102,99,101,53,50,99,97,51,55,3,1,1,104,0,1,105,0,4,0,37,105,100,101,110,116,105,116,121,45,99,97,108,108,98,97,99,107,98,50,100,51,100,54,102,100,52,101,48,51,49,55,56,53,102,50,55,56,3,1,1,104,3,1,105,3,4,0,15,105,100,101,110,116,105,116,121,45,116,105,99,107,101,116,3,1,1,104,6,1,105,6,1,114,1,5,105,110,100,101,120,121,4,0,12,98,114,105,100,103,101,45,114,101,102,45,48,3,0,9,1,114,1,5,105,110,100,101,120,121,4,0,12,98,114,105,100,103,101,45,114,101,102,45,49,3,0,11,1,114,1,5,105,110,100,101,120,121,4,0,12,98,114,105,100,103,101,45,114,101,102,45,52,3,0,13,1,114,1,5,105,110,100,101,120,121,4,0,12,98,114,105,100,103,101,45,114,101,102,45,53,3,0,15,1,114,1,5,105,110,100,101,120,121,4,0,12,98,114,105,100,103,101,45,114,101,102,45,54,3,0,17,1,114,1,5,105,110,100,101,120,121,4,0,12,98,114,105,100,103,101,45,114,101,102,45,56,3,0,19,1,112,121,4,0,10,98,114,105,100,103,101,45,110,97,116,3,0,21,1,114,2,6,104,111,108,100,101,114,7,6,119,105,110,100,111,119,20,4,0,18,98,114,105,100,103,101,45,114,111,119,45,52,45,105,110,112,117,116,3,0,23,1,114,2,2,108,111,22,2,104,105,22,4,0,18,98,114,105,100,103,101,45,114,111,119,45,56,45,105,110,112,117,116,3,0,25,1,112,24,4,0,22,98,114,105,100,103,101,45,116,97,98,108,101,45,52,45,52,45,105,110,112,117,116,3,0,27,1,112,26,4,0,22,98,114,105,100,103,101,45,116,97,98,108,101,45,52,45,56,45,105,110,112,117,116,3,0,29,1,114,2,6,110,111,100,101,115,52,28,6,110,111,100,101,115,56,30,4,0,20,98,114,105,100,103,101,45,97,114,101,110,97,45,52,45,105,110,112,117,116,3,0,31,1,114,2,4,114,111,111,116,14,5,110,111,100,101,115,32,4,0,20,98,114,105,100,103,101,45,118,97,108,117,101,45,52,45,105,110,112,117,116,3,0,33,4,0,13,98,111,111,107,105,110,103,45,105,110,112,117,116,3,0,34,1,107,16,4,0,19,98,114,105,100,103,101,45,114,111,119,45,49,45,111,117,116,112,117,116,3,0,36,1,114,2,6,104,111,108,100,101,114,8,5,113,117,111,116,97,22,4,0,19,98,114,105,100,103,101,45,114,111,119,45,53,45,111,117,116,112,117,116,3,0,38,1,112,37,4,0,23,98,114,105,100,103,101,45,116,97,98,108,101,45,49,45,49,45,111,117,116,112,117,116,3,0,40,1,112,39,4,0,23,98,114,105,100,103,101,45,116,97,98,108,101,45,49,45,53,45,111,117,116,112,117,116,3,0,42,1,114,2,6,110,111,100,101,115,49,41,6,110,111,100,101,115,53,43,4,0,21,98,114,105,100,103,101,45,97,114,101,110,97,45,49,45,111,117,116,112,117,116,3,0,44,1,114,2,4,114,111,111,116,12,5,110,111,100,101,115,45,4,0,21,98,114,105,100,103,101,45,118,97,108,117,101,45,49,45,111,117,116,112,117,116,3,0,46,1,114,2,6,104,111,108,100,101,114,7,5,113,117,111,116,97,22,4,0,18,98,114,105,100,103,101,45,114,111,119,45,53,45,105,110,112,117,116,3,0,48,1,112,49,4,0,22,98,114,105,100,103,101,45,116,97,98,108,101,45,53,45,53,45,105,110,112,117,116,3,0,50,1,114,1,6,110,111,100,101,115,53,51,4,0,20,98,114,105,100,103,101,45,97,114,101,110,97,45,53,45,105,110,112,117,116,3,0,52,1,114,2,4,114,111,111,116,16,5,110,111,100,101,115,53,4,0,20,98,114,105,100,103,101,45,118,97,108,117,101,45,53,45,105,110,112,117,116,3,0,54,4,0,11,99,108,97,105,109,45,105,110,112,117,116,3,0,55,1,114,2,6,104,111,108,100,101,114,8,6,119,105,110,100,111,119,20,4,0,19,98,114,105,100,103,101,45,114,111,119,45,52,45,111,117,116,112,117,116,3,0,57,1,114,2,2,108,111,22,2,104,105,22,4,0,19,98,114,105,100,103,101,45,114,111,119,45,56,45,111,117,116,112,117,116,3,0,59,1,112,58,4,0,23,98,114,105,100,103,101,45,116,97,98,108,101,45,52,45,52,45,111,117,116,112,117,116,3,0,61,1,112,60,4,0,23,98,114,105,100,103,101,45,116,97,98,108,101,45,52,45,56,45,111,117,116,112,117,116,3,0,63,1,114,2,6,110,111,100,101,115,52,62,6,110,111,100,101,115,56,192,0,4,0,21,98,114,105,100,103,101,45,97,114,101,110,97,45,52,45,111,117,116,112,117,116,3,0,65,1,114,2,4,114,111,111,116,14,5,110,111,100,101,115,194,0,4,0,21,98,114,105,100,103,101,45,118,97,108,117,101,45,52,45,111,117,116,112,117,116,3,0,67,4,0,14,98,111,111,107,105,110,103,45,111,117,116,112,117,116,3,0,68,1,112,39,4,0,23,98,114,105,100,103,101,45,116,97,98,108,101,45,53,45,53,45,111,117,116,112,117,116,3,0,70,1,114,1,6,110,111,100,101,115,53,199,0,4,0,21,98,114,105,100,103,101,45,97,114,101,110,97,45,53,45,111,117,116,112,117,116,3,0,72,1,114,2,4,114,111,111,116,16,5,110,111,100,101,115,201,0,4,0,21,98,114,105,100,103,101,45,118,97,108,117,101,45,53,45,111,117,116,112,117,116,3,0,74,4,0,12,99,108,97,105,109,45,111,117,116,112,117,116,3,0,75,1,112,16,4,0,18,98,114,105,100,103,101,45,114,111,119,45,48,45,105,110,112,117,116,3,0,77,1,112,206,0,4,0,22,98,114,105,100,103,101,45,116,97,98,108,101,45,48,45,48,45,105,110,112,117,116,3,0,79,1,112,49,4,0,22,98,114,105,100,103,101,45,116,97,98,108,101,45,48,45,53,45,105,110,112,117,116,3,0,81,1,114,2,6,110,111,100,101,115,48,208,0,6,110,111,100,101,115,53,210,0,4,0,20,98,114,105,100,103,101,45,97,114,101,110,97,45,48,45,105,110,112,117,116,3,0,83,1,114,2,4,114,111,111,116,10,5,110,111,100,101,115,212,0,4,0,20,98,114,105,100,103,101,45,118,97,108,117,101,45,48,45,105,110,112,117,116,3,0,85,1,112,16,4,0,19,98,114,105,100,103,101,45,114,111,119,45,48,45,111,117,116,112,117,116,3,0,87,1,112,216,0,4,0,23,98,114,105,100,103,101,45,116,97,98,108,101,45,48,45,48,45,111,117,116,112,117,116,3,0,89,1,112,39,4,0,23,98,114,105,100,103,101,45,116,97,98,108,101,45,48,45,53,45,111,117,116,112,117,116,3,0,91,1,114,2,6,110,111,100,101,115,48,218,0,6,110,111,100,101,115,53,220,0,4,0,21,98,114,105,100,103,101,45,97,114,101,110,97,45,48,45,111,117,116,112,117,116,3,0,93,1,114,2,4,114,111,111,116,10,5,110,111,100,101,115,222,0,4,0,21,98,114,105,100,103,101,45,118,97,108,117,101,45,48,45,111,117,116,112,117,116,3,0,95,1,114,3,6,104,111,108,100,101,114,7,6,119,101,105,103,104,116,22,5,108,105,109,105,116,22,4,0,18,98,114,105,100,103,101,45,114,111,119,45,54,45,105,110,112,117,116,3,0,97,1,112,226,0,4,0,22,98,114,105,100,103,101,45,116,97,98,108,101,45,54,45,54,45,105,110,112,117,116,3,0,99,1,114,1,6,110,111,100,101,115,54,228,0,4,0,20,98,114,105,100,103,101,45,97,114,101,110,97,45,54,45,105,110,112,117,116,3,0,101,1,114,2,4,114,111,111,116,18,5,110,111,100,101,115,230,0,4,0,20,98,114,105,100,103,101,45,118,97,108,117,101,45,54,45,105,110,112,117,116,3,0,103,4,0,11,103,114,97,110,116,45,105,110,112,117,116,3,0,104,1,114,3,6,104,111,108,100,101,114,8,6,119,101,105,103,104,116,22,5,108,105,109,105,116,22,4,0,19,98,114,105,100,103,101,45,114,111,119,45,54,45,111,117,116,112,117,116,3,0,106,1,112,235,0,4,0,23,98,114,105,100,103,101,45,116,97,98,108,101,45,54,45,54,45,111,117,116,112,117,116,3,0,108,1,114,1,6,110,111,100,101,115,54,237,0,4,0,21,98,114,105,100,103,101,45,97,114,101,110,97,45,54,45,111,117,116,112,117,116,3,0,110,1,114,2,4,114,111,111,116,18,5,110,111,100,101,115,239,0,4,0,21,98,114,105,100,103,101,45,118,97,108,117,101,45,54,45,111,117,116,112,117,116,3,0,112,4,0,12,103,114,97,110,116,45,111,117,116,112,117,116,3,0,113,1,64,1,4,97,114,103,48,35,0,22,4,0,12,98,111,111,107,105,110,103,45,115,112,97,110,1,115,1,64,0,0,2,4,0,13,99,108,97,105,109,45,99,108,111,115,117,114,101,1,116,1,64,1,4,97,114,103,48,7,0,47,4,0,9,99,108,97,105,109,45,102,111,114,1,117,1,64,1,4,97,114,103,48,56,0,22,4,0,11,99,108,97,105,109,45,113,117,111,116,97,1,118,1,64,1,4,97,114,103,48,35,0,197,0,4,0,12,101,99,104,111,45,98,111,111,107,105,110,103,1,119,1,64,1,4,97,114,103,48,56,0,204,0,4,0,10,101,99,104,111,45,99,108,97,105,109,1,120,1,64,1,4,97,114,103,48,214,0,0,224,0,4,0,11,101,99,104,111,45,99,108,97,105,109,115,1,121,1,64,1,4,97,114,103,48,233,0,0,242,0,4,0,10,101,99,104,111,45,103,114,97,110,116,1,122,1,64,2,4,97,114,103,48,22,4,97,114,103,49,115,0,8,4,0,10,110,101,119,45,116,105,99,107,101,116,1,123,1,64,2,4,97,114,103,48,35,4,97,114,103,49,56,0,204,0,4,0,10,112,97,105,114,45,99,108,97,105,109,1,124,1,64,1,4,97,114,103,48,7,0,22,4,0,6,115,101,114,105,97,108,1,125,1,64,1,4,97,114,103,48,204,0,0,204,0,4,0,14,116,114,97,110,115,102,101,114,45,99,108,97,105,109,1,126,1,64,2,4,97,114,103,48,197,0,4,97,114,103,49,204,0,0,204,0,4,0,19,116,114,97,110,115,102,101,114,45,112,97,105,114,45,99,108,97,105,109,1,127,1,64,2,4,97,114,103,48,204,0,4,97,114,103,49,4,0,204,0,4,0,28,116,114,97,110,115,102,101,114,45,119,105,116,104,45,99,108,97,105,109,45,99,97,108,108,98,97,99,107,1,128,1,1,64,2,4,97,114,103,48,56,4,97,114,103,49,4,0,204,0,4,0,19,119,105,116,104,45,99,108,97,105,109,45,99,97,108,108,98,97,99,107,1,129,1,1,64,2,4,115,101,108,102,1,4,97,114,103,48,56,0,204,0,4,0,44,105,110,118,111,107,101,45,105,100,101,110,116,105,116,121,45,99,97,108,108,98,97,99,107,50,54,54,50,49,99,52,48,98,52,56,102,99,101,53,50,99,97,51,55,1,130,1,1,64,2,4,115,101,108,102,4,4,97,114,103,48,56,0,204,0,4,0,44,105,110,118,111,107,101,45,105,100,101,110,116,105,116,121,45,99,97,108,108,98,97,99,107,98,50,100,51,100,54,102,100,52,101,48,51,49,55,56,53,102,50,55,56,1,131,1,10,51,1,0,46,108,101,97,110,45,98,114,105,100,103,101,58,111,119,110,101,100,45,99,104,101,99,107,101,100,45,114,101,99,111,114,100,115,47,110,97,116,105,118,101,64,49,46,48,46,48,5,0,6,159,10,57,3,0,0,12,98,114,105,100,103,101,45,114,101,102,45,48,3,0,0,12,98,114,105,100,103,101,45,114,101,102,45,49,3,0,0,12,98,114,105,100,103,101,45,114,101,102,45,52,3,0,0,12,98,114,105,100,103,101,45,114,101,102,45,53,3,0,0,12,98,114,105,100,103,101,45,114,101,102,45,54,3,0,0,12,98,114,105,100,103,101,45,114,101,102,45,56,3,0,0,10,98,114,105,100,103,101,45,110,97,116,3,0,0,18,98,114,105,100,103,101,45,114,111,119,45,52,45,105,110,112,117,116,3,0,0,18,98,114,105,100,103,101,45,114,111,119,45,56,45,105,110,112,117,116,3,0,0,22,98,114,105,100,103,101,45,116,97,98,108,101,45,52,45,52,45,105,110,112,117,116,3,0,0,22,98,114,105,100,103,101,45,116,97,98,108,101,45,52,45,56,45,105,110,112,117,116,3,0,0,20,98,114,105,100,103,101,45,97,114,101,110,97,45,52,45,105,110,112,117,116,3,0,0,20,98,114,105,100,103,101,45,118,97,108,117,101,45,52,45,105,110,112,117,116,3,0,0,13,98,111,111,107,105,110,103,45,105,110,112,117,116,3,0,0,19,98,114,105,100,103,101,45,114,111,119,45,49,45,111,117,116,112,117,116,3,0,0,19,98,114,105,100,103,101,45,114,111,119,45,53,45,111,117,116,112,117,116,3,0,0,23,98,114,105,100,103,101,45,116,97,98,108,101,45,49,45,49,45,111,117,116,112,117,116,3,0,0,23,98,114,105,100,103,101,45,116,97,98,108,101,45,49,45,53,45,111,117,116,112,117,116,3,0,0,21,98,114,105,100,103,101,45,97,114,101,110,97,45,49,45,111,117,116,112,117,116,3,0,0,21,98,114,105,100,103,101,45,118,97,108,117,101,45,49,45,111,117,116,112,117,116,3,0,0,18,98,114,105,100,103,101,45,114,111,119,45,53,45,105,110,112,117,116,3,0,0,22,98,114,105,100,103,101,45,116,97,98,108,101,45,53,45,53,45,105,110,112,117,116,3,0,0,20,98,114,105,100,103,101,45,97,114,101,110,97,45,53,45,105,110,112,117,116,3,0,0,20,98,114,105,100,103,101,45,118,97,108,117,101,45,53,45,105,110,112,117,116,3,0,0,11,99,108,97,105,109,45,105,110,112,117,116,3,0,0,19,98,114,105,100,103,101,45,114,111,119,45,52,45,111,117,116,112,117,116,3,0,0,19,98,114,105,100,103,101,45,114,111,119,45,56,45,111,117,116,112,117,116,3,0,0,23,98,114,105,100,103,101,45,116,97,98,108,101,45,52,45,52,45,111,117,116,112,117,116,3,0,0,23,98,114,105,100,103,101,45,116,97,98,108,101,45,52,45,56,45,111,117,116,112,117,116,3,0,0,21,98,114,105,100,103,101,45,97,114,101,110,97,45,52,45,111,117,116,112,117,116,3,0,0,21,98,114,105,100,103,101,45,118,97,108,117,101,45,52,45,111,117,116,112,117,116,3,0,0,14,98,111,111,107,105,110,103,45,111,117,116,112,117,116,3,0,0,23,98,114,105,100,103,101,45,116,97,98,108,101,45,53,45,53,45,111,117,116,112,117,116,3,0,0,21,98,114,105,100,103,101,45,97,114,101,110,97,45,53,45,111,117,116,112,117,116,3,0,0,21,98,114,105,100,103,101,45,118,97,108,117,101,45,53,45,111,117,116,112,117,116,3,0,0,12,99,108,97,105,109,45,111,117,116,112,117,116,3,0,0,18,98,114,105,100,103,101,45,114,111,119,45,48,45,105,110,112,117,116,3,0,0,22,98,114,105,100,103,101,45,116,97,98,108,101,45,48,45,48,45,105,110,112,117,116,3,0,0,22,98,114,105,100,103,101,45,116,97,98,108,101,45,48,45,53,45,105,110,112,117,116,3,0,0,20,98,114,105,100,103,101,45,97,114,101,110,97,45,48,45,105,110,112,117,116,3,0,0,20,98,114,105,100,103,101,45,118,97,108,117,101,45,48,45,105,110,112,117,116,3,0,0,19,98,114,105,100,103,101,45,114,111,119,45,48,45,111,117,116,112,117,116,3,0,0,23,98,114,105,100,103,101,45,116,97,98,108,101,45,48,45,48,45,111,117,116,112,117,116,3,0,0,23,98,114,105,100,103,101,45,116,97,98,108,101,45,48,45,53,45,111,117,116,112,117,116,3,0,0,21,98,114,105,100,103,101,45,97,114,101,110,97,45,48,45,111,117,116,112,117,116,3,0,0,21,98,114,105,100,103,101,45,118,97,108,117,101,45,48,45,111,117,116,112,117,116,3,0,0,18,98,114,105,100,103,101,45,114,111,119,45,54,45,105,110,112,117,116,3,0,0,22,98,114,105,100,103,101,45,116,97,98,108,101,45,54,45,54,45,105,110,112,117,116,3,0,0,20,98,114,105,100,103,101,45,97,114,101,110,97,45,54,45,105,110,112,117,116,3,0,0,20,98,114,105,100,103,101,45,118,97,108,117,101,45,54,45,105,110,112,117,116,3,0,0,11,103,114,97,110,116,45,105,110,112,117,116,3,0,0,19,98,114,105,100,103,101,45,114,111,119,45,54,45,111,117,116,112,117,116,3,0,0,23,98,114,105,100,103,101,45,116,97,98,108,101,45,54,45,54,45,111,117,116,112,117,116,3,0,0,21,98,114,105,100,103,101,45,97,114,101,110,97,45,54,45,111,117,116,112,117,116,3,0,0,21,98,114,105,100,103,101,45,118,97,108,117,101,45,54,45,111,117,116,112,117,116,3,0,0,12,103,114,97,110,116,45,111,117,116,112,117,116,3,0,0,37,105,100,101,110,116,105,116,121,45,99,97,108,108,98,97,99,107,50,54,54,50,49,99,52,48,98,52,56,102,99,101,53,50,99,97,51,55,7,5,2,104,57,105,57,6,42,1,3,0,0,37,105,100,101,110,116,105,116,121,45,99,97,108,108,98,97,99,107,98,50,100,51,100,54,102,100,52,101,48,51,49,55,56,53,102,50,55,56,7,5,2,104,60,105,60,6,20,1,3,0,0,15,105,100,101,110,116,105,116,121,45,116,105,99,107,101,116,7,5,2,104,63,105,63,6,223,2,17,1,0,0,12,98,111,111,107,105,110,103,45,115,112,97,110,1,0,0,13,99,108,97,105,109,45,99,108,111,115,117,114,101,1,0,0,9,99,108,97,105,109,45,102,111,114,1,0,0,11,99,108,97,105,109,45,113,117,111,116,97,1,0,0,12,101,99,104,111,45,98,111,111,107,105,110,103,1,0,0,10,101,99,104,111,45,99,108,97,105,109,1,0,0,11,101,99,104,111,45,99,108,97,105,109,115,1,0,0,10,101,99,104,111,45,103,114,97,110,116,1,0,0,10,110,101,119,45,116,105,99,107,101,116,1,0,0,10,112,97,105,114,45,99,108,97,105,109,1,0,0,6,115,101,114,105,97,108,1,0,0,14,116,114,97,110,115,102,101,114,45,99,108,97,105,109,1,0,0,19,116,114,97,110,115,102,101,114,45,112,97,105,114,45,99,108,97,105,109,1,0,0,28,116,114,97,110,115,102,101,114,45,119,105,116,104,45,99,108,97,105,109,45,99,97,108,108,98,97,99,107,1,0,0,19,119,105,116,104,45,99,108,97,105,109,45,99,97,108,108,98,97,99,107,1,0,0,44,105,110,118,111,107,101,45,105,100,101,110,116,105,116,121,45,99,97,108,108,98,97,99,107,50,54,54,50,49,99,52,48,98,52,56,102,99,101,53,50,99,97,51,55,1,0,0,44,105,110,118,111,107,101,45,105,100,101,110,116,105,116,121,45,99,97,108,108,98,97,99,107,98,50,100,51,100,54,102,100,52,101,48,51,49,55,56,53,102,50,55,56,1,197,3,0,97,115,109,1,0,0,0,1,28,6,96,0,0,96,4,127,127,127,127,1,127,96,1,127,0,96,1,126,0,96,1,125,0,96,1,124,0,3,8,7,0,0,1,2,3,4,5,5,5,1,1,1,128,8,6,12,2,127,1,65,144,2,11,127,1,65,0,11,7,72,7,6,109,101,109,111,114,121,2,0,5,101,110,116,101,114,0,0,7,114,101,97,108,108,111,99,0,2,8,112,111,115,116,45,105,51,50,0,3,8,112,111,115,116,45,105,54,52,0,4,8,112,111,115,116,45,102,51,50,0,5,8,112,111,115,116,45,102,54,52,0,6,10,206,1,7,29,0,35,1,65,192,0,79,4,64,0,11,35,1,65,2,116,35,0,54,2,16,35,1,65,1,106,36,1,11,36,0,35,1,69,4,64,0,11,35,1,65,1,107,36,1,35,1,69,4,127,65,144,2,5,35,1,65,2,116,40,2,16,11,36,0,11,117,1,3,127,32,3,69,4,64,65,0,15,11,35,0,32,2,65,1,107,106,65,0,32,2,107,113,33,4,32,4,32,3,106,33,5,32,5,32,4,73,32,5,65,128,128,128,32,75,114,4,64,0,11,32,5,65,255,255,3,106,65,16,118,33,6,32,6,63,0,75,4,64,32,6,63,0,107,64,0,65,127,70,4,64,0,11,11,32,0,4,64,32,4,32,0,32,1,32,3,32,1,32,3,73,27,252,10,0,0,11,32,5,36,0,32,4,11,4,0,16,1,11,4,0,16,1,11,4,0,16,1,11,4,0,16,1,11,0,99,4,110,97,109,101,0,10,9,97,108,108,111,99,97,116,111,114,1,8,1,1,5,108,101,97,118,101,2,54,1,2,7,0,3,111,108,100,1,8,111,108,100,45,115,105,122,101,2,9,97,108,105,103,110,109,101,110,116,3,4,115,105,122,101,4,5,115,116,97,114,116,5,3,101,110,100,6,5,112,97,103,101,115,7,14,2,0,4,104,101,97,112,1,5,100,101,112,116,104,2,4,1,0,0,0,6,76,6,0,2,1,0,6,109,101,109,111,114,121,0,0,1,0,7,114,101,97,108,108,111,99,0,0,1,0,8,112,111,115,116,45,105,51,50,0,0,1,0,8,112,111,115,116,45,105,54,52,0,0,1,0,8,112,111,115,116,45,102,51,50,0,0,1,0,8,112,111,115,116,45,102,54,52,8,143,1,20,1,0,0,2,3,0,4,0,1,0,1,2,3,0,4,0,1,0,2,2,3,0,4,0,1,0,3,2,3,0,4,0,1,0,4,2,3,0,4,0,1,0,5,2,3,0,4,0,1,0,6,2,3,0,4,0,1,0,7,2,3,0,4,0,1,0,8,2,3,0,4,0,1,0,9,2,3,0,4,0,1,0,10,2,3,0,4,0,1,0,11,2,3,0,4,0,1,0,12,2,3,0,4,0,1,0,13,2,3,0,4,0,1,0,14,2,3,0,4,0,1,0,15,2,3,0,4,0,1,0,16,2,3,0,4,0,3,57,3,60,3,63,1,217,14,0,97,115,109,1,0,0,0,1,94,13,96,4,127,127,127,127,1,127,96,0,0,96,1,127,0,96,6,127,127,127,127,127,127,0,96,0,1,127,96,2,127,127,0,96,4,127,127,127,127,0,96,9,127,127,127,127,127,127,127,127,127,0,96,5,127,127,127,127,127,0,96,5,127,127,127,127,127,1,127,96,1,127,1,127,96,3,127,127,127,1,127,96,8,127,127,127,127,127,127,127,127,1,127,2,168,2,23,10,97,108,108,111,99,97,116,105,111,110,7,114,101,97,108,108,111,99,0,0,10,97,108,108,111,99,97,116,105,111,110,6,109,101,109,111,114,121,2,0,1,10,97,108,108,111,99,97,116,105,111,110,5,101,110,116,101,114,0,1,9,114,101,115,111,117,114,99,101,115,6,100,114,111,112,53,54,0,2,9,114,101,115,111,117,114,99,101,115,6,100,114,111,112,53,55,0,2,9,114,101,115,111,117,114,99,101,115,6,100,114,111,112,53,56,0,2,4,104,111,115,116,2,102,48,0,3,4,104,111,115,116,2,102,49,0,4,4,104,111,115,116,2,102,50,0,5,4,104,111,115,116,2,102,51,0,6,4,104,111,115,116,2,102,52,0,3,4,104,111,115,116,2,102,53,0,6,4,104,111,115,116,2,102,54,0,3,4,104,111,115,116,2,102,55,0,6,4,104,111,115,116,2,102,56,0,0,4,104,111,115,116,2,102,57,0,7,4,104,111,115,116,3,102,49,48,0,5,4,104,111,115,116,3,102,49,49,0,6,4,104,111,115,116,3,102,49,50,0,7,4,104,111,115,116,3,102,49,51,0,8,4,104,111,115,116,3,102,49,52,0,8,4,104,111,115,116,3,102,49,53,0,8,4,104,111,115,116,3,102,49,54,0,8,3,26,25,2,2,5,2,5,5,2,5,9,4,10,11,9,11,9,11,0,12,10,11,12,0,0,0,0,7,93,17,2,102,48,0,30,2,102,49,0,31,2,102,50,0,32,2,102,51,0,33,2,102,52,0,34,2,102,53,0,35,2,102,54,0,36,2,102,55,0,37,2,102,56,0,38,2,102,57,0,39,3,102,49,48,0,40,3,102,49,49,0,41,3,102,49,50,0,42,3,102,49,51,0,43,3,102,49,52,0,44,3,102,49,53,0,45,3,102,49,54,0,46,10,149,6,25,9,0,32,0,40,2,0,16,4,11,6,0,32,0,16,22,11,36,1,1,127,2,64,3,64,32,2,32,1,70,13,1,32,0,32,2,65,8,108,106,16,23,32,2,65,1,106,33,2,12,0,11,11,11,6,0,32,0,16,22,11,36,1,1,127,2,64,3,64,32,2,32,1,70,13,1,32,0,32,2,65,12,108,106,16,25,32,2,65,1,106,33,2,12,0,11,11,11,36,1,1,127,2,64,3,64,32,2,32,1,70,13,1,32,0,32,2,65,12,108,106,16,25,32,2,65,1,106,33,2,12,0,11,11,11,6,0,32,0,16,22,11,36,1,1,127,2,64,3,64,32,2,32,1,70,13,1,32,0,32,2,65,20,108,106,16,28,32,2,65,1,106,33,2,12,0,11,11,11,40,1,1,127,16,1,65,0,65,0,65,4,65,8,16,0,33,5,32,0,32,1,32,2,32,3,32,4,32,5,16,5,32,1,32,2,16,24,32,5,11,6,0,16,1,16,6,11,30,1,1,127,16,1,65,0,65,0,65,4,65,20,16,0,33,1,32,0,32,1,16,7,32,0,16,4,32,1,11,36,1,1,127,16,1,65,0,65,0,65,4,65,8,16,0,33,3,32,0,32,1,32,2,32,3,16,8,32,1,32,2,16,26,32,3,11,40,1,1,127,16,1,65,0,65,0,65,4,65,20,16,0,33,5,32,0,32,1,32,2,32,3,32,4,32,5,16,9,32,1,32,2,16,24,32,5,11,36,1,1,127,16,1,65,0,65,0,65,4,65,12,16,0,33,3,32,0,32,1,32,2,32,3,16,10,32,1,32,2,16,26,32,3,11,40,1,1,127,16,1,65,0,65,0,65,4,65,20,16,0,33,5,32,0,32,1,32,2,32,3,32,4,32,5,16,11,32,3,32,4,16,27,32,5,11,36,1,1,127,16,1,65,0,65,0,65,4,65,12,16,0,33,3,32,0,32,1,32,2,32,3,16,12,32,1,32,2,16,29,32,3,11,14,0,16,1,32,0,32,1,32,2,32,3,16,13,11,52,1,1,127,16,1,65,0,65,0,65,4,65,12,16,0,33,8,32,0,32,1,32,2,32,3,32,4,32,5,32,6,32,7,32,8,16,14,32,1,32,2,16,24,32,6,32,7,16,26,32,8,11,30,1,1,127,16,1,65,0,65,0,65,4,65,8,16,0,33,1,32,0,32,1,16,15,32,0,16,4,32,1,11,30,1,1,127,16,1,65,0,65,0,65,4,65,12,16,0,33,3,32,0,32,1,32,2,32,3,16,16,32,3,11,40,1,1,127,16,1,65,0,65,0,65,4,65,12,16,0,33,8,32,0,32,1,32,2,32,3,32,4,32,5,32,6,32,7,32,8,16,17,32,8,11,36,1,1,127,16,1,65,0,65,0,65,4,65,12,16,0,33,4,32,0,32,1,32,2,32,3,32,4,16,18,32,3,16,3,32,4,11,42,1,1,127,16,1,65,0,65,0,65,4,65,12,16,0,33,4,32,0,32,1,32,2,32,3,32,4,16,19,32,1,32,2,16,26,32,3,16,3,32,4,11,42,1,1,127,16,1,65,0,65,0,65,4,65,12,16,0,33,4,32,0,32,1,32,2,32,3,32,4,16,20,32,0,16,2,32,2,32,3,16,26,32,4,11,42,1,1,127,16,1,65,0,65,0,65,4,65,12,16,0,33,4,32,0,32,1,32,2,32,3,32,4,16,21,32,0,16,3,32,2,32,3,16,26,32,4,11,0,176,4,4,110,97,109,101,0,8,7,102,111,114,119,97,114,100,1,233,1,30,0,8,97,108,108,111,99,97,116,101,1,5,101,110,116,101,114,2,6,100,114,111,112,53,54,3,6,100,114,111,112,53,55,4,6,100,114,111,112,53,56,5,2,102,48,6,2,102,49,7,2,102,50,8,2,102,51,9,2,102,52,10,2,102,53,11,2,102,54,12,2,102,55,13,2,102,56,14,2,102,57,15,3,102,49,48,16,3,102,49,49,17,3,102,49,50,18,3,102,49,51,19,3,102,49,52,20,3,102,49,53,21,3,102,49,54,22,13,98,111,114,114,111,119,45,118,97,108,117,101,49,23,13,98,111,114,114,111,119,45,118,97,108,117,101,48,24,12,98,111,114,114,111,119,45,108,105,115,116,48,25,13,98,111,114,114,111,119,45,118,97,108,117,101,50,26,12,98,111,114,114,111,119,45,108,105,115,116,49,27,12,98,111,114,114,111,119,45,108,105,115,116,50,28,13,98,111,114,114,111,119,45,118,97,108,117,101,51,29,12,98,111,114,114,111,119,45,108,105,115,116,51,2,247,1,23,22,1,0,1,112,23,1,0,1,112,24,3,0,1,112,1,5,99,111,117,110,116,2,5,105,110,100,101,120,25,1,0,1,112,26,3,0,1,112,1,5,99,111,117,110,116,2,5,105,110,100,101,120,27,3,0,1,112,1,5,99,111,117,110,116,2,5,105,110,100,101,120,28,1,0,1,112,29,3,0,1,112,1,5,99,111,117,110,116,2,5,105,110,100,101,120,30,1,5,6,114,101,115,117,108,116,32,1,1,6,114,101,115,117,108,116,33,1,3,6,114,101,115,117,108,116,34,1,5,6,114,101,115,117,108,116,35,1,3,6,114,101,115,117,108,116,36,1,5,6,114,101,115,117,108,116,37,1,3,6,114,101,115,117,108,116,39,1,8,6,114,101,115,117,108,116,40,1,1,6,114,101,115,117,108,116,41,1,3,6,114,101,115,117,108,116,42,1,8,6,114,101,115,117,108,116,43,1,4,6,114,101,115,117,108,116,44,1,4,6,114,101,115,117,108,116,45,1,4,6,114,101,115,117,108,116,46,1,4,6,114,101,115,117,108,116,3,57,4,24,2,0,4,100,111,110,101,1,4,110,101,120,116,26,2,0,4,100,111,110,101,1,4,110,101,120,116,27,2,0,4,100,111,110,101,1,4,110,101,120,116,29,2,0,4,100,111,110,101,1,4,110,101,120,116,2,159,1,3,1,17,2,102,48,0,5,2,102,49,0,6,2,102,50,0,7,2,102,51,0,8,2,102,52,0,9,2,102,53,0,10,2,102,54,0,11,2,102,55,0,12,2,102,56,0,13,2,102,57,0,14,3,102,49,48,0,15,3,102,49,49,0,16,3,102,49,50,0,17,3,102,49,51,0,18,3,102,49,52,0,19,3,102,49,53,0,20,3,102,49,54,0,21,1,3,6,100,114,111,112,53,54,0,22,6,100,114,111,112,53,55,0,23,6,100,114,111,112,53,56,0,24,0,1,3,10,97,108,108,111,99,97,116,105,111,110,18,0,4,104,111,115,116,18,1,9,114,101,115,111,117,114,99,101,115,18,2,6,127,17,0,0,1,3,2,102,48,0,0,1,3,2,102,49,0,0,1,3,2,102,50,0,0,1,3,2,102,51,0,0,1,3,2,102,52,0,0,1,3,2,102,53,0,0,1,3,2,102,54,0,0,1,3,2,102,55,0,0,1,3,2,102,56,0,0,1,3,2,102,57,0,0,1,3,3,102,49,48,0,0,1,3,3,102,49,49,0,0,1,3,3,102,49,50,0,0,1,3,3,102,49,51,0,0,1,3,3,102,49,52,0,0,1,3,3,102,49,53,0,0,1,3,3,102,49,54,7,11,1,64,1,4,97,114,103,48,14,0,7,8,12,1,0,0,25,3,3,0,4,0,5,1,66,7,5,1,64,0,0,59,8,12,1,0,0,26,3,3,0,4,0,5,1,67,7,12,1,64,1,4,97,114,103,48,192,0,0,20,8,12,1,0,0,27,3,3,0,4,0,5,1,68,7,11,1,64,1,4,97,114,103,48,25,0,7,8,12,1,0,0,28,3,3,0,4,0,5,1,69,7,11,1,64,1,4,97,114,103,48,14,0,32,8,12,1,0,0,29,3,3,0,4,0,5,1,70,7,11,1,64,1,4,97,114,103,48,25,0,36,8,12,1,0,0,30,3,3,0,4,0,5,1,71,7,11,1,64,1,4,97,114,103,48,41,0,46,8,12,1,0,0,31,3,3,0,4,0,5,1,72,7,11,1,64,1,4,97,114,103,48,51,0,56,8,12,1,0,0,32,3,3,0,4,0,5,1,73,7,18,1,64,2,4,97,114,103,48,7,4,97,114,103,49,115,0,193,0,8,12,1,0,0,33,3,3,0,4,0,5,1,74,7,17,1,64,2,4,97,114,103,48,14,4,97,114,103,49,25,0,36,8,12,1,0,0,34,3,3,0,4,0,5,1,75,7,12,1,64,1,4,97,114,103,48,192,0,0,7,8,12,1,0,0,35,3,3,0,4,0,5,1,76,7,11,1,64,1,4,97,114,103,48,36,0,36,8,12,1,0,0,36,3,3,0,4,0,5,1,77,7,17,1,64,2,4,97,114,103,48,32,4,97,114,103,49,36,0,36,8,12,1,0,0,37,3,3,0,4,0,5,1,78,7,17,1,64,2,4,97,114,103,48,36,4,97,114,103,49,61,0,36,8,12,1,0,0,38,3,3,0,4,0,5,1,79,7,17,1,64,2,4,97,114,103,48,25,4,97,114,103,49,61,0,36,8,12,1,0,0,39,3,3,0,4,0,5,1,80,7,17,1,64,2,4,115,101,108,102,58,4,97,114,103,48,25,0,36,8,12,1,0,0,40,3,3,0,4,0,5,1,81,7,17,1,64,2,4,115,101,108,102,61,4,97,114,103,48,25,0,36,8,12,1,0,0,41,3,3,0,4,0,5,1,82,7,255,18,1,66,158,1,2,3,2,1,1,4,0,12,98,114,105,100,103,101,45,114,101,102,45,48,3,0,0,2,3,2,1,2,4,0,12,98,114,105,100,103,101,45,114,101,102,45,49,3,0,2,2,3,2,1,3,4,0,12,98,114,105,100,103,101,45,114,101,102,45,52,3,0,4,2,3,2,1,4,4,0,12,98,114,105,100,103,101,45,114,101,102,45,53,3,0,6,2,3,2,1,5,4,0,12,98,114,105,100,103,101,45,114,101,102,45,54,3,0,8,2,3,2,1,6,4,0,12,98,114,105,100,103,101,45,114,101,102,45,56,3,0,10,2,3,2,1,7,4,0,10,98,114,105,100,103,101,45,110,97,116,3,0,12,2,3,2,1,8,4,0,18,98,114,105,100,103,101,45,114,111,119,45,52,45,105,110,112,117,116,3,0,14,2,3,2,1,9,4,0,18,98,114,105,100,103,101,45,114,111,119,45,56,45,105,110,112,117,116,3,0,16,2,3,2,1,10,4,0,22,98,114,105,100,103,101,45,116,97,98,108,101,45,52,45,52,45,105,110,112,117,116,3,0,18,2,3,2,1,11,4,0,22,98,114,105,100,103,101,45,116,97,98,108,101,45,52,45,56,45,105,110,112,117,116,3,0,20,2,3,2,1,12,4,0,20,98,114,105,100,103,101,45,97,114,101,110,97,45,52,45,105,110,112,117,116,3,0,22,2,3,2,1,13,4,0,20,98,114,105,100,103,101,45,118,97,108,117,101,45,52,45,105,110,112,117,116,3,0,24,2,3,2,1,14,4,0,13,98,111,111,107,105,110,103,45,105,110,112,117,116,3,0,26,2,3,2,1,15,4,0,19,98,114,105,100,103,101,45,114,111,119,45,49,45,111,117,116,112,117,116,3,0,28,2,3,2,1,16,4,0,19,98,114,105,100,103,101,45,114,111,119,45,53,45,111,117,116,112,117,116,3,0,30,2,3,2,1,17,4,0,23,98,114,105,100,103,101,45,116,97,98,108,101,45,49,45,49,45,111,117,116,112,117,116,3,0,32,2,3,2,1,18,4,0,23,98,114,105,100,103,101,45,116,97,98,108,101,45,49,45,53,45,111,117,116,112,117,116,3,0,34,2,3,2,1,19,4,0,21,98,114,105,100,103,101,45,97,114,101,110,97,45,49,45,111,117,116,112,117,116,3,0,36,2,3,2,1,20,4,0,21,98,114,105,100,103,101,45,118,97,108,117,101,45,49,45,111,117,116,112,117,116,3,0,38,2,3,2,1,21,4,0,18,98,114,105,100,103,101,45,114,111,119,45,53,45,105,110,112,117,116,3,0,40,2,3,2,1,22,4,0,22,98,114,105,100,103,101,45,116,97,98,108,101,45,53,45,53,45,105,110,112,117,116,3,0,42,2,3,2,1,23,4,0,20,98,114,105,100,103,101,45,97,114,101,110,97,45,53,45,105,110,112,117,116,3,0,44,2,3,2,1,24,4,0,20,98,114,105,100,103,101,45,118,97,108,117,101,45,53,45,105,110,112,117,116,3,0,46,2,3,2,1,25,4,0,11,99,108,97,105,109,45,105,110,112,117,116,3,0,48,2,3,2,1,26,4,0,19,98,114,105,100,103,101,45,114,111,119,45,52,45,111,117,116,112,117,116,3,0,50,2,3,2,1,27,4,0,19,98,114,105,100,103,101,45,114,111,119,45,56,45,111,117,116,112,117,116,3,0,52,2,3,2,1,28,4,0,23,98,114,105,100,103,101,45,116,97,98,108,101,45,52,45,52,45,111,117,116,112,117,116,3,0,54,2,3,2,1,29,4,0,23,98,114,105,100,103,101,45,116,97,98,108,101,45,52,45,56,45,111,117,116,112,117,116,3,0,56,2,3,2,1,30,4,0,21,98,114,105,100,103,101,45,97,114,101,110,97,45,52,45,111,117,116,112,117,116,3,0,58,2,3,2,1,31,4,0,21,98,114,105,100,103,101,45,118,97,108,117,101,45,52,45,111,117,116,112,117,116,3,0,60,2,3,2,1,32,4,0,14,98,111,111,107,105,110,103,45,111,117,116,112,117,116,3,0,62,2,3,2,1,33,4,0,23,98,114,105,100,103,101,45,116,97,98,108,101,45,53,45,53,45,111,117,116,112,117,116,3,0,64,2,3,2,1,34,4,0,21,98,114,105,100,103,101,45,97,114,101,110,97,45,53,45,111,117,116,112,117,116,3,0,66,2,3,2,1,35,4,0,21,98,114,105,100,103,101,45,118,97,108,117,101,45,53,45,111,117,116,112,117,116,3,0,68,2,3,2,1,36,4,0,12,99,108,97,105,109,45,111,117,116,112,117,116,3,0,70,2,3,2,1,37,4,0,18,98,114,105,100,103,101,45,114,111,119,45,48,45,105,110,112,117,116,3,0,72,2,3,2,1,38,4,0,22,98,114,105,100,103,101,45,116,97,98,108,101,45,48,45,48,45,105,110,112,117,116,3,0,74,2,3,2,1,39,4,0,22,98,114,105,100,103,101,45,116,97,98,108,101,45,48,45,53,45,105,110,112,117,116,3,0,76,2,3,2,1,40,4,0,20,98,114,105,100,103,101,45,97,114,101,110,97,45,48,45,105,110,112,117,116,3,0,78,2,3,2,1,41,4,0,20,98,114,105,100,103,101,45,118,97,108,117,101,45,48,45,105,110,112,117,116,3,0,80,2,3,2,1,42,4,0,19,98,114,105,100,103,101,45,114,111,119,45,48,45,111,117,116,112,117,116,3,0,82,2,3,2,1,43,4,0,23,98,114,105,100,103,101,45,116,97,98,108,101,45,48,45,48,45,111,117,116,112,117,116,3,0,84,2,3,2,1,44,4,0,23,98,114,105,100,103,101,45,116,97,98,108,101,45,48,45,53,45,111,117,116,112,117,116,3,0,86,2,3,2,1,45,4,0,21,98,114,105,100,103,101,45,97,114,101,110,97,45,48,45,111,117,116,112,117,116,3,0,88,2,3,2,1,46,4,0,21,98,114,105,100,103,101,45,118,97,108,117,101,45,48,45,111,117,116,112,117,116,3,0,90,2,3,2,1,47,4,0,18,98,114,105,100,103,101,45,114,111,119,45,54,45,105,110,112,117,116,3,0,92,2,3,2,1,48,4,0,22,98,114,105,100,103,101,45,116,97,98,108,101,45,54,45,54,45,105,110,112,117,116,3,0,94,2,3,2,1,49,4,0,20,98,114,105,100,103,101,45,97,114,101,110,97,45,54,45,105,110,112,117,116,3,0,96,2,3,2,1,50,4,0,20,98,114,105,100,103,101,45,118,97,108,117,101,45,54,45,105,110,112,117,116,3,0,98,2,3,2,1,51,4,0,11,103,114,97,110,116,45,105,110,112,117,116,3,0,100,2,3,2,1,52,4,0,19,98,114,105,100,103,101,45,114,111,119,45,54,45,111,117,116,112,117,116,3,0,102,2,3,2,1,53,4,0,23,98,114,105,100,103,101,45,116,97,98,108,101,45,54,45,54,45,111,117,116,112,117,116,3,0,104,2,3,2,1,54,4,0,21,98,114,105,100,103,101,45,97,114,101,110,97,45,54,45,111,117,116,112,117,116,3,0,106,2,3,2,1,55,4,0,21,98,114,105,100,103,101,45,118,97,108,117,101,45,54,45,111,117,116,112,117,116,3,0,108,2,3,2,1,56,4,0,12,103,114,97,110,116,45,111,117,116,112,117,116,3,0,110,2,3,2,1,57,4,0,37,105,100,101,110,116,105,116,121,45,99,97,108,108,98,97,99,107,50,54,54,50,49,99,52,48,98,52,56,102,99,101,53,50,99,97,51,55,3,0,112,1,104,113,1,105,113,2,3,2,1,60,4,0,37,105,100,101,110,116,105,116,121,45,99,97,108,108,98,97,99,107,98,50,100,51,100,54,102,100,52,101,48,51,49,55,56,53,102,50,55,56,3,0,116,1,104,117,1,105,117,2,3,2,1,63,4,0,15,105,100,101,110,116,105,116,121,45,116,105,99,107,101,116,3,0,120,1,104,121,1,105,121,1,64,1,4,97,114,103,48,27,0,13,4,0,12,98,111,111,107,105,110,103,45,115,112,97,110,1,124,1,64,0,0,243,0,4,0,13,99,108,97,105,109,45,99,108,111,115,117,114,101,1,125,1,64,1,4,97,114,103,48,250,0,0,39,4,0,9,99,108,97,105,109,45,102,111,114,1,126,1,64,1,4,97,114,103,48,49,0,13,4,0,11,99,108,97,105,109,45,113,117,111,116,97,1,127,1,64,1,4,97,114,103,48,27,0,63,4,0,12,101,99,104,111,45,98,111,111,107,105,110,103,1,128,1,1,64,1,4,97,114,103,48,49,0,199,0,4,0,10,101,99,104,111,45,99,108,97,105,109,1,129,1,1,64,1,4,97,114,103,48,209,0,0,219,0,4,0,11,101,99,104,111,45,99,108,97,105,109,115,1,130,1,1,64,1,4,97,114,103,48,229,0,0,239,0,4,0,10,101,99,104,111,45,103,114,97,110,116,1,131,1,1,64,2,4,97,114,103,48,13,4,97,114,103,49,115,0,251,0,4,0,10,110,101,119,45,116,105,99,107,101,116,1,132,1,1,64,2,4,97,114,103,48,27,4,97,114,103,49,49,0,199,0,4,0,10,112,97,105,114,45,99,108,97,105,109,1,133,1,1,64,1,4,97,114,103,48,250,0,0,13,4,0,6,115,101,114,105,97,108,1,134,1,1,64,1,4,97,114,103,48,199,0,0,199,0,4,0,14,116,114,97,110,115,102,101,114,45,99,108,97,105,109,1,135,1,1,64,2,4,97,114,103,48,63,4,97,114,103,49,199,0,0,199,0,4,0,19,116,114,97,110,115,102,101,114,45,112,97,105,114,45,99,108,97,105,109,1,136,1,1,64,2,4,97,114,103,48,199,0,4,97,114,103,49,246,0,0,199,0,4,0,28,116,114,97,110,115,102,101,114,45,119,105,116,104,45,99,108,97,105,109,45,99,97,108,108,98,97,99,107,1,137,1,1,64,2,4,97,114,103,48,49,4,97,114,103,49,246,0,0,199,0,4,0,19,119,105,116,104,45,99,108,97,105,109,45,99,97,108,108,98,97,99,107,1,138,1,1,64,2,4,115,101,108,102,242,0,4,97,114,103,48,49,0,199,0,4,0,44,105,110,118,111,107,101,45,105,100,101,110,116,105,116,121,45,99,97,108,108,98,97,99,107,50,54,54,50,49,99,52,48,98,52,56,102,99,101,53,50,99,97,51,55,1,139,1,1,64,2,4,115,101,108,102,246,0,4,97,114,103,48,49,0,199,0,4,0,44,105,110,118,111,107,101,45,105,100,101,110,116,105,116,121,45,99,97,108,108,98,97,99,107,98,50,100,51,100,54,102,100,52,101,48,51,49,55,56,53,102,50,55,56,1,140,1,5,187,13,1,1,76,0,12,98,114,105,100,103,101,45,114,101,102,45,48,3,1,0,12,98,114,105,100,103,101,45,114,101,102,45,49,3,2,0,12,98,114,105,100,103,101,45,114,101,102,45,52,3,3,0,12,98,114,105,100,103,101,45,114,101,102,45,53,3,4,0,12,98,114,105,100,103,101,45,114,101,102,45,54,3,5,0,12,98,114,105,100,103,101,45,114,101,102,45,56,3,6,0,10,98,114,105,100,103,101,45,110,97,116,3,7,0,18,98,114,105,100,103,101,45,114,111,119,45,52,45,105,110,112,117,116,3,8,0,18,98,114,105,100,103,101,45,114,111,119,45,56,45,105,110,112,117,116,3,9,0,22,98,114,105,100,103,101,45,116,97,98,108,101,45,52,45,52,45,105,110,112,117,116,3,10,0,22,98,114,105,100,103,101,45,116,97,98,108,101,45,52,45,56,45,105,110,112,117,116,3,11,0,20,98,114,105,100,103,101,45,97,114,101,110,97,45,52,45,105,110,112,117,116,3,12,0,20,98,114,105,100,103,101,45,118,97,108,117,101,45,52,45,105,110,112,117,116,3,13,0,13,98,111,111,107,105,110,103,45,105,110,112,117,116,3,14,0,19,98,114,105,100,103,101,45,114,111,119,45,49,45,111,117,116,112,117,116,3,15,0,19,98,114,105,100,103,101,45,114,111,119,45,53,45,111,117,116,112,117,116,3,16,0,23,98,114,105,100,103,101,45,116,97,98,108,101,45,49,45,49,45,111,117,116,112,117,116,3,17,0,23,98,114,105,100,103,101,45,116,97,98,108,101,45,49,45,53,45,111,117,116,112,117,116,3,18,0,21,98,114,105,100,103,101,45,97,114,101,110,97,45,49,45,111,117,116,112,117,116,3,19,0,21,98,114,105,100,103,101,45,118,97,108,117,101,45,49,45,111,117,116,112,117,116,3,20,0,18,98,114,105,100,103,101,45,114,111,119,45,53,45,105,110,112,117,116,3,21,0,22,98,114,105,100,103,101,45,116,97,98,108,101,45,53,45,53,45,105,110,112,117,116,3,22,0,20,98,114,105,100,103,101,45,97,114,101,110,97,45,53,45,105,110,112,117,116,3,23,0,20,98,114,105,100,103,101,45,118,97,108,117,101,45,53,45,105,110,112,117,116,3,24,0,11,99,108,97,105,109,45,105,110,112,117,116,3,25,0,19,98,114,105,100,103,101,45,114,111,119,45,52,45,111,117,116,112,117,116,3,26,0,19,98,114,105,100,103,101,45,114,111,119,45,56,45,111,117,116,112,117,116,3,27,0,23,98,114,105,100,103,101,45,116,97,98,108,101,45,52,45,52,45,111,117,116,112,117,116,3,28,0,23,98,114,105,100,103,101,45,116,97,98,108,101,45,52,45,56,45,111,117,116,112,117,116,3,29,0,21,98,114,105,100,103,101,45,97,114,101,110,97,45,52,45,111,117,116,112,117,116,3,30,0,21,98,114,105,100,103,101,45,118,97,108,117,101,45,52,45,111,117,116,112,117,116,3,31,0,14,98,111,111,107,105,110,103,45,111,117,116,112,117,116,3,32,0,23,98,114,105,100,103,101,45,116,97,98,108,101,45,53,45,53,45,111,117,116,112,117,116,3,33,0,21,98,114,105,100,103,101,45,97,114,101,110,97,45,53,45,111,117,116,112,117,116,3,34,0,21,98,114,105,100,103,101,45,118,97,108,117,101,45,53,45,111,117,116,112,117,116,3,35,0,12,99,108,97,105,109,45,111,117,116,112,117,116,3,36,0,18,98,114,105,100,103,101,45,114,111,119,45,48,45,105,110,112,117,116,3,37,0,22,98,114,105,100,103,101,45,116,97,98,108,101,45,48,45,48,45,105,110,112,117,116,3,38,0,22,98,114,105,100,103,101,45,116,97,98,108,101,45,48,45,53,45,105,110,112,117,116,3,39,0,20,98,114,105,100,103,101,45,97,114,101,110,97,45,48,45,105,110,112,117,116,3,40,0,20,98,114,105,100,103,101,45,118,97,108,117,101,45,48,45,105,110,112,117,116,3,41,0,19,98,114,105,100,103,101,45,114,111,119,45,48,45,111,117,116,112,117,116,3,42,0,23,98,114,105,100,103,101,45,116,97,98,108,101,45,48,45,48,45,111,117,116,112,117,116,3,43,0,23,98,114,105,100,103,101,45,116,97,98,108,101,45,48,45,53,45,111,117,116,112,117,116,3,44,0,21,98,114,105,100,103,101,45,97,114,101,110,97,45,48,45,111,117,116,112,117,116,3,45,0,21,98,114,105,100,103,101,45,118,97,108,117,101,45,48,45,111,117,116,112,117,116,3,46,0,18,98,114,105,100,103,101,45,114,111,119,45,54,45,105,110,112,117,116,3,47,0,22,98,114,105,100,103,101,45,116,97,98,108,101,45,54,45,54,45,105,110,112,117,116,3,48,0,20,98,114,105,100,103,101,45,97,114,101,110,97,45,54,45,105,110,112,117,116,3,49,0,20,98,114,105,100,103,101,45,118,97,108,117,101,45,54,45,105,110,112,117,116,3,50,0,11,103,114,97,110,116,45,105,110,112,117,116,3,51,0,19,98,114,105,100,103,101,45,114,111,119,45,54,45,111,117,116,112,117,116,3,52,0,23,98,114,105,100,103,101,45,116,97,98,108,101,45,54,45,54,45,111,117,116,112,117,116,3,53,0,21,98,114,105,100,103,101,45,97,114,101,110,97,45,54,45,111,117,116,112,117,116,3,54,0,21,98,114,105,100,103,101,45,118,97,108,117,101,45,54,45,111,117,116,112,117,116,3,55,0,12,103,114,97,110,116,45,111,117,116,112,117,116,3,56,0,37,105,100,101,110,116,105,116,121,45,99,97,108,108,98,97,99,107,50,54,54,50,49,99,52,48,98,52,56,102,99,101,53,50,99,97,51,55,3,57,0,37,105,100,101,110,116,105,116,121,45,99,97,108,108,98,97,99,107,98,50,100,51,100,54,102,100,52,101,48,51,49,55,56,53,102,50,55,56,3,60,0,15,105,100,101,110,116,105,116,121,45,116,105,99,107,101,116,3,63,0,12,98,111,111,107,105,110,103,45,115,112,97,110,1,17,0,13,99,108,97,105,109,45,99,108,111,115,117,114,101,1,18,0,9,99,108,97,105,109,45,102,111,114,1,19,0,11,99,108,97,105,109,45,113,117,111,116,97,1,20,0,12,101,99,104,111,45,98,111,111,107,105,110,103,1,21,0,10,101,99,104,111,45,99,108,97,105,109,1,22,0,11,101,99,104,111,45,99,108,97,105,109,115,1,23,0,10,101,99,104,111,45,103,114,97,110,116,1,24,0,10,110,101,119,45,116,105,99,107,101,116,1,25,0,10,112,97,105,114,45,99,108,97,105,109,1,26,0,6,115,101,114,105,97,108,1,27,0,14,116,114,97,110,115,102,101,114,45,99,108,97,105,109,1,28,0,19,116,114,97,110,115,102,101,114,45,112,97,105,114,45,99,108,97,105,109,1,29,0,28,116,114,97,110,115,102,101,114,45,119,105,116,104,45,99,108,97,105,109,45,99,97,108,108,98,97,99,107,1,30,0,19,119,105,116,104,45,99,108,97,105,109,45,99,97,108,108,98,97,99,107,1,31,0,44,105,110,118,111,107,101,45,105,100,101,110,116,105,116,121,45,99,97,108,108,98,97,99,107,50,54,54,50,49,99,52,48,98,52,56,102,99,101,53,50,99,97,51,55,1,32,0,44,105,110,118,111,107,101,45,105,100,101,110,116,105,116,121,45,99,97,108,108,98,97,99,107,98,50,100,51,100,54,102,100,52,101,48,51,49,55,56,53,102,50,55,56,1,33,11,51,1,0,43,108,101,97,110,45,98,114,105,100,103,101,58,111,119,110,101,100,45,99,104,101,99,107,101,100,45,114,101,99,111,114,100,115,47,97,112,105,64,49,46,48,46,48,5,1,1,5,83,0,157,11,14,99,111,109,112,111,110,101,110,116,45,110,97,109,101,1,140,3,0,0,42,0,7,114,101,97,108,108,111,99,1,8,112,111,115,116,45,105,51,50,2,8,112,111,115,116,45,105,54,52,3,8,112,111,115,116,45,102,51,50,4,8,112,111,115,116,45,102,54,52,5,6,108,111,119,101,114,48,6,6,108,111,119,101,114,49,7,6,108,111,119,101,114,50,8,6,108,111,119,101,114,51,9,6,108,111,119,101,114,52,10,6,108,111,119,101,114,53,11,6,108,111,119,101,114,54,12,6,108,111,119,101,114,55,13,6,108,111,119,101,114,56,14,6,108,111,119,101,114,57,15,7,108,111,119,101,114,49,48,16,7,108,111,119,101,114,49,49,17,7,108,111,119,101,114,49,50,18,7,108,111,119,101,114,49,51,19,7,108,111,119,101,114,49,52,20,7,108,111,119,101,114,49,53,21,7,108,111,119,101,114,49,54,22,6,100,114,111,112,53,54,23,6,100,114,111,112,53,55,24,6,100,114,111,112,53,56,25,8,102,111,114,119,97,114,100,48,26,8,102,111,114,119,97,114,100,49,27,8,102,111,114,119,97,114,100,50,28,8,102,111,114,119,97,114,100,51,29,8,102,111,114,119,97,114,100,52,30,8,102,111,114,119,97,114,100,53,31,8,102,111,114,119,97,114,100,54,32,8,102,111,114,119,97,114,100,55,33,8,102,111,114,119,97,114,100,56,34,8,102,111,114,119,97,114,100,57,35,9,102,111,114,119,97,114,100,49,48,36,9,102,111,114,119,97,114,100,49,49,37,9,102,111,114,119,97,114,100,49,50,38,9,102,111,114,119,97,114,100,49,51,39,9,102,111,114,119,97,114,100,49,52,40,9,102,111,114,119,97,114,100,49,53,41,9,102,111,114,119,97,114,100,49,54,1,11,0,2,1,0,6,109,101,109,111,114,121,1,23,0,17,2,0,9,97,108,108,111,99,97,116,111,114,1,7,102,111,114,119,97,114,100,1,46,0,18,4,0,10,97,108,108,111,99,97,116,105,111,110,1,7,105,109,112,111,114,116,115,2,9,114,101,115,111,117,114,99,101,115,3,9,102,111,114,119,97,114,100,101,100,1,203,1,1,34,0,5,104,111,115,116,48,1,5,104,111,115,116,49,2,5,104,111,115,116,50,3,5,104,111,115,116,51,4,5,104,111,115,116,52,5,5,104,111,115,116,53,6,5,104,111,115,116,54,7,5,104,111,115,116,55,8,5,104,111,115,116,56,9,5,104,111,115,116,57,10,6,104,111,115,116,49,48,11,6,104,111,115,116,49,49,12,6,104,111,115,116,49,50,13,6,104,111,115,116,49,51,14,6,104,111,115,116,49,52,15,6,104,111,115,116,49,53,16,6,104,111,115,116,49,54,17,2,102,48,18,2,102,49,19,2,102,50,20,2,102,51,21,2,102,52,22,2,102,53,23,2,102,54,24,2,102,55,25,2,102,56,26,2,102,57,27,3,102,49,48,28,3,102,49,49,29,3,102,49,50,30,3,102,49,51,31,3,102,49,52,32,3,102,49,53,33,3,102,49,54,1,198,5,3,67,0,3,97,112,105,1,7,112,117,98,108,105,99,48,2,7,112,117,98,108,105,99,49,3,7,112,117,98,108,105,99,50,4,7,112,117,98,108,105,99,51,5,7,112,117,98,108,105,99,52,6,7,112,117,98,108,105,99,53,7,7,112,117,98,108,105,99,54,8,7,112,117,98,108,105,99,55,9,7,112,117,98,108,105,99,56,10,7,112,117,98,108,105,99,57,11,8,112,117,98,108,105,99,49,48,12,8,112,117,98,108,105,99,49,49,13,8,112,117,98,108,105,99,49,50,14,8,112,117,98,108,105,99,49,51,15,8,112,117,98,108,105,99,49,52,16,8,112,117,98,108,105,99,49,53,17,8,112,117,98,108,105,99,49,54,18,8,112,117,98,108,105,99,49,55,19,8,112,117,98,108,105,99,49,56,20,8,112,117,98,108,105,99,49,57,21,8,112,117,98,108,105,99,50,48,22,8,112,117,98,108,105,99,50,49,23,8,112,117,98,108,105,99,50,50,24,8,112,117,98,108,105,99,50,51,25,8,112,117,98,108,105,99,50,52,26,8,112,117,98,108,105,99,50,53,27,8,112,117,98,108,105,99,50,54,28,8,112,117,98,108,105,99,50,55,29,8,112,117,98,108,105,99,50,56,30,8,112,117,98,108,105,99,50,57,31,8,112,117,98,108,105,99,51,48,32,8,112,117,98,108,105,99,51,49,33,8,112,117,98,108,105,99,51,50,34,8,112,117,98,108,105,99,51,51,35,8,112,117,98,108,105,99,51,52,36,8,112,117,98,108,105,99,51,53,37,8,112,117,98,108,105,99,51,54,38,8,112,117,98,108,105,99,51,55,39,8,112,117,98,108,105,99,51,56,40,8,112,117,98,108,105,99,51,57,41,8,112,117,98,108,105,99,52,48,42,8,112,117,98,108,105,99,52,49,43,8,112,117,98,108,105,99,52,50,44,8,112,117,98,108,105,99,52,51,45,8,112,117,98,108,105,99,52,52,46,8,112,117,98,108,105,99,52,53,47,8,112,117,98,108,105,99,52,54,48,8,112,117,98,108,105,99,52,55,49,8,112,117,98,108,105,99,52,56,50,8,112,117,98,108,105,99,52,57,51,8,112,117,98,108,105,99,53,48,52,8,112,117,98,108,105,99,53,49,53,8,112,117,98,108,105,99,53,50,54,8,112,117,98,108,105,99,53,51,55,8,112,117,98,108,105,99,53,52,56,8,112,117,98,108,105,99,53,53,57,16,112,117,98,108,105,99,82,101,115,111,117,114,99,101,53,54,58,14,112,117,98,108,105,99,66,111,114,114,111,119,53,54,59,11,112,117,98,108,105,99,79,119,110,53,54,60,16,112,117,98,108,105,99,82,101,115,111,117,114,99,101,53,55,61,14,112,117,98,108,105,99,66,111,114,114,111,119,53,55,62,11,112,117,98,108,105,99,79,119,110,53,55,63,16,112,117,98,108,105,99,82,101,115,111,117,114,99,101,53,56,64,14,112,117,98,108,105,99,66,111,114,114,111,119,53,56,65,11,112,117,98,108,105,99,79,119,110,53,56,83,10,112,117,98,108,105,99,45,97,112,105,1,16,5,2,0,4,104,111,115,116,1,6,112,117,98,108,105,99};
typedef struct ows_frame ows_frame;
typedef struct {
  lb_owned_context *native;
  wasm_engine_t *engine;
  wasmtime_component_t *component;
  ows_frame *frames;
  size_t depth;
  bool closing;
} ows_session;
struct ows_frame {
  ows_frame *parent;
  ows_session *session;
  wasmtime_store_t *store;
  wasmtime_component_linker_t *linker;
  wasmtime_component_instance_t instance;
  ow_native_host host;
  ow_native_call call;
};
static inline void ows_session_destroy(ows_session *session) {
  if (session->component) wasmtime_component_delete(session->component);
  if (session->engine) wasm_engine_delete(session->engine);
  LB_OWNED_FREE(session);
}
static inline int ows_session_open(lb_owned_context *native, ows_session **out) {
  int status = lb_owned_ready(native);
  if (status) return status;
  ows_session *session = LB_OWNED_ALLOC(sizeof(*session));
  if (!session) return LB_OWNED_ALLOC_FAILED;
  memset(session, 0, sizeof(*session)); session->native = native;
  wasm_config_t *config = wasm_config_new();
  if (!config) { ows_session_destroy(session); return LB_OWNED_ALLOC_FAILED; }
  wasmtime_config_wasm_component_model_set(config, true);
  session->engine = wasm_engine_new_with_config(config);
  if (!session->engine) { ows_session_destroy(session); return LB_OWNED_ALLOC_FAILED; }
  wasmtime_error_t *error = wasmtime_component_new(session->engine, ows_component_bytes, sizeof(ows_component_bytes), &session->component);
  if (error) { wasmtime_error_delete(error); ows_session_destroy(session); return LB_OWNED_RUNTIME; }
  *out = session; return LB_OWNED_OK;
}
static inline void ows_session_request_close(ows_session *session) {
  session->closing = true;
  for (ows_frame *frame = session->frames; frame; frame = frame->parent) {
    frame->host.closing = true; (void)ow_native_status(&frame->host, LB_OWNED_CLOSED);
  }
}
static inline int ows_frame_end(ows_frame *frame, int status) {
  ows_session *session = frame->session;
  if (frame->host.status && !status) status = frame->host.status;
  /* No canonical identity escapes this frame. Independently retained native
   * results are outside this ledger, so all proxy leases can be rolled back. */
  if (frame->call.host) (void)ow_native_call_end(&frame->call, false);
  if (frame->host.self && !ow_native_host_close(&frame->host) && !status) status = LB_OWNED_RUNTIME;
  if (frame->linker) wasmtime_component_linker_delete(frame->linker);
  if (frame->store) wasmtime_store_delete(frame->store);
  if (session) { session->frames = frame->parent; --session->depth; }
  *frame = (ows_frame){0}; return status;
}
static inline int ows_frame_begin(ows_session *session, ows_frame *frame) {
  int status = lb_owned_ready(session->native);
  if (status) return status;
  if (session->closing) return LB_OWNED_CLOSED;
  if (session->depth == LB_OWNED_SCOPE_LIMIT) return LB_OWNED_LIMIT;
  frame->parent = session->frames; frame->session = session;
  session->frames = frame; ++session->depth;
  frame->store = wasmtime_store_new(session->engine, NULL, NULL);
  if (!frame->store) return ows_frame_end(frame, LB_OWNED_ALLOC_FAILED);
  wasmtime_context_t *context = wasmtime_store_context(frame->store);
  if (!ow_native_host_init(&frame->host, session->native, context))
    return ows_frame_end(frame, frame->host.status ? frame->host.status : LB_OWNED_ALLOC_FAILED);
  frame->linker = wasmtime_component_linker_new(session->engine);
  if (!frame->linker) return ows_frame_end(frame, LB_OWNED_ALLOC_FAILED);
  wasmtime_error_t *error = ow_native_link(&frame->host, frame->linker);
  if (!error) error = wasmtime_component_linker_instantiate(frame->linker, context, session->component, &frame->instance);
  if (error) { wasmtime_error_delete(error); return ows_frame_end(frame, LB_OWNED_RUNTIME); }
  if (!ow_native_call_begin(&frame->host, &frame->call)) return ows_frame_end(frame, LB_OWNED_RUNTIME);
  return LB_OWNED_OK;
}
static inline int ows_invoke(ows_frame *frame, const char *name,
    const wasmtime_component_val_t *args, size_t count, wasmtime_component_val_t *out) {
  wasmtime_context_t *context = frame->host.context;
  wasmtime_component_export_index_t *api = wasmtime_component_instance_get_export_index(&frame->instance,
    context, NULL, "lean-bridge:owned-checked-records/api@1.0.0", 43);
  if (!api) return LB_OWNED_RUNTIME;
  wasmtime_component_export_index_t *index = wasmtime_component_instance_get_export_index(&frame->instance,
    context, api, name, strlen(name));
  wasmtime_component_export_index_delete(api);
  if (!index) return LB_OWNED_RUNTIME;
  wasmtime_component_func_t function;
  bool found = wasmtime_component_instance_get_func(&frame->instance, context, index, &function);
  wasmtime_component_export_index_delete(index);
  if (!found) return LB_OWNED_RUNTIME;
  wasmtime_error_t *error = wasmtime_component_func_call(&function, context, args, count, out, 1);
  int status = frame->host.status;
  if (error) { wasmtime_error_delete(error); if (!status) status = LB_OWNED_RUNTIME; }
  return status;
}
/* Canonical lowering borrows an owned host proxy. Creating ResourceAny borrows
 * here would require an already-active Component Model call frame. */
static bool ows_write_input(void *data, size_t type, bool borrowed, uint64_t token, wasmtime_component_val_t *out) {
  (void)borrowed;
  return ow_native_write_identity(data, type, false, token, out);
}
/* Only results of this frame's trusted component enter this reader. An own is
 * consumed once, even when several graph references point to its table row. */
static bool ows_read_output(void *data, size_t type, bool borrowed,
    const wasmtime_component_val_t *value, uint64_t *out) {
  ow_native_conversion *conversion = data; ow_native_host *host = conversion->host;
  if (!ow_native_ready(host) || !host->call || host->failure || borrowed
      || !ow_native_type(host, type, value->of.resource) || !wasmtime_component_resource_any_owned(value->of.resource)) return false;
  ow_native_read *read = conversion->reads;
  while (read && read->handle != value->of.resource) read = read->next;
  if (!read) {
    if (!lb_charge(&conversion->scope.memory, 1, sizeof(*read))) return false;
    read = lb_alloc(&conversion->scope.memory, 1, sizeof(*read));
    if (!read) return false;
    wasmtime_component_resource_host_t *resource = NULL;
    wasmtime_error_t *error = wasmtime_component_resource_any_to_host(host->context, value->of.resource, &resource);
    if (error) { ow_native_error(host, error); return false; }
    *read = (ow_native_read){.next = conversion->reads, .handle = value->of.resource,
      .rep = wasmtime_component_resource_host_rep(resource), .type = type,
      .borrowed = !wasmtime_component_resource_host_owned(resource)};
    uint32_t tag = wasmtime_component_resource_host_type(resource);
    wasmtime_component_resource_host_delete(resource); conversion->reads = read;
    if (tag != host->tags[type]) return false;
  }
  ow_native_entry *entry = ow_native_find(host, read->rep);
  if (!entry || read->type != type || read->borrowed || entry->type != type
      || !lb_owned_find(host->native, ow_native_kinds[type], entry->token)) return false;
  if (out) *out = entry->token;
  return true;
}
static inline int ows_conversion_status(ow_native_conversion *conversion, int invalid) {
  if (conversion->host->status) return conversion->host->status;
  return conversion->scope.memory.failure ? (int)conversion->scope.memory.failure : invalid;
}
static inline int ows_dispatch_0(ows_session *session,
    const lbov_7fab4b2842f6c64d9621_t23107461f72b24c37654 *a0, lbov_7fab4b2842f6c64d9621_t167081552b6f9c1d1afd *out, ov_result_owner *owner) {
  ows_frame frame = {0}; int status = ows_frame_begin(session, &frame);
  if (status) return status;
  ow_native_conversion input, output;
  ow_native_conversion_init(&input, &frame.host); ow_native_conversion_init(&output, &frame.host);
  input.scope.identities.write = ows_write_input; output.scope.identities.read = ows_read_output;
  wasmtime_component_val_t args[1] = {{0}}, reply = {0};
  lbov_7fab4b2842f6c64d9621_t167081552b6f9c1d1afd decoded = {0}, converted = {0}; ov_transaction transaction = {0};
  if (!ow_encode_4_input(a0, &input.scope, &args[0])) {
    status = ows_conversion_status(&input, LB_OWNED_INVALID); goto done;
  }
  status = ows_invoke(&frame, "booking-span", args, 1, &reply);
  if (status) goto done;
  if (!ow_decode_9_output(&reply, &output.scope, &decoded)) {
    status = ows_conversion_status(&output, OV_RESULT); goto done;
  }
  status = ov_begin(&transaction, session->native, owner, "owned-checked-records@1.0.0");
  if (!status) {
    lean_object *value = NULL;
    status = lbov_7fab4b2842f6c64d9621_v167081552b6f9c1d1afd_in(&decoded, 0, 1, &transaction, &value);
    if (!status) status = lbov_7fab4b2842f6c64d9621_v167081552b6f9c1d1afd_out(&converted, value, 0, &transaction);
  }
  if (!status) status = ov_commit(&transaction, owner);
  else if (transaction.scope.context) status = ov_abort(&transaction, status);
done:
  /* The store may have trapped, and output reads consume resource metadata.
   * Delete boxes only; frame teardown drains the complete native proxy ledger. */
  for (size_t i = 0; i < 1; ++i) wasmtime_component_val_delete(&args[i]);
  wasmtime_component_val_delete(&reply);
  ow_native_conversion_close(&output); ow_native_conversion_close(&input);
  status = ows_frame_end(&frame, status);
  if (status) (void)ov_owner_clear(owner); else *out = converted;
  return status;
}

static inline int ows_dispatch_1(ows_session *session,
    lbov_7fab4b2842f6c64d9621_t648974cffb2d6c1d7951 *out, ov_result_owner *owner) {
  ows_frame frame = {0}; int status = ows_frame_begin(session, &frame);
  if (status) return status;
  ow_native_conversion input, output;
  ow_native_conversion_init(&input, &frame.host); ow_native_conversion_init(&output, &frame.host);
  input.scope.identities.write = ows_write_input; output.scope.identities.read = ows_read_output;
  wasmtime_component_val_t args[1] = {{0}}, reply = {0};
  lbov_7fab4b2842f6c64d9621_t648974cffb2d6c1d7951 decoded = {0}, converted = {0}; ov_transaction transaction = {0};

  status = ows_invoke(&frame, "claim-closure", args, 0, &reply);
  if (status) goto done;
  if (!ow_decode_2_output(&reply, &output.scope, &decoded)) {
    status = ows_conversion_status(&output, OV_RESULT); goto done;
  }
  status = ov_begin(&transaction, session->native, owner, "owned-checked-records@1.0.0");
  if (!status) {
    lean_object *value = NULL;
    status = lbov_7fab4b2842f6c64d9621_v648974cffb2d6c1d7951_in(&decoded, 0, 1, &transaction, &value);
    if (!status) status = lbov_7fab4b2842f6c64d9621_v648974cffb2d6c1d7951_out(&converted, value, 0, &transaction);
  }
  if (!status) status = ov_commit(&transaction, owner);
  else if (transaction.scope.context) status = ov_abort(&transaction, status);
done:
  /* The store may have trapped, and output reads consume resource metadata.
   * Delete boxes only; frame teardown drains the complete native proxy ledger. */
  for (size_t i = 0; i < 1; ++i) wasmtime_component_val_delete(&args[i]);
  wasmtime_component_val_delete(&reply);
  ow_native_conversion_close(&output); ow_native_conversion_close(&input);
  status = ows_frame_end(&frame, status);
  if (status) (void)ov_owner_clear(owner); else *out = converted;
  return status;
}

static inline int ows_dispatch_2(ows_session *session,
    const lbov_7fab4b2842f6c64d9621_td79b9bbde250ee1779da *a0, lbov_7fab4b2842f6c64d9621_t160ce821a84f6887bbfd *out, ov_result_owner *owner) {
  ows_frame frame = {0}; int status = ows_frame_begin(session, &frame);
  if (status) return status;
  ow_native_conversion input, output;
  ow_native_conversion_init(&input, &frame.host); ow_native_conversion_init(&output, &frame.host);
  input.scope.identities.write = ows_write_input; output.scope.identities.read = ows_read_output;
  wasmtime_component_val_t args[1] = {{0}}, reply = {0};
  lbov_7fab4b2842f6c64d9621_t160ce821a84f6887bbfd decoded = {0}, converted = {0}; ov_transaction transaction = {0};
  if (!ow_encode_7_input(a0, &input.scope, &args[0])) {
    status = ows_conversion_status(&input, LB_OWNED_INVALID); goto done;
  }
  status = ows_invoke(&frame, "claim-for", args, 1, &reply);
  if (status) goto done;
  if (!ow_decode_1_output(&reply, &output.scope, &decoded)) {
    status = ows_conversion_status(&output, OV_RESULT); goto done;
  }
  status = ov_begin(&transaction, session->native, owner, "owned-checked-records@1.0.0");
  if (!status) {
    lean_object *value = NULL;
    status = lbov_7fab4b2842f6c64d9621_v160ce821a84f6887bbfd_in(&decoded, 0, 1, &transaction, &value);
    if (!status) status = lbov_7fab4b2842f6c64d9621_v160ce821a84f6887bbfd_out(&converted, value, 0, &transaction);
  }
  if (!status) status = ov_commit(&transaction, owner);
  else if (transaction.scope.context) status = ov_abort(&transaction, status);
done:
  /* The store may have trapped, and output reads consume resource metadata.
   * Delete boxes only; frame teardown drains the complete native proxy ledger. */
  for (size_t i = 0; i < 1; ++i) wasmtime_component_val_delete(&args[i]);
  wasmtime_component_val_delete(&reply);
  ow_native_conversion_close(&output); ow_native_conversion_close(&input);
  status = ows_frame_end(&frame, status);
  if (status) (void)ov_owner_clear(owner); else *out = converted;
  return status;
}

static inline int ows_dispatch_3(ows_session *session,
    const lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b *a0, lbov_7fab4b2842f6c64d9621_t167081552b6f9c1d1afd *out, ov_result_owner *owner) {
  ows_frame frame = {0}; int status = ows_frame_begin(session, &frame);
  if (status) return status;
  ow_native_conversion input, output;
  ow_native_conversion_init(&input, &frame.host); ow_native_conversion_init(&output, &frame.host);
  input.scope.identities.write = ows_write_input; output.scope.identities.read = ows_read_output;
  wasmtime_component_val_t args[1] = {{0}}, reply = {0};
  lbov_7fab4b2842f6c64d9621_t167081552b6f9c1d1afd decoded = {0}, converted = {0}; ov_transaction transaction = {0};
  if (!ow_encode_5_input(a0, &input.scope, &args[0])) {
    status = ows_conversion_status(&input, LB_OWNED_INVALID); goto done;
  }
  status = ows_invoke(&frame, "claim-quota", args, 1, &reply);
  if (status) goto done;
  if (!ow_decode_9_output(&reply, &output.scope, &decoded)) {
    status = ows_conversion_status(&output, OV_RESULT); goto done;
  }
  status = ov_begin(&transaction, session->native, owner, "owned-checked-records@1.0.0");
  if (!status) {
    lean_object *value = NULL;
    status = lbov_7fab4b2842f6c64d9621_v167081552b6f9c1d1afd_in(&decoded, 0, 1, &transaction, &value);
    if (!status) status = lbov_7fab4b2842f6c64d9621_v167081552b6f9c1d1afd_out(&converted, value, 0, &transaction);
  }
  if (!status) status = ov_commit(&transaction, owner);
  else if (transaction.scope.context) status = ov_abort(&transaction, status);
done:
  /* The store may have trapped, and output reads consume resource metadata.
   * Delete boxes only; frame teardown drains the complete native proxy ledger. */
  for (size_t i = 0; i < 1; ++i) wasmtime_component_val_delete(&args[i]);
  wasmtime_component_val_delete(&reply);
  ow_native_conversion_close(&output); ow_native_conversion_close(&input);
  status = ows_frame_end(&frame, status);
  if (status) (void)ov_owner_clear(owner); else *out = converted;
  return status;
}

static inline int ows_dispatch_4(ows_session *session,
    const lbov_7fab4b2842f6c64d9621_t23107461f72b24c37654 *a0, lbov_7fab4b2842f6c64d9621_t23107461f72b24c37654 *out, ov_result_owner *owner) {
  ows_frame frame = {0}; int status = ows_frame_begin(session, &frame);
  if (status) return status;
  ow_native_conversion input, output;
  ow_native_conversion_init(&input, &frame.host); ow_native_conversion_init(&output, &frame.host);
  input.scope.identities.write = ows_write_input; output.scope.identities.read = ows_read_output;
  wasmtime_component_val_t args[1] = {{0}}, reply = {0};
  lbov_7fab4b2842f6c64d9621_t23107461f72b24c37654 decoded = {0}, converted = {0}; ov_transaction transaction = {0};
  if (!ow_encode_4_input(a0, &input.scope, &args[0])) {
    status = ows_conversion_status(&input, LB_OWNED_INVALID); goto done;
  }
  status = ows_invoke(&frame, "echo-booking", args, 1, &reply);
  if (status) goto done;
  if (!ow_decode_4_output(&reply, &output.scope, &decoded)) {
    status = ows_conversion_status(&output, OV_RESULT); goto done;
  }
  status = ov_begin(&transaction, session->native, owner, "owned-checked-records@1.0.0");
  if (!status) {
    lean_object *value = NULL;
    status = lbov_7fab4b2842f6c64d9621_v23107461f72b24c37654_in(&decoded, 0, 1, &transaction, &value);
    if (!status) status = lbov_7fab4b2842f6c64d9621_v23107461f72b24c37654_out(&converted, value, 0, &transaction);
  }
  if (!status) status = ov_commit(&transaction, owner);
  else if (transaction.scope.context) status = ov_abort(&transaction, status);
done:
  /* The store may have trapped, and output reads consume resource metadata.
   * Delete boxes only; frame teardown drains the complete native proxy ledger. */
  for (size_t i = 0; i < 1; ++i) wasmtime_component_val_delete(&args[i]);
  wasmtime_component_val_delete(&reply);
  ow_native_conversion_close(&output); ow_native_conversion_close(&input);
  status = ows_frame_end(&frame, status);
  if (status) (void)ov_owner_clear(owner); else *out = converted;
  return status;
}

static inline int ows_dispatch_5(ows_session *session,
    const lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b *a0, lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b *out, ov_result_owner *owner) {
  ows_frame frame = {0}; int status = ows_frame_begin(session, &frame);
  if (status) return status;
  ow_native_conversion input, output;
  ow_native_conversion_init(&input, &frame.host); ow_native_conversion_init(&output, &frame.host);
  input.scope.identities.write = ows_write_input; output.scope.identities.read = ows_read_output;
  wasmtime_component_val_t args[1] = {{0}}, reply = {0};
  lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b decoded = {0}, converted = {0}; ov_transaction transaction = {0};
  if (!ow_encode_5_input(a0, &input.scope, &args[0])) {
    status = ows_conversion_status(&input, LB_OWNED_INVALID); goto done;
  }
  status = ows_invoke(&frame, "echo-claim", args, 1, &reply);
  if (status) goto done;
  if (!ow_decode_5_output(&reply, &output.scope, &decoded)) {
    status = ows_conversion_status(&output, OV_RESULT); goto done;
  }
  status = ov_begin(&transaction, session->native, owner, "owned-checked-records@1.0.0");
  if (!status) {
    lean_object *value = NULL;
    status = lbov_7fab4b2842f6c64d9621_vb2825946e038e653bd2b_in(&decoded, 0, 1, &transaction, &value);
    if (!status) status = lbov_7fab4b2842f6c64d9621_vb2825946e038e653bd2b_out(&converted, value, 0, &transaction);
  }
  if (!status) status = ov_commit(&transaction, owner);
  else if (transaction.scope.context) status = ov_abort(&transaction, status);
done:
  /* The store may have trapped, and output reads consume resource metadata.
   * Delete boxes only; frame teardown drains the complete native proxy ledger. */
  for (size_t i = 0; i < 1; ++i) wasmtime_component_val_delete(&args[i]);
  wasmtime_component_val_delete(&reply);
  ow_native_conversion_close(&output); ow_native_conversion_close(&input);
  status = ows_frame_end(&frame, status);
  if (status) (void)ov_owner_clear(owner); else *out = converted;
  return status;
}

static inline int ows_dispatch_6(ows_session *session,
    const lbov_7fab4b2842f6c64d9621_tf790309465bbf573c7b9 *a0, lbov_7fab4b2842f6c64d9621_tf790309465bbf573c7b9 *out, ov_result_owner *owner) {
  ows_frame frame = {0}; int status = ows_frame_begin(session, &frame);
  if (status) return status;
  ow_native_conversion input, output;
  ow_native_conversion_init(&input, &frame.host); ow_native_conversion_init(&output, &frame.host);
  input.scope.identities.write = ows_write_input; output.scope.identities.read = ows_read_output;
  wasmtime_component_val_t args[1] = {{0}}, reply = {0};
  lbov_7fab4b2842f6c64d9621_tf790309465bbf573c7b9 decoded = {0}, converted = {0}; ov_transaction transaction = {0};
  if (!ow_encode_0_input(a0, &input.scope, &args[0])) {
    status = ows_conversion_status(&input, LB_OWNED_INVALID); goto done;
  }
  status = ows_invoke(&frame, "echo-claims", args, 1, &reply);
  if (status) goto done;
  if (!ow_decode_0_output(&reply, &output.scope, &decoded)) {
    status = ows_conversion_status(&output, OV_RESULT); goto done;
  }
  status = ov_begin(&transaction, session->native, owner, "owned-checked-records@1.0.0");
  if (!status) {
    lean_object *value = NULL;
    status = lbov_7fab4b2842f6c64d9621_vf790309465bbf573c7b9_in(&decoded, 0, 1, &transaction, &value);
    if (!status) status = lbov_7fab4b2842f6c64d9621_vf790309465bbf573c7b9_out(&converted, value, 0, &transaction);
  }
  if (!status) status = ov_commit(&transaction, owner);
  else if (transaction.scope.context) status = ov_abort(&transaction, status);
done:
  /* The store may have trapped, and output reads consume resource metadata.
   * Delete boxes only; frame teardown drains the complete native proxy ledger. */
  for (size_t i = 0; i < 1; ++i) wasmtime_component_val_delete(&args[i]);
  wasmtime_component_val_delete(&reply);
  ow_native_conversion_close(&output); ow_native_conversion_close(&input);
  status = ows_frame_end(&frame, status);
  if (status) (void)ov_owner_clear(owner); else *out = converted;
  return status;
}

static inline int ows_dispatch_7(ows_session *session,
    const lbov_7fab4b2842f6c64d9621_t4ce841c87ea3b1559bfb *a0, lbov_7fab4b2842f6c64d9621_t4ce841c87ea3b1559bfb *out, ov_result_owner *owner) {
  ows_frame frame = {0}; int status = ows_frame_begin(session, &frame);
  if (status) return status;
  ow_native_conversion input, output;
  ow_native_conversion_init(&input, &frame.host); ow_native_conversion_init(&output, &frame.host);
  input.scope.identities.write = ows_write_input; output.scope.identities.read = ows_read_output;
  wasmtime_component_val_t args[1] = {{0}}, reply = {0};
  lbov_7fab4b2842f6c64d9621_t4ce841c87ea3b1559bfb decoded = {0}, converted = {0}; ov_transaction transaction = {0};
  if (!ow_encode_6_input(a0, &input.scope, &args[0])) {
    status = ows_conversion_status(&input, LB_OWNED_INVALID); goto done;
  }
  status = ows_invoke(&frame, "echo-grant", args, 1, &reply);
  if (status) goto done;
  if (!ow_decode_6_output(&reply, &output.scope, &decoded)) {
    status = ows_conversion_status(&output, OV_RESULT); goto done;
  }
  status = ov_begin(&transaction, session->native, owner, "owned-checked-records@1.0.0");
  if (!status) {
    lean_object *value = NULL;
    status = lbov_7fab4b2842f6c64d9621_v4ce841c87ea3b1559bfb_in(&decoded, 0, 1, &transaction, &value);
    if (!status) status = lbov_7fab4b2842f6c64d9621_v4ce841c87ea3b1559bfb_out(&converted, value, 0, &transaction);
  }
  if (!status) status = ov_commit(&transaction, owner);
  else if (transaction.scope.context) status = ov_abort(&transaction, status);
done:
  /* The store may have trapped, and output reads consume resource metadata.
   * Delete boxes only; frame teardown drains the complete native proxy ledger. */
  for (size_t i = 0; i < 1; ++i) wasmtime_component_val_delete(&args[i]);
  wasmtime_component_val_delete(&reply);
  ow_native_conversion_close(&output); ow_native_conversion_close(&input);
  status = ows_frame_end(&frame, status);
  if (status) (void)ov_owner_clear(owner); else *out = converted;
  return status;
}

static inline int ows_dispatch_8(ows_session *session,
    const lbov_7fab4b2842f6c64d9621_t167081552b6f9c1d1afd *a0, const lbov_7fab4b2842f6c64d9621_tdc0347e1f7f5c4d928f1 *a1, lbov_7fab4b2842f6c64d9621_td79b9bbde250ee1779da *out, ov_result_owner *owner) {
  ows_frame frame = {0}; int status = ows_frame_begin(session, &frame);
  if (status) return status;
  ow_native_conversion input, output;
  ow_native_conversion_init(&input, &frame.host); ow_native_conversion_init(&output, &frame.host);
  input.scope.identities.write = ows_write_input; output.scope.identities.read = ows_read_output;
  wasmtime_component_val_t args[2] = {{0}}, reply = {0};
  lbov_7fab4b2842f6c64d9621_td79b9bbde250ee1779da decoded = {0}, converted = {0}; ov_transaction transaction = {0};
  if (!ow_encode_9_input(a0, &input.scope, &args[0])) {
    status = ows_conversion_status(&input, LB_OWNED_INVALID); goto done;
  }
  if (!ow_encode_10_input(a1, &input.scope, &args[1])) {
    status = ows_conversion_status(&input, LB_OWNED_INVALID); goto done;
  }
  status = ows_invoke(&frame, "new-ticket", args, 2, &reply);
  if (status) goto done;
  if (!ow_decode_7_output(&reply, &output.scope, &decoded)) {
    status = ows_conversion_status(&output, OV_RESULT); goto done;
  }
  status = ov_begin(&transaction, session->native, owner, "owned-checked-records@1.0.0");
  if (!status) {
    lean_object *value = NULL;
    status = lbov_7fab4b2842f6c64d9621_vd79b9bbde250ee1779da_in(&decoded, 0, 1, &transaction, &value);
    if (!status) status = lbov_7fab4b2842f6c64d9621_vd79b9bbde250ee1779da_out(&converted, value, 0, &transaction);
  }
  if (!status) status = ov_commit(&transaction, owner);
  else if (transaction.scope.context) status = ov_abort(&transaction, status);
done:
  /* The store may have trapped, and output reads consume resource metadata.
   * Delete boxes only; frame teardown drains the complete native proxy ledger. */
  for (size_t i = 0; i < 2; ++i) wasmtime_component_val_delete(&args[i]);
  wasmtime_component_val_delete(&reply);
  ow_native_conversion_close(&output); ow_native_conversion_close(&input);
  status = ows_frame_end(&frame, status);
  if (status) (void)ov_owner_clear(owner); else *out = converted;
  return status;
}

static inline int ows_dispatch_9(ows_session *session,
    const lbov_7fab4b2842f6c64d9621_t23107461f72b24c37654 *a0, const lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b *a1, lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b *out, ov_result_owner *owner) {
  ows_frame frame = {0}; int status = ows_frame_begin(session, &frame);
  if (status) return status;
  ow_native_conversion input, output;
  ow_native_conversion_init(&input, &frame.host); ow_native_conversion_init(&output, &frame.host);
  input.scope.identities.write = ows_write_input; output.scope.identities.read = ows_read_output;
  wasmtime_component_val_t args[2] = {{0}}, reply = {0};
  lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b decoded = {0}, converted = {0}; ov_transaction transaction = {0};
  if (!ow_encode_4_input(a0, &input.scope, &args[0])) {
    status = ows_conversion_status(&input, LB_OWNED_INVALID); goto done;
  }
  if (!ow_encode_5_input(a1, &input.scope, &args[1])) {
    status = ows_conversion_status(&input, LB_OWNED_INVALID); goto done;
  }
  status = ows_invoke(&frame, "pair-claim", args, 2, &reply);
  if (status) goto done;
  if (!ow_decode_5_output(&reply, &output.scope, &decoded)) {
    status = ows_conversion_status(&output, OV_RESULT); goto done;
  }
  status = ov_begin(&transaction, session->native, owner, "owned-checked-records@1.0.0");
  if (!status) {
    lean_object *value = NULL;
    status = lbov_7fab4b2842f6c64d9621_vb2825946e038e653bd2b_in(&decoded, 0, 1, &transaction, &value);
    if (!status) status = lbov_7fab4b2842f6c64d9621_vb2825946e038e653bd2b_out(&converted, value, 0, &transaction);
  }
  if (!status) status = ov_commit(&transaction, owner);
  else if (transaction.scope.context) status = ov_abort(&transaction, status);
done:
  /* The store may have trapped, and output reads consume resource metadata.
   * Delete boxes only; frame teardown drains the complete native proxy ledger. */
  for (size_t i = 0; i < 2; ++i) wasmtime_component_val_delete(&args[i]);
  wasmtime_component_val_delete(&reply);
  ow_native_conversion_close(&output); ow_native_conversion_close(&input);
  status = ows_frame_end(&frame, status);
  if (status) (void)ov_owner_clear(owner); else *out = converted;
  return status;
}

static inline int ows_dispatch_10(ows_session *session,
    const lbov_7fab4b2842f6c64d9621_td79b9bbde250ee1779da *a0, lbov_7fab4b2842f6c64d9621_t167081552b6f9c1d1afd *out, ov_result_owner *owner) {
  ows_frame frame = {0}; int status = ows_frame_begin(session, &frame);
  if (status) return status;
  ow_native_conversion input, output;
  ow_native_conversion_init(&input, &frame.host); ow_native_conversion_init(&output, &frame.host);
  input.scope.identities.write = ows_write_input; output.scope.identities.read = ows_read_output;
  wasmtime_component_val_t args[1] = {{0}}, reply = {0};
  lbov_7fab4b2842f6c64d9621_t167081552b6f9c1d1afd decoded = {0}, converted = {0}; ov_transaction transaction = {0};
  if (!ow_encode_7_input(a0, &input.scope, &args[0])) {
    status = ows_conversion_status(&input, LB_OWNED_INVALID); goto done;
  }
  status = ows_invoke(&frame, "serial", args, 1, &reply);
  if (status) goto done;
  if (!ow_decode_9_output(&reply, &output.scope, &decoded)) {
    status = ows_conversion_status(&output, OV_RESULT); goto done;
  }
  status = ov_begin(&transaction, session->native, owner, "owned-checked-records@1.0.0");
  if (!status) {
    lean_object *value = NULL;
    status = lbov_7fab4b2842f6c64d9621_v167081552b6f9c1d1afd_in(&decoded, 0, 1, &transaction, &value);
    if (!status) status = lbov_7fab4b2842f6c64d9621_v167081552b6f9c1d1afd_out(&converted, value, 0, &transaction);
  }
  if (!status) status = ov_commit(&transaction, owner);
  else if (transaction.scope.context) status = ov_abort(&transaction, status);
done:
  /* The store may have trapped, and output reads consume resource metadata.
   * Delete boxes only; frame teardown drains the complete native proxy ledger. */
  for (size_t i = 0; i < 1; ++i) wasmtime_component_val_delete(&args[i]);
  wasmtime_component_val_delete(&reply);
  ow_native_conversion_close(&output); ow_native_conversion_close(&input);
  status = ows_frame_end(&frame, status);
  if (status) (void)ov_owner_clear(owner); else *out = converted;
  return status;
}

static inline int ows_dispatch_11(ows_session *session,
    const lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b *a0, ov_input_transfers *transfer, lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b *out, ov_result_owner *owner) {
  ows_frame frame = {0}; int status = ows_frame_begin(session, &frame);
  if (status) return status;
  frame.host.input_transfers = transfer;
  ow_native_conversion input, output;
  ow_native_conversion_init(&input, &frame.host); ow_native_conversion_init(&output, &frame.host);
  input.scope.identities.write = ows_write_input; output.scope.identities.read = ows_read_output;
  wasmtime_component_val_t args[1] = {{0}}, reply = {0};
  lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b decoded = {0}, converted = {0}; ov_transaction transaction = {0};
  if (!ow_encode_5_output(a0, &input.scope, &args[0])) {
    status = ows_conversion_status(&input, LB_OWNED_INVALID); goto done;
  }
  status = ows_invoke(&frame, "transfer-claim", args, 1, &reply);
  if (status) goto done;
  if (!ow_decode_5_output(&reply, &output.scope, &decoded)) {
    status = ows_conversion_status(&output, OV_RESULT); goto done;
  }
  status = ov_begin(&transaction, session->native, owner, "owned-checked-records@1.0.0");
  if (!status) {
    lean_object *value = NULL;
    status = lbov_7fab4b2842f6c64d9621_vb2825946e038e653bd2b_in(&decoded, 0, 1, &transaction, &value);
    if (!status) status = lbov_7fab4b2842f6c64d9621_vb2825946e038e653bd2b_out(&converted, value, 0, &transaction);
  }
  if (!status) status = ov_commit(&transaction, owner);
  else if (transaction.scope.context) status = ov_abort(&transaction, status);
done:
  /* The store may have trapped, and output reads consume resource metadata.
   * Delete boxes only; frame teardown drains the complete native proxy ledger. */
  for (size_t i = 0; i < 1; ++i) wasmtime_component_val_delete(&args[i]);
  wasmtime_component_val_delete(&reply);
  ow_native_conversion_close(&output); ow_native_conversion_close(&input);
  status = ows_frame_end(&frame, status);
  if (status) (void)ov_owner_clear(owner); else *out = converted;
  return status;
}

static inline int ows_dispatch_12(ows_session *session,
    const lbov_7fab4b2842f6c64d9621_t23107461f72b24c37654 *a0, const lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b *a1, ov_input_transfers *transfer, lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b *out, ov_result_owner *owner) {
  ows_frame frame = {0}; int status = ows_frame_begin(session, &frame);
  if (status) return status;
  frame.host.input_transfers = transfer;
  ow_native_conversion input, output;
  ow_native_conversion_init(&input, &frame.host); ow_native_conversion_init(&output, &frame.host);
  input.scope.identities.write = ows_write_input; output.scope.identities.read = ows_read_output;
  wasmtime_component_val_t args[2] = {{0}}, reply = {0};
  lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b decoded = {0}, converted = {0}; ov_transaction transaction = {0};
  if (!ow_encode_4_output(a0, &input.scope, &args[0])) {
    status = ows_conversion_status(&input, LB_OWNED_INVALID); goto done;
  }
  if (!ow_encode_5_output(a1, &input.scope, &args[1])) {
    status = ows_conversion_status(&input, LB_OWNED_INVALID); goto done;
  }
  status = ows_invoke(&frame, "transfer-pair-claim", args, 2, &reply);
  if (status) goto done;
  if (!ow_decode_5_output(&reply, &output.scope, &decoded)) {
    status = ows_conversion_status(&output, OV_RESULT); goto done;
  }
  status = ov_begin(&transaction, session->native, owner, "owned-checked-records@1.0.0");
  if (!status) {
    lean_object *value = NULL;
    status = lbov_7fab4b2842f6c64d9621_vb2825946e038e653bd2b_in(&decoded, 0, 1, &transaction, &value);
    if (!status) status = lbov_7fab4b2842f6c64d9621_vb2825946e038e653bd2b_out(&converted, value, 0, &transaction);
  }
  if (!status) status = ov_commit(&transaction, owner);
  else if (transaction.scope.context) status = ov_abort(&transaction, status);
done:
  /* The store may have trapped, and output reads consume resource metadata.
   * Delete boxes only; frame teardown drains the complete native proxy ledger. */
  for (size_t i = 0; i < 2; ++i) wasmtime_component_val_delete(&args[i]);
  wasmtime_component_val_delete(&reply);
  ow_native_conversion_close(&output); ow_native_conversion_close(&input);
  status = ows_frame_end(&frame, status);
  if (status) (void)ov_owner_clear(owner); else *out = converted;
  return status;
}

static inline int ows_dispatch_13(ows_session *session,
    const lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b *a0, const lbov_7fab4b2842f6c64d9621_t5035e6ea0903f12776d9 *a1, ov_input_transfers *transfer, lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b *out, ov_result_owner *owner) {
  ows_frame frame = {0}; int status = ows_frame_begin(session, &frame);
  if (status) return status;
  frame.host.input_transfers = transfer;
  ow_native_conversion input, output;
  ow_native_conversion_init(&input, &frame.host); ow_native_conversion_init(&output, &frame.host);
  input.scope.identities.write = ows_write_input; output.scope.identities.read = ows_read_output;
  wasmtime_component_val_t args[2] = {{0}}, reply = {0};
  lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b decoded = {0}, converted = {0}; ov_transaction transaction = {0};
  if (!ow_encode_5_output(a0, &input.scope, &args[0])) {
    status = ows_conversion_status(&input, LB_OWNED_INVALID); goto done;
  }
  if (!ow_encode_3_input(a1, &input.scope, &args[1])) {
    status = ows_conversion_status(&input, LB_OWNED_INVALID); goto done;
  }
  status = ows_invoke(&frame, "transfer-with-claim-callback", args, 2, &reply);
  if (status) goto done;
  if (!ow_decode_5_output(&reply, &output.scope, &decoded)) {
    status = ows_conversion_status(&output, OV_RESULT); goto done;
  }
  status = ov_begin(&transaction, session->native, owner, "owned-checked-records@1.0.0");
  if (!status) {
    lean_object *value = NULL;
    status = lbov_7fab4b2842f6c64d9621_vb2825946e038e653bd2b_in(&decoded, 0, 1, &transaction, &value);
    if (!status) status = lbov_7fab4b2842f6c64d9621_vb2825946e038e653bd2b_out(&converted, value, 0, &transaction);
  }
  if (!status) status = ov_commit(&transaction, owner);
  else if (transaction.scope.context) status = ov_abort(&transaction, status);
done:
  /* The store may have trapped, and output reads consume resource metadata.
   * Delete boxes only; frame teardown drains the complete native proxy ledger. */
  for (size_t i = 0; i < 2; ++i) wasmtime_component_val_delete(&args[i]);
  wasmtime_component_val_delete(&reply);
  ow_native_conversion_close(&output); ow_native_conversion_close(&input);
  status = ows_frame_end(&frame, status);
  if (status) (void)ov_owner_clear(owner); else *out = converted;
  return status;
}

static inline int ows_dispatch_14(ows_session *session,
    const lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b *a0, const lbov_7fab4b2842f6c64d9621_t5035e6ea0903f12776d9 *a1, lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b *out, ov_result_owner *owner) {
  ows_frame frame = {0}; int status = ows_frame_begin(session, &frame);
  if (status) return status;
  ow_native_conversion input, output;
  ow_native_conversion_init(&input, &frame.host); ow_native_conversion_init(&output, &frame.host);
  input.scope.identities.write = ows_write_input; output.scope.identities.read = ows_read_output;
  wasmtime_component_val_t args[2] = {{0}}, reply = {0};
  lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b decoded = {0}, converted = {0}; ov_transaction transaction = {0};
  if (!ow_encode_5_input(a0, &input.scope, &args[0])) {
    status = ows_conversion_status(&input, LB_OWNED_INVALID); goto done;
  }
  if (!ow_encode_3_input(a1, &input.scope, &args[1])) {
    status = ows_conversion_status(&input, LB_OWNED_INVALID); goto done;
  }
  status = ows_invoke(&frame, "with-claim-callback", args, 2, &reply);
  if (status) goto done;
  if (!ow_decode_5_output(&reply, &output.scope, &decoded)) {
    status = ows_conversion_status(&output, OV_RESULT); goto done;
  }
  status = ov_begin(&transaction, session->native, owner, "owned-checked-records@1.0.0");
  if (!status) {
    lean_object *value = NULL;
    status = lbov_7fab4b2842f6c64d9621_vb2825946e038e653bd2b_in(&decoded, 0, 1, &transaction, &value);
    if (!status) status = lbov_7fab4b2842f6c64d9621_vb2825946e038e653bd2b_out(&converted, value, 0, &transaction);
  }
  if (!status) status = ov_commit(&transaction, owner);
  else if (transaction.scope.context) status = ov_abort(&transaction, status);
done:
  /* The store may have trapped, and output reads consume resource metadata.
   * Delete boxes only; frame teardown drains the complete native proxy ledger. */
  for (size_t i = 0; i < 2; ++i) wasmtime_component_val_delete(&args[i]);
  wasmtime_component_val_delete(&reply);
  ow_native_conversion_close(&output); ow_native_conversion_close(&input);
  status = ows_frame_end(&frame, status);
  if (status) (void)ov_owner_clear(owner); else *out = converted;
  return status;
}

static inline int ows_dispatch_15(ows_session *session,
    const lbov_7fab4b2842f6c64d9621_t648974cffb2d6c1d7951 *a0, const lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b *a1, lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b *out, ov_result_owner *owner) {
  ows_frame frame = {0}; int status = ows_frame_begin(session, &frame);
  if (status) return status;
  ow_native_conversion input, output;
  ow_native_conversion_init(&input, &frame.host); ow_native_conversion_init(&output, &frame.host);
  input.scope.identities.write = ows_write_input; output.scope.identities.read = ows_read_output;
  wasmtime_component_val_t args[2] = {{0}}, reply = {0};
  lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b decoded = {0}, converted = {0}; ov_transaction transaction = {0};
  if (!ow_encode_2_input(a0, &input.scope, &args[0])) {
    status = ows_conversion_status(&input, LB_OWNED_INVALID); goto done;
  }
  if (!ow_encode_5_input(a1, &input.scope, &args[1])) {
    status = ows_conversion_status(&input, LB_OWNED_INVALID); goto done;
  }
  status = ows_invoke(&frame, "invoke-identity-callback26621c40b48fce52ca37", args, 2, &reply);
  if (status) goto done;
  if (!ow_decode_5_output(&reply, &output.scope, &decoded)) {
    status = ows_conversion_status(&output, OV_RESULT); goto done;
  }
  status = ov_begin(&transaction, session->native, owner, "owned-checked-records@1.0.0");
  if (!status) {
    lean_object *value = NULL;
    status = lbov_7fab4b2842f6c64d9621_vb2825946e038e653bd2b_in(&decoded, 0, 1, &transaction, &value);
    if (!status) status = lbov_7fab4b2842f6c64d9621_vb2825946e038e653bd2b_out(&converted, value, 0, &transaction);
  }
  if (!status) status = ov_commit(&transaction, owner);
  else if (transaction.scope.context) status = ov_abort(&transaction, status);
done:
  /* The store may have trapped, and output reads consume resource metadata.
   * Delete boxes only; frame teardown drains the complete native proxy ledger. */
  for (size_t i = 0; i < 2; ++i) wasmtime_component_val_delete(&args[i]);
  wasmtime_component_val_delete(&reply);
  ow_native_conversion_close(&output); ow_native_conversion_close(&input);
  status = ows_frame_end(&frame, status);
  if (status) (void)ov_owner_clear(owner); else *out = converted;
  return status;
}

static inline int ows_dispatch_16(ows_session *session,
    const lbov_7fab4b2842f6c64d9621_t5035e6ea0903f12776d9 *a0, const lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b *a1, lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b *out, ov_result_owner *owner) {
  ows_frame frame = {0}; int status = ows_frame_begin(session, &frame);
  if (status) return status;
  ow_native_conversion input, output;
  ow_native_conversion_init(&input, &frame.host); ow_native_conversion_init(&output, &frame.host);
  input.scope.identities.write = ows_write_input; output.scope.identities.read = ows_read_output;
  wasmtime_component_val_t args[2] = {{0}}, reply = {0};
  lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b decoded = {0}, converted = {0}; ov_transaction transaction = {0};
  if (!ow_encode_3_input(a0, &input.scope, &args[0])) {
    status = ows_conversion_status(&input, LB_OWNED_INVALID); goto done;
  }
  if (!ow_encode_5_input(a1, &input.scope, &args[1])) {
    status = ows_conversion_status(&input, LB_OWNED_INVALID); goto done;
  }
  status = ows_invoke(&frame, "invoke-identity-callbackb2d3d6fd4e031785f278", args, 2, &reply);
  if (status) goto done;
  if (!ow_decode_5_output(&reply, &output.scope, &decoded)) {
    status = ows_conversion_status(&output, OV_RESULT); goto done;
  }
  status = ov_begin(&transaction, session->native, owner, "owned-checked-records@1.0.0");
  if (!status) {
    lean_object *value = NULL;
    status = lbov_7fab4b2842f6c64d9621_vb2825946e038e653bd2b_in(&decoded, 0, 1, &transaction, &value);
    if (!status) status = lbov_7fab4b2842f6c64d9621_vb2825946e038e653bd2b_out(&converted, value, 0, &transaction);
  }
  if (!status) status = ov_commit(&transaction, owner);
  else if (transaction.scope.context) status = ov_abort(&transaction, status);
done:
  /* The store may have trapped, and output reads consume resource metadata.
   * Delete boxes only; frame teardown drains the complete native proxy ledger. */
  for (size_t i = 0; i < 2; ++i) wasmtime_component_val_delete(&args[i]);
  wasmtime_component_val_delete(&reply);
  ow_native_conversion_close(&output); ow_native_conversion_close(&input);
  status = ows_frame_end(&frame, status);
  if (status) (void)ov_owner_clear(owner); else *out = converted;
  return status;
}


_Static_assert(sizeof(bool) == 1, "owned C values require one-byte bool storage");
typedef struct oc_block {
  struct oc_block *next;
  int integer_initialized;
  mpz_t integer;
  max_align_t alignment;
  unsigned char data[];
} oc_block;
typedef struct { oc_block *head; ov_budget *budget; } oc_arena;
typedef struct oc_session oc_session;
typedef struct oc_result {
  struct oc_result *next;
  uint64_t key;
  oc_session *session;
  ov_result_owner native;
  oc_block *blocks;
} oc_result;
struct oc_session {
  oc_session *next;
  uint64_t key;
  lb_owned_context native;
  ows_session *transport;
  size_t results, calls;
  int closed;
};
static _Thread_local oc_session *oc_sessions;
static _Thread_local oc_result *oc_results;
extern lean_object *initialize_LeanBridgeOwned5d91995ea6e026c5(uint8_t);
static void *oc_initialize(uint8_t builtin) { return initialize_LeanBridgeOwned5d91995ea6e026c5(builtin); }

static inline void oc_release(oc_block *block) {
  while (block) {
    oc_block *next = block->next;
    if (block->integer_initialized) mpz_clear(block->integer);
    LB_OWNED_FREE(block); block = next;
  }
}
static inline int oc_block_new(oc_arena *arena, size_t count, size_t width, oc_block **out) {
  int status = ov_charge(arena->budget, count, width);
  if (!status) status = ov_charge(arena->budget, 1, sizeof(oc_block));
  if (status) return status;
  oc_block *block = LB_OWNED_ALLOC(sizeof(*block) + count * width);
  if (!block) return LB_OWNED_ALLOC_FAILED;
  memset(block, 0, sizeof(*block) + count * width);
  block->next = arena->head; arena->head = block; *out = block;
  return LB_OWNED_OK;
}
static inline int oc_allocate(oc_arena *arena, size_t count, size_t width, void **out) {
  *out = NULL; if (!count) return LB_OWNED_OK;
  oc_block *block; int status = oc_block_new(arena, count, width, &block);
  if (!status) *out = block->data;
  return status;
}
static inline int oc_integer(oc_arena *arena, const uint32_t *limbs, size_t length, int negative, mpz_srcptr *out) {
  int status = ov_span(arena->budget, limbs, length, sizeof(uint32_t), _Alignof(uint32_t));
  if (status) return status;
  size_t bits = length * 32, count = bits / GMP_NUMB_BITS + (bits % GMP_NUMB_BITS != 0);
  status = ov_charge(arena->budget, count, sizeof(mp_limb_t));
  if (status) return status;
  oc_block *block; status = oc_block_new(arena, 0, 1, &block);
  if (status) return status;
  mpz_init(block->integer); block->integer_initialized = 1;
  if (length) mpz_import(block->integer, length, -1, sizeof(uint32_t), 0, 0, limbs);
  if (negative) mpz_neg(block->integer, block->integer);
  *out = block->integer; return LB_OWNED_OK;
}
static inline oc_session *oc_session_find(const owned_checked_records_wasmtime_session *key) {
  for (oc_session *item = oc_sessions; item; item = item->next)
    if (item->key == (uint64_t)(uintptr_t)key) return item;
  return NULL;
}
static inline int oc_session_get(const owned_checked_records_wasmtime_session *key, oc_session **out) {
  if (!lean_bridge_native_process_valid()) return LB_OWNED_PROCESS;
  oc_session *session = oc_session_find(key);
  if (!session) return LB_OWNED_INVALID;
  if (session->closed) return LB_OWNED_CLOSED;
  int status = lb_owned_ready(&session->native);
  if (!status) *out = session;
  return status;
}
static inline void oc_session_collect(oc_session *session) {
  if (!session->closed || session->calls) return;
  if (session->transport) { ows_session_destroy(session->transport); session->transport = NULL; }
  if (session->native.initialized) (void)lb_owned_context_close(&session->native);
  if (session->results) return;
  oc_session **slot = &oc_sessions;
  while (*slot != session) slot = &(*slot)->next;
  *slot = session->next;
  (void)lean_bridge_native_identity_release(session->key, "owned-c-session:owned-checked-records@1.0.0", session);
  LB_OWNED_FREE(session);
}
owned_checked_records_wasmtime_status owned_checked_records_wasmtime_session_open(owned_checked_records_wasmtime_session **out) {
  if (getpid() != lb_package_pid) return (owned_checked_records_wasmtime_status)LB_OWNED_PROCESS;
  if (lb_package_failure()) return (owned_checked_records_wasmtime_status)LB_OWNED_RUNTIME;
  if (!ov_pointer(out, sizeof(*out), _Alignof(owned_checked_records_wasmtime_session *)) || *out) return (owned_checked_records_wasmtime_status)LB_OWNED_INVALID;
  if (!lean_bridge_native_process_valid()) return (owned_checked_records_wasmtime_status)LB_OWNED_PROCESS;
  if (!lean_bridge_native_component_initialize("owned-checked-records@1.0.0", oc_initialize)) return (owned_checked_records_wasmtime_status)LB_OWNED_RUNTIME;
  oc_session *session = LB_OWNED_ALLOC(sizeof(*session));
  if (!session) return (owned_checked_records_wasmtime_status)LB_OWNED_ALLOC_FAILED;
  memset(session, 0, sizeof(*session));
  int status = lb_owned_context_init(&session->native, "owned-checked-records@1.0.0");
  if (status) { LB_OWNED_FREE(session); return (owned_checked_records_wasmtime_status)status; }
  status = ows_session_open(&session->native, &session->transport);
  if (status) { lb_owned_context_close(&session->native); LB_OWNED_FREE(session); return (owned_checked_records_wasmtime_status)status; }
  session->key = lean_bridge_native_identity_acquire("owned-c-session:owned-checked-records@1.0.0", session);
  if (!session->key) { ows_session_destroy(session->transport); lb_owned_context_close(&session->native); LB_OWNED_FREE(session); return (owned_checked_records_wasmtime_status)LB_OWNED_LIMIT; }
  session->next = oc_sessions; oc_sessions = session;
  *out = (owned_checked_records_wasmtime_session *)(uintptr_t)session->key;
  return (owned_checked_records_wasmtime_status)LB_OWNED_OK;
}
owned_checked_records_wasmtime_status owned_checked_records_wasmtime_session_close(owned_checked_records_wasmtime_session **value) {
  if (getpid() != lb_package_pid) return (owned_checked_records_wasmtime_status)LB_OWNED_PROCESS;
  if (lb_package_failure()) return (owned_checked_records_wasmtime_status)LB_OWNED_RUNTIME;
  if (!ov_pointer(value, sizeof(*value), _Alignof(owned_checked_records_wasmtime_session *))) return (owned_checked_records_wasmtime_status)LB_OWNED_INVALID;
  if (!lean_bridge_native_process_valid()) return (owned_checked_records_wasmtime_status)LB_OWNED_PROCESS;
  if (!*value) return (owned_checked_records_wasmtime_status)LB_OWNED_OK;
  oc_session *session = oc_session_find(*value);
  if (!session) return (owned_checked_records_wasmtime_status)LB_OWNED_INVALID;
  if (session->closed) return (owned_checked_records_wasmtime_status)LB_OWNED_CLOSED;
  int status = lb_owned_affinity(&session->native);
  if (status) return (owned_checked_records_wasmtime_status)status;
  session->closed = 1; *value = NULL;
  ows_session_request_close(session->transport);
  oc_session_collect(session); return (owned_checked_records_wasmtime_status)LB_OWNED_OK;
}
owned_checked_records_wasmtime_status owned_checked_records_wasmtime_result_release(owned_checked_records_wasmtime_result **value) {
  if (getpid() != lb_package_pid) return (owned_checked_records_wasmtime_status)LB_OWNED_PROCESS;
  if (lb_package_failure()) return (owned_checked_records_wasmtime_status)LB_OWNED_RUNTIME;
  if (!ov_pointer(value, sizeof(*value), _Alignof(owned_checked_records_wasmtime_result *))) return (owned_checked_records_wasmtime_status)LB_OWNED_INVALID;
  if (!lean_bridge_native_process_valid()) return (owned_checked_records_wasmtime_status)LB_OWNED_PROCESS;
  if (!*value) return (owned_checked_records_wasmtime_status)LB_OWNED_OK;
  oc_result **slot = &oc_results;
  while (*slot && (*slot)->key != (uint64_t)(uintptr_t)*value) slot = &(*slot)->next;
  if (!*slot) return (owned_checked_records_wasmtime_status)LB_OWNED_INVALID;
  oc_result *result = *slot; oc_session *session = result->session;
  int status = ov_owner_clear(&result->native);
  if (!ov_owner_empty(&result->native)) return (owned_checked_records_wasmtime_status)status;
  *slot = result->next; --session->results;
  if (lean_bridge_native_identity_release(result->key, "owned-c-result:owned-checked-records@1.0.0", result) < 0 && !status) status = LB_OWNED_RUNTIME;
  oc_release(result->blocks); LB_OWNED_FREE(result); *value = NULL;
  oc_session_collect(session); return (owned_checked_records_wasmtime_status)status;
}
static inline int oc_result_begin(oc_session *session, ov_budget *budget, oc_result **out) {
  if (session->calls == LB_OWNED_SCOPE_LIMIT) return LB_OWNED_LIMIT;
  int status = ov_charge(budget, 1, sizeof(oc_result));
  if (status) return status;
  oc_result *result = LB_OWNED_ALLOC(sizeof(*result));
  if (!result) return LB_OWNED_ALLOC_FAILED;
  memset(result, 0, sizeof(*result)); result->session = session;
  ++session->calls; *out = result; return LB_OWNED_OK;
}
static inline int oc_result_finish(oc_result *result, oc_arena *output, int status, owned_checked_records_wasmtime_result **owner) {
  oc_session *session = result->session;
  if (status == OV_RESULT) lean_bridge_native_runtime_retire();
  if (!status && session->closed) status = LB_OWNED_CLOSED;
  if (!status) status = lb_owned_ready(&session->native);
  if (!status) {
    result->key = lean_bridge_native_identity_acquire("owned-c-result:owned-checked-records@1.0.0", result);
    if (!result->key) status = LB_OWNED_LIMIT;
  }
  if (!status) {
    result->blocks = output->head; output->head = NULL;
    result->next = oc_results; oc_results = result; ++session->results;
    *owner = (owned_checked_records_wasmtime_result *)(uintptr_t)result->key;
  } else {
    (void)ov_owner_clear(&result->native);
    oc_release(output->head); output->head = NULL; LB_OWNED_FREE(result);
  }
  --session->calls; oc_session_collect(session); return status;
}
static inline ov_budget oc_budget(void) {
  return (ov_budget){ .bytes = 16777216, .visits = 262144 };
}
static inline int oc_outputs(const void *out, size_t bytes, size_t alignment, const void *owner) {
  if (!ov_pointer(out, bytes, alignment) || !ov_pointer(owner, sizeof(void *), _Alignof(void *))) return 0;
  uintptr_t a = (uintptr_t)out, b = (uintptr_t)owner;
  return a < b ? bytes <= b - a : sizeof(void *) <= a - b;
}


typedef struct {
  owned_checked_records_wasmtime_result **slot;
  oc_result *result;
} oc_transfer_input;
typedef struct {
  oc_transfer_input *inputs;
  size_t count;
  int consumed;
} oc_transfer_frame;

static inline int oc_transfer_prepare(oc_session *session, oc_transfer_frame *frame,
    ov_result_owner **owners, void *out, size_t bytes, size_t alignment,
    owned_checked_records_wasmtime_result **output_owner) {
  for (size_t i = 0; i < frame->count; ++i) {
    owned_checked_records_wasmtime_result **slot = frame->inputs[i].slot;
    if (!oc_outputs(out, bytes, alignment, slot) ||
        !oc_outputs(slot, sizeof(*slot), _Alignof(owned_checked_records_wasmtime_result *), output_owner) ||
        !*slot) return LB_OWNED_INVALID;
    oc_result *result = oc_results;
    while (result && result->key != (uint64_t)(uintptr_t)*slot) result = result->next;
    if (!result || result->session != session) return LB_OWNED_INVALID;
    for (size_t j = 0; j < i; ++j)
      if (frame->inputs[j].result == result) return LB_OWNED_INVALID;
    frame->inputs[i].result = result;
    owners[i] = &result->native;
  }
  return LB_OWNED_OK;
}

/* Native conversion has validated every value and moved every input batch.
   This hook cannot allocate, call user code, or fail partway through the set. */
static inline void oc_transfer_consume(void *context) {
  oc_transfer_frame *frame = context;
  for (size_t i = 0; i < frame->count; ++i) {
    oc_result *result = frame->inputs[i].result;
    oc_result **position = &oc_results;
    while (*position != result) position = &(*position)->next;
    *position = result->next;
    --result->session->results;
    *frame->inputs[i].slot = NULL;
  }
  frame->consumed = 1;
}

static inline int oc_transfer_finish(oc_transfer_frame *frame, int status) {
  if (!frame->consumed) return status;
  for (size_t i = 0; i < frame->count; ++i) {
    oc_result *result = frame->inputs[i].result;
    int cleanup = ov_owner_clear(&result->native);
    if (!status) status = cleanup;
    if (lean_bridge_native_identity_release(result->key, "owned-c-result:owned-checked-records@1.0.0", result) < 0 && !status)
      status = LB_OWNED_RUNTIME;
    oc_release(result->blocks); LB_OWNED_FREE(result);
  }
  return status;
}

static inline int oc_v0_to(owned_checked_records_wasmtime_value_f790309465bbf573c7b9_t const *, lbov_7fab4b2842f6c64d9621_tf790309465bbf573c7b9 *, size_t, oc_arena *);
static inline int oc_v0_from(const lbov_7fab4b2842f6c64d9621_tf790309465bbf573c7b9 *, owned_checked_records_wasmtime_value_f790309465bbf573c7b9_t *, size_t, oc_arena *);
static inline int oc_v1_to(owned_checked_records_wasmtime_value_160ce821a84f6887bbfd_t const *, lbov_7fab4b2842f6c64d9621_t160ce821a84f6887bbfd *, size_t, oc_arena *);
static inline int oc_v1_from(const lbov_7fab4b2842f6c64d9621_t160ce821a84f6887bbfd *, owned_checked_records_wasmtime_value_160ce821a84f6887bbfd_t *, size_t, oc_arena *);
static inline int oc_v2_to(owned_checked_records_wasmtime_claim_closure_result_t const *, lbov_7fab4b2842f6c64d9621_t648974cffb2d6c1d7951 *, size_t, oc_arena *);
static inline int oc_v2_from(const lbov_7fab4b2842f6c64d9621_t648974cffb2d6c1d7951 *, owned_checked_records_wasmtime_claim_closure_result_t *, size_t, oc_arena *);
static inline int oc_v3_to(owned_checked_records_wasmtime_transfer_with_claim_callback_argument1_t const *, lbov_7fab4b2842f6c64d9621_t5035e6ea0903f12776d9 *, size_t, oc_arena *);
static inline int oc_v3_from(const lbov_7fab4b2842f6c64d9621_t5035e6ea0903f12776d9 *, owned_checked_records_wasmtime_transfer_with_claim_callback_argument1_t *, size_t, oc_arena *);
static inline int oc_v4_to(owned_checked_records_wasmtime_booking_t const *, lbov_7fab4b2842f6c64d9621_t23107461f72b24c37654 *, size_t, oc_arena *);
static inline int oc_v4_from(const lbov_7fab4b2842f6c64d9621_t23107461f72b24c37654 *, owned_checked_records_wasmtime_booking_t *, size_t, oc_arena *);
static inline int oc_v5_to(owned_checked_records_wasmtime_claim_t const *, lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b *, size_t, oc_arena *);
static inline int oc_v5_from(const lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b *, owned_checked_records_wasmtime_claim_t *, size_t, oc_arena *);
static inline int oc_v6_to(owned_checked_records_wasmtime_grant_t const *, lbov_7fab4b2842f6c64d9621_t4ce841c87ea3b1559bfb *, size_t, oc_arena *);
static inline int oc_v6_from(const lbov_7fab4b2842f6c64d9621_t4ce841c87ea3b1559bfb *, owned_checked_records_wasmtime_grant_t *, size_t, oc_arena *);
static inline int oc_v7_to(owned_checked_records_wasmtime_ticket_t const *, lbov_7fab4b2842f6c64d9621_td79b9bbde250ee1779da *, size_t, oc_arena *);
static inline int oc_v7_from(const lbov_7fab4b2842f6c64d9621_td79b9bbde250ee1779da *, owned_checked_records_wasmtime_ticket_t *, size_t, oc_arena *);
static inline int oc_v8_to(owned_checked_records_wasmtime_window_t const *, lbov_7fab4b2842f6c64d9621_t2a091437b2d587ce3891 *, size_t, oc_arena *);
static inline int oc_v8_from(const lbov_7fab4b2842f6c64d9621_t2a091437b2d587ce3891 *, owned_checked_records_wasmtime_window_t *, size_t, oc_arena *);
static inline int oc_v9_to(mpz_srcptr const *, lbov_7fab4b2842f6c64d9621_t167081552b6f9c1d1afd *, size_t, oc_arena *);
static inline int oc_v9_from(const lbov_7fab4b2842f6c64d9621_t167081552b6f9c1d1afd *, mpz_srcptr *, size_t, oc_arena *);
static inline int oc_v10_to(owned_checked_records_wasmtime_scalar_string_t const *, lbov_7fab4b2842f6c64d9621_tdc0347e1f7f5c4d928f1 *, size_t, oc_arena *);
static inline int oc_v10_from(const lbov_7fab4b2842f6c64d9621_tdc0347e1f7f5c4d928f1 *, owned_checked_records_wasmtime_scalar_string_t *, size_t, oc_arena *);
static inline int oc_v0_to(owned_checked_records_wasmtime_value_f790309465bbf573c7b9_t const *value, lbov_7fab4b2842f6c64d9621_tf790309465bbf573c7b9 *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(owned_checked_records_wasmtime_value_f790309465bbf573c7b9_t))) return LB_OWNED_INVALID;
  int status = ov_enter(arena->budget, value, 0, depth);
  if (status) return status;
  (void)out;
  if (value->length > arena->budget->visits) return LB_OWNED_LIMIT;
  status = ov_span(arena->budget, value->data, value->length, sizeof(owned_checked_records_wasmtime_claim_t), _Alignof(owned_checked_records_wasmtime_claim_t));
  if (status) return status;
  void *data = NULL;
  status = oc_allocate(arena, value->length, sizeof(lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b), &data);
  if (status) return status;
  lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b *items = data; out->data = data; out->length = value->length;
  for (size_t i = 0; i < value->length; ++i) {
    status = oc_v5_to(value->data + i, items + i, depth + 1, arena);
    if (status) return status;
  }
  return LB_OWNED_OK;
}
static inline int oc_v0_from(const lbov_7fab4b2842f6c64d9621_tf790309465bbf573c7b9 *value, owned_checked_records_wasmtime_value_f790309465bbf573c7b9_t *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_7fab4b2842f6c64d9621_tf790309465bbf573c7b9))) return OV_RESULT;
  int status = ov_enter(arena->budget, value, 0, depth);
  if (status) return status;
  (void)out;
  if (value->length > arena->budget->visits) return LB_OWNED_LIMIT;
  status = ov_span(arena->budget, value->data, value->length, sizeof(lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b), _Alignof(lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b));
  if (status) return status;
  void *data = NULL;
  status = oc_allocate(arena, value->length, sizeof(owned_checked_records_wasmtime_claim_t), &data);
  if (status) return status;
  owned_checked_records_wasmtime_claim_t *items = data; out->data = data; out->length = value->length;
  for (size_t i = 0; i < value->length; ++i) {
    status = oc_v5_from(value->data + i, items + i, depth + 1, arena);
    if (status) return status;
  }
  return LB_OWNED_OK;
}
static inline int oc_v1_to(owned_checked_records_wasmtime_value_160ce821a84f6887bbfd_t const *value, lbov_7fab4b2842f6c64d9621_t160ce821a84f6887bbfd *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(owned_checked_records_wasmtime_value_160ce821a84f6887bbfd_t))) return LB_OWNED_INVALID;
  int status = ov_enter(arena->budget, value, 1, depth);
  if (status) return status;
  (void)out;
  uint8_t selected; memcpy(&selected, &value->has_value, 1);
  if (selected > 1) return LB_OWNED_INVALID;
  out->tag = selected;
  if (out->tag == 1) {
  {
    void *data = NULL;
    status = oc_allocate(arena, 1, sizeof(lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b), &data);
    if (status) return status;
    out->f0 = data;
    status = oc_v5_to(value->value, data, depth + 1, arena);
    if (status) return status;
  }
  }
  return LB_OWNED_OK;
}
static inline int oc_v1_from(const lbov_7fab4b2842f6c64d9621_t160ce821a84f6887bbfd *value, owned_checked_records_wasmtime_value_160ce821a84f6887bbfd_t *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_7fab4b2842f6c64d9621_t160ce821a84f6887bbfd))) return OV_RESULT;
  int status = ov_enter(arena->budget, value, 1, depth);
  if (status) return status;
  (void)out;
  if (value->tag > 1) return OV_RESULT;
  out->has_value = value->tag != 0;
  if (value->tag == 1) {
  {
    void *data = NULL;
    status = oc_allocate(arena, 1, sizeof(owned_checked_records_wasmtime_claim_t), &data);
    if (status) return status;
    out->value = data;
    status = oc_v5_from(value->f0, data, depth + 1, arena);
    if (status) return status;
  }
  }
  return LB_OWNED_OK;
}
static inline int oc_v2_to(owned_checked_records_wasmtime_claim_closure_result_t const *value, lbov_7fab4b2842f6c64d9621_t648974cffb2d6c1d7951 *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(owned_checked_records_wasmtime_claim_closure_result_t))) return LB_OWNED_INVALID;
  int status = ov_enter(arena->budget, value, 2, depth);
  if (status) return status;
  (void)out;
  if (!*value) return LB_OWNED_INVALID;
  out->token = (uint64_t)(uintptr_t)*value;
  return LB_OWNED_OK;
}
static inline int oc_v2_from(const lbov_7fab4b2842f6c64d9621_t648974cffb2d6c1d7951 *value, owned_checked_records_wasmtime_claim_closure_result_t *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_7fab4b2842f6c64d9621_t648974cffb2d6c1d7951))) return OV_RESULT;
  int status = ov_enter(arena->budget, value, 2, depth);
  if (status) return status;
  (void)out;
  if (!value->token) return OV_RESULT;
  *out = (owned_checked_records_wasmtime_claim_closure_result_t)(uintptr_t)value->token;
  return LB_OWNED_OK;
}
static inline int oc_v3_to(owned_checked_records_wasmtime_transfer_with_claim_callback_argument1_t const *value, lbov_7fab4b2842f6c64d9621_t5035e6ea0903f12776d9 *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(owned_checked_records_wasmtime_transfer_with_claim_callback_argument1_t))) return LB_OWNED_INVALID;
  int status = ov_enter(arena->budget, value, 3, depth);
  if (status) return status;
  (void)out;
  if (!*value) return LB_OWNED_INVALID;
  out->token = (uint64_t)(uintptr_t)*value;
  return LB_OWNED_OK;
}
static inline int oc_v3_from(const lbov_7fab4b2842f6c64d9621_t5035e6ea0903f12776d9 *value, owned_checked_records_wasmtime_transfer_with_claim_callback_argument1_t *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_7fab4b2842f6c64d9621_t5035e6ea0903f12776d9))) return OV_RESULT;
  int status = ov_enter(arena->budget, value, 3, depth);
  if (status) return status;
  (void)out;
  if (!value->token) return OV_RESULT;
  *out = (owned_checked_records_wasmtime_transfer_with_claim_callback_argument1_t)(uintptr_t)value->token;
  return LB_OWNED_OK;
}
static inline int oc_v4_to(owned_checked_records_wasmtime_booking_t const *value, lbov_7fab4b2842f6c64d9621_t23107461f72b24c37654 *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(owned_checked_records_wasmtime_booking_t))) return LB_OWNED_INVALID;
  int status = ov_enter(arena->budget, value, 4, depth);
  if (status) return status;
  (void)out;
  {
    status = oc_v7_to(&value->holder, &out->f0, depth + 1, arena);
    if (status) return status;
  }
  {
    void *data = NULL;
    status = oc_allocate(arena, 1, sizeof(lbov_7fab4b2842f6c64d9621_t2a091437b2d587ce3891), &data);
    if (status) return status;
    out->f1 = data;
    status = oc_v8_to(value->window, data, depth + 1, arena);
    if (status) return status;
  }
  return LB_OWNED_OK;
}
static inline int oc_v4_from(const lbov_7fab4b2842f6c64d9621_t23107461f72b24c37654 *value, owned_checked_records_wasmtime_booking_t *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_7fab4b2842f6c64d9621_t23107461f72b24c37654))) return OV_RESULT;
  int status = ov_enter(arena->budget, value, 4, depth);
  if (status) return status;
  (void)out;
  {
    status = oc_v7_from(&value->f0, &out->holder, depth + 1, arena);
    if (status) return status;
  }
  {
    void *data = NULL;
    status = oc_allocate(arena, 1, sizeof(owned_checked_records_wasmtime_window_t), &data);
    if (status) return status;
    out->window = data;
    status = oc_v8_from(value->f1, data, depth + 1, arena);
    if (status) return status;
  }
  return LB_OWNED_OK;
}
static inline int oc_v5_to(owned_checked_records_wasmtime_claim_t const *value, lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(owned_checked_records_wasmtime_claim_t))) return LB_OWNED_INVALID;
  int status = ov_enter(arena->budget, value, 5, depth);
  if (status) return status;
  (void)out;
  {
    status = oc_v7_to(&value->holder, &out->f0, depth + 1, arena);
    if (status) return status;
  }
  {
    status = oc_v9_to(&value->quota, &out->f1, depth + 1, arena);
    if (status) return status;
  }
  return LB_OWNED_OK;
}
static inline int oc_v5_from(const lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b *value, owned_checked_records_wasmtime_claim_t *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b))) return OV_RESULT;
  int status = ov_enter(arena->budget, value, 5, depth);
  if (status) return status;
  (void)out;
  {
    status = oc_v7_from(&value->f0, &out->holder, depth + 1, arena);
    if (status) return status;
  }
  {
    status = oc_v9_from(&value->f1, &out->quota, depth + 1, arena);
    if (status) return status;
  }
  return LB_OWNED_OK;
}
static inline int oc_v6_to(owned_checked_records_wasmtime_grant_t const *value, lbov_7fab4b2842f6c64d9621_t4ce841c87ea3b1559bfb *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(owned_checked_records_wasmtime_grant_t))) return LB_OWNED_INVALID;
  int status = ov_enter(arena->budget, value, 6, depth);
  if (status) return status;
  (void)out;
  {
    status = oc_v7_to(&value->holder, &out->f0, depth + 1, arena);
    if (status) return status;
  }
  {
    status = oc_v9_to(&value->weight, &out->f1, depth + 1, arena);
    if (status) return status;
  }
  {
    status = oc_v9_to(&value->limit, &out->f2, depth + 1, arena);
    if (status) return status;
  }
  return LB_OWNED_OK;
}
static inline int oc_v6_from(const lbov_7fab4b2842f6c64d9621_t4ce841c87ea3b1559bfb *value, owned_checked_records_wasmtime_grant_t *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_7fab4b2842f6c64d9621_t4ce841c87ea3b1559bfb))) return OV_RESULT;
  int status = ov_enter(arena->budget, value, 6, depth);
  if (status) return status;
  (void)out;
  {
    status = oc_v7_from(&value->f0, &out->holder, depth + 1, arena);
    if (status) return status;
  }
  {
    status = oc_v9_from(&value->f1, &out->weight, depth + 1, arena);
    if (status) return status;
  }
  {
    status = oc_v9_from(&value->f2, &out->limit, depth + 1, arena);
    if (status) return status;
  }
  return LB_OWNED_OK;
}
static inline int oc_v7_to(owned_checked_records_wasmtime_ticket_t const *value, lbov_7fab4b2842f6c64d9621_td79b9bbde250ee1779da *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(owned_checked_records_wasmtime_ticket_t))) return LB_OWNED_INVALID;
  int status = ov_enter(arena->budget, value, 7, depth);
  if (status) return status;
  (void)out;
  if (!*value) return LB_OWNED_INVALID;
  out->token = (uint64_t)(uintptr_t)*value;
  return LB_OWNED_OK;
}
static inline int oc_v7_from(const lbov_7fab4b2842f6c64d9621_td79b9bbde250ee1779da *value, owned_checked_records_wasmtime_ticket_t *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_7fab4b2842f6c64d9621_td79b9bbde250ee1779da))) return OV_RESULT;
  int status = ov_enter(arena->budget, value, 7, depth);
  if (status) return status;
  (void)out;
  if (!value->token) return OV_RESULT;
  *out = (owned_checked_records_wasmtime_ticket_t)(uintptr_t)value->token;
  return LB_OWNED_OK;
}
static inline int oc_v8_to(owned_checked_records_wasmtime_window_t const *value, lbov_7fab4b2842f6c64d9621_t2a091437b2d587ce3891 *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(owned_checked_records_wasmtime_window_t))) return LB_OWNED_INVALID;
  int status = ov_enter(arena->budget, value, 8, depth);
  if (status) return status;
  (void)out;
  {
    status = oc_v9_to(&value->lo, &out->f0, depth + 1, arena);
    if (status) return status;
  }
  {
    status = oc_v9_to(&value->hi, &out->f1, depth + 1, arena);
    if (status) return status;
  }
  return LB_OWNED_OK;
}
static inline int oc_v8_from(const lbov_7fab4b2842f6c64d9621_t2a091437b2d587ce3891 *value, owned_checked_records_wasmtime_window_t *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_7fab4b2842f6c64d9621_t2a091437b2d587ce3891))) return OV_RESULT;
  int status = ov_enter(arena->budget, value, 8, depth);
  if (status) return status;
  (void)out;
  {
    status = oc_v9_from(&value->f0, &out->lo, depth + 1, arena);
    if (status) return status;
  }
  {
    status = oc_v9_from(&value->f1, &out->hi, depth + 1, arena);
    if (status) return status;
  }
  return LB_OWNED_OK;
}
static inline int oc_v9_to(mpz_srcptr const *value, lbov_7fab4b2842f6c64d9621_t167081552b6f9c1d1afd *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(mpz_srcptr))) return LB_OWNED_INVALID;
  int status = ov_enter(arena->budget, value, 9, depth);
  if (status) return status;
  (void)out;
  if (!ov_pointer(*value, sizeof(**value), _Alignof(__mpz_struct))) return LB_OWNED_INVALID;
  if (mpz_sgn(*value) < 0) return LB_OWNED_INVALID;
  if (mpz_size(*value) > arena->budget->bytes / sizeof(mp_limb_t) + 1) return LB_OWNED_LIMIT;
  size_t length = mpz_sgn(*value) ? (mpz_sizeinbase(*value, 2) - 1) / 32 + 1 : 0;
  void *data = NULL; status = oc_allocate(arena, length, sizeof(uint32_t), &data);
  if (status) return status;
  if (length) mpz_export(data, &length, -1, sizeof(uint32_t), 0, 0, *value);
  out->data = data; out->length = length;
  return LB_OWNED_OK;
}
static inline int oc_v9_from(const lbov_7fab4b2842f6c64d9621_t167081552b6f9c1d1afd *value, mpz_srcptr *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_7fab4b2842f6c64d9621_t167081552b6f9c1d1afd))) return OV_RESULT;
  int status = ov_enter(arena->budget, value, 9, depth);
  if (status) return status;
  (void)out;
  return oc_integer(arena, value->data, value->length, 0, out);
  return LB_OWNED_OK;
}
static inline int oc_v10_to(owned_checked_records_wasmtime_scalar_string_t const *value, lbov_7fab4b2842f6c64d9621_tdc0347e1f7f5c4d928f1 *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(owned_checked_records_wasmtime_scalar_string_t))) return LB_OWNED_INVALID;
  int status = ov_enter(arena->budget, value, 10, depth);
  if (status) return status;
  (void)out;
  status = ov_span(arena->budget, value->data, value->length, 1, 1);
  if (status) return status;
  if (!ov_utf8((const uint8_t *)value->data, value->length)) return LB_OWNED_INVALID;
  out->data = value->data; out->length = value->length;
  return LB_OWNED_OK;
}
static inline int oc_v10_from(const lbov_7fab4b2842f6c64d9621_tdc0347e1f7f5c4d928f1 *value, owned_checked_records_wasmtime_scalar_string_t *out, size_t depth, oc_arena *arena) {
  if (!ov_pointer(value, sizeof(*value), _Alignof(lbov_7fab4b2842f6c64d9621_tdc0347e1f7f5c4d928f1))) return OV_RESULT;
  int status = ov_enter(arena->budget, value, 10, depth);
  if (status) return status;
  (void)out;
  status = ov_span(arena->budget, value->data, value->length, 1, 1);
  if (status) return status;
  if (!ov_utf8((const uint8_t *)value->data, value->length)) return OV_RESULT;
  out->data = value->data; out->length = value->length;
  return LB_OWNED_OK;
}
typedef struct oc_host_v2 {
  owned_checked_records_wasmtime_claim_closure_result_t_host descriptor;
  oc_session *session;
  ov_budget *budget;
  uint64_t token;
  ov_result_owner owner;
} oc_host_v2;
static lean_object *oc_host_v2_invoke(void *context, lean_object *a0) {
  oc_host_v2 *borrow = context; ov_callback_frame *frame = ov_active_callback_frame;
  int status = !frame || frame->transaction->scope.context != &borrow->session->native ? OV_CALLBACK : frame->status;
  ov_transaction arguments = {0}; ov_result_owner argument_owner = {0};
  oc_arena views = { .budget = borrow->budget }, reply_input = { .budget = borrow->budget };
  owned_checked_records_wasmtime_result *reply_owner = NULL; lean_object *returned = NULL;
  lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b raw0 = {0};
  owned_checked_records_wasmtime_claim_t view0 = {0};
  owned_checked_records_wasmtime_claim_t reply = {0}; lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b raw_reply = {0};
  if (!status) status = ov_begin(&arguments, &borrow->session->native, &argument_owner, "owned-checked-records@1.0.0");
  if (!status) arguments.budget = frame->transaction->budget;
  if (!status) { status = lbov_7fab4b2842f6c64d9621_vb2825946e038e653bd2b_out(&raw0, a0, 0, &arguments); a0 = NULL; }
  if (arguments.scope.context) frame->transaction->budget = arguments.budget;
  if (!status) status = ov_commit(&arguments, &argument_owner);
  else if (arguments.scope.context) status = ov_abort(&arguments, status);
  if (!status) status = oc_v5_from(&raw0, &view0, 0, &views);
  if (!status) {
    owned_checked_records_wasmtime_status host_status = borrow->descriptor.call(borrow->descriptor.context, (owned_checked_records_wasmtime_session *)(uintptr_t)borrow->session->key, &view0, &reply, &reply_owner);
    if (host_status) status = OV_CALLBACK;
    if (!status) status = lb_owned_scope_ready(&frame->transaction->scope);
  }
  if (!status) status = oc_v5_to(&reply, &raw_reply, 0, &reply_input);
  if (!status) status = lbov_7fab4b2842f6c64d9621_vb2825946e038e653bd2b_in(&raw_reply, 0, 1, frame->transaction, &returned);
  int cleanup = owned_checked_records_wasmtime_result_release(&reply_owner); if (!status) status = cleanup;
  cleanup = ov_owner_clear(&argument_owner); if (!status) status = cleanup;
  oc_release(reply_input.head); oc_release(views.head);
  if (a0) lean_dec(a0);
  if (status) { ov_callback_fail(frame, status); if (returned) lean_dec(returned); return lean_alloc_array(0, 0); }
  return returned;
}
static inline int oc_host_v2_end(oc_host_v2 *borrow) {
  int status = LB_OWNED_OK;
  if (borrow->token) {
    if (lb_native_callback_wrong_thread(borrow->token)) status = LB_OWNED_THREAD;
    lb_native_callback_release(borrow->token); borrow->token = 0;
  }
  int cleanup = ov_owner_clear(&borrow->owner); return status ? status : cleanup;
}
static inline int oc_host_v2_begin(oc_host_v2 *borrow, const owned_checked_records_wasmtime_claim_closure_result_t_host *input, oc_session *session, ov_budget *budget, lbov_7fab4b2842f6c64d9621_t648974cffb2d6c1d7951 *out) {
  if (!ov_pointer(input, sizeof(*input), _Alignof(owned_checked_records_wasmtime_claim_closure_result_t_host))) return LB_OWNED_INVALID;
  borrow->descriptor = *input; borrow->session = session; borrow->budget = budget;
  if ((!input->call) == (!input->closure)) return LB_OWNED_INVALID;
  if (input->closure) {
    if (input->context || input->recovery) return LB_OWNED_INVALID;
    oc_arena arena = { .budget = budget };
    return oc_v2_to(&input->closure, out, 0, &arena);
  }
  borrow->token = lb_native_callback_register((void (*)(void))oc_host_v2_invoke, borrow);
  if (!borrow->token) return LB_OWNED_LIMIT;
  ov_transaction transaction = {0}; oc_arena arena = { .budget = budget };
  int status = ov_begin(&transaction, &session->native, &borrow->owner, "owned-checked-records@1.0.0");
  lean_object *recovery = NULL;
  if (!status && input->recovery) {
    lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b raw = {0}; status = oc_v5_to(input->recovery, &raw, 0, &arena);
    if (!status) status = lbov_7fab4b2842f6c64d9621_vb2825946e038e653bd2b_in(&raw, 0, 1, &transaction, &recovery);
  }
  if (!status) {
    if (!recovery) recovery = lean_alloc_array(0, 0);
    lean_object *closure = lean_bridge_owned_0d662a6486ef7827f9e97a02_t648974cffb2d6c1d7951_wrap((size_t)borrow->token, input->recovery ? 1 : 0, recovery);
    if (!ov_carrier(closure)) { lean_dec(closure); status = LB_OWNED_INVALID; }
    else status = lbov_7fab4b2842f6c64d9621_v648974cffb2d6c1d7951_out(out, closure, 0, &transaction);
  }
  oc_release(arena.head);
  if (!status) status = ov_commit(&transaction, &borrow->owner);
  else if (transaction.scope.context) status = ov_abort(&transaction, status);
  if (status) (void)oc_host_v2_end(borrow);
  return status;
}
typedef struct oc_host_v3 {
  owned_checked_records_wasmtime_transfer_with_claim_callback_argument1_t_host descriptor;
  oc_session *session;
  ov_budget *budget;
  uint64_t token;
  ov_result_owner owner;
} oc_host_v3;
static lean_object *oc_host_v3_invoke(void *context, lean_object *a0) {
  oc_host_v3 *borrow = context; ov_callback_frame *frame = ov_active_callback_frame;
  int status = !frame || frame->transaction->scope.context != &borrow->session->native ? OV_CALLBACK : frame->status;
  ov_transaction arguments = {0}; ov_result_owner argument_owner = {0};
  oc_arena views = { .budget = borrow->budget }, reply_input = { .budget = borrow->budget };
  owned_checked_records_wasmtime_result *reply_owner = NULL; lean_object *returned = NULL;
  lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b raw0 = {0};
  owned_checked_records_wasmtime_claim_t view0 = {0};
  owned_checked_records_wasmtime_claim_t reply = {0}; lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b raw_reply = {0};
  if (!status) status = ov_begin(&arguments, &borrow->session->native, &argument_owner, "owned-checked-records@1.0.0");
  if (!status) arguments.budget = frame->transaction->budget;
  if (!status) { status = lbov_7fab4b2842f6c64d9621_vb2825946e038e653bd2b_out(&raw0, a0, 0, &arguments); a0 = NULL; }
  if (arguments.scope.context) frame->transaction->budget = arguments.budget;
  if (!status) status = ov_commit(&arguments, &argument_owner);
  else if (arguments.scope.context) status = ov_abort(&arguments, status);
  if (!status) status = oc_v5_from(&raw0, &view0, 0, &views);
  if (!status) {
    owned_checked_records_wasmtime_status host_status = borrow->descriptor.call(borrow->descriptor.context, (owned_checked_records_wasmtime_session *)(uintptr_t)borrow->session->key, &view0, &reply, &reply_owner);
    if (host_status) status = OV_CALLBACK;
    if (!status) status = lb_owned_scope_ready(&frame->transaction->scope);
  }
  if (!status) status = oc_v5_to(&reply, &raw_reply, 0, &reply_input);
  if (!status) status = lbov_7fab4b2842f6c64d9621_vb2825946e038e653bd2b_in(&raw_reply, 0, 1, frame->transaction, &returned);
  if (!status) { lean_inc(returned); if (!lean_bridge_owned_refine_ca177b2570793a278657(returned)) { lean_dec(returned); returned = NULL; status = LB_OWNED_INVALID; } }
  int cleanup = owned_checked_records_wasmtime_result_release(&reply_owner); if (!status) status = cleanup;
  cleanup = ov_owner_clear(&argument_owner); if (!status) status = cleanup;
  oc_release(reply_input.head); oc_release(views.head);
  if (a0) lean_dec(a0);
  if (status) { ov_callback_fail(frame, status); if (returned) lean_dec(returned); return lean_alloc_array(0, 0); }
  return returned;
}
static inline int oc_host_v3_end(oc_host_v3 *borrow) {
  int status = LB_OWNED_OK;
  if (borrow->token) {
    if (lb_native_callback_wrong_thread(borrow->token)) status = LB_OWNED_THREAD;
    lb_native_callback_release(borrow->token); borrow->token = 0;
  }
  int cleanup = ov_owner_clear(&borrow->owner); return status ? status : cleanup;
}
static inline int oc_host_v3_begin(oc_host_v3 *borrow, const owned_checked_records_wasmtime_transfer_with_claim_callback_argument1_t_host *input, oc_session *session, ov_budget *budget, lbov_7fab4b2842f6c64d9621_t5035e6ea0903f12776d9 *out) {
  if (!ov_pointer(input, sizeof(*input), _Alignof(owned_checked_records_wasmtime_transfer_with_claim_callback_argument1_t_host))) return LB_OWNED_INVALID;
  borrow->descriptor = *input; borrow->session = session; borrow->budget = budget;
  if ((!input->call) == (!input->closure)) return LB_OWNED_INVALID;
  if (input->closure) {
    if (input->context || input->recovery) return LB_OWNED_INVALID;
    oc_arena arena = { .budget = budget };
    return oc_v3_to(&input->closure, out, 0, &arena);
  }
  borrow->token = lb_native_callback_register((void (*)(void))oc_host_v3_invoke, borrow);
  if (!borrow->token) return LB_OWNED_LIMIT;
  ov_transaction transaction = {0}; oc_arena arena = { .budget = budget };
  int status = ov_begin(&transaction, &session->native, &borrow->owner, "owned-checked-records@1.0.0");
  lean_object *recovery = NULL;
  if (!status && input->recovery) {
    lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b raw = {0}; status = oc_v5_to(input->recovery, &raw, 0, &arena);
    if (!status) status = lbov_7fab4b2842f6c64d9621_vb2825946e038e653bd2b_in(&raw, 0, 1, &transaction, &recovery);
    if (!status) { lean_inc(recovery); if (!lean_bridge_owned_refine_ca177b2570793a278657(recovery)) { lean_dec(recovery); recovery = NULL; status = LB_OWNED_INVALID; } }
  }
  if (!status) {
    if (!recovery) recovery = lean_alloc_array(0, 0);
    lean_object *closure = lean_bridge_owned_0d662a6486ef7827f9e97a02_t5035e6ea0903f12776d9_wrap((size_t)borrow->token, input->recovery ? 1 : 0, recovery);
    if (!ov_carrier(closure)) { lean_dec(closure); status = LB_OWNED_INVALID; }
    else status = lbov_7fab4b2842f6c64d9621_v5035e6ea0903f12776d9_out(out, closure, 0, &transaction);
  }
  oc_release(arena.head);
  if (!status) status = ov_commit(&transaction, &borrow->owner);
  else if (transaction.scope.context) status = ov_abort(&transaction, status);
  if (status) (void)oc_host_v3_end(borrow);
  return status;
}

static inline int lbov_7fab4b2842f6c64d9621_v648974cffb2d6c1d7951_retain(lb_owned_context *context, const lbov_7fab4b2842f6c64d9621_t648974cffb2d6c1d7951 *input, lbov_7fab4b2842f6c64d9621_t648974cffb2d6c1d7951 *out, ov_result_owner *owner) {
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  lean_object *value = NULL;
  status = lbov_7fab4b2842f6c64d9621_v648974cffb2d6c1d7951_in(input, 0, 1, &transaction, &value);
  if (status) return ov_abort(&transaction, status);
  status = lbov_7fab4b2842f6c64d9621_v648974cffb2d6c1d7951_out(out, value, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  return ov_commit(&transaction, owner);
}
static inline int lbov_7fab4b2842f6c64d9621_v5035e6ea0903f12776d9_retain(lb_owned_context *context, const lbov_7fab4b2842f6c64d9621_t5035e6ea0903f12776d9 *input, lbov_7fab4b2842f6c64d9621_t5035e6ea0903f12776d9 *out, ov_result_owner *owner) {
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  lean_object *value = NULL;
  status = lbov_7fab4b2842f6c64d9621_v5035e6ea0903f12776d9_in(input, 0, 1, &transaction, &value);
  if (status) return ov_abort(&transaction, status);
  status = lbov_7fab4b2842f6c64d9621_v5035e6ea0903f12776d9_out(out, value, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  return ov_commit(&transaction, owner);
}
static inline int lbov_7fab4b2842f6c64d9621_vd79b9bbde250ee1779da_retain(lb_owned_context *context, const lbov_7fab4b2842f6c64d9621_td79b9bbde250ee1779da *input, lbov_7fab4b2842f6c64d9621_td79b9bbde250ee1779da *out, ov_result_owner *owner) {
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  lean_object *value = NULL;
  status = lbov_7fab4b2842f6c64d9621_vd79b9bbde250ee1779da_in(input, 0, 1, &transaction, &value);
  if (status) return ov_abort(&transaction, status);
  status = lbov_7fab4b2842f6c64d9621_vd79b9bbde250ee1779da_out(out, value, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  return ov_commit(&transaction, owner);
}
static inline int lbov_7fab4b2842f6c64d9621_vf790309465bbf573c7b9_retain(lb_owned_context *context, const lbov_7fab4b2842f6c64d9621_tf790309465bbf573c7b9 *input, lbov_7fab4b2842f6c64d9621_tf790309465bbf573c7b9 *out, ov_result_owner *owner) {
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  lean_object *value = NULL;
  status = lbov_7fab4b2842f6c64d9621_vf790309465bbf573c7b9_in(input, 0, 1, &transaction, &value);
  if (status) return ov_abort(&transaction, status);
  status = lbov_7fab4b2842f6c64d9621_vf790309465bbf573c7b9_out(out, value, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  return ov_commit(&transaction, owner);
}
static inline int lbov_7fab4b2842f6c64d9621_v160ce821a84f6887bbfd_retain(lb_owned_context *context, const lbov_7fab4b2842f6c64d9621_t160ce821a84f6887bbfd *input, lbov_7fab4b2842f6c64d9621_t160ce821a84f6887bbfd *out, ov_result_owner *owner) {
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  lean_object *value = NULL;
  status = lbov_7fab4b2842f6c64d9621_v160ce821a84f6887bbfd_in(input, 0, 1, &transaction, &value);
  if (status) return ov_abort(&transaction, status);
  status = lbov_7fab4b2842f6c64d9621_v160ce821a84f6887bbfd_out(out, value, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  return ov_commit(&transaction, owner);
}
static inline int lbov_7fab4b2842f6c64d9621_v23107461f72b24c37654_retain(lb_owned_context *context, const lbov_7fab4b2842f6c64d9621_t23107461f72b24c37654 *input, lbov_7fab4b2842f6c64d9621_t23107461f72b24c37654 *out, ov_result_owner *owner) {
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  lean_object *value = NULL;
  status = lbov_7fab4b2842f6c64d9621_v23107461f72b24c37654_in(input, 0, 1, &transaction, &value);
  if (status) return ov_abort(&transaction, status);
  status = lbov_7fab4b2842f6c64d9621_v23107461f72b24c37654_out(out, value, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  return ov_commit(&transaction, owner);
}
static inline int lbov_7fab4b2842f6c64d9621_vb2825946e038e653bd2b_retain(lb_owned_context *context, const lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b *input, lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b *out, ov_result_owner *owner) {
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  lean_object *value = NULL;
  status = lbov_7fab4b2842f6c64d9621_vb2825946e038e653bd2b_in(input, 0, 1, &transaction, &value);
  if (status) return ov_abort(&transaction, status);
  status = lbov_7fab4b2842f6c64d9621_vb2825946e038e653bd2b_out(out, value, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  return ov_commit(&transaction, owner);
}
static inline int lbov_7fab4b2842f6c64d9621_v4ce841c87ea3b1559bfb_retain(lb_owned_context *context, const lbov_7fab4b2842f6c64d9621_t4ce841c87ea3b1559bfb *input, lbov_7fab4b2842f6c64d9621_t4ce841c87ea3b1559bfb *out, ov_result_owner *owner) {
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  lean_object *value = NULL;
  status = lbov_7fab4b2842f6c64d9621_v4ce841c87ea3b1559bfb_in(input, 0, 1, &transaction, &value);
  if (status) return ov_abort(&transaction, status);
  status = lbov_7fab4b2842f6c64d9621_v4ce841c87ea3b1559bfb_out(out, value, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  return ov_commit(&transaction, owner);
}
static inline int lbov_7fab4b2842f6c64d9621_v2a091437b2d587ce3891_retain(lb_owned_context *context, const lbov_7fab4b2842f6c64d9621_t2a091437b2d587ce3891 *input, lbov_7fab4b2842f6c64d9621_t2a091437b2d587ce3891 *out, ov_result_owner *owner) {
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  lean_object *value = NULL;
  status = lbov_7fab4b2842f6c64d9621_v2a091437b2d587ce3891_in(input, 0, 1, &transaction, &value);
  if (status) return ov_abort(&transaction, status);
  status = lbov_7fab4b2842f6c64d9621_v2a091437b2d587ce3891_out(out, value, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  return ov_commit(&transaction, owner);
}
static inline int lbov_7fab4b2842f6c64d9621_v167081552b6f9c1d1afd_retain(lb_owned_context *context, const lbov_7fab4b2842f6c64d9621_t167081552b6f9c1d1afd *input, lbov_7fab4b2842f6c64d9621_t167081552b6f9c1d1afd *out, ov_result_owner *owner) {
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  lean_object *value = NULL;
  status = lbov_7fab4b2842f6c64d9621_v167081552b6f9c1d1afd_in(input, 0, 1, &transaction, &value);
  if (status) return ov_abort(&transaction, status);
  status = lbov_7fab4b2842f6c64d9621_v167081552b6f9c1d1afd_out(out, value, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  return ov_commit(&transaction, owner);
}
static inline int lbov_7fab4b2842f6c64d9621_vdc0347e1f7f5c4d928f1_retain(lb_owned_context *context, const lbov_7fab4b2842f6c64d9621_tdc0347e1f7f5c4d928f1 *input, lbov_7fab4b2842f6c64d9621_tdc0347e1f7f5c4d928f1 *out, ov_result_owner *owner) {
  ov_transaction transaction = {0};
  int status = ov_begin(&transaction, context, owner, "owned-checked-records@1.0.0");
  if (status) return status;
  lean_object *value = NULL;
  status = lbov_7fab4b2842f6c64d9621_vdc0347e1f7f5c4d928f1_in(input, 0, 1, &transaction, &value);
  if (status) return ov_abort(&transaction, status);
  status = lbov_7fab4b2842f6c64d9621_vdc0347e1f7f5c4d928f1_out(out, value, 0, &transaction);
  if (status) return ov_abort(&transaction, status);
  return ov_commit(&transaction, owner);
}
owned_checked_records_wasmtime_status owned_checked_records_wasmtime_booking_span(owned_checked_records_wasmtime_session *session, owned_checked_records_wasmtime_booking_t const * a0, mpz_srcptr *out, owned_checked_records_wasmtime_result **owner) {
  if (getpid() != lb_package_pid) return (owned_checked_records_wasmtime_status)LB_OWNED_PROCESS;
  if (lb_package_failure()) return (owned_checked_records_wasmtime_status)LB_OWNED_RUNTIME;
  if (!oc_outputs(out, sizeof(*out), _Alignof(mpz_srcptr), owner) || *owner) return (owned_checked_records_wasmtime_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_wasmtime_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_wasmtime_status)status;
  lbov_7fab4b2842f6c64d9621_t23107461f72b24c37654 raw0 = {0};
  lbov_7fab4b2842f6c64d9621_t167081552b6f9c1d1afd returned = {0};
  mpz_srcptr converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v4_to(a0, &raw0, 0, &input);
  if (!status) status = ows_dispatch_0(active->transport, &raw0, &returned, &result_owner->native);
  if (!status) {
    status = oc_v9_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_wasmtime_status)status;
}
owned_checked_records_wasmtime_status owned_checked_records_wasmtime_claim_closure(owned_checked_records_wasmtime_session *session, owned_checked_records_wasmtime_claim_closure_result_t *out, owned_checked_records_wasmtime_result **owner) {
  if (getpid() != lb_package_pid) return (owned_checked_records_wasmtime_status)LB_OWNED_PROCESS;
  if (lb_package_failure()) return (owned_checked_records_wasmtime_status)LB_OWNED_RUNTIME;
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_checked_records_wasmtime_claim_closure_result_t), owner) || *owner) return (owned_checked_records_wasmtime_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_wasmtime_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_wasmtime_status)status;
  lbov_7fab4b2842f6c64d9621_t648974cffb2d6c1d7951 returned = {0};
  owned_checked_records_wasmtime_claim_closure_result_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = ows_dispatch_1(active->transport, &returned, &result_owner->native);
  if (!status) {
    status = oc_v2_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_wasmtime_status)status;
}
owned_checked_records_wasmtime_status owned_checked_records_wasmtime_claim_for(owned_checked_records_wasmtime_session *session, owned_checked_records_wasmtime_ticket_t a0, owned_checked_records_wasmtime_value_160ce821a84f6887bbfd_t *out, owned_checked_records_wasmtime_result **owner) {
  if (getpid() != lb_package_pid) return (owned_checked_records_wasmtime_status)LB_OWNED_PROCESS;
  if (lb_package_failure()) return (owned_checked_records_wasmtime_status)LB_OWNED_RUNTIME;
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_checked_records_wasmtime_value_160ce821a84f6887bbfd_t), owner) || *owner) return (owned_checked_records_wasmtime_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_wasmtime_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_wasmtime_status)status;
  lbov_7fab4b2842f6c64d9621_td79b9bbde250ee1779da raw0 = {0};
  lbov_7fab4b2842f6c64d9621_t160ce821a84f6887bbfd returned = {0};
  owned_checked_records_wasmtime_value_160ce821a84f6887bbfd_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v7_to(&a0, &raw0, 0, &input);
  if (!status) status = ows_dispatch_2(active->transport, &raw0, &returned, &result_owner->native);
  if (!status) {
    status = oc_v1_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_wasmtime_status)status;
}
owned_checked_records_wasmtime_status owned_checked_records_wasmtime_claim_quota(owned_checked_records_wasmtime_session *session, owned_checked_records_wasmtime_claim_t const * a0, mpz_srcptr *out, owned_checked_records_wasmtime_result **owner) {
  if (getpid() != lb_package_pid) return (owned_checked_records_wasmtime_status)LB_OWNED_PROCESS;
  if (lb_package_failure()) return (owned_checked_records_wasmtime_status)LB_OWNED_RUNTIME;
  if (!oc_outputs(out, sizeof(*out), _Alignof(mpz_srcptr), owner) || *owner) return (owned_checked_records_wasmtime_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_wasmtime_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_wasmtime_status)status;
  lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b raw0 = {0};
  lbov_7fab4b2842f6c64d9621_t167081552b6f9c1d1afd returned = {0};
  mpz_srcptr converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v5_to(a0, &raw0, 0, &input);
  if (!status) status = ows_dispatch_3(active->transport, &raw0, &returned, &result_owner->native);
  if (!status) {
    status = oc_v9_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_wasmtime_status)status;
}
owned_checked_records_wasmtime_status owned_checked_records_wasmtime_echo_booking(owned_checked_records_wasmtime_session *session, owned_checked_records_wasmtime_booking_t const * a0, owned_checked_records_wasmtime_booking_t *out, owned_checked_records_wasmtime_result **owner) {
  if (getpid() != lb_package_pid) return (owned_checked_records_wasmtime_status)LB_OWNED_PROCESS;
  if (lb_package_failure()) return (owned_checked_records_wasmtime_status)LB_OWNED_RUNTIME;
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_checked_records_wasmtime_booking_t), owner) || *owner) return (owned_checked_records_wasmtime_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_wasmtime_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_wasmtime_status)status;
  lbov_7fab4b2842f6c64d9621_t23107461f72b24c37654 raw0 = {0};
  lbov_7fab4b2842f6c64d9621_t23107461f72b24c37654 returned = {0};
  owned_checked_records_wasmtime_booking_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v4_to(a0, &raw0, 0, &input);
  if (!status) status = ows_dispatch_4(active->transport, &raw0, &returned, &result_owner->native);
  if (!status) {
    status = oc_v4_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_wasmtime_status)status;
}
owned_checked_records_wasmtime_status owned_checked_records_wasmtime_echo_claim(owned_checked_records_wasmtime_session *session, owned_checked_records_wasmtime_claim_t const * a0, owned_checked_records_wasmtime_claim_t *out, owned_checked_records_wasmtime_result **owner) {
  if (getpid() != lb_package_pid) return (owned_checked_records_wasmtime_status)LB_OWNED_PROCESS;
  if (lb_package_failure()) return (owned_checked_records_wasmtime_status)LB_OWNED_RUNTIME;
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_checked_records_wasmtime_claim_t), owner) || *owner) return (owned_checked_records_wasmtime_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_wasmtime_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_wasmtime_status)status;
  lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b raw0 = {0};
  lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b returned = {0};
  owned_checked_records_wasmtime_claim_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v5_to(a0, &raw0, 0, &input);
  if (!status) status = ows_dispatch_5(active->transport, &raw0, &returned, &result_owner->native);
  if (!status) {
    status = oc_v5_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_wasmtime_status)status;
}
owned_checked_records_wasmtime_status owned_checked_records_wasmtime_echo_claims(owned_checked_records_wasmtime_session *session, owned_checked_records_wasmtime_value_f790309465bbf573c7b9_t const * a0, owned_checked_records_wasmtime_value_f790309465bbf573c7b9_t *out, owned_checked_records_wasmtime_result **owner) {
  if (getpid() != lb_package_pid) return (owned_checked_records_wasmtime_status)LB_OWNED_PROCESS;
  if (lb_package_failure()) return (owned_checked_records_wasmtime_status)LB_OWNED_RUNTIME;
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_checked_records_wasmtime_value_f790309465bbf573c7b9_t), owner) || *owner) return (owned_checked_records_wasmtime_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_wasmtime_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_wasmtime_status)status;
  lbov_7fab4b2842f6c64d9621_tf790309465bbf573c7b9 raw0 = {0};
  lbov_7fab4b2842f6c64d9621_tf790309465bbf573c7b9 returned = {0};
  owned_checked_records_wasmtime_value_f790309465bbf573c7b9_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v0_to(a0, &raw0, 0, &input);
  if (!status) status = ows_dispatch_6(active->transport, &raw0, &returned, &result_owner->native);
  if (!status) {
    status = oc_v0_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_wasmtime_status)status;
}
owned_checked_records_wasmtime_status owned_checked_records_wasmtime_echo_grant(owned_checked_records_wasmtime_session *session, owned_checked_records_wasmtime_grant_t const * a0, owned_checked_records_wasmtime_grant_t *out, owned_checked_records_wasmtime_result **owner) {
  if (getpid() != lb_package_pid) return (owned_checked_records_wasmtime_status)LB_OWNED_PROCESS;
  if (lb_package_failure()) return (owned_checked_records_wasmtime_status)LB_OWNED_RUNTIME;
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_checked_records_wasmtime_grant_t), owner) || *owner) return (owned_checked_records_wasmtime_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_wasmtime_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_wasmtime_status)status;
  lbov_7fab4b2842f6c64d9621_t4ce841c87ea3b1559bfb raw0 = {0};
  lbov_7fab4b2842f6c64d9621_t4ce841c87ea3b1559bfb returned = {0};
  owned_checked_records_wasmtime_grant_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v6_to(a0, &raw0, 0, &input);
  if (!status) status = ows_dispatch_7(active->transport, &raw0, &returned, &result_owner->native);
  if (!status) {
    status = oc_v6_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_wasmtime_status)status;
}
owned_checked_records_wasmtime_status owned_checked_records_wasmtime_new_ticket(owned_checked_records_wasmtime_session *session, mpz_srcptr a0, owned_checked_records_wasmtime_scalar_string_t a1, owned_checked_records_wasmtime_ticket_t *out, owned_checked_records_wasmtime_result **owner) {
  if (getpid() != lb_package_pid) return (owned_checked_records_wasmtime_status)LB_OWNED_PROCESS;
  if (lb_package_failure()) return (owned_checked_records_wasmtime_status)LB_OWNED_RUNTIME;
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_checked_records_wasmtime_ticket_t), owner) || *owner) return (owned_checked_records_wasmtime_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_wasmtime_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_wasmtime_status)status;
  lbov_7fab4b2842f6c64d9621_t167081552b6f9c1d1afd raw0 = {0};
  lbov_7fab4b2842f6c64d9621_tdc0347e1f7f5c4d928f1 raw1 = {0};
  lbov_7fab4b2842f6c64d9621_td79b9bbde250ee1779da returned = {0};
  owned_checked_records_wasmtime_ticket_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v9_to(&a0, &raw0, 0, &input);
  if (!status) status = oc_v10_to(&a1, &raw1, 0, &input);
  if (!status) status = ows_dispatch_8(active->transport, &raw0, &raw1, &returned, &result_owner->native);
  if (!status) {
    status = oc_v7_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_wasmtime_status)status;
}
owned_checked_records_wasmtime_status owned_checked_records_wasmtime_pair_claim(owned_checked_records_wasmtime_session *session, owned_checked_records_wasmtime_booking_t const * a0, owned_checked_records_wasmtime_claim_t const * a1, owned_checked_records_wasmtime_claim_t *out, owned_checked_records_wasmtime_result **owner) {
  if (getpid() != lb_package_pid) return (owned_checked_records_wasmtime_status)LB_OWNED_PROCESS;
  if (lb_package_failure()) return (owned_checked_records_wasmtime_status)LB_OWNED_RUNTIME;
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_checked_records_wasmtime_claim_t), owner) || *owner) return (owned_checked_records_wasmtime_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_wasmtime_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_wasmtime_status)status;
  lbov_7fab4b2842f6c64d9621_t23107461f72b24c37654 raw0 = {0};
  lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b raw1 = {0};
  lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b returned = {0};
  owned_checked_records_wasmtime_claim_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v4_to(a0, &raw0, 0, &input);
  if (!status) status = oc_v5_to(a1, &raw1, 0, &input);
  if (!status) status = ows_dispatch_9(active->transport, &raw0, &raw1, &returned, &result_owner->native);
  if (!status) {
    status = oc_v5_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_wasmtime_status)status;
}
owned_checked_records_wasmtime_status owned_checked_records_wasmtime_serial(owned_checked_records_wasmtime_session *session, owned_checked_records_wasmtime_ticket_t a0, mpz_srcptr *out, owned_checked_records_wasmtime_result **owner) {
  if (getpid() != lb_package_pid) return (owned_checked_records_wasmtime_status)LB_OWNED_PROCESS;
  if (lb_package_failure()) return (owned_checked_records_wasmtime_status)LB_OWNED_RUNTIME;
  if (!oc_outputs(out, sizeof(*out), _Alignof(mpz_srcptr), owner) || *owner) return (owned_checked_records_wasmtime_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_wasmtime_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_wasmtime_status)status;
  lbov_7fab4b2842f6c64d9621_td79b9bbde250ee1779da raw0 = {0};
  lbov_7fab4b2842f6c64d9621_t167081552b6f9c1d1afd returned = {0};
  mpz_srcptr converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v7_to(&a0, &raw0, 0, &input);
  if (!status) status = ows_dispatch_10(active->transport, &raw0, &returned, &result_owner->native);
  if (!status) {
    status = oc_v9_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_wasmtime_status)status;
}
owned_checked_records_wasmtime_status owned_checked_records_wasmtime_transfer_claim(owned_checked_records_wasmtime_session *session, owned_checked_records_wasmtime_claim_t const * a0, owned_checked_records_wasmtime_result **a0_owner, owned_checked_records_wasmtime_claim_t *out, owned_checked_records_wasmtime_result **owner) {
  if (getpid() != lb_package_pid) return (owned_checked_records_wasmtime_status)LB_OWNED_PROCESS;
  if (lb_package_failure()) return (owned_checked_records_wasmtime_status)LB_OWNED_RUNTIME;
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_checked_records_wasmtime_claim_t), owner) || *owner) return (owned_checked_records_wasmtime_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_wasmtime_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_wasmtime_status)status;
  oc_transfer_input transfer_inputs[1] = { { .slot = a0_owner } };
  ov_result_owner *transfer_owners[1] = {0};
  oc_transfer_frame transfer_frame = { .inputs = transfer_inputs, .count = 1 };
  ov_input_transfers transfer = { .owners = transfer_owners, .count = 1, .consume = oc_transfer_consume, .context = &transfer_frame };
  lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b raw0 = {0};
  lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b returned = {0};
  owned_checked_records_wasmtime_claim_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_transfer_prepare(active, &transfer_frame, transfer_owners, out, sizeof(*out), _Alignof(owned_checked_records_wasmtime_claim_t), owner);
  if (!status) status = oc_v5_to(a0, &raw0, 0, &input);
  if (!status) status = ows_dispatch_11(active->transport, &raw0, &transfer, &returned, &result_owner->native);
  if (!status) {
    status = oc_v5_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_transfer_finish(&transfer_frame, status);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_wasmtime_status)status;
}
owned_checked_records_wasmtime_status owned_checked_records_wasmtime_transfer_pair_claim(owned_checked_records_wasmtime_session *session, owned_checked_records_wasmtime_booking_t const * a0, owned_checked_records_wasmtime_result **a0_owner, owned_checked_records_wasmtime_claim_t const * a1, owned_checked_records_wasmtime_result **a1_owner, owned_checked_records_wasmtime_claim_t *out, owned_checked_records_wasmtime_result **owner) {
  if (getpid() != lb_package_pid) return (owned_checked_records_wasmtime_status)LB_OWNED_PROCESS;
  if (lb_package_failure()) return (owned_checked_records_wasmtime_status)LB_OWNED_RUNTIME;
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_checked_records_wasmtime_claim_t), owner) || *owner) return (owned_checked_records_wasmtime_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_wasmtime_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_wasmtime_status)status;
  oc_transfer_input transfer_inputs[2] = { { .slot = a0_owner }, { .slot = a1_owner } };
  ov_result_owner *transfer_owners[2] = {0};
  oc_transfer_frame transfer_frame = { .inputs = transfer_inputs, .count = 2 };
  ov_input_transfers transfer = { .owners = transfer_owners, .count = 2, .consume = oc_transfer_consume, .context = &transfer_frame };
  lbov_7fab4b2842f6c64d9621_t23107461f72b24c37654 raw0 = {0};
  lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b raw1 = {0};
  lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b returned = {0};
  owned_checked_records_wasmtime_claim_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_transfer_prepare(active, &transfer_frame, transfer_owners, out, sizeof(*out), _Alignof(owned_checked_records_wasmtime_claim_t), owner);
  if (!status) status = oc_v4_to(a0, &raw0, 0, &input);
  if (!status) status = oc_v5_to(a1, &raw1, 0, &input);
  if (!status) status = ows_dispatch_12(active->transport, &raw0, &raw1, &transfer, &returned, &result_owner->native);
  if (!status) {
    status = oc_v5_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_transfer_finish(&transfer_frame, status);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_wasmtime_status)status;
}
owned_checked_records_wasmtime_status owned_checked_records_wasmtime_transfer_with_claim_callback(owned_checked_records_wasmtime_session *session, owned_checked_records_wasmtime_claim_t const * a0, owned_checked_records_wasmtime_result **a0_owner, owned_checked_records_wasmtime_transfer_with_claim_callback_argument1_t_host const * a1, owned_checked_records_wasmtime_claim_t *out, owned_checked_records_wasmtime_result **owner) {
  if (getpid() != lb_package_pid) return (owned_checked_records_wasmtime_status)LB_OWNED_PROCESS;
  if (lb_package_failure()) return (owned_checked_records_wasmtime_status)LB_OWNED_RUNTIME;
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_checked_records_wasmtime_claim_t), owner) || *owner) return (owned_checked_records_wasmtime_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_wasmtime_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_wasmtime_status)status;
  oc_transfer_input transfer_inputs[1] = { { .slot = a0_owner } };
  ov_result_owner *transfer_owners[1] = {0};
  oc_transfer_frame transfer_frame = { .inputs = transfer_inputs, .count = 1 };
  ov_input_transfers transfer = { .owners = transfer_owners, .count = 1, .consume = oc_transfer_consume, .context = &transfer_frame };
  lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b raw0 = {0};
  lbov_7fab4b2842f6c64d9621_t5035e6ea0903f12776d9 raw1 = {0};
  oc_host_v3 borrow1 = {0};
  lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b returned = {0};
  owned_checked_records_wasmtime_claim_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_transfer_prepare(active, &transfer_frame, transfer_owners, out, sizeof(*out), _Alignof(owned_checked_records_wasmtime_claim_t), owner);
  if (!status) status = oc_v5_to(a0, &raw0, 0, &input);
  if (!status) status = oc_host_v3_begin(&borrow1, a1, active, &budget, &raw1);
  if (!status) status = ows_dispatch_13(active->transport, &raw0, &raw1, &transfer, &returned, &result_owner->native);
  { int cleanup = oc_host_v3_end(&borrow1); if (!status) status = cleanup; }
  if (!status) {
    status = oc_v5_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_transfer_finish(&transfer_frame, status);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_wasmtime_status)status;
}
owned_checked_records_wasmtime_status owned_checked_records_wasmtime_with_claim_callback(owned_checked_records_wasmtime_session *session, owned_checked_records_wasmtime_claim_t const * a0, owned_checked_records_wasmtime_transfer_with_claim_callback_argument1_t_host const * a1, owned_checked_records_wasmtime_claim_t *out, owned_checked_records_wasmtime_result **owner) {
  if (getpid() != lb_package_pid) return (owned_checked_records_wasmtime_status)LB_OWNED_PROCESS;
  if (lb_package_failure()) return (owned_checked_records_wasmtime_status)LB_OWNED_RUNTIME;
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_checked_records_wasmtime_claim_t), owner) || *owner) return (owned_checked_records_wasmtime_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_wasmtime_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_wasmtime_status)status;
  lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b raw0 = {0};
  lbov_7fab4b2842f6c64d9621_t5035e6ea0903f12776d9 raw1 = {0};
  oc_host_v3 borrow1 = {0};
  lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b returned = {0};
  owned_checked_records_wasmtime_claim_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v5_to(a0, &raw0, 0, &input);
  if (!status) status = oc_host_v3_begin(&borrow1, a1, active, &budget, &raw1);
  if (!status) status = ows_dispatch_14(active->transport, &raw0, &raw1, &returned, &result_owner->native);
  { int cleanup = oc_host_v3_end(&borrow1); if (!status) status = cleanup; }
  if (!status) {
    status = oc_v5_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_wasmtime_status)status;
}
owned_checked_records_wasmtime_status owned_checked_records_wasmtime_claim_closure_result_t_call(owned_checked_records_wasmtime_session *session, owned_checked_records_wasmtime_claim_closure_result_t a0, owned_checked_records_wasmtime_claim_t const * a1, owned_checked_records_wasmtime_claim_t *out, owned_checked_records_wasmtime_result **owner) {
  if (getpid() != lb_package_pid) return (owned_checked_records_wasmtime_status)LB_OWNED_PROCESS;
  if (lb_package_failure()) return (owned_checked_records_wasmtime_status)LB_OWNED_RUNTIME;
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_checked_records_wasmtime_claim_t), owner) || *owner) return (owned_checked_records_wasmtime_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_wasmtime_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_wasmtime_status)status;
  lbov_7fab4b2842f6c64d9621_t648974cffb2d6c1d7951 raw0 = {0};
  lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b raw1 = {0};
  lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b returned = {0};
  owned_checked_records_wasmtime_claim_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v2_to(&a0, &raw0, 0, &input);
  if (!status) status = oc_v5_to(a1, &raw1, 0, &input);
  if (!status) status = ows_dispatch_15(active->transport, &raw0, &raw1, &returned, &result_owner->native);
  if (!status) {
    status = oc_v5_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_wasmtime_status)status;
}
owned_checked_records_wasmtime_status owned_checked_records_wasmtime_transfer_with_claim_callback_argument1_t_call(owned_checked_records_wasmtime_session *session, owned_checked_records_wasmtime_transfer_with_claim_callback_argument1_t a0, owned_checked_records_wasmtime_claim_t const * a1, owned_checked_records_wasmtime_claim_t *out, owned_checked_records_wasmtime_result **owner) {
  if (getpid() != lb_package_pid) return (owned_checked_records_wasmtime_status)LB_OWNED_PROCESS;
  if (lb_package_failure()) return (owned_checked_records_wasmtime_status)LB_OWNED_RUNTIME;
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_checked_records_wasmtime_claim_t), owner) || *owner) return (owned_checked_records_wasmtime_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_wasmtime_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_wasmtime_status)status;
  lbov_7fab4b2842f6c64d9621_t5035e6ea0903f12776d9 raw0 = {0};
  lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b raw1 = {0};
  lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b returned = {0};
  owned_checked_records_wasmtime_claim_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v3_to(&a0, &raw0, 0, &input);
  if (!status) status = oc_v5_to(a1, &raw1, 0, &input);
  if (!status) status = ows_dispatch_16(active->transport, &raw0, &raw1, &returned, &result_owner->native);
  if (!status) {
    status = oc_v5_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_wasmtime_status)status;
}
owned_checked_records_wasmtime_status owned_checked_records_wasmtime_claim_closure_result_t_retain(owned_checked_records_wasmtime_session *session, owned_checked_records_wasmtime_claim_closure_result_t a0, owned_checked_records_wasmtime_claim_closure_result_t *out, owned_checked_records_wasmtime_result **owner) {
  if (getpid() != lb_package_pid) return (owned_checked_records_wasmtime_status)LB_OWNED_PROCESS;
  if (lb_package_failure()) return (owned_checked_records_wasmtime_status)LB_OWNED_RUNTIME;
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_checked_records_wasmtime_claim_closure_result_t), owner) || *owner) return (owned_checked_records_wasmtime_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_wasmtime_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_wasmtime_status)status;
  lbov_7fab4b2842f6c64d9621_t648974cffb2d6c1d7951 raw0 = {0};
  lbov_7fab4b2842f6c64d9621_t648974cffb2d6c1d7951 returned = {0};
  owned_checked_records_wasmtime_claim_closure_result_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v2_to(&a0, &raw0, 0, &input);
  if (!status) status = lbov_7fab4b2842f6c64d9621_v648974cffb2d6c1d7951_retain(&active->native, &raw0, &returned, &result_owner->native);
  if (!status) {
    status = oc_v2_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_wasmtime_status)status;
}
owned_checked_records_wasmtime_status owned_checked_records_wasmtime_transfer_with_claim_callback_argument1_t_retain(owned_checked_records_wasmtime_session *session, owned_checked_records_wasmtime_transfer_with_claim_callback_argument1_t a0, owned_checked_records_wasmtime_transfer_with_claim_callback_argument1_t *out, owned_checked_records_wasmtime_result **owner) {
  if (getpid() != lb_package_pid) return (owned_checked_records_wasmtime_status)LB_OWNED_PROCESS;
  if (lb_package_failure()) return (owned_checked_records_wasmtime_status)LB_OWNED_RUNTIME;
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_checked_records_wasmtime_transfer_with_claim_callback_argument1_t), owner) || *owner) return (owned_checked_records_wasmtime_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_wasmtime_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_wasmtime_status)status;
  lbov_7fab4b2842f6c64d9621_t5035e6ea0903f12776d9 raw0 = {0};
  lbov_7fab4b2842f6c64d9621_t5035e6ea0903f12776d9 returned = {0};
  owned_checked_records_wasmtime_transfer_with_claim_callback_argument1_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v3_to(&a0, &raw0, 0, &input);
  if (!status) status = lbov_7fab4b2842f6c64d9621_v5035e6ea0903f12776d9_retain(&active->native, &raw0, &returned, &result_owner->native);
  if (!status) {
    status = oc_v3_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_wasmtime_status)status;
}
owned_checked_records_wasmtime_status owned_checked_records_wasmtime_ticket_t_retain(owned_checked_records_wasmtime_session *session, owned_checked_records_wasmtime_ticket_t a0, owned_checked_records_wasmtime_ticket_t *out, owned_checked_records_wasmtime_result **owner) {
  if (getpid() != lb_package_pid) return (owned_checked_records_wasmtime_status)LB_OWNED_PROCESS;
  if (lb_package_failure()) return (owned_checked_records_wasmtime_status)LB_OWNED_RUNTIME;
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_checked_records_wasmtime_ticket_t), owner) || *owner) return (owned_checked_records_wasmtime_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_wasmtime_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_wasmtime_status)status;
  lbov_7fab4b2842f6c64d9621_td79b9bbde250ee1779da raw0 = {0};
  lbov_7fab4b2842f6c64d9621_td79b9bbde250ee1779da returned = {0};
  owned_checked_records_wasmtime_ticket_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v7_to(&a0, &raw0, 0, &input);
  if (!status) status = lbov_7fab4b2842f6c64d9621_vd79b9bbde250ee1779da_retain(&active->native, &raw0, &returned, &result_owner->native);
  if (!status) {
    status = oc_v7_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_wasmtime_status)status;
}
owned_checked_records_wasmtime_status owned_checked_records_wasmtime_value_f790309465bbf573c7b9_t_copy(owned_checked_records_wasmtime_session *session, owned_checked_records_wasmtime_value_f790309465bbf573c7b9_t const * a0, owned_checked_records_wasmtime_value_f790309465bbf573c7b9_t *out, owned_checked_records_wasmtime_result **owner) {
  if (getpid() != lb_package_pid) return (owned_checked_records_wasmtime_status)LB_OWNED_PROCESS;
  if (lb_package_failure()) return (owned_checked_records_wasmtime_status)LB_OWNED_RUNTIME;
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_checked_records_wasmtime_value_f790309465bbf573c7b9_t), owner) || *owner) return (owned_checked_records_wasmtime_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_wasmtime_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_wasmtime_status)status;
  lbov_7fab4b2842f6c64d9621_tf790309465bbf573c7b9 raw0 = {0};
  lbov_7fab4b2842f6c64d9621_tf790309465bbf573c7b9 returned = {0};
  owned_checked_records_wasmtime_value_f790309465bbf573c7b9_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v0_to(a0, &raw0, 0, &input);
  if (!status) status = lbov_7fab4b2842f6c64d9621_vf790309465bbf573c7b9_retain(&active->native, &raw0, &returned, &result_owner->native);
  if (!status) {
    status = oc_v0_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_wasmtime_status)status;
}
owned_checked_records_wasmtime_status owned_checked_records_wasmtime_value_160ce821a84f6887bbfd_t_copy(owned_checked_records_wasmtime_session *session, owned_checked_records_wasmtime_value_160ce821a84f6887bbfd_t const * a0, owned_checked_records_wasmtime_value_160ce821a84f6887bbfd_t *out, owned_checked_records_wasmtime_result **owner) {
  if (getpid() != lb_package_pid) return (owned_checked_records_wasmtime_status)LB_OWNED_PROCESS;
  if (lb_package_failure()) return (owned_checked_records_wasmtime_status)LB_OWNED_RUNTIME;
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_checked_records_wasmtime_value_160ce821a84f6887bbfd_t), owner) || *owner) return (owned_checked_records_wasmtime_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_wasmtime_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_wasmtime_status)status;
  lbov_7fab4b2842f6c64d9621_t160ce821a84f6887bbfd raw0 = {0};
  lbov_7fab4b2842f6c64d9621_t160ce821a84f6887bbfd returned = {0};
  owned_checked_records_wasmtime_value_160ce821a84f6887bbfd_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v1_to(a0, &raw0, 0, &input);
  if (!status) status = lbov_7fab4b2842f6c64d9621_v160ce821a84f6887bbfd_retain(&active->native, &raw0, &returned, &result_owner->native);
  if (!status) {
    status = oc_v1_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_wasmtime_status)status;
}
owned_checked_records_wasmtime_status owned_checked_records_wasmtime_booking_t_copy(owned_checked_records_wasmtime_session *session, owned_checked_records_wasmtime_booking_t const * a0, owned_checked_records_wasmtime_booking_t *out, owned_checked_records_wasmtime_result **owner) {
  if (getpid() != lb_package_pid) return (owned_checked_records_wasmtime_status)LB_OWNED_PROCESS;
  if (lb_package_failure()) return (owned_checked_records_wasmtime_status)LB_OWNED_RUNTIME;
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_checked_records_wasmtime_booking_t), owner) || *owner) return (owned_checked_records_wasmtime_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_wasmtime_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_wasmtime_status)status;
  lbov_7fab4b2842f6c64d9621_t23107461f72b24c37654 raw0 = {0};
  lbov_7fab4b2842f6c64d9621_t23107461f72b24c37654 returned = {0};
  owned_checked_records_wasmtime_booking_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v4_to(a0, &raw0, 0, &input);
  if (!status) status = lbov_7fab4b2842f6c64d9621_v23107461f72b24c37654_retain(&active->native, &raw0, &returned, &result_owner->native);
  if (!status) {
    status = oc_v4_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_wasmtime_status)status;
}
owned_checked_records_wasmtime_status owned_checked_records_wasmtime_claim_t_copy(owned_checked_records_wasmtime_session *session, owned_checked_records_wasmtime_claim_t const * a0, owned_checked_records_wasmtime_claim_t *out, owned_checked_records_wasmtime_result **owner) {
  if (getpid() != lb_package_pid) return (owned_checked_records_wasmtime_status)LB_OWNED_PROCESS;
  if (lb_package_failure()) return (owned_checked_records_wasmtime_status)LB_OWNED_RUNTIME;
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_checked_records_wasmtime_claim_t), owner) || *owner) return (owned_checked_records_wasmtime_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_wasmtime_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_wasmtime_status)status;
  lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b raw0 = {0};
  lbov_7fab4b2842f6c64d9621_tb2825946e038e653bd2b returned = {0};
  owned_checked_records_wasmtime_claim_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v5_to(a0, &raw0, 0, &input);
  if (!status) status = lbov_7fab4b2842f6c64d9621_vb2825946e038e653bd2b_retain(&active->native, &raw0, &returned, &result_owner->native);
  if (!status) {
    status = oc_v5_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_wasmtime_status)status;
}
owned_checked_records_wasmtime_status owned_checked_records_wasmtime_grant_t_copy(owned_checked_records_wasmtime_session *session, owned_checked_records_wasmtime_grant_t const * a0, owned_checked_records_wasmtime_grant_t *out, owned_checked_records_wasmtime_result **owner) {
  if (getpid() != lb_package_pid) return (owned_checked_records_wasmtime_status)LB_OWNED_PROCESS;
  if (lb_package_failure()) return (owned_checked_records_wasmtime_status)LB_OWNED_RUNTIME;
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_checked_records_wasmtime_grant_t), owner) || *owner) return (owned_checked_records_wasmtime_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_wasmtime_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_wasmtime_status)status;
  lbov_7fab4b2842f6c64d9621_t4ce841c87ea3b1559bfb raw0 = {0};
  lbov_7fab4b2842f6c64d9621_t4ce841c87ea3b1559bfb returned = {0};
  owned_checked_records_wasmtime_grant_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v6_to(a0, &raw0, 0, &input);
  if (!status) status = lbov_7fab4b2842f6c64d9621_v4ce841c87ea3b1559bfb_retain(&active->native, &raw0, &returned, &result_owner->native);
  if (!status) {
    status = oc_v6_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_wasmtime_status)status;
}
owned_checked_records_wasmtime_status owned_checked_records_wasmtime_window_t_copy(owned_checked_records_wasmtime_session *session, owned_checked_records_wasmtime_window_t const * a0, owned_checked_records_wasmtime_window_t *out, owned_checked_records_wasmtime_result **owner) {
  if (getpid() != lb_package_pid) return (owned_checked_records_wasmtime_status)LB_OWNED_PROCESS;
  if (lb_package_failure()) return (owned_checked_records_wasmtime_status)LB_OWNED_RUNTIME;
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_checked_records_wasmtime_window_t), owner) || *owner) return (owned_checked_records_wasmtime_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_wasmtime_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_wasmtime_status)status;
  lbov_7fab4b2842f6c64d9621_t2a091437b2d587ce3891 raw0 = {0};
  lbov_7fab4b2842f6c64d9621_t2a091437b2d587ce3891 returned = {0};
  owned_checked_records_wasmtime_window_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v8_to(a0, &raw0, 0, &input);
  if (!status) status = lbov_7fab4b2842f6c64d9621_v2a091437b2d587ce3891_retain(&active->native, &raw0, &returned, &result_owner->native);
  if (!status) {
    status = oc_v8_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_wasmtime_status)status;
}
owned_checked_records_wasmtime_status owned_checked_records_wasmtime_scalar_nat_copy(owned_checked_records_wasmtime_session *session, mpz_srcptr a0, mpz_srcptr *out, owned_checked_records_wasmtime_result **owner) {
  if (getpid() != lb_package_pid) return (owned_checked_records_wasmtime_status)LB_OWNED_PROCESS;
  if (lb_package_failure()) return (owned_checked_records_wasmtime_status)LB_OWNED_RUNTIME;
  if (!oc_outputs(out, sizeof(*out), _Alignof(mpz_srcptr), owner) || *owner) return (owned_checked_records_wasmtime_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_wasmtime_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_wasmtime_status)status;
  lbov_7fab4b2842f6c64d9621_t167081552b6f9c1d1afd raw0 = {0};
  lbov_7fab4b2842f6c64d9621_t167081552b6f9c1d1afd returned = {0};
  mpz_srcptr converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v9_to(&a0, &raw0, 0, &input);
  if (!status) status = lbov_7fab4b2842f6c64d9621_v167081552b6f9c1d1afd_retain(&active->native, &raw0, &returned, &result_owner->native);
  if (!status) {
    status = oc_v9_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_wasmtime_status)status;
}
owned_checked_records_wasmtime_status owned_checked_records_wasmtime_scalar_string_copy(owned_checked_records_wasmtime_session *session, owned_checked_records_wasmtime_scalar_string_t a0, owned_checked_records_wasmtime_scalar_string_t *out, owned_checked_records_wasmtime_result **owner) {
  if (getpid() != lb_package_pid) return (owned_checked_records_wasmtime_status)LB_OWNED_PROCESS;
  if (lb_package_failure()) return (owned_checked_records_wasmtime_status)LB_OWNED_RUNTIME;
  if (!oc_outputs(out, sizeof(*out), _Alignof(owned_checked_records_wasmtime_scalar_string_t), owner) || *owner) return (owned_checked_records_wasmtime_status)LB_OWNED_INVALID;
  oc_session *active = NULL; int status = oc_session_get(session, &active);
  if (status) return (owned_checked_records_wasmtime_status)status;
  ov_budget budget = oc_budget(); oc_arena input = { .budget = &budget }, output = { .budget = &budget };
  oc_result *result_owner = NULL; status = oc_result_begin(active, &budget, &result_owner);
  if (status) return (owned_checked_records_wasmtime_status)status;
  lbov_7fab4b2842f6c64d9621_tdc0347e1f7f5c4d928f1 raw0 = {0};
  lbov_7fab4b2842f6c64d9621_tdc0347e1f7f5c4d928f1 returned = {0};
  owned_checked_records_wasmtime_scalar_string_t converted = {0};
  status = ov_charge(&budget, 1, sizeof(converted));
  if (!status) status = oc_v10_to(&a0, &raw0, 0, &input);
  if (!status) status = lbov_7fab4b2842f6c64d9621_vdc0347e1f7f5c4d928f1_retain(&active->native, &raw0, &returned, &result_owner->native);
  if (!status) {
    status = oc_v10_from(&returned, &converted, 0, &output);
    if (status == LB_OWNED_INVALID) status = OV_RESULT;
  }
  oc_release(input.head);
  status = oc_result_finish(result_owner, &output, status, owner);
  if (!status) *out = converted;
  return (owned_checked_records_wasmtime_status)status;
}
