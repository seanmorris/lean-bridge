#pragma once
#include "inheritedcheckedrecords.h"
#include <stdexcept>
#include <memory>
#include <string>
#include <variant>
#include <optional>
#include <vector>
#include <utility>

#ifndef BOOST_MP_STANDALONE
#define BOOST_MP_STANDALONE
#endif
#include <boost/multiprecision/cpp_int.hpp>

namespace lean_bridge::inheritedcheckedrecords {

using Nat = boost::multiprecision::cpp_int;
using Int = boost::multiprecision::cpp_int;
struct Span {
  Nat lo{};
  Nat hi{};
  friend bool operator==(const Span&, const Span&) = default;
};
struct Ticket {
  Span to_span{};
  Nat word{};
  friend bool operator==(const Ticket&, const Ticket&) = default;
};
struct Stamped {
  Ticket to_ticket{};
  Nat mark{};
  friend bool operator==(const Stamped&, const Stamped&) = default;
};
class Error final : public std::runtime_error {
public:
  inheritedcheckedrecords_status status;
  inheritedcheckedrecords_error_code code;
  Error(inheritedcheckedrecords_status value, const inheritedcheckedrecords_error& error)
    : std::runtime_error(error.message ? std::string(error.message, error.message_length) : "Lean call failed"), status(value), code(error.code) {}
};
namespace detail {
[[noreturn]] inline void invalid(const char* message) {
  const inheritedcheckedrecords_error error{INHERITEDCHECKEDRECORDS_ERROR_INVALID_ARGUMENT, message, std::char_traits<char>::length(message)};
  throw Error(INHERITEDCHECKEDRECORDS_STATUS_INVALID_ARGUMENT, error);
}
inline void charge(size_t& budget, size_t count, size_t width) {
  if (count > budget / width) {
    const inheritedcheckedrecords_error error{INHERITEDCHECKEDRECORDS_ERROR_INVALID_ARGUMENT, "16 MiB call limit exceeded", 26};
    throw Error(INHERITEDCHECKEDRECORDS_STATUS_INVALID_ARGUMENT, error);
  }
  budget -= count * width;
}
inline void check0(const Nat& source, size_t& budget) {
  (void)source; (void)budget;
  if (source < 0) invalid("Nat must be nonnegative");
  charge(budget, source == 0 ? 0 : (boost::multiprecision::msb(source < 0 ? -source : source) / 32 + 1), sizeof(uint32_t));
}
struct View0 {
  std::vector<uint32_t> limbs;
  inheritedcheckedrecords_nat value{};
  explicit View0(const Nat& source) {
    (void)source;
    if (source != 0) boost::multiprecision::export_bits(source, std::back_inserter(limbs), 32, false);
    value = inheritedcheckedrecords_nat{limbs.data(), limbs.size(), nullptr, nullptr};
  }
};
inline Nat from0(const inheritedcheckedrecords_nat& source) {
  (void)source;
  Nat result = 0;
  if (source.length) boost::multiprecision::import_bits(result, source.data, source.data + source.length, 32, false);
  return result;
}

inline void check1(const Span& source, size_t& budget) {
  (void)source; (void)budget;
  charge(budget, 1, sizeof(inheritedcheckedrecords_span));
  check0(source.lo, budget);
  check0(source.hi, budget);
}
struct View1 {
  View0 field0;
  View0 field1;
  inheritedcheckedrecords_span value{};
  explicit View1(const Span& source) : field0(source.lo), field1(source.hi) {
    (void)source;
    value = inheritedcheckedrecords_span{field0.value, field1.value};
  }
};
inline Span from1(const inheritedcheckedrecords_span& source) {
  (void)source;
  return Span{from0(source.lo), from0(source.hi)};
}

inline void check2(const Ticket& source, size_t& budget) {
  (void)source; (void)budget;
  charge(budget, 1, sizeof(inheritedcheckedrecords_ticket));
  check1(source.to_span, budget);
  check0(source.word, budget);
}
struct View2 {
  View1 field0;
  View0 field1;
  inheritedcheckedrecords_ticket value{};
  explicit View2(const Ticket& source) : field0(source.to_span), field1(source.word) {
    (void)source;
    value = inheritedcheckedrecords_ticket{field0.value, field1.value};
  }
};
inline Ticket from2(const inheritedcheckedrecords_ticket& source) {
  (void)source;
  return Ticket{from1(source.to_span), from0(source.word)};
}

inline void check3(const Stamped& source, size_t& budget) {
  (void)source; (void)budget;
  charge(budget, 1, sizeof(inheritedcheckedrecords_stamped));
  check2(source.to_ticket, budget);
  check0(source.mark, budget);
}
struct View3 {
  View2 field0;
  View0 field1;
  inheritedcheckedrecords_stamped value{};
  explicit View3(const Stamped& source) : field0(source.to_ticket), field1(source.mark) {
    (void)source;
    value = inheritedcheckedrecords_stamped{field0.value, field1.value};
  }
};
inline Stamped from3(const inheritedcheckedrecords_stamped& source) {
  (void)source;
  return Stamped{from2(source.to_ticket), from0(source.mark)};
}
inline void check(inheritedcheckedrecords_status status, const inheritedcheckedrecords_error& error) {
  if (status != INHERITEDCHECKEDRECORDS_STATUS_OK) throw Error(status, error);
}
template<class T, void (*Clear)(T*)> struct Owned {
  T* value;
  ~Owned() { Clear(value); }
  Owned(const Owned&) = delete;
  Owned& operator=(const Owned&) = delete;
  explicit Owned(T* input) : value(input) {}
};
}


inline Ticket produce(Nat const& arg0) {
  inheritedcheckedrecords_error _lb_error{}; size_t _lb_budget = 16u * 1024u * 1024u; (void)_lb_budget;
  detail::check0(arg0, _lb_budget);
  detail::View0 _lb_arg0{arg0};
  inheritedcheckedrecords_ticket _lb_result{};
  detail::Owned<inheritedcheckedrecords_ticket, inheritedcheckedrecords_ticket_clear> _lb_owner{&_lb_result};
  const auto _lb_status = inheritedcheckedrecords_produce(&_lb_arg0.value, &_lb_result, &_lb_error);
  detail::check(_lb_status, _lb_error);
  return detail::from2(_lb_result);
}

inline Stamped produce_stamped(Nat const& arg0) {
  inheritedcheckedrecords_error _lb_error{}; size_t _lb_budget = 16u * 1024u * 1024u; (void)_lb_budget;
  detail::check0(arg0, _lb_budget);
  detail::View0 _lb_arg0{arg0};
  inheritedcheckedrecords_stamped _lb_result{};
  detail::Owned<inheritedcheckedrecords_stamped, inheritedcheckedrecords_stamped_clear> _lb_owner{&_lb_result};
  const auto _lb_status = inheritedcheckedrecords_produce_stamped(&_lb_arg0.value, &_lb_result, &_lb_error);
  detail::check(_lb_status, _lb_error);
  return detail::from3(_lb_result);
}
}
