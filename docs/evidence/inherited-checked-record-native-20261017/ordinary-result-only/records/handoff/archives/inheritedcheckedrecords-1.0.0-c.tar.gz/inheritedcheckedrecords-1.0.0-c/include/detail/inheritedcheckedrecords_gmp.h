#pragma once
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <gmp.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef enum inheritedcheckedrecords_gmp_status { INHERITEDCHECKEDRECORDS_GMP_STATUS_OK = 0, INHERITEDCHECKEDRECORDS_GMP_STATUS_INVALID_ARGUMENT = 1, INHERITEDCHECKEDRECORDS_GMP_STATUS_RUNTIME_UNAVAILABLE = 2, INHERITEDCHECKEDRECORDS_GMP_STATUS_RUNTIME_REJECTED = 3, INHERITEDCHECKEDRECORDS_GMP_STATUS_DECLARED_ERROR = 4, INHERITEDCHECKEDRECORDS_GMP_STATUS_UNEXPECTED_ERROR = 5 } inheritedcheckedrecords_gmp_status;
typedef enum inheritedcheckedrecords_gmp_error_code { INHERITEDCHECKEDRECORDS_GMP_ERROR_NONE = 0, INHERITEDCHECKEDRECORDS_GMP_ERROR_INVALID_ARGUMENT = 1, INHERITEDCHECKEDRECORDS_GMP_ERROR_RUNTIME_UNAVAILABLE = 2, INHERITEDCHECKEDRECORDS_GMP_ERROR_UNEXPECTED = 65535 } inheritedcheckedrecords_gmp_error_code;
typedef struct { inheritedcheckedrecords_gmp_error_code code; const char* message; size_t message_length; } inheritedcheckedrecords_gmp_error;
typedef mpz_t inheritedcheckedrecords_gmp_nat;
typedef struct inheritedcheckedrecords_gmp_span inheritedcheckedrecords_gmp_span;
typedef struct inheritedcheckedrecords_gmp_ticket inheritedcheckedrecords_gmp_ticket;
typedef struct inheritedcheckedrecords_gmp_stamped inheritedcheckedrecords_gmp_stamped;
void inheritedcheckedrecords_gmp_nat_init(mpz_ptr value);
void inheritedcheckedrecords_gmp_nat_clear(mpz_ptr value);
struct inheritedcheckedrecords_gmp_span {
  inheritedcheckedrecords_gmp_nat lo;
  inheritedcheckedrecords_gmp_nat hi;
};
void inheritedcheckedrecords_gmp_span_init(inheritedcheckedrecords_gmp_span* value);
void inheritedcheckedrecords_gmp_span_clear(inheritedcheckedrecords_gmp_span* value);
struct inheritedcheckedrecords_gmp_ticket {
  inheritedcheckedrecords_gmp_span to_span;
  inheritedcheckedrecords_gmp_nat word;
};
void inheritedcheckedrecords_gmp_ticket_init(inheritedcheckedrecords_gmp_ticket* value);
void inheritedcheckedrecords_gmp_ticket_clear(inheritedcheckedrecords_gmp_ticket* value);
struct inheritedcheckedrecords_gmp_stamped {
  inheritedcheckedrecords_gmp_ticket to_ticket;
  inheritedcheckedrecords_gmp_nat mark;
};
void inheritedcheckedrecords_gmp_stamped_init(inheritedcheckedrecords_gmp_stamped* value);
void inheritedcheckedrecords_gmp_stamped_clear(inheritedcheckedrecords_gmp_stamped* value);

inheritedcheckedrecords_gmp_status inheritedcheckedrecords_gmp_produce(mpz_srcptr _lb_arg0, inheritedcheckedrecords_gmp_ticket* out, inheritedcheckedrecords_gmp_error* error);
inheritedcheckedrecords_gmp_status inheritedcheckedrecords_gmp_produce_stamped(mpz_srcptr _lb_arg0, inheritedcheckedrecords_gmp_stamped* out, inheritedcheckedrecords_gmp_error* error);
#ifdef __cplusplus
}
#endif
