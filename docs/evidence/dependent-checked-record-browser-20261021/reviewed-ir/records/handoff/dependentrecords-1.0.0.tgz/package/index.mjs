// Generated from Binding IR SHA-256 69567662e7e08f19daea34b1652996700f49332ee383f37bafa2afba6f8fb363.
import { runtime } from "./internal/runtime.mjs";
import * as validate from "./internal/validators.mjs";

/**
 * Independent corpus contract.
 */
export function dependentResult(value0) {
  validate.assertNat(value0, "dependentResult.value0");
  const result = runtime.call("lean:DependentRecords.dependentResult", [value0]);
  validate.assertDependent(result, "dependentResult.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function dependentRoundtrip(value0) {
  validate.assertDependent(value0, "dependentRoundtrip.value0");
  const result = runtime.call("lean:DependentRecords.dependentRoundtrip", [value0]);
  validate.assertDependent(result, "dependentRoundtrip.result");
  return result;
}

/**
 * Independent corpus contract.
 */
export function dependentTotal(value0) {
  validate.assertDependent(value0, "dependentTotal.value0");
  const result = runtime.call("lean:DependentRecords.dependentTotal", [value0]);
  validate.assertNat(result, "dependentTotal.result");
  return result;
}

export default Object.freeze({ dependentResult, dependentRoundtrip, dependentTotal });
