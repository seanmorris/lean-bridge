# dependentrecords

Independent corpus contract.

Binding IR SHA-256: `69567662e7e08f19daea34b1652996700f49332ee383f37bafa2afba6f8fb363`

## Exports

### dependentResult

Independent corpus contract.

### dependentRoundtrip

Independent corpus contract.

### dependentTotal

Independent corpus contract.

## Assurance

