# dependentrecords

Compiler-checked exports for dependentrecords.

Binding IR SHA-256: `836074ffcb70109ff3fe1d2fad5e51618e05d9ad2b8e33a767058f37bfe7580a`

## Exports

### dependentResult

Lean produces the dependent proofs for a result-only API. 

## Assurance

