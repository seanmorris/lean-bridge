import { loadComponent } from "@lean-bridge/runtime";
import descriptor from "./descriptor.mjs";

export const runtime = await loadComponent(descriptor);
