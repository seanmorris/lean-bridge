// Generated from Binding IR SHA-256 836074ffcb70109ff3fe1d2fad5e51618e05d9ad2b8e33a767058f37bfe7580a.
import { runtime } from "./internal/runtime.mjs";
import * as validate from "./internal/validators.mjs";

/**
 * Lean produces the dependent proofs for a result-only API. 
 */
export function dependentResult(arg0) {
  validate.assertNat(arg0, "dependentResult.arg0");
  const result = runtime.call("lean:DependentRecords.dependentResult", [arg0]);
  validate.assertDependent(result, "dependentResult.result");
  return result;
}

export default Object.freeze({ dependentResult });
