// Generated from Binding IR SHA-256 2bba7e14f88b28a3039a49136afbed8b85a306281c6853344a3d8519ac4ec6de.
import { runtime } from "./internal/runtime.mjs";
import * as validate from "./internal/validators.mjs";

/**
 * Lean produces the dependent proofs for a result-only API. 
 */
export function dependentResult(arg0) {
  validate.assertNat(arg0, "dependentResult.arg0");
  const result = runtime.call("lean:DependentRecords.dependentResult", [arg0]);
  validate.assertDependent(result, "dependentResult.result");
  return result;
}

/**
 * Return the exact checked value through its proof-free host mirror. 
 */
export function dependentRoundtrip(arg0) {
  validate.assertDependent(arg0, "dependentRoundtrip.arg0");
  const result = runtime.call("lean:DependentRecords.dependentRoundtrip", [arg0]);
  validate.assertDependent(result, "dependentRoundtrip.result");
  return result;
}

/**
 * Consume both retained fields after the checked constructor has run. 
 */
export function dependentTotal(arg0) {
  validate.assertDependent(arg0, "dependentTotal.arg0");
  const result = runtime.call("lean:DependentRecords.dependentTotal", [arg0]);
  validate.assertNat(result, "dependentTotal.result");
  return result;
}

export default Object.freeze({ dependentResult, dependentRoundtrip, dependentTotal });
