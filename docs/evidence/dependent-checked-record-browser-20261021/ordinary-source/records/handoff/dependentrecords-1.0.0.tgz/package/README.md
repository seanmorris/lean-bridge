# dependentrecords

Compiler-checked exports for dependentrecords.

Binding IR SHA-256: `2bba7e14f88b28a3039a49136afbed8b85a306281c6853344a3d8519ac4ec6de`

## Exports

### dependentResult

Lean produces the dependent proofs for a result-only API. 

### dependentRoundtrip

Return the exact checked value through its proof-free host mirror. 

### dependentTotal

Consume both retained fields after the checked constructor has run. 

## Assurance

