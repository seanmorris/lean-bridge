# dependentrecords

Independent corpus contract.

Binding IR SHA-256: `d1515d6a8e4f834d593b60ef2304a87a77321852bcfcf8aa43de103e7319a8dd`

## Exports

### dependentResult

Independent corpus contract.

## Assurance

