// Generated from Binding IR SHA-256 d1515d6a8e4f834d593b60ef2304a87a77321852bcfcf8aa43de103e7319a8dd.
import { runtime } from "./internal/runtime.mjs";
import * as validate from "./internal/validators.mjs";

/**
 * Independent corpus contract.
 */
export function dependentResult(value0) {
  validate.assertNat(value0, "dependentResult.value0");
  const result = runtime.call("lean:DependentRecords.dependentResult", [value0]);
  validate.assertDependent(result, "dependentResult.result");
  return result;
}

export default Object.freeze({ dependentResult });
