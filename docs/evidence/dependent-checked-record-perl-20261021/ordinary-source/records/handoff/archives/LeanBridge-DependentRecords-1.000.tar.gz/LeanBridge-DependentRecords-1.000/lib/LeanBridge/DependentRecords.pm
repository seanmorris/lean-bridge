package LeanBridge::DependentRecords;
use strict;
use warnings;
use Math::BigInt;
use LeanBridge::Runtime;
die "Incompatible shared Lean runtime package version\n" unless $LeanBridge::Runtime::VERSION eq '0.0020130180835253351074425099676719723942806298898514237203907626409680523998624031';
use XSLoader;
our $VERSION = '1.000';
LeanBridge::Runtime::_load_component(__FILE__, 'libcomponent_ca8ca903379eb247d9eb.so', 'cd5e274866e4d6615a5da362d86900b493ee62a46ef9878944fa052a6a2eeb94', '6f4dbd1e2e112f4678734553d1c9bb8722fad3e6290adbff1ac46d05e5eff7dd', { 'DependentRecords' => '44eeadfa43d24e6a0a65d5b8be25809c22a5f29f217d57fb5dd462da9526782e' }, 'dependentrecords@1.0.0');
XSLoader::load(__PACKAGE__, $VERSION);
sub true () { !!1 }
sub false () { !!0 }
sub CLONE_SKIP { 1 }

package LeanBridge::DependentRecords::Dependent;
sub new {
  die "LeanBridge::DependentRecords::Dependent->new expects named fields\n" unless @_ % 2 == 1 && $_[0] eq 'LeanBridge::DependentRecords::Dependent';
  shift; my %fields;
  while (@_) {
    my ($key, $value) = splice @_, 0, 2;
    die "invalid record field\n" if !defined($key) || ref($key);
    $fields{$key} = $value;
  }
  my @required = qw(bound below);
  die "record fields do not match the generated schema\n" if keys(%fields) != @required || grep { !exists $fields{$_} } @required;
  return bless \%fields, 'LeanBridge::DependentRecords::Dependent';
}
sub bound { $_[0]->{bound} }
sub below { $_[0]->{below} }
1;

__END__
=head1 NAME

LeanBridge::DependentRecords - Generated functions from dependentrecords

=head1 API

=head2 dependent_result

Calls C<DependentRecords.dependentResult> in the compiled Lean component.

Checked Lean refinements: result projects proof-backed record payload fields; result.below < result.bound.

=head2 dependent_roundtrip

Calls C<DependentRecords.dependentRoundtrip> in the compiled Lean component.

Checked Lean refinements: arg0 checked by DependentRecords.mkDependent; arg0.below < arg0.bound; result projects proof-backed record payload fields; result.below < result.bound.

=head2 dependent_total

Calls C<DependentRecords.dependentTotal> in the compiled Lean component.

Checked Lean refinements: arg0 checked by DependentRecords.mkDependent; arg0.below < arg0.bound.

=head1 ARRAYS AND RECORDS

Lean Array values use plain dense array references. Calls reject blessed, tied and sparse arrays. Copied records use generated classes with named fields and accessors. Record keyword arguments keep Perl's last-value-wins hash semantics, including new(%old_fields, field => $replacement). Constructors reject missing, extra or unnamed fields; calls require the exact generated class and reject tied hashes and subclasses. Empty records and one-field records retain their named types.

Array slots and record fields are pinned before conversion can invoke Perl code. Returned arrays, records, octet strings and Math::BigInt payloads own independent copied storage. Reference equality is not deep value equality. Nested copied values share a 16 MiB conversion budget and a 32-level schema limit; these are not limits on all Perl allocations or Lean working memory. Recursive copied types remain unsupported.

=head1 CHECKED RECORDS

Checked records use generated classes containing only payload fields. Pass L<Math::BigInt> for C<Nat> fields and plain array references for copied arrays. Checked records may occur directly or through arrays, Lists, options, products, Except branches, plain record fields and active variant fields. Every nested Fin bound and Subtype constructor runs before the record constructor at that exact path. A rejection names the failing path and check. A normalizing constructor changes the record received by Lean without changing the caller's record. Results project payload fields after Lean constructs the proofs. No proof object or input constructor is needed for a result-only export. Ordinary and independently reviewed APIs preserve each site's constructor choices. A top-level closed generic checked record retains its compiler-authenticated type and value indices and may select Subtype constructors for payload fields. Generic checked records nested inside another value, Fin-refined fields inside a generic checked record, other dependent forms beyond the recorded closed fields, recursive checked records, callbacks and identity-bearing payloads remain unsupported.

=head1 BOUNDED INTEGERS

Lean C<Fin n> parameters and results are L<Math::BigInt> values below C<n>. Each argument is compared with its exact bound, including bounds wider than 64 bits, before the guarded adapter or the exported function runs. A value that is not a Math::BigInt, or a negative one, is rejected as for Nat; a value at or above its bound dies with a message naming the Lean parameter and bound. C<Fin 0> has no values, so every call to a function taking one dies. Results are Math::BigInt values below their declared bound. Inside arrays, Lists and options every present element is checked the same way before the guarded adapter or the exported function runs, so a C<Fin 0> element is rejected while an empty array or an undefined option is accepted; each checked path is listed as C<arg0[*]? < n> at its function, and a rejection names the failing element's own path and bound, such as C<arg0[2]? is not below its Fin 10 bound>. Fin inside records, variants, callbacks or reviewed Binding IR is not supported in CPAN packages.

=head1 OWNERSHIP

Close resource and closure objects when finished. Host callbacks are synchronous and may not be retained by Lean.

=cut
