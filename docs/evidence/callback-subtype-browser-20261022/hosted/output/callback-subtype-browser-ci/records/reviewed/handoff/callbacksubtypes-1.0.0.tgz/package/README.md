# callbacksubtypes

Compiler-checked exports for callbacksubtypes.

Binding IR SHA-256: `5a459aaa70fdcbaabbdcb9a9ab192eaf38a94c0a124641d66608bd240935618e`

## Exports

### callHost

Call CallbackSubtypes.callHost.

### callHostContainer

Call CallbackSubtypes.callHostContainer.

### callHostMixed

Call CallbackSubtypes.callHostMixed.

### makeClosure

Call CallbackSubtypes.makeClosure.

### makeContainerClosure

Call CallbackSubtypes.makeContainerClosure.

### makeMixedClosure

Call CallbackSubtypes.makeMixedClosure.

## Assurance

