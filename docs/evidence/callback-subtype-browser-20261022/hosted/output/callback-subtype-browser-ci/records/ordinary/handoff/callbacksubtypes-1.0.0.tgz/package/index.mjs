// Generated from Binding IR SHA-256 abef6a1ecab297a3cf7dbad0cb7d2a45266f3807a0b2ff1367a1bf0b36ee79c9.
import { runtime } from "./internal/runtime.mjs";
import * as validate from "./internal/validators.mjs";

/**
 * Call CallbackSubtypes.callHost.
 */
export function callHost(arg0) {
  validate.assertCallbacke84eef4c26bca64196e6(arg0, "callHost.arg0");
  const result = runtime.call("lean:CallbackSubtypes.callHost", [runtime.prepareCallback(arg0, validate.wrapCallbacke84eef4c26bca64196e6(arg0, "callHost.arg0"))]);
  validate.assertNat(result, "callHost.result");
  return result;
}

/**
 * Call CallbackSubtypes.callHostContainer.
 */
export function callHostContainer(arg0) {
  validate.assertCallback0cd085da803af7102cc3(arg0, "callHostContainer.arg0");
  const result = runtime.call("lean:CallbackSubtypes.callHostContainer", [runtime.prepareCallback(arg0, validate.wrapCallback0cd085da803af7102cc3(arg0, "callHostContainer.arg0"))]);
  validate.assertApplied$8b7defcfd3adf326d323(result, "callHostContainer.result");
  validate.assertNestedFin(result, {"arguments":[{"arguments":[{"constructor":null,"kind":"subtype"}],"kind":"option"},null],"kind":"result"}, "callHostContainer.result");
  return result;
}

/**
 * Call CallbackSubtypes.callHostMixed.
 */
export function callHostMixed(arg0) {
  validate.assertCallback2ad56570215cca826b8e(arg0, "callHostMixed.arg0");
  const result = runtime.call("lean:CallbackSubtypes.callHostMixed", [runtime.prepareCallback(arg0, validate.wrapCallback2ad56570215cca826b8e(arg0, "callHostMixed.arg0"))]);
  validate.assertNat(result, "callHostMixed.result");
  return result;
}

/**
 * Call CallbackSubtypes.makeClosure.
 */
export function makeClosure(arg0) {
  validate.assertNat(arg0, "makeClosure.arg0");
  const result = runtime.call("lean:CallbackSubtypes.makeClosure", [arg0]);
  validate.assertCallback0f78910188dae34fd8b0(result, "makeClosure.result");
  return validate.wrapCallback0f78910188dae34fd8b0(result, "makeClosure.result");
}

/**
 * Call CallbackSubtypes.makeContainerClosure.
 */
export function makeContainerClosure(arg0) {
  validate.assertNat(arg0, "makeContainerClosure.arg0");
  const result = runtime.call("lean:CallbackSubtypes.makeContainerClosure", [arg0]);
  validate.assertCallbackc2ff96fa00e1ff712eba(result, "makeContainerClosure.result");
  return validate.wrapCallbackc2ff96fa00e1ff712eba(result, "makeContainerClosure.result");
}

/**
 * Call CallbackSubtypes.makeMixedClosure.
 */
export function makeMixedClosure(arg0) {
  validate.assertNat(arg0, "makeMixedClosure.arg0");
  const result = runtime.call("lean:CallbackSubtypes.makeMixedClosure", [arg0]);
  validate.assertCallback34f6a3c1043662b01ed6(result, "makeMixedClosure.result");
  return validate.wrapCallback34f6a3c1043662b01ed6(result, "makeMixedClosure.result");
}

export function withRecovery(operation, recovery) { return runtime.withRecovery(operation, recovery); }

export default Object.freeze({ callHost, callHostContainer, callHostMixed, makeClosure, makeContainerClosure, makeMixedClosure, withRecovery });
