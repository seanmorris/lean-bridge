# callbacksubtypes

Compiler-checked exports for callbacksubtypes.

Binding IR SHA-256: `abef6a1ecab297a3cf7dbad0cb7d2a45266f3807a0b2ff1367a1bf0b36ee79c9`

## Exports

### callHost

Call CallbackSubtypes.callHost.

### callHostContainer

Call CallbackSubtypes.callHostContainer.

### callHostMixed

Call CallbackSubtypes.callHostMixed.

### makeClosure

Call CallbackSubtypes.makeClosure.

### makeContainerClosure

Call CallbackSubtypes.makeContainerClosure.

### makeMixedClosure

Call CallbackSubtypes.makeMixedClosure.

## Assurance

