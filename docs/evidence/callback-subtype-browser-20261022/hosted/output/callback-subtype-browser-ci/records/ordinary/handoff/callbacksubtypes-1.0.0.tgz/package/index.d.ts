// Generated from Binding IR SHA-256 abef6a1ecab297a3cf7dbad0cb7d2a45266f3807a0b2ff1367a1bf0b36ee79c9.
/**
 * Checked Lean callback.
 */
export type Callback0cd085da803af7102cc3 = (arg0: Readonly<{ tag: "none" }> | Readonly<{ tag: "some"; value: bigint }>) => Readonly<{ ok: Readonly<{ tag: "none" }> | Readonly<{ tag: "some"; value: bigint }> }> | Readonly<{ error: string }>;

/**
 * Checked Lean callback.
 */
export type Callback0f78910188dae34fd8b0 = (arg0: bigint) => bigint;

/**
 * Checked Lean callback.
 */
export type Callback2ad56570215cca826b8e = (arg0: bigint, arg1: bigint) => bigint;

/**
 * Checked Lean callback.
 */
export type Callback34f6a3c1043662b01ed6 = (arg0: bigint, arg1: bigint) => bigint;

/**
 * Checked Lean callback.
 */
export type Callbackc2ff96fa00e1ff712eba = (arg0: ReadonlyArray<Readonly<{ tag: "none" }> | Readonly<{ tag: "some"; value: bigint }>>) => Readonly<{ tag: "none" }> | Readonly<{ tag: "some"; value: bigint }>;

/**
 * Checked Lean callback.
 */
export type Callbacke84eef4c26bca64196e6 = (arg0: bigint) => bigint;

export interface LeanOwnedCallable {
  readonly disposed: boolean;
  dispose(): boolean;
  [Symbol.dispose](): void;
}

/**
 * Call CallbackSubtypes.callHost.
 */
export declare function callHost(arg0: Callbacke84eef4c26bca64196e6): bigint;

/**
 * Call CallbackSubtypes.callHostContainer.
 */
export declare function callHostContainer(arg0: Callback0cd085da803af7102cc3): Readonly<{ ok: Readonly<{ tag: "none" }> | Readonly<{ tag: "some"; value: bigint }> }> | Readonly<{ error: string }>;

/**
 * Call CallbackSubtypes.callHostMixed.
 */
export declare function callHostMixed(arg0: Callback2ad56570215cca826b8e): bigint;

/**
 * Call CallbackSubtypes.makeClosure.
 */
export declare function makeClosure(arg0: bigint): Callback0f78910188dae34fd8b0 & LeanOwnedCallable;

/**
 * Call CallbackSubtypes.makeContainerClosure.
 */
export declare function makeContainerClosure(arg0: bigint): Callbackc2ff96fa00e1ff712eba & LeanOwnedCallable;

/**
 * Call CallbackSubtypes.makeMixedClosure.
 */
export declare function makeMixedClosure(arg0: bigint): Callback34f6a3c1043662b01ed6 & LeanOwnedCallable;

export declare function withRecovery<Args extends readonly unknown[], Result>(operation: (...args: Args) => Result, recovery: Result): (...args: Args) => Result;

declare const bindings: Readonly<{
  readonly callHost: typeof callHost;
  readonly callHostContainer: typeof callHostContainer;
  readonly callHostMixed: typeof callHostMixed;
  readonly makeClosure: typeof makeClosure;
  readonly makeContainerClosure: typeof makeContainerClosure;
  readonly makeMixedClosure: typeof makeMixedClosure;
  readonly withRecovery: typeof withRecovery;
}>;
export default bindings;
